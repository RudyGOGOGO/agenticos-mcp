# POC: working-computer setup and resume

This is the authoritative entry point for this flattened delivery. **Broader
feature development and latency optimization remain PAUSED.** The current task
permits handoff/bootstrap/portability corrections only. Resume implementation
only when the owner explicitly requests it on the work computer. Do not publish,
provision AWS, send messages to others, run broad qualification or make paid model
calls merely to verify packaging. Keep existing services, evidence, original task
deadlines, accounting and all UNKNOWN holds intact.

## 1. Source and current state

```text
agenticos/                         Core, isolated SDK, agent UI, migrations, tests, assets
  optimization/latency/            original optimization review and current checkpoint
simplified-vf-ios-app-and-backend/ reusable native Agent integration + mock VF/backend
mcp/                               reusable Java MCP service
supportive_docs/                    design, shared contracts, evidence, deployment references
AGENTS.md                           this setup/resume entry point
.gitignore                          required upload exclusions
```

The three root code folders are the editable delivery source. Use one owner-chosen
Git repository at this root; do not accidentally add nested repositories/submodule
pointers. Old component Git metadata and caches are retained only under ignored
`supportive_docs/local-only/`; exclude that directory from copies/uploads. It is
not needed to build or run. Do not omit required tests, locks, schemas or UI assets
just to shrink the archive. The clean archive/file manifest includes them.

[Current checkpoint](supportive_docs/coordination/paused-handoff.json),
[bootstrap validation](supportive_docs/coordination/portable-bootstrap-validation.json),
and [source manifest](supportive_docs/coordination/handoff-manifest.json) distinguish
source baselines, current content hashes and installed artifacts. Original baseline
commits are Core`438154bd282e0cf6cf9400ca282a2ebab9bb2618`, export`15c42d6eae3e29f398a188ad71e9176529a7c643`,
app/backend`eab558a598d1facd972cae4a29a27c4678f280a4`, MCP`4bb797d9af8944853811d2c25a1b057c60d42607`.
Bootstrap/path changes are a recorded source change set, not invented Git commits.
The old production/WP checkout is not a build/development prerequisite.

Original Mac services remain on190xx with installed Core1f967152/SDKae0a353,
Java22809e0, backend840c355 and native build24/1302932. Fresh validation uses separate
191xx listeners and new state/identities. Its wheels include the current source
(including previously staged latency fixes); it is not an upgrade of the original
services or a measured end-to-end speedup. Older images/packages retain their exact
original pins. Failed reports and54original UNKNOWN holds remain retained.

The fresh local initializer is now implemented at
`supportive_docs/local-setup/local.py`. Source/build, fresh startup, and prior
end-to-end acceptance are different claims. Default startup deliberately **denies
model reservations**; it cannot answer Agent requests or perform model-driven
changes. This verifies real setup/authentication/connectivity without a paid call.
Actual planning requires approved private provider/accounting inputs below.
The full native create/edit/confirm/write/result/readback/reopen journey is still
**OPEN**. Prior actual native form/amendment and older-record readback are partial
evidence, not completion of that gate.

## 2. Prerequisites and private paths

Qualified full local placement: **Apple-silicon macOS**, Docker Desktop/local Unix
socket, Xcode with an installed compatible iOS Simulator runtime. This validation
used macOS26.6.2, Xcode27.2(27B52), Node22.22.2/npm10.9.7, uv0.10.12 and Python3.12.2.
Docker Desktop4.71.0 exposed client29.8.2/server29.4.1; other Docker versions are
not independently qualified by this handoff.
Core/SDK require Python>=3.12,<3.13; use Python3.12 to invoke the setup script.
The native source minimum is iOS17, not a qualification of every older Xcode/runtime.
Intel/Windows full-stack native placement and physical-device signing are unqualified.
Physical devices need approved signing/provisioning and appropriate HTTPS/IdP routes.

**An external SSD is not required.** Select canonical private storage outside the
checkout, with at least24GiB free before build; the product keeps its20GiB growth
floor. Docker requires its own adequate backing storage (at least2CPUs/4GiB memory
for the local foundation). Do not change shared Docker settings or prune others'
resources. Direct/keyword POC starts no Temporal service/Cloud, Firecracker, EFS,
embedding service or AWS resources. Some Temporal/embedding Python libraries remain
locked package dependencies; this does not require their services.

External downloads are public artifacts/dependencies, not old installed environments:

- Core and SDK dependency bytes/versions: their separate `uv.lock` files.
- UI dependencies: `agenticos/ui/package-lock.json` (`npm ci --ignore-scripts`).
- Backend dependencies: `poc/vf-test-backend/requirements-lock.txt` in the app repo.
- Corretto21.0.13.0.11 and Maven3.9.11/wrapper3.3.4: existing toolchain/wrapper pins;
  builder verifies the JDK archive and all82runtime jar hashes.
- OPA1.21.1: `agenticos/deploy/source-lock.json`, fetched and hash-checked by the product.
- PostgreSQL16.15/vector0.8.2 local image: fixed Docker recipe and two immutable base
  digests in `agenticos/deploy/profiles/`. A newly built local image ID is verified
  against actual version/library bytes and bound to that installation. An old local
  image ID is not an acquisition URL and is never assumed on the new computer.
- Xcode/Simulator runtime and Docker Desktop are installed operator prerequisites.

```sh
# Run from your copied/cloned project root; replace these paths for THIS computer.
export POC_PROJECT="$PWD"
export POC_STATE=/absolute/private/runtime/poc
mkdir -p "$(dirname "$POC_STATE")"
export POC_DOCKER_ENDPOINT="$(docker context inspect --format '{{.Endpoints.docker.Host}}')"
# The endpoint must be an explicit local unix:///... socket.
python3.12 supportive_docs/local-setup/local.py build \
  --state "$POC_STATE" --docker-endpoint "$POC_DOCKER_ENDPOINT"
python3.12 supportive_docs/local-setup/local.py init --state "$POC_STATE" --port-base 19110
python3.12 supportive_docs/local-setup/local.py start --state "$POC_STATE"
python3.12 supportive_docs/local-setup/local.py status --state "$POC_STATE"
```

`build` requires a new state leaf and creates a private source snapshot, separate
locked Core/SDK/backend environments, UI/wheels, installed wheel artifacts, Java
jar and storage image. It does not copy installed dependencies, cached wheels,
private databases or keys from the old Mac. Repeated builds/init refuse existing
or partial state instead of overwriting it. Private logs and numbered failure
records stay under the state directory; failures do not authorize resetting data.
`init` uses existing ownership/migration/operator/assurance/backend primitives:
new three-store Core installation, immutable control105/RDS component migrations,
new operator/artifact/SDK/TLS/effect/observer/Host keys, a distinct least-privilege
VF database with atomic schema+seed, and the actual app-owned signed-out registry.
No hand-written READY/ACTIVE record is used. Memory journals are provisioned by
the normal registered family composition. The historical template is only a shape
reference; the initializer emits actual runnable protected configuration.

Default synthetic seed anchor is current UTC, shifted by the existing seed loader.
New environment/application/installation/session UUIDs and keys are fresh. Public
fixed local wire-scope identifiers are protocol labels, not transplanted private
installation identity. The source snapshot receives the matching nonsecret native
configuration; the checkout's original Debug defaults are not silently adopted.
`VF_SSD_ROOT` is a legacy name for one private issuer directory, not a drive rule.

## 3. Startup, readiness and native login

Default port base19110 yields:

| Service | Local endpoint |
|---|---|
| Core |19110; `/os/health` |
| Host/native bootstrap |19111; `/native/bootstrap`, `/native/session-changed` |
| Private Core/SDK RPC |19112 HTTPS, generated pinned local certificate |
| Four owned OPA services |19113–19116 |
| Synthetic owner assurance |19117 |
| Java MCP Streamable HTTP |19118 `/mcp`; `/actuator/health/readiness` |
| Separate private MCP receipt observation |19119 `/private/v1/receipt-observations` |
| VF native/business API |19120 `/api/v1`; `/health` |
| Private backend account/receipt observer |19121; authenticated only |

Startup order is owned storage→backend→observer→Java→assurance→Core, then native.
The helper waits for actual dependency listeners/readiness and records exact
process identities; it does not adopt occupied ports or certify whole acceptance.
Use a different port base for another environment. Core's general mature-baseline
installer/readiness commands include excluded stores; use this selected POC entry.

```sh
curl --fail http://127.0.0.1:19120/health
curl --fail http://127.0.0.1:19118/actuator/health/readiness
curl --fail http://127.0.0.1:19110/os/health
# Optional focused HTTP connectivity check, in an idle NEW synthetic environment:
python3.12 supportive_docs/local-setup/check_connectivity.py --state "$POC_STATE"
# It performs actual test sign-in, Host/DPoP bootstrap, MCP read, receipt observation
# and revocation; no Agent task/model/business effect. Ends signed out.
python3.12 supportive_docs/local-setup/local.py ios-build --state "$POC_STATE"
xcrun simctl list devices available
# Select/boot a suitable Simulator; do not overwrite another active test app.
export POC_SIMULATOR=YOUR_SIMULATOR_UUID
xcrun simctl bootstatus "$POC_SIMULATOR" -b
xcrun simctl install "$POC_SIMULATOR" "$POC_STATE/ios-derived/Build/Products/Debug-iphonesimulator/VFMock.app"
xcrun simctl launch "$POC_SIMULATOR" com.example.agenticos.vfpoc
```

Use the generated private build's **VFMock-Family**, Debug configuration. Its
existing resource phase bundles the generated family-local Config.json. Build
verification compares the bundled config with the initialized environment. The
handoff builds the native product but does not install it over the original app.
On the work laptop: app icon→Sign in(test-user-001)→Home→Agent. Account exposes
sign-out/restricted synthetic account switching. Ordinary chat/forms/review/progress/
results/history stay inside WKWebView and trusted in-app containers, not Chrome.
No operator script is required for ordinary owner interactions.

The native opaque local credential is non-expiring and revocable in Keychain;
OS/Host/account/receipt/execution tokens remain finite and are transparently renewed
through the pinned local issuers/current native epoch. Sign-out, switch/revoke or
explicit environment stop ends authorization; restarting never signs in for you.
Original120-second task horizons and per-action authorization/confirmation remain
unchanged. Credential renewal never revives an expired task or replays uncertainty.
Long idle renewal/native reconnect/current full write acceptance remain separate
open gates; a startup check does not waive them. The generated private RPC test
certificate has finite validity (365days); later certificate renewal is an operator
maintenance step at idle, not a login or task extension.

## 4. Enable real planning without resetting accounting

No API key, allowance, issuer key, database or private history is included in the
shareable folder. Provide an owner-only API credential file and **the existing
approved cumulative allowance ledger with every UNKNOWN hold intact**, through a
secure operator path. Ensure one active writer for that allowance when moving
computers. Never create a replacement/reset ledger to get past a guard.

An approved protected controls JSON has the existing schema: `profile` is
`synthetic-openai-analysis-qualification/1` (or supported lookup profile),
`credentialFile` and `allowanceFile` are absolute private file references,
`accountPolicyRef` is the actual approved policy reference. No secret value belongs
in source, shell arguments, logs or model context. Do not paste it into chat.

Choose controls **before initial profile registration** when possible:

```sh
# For a NEW initialized environment with approved private inputs available:
python3.12 supportive_docs/local-setup/local.py init --state "$POC_STATE" \
  --port-base 19110 --live-controls /absolute/private/approved-controls.json
# Default start is still NO-MODEL, even when controls were supplied at init.
python3.12 supportive_docs/local-setup/local.py start --state "$POC_STATE"
# After verified idle stop, explicitly select the real existing allowance controller:
python3.12 supportive_docs/local-setup/local.py stop --state "$POC_STATE"
python3.12 supportive_docs/local-setup/local.py start --state "$POC_STATE" \
  --live-controls /absolute/private/approved-controls.json
```

The commands above are alternative setup paths, not permission to repeat `init` on
populated state. For an existing no-model environment whose immutable model/privacy
pins differ, create a new environment with the approved controls; do not rewrite
registered profiles. The helper refuses mismatched pins before starting services.
Actual live-provider execution was deliberately not performed for packaging.
Providing the operator inputs is a prerequisite; the initializer/runtime engineering
is implemented. Whole fresh live-model/native acceptance remains unverified.

## 5. Source interfaces for the teams

All app paths below are under `simplified-vf-ios-app-and-backend/`:

| Source | Reuse/adaptation |
|---|---|
| `poc/mock-vf-ios/App/AgentSurface.swift` | WKWebView coordinator, bootstrap/control transport, popup review/ceremony containers, account/lifecycle teardown |
| `poc/mock-vf-ios/Sources/VFCore/EmbedControl.swift` | Origin/main-frame/nonce/source/generation/replay state machine; do not add native planning or conversation parsing |
| `poc/mock-vf-ios/Sources/VFCore/TrustedReviewNavigation.swift`, `OIDCAssuranceConfiguration.swift` | Trusted in-app navigation and approved assurance binding |
| `poc/mock-vf-ios/App/API.swift`, `Sources/VFCore/TokenBinding.swift` | Real HTTP/session integration and purpose/environment/account Keychain separation; replace local identity with real Host/IdP integration |
| `poc/mock-vf-ios/App/Store.swift` | Native data refresh/readback; adapt business repositories, preserve verified readback |
| `poc/mock-vf-ios/Sources/VFCore/Outbox.swift`, `NativePayload.swift` | Exact per-effect intent/key/revision and explicit durable recovery; never auto-retry an uncertain effect with a new key |
| `poc/mock-vf-ios/App/Views.swift`, `Editors.swift`, `FamilyStyle.swift` | Mock VF business screens/styles |
| `poc/vf-test-backend/vf_backend/`, `scripts/issue_*_token.py` | Synthetic backend and local-only test issuers, not production identity implementations |

The Agent UI/forms/history/streaming/progress/results are in
`agenticos/ui/shell/main.tsx`, `ProductionReview.tsx` and related UI modules.
Preserve exact confirmed values, independent trusted confirmation, current
capability/resource scope, original task deadlines, idempotency and receipts.
Test drivers under `UITests/` and `run_native_*` are not ordinary product controls.
Original-Mac-only operators are explicitly disabled/marked historical; do not use
them as portable setup or treat a driver failure as a product failure.

Java: `mcp/src/main/resources/catalog.json` declares nine tools; `ports/`/`contracts/`
under `src/main/java/com/vf/poc/` are independent Java interfaces/DTOs. Normal transport
is MCP2025-11-25 Streamable HTTP. `adapters/local/BackendHttpClient.java`,
`HttpOperationAdapters.java`, `BackendConfiguration.java`, `mapping/`, `errors/`,
and `adapters/aws/DelegatedCredentials.java` are the real VF API/auth replacement
boundary. Validate actual subject delegation, units/precision, null clearing,
history coverage/errors, idempotency horizon, revision/ETag concurrency and receipt
semantics. Do not promise configuration-only switching; `aws-real` stays disabled.
Mutation calls require the exact signed EffectCallContext, confirmed JCS argument
hash, operation/key/revision and original authority; dispatched uncertainty remains
UNKNOWN. Receipt observation has independent scope and grants no execution.

Core package: `agenticos/src/agentic_os/`; SDK package:
`agenticos/harnesses/agent-worker/src/agentic_os_agent_worker/`. Core MCP2.2.0 and SDK
MCP1.30.0 stay in separate environments. Core owns canonical SQL tasks/budgets/
receipts, memory consent/deletion and schedules; the SDK is supervised over private
TLS. VF-specific bindings are in `adapters/poc/family_*`, mapping/Host/capability
configuration; local synthetic authentication is separate from configured AWS
identity. Do not introduce a new SDK/framework or hardcode scenario replies.

## 6. Rebuild, restart and safe fixtures

The builder writes environments/artifacts/source under the private state, not the
checkout. `build.json` records those paths; a reused environment may point to the
explicit original build state. Rebuild only what changed, at a verified idle point:

- Core Python: copy reviewed changed source into a new/private build snapshot,
  stage maintained resources with `poc/checks/stage_resources.py`, `uv build --wheel
  --project SNAPSHOT/agenticos --out-dir PRIVATE_WHEELS`, then use `uv pip install
  --python CORE_PYTHON --no-deps --reinstall NEW_WHEEL`. Reuse locked dependencies.
- Core UI: `npm ci --ignore-scripts` only when the lock/dependencies changed; run
  `npm run build` in the private snapshot's `agenticos/ui`, stage resources and
  rebuild/install the Core wheel. UI generated output/dependencies are not source.
- SDK: build from `agenticos/harnesses/agent-worker` and install into SDK_PYTHON only;
  never install Core there or qualify into a live SDK environment.
- Backend: use its locked backend environment and the reviewed source snapshot;
  changing pinned issuer helpers requires regenerating/reviewing issuer source pins
  at idle, never disabling their hash checks.
- Java: existing wrapper `mcp/mvnw -B -ntp -Dmaven.repo.local=PRIVATE_M2
  -Dmcp.build.dir=PRIVATE_BUILD package` with the pinned JAVA_HOME/MAVEN_USER_HOME;
  run `scripts/VerifyDependencies.java` against its dependency lock. Select a new
  jar in the protected build reference at idle; don't overwrite a running artifact.
- Native: `local.py ios-build` rebuilds the selected private app snapshot/config;
  install only into the intended Simulator. No physical signing is claimed.

```sh
python3.12 supportive_docs/local-setup/local.py stop --state "$POC_STATE"
# Optional complete storage stop, preserving volumes and data:
python3.12 supportive_docs/local-setup/local.py storage-stop --state "$POC_STATE"
python3.12 supportive_docs/local-setup/local.py storage-start --state "$POC_STATE"
python3.12 supportive_docs/local-setup/local.py start --state "$POC_STATE"
# Fresh alternative fixture/environment, reusing ONLY explicitly selected builds:
python3.12 supportive_docs/local-setup/local.py new-environment \
  --build-state "$POC_STATE" --state /absolute/private/runtime/another-poc
python3.12 supportive_docs/local-setup/local.py init \
  --state /absolute/private/runtime/another-poc --port-base 19210
```

Stop refuses nonterminal tasks, uncertain/unsettled work, outstanding budgets and
active/unknown learning jobs, then signals only exact recorded processes. Do not
force-kill/replay to get past a refusal. Storage start verifies ownership/image and
actual schema heads; if Docker reallocates a port, only the protected VF connection
configuration is updated after the product's guard accepts it. Never re-run init
on populated state. No reset/prune/delete is part of this lifecycle.
The separate opt-in local backend reset refuses fixtures with recorded effects;
prefer a new environment. Never erase OS accounting, memory, receipts, native outbox
or UNKNOWN holds to reset a demo. No catch-up execution is implied by restart.

## 7. Hands-on acceptance after funded setup

Use the native app as primary. Separate read/change/memory assistant choices remain
a usability limitation. Ask a complete saved-location/boundary summary with name,
address, member, radius units, notification, enabled, updatedAt and ruleStatus.
Then request a uniquely named synthetic place with explicit address/coordinates
and its member geofence. Edit the actual generated form, save edits, inspect final
trusted values and explicitly confirm. Require a canonical committed receipt and
verified Agent result before native Saved Locations/detail/coordinates/member/
radius/notification/enabled readback; leave/reopen and refresh to check persistence.

Use the actual UI-generated continuation for a compound request, with fresh Send
and independent confirmation; don't reconstruct it from operator IDs and call it
natural completion. Exercise explicit Remember selected message/Memory & privacy,
recall/correction/Forget and the separate standing-inference consent path. Supported
finite read schedules/advisory reflection exist; inbox-to-confirmed-effect and
future consequential scheduling remain local work. Forced native stream reconnect,
affected access renewal/revocation and conversational quality still need affected
acceptance. Source/component checks do not close these gates.

Retained timings: native form22.242s/trusted review27.977s in a partial journey;
older browser read30.992s to meaningful output; historical write83–87s includes
operator time. There is no new latency improvement claim from this bootstrap test.

## 8. Deployment reference and exact resume

`supportive_docs/deployment_aws/` is reference/operator material, not a runnable
managed export target. Its obsolete `sync.py` CLI now refuses execution; do not
remove that guard. For AWS source builds use `agenticos/poc/build_image.py` with
its owned build target and current wheels; Java/backend have their own Dockerfiles.
[Deployment entry](supportive_docs/deployment_aws/README.md),
[POC initialization](supportive_docs/deployment_aws/poc-a1/INITIALIZATION.md),
[credential publication](supportive_docs/deployment_aws/poc-a1/CREDENTIAL-PUBLICATION.md)
and [MCP configuration](mcp/docs/A1-CONFIGURATION.md) retain approved configuration,
role/TLS/issuer/secret/registry requirements. Select actual current artifact digests;
do not relabel old archives as this new source. Runtime `/operator` examples refer
to an assembled deployment image/package; checkout helpers are under
`supportive_docs/deployment_aws/poc-a1/`. No AWS resources were provisioned here.
For later upstream synchronization, map `agenticos/` to canonical `modules/agentic-os/`,
review/commit there, run the original conflict-safe export into a new staging target,
and review the projection back. Never run it directly against this flattened tree.
AWS/approved IdP/real Verizon qualification is external; unfinished local/native
acceptance is not. [Archived previous guides](supportive_docs/previous-root-guides/README.md)
are explicitly superseded and have no current agent-instruction authority.

Copyable prompt for the work-computer session:

> Resume on this computer in the current `agenticos_for_poc` checkout. Read root
> AGENTS.md, supportive_docs/coordination/paused-handoff.json and
> agenticos/optimization/latency/README.md. Preserve active operations, exact source
> and installed revisions, failed reports, original deadlines/accounting and UNKNOWN
> holds. Set this computer's checkout/private state/Docker paths; run the supported
> local build/init/start/native-build sequence with fresh synthetic identities.
> Use no-model mode until approved provider controls and the original allowance are
> available; never fabricate readiness, copy old runtime state or create a new budget.
> After setup, responsiveness is the next development priority: reconcile already
> staged graph/SQL/MCP/diagnostic fixes, finish remaining P0 delivery waits, use cheap
> affected guards and one necessary comparable native read with the same model.
> Then resume eligible simple reads/context/forms and the still-open actual native
> create/edit/confirm/write/result/readback/reopen, compound and remaining acceptance.
> Reuse compatible evidence, keep services available, update implemented/integrated/
> external status, and never mark incomplete native or AWS gates passed.
