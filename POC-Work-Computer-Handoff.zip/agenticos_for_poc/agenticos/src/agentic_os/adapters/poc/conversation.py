"""Canonical controller/outbox with finite direct placement and no replay."""
import asyncio
import time
import logging
import traceback
from pathlib import Path

from agentic_os.errors import OSErrorCode
from agentic_os.production.conversation_service import AgentConversationService
from agentic_os.identity.context import timestamp,utcnow


class DirectConversationService(AgentConversationService):
    def __init__(self,verified,presentation,*,activity_timeout_ms=None):
        super().__init__(verified,presentation,activity_timeout_ms=activity_timeout_ms)
        self.driver=verified.models.admission.execution_driver
        if self.driver is None:
            raise ValueError('Explicit direct placement required')

    async def tick(self):
        await self.driver.stop_terminal()
        for actor,context in await asyncio.to_thread(self.controller.pending):
            if self._stopping:return
            execution_id=self.driver.execution_id(dict(**context['subject'],taskId=context['taskId']))
            failed=False;execution={}
            try:
                execution=await self.driver.inspect(execution_id)
                failed=execution['state'] in {'INTERRUPTED','EXITED'}
            except OSErrorCode as error:
                if error.code!='NOT_FOUND':raise
            # The original controller retains Stop/deadline/current owner and
            # accounting. Process exit cannot publish a successful result.
            result=await self.controller.poll(actor,context,failed=failed)
            if result['interrupted'] or result.get('terminal'):continue
            if self.resources is not None:
                try:await self.resources.publish(actor,context)
                except OSErrorCode:pass
            if execution.get('state')=='RUNNING':
                try:
                    control=await self.driver.status(context)
                    if control['notBefore'] is not None and timestamp(control['notBefore'])>utcnow():continue
                    operation=control['operationId']
                    waiting=control['status'] in {'waiting-resources','waiting-reconciliation'}
                    if waiting and operation is not None:
                        allowed=(self.resources is not None and await self.resources.can_resume(actor,context,operation))
                        if not allowed and control['status']=='waiting-reconciliation':
                            allowed=await self.controller.can_resume_accepted(self.dispatcher.models,actor,context,operation)
                        from agentic_os.production.profiles import selected_journey
                        selected=selected_journey(self.controller.presentation.verified,context)
                        if not allowed and getattr(selected,'reviews',None) is not None:
                            allowed=await asyncio.to_thread(selected.can_resume,actor,context,operation)
                        if not allowed and getattr(selected,'proactivity',None) is not None:
                            allowed=await asyncio.to_thread(selected.can_resume,actor,context,operation)
                        if allowed:await self.driver.resume(context,operation)
                except OSErrorCode:pass
        if self._stopping:return
        await self.dispatcher.tick()
        if time.monotonic()>=self.retention_due:
            applications=sorted({value[0] for value in self.controller.admission._selected})
            self.retention_status=await asyncio.to_thread(self.retention.sweep,applications,after=self.retention_after)
            self.retention_after=self.retention_status['next']
            self.retention_due=time.monotonic()+60

    async def close(self):
        await self.driver.close()

    async def run(self):
        previous=None
        try:
            while not self._stopping:
                try:
                    await self.tick()
                    previous=None
                except Exception as error:
                    # Retain bounded diagnostic locations without SQL values,
                    # credentials, user content or exception argument strings.
                    frames=traceback.extract_tb(error.__traceback__)
                    signature=(type(error).__name__,getattr(error,'code',None),
                        tuple((Path(frame.filename).name,frame.lineno) for frame in frames))
                    if signature!=previous:
                        logging.getLogger(__name__).error('Direct coordinator failed: %r',signature)
                        previous=signature
                if not self._stopping:await asyncio.sleep(1)
        finally:self._stopping=False
