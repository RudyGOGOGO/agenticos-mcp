"""Disjoint approved Core workload identities for execution and observation.

These credentials authenticate the workload. Execution still needs current
Host scope and, for mutations, the original canonical reviewed permit.
"""
from copy import deepcopy
import hashlib
from pathlib import Path
import time
from urllib.parse import urlsplit
from uuid import UUID,uuid4

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
import jwt

from agentic_os.adapters.local.files import private_read
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import timestamp
from .effect_context import EffectContracts,MCPBearerVerifier


class MCPWorkloadCredentials:
    def __init__(self,*,target,namespace,tenant,wire_namespace,subjects,execution,observer,contracts):
        if (target!='aws-test' or type(contracts) is not EffectContracts
                or type(namespace) is not dict or set(namespace)!={'installationId','applicationId'}
                or any(str(UUID(v))!=v for v in namespace.values())
                or type(wire_namespace) is not dict or set(wire_namespace)!={'installation','application','environment','client_id'}
                or any(type(v) is not str or not 1<=len(v)<=128 for v in wire_namespace.values())
                or wire_namespace['environment']=='local' or not wire_namespace['environment'].startswith('vf-')
                or type(tenant) is not str or not 1<=len(tenant)<=128
                or type(subjects) is not list or not 1<=len(subjects)<=16 or len(set(subjects))!=len(subjects)
                or any(type(s) is not str or not 1<=len(s)<=128 for s in subjects)):
            raise ValueError('Approved A1 workload namespace and subjects required')
        self.namespace,self.wire,self.tenant=deepcopy(namespace),deepcopy(wire_namespace),tenant
        self.subjects,self.tools=frozenset(subjects),frozenset(contracts.tools)
        self.execution,self.execution_key=self._key(execution)
        self.observer,self.observer_key=self._key(observer)
        if (self.execution['audience']!='vf-mcp' or self.observer['audience']=='vf-mcp'
                or self.execution['client_id']!=wire_namespace['client_id']
                or self.execution['client_id']==self.observer['client_id']
                or self.execution['public_key_sha256']==self.observer['public_key_sha256']):
            raise ValueError('Disjoint execution/observation trust and fixed effect audience required')
        self.verifier=MCPBearerVerifier(target='aws',key=self.execution_key.public_key(),algorithm='RS256',
            issuer=self.execution['issuer'],key_id=self.execution['key_id'],core_namespace=namespace,wire_namespace=wire_namespace)

    @staticmethod
    def _key(value):
        if type(value) is not dict or set(value)!={'issuer','audience','key_id','client_id','key_file','public_key_sha256'}:
            raise ValueError('Closed workload signing configuration required')
        endpoint=urlsplit(value['issuer'])
        if (endpoint.scheme!='https' or not endpoint.hostname or endpoint.username or endpoint.password
                or endpoint.query or endpoint.fragment or any(type(value[k]) is not str or not 1<=len(value[k])<=128
                    for k in ('audience','key_id','client_id')) or not Path(value['key_file']).is_absolute()):
            raise ValueError('Approved HTTPS issuer and protected signing key required')
        key=serialization.load_pem_private_key(private_read(Path(value['key_file']),16384),password=None)
        if not isinstance(key,RSAPrivateKey) or not 2048<=key.key_size<=4096:raise ValueError('Approved RSA workload key required')
        public=key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
        if hashlib.sha256(public).hexdigest()!=value['public_key_sha256']:raise ValueError('Workload public verification pin differs')
        return deepcopy(value),key

    def _subject(self,subject):
        validate_contract('SubjectRef',subject)
        if (any(subject[k]!=v for k,v in self.namespace.items()) or subject['tenantId']!=self.tenant
                or subject['subjectId'] not in self.subjects):raise OSErrorCode('DENIED')

    def execution_token(self,subject,tool,until):
        self._subject(subject)
        if tool not in self.tools:raise OSErrorCode('DENIED')
        now=int(time.time());expiry=min(now+60,int(timestamp(until).timestamp()))
        if expiry<=now:raise OSErrorCode('DENIED')
        profile=self.execution
        return jwt.encode(dict(iss=profile['issuer'],aud=[profile['audience']],sub=subject['subjectId'],
            **self.wire,tools=[tool],iat=now,exp=expiry),self.execution_key,algorithm='RS256',
            headers=dict(typ='JWT',kid=profile['key_id']))

    def observation_token(self,subject):
        # Historical observation has fresh disjoint workload authority. It
        # never recreates a tool scope or renews an original execution horizon.
        self._subject(subject);profile=self.observer;now=int(time.time())
        wire={**self.wire,'client_id':profile['client_id']}
        return jwt.encode(dict(iss=profile['issuer'],aud=[profile['audience']],sub=subject['subjectId'],
            **wire,scope='receipt:observe',jti=str(uuid4()),iat=now,exp=now+60),self.observer_key,algorithm='RS256',
            headers=dict(typ='JWT',kid=profile['key_id']))
