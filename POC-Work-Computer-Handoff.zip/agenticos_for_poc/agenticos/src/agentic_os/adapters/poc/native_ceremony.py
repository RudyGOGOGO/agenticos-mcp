"""Native-only local owner command transport into the existing ceremony.

The native trusted container supplies its authenticated login and an explicit
owner command. Neither a model request nor a login refresh invokes this route.
The existing provider creates/verifies the assertion; Core still separately
validates the review decision and finite execution permit.
"""
import asyncio
from copy import deepcopy
import hashlib
from pathlib import Path
import re
from uuid import UUID

import httpx
from sqlalchemy import select

from agentic_os.adapters.local.files import private_read
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.postgres.models import AgentReviewChallenge,AgentReviewRecord,InteractiveSession
from agentic_os.admission.service import guarded_owner
from agentic_os.contracts.canonical import parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.effects.assurance import check_binding
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import InteractivePrincipal,utcnow
from agentic_os.identity.service import scoped


class LocalNativeCeremony:
    def __init__(self,*,reviews,host,client_profile):
        from agentic_os.production.review import ProductionReviews
        from .local_synthetic_access import LocalNativeAccess
        if (type(reviews) is not ProductionReviews or reviews.oidc
                or type(host.local_access) is not LocalNativeAccess or type(client_profile) is not str):
            raise ValueError('Explicit local native ceremony composition required')
        self.reviews,self.host,self.access,self.profile=reviews,host,host.local_access,client_profile

    def _challenge(self,subject,command,native):
        with self.reviews.store.transaction() as db:
            row=db.scalar(select(AgentReviewChallenge).where(*scoped(AgentReviewChallenge,subject),
                AgentReviewChallenge.id==UUID(command['challengeId'])))
            review=db.get(AgentReviewRecord,row.review_id) if row else None
            session=db.scalar(select(InteractiveSession).where(*scoped(InteractiveSession,subject),
                InteractiveSession.id==row.session_id)) if row else None
            if (row is None or review is None or session is None or row.expires_at<=utcnow()
                    or session.embed_ref!=self.host.embed_ref):raise OSErrorCode('DENIED')
            binding=deepcopy(row.binding);check_binding(binding)
            if (binding['subject']!=subject or binding['sessionId']!=str(session.id)
                    or binding['hostSessionRef']!=session.host_session_ref
                    or binding['sessionGeneration']!=session.session_generation):raise OSErrorCode('DENIED')
            actor=InteractivePrincipal(subject,session.id,session.session_generation,session.application_generation,
                session.subject_generation,session.host_session_ref,self.profile,binding['policyGeneration'])
            guarded_owner(db,actor,read_only=True)
            host_session=self.host.sessions.get(session.host_session_ref)
            if not host_session or host_session.get('native')!=native:raise OSErrorCode('DENIED')
            return actor,str(review.task_id),str(review.id),binding

    async def confirm(self,subject,authorization,command):
        validate_contract('SyntheticOwnerCeremonyCommand',command)
        native=await self.access.native(subject,authorization)
        actor,task_id,review_id,binding=await asyncio.to_thread(self._challenge,subject,command,native)
        context,_=await asyncio.to_thread(self.reviews._context,actor,task_id)
        await self.access.check_root(context)
        # This reuses current review/source/owner checks and the exact amended
        # proposal. An obsolete or expired challenge never gets a new horizon.
        view=await self.reviews.view(actor,task_id)
        if view['reviewId']!=review_id or view['proposal']['digest']!=binding['proposalDigest']:
            raise OSErrorCode('CONFLICT')
        assurance=self.reviews.assurance_for(subject)
        assurance.check_provider(binding);await assurance.current()
        selected=await asyncio.to_thread(self._challenge,subject,command,native)
        if selected!=(actor,task_id,review_id,binding):raise OSErrorCode('CONFLICT')
        config_path=Path(load_manifest(assurance.manifest)['root'])/'synthetic-assurance/config.json'
        raw=private_read(config_path,16384)
        if hashlib.sha256(raw).hexdigest()!=assurance.binding['fixtureConfigDigest']:raise OSErrorCode('DENIED')
        config=parse_canonical_json(raw)
        owners=[owner for owner in config['owners'] if owner['subject']==subject]
        if len(owners)!=1 or re.fullmatch('[A-Za-z0-9_-]{43,128}',owners[0]['ceremonyKey']) is None:
            raise OSErrorCode('DENIED')
        # Only the distinct owner credential reaches this existing owner-only
        # route. The controller credential never authorizes a confirmation.
        try:
            async with httpx.AsyncClient(trust_env=False,follow_redirects=False,timeout=3) as client:
                response=await client.post(assurance.binding['origin']+'/ceremony/confirm',json=command,
                    headers={'Authorization':'Bearer '+owners[0]['ceremonyKey'],'Accept-Encoding':'identity'})
            if response.status_code!=200 or len(response.content)>4096:raise OSErrorCode('DENIED')
            result=parse_canonical_json(response.content)
            if (type(result) is not dict or set(result)!={'assertionRef'}
                    or re.fullmatch('assertion/[a-f0-9-]{36}',result['assertionRef']) is None):raise OSErrorCode('DENIED')
            UUID(result['assertionRef'][10:])
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None
        # An uncertain transport result is never repeated here. Only its
        # assertion is returned; the unchanged review command accepts it later.
        if await self.access.native(subject,authorization)!=native:raise OSErrorCode('DENIED')
        await assurance.current();check_binding(binding)
        return result
