"""Configured native bootstrap over the existing Core challenge and exchange.

The Host retains only finite session bindings, never the native bearer. Product
reads, owner assurance, Core tickets and DPoP remain separate authorities.
"""
import asyncio
from copy import deepcopy
from datetime import datetime,timedelta,timezone
from pathlib import Path
import time
from uuid import UUID,uuid4

from fastapi import FastAPI,Request
from fastapi.responses import JSONResponse
import httpx

from agentic_os.adapters.http.endpoint import reviewed_parent_origin
from agentic_os.adapters.http.tls import reviewed_tls_context
from agentic_os.adapters.local.files import private_read
from agentic_os.adapters.local.resources import canonical_path,read_signed,write_signed
from agentic_os.contracts.canonical import parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import iso,timestamp,utcnow
from .account_observation import PrivateAccountObservation
from .native_host_identity import NativeHostVerifier
from .placement import LOCAL_IDENTITY_HEADERS


class ConfiguredNativeBootstrap:
    def __init__(self,*,target,verifier,accounts,control,namespace,tenant,host_origin,core_origin,
            embed_ref,client_profile,bridge_key,session_file,session_key_file,ca_file,ca_sha256):
        if (target!='aws-test' or type(verifier) is not NativeHostVerifier
                or type(accounts) is not PrivateAccountObservation or accounts.network!='web-pki/1'
                or accounts.trust['ca_file'] is None or accounts.trust['ca_sha256'] is None
                or ca_file is None or ca_sha256 is None
                or not callable(control) or accounts.namespace!=namespace or accounts.environment!=verifier.environment
                or type(namespace) is not dict or set(namespace)!={'installationId','applicationId'}
                or any(str(UUID(v))!=v for v in namespace.values())
                or type(tenant) is not str or not 1<=len(tenant)<=128
                or type(embed_ref) is not str or not 1<=len(embed_ref)<=128
                or type(bridge_key) is not str or not 32<=len(bridge_key)<=256):
            raise ValueError('Exact configured native identity, private account and Host binding required')
        self.verifier,self.accounts,self.control=verifier,accounts,control
        self.namespace,self.tenant=deepcopy(namespace),tenant
        self.host_origin=reviewed_parent_origin(host_origin,'web-pki/1')
        self.core_origin=reviewed_parent_origin(core_origin,'web-pki/1')
        self.embed_ref,self.bridge_key=embed_ref,bridge_key
        validate_contract('ClientProfile',client_profile)
        if client_profile['assurance']!='dpop-qualified':raise ValueError('Configured DPoP client profile required')
        self.client_profile=deepcopy(client_profile)
        self.tls=reviewed_tls_context('web-pki/1',ca_file=ca_file,ca_sha256=ca_sha256)
        self.file=canonical_path(Path(session_file));self.key_file=canonical_path(Path(session_key_file))
        if len(private_read(self.key_file,32))!=32:raise ValueError('Existing protected Host session key required')
        self.binding=dict(schema='poc-configured-host-sessions/1',namespace=self.namespace,tenant=tenant,
            hostOrigin=self.host_origin,coreOrigin=self.core_origin,embedRef=embed_ref,
            issuer=verifier.issuer,audience=verifier.audience,keyId=verifier.key_id,environment=verifier.environment)
        self.binding['publicKeySha256']=verifier.public_key_sha256
        self.binding['clientProfile']=deepcopy(client_profile)
        self.sessions={};self.lock=asyncio.Lock();self.bulkhead=asyncio.Semaphore(2)
        if self.file.exists() or self.file.is_symlink():
            saved=read_signed(self.file,self.key_file,maximum=131072)
            if type(saved) is not dict or set(saved)!={'binding','sessions'} or saved['binding']!=self.binding:
                raise ValueError('Host session identity changed; adoption refused')
            if type(saved['sessions']) is not dict or len(saved['sessions'])>128:raise ValueError('Bounded Host sessions required')
            for reference,value in saved['sessions'].items():
                if str(UUID(reference))!=reference:raise ValueError('Canonical Host session reference required')
                self._validate_session(value)
                if value['expiresAt']>time.time():self.sessions[reference]=value

    def subject(self,user):return dict(**self.namespace,tenantId=self.tenant,subjectId=user)

    def _control(self,subject):
        validate_contract('SubjectRef',subject)
        if (subject!=self.subject(subject['subjectId']) or subject['subjectId'] not in self.verifier.subjects):
            raise OSErrorCode('DENIED')
        value=deepcopy(self.control(subject))
        if (value.get('active') is not True or any(type(value.get(k)) is not int or not 1<=value[k]<=2**53-1
                for k in ('sessionGeneration','policyGeneration'))):raise OSErrorCode('DENIED')
        return value

    def _validate_session(self,value):
        if (type(value) is not dict or set(value)!={'subject','generation','issuedAt','expiresAt'}
                or type(value['issuedAt']) is not int or type(value['expiresAt']) is not int
                or not 0<value['expiresAt']-value['issuedAt']<=900
                or type(value['generation']) is not int or value['generation']<1):raise ValueError('Invalid Host session')
        validate_contract('SubjectRef',value['subject'])
        if (value['subject']!=self.subject(value['subject']['subjectId'])
                or value['subject']['subjectId'] not in self.verifier.subjects):raise ValueError('Foreign Host session')

    async def _remember(self,subject,control,expiry):
        async with self.lock:
            now=int(time.time());values={k:v for k,v in self.sessions.items() if v['expiresAt']>now}
            if len(values)>=128:raise OSErrorCode('CAPACITY')
            reference=str(uuid4());value=dict(subject=deepcopy(subject),generation=control['sessionGeneration'],
                issuedAt=now,expiresAt=expiry)
            self._validate_session(value);values[reference]=value
            write_signed(self.file,dict(binding=self.binding,sessions=values),self.key_file)
            self.sessions=values;return reference

    async def session(self,subject,reference,generation):
        validate_contract('SubjectRef',subject)
        control=self._control(subject);value=self.sessions.get(reference);now=utcnow()
        active=bool(value and value['subject']==subject and value['expiresAt']>now.timestamp()
            and value['generation']==generation==control['sessionGeneration'])
        if active:
            account=await self.accounts.observe(subject)
            active=account['active'] and self._control(subject)==control and value['expiresAt']>time.time()
            until=min(timestamp(account['validUntil']),now+timedelta(seconds=15),
                datetime.fromtimestamp(value['expiresAt'],timezone.utc))
        else:until=utcnow()+timedelta(seconds=1)
        return dict(subject=subject,active=active,sessionGeneration=control['sessionGeneration'],
            policyGeneration=control['policyGeneration'],checkedAt=iso(now),validUntil=iso(until))

    async def bootstrap(self,token,body):
        identity=self.verifier.verify(token);subject=self.subject(identity.subject_id);control=self._control(subject)
        binding=dict(subject=subject,**body,sessionGeneration=control['sessionGeneration'],
            audience='agentic-os.browser',replayId=str(uuid4()))
        if set(body)!={'challengeId','embedRef','frameNonce','proofKeyThumbprint','expiresAt'} or body['embedRef']!=self.embed_ref:
            raise OSErrorCode('INVALID')
        validate_contract('BridgeBootstrap',dict(binding=binding,hostSessionRef=str(uuid4())))
        if not utcnow()<timestamp(body['expiresAt'])<=utcnow()+timedelta(seconds=30):raise OSErrorCode('DENIED')
        async with asyncio.timeout(8),self.bulkhead:
            account=await self.accounts.observe(subject)
            if not account['active'] or self._control(subject)!=control:raise OSErrorCode('DENIED')
            reference=await self._remember(subject,control,identity.expires_at)
            async with httpx.AsyncClient(verify=self.tls,trust_env=False,follow_redirects=False,timeout=5) as client:
                async with client.stream('POST',self.core_origin+'/os/embed/bootstrap',
                        json=dict(binding=binding,hostSessionRef=reference),headers={
                            'Authorization':'Bearer '+self.bridge_key,'Accept-Encoding':'identity'}) as response:
                    if (response.status_code!=200 or response.headers.get('content-encoding','identity')!='identity'
                            or not response.headers.get('content-type','').startswith('application/json')):
                        raise OSErrorCode('UNAUTHENTICATED' if response.status_code in {401,403} else 'UNAVAILABLE')
                    raw=bytearray()
                    async for chunk in response.aiter_bytes():
                        raw.extend(chunk)
                        if len(raw)>4096:raise OSErrorCode('UNAVAILABLE')
            result=parse_canonical_json(bytes(raw));validate_contract('BootstrapAccepted',result)
            if (self._control(subject)!=control or identity.expires_at<=time.time()
                    or result['challengeId']!=body['challengeId']
                    or result['profile']!=self.client_profile
                    or timestamp(result['expiresAt'])>timestamp(body['expiresAt'])):raise OSErrorCode('DENIED')
            return result

    def app(self):
        app=FastAPI(docs_url=None,redoc_url=None,openapi_url=None)
        @app.post('/native/bootstrap')
        async def bootstrap(request:Request):
            try:
                if (LOCAL_IDENTITY_HEADERS.intersection(request.headers) or 'cookie' in request.headers
                        or request.headers.get('origin') not in (None,self.host_origin)):
                    raise OSErrorCode('DENIED')
                auth=request.headers.get('authorization','')
                if not auth.startswith('Bearer ') or len(auth)>16400:raise OSErrorCode('UNAUTHENTICATED')
                raw=bytearray()
                async for chunk in request.stream():
                    raw.extend(chunk)
                    if len(raw)>8192:raise OSErrorCode('CAPACITY')
                result=await self.bootstrap(auth[7:],parse_canonical_json(bytes(raw)))
                return JSONResponse(result)
            except OSErrorCode as error:return JSONResponse(dict(code=error.code),status_code=error.STATUS[error.code])
            except (ValueError,KeyError,TypeError):return JSONResponse(dict(code='INVALID'),status_code=400)
            except (httpx.HTTPError,TimeoutError):return JSONResponse(dict(code='UNAVAILABLE'),status_code=503)
        return app
