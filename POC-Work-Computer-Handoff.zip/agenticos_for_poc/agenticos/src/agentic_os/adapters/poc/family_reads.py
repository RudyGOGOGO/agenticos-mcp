"""Application-owned derived labels and table presentation over real VF reads."""
from copy import deepcopy
from math import atan2,cos,radians,sin,sqrt

from agentic_os.contracts.canonical import parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import timestamp
from agentic_os.interaction.catalog import compile_answer,validate_messages
from agentic_os.production.lookup_reads import LookupReadGoals
from agentic_os.production.table_reads import VerifiedTableLookupReads

LAST='vf.GetLastKnownLocation';LIST='vf.ListSavedLocations';DETAIL='vf.GetSavedLocationWithGeofences'
HISTORY='vf.GetLocationHistory'
RULE_FIELDS=('name','address','memberDisplayName','radiusMeters','notificationType','enabled','updatedAt','ruleStatus')


def rows(page):return [dict((field['name'],field['value']) for field in row) for row in page['records']]


def label_sources(material):
    lists=[source for source in material if source['binding']['capability']['ref']==LIST]
    details={}
    for source in sorted(material,key=lambda value:value['page']['evidence']['observedAt']):
        if source['binding']['capability']['ref']!=DETAIL:continue
        locations={row['savedLocationId'] for row in rows(source['page'])}
        if len(locations)!=1:raise OSErrorCode('DENIED')
        details[next(iter(locations))]=source
    if not lists:raise OSErrorCode('DENIED')
    saved={row['id'] for source in lists for row in rows(source['page'])}
    seen=set(details)
    if saved!=seen:raise OSErrorCode('DENIED')
    return list(details.values())


class FamilyReadGoals(LookupReadGoals):
    def retained_profile(self,context):
        # Qualified observation of this immutable table harness only. The
        # short capture still gates execution; retained metered inputs gate
        # later owner reads, with all current registration/source fences.
        pin=context['harness']
        return (pin==dict(ref=self.harness_ref,revision=2,
            digest='2b7c33c37c2834d47e2789e69ac0c8d20a6d275f56cb44e200e5db0603a9d95f')
            or pin in getattr(self,'retained_harness_pins',()))

    async def _validated_planner(self,actor,context,reference,*,retained=False):
        # read() already validates the entire causal graph, including fresh
        # Host checks and the post-Host SQL/artifact fence. Keep its material
        # for the immediately following planner checks rather than performing
        # that complete graph traversal a second time in this invocation.
        self._profile(context)
        accepted,graph=await self.observations.read(actor,context,reference,include_sources=True)
        text=await self._planner_graph(actor,context,accepted,graph,retained=retained)
        return accepted,text if retained else None

    async def _retained_planner_source(self,actor,context,accepted):
        self._profile(context)
        _,graph=await self.observations.read(actor,context,accepted['result'],include_sources=True)
        return await self._planner_graph(actor,context,accepted,graph,retained=True)

    async def _planner_graph(self,actor,context,accepted,graph,*,retained):
        import asyncio
        from agentic_os.production.goals import ReadGoals,response_document
        from agentic_os.production.lookup_scope import require_observed_resources
        self._profile(context)
        initial=[value for ref,value in graph if ref['payload']['schemaRef']=='AgentProviderResponse'
            and value['identity']['parentOperationId'] is None]
        if len(initial)!=1:raise OSErrorCode('DENIED')
        await asyncio.to_thread(self._discovery_sources,actor,context,accepted,graph)
        text=await asyncio.to_thread(ReadGoals._planner_source,self,actor,context,initial[0],retained=retained)
        await asyncio.to_thread(self._planner_prefix,actor,context,accepted,
            retained_text=text if retained else None,retained_prefix=initial[0] if retained else None)
        require_observed_resources(response_document(accepted['payloadJson']),graph,self.discovery)
        self._family_goal(accepted,graph)
        return text

    async def _validate_planner_source(self,actor,context,accepted):
        _,graph=await self.observations.read(actor,context,accepted['result'],include_sources=True)
        await self._planner_graph(actor,context,accepted,graph,retained=False)

    def _family_goal(self,accepted,graph):
        from agentic_os.production.goals import response_document
        draft=response_document(accepted['payloadJson'])
        for criterion in draft['criteria']:
            if criterion['capability']['ref']==DETAIL and not set(RULE_FIELDS)<=set(criterion['fields']):
                raise OSErrorCode('DENIED')
        if any(item['capability']['ref'] in {LAST,HISTORY} for item in draft['criteria']):
            material=[dict(binding=source['binding'],page=parse_canonical_json(source['payloadJson'].encode()))
                for ref,source in graph if ref['payload']['schemaRef']=='EvidencePage']
            label_sources(material)


def distance_meters(lat1,lon1,lat2,lon2):
    lat1,lon1,lat2,lon2=map(radians,map(float,(lat1,lon1,lat2,lon2)))
    a=sin((lat2-lat1)/2)**2+cos(lat1)*cos(lat2)*sin((lon2-lon1)/2)**2
    a=min(1,max(0,a));return 6371008.8*2*atan2(sqrt(a),sqrt(1-a))


def append_labels(answer,material):
    selected={item['id'] for item in answer['evidence']}
    last=[source for source in material if source['binding']['capability']['ref'] in {LAST,HISTORY}
        and source['page']['evidence']['id'] in selected]
    if not last:return answer
    details=label_sources(material);answer=deepcopy(answer)
    for source in last:
        for point in rows(source['page']):
            if point['recordedAt'] is None:continue
            matched=[]
            for detail in details:
                for rule in rows(detail['page']):
                    if (rule['memberId']==point['memberId'] and rule['enabled'] is True
                            and distance_meters(point['latitude'],point['longitude'],rule['latitude'],rule['longitude'])<=rule['radiusMeters']):
                        matched.append(rule['name'])
            label='Near '+', '.join(sorted(set(matched))) if matched else 'Unknown'
            age=max(0,int((timestamp(source['page']['evidence']['observedAt'])-timestamp(point['recordedAt'])).total_seconds()))
            text='Approximate label: '+label+'. Recorded '+point['recordedAt']+'; '+str(age)+' seconds old at observation. Synthetic recorded data; no live GPS or safety claim.'
            if len(text)>256:raise OSErrorCode('CAPACITY')
            answer['blocks'].append(dict(kind='narrative',text=text))
    existing={item['id'] for item in answer['evidence']}
    for source in details:
        if source['page']['evidence']['id'] not in existing:
            answer['evidence'].append(deepcopy(source['page']['evidence']));existing.add(source['page']['evidence']['id'])
    validate_contract('GroundedAnswer',answer);return answer


class VerifiedFamilyReads(VerifiedTableLookupReads):
    def __init__(self,observations,capabilities):
        super().__init__(observations,capabilities)
        self.goals=FamilyReadGoals(observations,capabilities)
        observations.tools.before_execute=self.goals.authorize_tool

    async def assess(self,actor,context,candidate):
        result,material=await super().assess(actor,context,candidate)
        if result['kind']=='verified' and any(item['binding']['capability']['ref'] in {LAST,HISTORY} for item in material):
            _,graph=await self.observations.read(actor,context,candidate,include_sources=True)
            material=[dict(result=ref,binding=source['binding'],page=parse_canonical_json(source['payloadJson'].encode()))
                for ref,source in graph if ref['payload']['schemaRef']=='EvidencePage']
            result['answer']=append_labels(result['answer'],material)
        return result,material

    @staticmethod
    def surface_messages(surface_id,answer,handles,publication,*,supported=False,preserve_extra_fields=False):
        if supported:raise OSErrorCode('PROFILE_DISABLED')
        messages=compile_answer(surface_id,answer,handles)
        components=messages[1]['updateComponents']['components'];rule_tables=[]
        for component in components:
            if component['component']=='Table' and set(RULE_FIELDS)<=set(component['columns']):
                rule_tables.append(component)
        if rule_tables:
            extras=list(dict.fromkeys(column for table in rule_tables for column in table['columns']
                if column not in RULE_FIELDS)) if preserve_extra_fields else []
            merged=[]
            for table in rule_tables:
                for row in table['rows']:
                    value=dict(zip(table['columns'],row,strict=True));empty=value['ruleStatus']=='No boundary alerts'
                    merged.append([value['name']+' — No boundary alerts' if empty else value['name'],value['address'],'' if empty else value['memberDisplayName'],
                        '' if empty else value['radiusMeters']+' meters',
                        '' if empty else {'ENTER_ONLY':'When they arrive','LEAVE_ONLY':'When they leave','BOTH':'Arrive and leave'}[value['notificationType']],
                        '' if empty else {'True':'On','False':'Off'}[value['enabled']],value['updatedAt'],
                        *[value.get(column,'') for column in extras]])
            first=rule_tables[0];first['columns']=['Saved location','Address','Member','Radius','Notify','Enabled','Updated']+[
                {'latitude':'Latitude','longitude':'Longitude'}.get(column,column) for column in extras];first['rows']=merged
            removed={item['id'] for item in rule_tables[1:]}
            messages[1]['updateComponents']['components']=[item for item in components if item['id'] not in removed]
            root=next(item for item in messages[1]['updateComponents']['components'] if item['id']=='root')
            root['children']=[item for item in root['children'] if item not in removed]
        validate_messages(surface_id,messages);return messages


class UnitLabelledFamilyReads(VerifiedFamilyReads):
    """One fixed display mapping bound to a complete immutable definition pin."""
    def __init__(self,observations,capabilities,definition):
        super().__init__(observations,capabilities)
        self.display_definition=deepcopy(definition)

    def surface_messages(self,surface_id,answer,handles,publication,*,supported=False):
        selected=publication.get('context',{}).get('definition')==self.display_definition
        messages=super().surface_messages(surface_id,answer,handles,publication,supported=supported,
            preserve_extra_fields=selected and getattr(self,'preserve_extra_fields',False))
        if publication.get('context',{}).get('definition')==self.display_definition:
            for component in messages[1]['updateComponents']['components']:
                if (component['component']=='Table' and component['columns'][:7]==
                        ['Saved location','Address','Member','Radius','Notify','Enabled','Updated']):
                    component['columns'][3]='Radius (meters)'
        validate_messages(surface_id,messages);return messages


class ContextualFamilyReadGoals(FamilyReadGoals):
    """A separate immutable profile; historical read profiles stay exact."""
    owner_read_context=True
    context_schema='agent-owner-read-turn-context/1'
    harness_prefix='agent-sdk-owner-input/1'

    def _harness_ref(self):return self.harness_prefix

    def _contextual_source(self,db,actor,context,admission,items,text,*,retained):
        from agentic_os.production.owner_read_context import collect,prefix
        self._profile(context)
        if type(items) is not list or len(items)!=2:raise OSErrorCode('DENIED')
        expected=None if retained else collect(db,actor,context,admission,self.artifacts,owner_inputs=self.inputs,schema=self.context_schema)
        original=prefix(items,context,expected=expected,schema=self.context_schema)
        if not retained and original!=text:raise OSErrorCode('DENIED')
        return original

    def _contextual_prefix(self,db,actor,context,admission,items,text,*,retained,retained_prefix,accepted):
        from agentic_os.production.owner_read_context import collect,prefix
        from agentic_os.production.provider_json import provider_json
        self._profile(context)
        expected=None
        if retained:
            if retained_prefix is None:raise OSErrorCode('DENIED')
            reference=retained_prefix['inputReference'];self.models._input(db,context,reference)
            raw=self.artifacts.read(actor.subject,reference['artifactRef'][9:],purpose='artifact')
            if len(raw)!=reference['bytes']:raise OSErrorCode('DENIED')
            original_items=provider_json(raw).get('input')
            if type(original_items) is not list or len(original_items)!=2:raise OSErrorCode('DENIED')
            prefix(original_items,context,schema=self.context_schema)
            expected=parse_canonical_json(original_items[1]['content'].encode())
        else:expected=collect(db,actor,context,admission,self.artifacts,owner_inputs=self.inputs,schema=self.context_schema)
        if prefix(items,context,expected=expected,schema=self.context_schema)!=text:raise OSErrorCode('DENIED')
        users=[]
        for item in items[2:]:
            if type(item) is not dict or item.get('role') in {'system','developer'}:raise OSErrorCode('DENIED')
            if item.get('role')=='user':users.append(item)
        if not users:return
        from agentic_os.production.owner_input import reply_input
        reply=self.inputs.accepted_reply_tx(db,actor,context)
        expected_reply=reply_input(text,parse_canonical_json(reply['payloadJson'])['text'])[1]
        if (users!=[expected_reply] or reply['result'] not in accepted['inputResults']):
            raise OSErrorCode('DENIED')

    def _source(self,actor,context,*,executing):
        from agentic_os.contracts.canonical import digest
        original=super()._source(actor,context,executing=executing)
        try:reply=self.inputs.accepted_reply(actor,context)
        except OSErrorCode as error:
            if error.code!='NOT_FOUND':raise
            return original
        return digest('command',dict(original=original,ownerReply=reply['result']))

    def _profile(self,context):
        super()._profile(context)
        if context['harness']!=self.context_harness or context['definition']!=self.context_definition:
            raise OSErrorCode('PROFILE_DISABLED')


class ContextualFamilyReads(UnitLabelledFamilyReads):
    journey_schema='agent-contextual-lookup-read-journey/1'
    preserve_extra_fields=True

    def __init__(self,observations,capabilities,definition,harness,*,with_coverage=False):
        if type(with_coverage) is not bool:raise ValueError('Explicit context coverage version required')
        super().__init__(observations,capabilities,definition)
        self.goals=ContextualFamilyReadGoals(observations,capabilities)
        if with_coverage:
            self.journey_schema='agent-contextual-lookup-read-journey/2'
            self.goals.context_schema='agent-owner-read-coverage-context/1'
        self.goals.context_harness=deepcopy(harness)
        self.goals.context_definition=deepcopy(definition)
        self.goals.retained_harness_pins=(deepcopy(harness),)
        from .family_read_questions import ContextualReadOwnerInput
        self.owner_inputs=ContextualReadOwnerInput(self,capabilities)
        self.goals.inputs=self.owner_inputs
        observations.tools.before_execute=self.goals.authorize_tool
