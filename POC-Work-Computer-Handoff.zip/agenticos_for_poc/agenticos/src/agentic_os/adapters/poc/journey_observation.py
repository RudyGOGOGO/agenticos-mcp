"""Bounded, opt-in numeric journey diagnostics; never task or effect authority."""
import asyncio
from collections import deque
from contextlib import asynccontextmanager
from queue import Queue,Empty,Full
from copy import deepcopy
import math
import json
from pathlib import Path
import threading
import time
from uuid import UUID

from fastapi import Request
from sqlalchemy import select

from agentic_os.adapters.local.files import private_write
from agentic_os.adapters.postgres.models import Task
from agentic_os.admission.service import guarded_owner
from agentic_os.errors import OSErrorCode
from agentic_os.identity.service import scoped


MARKS={'submit','admission','first-meaningful','proposal-ready','editable-form','tool-result','verified-completion','failed','stopped'}
ROUTES={'events','review','memory','schedules','task','identity','control'}


def number(value,maximum):
    return type(value) in (int,float) and math.isfinite(value) and 0<=value<=maximum


def client_report(value):
    if (type(value) is not dict or set(value)!={'journeyId','taskId','clock','timeOriginMs','marks','requests'}
            or value['clock']!='webview-performance/1' or not number(value['timeOriginMs'],10**14)):
        raise OSErrorCode('INVALID')
    for key in ('journeyId','taskId'):
        try:
            if type(value[key]) is not str or str(UUID(value[key]))!=value[key]:raise ValueError()
        except (ValueError,AttributeError):raise OSErrorCode('INVALID') from None
    if type(value['marks']) is not list or not 1<=len(value['marks'])<=len(MARKS):raise OSErrorCode('INVALID')
    seen=set();previous=0
    for mark in value['marks']:
        if (type(mark) is not dict or set(mark)!={'kind','elapsedMs'} or type(mark['kind']) is not str or mark['kind'] not in MARKS
                or mark['kind'] in seen or not number(mark['elapsedMs'],86400000) or mark['elapsedMs']<previous):
            raise OSErrorCode('INVALID')
        seen.add(mark['kind']);previous=mark['elapsedMs']
    if value['marks'][0]!={'kind':'submit','elapsedMs':0}:raise OSErrorCode('INVALID')
    if type(value['requests']) is not list or len(value['requests'])>128:raise OSErrorCode('INVALID')
    for span in value['requests']:
        if (type(span) is not dict or set(span)!={'kind','method','status','elapsedMs','coreHeadersMs','resumed','offsetMs'}
                or type(span['kind']) is not str or span['kind'] not in ROUTES
                or type(span['method']) is not str or span['method'] not in {'GET','POST'}
                or type(span['status']) is not int or not 0<=span['status']<=599 or type(span['resumed']) is not bool
                or not number(span['elapsedMs'],86400000) or not number(span['offsetMs'],86400000)
                or span['coreHeadersMs'] is not None and not number(span['coreHeadersMs'],86400000)):
            raise OSErrorCode('INVALID')
    return deepcopy(value)


def parse_client_report(raw):
    # This diagnostic transport permits finite fractional measurements. Keep
    # duplicate-key and malformed/nonfinite refusal without the authority JSON
    # parser's intentional integer-only restriction.
    def unique(pairs):
        value={}
        for key,item in pairs:
            if key in value:raise ValueError('Duplicate numeric report key')
            value[key]=item
        return value
    try:value=json.loads(raw.decode('utf-8'),object_pairs_hook=unique)
    except (ValueError,UnicodeDecodeError,RecursionError):raise OSErrorCode('INVALID') from None
    return client_report(value)


class JourneyObservations:
    def __init__(self,path,*,queue_capacity=256):
        self.path=Path(path)
        if not self.path.is_absolute() or self.path.resolve()!=self.path or self.path.exists():raise ValueError('New private observation path required')
        if type(queue_capacity) is not int or not 1<=queue_capacity<=1024:raise ValueError('Bounded diagnostic queue required')
        self.lock=threading.Lock();self.flush_lock=threading.Lock()
        self.clients=deque(maxlen=128);self.server=deque(maxlen=256)
        self.pending=Queue(maxsize=queue_capacity);self.stopped=threading.Event();self.writer=None
        self.dropped=0;self.evicted=0;self.flush_failures=0;self.enqueue_calls=0;self.enqueue_ns=0
        self.save()

    def save(self):
        with self.lock:
            statistics=dict(droppedSamples=self.dropped,retainedWindowEvictions=self.evicted,flushFailures=self.flush_failures,
                enqueueCalls=self.enqueue_calls,enqueueNanoseconds=self.enqueue_ns)
        raw=json.dumps(dict(schema='poc-journey-observations/1',authority=False,
            clockNote='Client and server monotonic durations are independent; do not subtract their epochs.',
            client=list(self.clients),server=list(self.server),diagnostics=statistics),
            allow_nan=False,separators=(',',':'),sort_keys=True).encode('utf-8')
        if len(raw)>4*1048576:raise ValueError('Bounded diagnostics exceeded')
        private_write(self.path,raw,replace=self.path.exists())

    def record(self,kind,value):
        # No SQL, file write or worker wait on a product response path.
        if kind not in {'client','server'}:raise ValueError('Numeric diagnostic kind required')
        began=time.perf_counter_ns();accepted=True
        try:self.pending.put_nowait((kind,deepcopy(value)))
        except Full:
            accepted=False
            with self.lock:self.dropped+=1
        finally:
            with self.lock:
                self.enqueue_calls+=1;self.enqueue_ns+=time.perf_counter_ns()-began
        return accepted

    def flush(self):
        # Exactly one writer owns the retained bounded snapshot. Its slow IO
        # cannot hold the enqueue/statistics lock or delay an HTTP response.
        with self.flush_lock:
            count=0
            while True:
                try:kind,value=self.pending.get_nowait()
                except Empty:break
                target=self.clients if kind=='client' else self.server
                if len(target)==target.maxlen:
                    with self.lock:self.evicted+=1
                target.append(value);count+=1
            if not count:return
            try:self.save()
            except Exception:
                with self.lock:self.flush_failures+=1

    def start(self):
        if self.writer is not None:return
        def run():
            while not self.stopped.wait(.2):self.flush()
            self.flush()
        self.writer=threading.Thread(target=run,name='poc-numeric-diagnostics',daemon=True);self.writer.start()

    def close(self):
        self.stopped.set()
        if self.writer is not None:self.writer.join(timeout=1)
        else:self.flush()
        return self.writer is None or not self.writer.is_alive()


def attach(app,runtime,observations):
    previous_lifespan=app.router.lifespan_context
    @asynccontextmanager
    async def lifespan(application):
        observations.start()
        try:
            async with previous_lifespan(application) as state:yield state
        finally:observations.close()
    app.router.lifespan_context=lifespan
    @app.middleware('http')
    async def timing(request,call_next):
        started=time.monotonic();response=await call_next(request);duration=(time.monotonic()-started)*1000
        if request.url.path.startswith('/os/') and request.url.path!='/os/ui/journey-timings':
            response.headers['Server-Timing']='core;dur='+format(duration,'.3f')
            if request.url.path=='/os/ui/features':response.headers['X-AgenticOS-Journey-Timing']='1'
            # Only route templates and numeric metadata, never raw URL/query/body.
            route=getattr(request.scope.get('route'),'path',None)
            if route:
                try:observations.record('server',dict(route=route,method=request.method,
                    status=response.status_code,headersMs=duration,serverMonotonic=started))
                except Exception:pass  # Diagnostics never changes a product result.
            response.headers['Server-Timing']='core;dur='+format((time.monotonic()-started)*1000,'.3f')
        return response

    @app.post('/os/ui/journey-timings')
    async def capture(request:Request):
        if request.query_params:raise OSErrorCode('INVALID')
        actor=await runtime.authenticate_request(request)
        raw=await request.body()
        if len(raw)>32768:raise OSErrorCode('CAPACITY')
        value=parse_client_report(raw)
        def owned():
            with runtime.store.transaction() as db:
                guarded_owner(db,actor,read_only=True)
                return db.scalar(select(Task.id).where(*scoped(Task,actor.subject),Task.id==UUID(value['taskId']))) is not None
        if not await asyncio.to_thread(owned):return dict(accepted=False)
        try:return dict(accepted=observations.record('client',value))
        except Exception:return dict(accepted=False)
