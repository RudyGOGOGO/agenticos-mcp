"""Protected per-child credentials; no ambient paid provider or product secret."""
import json
from pathlib import Path
import time
from uuid import uuid4

from cryptography.hazmat.primitives import serialization
import jwt

from agentic_os.adapters.local.files import private_directory,private_read,private_write
from agentic_os.identity.context import timestamp
from .workload_identity import DirectWorkloadIdentity,LOCAL_IDENTITY


class ChildCredentials:
    def __init__(self, *, root, signing_key_file, ca_file, private_origin, meter, inference, privacy=None,
            reserve_root=None,identity=None):
        self.identity=LOCAL_IDENTITY if identity is None else identity
        if type(self.identity) is not DirectWorkloadIdentity:raise ValueError('Reviewed fixed worker identity required')
        self.root=Path(root)
        if not self.root.exists():private_directory(self.root)
        self.key=serialization.load_pem_private_key(private_read(Path(signing_key_file)),password=None)
        self.ca_file,self.private_origin=str(ca_file),private_origin
        self.meter,self.inference=meter,inference
        self.privacy,self.reserve_root=privacy,reserve_root
        if inference.get('mode')=='live-openai' and (privacy is None or not callable(reserve_root)):
            raise ValueError('Live qualification requires explicit privacy and original Root allowance reservation')

    async def __call__(self,payload,execution_id,epoch):
        context=payload['start']['context'];now=int(time.time())
        if self.inference.get('mode')=='live-openai':
            # The qualification operator owns the single cumulative ledger.
            # Reservation/binding must succeed before exposing any provider
            # credential to the installed isolated SDK child.
            await self.reserve_root(context,self.meter)
        expiry=min(int(timestamp(context['authorizationHorizon']).timestamp()),now+300)
        identity=self.identity
        token=jwt.encode(dict(iss=identity.issuer,aud=identity.audience,sub=identity.subject,jti=str(uuid4()),
            iat=now,exp=expiry,profile='agent-direct-workload/1',taskId=context['taskId'],executionId=execution_id,
            epoch=epoch),self.key,algorithm='EdDSA',headers={'kid':identity.key_id})
        token_file=self.root/(epoch+'.jwt')
        private_write(token_file,token.encode('ascii'))
        meter=self.meter;model=meter['model']
        transport=dict(provider=model['provider'],model_id=model['modelId'],model_profile_digest=context['model']['digest'],
            model_profile_json=json.dumps(model,sort_keys=True,separators=(',',':')),endpoint_ref=model['endpointRef'],
            credential_ref=model['credentialRef'],base_url='https://api.openai.com/v1',
            request_timeout_ms=meter['requestTimeoutMs'],max_request_bytes=meter['maxRequestBytes'],
            max_response_bytes=meter['maxResponseBytes'])
        if self.privacy is not None:
            transport['privacy_configuration_json']=json.dumps(self.privacy,sort_keys=True,separators=(',',':'))
        return dict(schema='agent-direct-child/2',origin=self.private_origin,token_file=str(token_file),ca_file=self.ca_file,
            start=payload,execution_id=execution_id,transport=transport,inference=self.inference)
