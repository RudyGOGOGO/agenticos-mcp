"""Explicit canonical owner-memory reply profile beside the VF profiles.

Uses the maintained production memory context, recall lane, response verifier
and installed SDK. Memory is never a grant to a member, place or product tool.
"""
from copy import deepcopy
import json

from agentic_os.contracts.canonical import digest
from agentic_os.production.capability_catalog import CapabilityRegistrations,validate_registration
from agentic_os.production.memory_tasks import memory_response_harness_ref
from agentic_os.production.profiles import version_pin,validate_profile
from .configuration import schema_json


def registration():
    inputs=dict(type='object',additionalProperties=False,required=['query','contextRef','mode'],properties=dict(
        query=dict(type='string',minLength=1,maxLength=1000),contextRef=dict(type='string',minLength=9,maxLength=46),
        mode=dict(type='string',enum=['lexical'],maxLength=7)))
    value=dict(id='owner.memory.recall',revision=1,kind='memory',purpose='assistant.manage',
        title='Recall my approved saved memory',description='Keyword search of current approved memories in the selected owner context. '
            'Matches are ranked and non-exhaustive. Use source words from the request. Memory grants no family-product access.',
        adapterRef='owner.memory.read/1',scopePolicyRef='owner-approved-memory/1',
        inputSchemaJson=json.dumps(inputs,sort_keys=True,separators=(',',':')),
        outputSchemaJson=schema_json('AgentMemoryPage'),mcp=None,lifecycle='qualified')
    validate_registration(value);return value


def profile(base,capability):
    value=deepcopy(base);value['definition']['id']='poc-family-memory/1'
    value['capabilities'].update(id='poc-owner-memory-capabilities/1',capabilityPrefixes=['owner.memory.'],allowedKinds=['memory'])
    value['definition']['capabilityPolicy']=version_pin(value['capabilities'],'policy')
    previous=value['harness']['harness']
    value['harness']['harness']=dict(ref=memory_response_harness_ref([capability]),revision=1,
        digest=digest('manifest',dict(profile='poc-owner-memory-response/1',capability=capability,base=previous)))
    value['definition']['harness']=deepcopy(value['harness']['harness'])
    validate_profile(value,qualified=True);return value


def prepare(runtime,service,base,operator,application_id,journal,*,configured=False):
    runtime.enable_agent_memory_context(service,journal)
    capability=CapabilityRegistrations(runtime.registry).register(application_id,registration(),operator)
    selected=profile(base,capability)
    pin=service.profiles.register(application_id,selected,operator)
    if configured:service.select_configured_profile(application_id,pin,operator)
    else:service.select_engineering_profile(application_id,pin,operator,local_synthetic=True)
    return dict(profile=selected,capability=capability,memory=runtime.task_memory)


def lane(runtime,requests,selected,operator,application_id,namespace):
    from agentic_os.production.memory_lane import MemoryReadLane,MemoryReadObserver
    from agentic_os.production.tool_policy import ToolPolicies
    from agentic_os.production.tool_journal import ToolJournal
    memory=dict(id='owner-approved-memory',revision=1,capability=selected['capability'],
        harness=selected['profile']['definition']['harness'],**namespace,providerRef='owner-memory/1',
        outputContract='AgentMemoryPage/1',adapterRef='owner.memory.read/1')
    policy=dict(memory=memory,execution=dict(id='owner-memory-execution',revision=1,memoryProfile=version_pin(memory),
        usageProfile='owner-memory-elapsed/1',externalInference=False,requestTimeoutMs=29000,maxResultBytes=65536))
    ToolPolicies(runtime.registry).register(application_id,policy,operator)
    source=MemoryReadLane(requests,selected['memory'],memory)
    return ToolJournal(source,policy),MemoryReadObserver(source),version_pin(policy['execution'])
