"""Trusted POC MCP descriptor/DTO wrapper, separate from the default adapter."""
import asyncio
from copy import deepcopy
import hashlib
import json
from uuid import uuid4

import httpx2
from jsonschema import Draft202012Validator
from jsonschema import ValidationError
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

from agentic_os.adapters.mcp.client import RegisteredTransport
from agentic_os.adapters.http.endpoint import reviewed_http_endpoint
from agentic_os.contracts.canonical import canonical_bytes,digest
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import iso,utcnow
from agentic_os.production.capability_schema import validate_payload
from agentic_os.production.read_lane import MCPReadLane


class POCToolError(OSErrorCode):
    """Validated external failure metadata, never effect completion authority."""
    def __init__(self,document,metadata):
        from uuid import UUID
        if (type(document) is not dict or set(document)!={'error'} or type(document['error']) is not dict
                or set(document['error'])!={'code','message','field','details'} or type(metadata) is not dict
                or set(metadata)!={'httpStatus','correlationId'} or type(metadata['httpStatus']) is not int
                or not 400<=metadata['httpStatus']<=599):
            raise OSErrorCode('UNAVAILABLE')
        UUID(metadata['correlationId']);error=document['error']
        if (error['code'] not in {'FORBIDDEN','NOT_FOUND','NO_LOCATION_YET','VALIDATION_ERROR','DUPLICATE_GEOFENCE',
                'IDEMPOTENCY_CONFLICT','STATE_CHANGED','PRECONDITION_REQUIRED','POC_CAPACITY_LIMIT','UNAUTHORIZED',
                'UNAVAILABLE','UNKNOWN','INVALID_BACKEND_RESPONSE','INVALID_ARGUMENT','UNKNOWN_TOOL'}
                or type(error['message']) is not str or len(error['message'])>512
                or error['field'] is not None and (type(error['field']) is not str or len(error['field'])>128)
                or type(error['details']) is not dict or set(error['details'])-{'existingGeofenceId'}
                or any(type(value) is not str or not 1<=len(value)<=128 for value in error['details'].values())):
            raise OSErrorCode('UNAVAILABLE')
        self.external,self.metadata=deepcopy(document),deepcopy(metadata)
        status=metadata['httpStatus']
        super().__init__({400:'INVALID',401:'UNAUTHENTICATED',403:'DENIED',404:'NOT_FOUND',409:'CONFLICT',
            412:'CONFLICT',428:'CONFLICT',429:'CAPACITY'}.get(status,'UNAVAILABLE'))


class POCSession(ClientSession):
    async def validate_tool_result(self,name,result):
        # Preserve SDK validation through its public validation seam, using
        # exact decimal multiples for the normative six-decimal DTO contract.
        # Binary float modulo incorrectly rejects valid coordinates at 1e-6.
        from .external_json import validate_external
        # The request already fetched this catalog on the same authenticated
        # session. Reuse only that invocation's immutable schema, not authority
        # or a catalog from another credential/session.
        catalog=getattr(self,'_poc_invocation_catalog',None)
        if catalog is None:catalog=await self.list_tools()
        if catalog.next_cursor is not None or len(catalog.tools)>9:raise OSErrorCode('CAPACITY')
        selected=[tool for tool in catalog.tools if tool.name==name]
        if len(selected)!=1 or selected[0].output_schema is None or result.structured_content is None:
            raise OSErrorCode('PROFILE_DISABLED')
        validate_external(selected[0].output_schema,result.structured_content)


def tool_descriptor(item):
    return dict(name=item.name,description=item.description,inputSchema=item.input_schema,
        outputSchema=item.output_schema,annotations=item.annotations.model_dump(by_alias=True,
            exclude_none=True) if item.annotations is not None else None)


class POCMCP:
    def __init__(self, endpoint, *, network='owned-local-http/1', timeout_ms=3000,ca_file=None,ca_sha256=None):
        self.endpoint=reviewed_http_endpoint(endpoint,network)
        self.network,self.timeout=network,timeout_ms/1000
        self.trust=dict(ca_file=ca_file,ca_sha256=ca_sha256)
        from agentic_os.adapters.http.tls import reviewed_tls_context
        reviewed_tls_context(network,**self.trust)

    async def request(self, token, *, tool=None, arguments=None,effect_context=None,expected_descriptor=None):
        try:
            remote_error=None;request_error=None
            headers={'Authorization':'Bearer '+token,'Accept-Encoding':'identity'}
            if effect_context is not None:
                if tool is None or type(effect_context) is not str or not 1<=len(effect_context)<=16384:
                    raise OSErrorCode('INVALID')
                headers['X-AgenticOS-Effect-Context']=effect_context
            async with asyncio.timeout(self.timeout):
                network=RegisteredTransport(self.endpoint,1048576,network=self.network,keepalive_connections=2,**self.trust)
                async with httpx2.AsyncClient(transport=network,trust_env=False,follow_redirects=False,
                        timeout=self.timeout,headers=headers) as http:
                    async with streamable_http_client(self.endpoint,http_client=http,terminate_on_close=True) as streams:
                        async with POCSession(*streams[:2],read_timeout_seconds=self.timeout) as session:
                            initialized=await session.initialize()
                            if initialized.protocol_version!='2025-11-25':raise OSErrorCode('PROFILE_DISABLED')
                            if tool is None:
                                result=await session.list_tools()
                                if result.next_cursor is not None or len(result.tools)>9:raise OSErrorCode('CAPACITY')
                                return [tool_descriptor(item) for item in result.tools]
                            catalog=await session.list_tools()
                            session._poc_invocation_catalog=deepcopy(catalog)
                            selected=[item for item in catalog.tools if item.name==tool]
                            if catalog.next_cursor is not None or len(catalog.tools)>9 or len(selected)!=1:
                                request_error='PROFILE_DISABLED'
                            elif expected_descriptor is not None and tool_descriptor(selected[0])!=expected_descriptor:
                                request_error='PROFILE_DISABLED'
                            else:
                                from .external_json import validate_external
                                try:validate_external(selected[0].input_schema,arguments)
                                except ValidationError:request_error='INVALID'
                            if request_error is None:
                                result=await session.call_tool(tool,arguments,read_timeout_seconds=self.timeout)
                                if result.is_error:
                                    # Leave SDK task groups before raising the
                                    # typed outcome, so ExceptionGroup cleanup
                                    # cannot erase a known external refusal.
                                    remote_error=(deepcopy(result.structured_content),deepcopy(result.meta))
                                else:
                                    if result.structured_content is None:raise OSErrorCode('UNAVAILABLE')
                                    return result.structured_content
            if request_error is not None:raise OSErrorCode(request_error)
            if remote_error is not None:raise POCToolError(*remote_error)
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None


class ReadMapping:
    """Operator-pinned mapping from a validated product DTO to OS evidence."""
    def __init__(self, descriptor, *, provider_ref, records_field, id_field, resource_type, fields,external_descriptor=False):
        if (type(descriptor) is not dict or descriptor['outputSchema'] is None or not fields
                or len(fields)>64 or len(set(fields))!=len(fields)
                or not descriptor.get('annotations',{}).get('readOnlyHint')):
            raise ValueError('Reviewed external descriptor and bounded evidence fields required')
        self.descriptor=deepcopy(descriptor)
        self.provider_ref,self.records_field,self.id_field=provider_ref,records_field,id_field
        self.resource_type,self.fields=resource_type,tuple(fields)
        self.validator=Draft202012Validator(descriptor['outputSchema'])
        if external_descriptor:
            from .external_json import external_sha256
            descriptor=dict(externalJCSDescriptorSHA256=external_sha256(descriptor))
        self.pin=digest('manifest',dict(descriptor=descriptor,providerRef=provider_ref,recordsField=records_field,
            idField=id_field,resourceType=resource_type,fields=list(fields)))

    def source(self, document):
        from .external_json import validate_external
        validate_external(self.descriptor['outputSchema'],document)
        rows=document[self.records_field] if self.records_field is not None else [document]
        if type(rows) is not list or len(rows)>64:raise OSErrorCode('CAPACITY')
        return rows

    @staticmethod
    def version(row):
        # This is a source-version fingerprint, not an OS command/proposal
        # digest. Numeric DTOs remain outside the Core canonical JSON subset.
        raw=json.dumps(row,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
        return hashlib.sha256(raw).hexdigest()

    def facts(self, document, subject):
        records=[];resources=[]
        for row in self.source(document):
            values=[]
            for name in self.fields:
                value=row[name]
                if type(value) is float:
                    # Exact decimal presentation at the POC API's six places;
                    # no rounded mutation argument or authority is created.
                    value=format(value,'.6f')
                if value is not None and type(value) not in {str,bool,int}:raise OSErrorCode('INVALID')
                values.append(dict(name=name,value=value))
            records.append(values)
            resources.append(dict(subject=deepcopy(subject),providerId=self.provider_ref,
                resourceType=self.resource_type,contractVersion=1,externalId=row[self.id_field],
                observedVersion=self.version(row)))
        return records,resources

    def page(self, document, subject):
        records,resources=self.facts(document,subject)
        evidence=dict(id=str(uuid4()),subject=deepcopy(subject),providerRef=self.provider_ref,
            resourceRefs=resources,observedAt=iso(utcnow()),classification='host-authorized',quality='synthetic',
            completeness=self.completeness(document),publicFields=list(self.fields),formatterRef='poc-tool-table',formatterVersion=1)
        evidence['coreDigest']=digest('evidence',dict(evidence=evidence,records=records))
        page=dict(evidence=evidence,records=records,nextCursor=None)
        validate_contract('EvidencePage',page)
        return page

    def completeness(self,document):return '1.00'

    def matches(self, document, subject, page):
        validate_contract('EvidencePage',page)
        records,resources=self.facts(document,subject)
        evidence=page['evidence']
        return (page['records']==records and page['nextCursor'] is None and evidence['subject']==subject
            and evidence['providerRef']==self.provider_ref and evidence['resourceRefs']==resources
            and evidence['publicFields']==list(self.fields) and evidence['quality']=='synthetic'
            and evidence['classification']=='host-authorized' and evidence['completeness']==self.completeness(document)
            and evidence['formatterRef']=='poc-tool-table' and evidence['formatterVersion']==1
            and evidence['coreDigest']==digest('evidence',dict(
                evidence={k:v for k,v in evidence.items() if k!='coreDigest'},records=records)))


class POCReadLane(MCPReadLane):
    adapter_ref='poc.mcp.read/1'

    def __init__(self, *args, mapping, mcp_trust=None, **kwargs):
        super().__init__(*args,**kwargs)
        self.mapping=mapping
        self.mcp_trust={} if mcp_trust is None else dict(mcp_trust)
        if set(self.mcp_trust) not in (set(),{'ca_file','ca_sha256'}):
            raise ValueError('Explicit MCP CA reference and pin required')

    async def observe(self, actor, binding, *, before_execute):
        registration=await self._binding(actor,binding)
        arguments=validate_payload(registration['inputSchemaJson'],binding['argumentsJson'])
        request,decision=await self._authorize(actor,binding,registration)
        credential=decision['credential']
        endpoint=registration['mcp']['connection']
        if (credential['subject']!=actor.subject or credential['capabilityRef']!=binding['capability']['ref']
                or credential['audienceRef']!=endpoint['audienceRef']):raise OSErrorCode('DENIED')
        client=POCMCP(endpoint['url'],network=endpoint['network'],timeout_ms=endpoint['requestTimeoutMs'],**self.mcp_trust)
        # Validate remote metadata on the actual call's session, after the
        # original fresh binding/Host checks. A separate authenticated catalog
        # session neither grants authority nor proves the later schema.
        await self._binding(actor,binding)
        latest_request,current=await self._authorize(actor,binding,registration)
        self._decision(actor,request,decision,dispatch=True)
        self._decision(actor,latest_request,current,dispatch=True)
        await self._binding(actor,binding)
        await before_execute()
        raw=await client.request(current['credential']['accessToken'],tool=self.mapping.descriptor['name'],arguments=arguments,
            expected_descriptor=self.mapping.descriptor)
        page=self.mapping.page(raw,binding['context']['subject'])
        return dict(kind='candidate',payloadJson=canonical_bytes(page).decode(),trust='untrusted-host-result')
