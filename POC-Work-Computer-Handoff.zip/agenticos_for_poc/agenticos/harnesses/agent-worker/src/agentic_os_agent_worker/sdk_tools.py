"""Public SDK FunctionTool callback into the private governed execution facade.

Only accepted output is returned as tool context. Unknown/pending work raises a
private controller condition, never an automatic retry or a fabricated result.
"""
from copy import deepcopy
import json

from agents.tool import FunctionTool
from agents.tool_context import ToolContext

from .checkpoint import tool_alias
from .sdk_model import SDKModelSequence,SDKModelPolicyError,SDKModelDeferred
from .transport import _json,_validate

PREPARATION_SYNTAX_CORRECTION='Regenerate the same intended call with each JSON property exactly once. Keep the supplied values; this syntax failure is not missing owner information. No tool executed.'


def local_preparation_argument_feedback(value):
    original=dict(kind='tool-error',failure='invalid-input',validation='local-schema')
    if value==original:return True
    if (type(value) is not dict or set(value)!=set(original)|{'validationError','correction'}
            or any(value[k]!=v for k,v in original.items())
            or value['correction']!=PREPARATION_SYNTAX_CORRECTION):return False
    detail=value['validationError']
    return (type(detail) is dict and set(detail)=={'code','property'} and detail['code']=='duplicate-property'
        and (detail['property'] is None or type(detail['property']) is str and len(detail['property'])<=120))


class SDKToolDeferred(RuntimeError):
    def __init__(self,preparation):
        self.preparation=deepcopy(preparation)
        super().__init__('governed_tool_'+preparation['kind'])


def deferred_tool_condition(error):
    """Recover a private condition through the SDK's standard error wrapper."""
    seen=set()
    while isinstance(error,BaseException) and id(error) not in seen:
        seen.add(id(error))
        if isinstance(error,(SDKToolDeferred,SDKModelDeferred)):return error
        error=error.__cause__
    return None


def governed_read_tool(item,boundary,sequence,*,result_context='evidence-page/1',argument_feedback=False):
    _validate('AgentCapabilityItem',item);item=deepcopy(item)
    preparation=result_context=='agent-prepared-change/1'
    memory=result_context=='agent-accepted-memory/1'
    knowledge=result_context=='agent-private-knowledge/1'
    wasm_creation=result_context=='agent-accepted-wasm-verification/1'
    proactive=result_context=='agent-accepted-proactivity/1'
    discovery=result_context=='agent-capability-discovery/1'
    if (item['kind']!=('native' if wasm_creation else 'schedule' if proactive else 'memory' if memory or knowledge else 'propose' if preparation else 'read') or not item['available'] or not isinstance(sequence,SDKModelSequence)
            or sequence.dependency_boundary is not boundary
            or not callable(getattr(boundary,'execute_tool',None))):raise SDKModelPolicyError()
    if result_context not in {'agent-accepted-wasm-verification/1','evidence-page/1','agent-accepted-read/1','agent-accepted-read-ref/1','agent-accepted-query/1','agent-accepted-query-ref/1','agent-prepared-change/1','agent-accepted-memory/1','agent-private-knowledge/1','agent-accepted-proactivity/1','agent-capability-discovery/1'}:raise SDKModelPolicyError()
    if type(argument_feedback) is not bool or argument_feedback and result_context not in {'agent-accepted-query/1','agent-accepted-query-ref/1','agent-prepared-change/1'}:raise SDKModelPolicyError()
    name=tool_alias(item['capability']);schema=_json(item['inputSchemaJson'])
    if type(schema) is not dict:raise SDKModelPolicyError()
    async def invoke(context,arguments):
        if (not isinstance(context,ToolContext) or context.tool_name!=name or context.tool_arguments!=arguments
                or context.tool_namespace is not None or sequence.pending is not None):raise SDKModelPolicyError()
        binding=sequence.snapshot()
        if binding['parentOperationId'] is None:raise SDKModelPolicyError()
        request=dict(context=binding['context'],modelOperationId=binding['parentOperationId'],capability=item['capability'],
            toolName=name,callId=context.tool_call_id,argumentsJson=arguments)
        _validate('AgentSDKToolRequest',request)
        if argument_feedback:
            from .memory_output import analysis_tool_arguments_valid
            if not analysis_tool_arguments_valid(schema,arguments):
                # No execution, accepted source or grant is fabricated. The
                # next SDK model turn is independently metered on this Root.
                feedback=dict(kind='tool-error',failure='invalid-input')
                if preparation:
                    feedback['validation']='local-schema'
                    from .transport import DuplicateJSONProperty
                    try:_json(arguments)
                    except DuplicateJSONProperty as error:
                        feedback['validationError']=dict(code='duplicate-property',
                            property=error.key if len(error.key)<=120 else None)
                        feedback['correction']=PREPARATION_SYNTAX_CORRECTION
                    except ValueError:pass
                return json.dumps(feedback,separators=(',',':'))
        result=await boundary.execute_tool(request);_validate('AgentToolPreparation',result)
        if result['kind']=='accepted':
            if discovery:
                accepted=result['accepted'];page=_json(accepted['payloadJson']);_validate('AgentCapabilityDiscoveryPage',page)
                if (accepted['result']['payload']['schemaRef']!='AgentCapabilityDiscoveryPage'
                        or page['context']!=binding['context']
                        or any(accepted['result'][key]!=binding['context'][key] for key in ('subject','rootId','taskId'))):
                    raise SDKModelPolicyError()
                compact=dict(schema=result_context,result=accepted['result'],page=page)
                _validate('AgentAcceptedCapabilityDiscoveryContext',compact)
                await sequence.add_tool_result(accepted['result'],context.agent)
                return json.dumps(compact,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            if wasm_creation:
                accepted=result['accepted'];value=_json(accepted['payloadJson']);_validate('AgentWasmVerificationCandidate',value)
                if (accepted['result']['payload']['schemaRef']!='AgentWasmVerificationCandidate'
                        or any(accepted['binding'][key]!=request[key] for key in
                            ('context','modelOperationId','capability','toolName','callId'))
                        or _json(accepted['binding']['argumentsJson'])!=_json(arguments)
                        or any(accepted['result'][key]!=binding['context'][key] for key in ('subject','rootId','taskId'))):
                    raise SDKModelPolicyError()
                compact=dict(schema=result_context,result=accepted['result'],name=value['original']['name'],
                    arity=value['compiled']['arity'],cases=value['cases'],activation='separate-owner-review-required')
                _validate('AgentAcceptedWasmCreationContext',compact)
                await sequence.add_tool_result(accepted['result'],context.agent)
                return json.dumps(compact,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            if proactive:
                accepted=result['accepted'];value=_json(accepted['payloadJson']);_validate('AgentProactivePreparation',value)
                if (accepted['result']['payload']['schemaRef']!='AgentProactivePreparation'
                        or any(accepted['result'][key]!=binding['context'][key] for key in ('subject','rootId','taskId'))
                        or value['receipt']['definition']['subject']!=binding['context']['subject']):raise SDKModelPolicyError()
                compact=dict(schema=result_context,result=accepted['result'],preparation=value)
                _validate('AgentAcceptedProactiveContext',compact)
                await sequence.add_tool_result(accepted['result'],context.agent)
                return json.dumps(compact,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            if memory:
                accepted=result['accepted'];value=_json(accepted['payloadJson']);_validate('AgentMemoryPage',value)
                if (accepted['result']['payload']['schemaRef']!='AgentMemoryPage'
                        or value['page']['evidence']['subject']!=binding['context']['subject']
                        or any(accepted['result'][key]!=binding['context'][key] for key in ('subject','rootId','taskId'))):
                    raise SDKModelPolicyError()
                compact=dict(schema=result_context,result=accepted['result'],memory=value)
                _validate('AgentAcceptedMemoryContext',compact)
                await sequence.add_tool_result(accepted['result'],context.agent)
                return json.dumps(compact,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            if preparation:
                if result['accepted']['result']['payload']['schemaRef']!='AgentPreparedChange':raise SDKModelPolicyError()
                _validate('AgentPreparedChange',_json(result['accepted']['payloadJson']))
                await sequence.add_tool_result(result['accepted']['result'],context.agent)
                return result['accepted']['payloadJson']
            if knowledge:
                accepted=result['accepted'];value=_json(accepted['payloadJson'])
                _validate('AgentPrivateKnowledgePage',value)
                if (accepted['result']['payload']['schemaRef']!='AgentPrivateKnowledgePage'
                        or any(accepted['result'][key]!=binding['context'][key] for key in ('subject','rootId','taskId'))
                        or value['binding']['value']['scope']!={key:binding['context']['subject'][key]
                            for key in ('installationId','applicationId','tenantId')}):raise SDKModelPolicyError()
                await sequence.add_tool_result(accepted['result'],context.agent)
                return accepted['payloadJson']
            query=result_context in {'agent-accepted-query/1','agent-accepted-query-ref/1'}
            if result['accepted']['result']['payload']['schemaRef']!=('AgentQueryPage' if query else 'EvidencePage'):raise SDKModelPolicyError()
            if result_context=='agent-accepted-read-ref/1':
                page=_json(result['accepted']['payloadJson']);_validate('EvidencePage',page)
                if (page['evidence']['subject']!=binding['context']['subject']
                        or any(resource['subject']!=binding['context']['subject']
                            or resource['providerId']!=page['evidence']['providerRef'] for resource in page['evidence']['resourceRefs'])
                        or any(result['accepted']['result'][key]!=binding['context'][key] for key in ('subject','rootId','taskId'))):
                    raise SDKModelPolicyError()
                compact=dict(schema=result_context,result=result['accepted']['result'],
                    resources=deepcopy(page['evidence']['resourceRefs']),fields=deepcopy(page['evidence']['publicFields']))
                _validate('AgentAcceptedReadReferenceContext',compact)
                await sequence.add_tool_result(result['accepted']['result'],context.agent)
                return json.dumps(compact,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            if result_context=='agent-accepted-query-ref/1':
                value=_json(result['accepted']['payloadJson']);_validate('AgentQueryPage',value)
                compact=dict(schema=result_context,result=result['accepted']['result'],
                    **{key:deepcopy(value[key]) for key in ('queryDigest','coverage','requestCursor','pageOrdinal','grain','pageGroupFields')},
                    nextCursor=value['page']['nextCursor'],fields=value['page']['evidence']['publicFields'])
                _validate('AgentAcceptedQueryReferenceContext',compact)
                await sequence.add_tool_result(result['accepted']['result'],context.agent)
                return json.dumps(compact,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            if result_context in {'agent-accepted-read/1','agent-accepted-query/1'}:
                value=dict(schema=result_context,result=result['accepted']['result'],
                    **{('query' if query else 'page'):_json(result['accepted']['payloadJson'])})
                _validate('AgentAcceptedQueryContext' if query else 'AgentAcceptedReadContext',value)
                await sequence.add_tool_result(result['accepted']['result'],context.agent)
                return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            _validate('EvidencePage',_json(result['accepted']['payloadJson']))
            await sequence.add_tool_result(result['accepted']['result'],context.agent)
            return result['accepted']['payloadJson']
        if result['kind']=='failed':
            return json.dumps(dict(kind='tool-error',failure=result['observation']['operation']['failure']),separators=(',',':'))
        raise SDKToolDeferred(result)
    return FunctionTool(name=name,description=item['description'],params_json_schema=schema,on_invoke_tool=invoke,
        strict_json_schema=False,needs_approval=False,timeout_behavior='raise_exception')


def governed_native_tool(item,boundary,sequence):
    _validate('AgentCapabilityItem',item);item=deepcopy(item)
    if (item['kind']!='native' or not item['available'] or not isinstance(sequence,SDKModelSequence)
            or sequence.dependency_boundary is not boundary or not callable(getattr(boundary,'execute_native',None))):
        raise SDKModelPolicyError()
    name=tool_alias(item['capability']);schema=_json(item['inputSchemaJson'])
    if type(schema) is not dict:raise SDKModelPolicyError()
    async def invoke(context,arguments):
        if (not isinstance(context,ToolContext) or context.tool_name!=name or context.tool_arguments!=arguments
                or context.tool_namespace is not None or sequence.pending is not None):raise SDKModelPolicyError()
        binding=sequence.snapshot()
        if binding['parentOperationId'] is None:raise SDKModelPolicyError()
        request=dict(context=binding['context'],modelOperationId=binding['parentOperationId'],capability=item['capability'],
            toolName=name,callId=context.tool_call_id,argumentsJson=arguments)
        _validate('AgentSDKToolRequest',request)
        result=await boundary.execute_native(request);_validate('AgentNativeAnalysisPreparation',result)
        if result['kind']=='accepted':
            accepted=result['accepted'];value=_json(accepted['payloadJson']);_validate('AgentNativeAnalysisResult',value)
            if (accepted['result']['payload']['schemaRef']!='AgentNativeAnalysisResult'
                    or value['context']!=binding['context']
                    or any(accepted['result'][key]!=binding['context'][key] for key in ('subject','rootId','taskId'))):raise SDKModelPolicyError()
            compact=dict(schema='agent-accepted-native-ref/1',result=accepted['result'],
                goalDigest=value['goalDigest'],outputDigest=value['outputDigest'])
            _validate('AgentAcceptedNativeReferenceContext',compact)
            await sequence.add_tool_result(accepted['result'],context.agent)
            return json.dumps(compact,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
        if result['kind']=='tool-error':return json.dumps(result,separators=(',',':'))
        raise SDKToolDeferred(result)
    return FunctionTool(name=name,description=item['description'],params_json_schema=schema,on_invoke_tool=invoke,
        strict_json_schema=False,needs_approval=False,timeout_behavior='raise_exception')
