"""Public SDK Model adapter over the private, metered kernel boundary.

The SDK owns its agent loop. This adapter handles one model operation and never
retries or sleeps. Its private binding must come from the durable controller;
model text, provider IDs and Temporal Run IDs cannot allocate that identity.
Tool execution, delegation and checkpoint persistence are separate boundaries.
"""
from copy import deepcopy
import asyncio
from dataclasses import fields
import hashlib
import json
from uuid import UUID,uuid5

from agents import Model,ModelProvider,ModelSettings,ModelTracing,RunHooks,TResponseInputItem
from agents.items import ModelResponse
from agents.tool import FunctionTool
from agents.usage import Usage
from openai.types.responses import Response
from pydantic import TypeAdapter

from .transport import _json,_validate,provider_usage

BINDING_KEY='agentic_os.model_binding.v1'
_RESPONSE_INPUT=TypeAdapter(list[TResponseInputItem])


class SDKModelPolicyError(ValueError):
    def __init__(self):super().__init__('unqualified_sdk_model_binding')


def serialized_response_input(items):
    if type(items) is str:return items
    from .lookup_output import FEEDBACK,CONTINUATION
    repair=any(type(item) is dict and item.get('id','').startswith('msg_os_feedback_')
        and item.get('role')=='assistant' and type(item.get('content')) is list
        and len(item['content'])==1 and type(item['content'][0].get('text')) is str
        and item['content'][0]['text'].startswith((FEEDBACK,CONTINUATION)) for item in items)
    restored_message=any(type(item) is dict and item.get('type')=='message'
        and item.get('role')=='assistant' and type(item.get('id')) is str
        and type(item.get('content')) is list for item in items)
    if repair or restored_message:
        # Private JSON continuation restores the official SDK's Iterable
        # message types before its strict serializer, including an accepted
        # owner question followed by its reply. Unknown fields still
        # fail; no content, source reference or provider result is replaced.
        items=_RESPONSE_INPUT.validate_python(items,strict=True,extra='forbid')
    return _RESPONSE_INPUT.dump_python(items,mode='json',warnings='error')


class SDKModelDeferred(RuntimeError):
    """Private controller decision. Never format its payload into a public error."""
    def __init__(self,preparation):
        self.preparation=deepcopy(preparation)
        super().__init__('governed_model_'+preparation['kind'])


def operation_id(binding):
    return str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/'+str(binding['turn'])))


def _dump(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def _input_digest(payload):
    # The closed generated payload reference contains only canonical control
    # fields. Provider documents use a separate opaque JSON boundary.
    _validate('AgentPayloadReference',payload)
    return hashlib.sha256(b'agentic-os.hash/1\0command\0'+_dump(payload).encode('utf-8')).hexdigest()


class SDKModelSequence(RunHooks):
    """Per-run public hooks; persist snapshot with the supported SDK checkpoint.

    A caller must give each agent/delegated context its own sequence and metadata
    dictionary. The production controller owns the instance ID and restores this
    state with SDK RunState; constructing a new sequence is not a restart policy.
    """
    def __init__(self,binding,*,dependency_boundary=None):
        _validate('AgentSDKModelBinding',binding)
        self.binding=deepcopy(binding)
        self.pending=None
        if dependency_boundary is not None and any(not callable(getattr(dependency_boundary,name,None))
                for name in ('accepted_model_operation','pack_input_results')):raise SDKModelPolicyError()
        self.dependency_boundary=dependency_boundary
        self._result_lock=asyncio.Lock()

    def snapshot(self):return deepcopy(self.binding)

    async def on_llm_start(self,context,agent,system_prompt,input_items):
        if self.pending is not None or agent.model_settings.metadata is None:raise SDKModelPolicyError()
        metadata=agent.model_settings.metadata
        if set(metadata)-{BINDING_KEY}:raise SDKModelPolicyError()
        self.pending=operation_id(self.binding)
        metadata[BINDING_KEY]=_dump(self.binding)

    async def on_llm_end(self,context,agent,response):
        if self.pending is None:raise SDKModelPolicyError()
        if self.dependency_boundary is not None:
            reference=await self.dependency_boundary.accepted_model_operation(self.binding['context'],self.pending)
            _validate('AgentResultReference',reference)
            self._result_owner(reference)
            if reference['payload']['schemaRef']!='AgentProviderResponse':raise SDKModelPolicyError()
            self.binding['inputResults']=[reference]
        self.binding['parentOperationId']=self.pending
        self.binding['turn']+=1
        _validate('AgentSDKModelBinding',self.binding)
        # SDK tool-choice reset copies ModelSettings before the next start
        # hook. Publish the next binding now, using the public end hook, so
        # that every supported settings copy contains the next operation.
        agent.model_settings.metadata[BINDING_KEY]=_dump(self.binding)
        self.pending=None

    async def add_tool_result(self,reference,agent):
        if self.dependency_boundary is None or self.pending is not None or agent is None:raise SDKModelPolicyError()
        _validate('AgentResultReference',reference);reference=deepcopy(reference)
        self._result_owner(reference)
        async with self._result_lock:
            results=self.binding['inputResults']
            for prior in results:
                if prior['resultId']==reference['resultId']:
                    if prior!=reference:raise SDKModelPolicyError()
                    return
            if len(results)==128:
                # A bounded wire page is not a task-wide tool/turn ceiling.
                results=[await self._pack_input_results(results)]
            results=sorted([*results,reference],key=lambda v:v['resultId'])
            self.binding['inputResults']=results;_validate('AgentSDKModelBinding',self.binding)
            agent.model_settings.metadata[BINDING_KEY]=_dump(self.binding)

    async def _pack_input_results(self,results):
        ordered=sorted(results,key=lambda v:v['resultId'])
        fingerprint=hashlib.sha256(_dump(ordered).encode()).hexdigest()
        set_id=str(uuid5(UUID(self.binding['sdkInstanceId']),'turn/'+str(self.binding['turn'])+'/input-results/'+fingerprint))
        packed=await self.dependency_boundary.pack_input_results(self.binding['context'],set_id,ordered)
        _validate('AgentInputResultSetResponse',packed)
        if packed['kind']!='ready':raise SDKModelDeferred(packed)
        self._result_owner(packed['result'])
        if packed['setId']!=set_id or packed['result']['payload']['schemaRef']!='AgentInputResultSet':raise SDKModelPolicyError()
        return packed['result']

    async def pack_accepted_results(self):
        """Meter an existing dependency page before a fresh SDK context."""
        if self.pending is not None or self.dependency_boundary is None:raise SDKModelPolicyError()
        async with self._result_lock:
            results=self.binding['inputResults']
            if len(results)>1:self.binding['inputResults']=[await self._pack_input_results(results)]
            _validate('AgentSDKModelBinding',self.binding)
        return self.snapshot()['inputResults']

    async def retain_query_facts(self,goal_digest,references,phase):
        if self.pending is not None or self.dependency_boundary is None:raise SDKModelPolicyError()
        remaining=sorted(deepcopy(references),key=lambda value:value['resultId']);head=None;invalid=set();ordinal=0
        async with self._result_lock:
            while remaining or head is None:
                width=128 if head is None else 127
                part=remaining[:width];remaining=remaining[width:]
                inputs=part if head is None else [head,*part]
                fingerprint=hashlib.sha256(_dump(inputs).encode()).hexdigest()
                ident=str(uuid5(UUID(self.binding['sdkInstanceId']),'turn/'+str(self.binding['turn'])+'/query-facts/'+goal_digest+'/'+phase+'/'+str(ordinal)+'/'+fingerprint))
                value=await self.dependency_boundary.retain_query_facts(self.binding['context'],goal_digest,ident,inputs,
                    self.binding['parentOperationId'])
                _validate('AgentQueryFactSetResponse',value)
                if value['kind']!='ready':raise SDKModelDeferred(value)
                if value['setId']!=ident:raise SDKModelPolicyError()
                self._result_owner(value['result'])
                if value['result']['payload']['schemaRef']!='AgentQueryFactSet':raise SDKModelPolicyError()
                head=value['result'];invalid.update(value['invalidQueryKeys']);ordinal+=1
            self.binding['inputResults']=[head];_validate('AgentSDKModelBinding',self.binding)
        return sorted(invalid)

    def _result_owner(self,reference):
        context=self.binding['context']
        if any(reference[k]!=context[k] for k in ('subject','taskId','rootId')):raise SDKModelPolicyError()


class GovernedResponsesModel(Model):
    def __init__(self,transport,*,max_output_tokens,reasoning_effort=None):
        if (transport.config.provider!='openai' or type(max_output_tokens) is not int
                or not 1<=max_output_tokens<2**53):raise SDKModelPolicyError()
        for name in ('stage_model_input','prepare_model_operation','accept_model'):
            if not callable(getattr(transport.boundary,name,None)):raise SDKModelPolicyError()
        self.transport,self.boundary=transport,transport.boundary
        self.max_output_tokens=max_output_tokens
        if reasoning_effort is not None and (type(reasoning_effort) is not str or reasoning_effort not in {'none','low','medium','high','xhigh'}):raise SDKModelPolicyError()
        self.reasoning_effort=reasoning_effort

    def _request(self,instructions,items,settings,tools,output_schema,handoffs,tracing,previous,conversation,prompt):
        if (tracing!=ModelTracing.DISABLED or previous is not None or conversation is not None
                or prompt is not None or handoffs or not isinstance(settings,ModelSettings)):
            raise SDKModelPolicyError()
        allowed={'metadata','max_tokens','store','parallel_tool_calls','tool_choice','reasoning','verbosity'}
        if any(getattr(settings,f.name) is not None for f in fields(settings) if f.name not in allowed):
            raise SDKModelPolicyError()
        if settings.store not in (None,False) or type(settings.metadata) is not dict or set(settings.metadata)!={BINDING_KEY}:
            raise SDKModelPolicyError()
        binding=_json(settings.metadata[BINDING_KEY]);_validate('AgentSDKModelBinding',binding)
        if binding['context']['model']['digest']!=self.transport.config.model_profile_digest:raise SDKModelPolicyError()
        maximum=self.max_output_tokens if settings.max_tokens is None else settings.max_tokens
        if type(maximum) is not int or not 1<=maximum<=self.max_output_tokens:raise SDKModelPolicyError()
        if (instructions is not None and type(instructions) is not str
                or type(items) not in (str,list)):raise SDKModelPolicyError()
        # Temporal's supported typed converter restores Iterable message content
        # as lazy Pydantic validators. The SDK's public input serializer consumes
        # those into JSON; deepcopy cannot copy them. Reject serializer warnings
        # and unknown objects before private staging or any provider admission.
        body=dict(input=serialized_response_input(items),
            include=['reasoning.encrypted_content'])
        if binding['context']['harness']['ref'].startswith('governed-read-discovery/'):
            from .catalog_context import discovery_model_input
            body['input']=discovery_model_input(body['input'],binding['context'])
            if settings.parallel_tool_calls is False:
                from .catalog_context import discovery_input_budget
                discovery_input_budget(body['input'],instructions)
        if instructions is not None:body['instructions']=instructions
        function_tools=[];names=set()
        for tool in tools:
            if not isinstance(tool,FunctionTool) or tool.name in names:raise SDKModelPolicyError()
            names.add(tool.name)
            function_tools.append(dict(type='function',name=tool.name,description=tool.description,
                parameters=deepcopy(tool.params_json_schema),strict=tool.strict_json_schema))
        if function_tools:body['tools']=function_tools
        choice=settings.tool_choice
        if choice is not None:
            if type(choice) is not str or choice not in {'auto','none','required'}|names:raise SDKModelPolicyError()
            body['tool_choice']=choice if choice in {'auto','none','required'} else dict(type='function',name=choice)
        if settings.parallel_tool_calls is not None:body['parallel_tool_calls']=settings.parallel_tool_calls
        if settings.reasoning is not None:body['reasoning']=settings.reasoning.model_dump(exclude_none=True)
        elif self.reasoning_effort is not None:body['reasoning']=dict(effort=self.reasoning_effort)
        text={}
        if output_schema is not None and not output_schema.is_plain_text():
            text['format']=dict(type='json_schema',name=output_schema.name(),schema=output_schema.json_schema(),
                strict=output_schema.is_strict_json_schema())
        if settings.verbosity is not None:text['verbosity']=settings.verbosity
        if text:body['text']=text
        raw=_dump(body);encoded=raw.encode('utf-8')
        if len(encoded)>self.transport.config.max_request_bytes and 'format' in text:
            context=binding['context'];harness=context['harness']
            legacy_child=(harness['ref']=='focused-child-reads/1' and harness['revision'] in {1,2}
                and binding['sdkInstanceId']!=str(uuid5(UUID(context['taskId']),'sdk-instance/1')))
            if (legacy_child and self.transport.config.max_request_bytes==4096
                    and text['format']['name']=='AgentReadAnswerDraft'):
                # These frozen reference profiles predate the provider schema
                # hint and retain their original4KiB wire envelope. The SDK's
                # complete output_schema/validate_json and Core completion
                # checks remain unchanged. Only an oversized, never-admitted
                # request uses the original provider format; fitting accepted
                # requests retain their exact bytes for replay.
                del text['format']
                if not text:del body['text']
                raw=_dump(body);encoded=raw.encode('utf-8')
        if len(encoded)>self.transport.config.max_request_bytes:raise SDKModelPolicyError()
        return binding,maximum,raw

    async def get_response(self,system_instructions,input,model_settings,tools,output_schema,handoffs,tracing,*,
                           previous_response_id,conversation_id,prompt):
        try:
            binding,maximum,raw=self._request(system_instructions,input,model_settings,tools,output_schema,
                handoffs,tracing,previous_response_id,conversation_id,prompt)
        except Exception:raise SDKModelPolicyError() from None
        ident=operation_id(binding);context=binding['context']
        child=(context['harness']['ref']=='focused-child-reads/1'
            and binding['sdkInstanceId']!=str(uuid5(UUID(context['taskId']),'sdk-instance/1')))
        staged=await self.boundary.stage_child_model_input(context,binding,raw) if child else await self.boundary.stage_model_input(context,ident,raw)
        if staged['kind']!='ready':raise SDKModelDeferred(staged)
        payload=staged['reference']['payload']
        identity={k:context[k] for k in ('taskId','rootId','segmentId','intentRevision','controlEpoch')}
        identity.update(operationId=ident,planRevision=binding['planRevision'],parentOperationId=binding['parentOperationId'],
            iteration=binding['turn']-1,kind='model',inputDigest=_input_digest(payload))
        record=dict(context=context,identity=identity,input=payload,inputResults=binding['inputResults'])
        reply=await self.boundary.prepare_model_operation(record,max_output_tokens=maximum,
            request_timeout_ms=self.transport.config.request_timeout_ms)
        preparation=reply['preparation']
        if preparation['kind']=='accepted':accepted=reply['accepted']
        elif preparation['kind']=='ready':
            request=preparation['request'];observed=await self.transport.invoke(request)
            if observed['operation']['state']!='succeeded':
                # Re-observe the journal so that known retry waits and UNKNOWN
                # holds remain kernel decisions, with no local provider retry.
                latest=await self.boundary.prepare_model_operation(record,max_output_tokens=maximum,
                    request_timeout_ms=self.transport.config.request_timeout_ms)
                raise SDKModelDeferred(latest['preparation'])
            accepted=await self.boundary.accept_model(request)
        else:raise SDKModelDeferred(preparation)
        try:
            candidate=_json(accepted['contentJson']);config=self.transport.config
            usage=provider_usage('openai',candidate,config.model_id,config.inference_geo)
            # The pinned OpenAI type requires this later optional detail. Keep
            # the original accepted bytes/accounting unchanged; normalize only
            # the local SDK view, as the pinned harness does for old snapshots.
            candidate['usage']['input_tokens_details'].setdefault('cache_write_tokens',0)
            response=Response.model_validate(candidate)
            if response.status!='completed' or response.error is not None:raise SDKModelPolicyError()
            names={tool.name for tool in tools};call_ids=set()
            if model_settings.parallel_tool_calls is False and sum(item.type=='function_call' for item in response.output)>1:
                raise SDKModelPolicyError()
            for item in response.output:
                if item.type not in {'message','function_call','reasoning'}:raise SDKModelPolicyError()
                if item.type=='function_call':
                    if item.name not in names or not item.call_id or item.call_id in call_ids:raise SDKModelPolicyError()
                    call_ids.add(item.call_id)
            if (context['harness']['ref'].startswith('governed-read-discovery/')
                    and model_settings.parallel_tool_calls is False):
                from .catalog_context import discovery_response_budget
                discovery_response_budget(response.output)
            input_total=usage['uncachedInputTokens']+usage['cachedInputTokens'];output_total=usage['outputTokens']
            return ModelResponse(output=response.output,response_id=response.id,usage=Usage(requests=1,
                input_tokens=input_total,output_tokens=output_total,total_tokens=input_total+output_total,
                input_tokens_details=response.usage.input_tokens_details,output_tokens_details=response.usage.output_tokens_details))
        except Exception:raise SDKModelPolicyError() from None

    async def stream_response(self,*args,**kwargs):
        # Public progress comes from durable OS events. Unaccepted provider
        # deltas must never bypass the accepted-result boundary.
        raise SDKModelPolicyError()
        yield


class GovernedResponsesProvider(ModelProvider):
    def __init__(self,model):
        if not isinstance(model,GovernedResponsesModel):raise SDKModelPolicyError()
        self.model=model

    def get_model(self,model_name):
        if model_name!=self.model.transport.config.model_id:raise SDKModelPolicyError()
        return self.model
