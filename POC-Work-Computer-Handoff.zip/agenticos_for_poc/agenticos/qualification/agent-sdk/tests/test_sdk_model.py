"""Actual SDK loop and official transport; kernel replies are synthetic here."""
import asyncio
from copy import deepcopy
from datetime import datetime,timezone
import json
from uuid import UUID,uuid5

from agents import Agent,ModelSettings,Runner,RunConfig,function_tool
from agents.models.interface import ModelTracing
import httpx
import pytest

from agentic_os_agent_worker.model_rpc import RPCModelBoundary
from agentic_os_agent_worker.sdk_model import (BINDING_KEY,GovernedResponsesModel,GovernedResponsesProvider,
    SDKModelDeferred,SDKModelPolicyError,SDKModelSequence,operation_id)
from agentic_os_agent_worker.transport import OfficialTransport
from provider_transport_fixture import fixture,ident
from test_model_rpc import observation


def response_document(output):
    _,_,_,response=fixture('openai')
    response.update(created_at=1,incomplete_details=None,instructions=None,metadata={},parallel_tool_calls=True,
        temperature=1.0,tool_choice='auto',tools=[],top_p=1.0,output=output)
    return response


def binding_fixture():
    config,request,_,_=fixture('openai')
    binding=dict(context=request['context'],sdkInstanceId=ident(81),turn=1,planRevision=1,
        parentOperationId=None,inputResults=[])
    return config,request,binding


def test_lookup_repair_restores_official_message_types_without_dropping_unknown_fields():
    from agentic_os_agent_worker.sdk_model import serialized_response_input
    from agentic_os_agent_worker.lookup_output import FEEDBACK,CONTINUATION
    from agentic_os_agent_worker.memory_output import analysis_feedback_message
    proposal=dict(type='message',role='assistant',id='msg_actual_proposal',status='completed',phase='final_answer',
        content=[dict(type='output_text',text='{"criteria":[]}',annotations=[],logprobs=[])])
    items=[dict(role='user',content='Original owner question'),proposal,
        analysis_feedback_message(FEEDBACK+' Missing a declared supporting read.',ident(81))]
    encoded=serialized_response_input(json.loads(json.dumps(items)))
    assert encoded==items
    continuation=[*items[:-1],analysis_feedback_message(CONTINUATION+' Reuse exact accepted sources.',ident(81))]
    assert serialized_response_input(json.loads(json.dumps(continuation)))==continuation
    owner_reply=[items[0],proposal,dict(role='user',content=json.dumps(dict(
        schema='agent-owner-reply/1',inputKind='change-details',text='Use the supplied synthetic coordinates.')))]
    assert serialized_response_input(json.loads(json.dumps(owner_reply)))==owner_reply
    invalid_reply=deepcopy(owner_reply);invalid_reply[1]['unrecognized_control']='must-refuse'
    with pytest.raises(Exception):serialized_response_input(invalid_reply)
    invalid=deepcopy(items);invalid[1]['unrecognized_control']='must-refuse'
    with pytest.raises(Exception):serialized_response_input(invalid)
    assert serialized_response_input('original plain input')=='original plain input'


@pytest.mark.parametrize('resource,field',[('00007','title'),('00000000-0000-4000-8000-000000000007','headline')])
def test_typed_child_output_fits_original_envelope_without_changing_accepted_requests(resource,field):
    from dataclasses import replace
    from types import SimpleNamespace
    from agents import FunctionTool
    from agents.items import ItemHelpers
    from agentic_os_agent_worker.memory_output import LookupOutput
    from agentic_os_agent_worker.transport import _SCHEMA
    config,_,binding=binding_fixture()
    binding['context']['harness'].update(ref='focused-child-reads/1',revision=2)
    def forbidden(*args,**kwargs):raise AssertionError('Pure request check cannot stage or dispatch work')
    async def invoke(*args,**kwargs):return forbidden()
    boundary=SimpleNamespace(stage_model_input=forbidden,prepare_model_operation=forbidden,accept_model=forbidden)
    def model(maximum):
        return GovernedResponsesModel(SimpleNamespace(config=replace(config,max_request_bytes=maximum),
            boundary=boundary),max_output_tokens=64)
    tool=FunctionTool(name='current_read',description='Read a synthetic value.',
        params_json_schema=deepcopy(_SCHEMA['$defs']['ReadToolArguments']),on_invoke_tool=invoke,strict_json_schema=False)
    selector=dict(resourceType='note' if field=='title' else 'document',externalIds=[resource],fieldNames=[field])
    original_question='Retrieve these exact authorized fields: '+json.dumps(selector,separators=(',',':'))
    instructions='Read the exact scoped fields through the governed tool. '*9
    output=LookupOutput(objective=False);schema_before=output.json_schema()
    arguments=(instructions,ItemHelpers.input_to_new_input_list(original_question),
        ModelSettings(metadata={BINDING_KEY:json.dumps(binding)},store=False,max_tokens=64),
        [tool],output,[],ModelTracing.DISABLED,None,None,None)
    original=model(16384)._request(*arguments)
    assert len(original[2].encode())>4096
    compact=model(4096)._request(*arguments)
    assert compact[:2]==original[:2] and len(compact[2].encode())<=4096
    before,after=json.loads(original[2]),json.loads(compact[2])
    assert before['input']==after['input']==ItemHelpers.input_to_new_input_list(original_question)
    assert before['instructions']==after['instructions']==instructions
    assert before['tools']==after['tools'] and before['include']==after['include']
    assert before['text']['format']['name']==output.name() and 'text' not in after
    from agents.exceptions import ModelBehaviorError
    with pytest.raises(ModelBehaviorError):
        output.validate_json('{"goalDigest":"wrong","facts":[]}')
    assert output.json_schema()==schema_before
    # Fitting, previously accepted operations keep the exact original wire body.
    assert model(len(original[2].encode()))._request(*arguments)==original
    with pytest.raises(SDKModelPolicyError):
        model(4096)._request(instructions*10,*arguments[1:])


@pytest.mark.parametrize('harness,revision,parent',[
    ('focused-child-reads/1',3,False),('synthetic',2,False),('focused-child-reads/1',2,True)])
def test_legacy_child_wire_compatibility_cannot_remove_other_profile_schema_hints(harness,revision,parent):
    from dataclasses import replace
    from types import SimpleNamespace
    from agentic_os_agent_worker.memory_output import LookupOutput
    config,_,binding=binding_fixture()
    binding['context']['harness'].update(ref=harness,revision=revision)
    if parent:binding['sdkInstanceId']=str(uuid5(UUID(binding['context']['taskId']),'sdk-instance/1'))
    def forbidden(*args,**kwargs):raise AssertionError('Rejected request cannot stage work')
    boundary=SimpleNamespace(stage_model_input=forbidden,prepare_model_operation=forbidden,accept_model=forbidden)
    model=GovernedResponsesModel(SimpleNamespace(config=replace(config,max_request_bytes=4096),boundary=boundary),max_output_tokens=64)
    with pytest.raises(SDKModelPolicyError):
        model._request('Current complete instructions. '*50,'Original request',
            ModelSettings(metadata={BINDING_KEY:json.dumps(binding)},store=False),[],LookupOutput(objective=False),[],
            ModelTracing.DISABLED,None,None,None)


def test_actual_request_budget_rejection_becomes_private_nonretryable_control_before_admission():
    from dataclasses import replace
    from types import SimpleNamespace
    from temporalio.exceptions import ApplicationError
    from agentic_os_agent_worker.temporal_driver import DurableModel,_wait
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    config,_,binding=binding_fixture();issued=[]
    async def unexpected(*args,**kwargs):
        issued.append(1);raise AssertionError('Rejected input cannot stage or issue provider work')
    boundary=SimpleNamespace(stage_model_input=unexpected,prepare_model_operation=unexpected,accept_model=unexpected)
    model=GovernedResponsesModel(SimpleNamespace(config=replace(config,max_request_bytes=1024),boundary=boundary),max_output_tokens=64)
    async def run():
        with pytest.raises(ApplicationError) as caught:
            await DurableModel(model).get_response('private-instruction-canary'+'x'*1024,'Original complete request',
                ModelSettings(metadata={BINDING_KEY:json.dumps(binding)},store=False),[],None,[],ModelTracing.DISABLED,
                previous_response_id=None,conversation_id=None,prompt=None)
        error=caught.value;control=_wait(error)
        assert error.non_retryable and control.status=='configuration-required' and error.__cause__ is None
        converter=AgentPayloadConverter();payload=converter.to_payloads([control])[0]
        assert b'private-instruction-canary' not in payload.SerializeToString()
        assert not issued and converter.from_payloads([payload])[0]==control
    asyncio.run(run())


def test_temporal_decoded_assistant_history_preserves_content_on_continuation():
    from temporalio.contrib.openai_agents._invoke_model_activity import ActivityModelInput
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    config,request,binding=binding_fixture();rpc=SyntheticOperationRPC(request);issued=[]
    items=[dict(role='user',content='Analyze the complete authorized query'),
        dict(type='message',id='partial',role='assistant',status='completed',content=[
            dict(type='output_text',text='{"results":["accepted-page-one"]}',annotations=[])]),
        dict(role='user',content='Coverage is incomplete; continue the same query')]
    converter=AgentPayloadConverter()
    decoded=converter.from_payloads(converter.to_payloads([dict(input=items,
        model_settings=ModelSettings(metadata={BINDING_KEY:json.dumps(binding)},store=False),tracing=0)]),[ActivityModelInput])[0]
    async def token():return 'synthetic-workload'
    async def upstream(r):
        issued.append(json.loads(r.content))
        return httpx.Response(200,json=response_document([dict(type='message',id='continued',role='assistant',status='completed',
            content=[dict(type='output_text',text='Continue accepted coverage',annotations=[])])]))
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(upstream))
        try:
            result=await GovernedResponsesModel(transport,max_output_tokens=64).get_response(None,decoded['input'],decoded['model_settings'],[],None,[],
                ModelTracing.DISABLED,previous_response_id=None,conversation_id=None,prompt=None)
            assert result.output[0].content[0].text=='Continue accepted coverage'
        finally:await transport.close();await boundary.close()
    asyncio.run(run())
    assert len(issued)==1 and issued[0]['input']==items
    assert rpc.events==['stage','prepare-operation','begin','finish','accept']


@pytest.mark.parametrize('fault',[None,'foreign-page','foreign-reference','extra-user','wide-response'])
def test_actual_model_sends_only_the_current_bound_discovery_window(fault):
    from agents import FunctionTool
    from test_tool_rpc import fixture as tool_fixture
    from test_tool_execution_rpc import accepted_for
    config,request,binding=binding_fixture()
    binding['context']['harness']['ref']='governed-read-discovery/'+'a'*64
    _,tool_request,_=tool_fixture();tool_request['context']=deepcopy(binding['context'])
    reference=accepted_for(tool_request)['accepted']['result']
    reference.update(subject=deepcopy(binding['context']['subject']),rootId=binding['context']['rootId'],taskId=binding['context']['taskId'])
    reference['payload']['schemaRef']='AgentCapabilityDiscoveryPage'
    def output(call_id,label):
        entry=dict(capability=deepcopy(tool_request['capability']),kind='read',title=label,description=label,
            descriptionTruncated=False,available=True,blocker=None,providerRef='synthetic.read')
        page=dict(context=deepcopy(binding['context']),request=dict(cursor=None,limit=16,retain=[]),
            catalogVersion=130,items=[entry],retained=[],nextCursor='opaque-next-page',validUntil=binding['context']['authorizationHorizon'])
        return dict(type='function_call_output',call_id=call_id,
            output=json.dumps(dict(schema='agent-capability-discovery/1',result=deepcopy(reference),page=page)))
    current=output('page_two','Current reviewed choice')
    data=json.loads(current['output'])
    data['page']['retained']=[deepcopy(data['page']['items'][0])|dict(title='Retained reviewed choice')]
    if fault=='foreign-page':data['page']['context']['subject']['subjectId']='foreign-owner'
    if fault=='foreign-reference':data['result']['rootId']=str(UUID(int=72))
    current['output']=json.dumps(data)
    original=dict(role='user',content='Original fixed read objective')
    items=[original,dict(type='function_call',id='fc_one',call_id='page_one',name='discover',arguments='{}'),
        output('page_one','PRIVATE-DROPPED-DESCRIPTOR'),
        dict(type='reasoning',id='rs_two',summary=[],encrypted_content='opaque-reasoning'),
        dict(type='function_call',id='fc_two',call_id='page_two',name='discover',arguments='{}'),current]
    if fault=='extra-user':items.insert(3,dict(role='user',content='Unbound replacement objective'))
    before=deepcopy(items);rpc=SyntheticOperationRPC(request);issued=[]
    async def no_tool(*_):raise AssertionError('Only model request projection is exercised')
    tool=FunctionTool(name='discover',description='Read current metadata',params_json_schema=dict(type='object',
        properties={},additionalProperties=False),on_invoke_tool=no_tool,strict_json_schema=False)
    async def token():return 'synthetic-workload'
    async def provider(r):
        issued.append(json.loads(r.content))
        if fault=='wide-response':
            arguments=dict(cursor=None,limit=16,retain=[dict(ref='r'+str(i).zfill(3)+'x'*252,
                revision=1,digest='a'*64) for i in range(64)])
            from agentic_os_agent_worker.transport import _validate
            _validate('AgentCapabilityDiscoveryRequest',arguments)
            return httpx.Response(200,json=response_document([dict(type='function_call',name='discover',call_id='wide',id='fc_wide',
                arguments=json.dumps(arguments,separators=(',',':')))]))
        return httpx.Response(200,json=response_document([dict(type='message',id='selected',role='assistant',status='completed',
            content=[dict(type='output_text',text='Selected current metadata',annotations=[])])]))
    async def run():
        from temporalio.contrib.openai_agents._invoke_model_activity import ActivityModelInput
        from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(provider))
        try:
            model=GovernedResponsesModel(transport,max_output_tokens=64)
            settings=ModelSettings(metadata={BINDING_KEY:json.dumps(binding)},store=False,parallel_tool_calls=False)
            # Restore the real SDK iterable types through its installed
            # Temporal converter, including reasoning-summary iterables.
            converter=AgentPayloadConverter()
            decoded=converter.from_payloads(converter.to_payloads([dict(input=items,model_settings=settings,tracing=0)]),[ActivityModelInput])[0]
            call=model.get_response(None,decoded['input'],decoded['model_settings'],
                [tool],None,[],ModelTracing.DISABLED,previous_response_id=None,conversation_id=None,prompt=None)
            if fault:
                with pytest.raises(SDKModelPolicyError):await call
            else:await call
        finally:await transport.close();await boundary.close()
    asyncio.run(run());assert items==before
    if fault=='wide-response':
        assert len(issued)==1 and rpc.events==['stage','prepare-operation','begin','finish','accept']
    elif fault:assert issued==[] and rpc.events==[]
    else:
        assert issued[0]['input']==[original,*items[3:]]
        assert 'PRIVATE-DROPPED-DESCRIPTOR' not in json.dumps(issued)
        assert issued[0]['input'][-1]==current


class SyntheticOperationRPC:
    def __init__(self,request):
        self.template=request;self.inputs={};self.calls={};self.accepted={};self.events=[];self.responses={}

    async def __call__(self,r):
        action=r.url.path.rsplit('/',1)[1];value=json.loads(r.content);self.events.append(action)
        if action in {'stage','child-stage'}:
            op=value['operationId'] if action=='stage' else operation_id(value['binding'])
            if action=='child-stage':assert value['binding']['context']==value['context']
            raw=value['inputJson']
            assert self.inputs.setdefault(op,raw)==raw
            payload=dict(artifactRef='artifact/'+op,ciphertextDigest='c'*64,bytes=len(raw.encode()),schemaRef='AgentProviderInput',schemaVersion=1)
            return httpx.Response(200,json=dict(kind='ready',reference=dict(subject=value['context']['subject'],
                rootId=value['context']['rootId'],taskId=value['context']['taskId'],writeId=str(uuid5(UUID(op),'provider-input/1')),
                payload=payload,createdAt=datetime.now(timezone.utc).isoformat(),expiresAt=value['context']['authorizationHorizon'])))
        if action=='prepare-operation':
            record=value['record'];op=record['identity']['operationId'];request=deepcopy(self.template)
            request['context']=record['context'];request['input']=request['grant']['input']=record['input']
            step=str(uuid5(UUID(op),'model-attempt/1'));request['step']['stepId']=request['grant']['stepId']=step
            request['step']['inputDigest']=request['grant']['inputDigest']=record['identity']['inputDigest']
            self.calls[step]=(op,request)
            if step in self.accepted:
                accepted=self.accepted[step]
                return httpx.Response(200,json=dict(preparation=dict(kind='accepted',operationId=op,attemptNumber=1,result=accepted['result']),accepted=accepted))
            return httpx.Response(200,json=dict(preparation=dict(kind='ready',operationId=op,attemptNumber=1,request=request),accepted=None))
        request=value['request'] if action in {'begin','finish'} else value;step=request['step']['stepId']
        if action=='begin':return httpx.Response(200,json=dict(inputJson=self.inputs[self.calls[step][0]]))
        if action=='finish':
            candidate=json.loads(value['candidateJson']);self.responses[step]=candidate
            return httpx.Response(200,json=observation(request,candidate))
        assert action=='accept'
        candidate=self.responses[step];observed=observation(request,candidate)
        ref=dict(subject=request['context']['subject'],taskId=request['context']['taskId'],rootId=request['context']['rootId'],
            resultId=step,producerStepId=step,acceptedAttemptId=request['grant']['attemptId'],payload=observed['operation']['candidate'],
            lineageRef=None,scopeRef=request['context']['scopeRef'],acceptedAt=datetime.now(timezone.utc).isoformat())
        result=dict(result=ref,contentJson=json.dumps(candidate));self.accepted[step]=result
        return httpx.Response(200,json=result)


def test_focused_sdk_child_stages_through_its_own_binding_and_replays_without_provider_io():
    config,request,binding=binding_fixture();binding['context']['harness']['ref']='focused-child-reads/1'
    binding['parentOperationId']=ident(91);request['context']=deepcopy(binding['context'])
    rpc=SyntheticOperationRPC(request);issued=[]
    async def token():return 'synthetic-workload'
    async def upstream(r):
        issued.append(json.loads(r.content))
        return httpx.Response(200,json=response_document([dict(type='message',id='focused',role='assistant',status='completed',
            content=[dict(type='output_text',text='Focused accepted output',annotations=[])])]))
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(upstream))
        model=GovernedResponsesModel(transport,max_output_tokens=64)
        settings=ModelSettings(metadata={BINDING_KEY:json.dumps(binding)},store=False)
        try:
            first=await model.get_response('Focused scope only','Own selector',settings,[],None,[],ModelTracing.DISABLED,
                previous_response_id=None,conversation_id=None,prompt=None)
            replay=await model.get_response('Focused scope only','Own selector',settings,[],None,[],ModelTracing.DISABLED,
                previous_response_id=None,conversation_id=None,prompt=None)
            assert first.output==replay.output and first.output[0].content[0].text=='Focused accepted output'
        finally:await transport.close();await boundary.close()
    asyncio.run(run())
    assert len(issued)==len(rpc.calls)==len(rpc.accepted)==1
    assert rpc.events==['child-stage','prepare-operation','begin','finish','accept','child-stage','prepare-operation']
    assert next(iter(rpc.inputs))==operation_id(binding)


@pytest.mark.parametrize('reasoning_effort',[None,'none','low','medium'])
def test_actual_sdk_reactive_loop_uses_distinct_operations_and_accepted_provider_results(reasoning_effort):
    config,request,binding=binding_fixture();rpc=SyntheticOperationRPC(request);issued=[];values=[]
    @function_tool
    async def advance(previous:int)->str:
        values.append(previous);return str(previous+1)
    async def token():return 'synthetic-workload'
    async def upstream(r):
        body=json.loads(r.content);issued.append(body)
        assert BINDING_KEY not in r.content.decode() and 'synthetic-workload' not in r.content.decode()
        assert body['include']==['reasoning.encrypted_content'] and body['store'] is False
        assert body.get('reasoning')==(None if reasoning_effort is None else dict(effort=reasoning_effort))
        assert any(json.loads(raw).get('reasoning')==body.get('reasoning') for raw in rpc.inputs.values())
        assert rpc.events[-1]=='begin'
        outputs=[i for i in body['input'] if i.get('type')=='function_call_output']
        n=int(outputs[-1]['output']) if outputs else 0
        output=([dict(type='function_call',call_id='call_'+str(n),name='advance',arguments=json.dumps(dict(previous=n)),
                      id='fc_'+str(n),status='completed')] if n<12 else
            [dict(type='message',id='msg_final',role='assistant',status='completed',content=[dict(type='output_text',text='Done',annotations=[])])])
        return httpx.Response(200,json=response_document(output))
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(upstream))
        model=GovernedResponsesModel(transport,max_output_tokens=64,reasoning_effort=reasoning_effort);hooks=SDKModelSequence(binding)
        agent=Agent(name='Governed compatibility loop',model=config.model_id,tools=[advance],
            model_settings=ModelSettings(metadata={},max_tokens=64,store=False))
        try:
            result=await Runner.run(agent,'Reach twelve',max_turns=None,hooks=hooks,
                run_config=RunConfig(model_provider=GovernedResponsesProvider(model),tracing_disabled=True))
            assert result.final_output=='Done' and result.context_wrapper.usage.requests==13
            assert hooks.snapshot()['turn']==14 and hooks.snapshot()['parentOperationId']==operation_id(binding|dict(turn=13))
        finally:await transport.close();await boundary.close()
    asyncio.run(run())
    assert values==list(range(12)) and len(issued)==len(rpc.calls)==len(rpc.accepted)==13
    assert rpc.events==['stage','prepare-operation','begin','finish','accept']*13


def test_governed_sdk_executes_independent_calls_in_one_explicit_parallel_round():
    config,request,binding=binding_fixture();rpc=SyntheticOperationRPC(request);issued=[];values=[]
    @function_tool
    async def advance(previous:int)->str:
        values.append(previous);return str(previous+1)
    async def token():return 'synthetic-workload'
    async def upstream(request):
        body=json.loads(request.content);issued.append(body)
        assert body['parallel_tool_calls'] is True and rpc.events[-1]=='begin'
        outputs=[item for item in body['input'] if item.get('type')=='function_call_output']
        if not outputs:
            output=[dict(type='function_call',call_id='independent_'+str(index),name='advance',
                arguments=json.dumps(dict(previous=index)),id='fc_'+str(index),status='completed') for index in (1,2)]
        else:
            assert {item['call_id'] for item in outputs}=={'independent_1','independent_2'}
            assert {item['output'] for item in outputs}=={'2','3'}
            output=[dict(type='message',id='complete',role='assistant',status='completed',
                content=[dict(type='output_text',text='Both accepted',annotations=[])])]
        return httpx.Response(200,json=response_document(output))
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(upstream))
        hooks=SDKModelSequence(binding);model=GovernedResponsesModel(transport,max_output_tokens=64)
        agent=Agent(name='Explicit parallel governed round',model=config.model_id,tools=[advance],
            model_settings=ModelSettings(metadata={},max_tokens=64,store=False,parallel_tool_calls=True))
        try:
            result=await Runner.run(agent,'Complete both independent reads',max_turns=None,hooks=hooks,
                run_config=RunConfig(model_provider=GovernedResponsesProvider(model),tracing_disabled=True))
            assert result.final_output=='Both accepted' and hooks.snapshot()['turn']==3
        finally:await transport.close();await boundary.close()
    asyncio.run(run())
    assert sorted(values)==[1,2] and len(issued)==len(rpc.calls)==len(rpc.accepted)==2
    assert rpc.events==['stage','prepare-operation','begin','finish','accept']*2


def test_accepted_replay_uses_the_same_binding_without_another_provider_call():
    config,request,binding=binding_fixture();rpc=SyntheticOperationRPC(request);issued=[]
    async def token():return 'synthetic-workload'
    async def upstream(r):
        issued.append(1)
        return httpx.Response(200,json=response_document([dict(type='message',id='msg_final',role='assistant',status='completed',
            content=[dict(type='output_text',text='Accepted once',annotations=[])])]))
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(upstream))
        try:
            model=GovernedResponsesModel(transport,max_output_tokens=64)
            async def call():
                return await model.get_response(None,'Synthetic request',ModelSettings(metadata={BINDING_KEY:json.dumps(binding)}),[],None,[],
                    ModelTracing.DISABLED,previous_response_id=None,conversation_id=None,prompt=None)
            first=await call();second=await call()
            assert first==second and first.output[0].content[0].text=='Accepted once'
            assert first.usage.input_tokens_details.cached_tokens==20
            assert first.usage.input_tokens_details.cache_write_tokens==0
            assert first.usage.output_tokens_details.reasoning_tokens==4 and first.usage.total_tokens==110
        finally:await transport.close();await boundary.close()
    asyncio.run(run());assert issued==[1] and rpc.events[-2:]==['stage','prepare-operation']


@pytest.mark.parametrize('fault',['missing-binding','tracing','provider-retry','stored-response','headers','handoff','input-object'])
def test_unqualified_sdk_options_fail_before_kernel_or_provider_io(fault):
    config,request,binding=binding_fixture();calls=[]
    async def token():calls.append('token');return 'synthetic-workload'
    async def io(r):calls.append('network');raise AssertionError('No I/O allowed')
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(io))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(io))
        settings=ModelSettings(metadata={BINDING_KEY:json.dumps(binding)});tracing=ModelTracing.DISABLED;handoffs=[];items='Synthetic'
        if fault=='missing-binding':settings.metadata={}
        elif fault=='tracing':tracing=ModelTracing.ENABLED
        elif fault=='provider-retry':settings.extra_args=dict(max_retries=2)
        elif fault=='stored-response':settings.store=True
        elif fault=='headers':settings.extra_headers=dict(Authorization='unapproved')
        elif fault=='handoff':handoffs=[object()]
        else:items=[dict(role='user',content=object())]
        try:
            with pytest.raises(SDKModelPolicyError):await GovernedResponsesModel(transport,max_output_tokens=64).get_response(
                None,items,settings,[],None,handoffs,tracing,previous_response_id=None,conversation_id=None,prompt=None)
        finally:await transport.close();await boundary.close()
    asyncio.run(run());assert calls==[]


@pytest.mark.parametrize('kind',['provider-wait','reconciliation'])
def test_kernel_wait_and_unknown_decisions_do_not_start_or_retry_a_provider_call(kind):
    config,request,binding=binding_fixture();rpc=SyntheticOperationRPC(request);issued=[]
    op=operation_id(binding)
    preparation=(dict(kind='provider-wait',operationId=op,attemptNumber=2,observedAt='2026-10-15T12:00:00Z',
        notBefore='2026-10-15T13:00:00Z',retryAfterMs=3600000,authorizationHorizon=binding['context']['authorizationHorizon'])
        if kind=='provider-wait' else dict(kind='reconciliation',operationId=op,attemptNumber=1,
            stepId=str(uuid5(UUID(op),'model-attempt/1')),reason='provider-completion-unknown'))
    async def token():return 'synthetic-workload'
    async def private(r):
        if r.url.path.endswith('/prepare-operation'):
            rpc.events.append('prepare-operation');return httpx.Response(200,json=dict(preparation=preparation,accepted=None))
        return await rpc(r)
    async def provider(r):issued.append(1);raise AssertionError('A wait cannot issue model I/O')
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(private))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(provider))
        try:
            with pytest.raises(SDKModelDeferred) as error:
                await GovernedResponsesModel(transport,max_output_tokens=64).get_response(None,'Synthetic request',
                    ModelSettings(metadata={BINDING_KEY:json.dumps(binding)}),[],None,[],ModelTracing.DISABLED,
                    previous_response_id=None,conversation_id=None,prompt=None)
            assert error.value.preparation==preparation
            assert '3600000' not in str(error.value) and binding['context']['rootId'] not in str(error.value)
        finally:await transport.close();await boundary.close()
    asyncio.run(run());assert issued==[] and rpc.events==['stage','prepare-operation']


@pytest.mark.parametrize('fault',['unregistered-function','duplicate-call-id','provider-hosted-output','parallel-policy'])
def test_unqualified_accepted_output_is_refused_before_sdk_tool_dispatch(fault):
    config,request,binding=binding_fixture();rpc=SyntheticOperationRPC(request)
    @function_tool
    async def registered()->str:raise AssertionError('No tool dispatch allowed')
    output=[dict(type='function_call',call_id='call_one',name='unregistered' if fault=='unregistered-function' else 'registered',
        arguments='{}',id='fc_one',status='completed')]
    if fault=='duplicate-call-id':output.append(output[0]|dict(id='fc_two'))
    if fault=='parallel-policy':output.append(output[0]|dict(id='fc_two',call_id='call_two'))
    if fault=='provider-hosted-output':output=[dict(type='web_search_call',id='web_unqualified',status='completed',
        action=dict(type='search',query='unqualified',sources=[]))]
    async def token():return 'synthetic-workload'
    async def provider(r):return httpx.Response(200,json=response_document(output))
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(provider))
        try:
            with pytest.raises(SDKModelPolicyError):await GovernedResponsesModel(transport,max_output_tokens=64).get_response(
                None,'Synthetic request',ModelSettings(metadata={BINDING_KEY:json.dumps(binding)},
                    parallel_tool_calls=False if fault=='parallel-policy' else None),[registered],None,[],
                ModelTracing.DISABLED,previous_response_id=None,conversation_id=None,prompt=None)
        finally:await transport.close();await boundary.close()
    asyncio.run(run());assert rpc.events==['stage','prepare-operation','begin','finish','accept']
