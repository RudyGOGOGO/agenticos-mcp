# Responsiveness checkpoint — implementation PAUSED

Read [the root handoff](../../../AGENTS.md) first. The owner has paused
feature development, optimization, acceptance and automatic continuation until
explicit resume. The five original review files are copied byte-for-byte;
[copied-package.json](copied-package.json) records their hashes. Their “design only”
wording is historical: implementation was authorized, then paused at this checkpoint.
Absolute paths in the original documents/evidence index are provenance, never
startup dependencies. Images and private trace originals are not bundled.

| Recommendation | Current state | Evidence / next action |
|---|---|---|
| P0.1 fresh-planner graph reuse | Installed; retained | Core `869e255c16c28196cbff6eaf5c4101aea3e79e89`, included in installed1f967152; no whole-journey speedup claim |
| P0.1 bounded post-Host source SQL batch | Committed7d71295b561372bed41da67cf30c30e342c6405f, not installed in the original stack | Nine protected SQL cases pass; one ordered pair132→124 queries,267.450→121.914ms; exact answer/source bytes retained |
| P0.3 per-invocation MCP session/catalog reuse | Committed38b8d20f0987c85b5e781d339333abca49ea119a, not installed in the original stack | Six focused cases cumulatively pass; expected protocol shape2initialize/3catalog/1call→1/1/1; no actual installed latency claim |
| P0.4 nonblocking numeric diagnostics | Committed664d1f173fd25c659b18af0d4627dba356973f5a, not installed in the original stack | Five focused cases pass; slow-writer barrier proves HTTP response is independent; no normal-response tool SQL |
| P0.2 delivery waits / surface refresh | Not implemented | Still80ms per32-character chunk; serial UI refresh, SSE close wait and polling remain |
| P1 redundant model/control calls / eligible simple reads | Not implemented | Preserve dynamic catalog composition and typed source validation; same model/comparable conditions first |
| P1.5 bounded context/deltas; timely forms; native refresh | Pending | Existing bounded two-turn context is not full contextual quality acceptance; no new context/cache architecture implemented |

Canonical product paths below are relative to `../../`:
`src/agentic_os/production/observation.py`, `src/agentic_os/adapters/poc/mcp.py`,
`src/agentic_os/adapters/mcp/client.py`, `src/agentic_os/adapters/poc/journey_observation.py`,
`src/agentic_os/presentation/stream.py`, `ui/shell/main.tsx`, and
`harnesses/agent-worker/src/agentic_os_agent_worker/read_journey.py`.

Focused safe summaries: [source batching](../../poc/evidence/latency-post-host-source-batching.json),
[MCP invocation](../../poc/evidence/latency-mcp-invocation-engineering.json),
[diagnostics](../../poc/evidence/latency-nonblocking-diagnostics-engineering.json).
Retain failed fixture reports; no failed aggregate was promoted to a pass.

On explicit resume: inspect all component status/WIP and active operations; run
the now-supported fresh bootstrap in the root guide if moving machines;
batch the remaining P0.2 changes, check affected boundaries cheaply, then build and
adopt matching Core/SDK only at verified idle. Run one comparable native read only
after the signed-in driver is ready. Separate execution from editing/confirmation;
never renew a Root or replay UNKNOWN. Then P1 and bounded context/forms, followed
by the still-open native write/compound and other design acceptance. Do not restart
a broad suite or rebuild Java/backend/iOS if their code is unchanged.

Portable handoff validation built/installed current source in a separate fresh
no-model fixture. This does not upgrade the original stack or establish an
installed/native latency improvement. Delivery-wait and later work remain paused.
