"""Prepare receipt-derived synthetic native follow-ups; never submit or approve.

These operator contexts are not executable grants. The peer driver still needs
its exact finite release, current authority and actual UI approval. No result
or receipt is synthesized by a preparation command.
"""
from pathlib import Path
from uuid import uuid4,UUID
from copy import deepcopy
import argparse,json,hashlib,subprocess,sys
from urllib.parse import urlsplit
from agentic_os.adapters.local.files import private_read,private_write,private_directory,check_private
from agentic_os.adapters.local.target import connect_owned
from agentic_os.contracts.validation import validate_contract
from agentic_os.production.profiles import version_pin
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from poc.client import LocalClient


def validated_native_continuation(parent,result,proof,native):
    """An observed UI draft is data for a new Send, never execution authority."""
    import math,time
    keys={'schema','parentRunId','parentTaskId','parentReceiptId','observedQuestion',
        'displayedControlLabel','nativeSession','capturedAtEpoch','Send'}
    expected={key:native[key] for key in ('subject','sessionId','generation')}
    if (set(proof)!=keys or proof['schema']!='vf.native-workflow-continuation-draft/1'
            or parent['schema']!='vf.native-workflow-context/2' or native['state']!='ACTIVE'
            or result['schema']!='vf.native-workflow-result/1' or result['taskState']!='COMPLETED'
            or result['workflow']!='create-location/1' or result['geofenceId'] is not None
            or result['runId']!=parent['runId'] or len(result['receiptIds'])!=1
            or proof['parentRunId']!=result['runId'] or proof['parentTaskId']!=result['taskId']
            or proof['parentReceiptId']!=result['receiptIds'][0]
            or proof['displayedControlLabel']!=parent['continueDraftLabel']
            or proof['nativeSession']!=expected or type(proof['nativeSession'].get('generation')) is not int
            or native['subject']!=parent['runtime']['subject']
            or type(proof['Send']) is not int or proof['Send']!=0
            or type(proof['observedQuestion']) is not str or not 1<=len(proof['observedQuestion'])<=2000
            or not proof['observedQuestion'].strip()
            or type(proof['capturedAtEpoch']) not in {int,float} or not math.isfinite(proof['capturedAtEpoch'])
            or not 0<proof['capturedAtEpoch']<=time.time()+5):
        raise ValueError('Exact observed unsent continuation and same current native login required')
    for value in [result['runId'],result['taskId'],result['locationId'],result['receiptIds'][0],native['sessionId']]:
        if str(UUID(value))!=value:raise ValueError('Canonical actual continuation bindings required')
    return proof['observedQuestion']


def validate_compound_results(parent,child,first,second):
    if (first['runId']!=parent['runId'] or second['runId']!=child['runId']
            or first['taskState']!='COMPLETED' or second['taskState']!='COMPLETED'
            or parent['workflow']!=first['workflow'] or child['workflow']!=second['workflow']
            or first['workflow']!='create-location/1'
            or second['workflow']!='create-boundary-at-created-location/1'
            or first['locationId']!=second['locationId'] or first['geofenceId'] is not None
            or len(first['receiptIds'])!=1 or len(second['receiptIds'])!=1
            or first['receiptIds']==second['receiptIds'] or first['taskId']==second['taskId']
            or second['parentReceiptId']!=first['receiptIds'][0]
            or child['priorResultFile']!=parent['actualResultFile']):
        raise ValueError('Exact completed parent and child receipt join required')
    for value in [first['taskId'],second['taskId'],first['locationId'],second['geofenceId'],*first['receiptIds'],*second['receiptIds']]:
        if str(UUID(value))!=value:raise ValueError('Canonical observed resource/receipt UUID required')


def boundary(args):
    parent=json.loads(private_read(args.parent_context,65536));result_path=Path(parent['actualResultFile'])
    result=json.loads(private_read(result_path,65536))
    assert result['runId']==parent['runId'] and result['taskState']=='COMPLETED' and result['workflow']=='create-location/1'
    assert result['geofenceId'] is None and len(result['receiptIds'])==1
    c=json.loads(private_read(args.runtime_config,65536));native=c.get('local_access') is not None
    capture=None
    if native:
        from agentic_os.adapters.poc.local_synthetic_access import LocalAccessRecord
        configured=c['local_access'];record=LocalAccessRecord(configured['state_file'],environment_id=configured['environment_id'],
            backend_environment=c['reviewed_effect']['backend_environment'])
        file=result_path.with_suffix('.continuation.json');raw=private_read(file,16384);actual=json.loads(raw)
        question=validated_native_continuation(parent,result,actual,record.read())
        capture=dict(file=str(file),sha256=hashlib.sha256(raw).hexdigest())
    else:
        client=LocalClient(c['public_origin'],c['host_origin'],embed_ref='vf.poc.embed/'+c['application_id'])
        try:
            client.sign_in(native_origin_header=False)
            actual=client.request('GET','/os/ui/agent-review/tasks/'+result['taskId']+'/continuation')
        finally:client.close()
        assert actual['phase']=='ready' and actual['taskId']==result['taskId']
        assert actual['receipt']['observation']['receiptId']==result['receiptIds'][0]
        assert actual['resource']['resourceType']=='saved-location' and actual['resource']['externalId']==result['locationId']
        module=(Path(__file__).resolve().parents[1]/'ui/shell/change-continuation.mjs').as_uri()
        script='import {continuationDraft} from '+json.dumps(module)+';let text="";for await(const chunk of process.stdin)text+=chunk;process.stdout.write(continuationDraft(JSON.parse(text)));'
        question=subprocess.check_output(['node','--input-type=module','-e',script],input=json.dumps(actual),text=True)
    assert 1<=len(question)<=2000
    requested=deepcopy(parent['requested']);requested['location']=deepcopy(parent['amended']['location'])
    amended=deepcopy(parent['amended']);assert amended['location']==requested['location']
    if native and (args.notification_type is None or args.enabled is None):
        raise ValueError('Explicit synthetic child notification/enabled amendments required')
    if args.notification_type is not None:amended['boundary']['notificationType']=args.notification_type
    if args.enabled is not None:amended['boundary']['enabled']=args.enabled=='true'
    run=str(uuid4());folder=args.native_root/'core-workflows'/run;private_directory(folder)
    context=deepcopy(parent);context.update(workflow='create-boundary-at-created-location/1',runId=run,question=question,requested=requested,amended=amended,
        actualResultFile=str(folder/'actual-result.json'),priorResultFile=str(result_path),ownerQuestion=None,continueDraftLabel='Continue remaining request',
        editor=dict(state='QUALIFIED',contract='core.boundary-edit/1',textLabels=dict(memberId='Member',radiusMeters='Radius (meters)'),
            selectLabels=dict(notificationType='Notifications',enabled='Enabled'),optionalChangeLabels={}))
    if native:
        context['editor']['expectedAssistantDefinitionRef']=parent['editor']['expectedAssistantDefinitionRef']
        context['editor']['optionalChangeLabels']={key:label+' change' for key,label in
            {**context['editor']['textLabels'],**context['editor']['selectLabels']}.items()}
        context.update(continuationDraftProof=capture,editing=dict(kind='choices-only/1',nameSuffix=None))
    private_write(folder/'current-continuation.json',json.dumps(actual,indent=2).encode())
    private_write(folder/'context.json',json.dumps(context,indent=2).encode())
    if not native:private_write(folder/'owner-credential.key',private_read(args.parent_context.parent/'owner-credential.key',4096))
    print(json.dumps(dict(runId=run,context=str(folder/'context.json'),parentTask=result['taskId'],actualParentLocation=result['locationId'],releaseCreated=False,AgentSend=0)))


def read(args):
    parent=json.loads(private_read(args.parent_context,65536));child=json.loads(private_read(args.boundary_context,65536))
    first=json.loads(private_read(Path(parent['actualResultFile']),65536));second=json.loads(private_read(Path(child['actualResultFile']),65536))
    validate_compound_results(parent,child,first,second)
    c=json.loads(private_read(args.runtime_config,65536))
    if c.get('local_access') is not None:raise ValueError('Native read preparation cannot use a diagnostic browser login')
    client=LocalClient(c['public_origin'],c['host_origin'],embed_ref='vf.poc.embed/'+c['application_id']).sign_in(native_origin_header=False)
    try:
        choices=client.request('GET','/os/bot-definitions')
        offered=[v for v in choices['bots'] if v['id']=='poc-family-read/1'];assert len(offered)==1
        choice=offered[0]
        with connect_owned(Path(c['manifest'])) as db:
            row=db.execute('SELECT payload,digest FROM os_agent_profiles WHERE application_id=%s AND definition_ref=%s AND revision=%s',
                (c['application_id'],choice['id'],choice['revision'])).fetchone()
        assert row is not None;profile,hashed=row;validate_contract('AgentAdmissionProfile',profile)
        assert profile['capabilities']['allowedKinds']==['read'] and profile['definition']['harness']['revision']==3
        assert profile['definition']['id']==choice['id'] and profile['definition']['revision']==choice['revision']
        run=str(uuid4());folder=args.native_root/'core-workflows'/run;private_directory(folder)
        expected=[dict(tool='LookupMemberByName',arguments=dict(displayName='Tom')),
            dict(tool='GetSavedLocationWithGeofences',arguments=dict(savedLocationId=first['locationId']))]
        eligibility=dict(schema='poc-current-native-read-eligibility/1',definition=version_pin(profile['definition'],'definition'),
            profile=profile['definition']['profile'],harness=profile['definition']['harness'],registeredProfileDigest=hashed,
            allowedKinds=['read'],currentOfferedChoice=choice,expectedInputs=expected,
            actualParentTask=first['taskId'],actualBoundaryTask=second['taskId'],actualLocationId=first['locationId'],actualGeofenceId=second['geofenceId'],
            authority=False,qualifiedBy='Current offered metadata plus immutable registered profile; actual admission/current sources still required.')
        raw=json.dumps(eligibility,indent=2).encode();file=folder/'read-eligibility.json';private_write(file,raw)
        name=parent['amended']['location']['name']
        question=f'Tom attends {name}. I prefer concise boundary summaries. Show only Tom\'s member record and the current boundary alerts at {name}, with the saved location identity. Do not retrieve last-known positions or location history.'
        labels=dict(composer='Message your assistant',send='Send',newConversation='New conversation',personalize='Personalize',
            assistant='Authorized assistant',savePersonalization='Save personalization',closePersonalization='Close Personalize your companion',
            terminalCompleted='Completed',acceptedAnswerRegion='Accepted answer',history='History',historyTitle='Your conversations',
            sourceTablePrefix='Source table. Scroll horizontally to view all columns.',disclosurePrefix='View supporting records')
        context=dict(schema='vf.native-readonly-context/1',runId=run,operation='send-readonly/1',runtime=parent['runtime'],question=question,
            actualResultFile=str(folder/'actual-result.json'),priorResultFile=None,reconnectCount=1,
            surfaceContract=dict(kind='source-tables/1',state='QUALIFIED',labels=labels,bounds=dict(maxTables=8,maxColumns=32,maxRowsPerTable=64,maxCellUTF16=2000)),
            admission=dict(assistantId=choice['id'],profileId=profile['definition']['profile']['ref'],profileRevision=profile['definition']['profile']['revision'],
                readCapabilities=sorted(['LookupMemberByName','GetLastKnownLocation','GetLocationHistory','ListSavedLocations','GetSavedLocationWithGeofences']),
                eligibilityFile=str(file),eligibilitySHA256=hashlib.sha256(raw).hexdigest()))
        private_write(folder/'context.json',json.dumps(context,indent=2).encode())
        print(json.dumps(dict(runId=run,context=str(folder/'context.json'),actualLocationId=first['locationId'],releaseCreated=False,AgentSend=0)))
    finally:client.close()


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['boundary','read'])
    p.add_argument('--runtime-config',required=True,type=Path)
    p.add_argument('--native-root',required=True,type=Path)
    p.add_argument('--parent-context',required=True,type=Path)
    p.add_argument('--boundary-context',type=Path)
    p.add_argument('--notification-type',choices=['ENTER_ONLY','LEAVE_ONLY','BOTH'])
    p.add_argument('--enabled',choices=['true','false'])
    args=p.parse_args(argv)
    if args.command=='read' and args.boundary_context is None:p.error('Read requires the actual completed child context')
    if any(not x.is_absolute() or x.resolve()!=x for x in [args.runtime_config,args.native_root,args.parent_context]):
        p.error('Exact protected runtime/native/context paths required')
    if args.parent_context.parent.parent!=args.native_root/'core-workflows':p.error('Current private parent context required')
    check_private(args.native_root/'core-workflows',directory=True)
    c=json.loads(private_read(args.runtime_config,65536));parent=json.loads(private_read(args.parent_context,65536))
    if (parent['runtime']['subject']!='test-user-001' or any(urlsplit(c[k]).hostname not in {'127.0.0.1','localhost'}
            for k in ['public_origin','host_origin','backend_url'])):p.error('Synthetic loopback runtime only')
    for key,target in [('VF_OS_ORIGIN','public_origin'),('VF_HOST_ORIGIN','host_origin'),('VF_NATIVE_INTEGRATION_BASE','backend_url')]:
        if parent['runtime']['launchEnvironment'][key]!=c[target]:p.error('Exact parent runtime binding required')
    if args.command=='boundary':boundary(args)
    else:read(args)


if __name__=='__main__':main()
