# Production Agent profiles and compatibility

Install and maintain the independent product by its separately retained release
manifest digest. The `0.1.0` package version alone does not establish compatibility.
Verify the Core wheel, UI, module inputs, dependency inventory and notices together;
keep the independently locked assigned SDK package separate. Installation and
successful local acceptance grant no production activation authority.

| Boundary | Supported selection and refusal |
|---|---|
| Core and UI | CPython3.12 and the exact distributed `agentic-os`0.1.0 wheel/UI/lock hashes. Reject missing, changed or mixed artifact members. |
| Assigned worker | The exact `agentic-os-agent-worker`0.1.0 artifact and its own lock: OpenAI Agents SDK0.19.4, OpenAI2.54.0 and TemporalIO1.34.0. Do not install the Core dependency graph into this environment. |
| Host and browser | Explicit registered bridge, capability schema, client profile, definition and harness revisions/digests. The distributed registered identity/contracts and required assurance must match. An older peer receives no implicit compatibility or execution authority from a matching package version. |
| Owned stores | The exact immutable component heads declared by the selected installation and artifact, including control0098 for the current production profile. Retained older profiles keep their original pins. A missing or incompatible required store/head fails readiness before admission. |
| Local execution | Local server, PostgreSQL, local Temporal, login-token identity, selected sandbox and local scheduler share the production core. Cloud credentials are unnecessary. The legacy all-component Core installation is a separate profile and may remain unavailable. |
| AWS execution | Thin Lambda entry points, EKS Core/native/SDK roles, EventBridge Scheduler, PostgreSQL, workload authorization and Temporal Cloud use the same contracts. Configuration/packaging and local checks do not qualify actual AWS/Cloud/IdP behavior. |
| Native placement | Explicit pinned Linux ARM64 Firecracker/jailer/kernel/rootfs/provider/runtime on a prepared device-capable host. Local nested-KVM acceptance is separate from actual deployed node containment/replacement. Retained Darwin component evidence grants no Linux/amd64 or default native activation. |

Profiles and history programs carry their original immutable pins. A replacement
worker must understand that exact history/profile; it cannot claim a new profile
by using an old package name. Preserve original task/Root identities, deadlines,
accepted results, receipts, private keys and UNKNOWN reservations across every
code or credential change. Recheck current owner/source authority before observing
or using saved results.

Before a code change, validate the selected artifact, declared store heads,
worker/history programs, Host/client contracts and immutable secret references.
Use the existing Park/drain and authenticated maintenance operations to quiesce
writers, prepare a compatible artifact and retain its checked recovery material.
After release, check readiness, fresh owner access, original history/receipt
observation and unchanged accounting. Keep the prior immutable code artifact for
an explicitly compatible rollback. An incompatible rollback requires isolation,
drain and forward recovery; never downgrade a populated schema or reset usage.
The detailed local and managed maintenance commands remain in
[README.md](README.md).

Temporal Cloud recovery retains the original namespace and encrypted-history
bindings through supported service APIs. Closed-history export is inspection
evidence, not restoration of running workflows. Never assume access to a Cloud
database, use local persistence restore for Cloud histories, or start replacement
work to hide missing recovery evidence. Missing external access leaves the
dependent live qualification open while independent engineering/local acceptance
continues. Default health-only startup and disabled production activation remain.

## Task incidents and truthful recovery

Inspect the current authenticated task snapshot and source surface before acting
on a saved message. History and screenshots record earlier observations; current
owner, application, source version and consent still govern access. A stream event
announces a committed fact. It does not grant authority, settle usage or prove that
a final answer exists. Reload recovers the current snapshot through the same
authorization checks.

| Current execution guidance | Operator action and preserved state |
|---|---|
| `provider-outcome-unknown` | The request may have reached the provider, but its result or usage is unconfirmed. Preserve the original request, task/Root, private history and held usage. Observe the original operation; do not resubmit or infer a refund from a timeout, account balance or closed HTTP connection. |
| `model-configuration-required` | Check the registered model, endpoint, credential access and immutable configuration through the supported credential/configuration lifecycle. Read the accompanying usage guidance: model unavailability can still leave UNKNOWN usage held. A configuration correction applies to eligible new admission and does not renew an existing task or release its reservation. Rewording the question does not repair configuration. |
| `provider-wait` | A known failed attempt may continue only through the existing task policy within its original limits. Preserve the saved question and accepted work; do not add a competing retry loop or submit a duplicate active task. |
| `model-failed` or `execution-expired` | No verified answer is implied. Retain accepted work and the original failure/deadline. A new owner request is separate admission, with fresh authority and its own resources; it cannot silently extend the old task. |
| `outcome-unresolved`, `effect-usage-unresolved` or `effect-reservation-held` | Keep the original effect/receipt identity and accounting. Use the existing authenticated receipt-only observation or held recovery procedure below. A confirmed application effect and unresolved OS usage are separate facts; never repeat the change merely to make the task close. |
| Current access or consent denied | Withhold old output and source details. Fix access only through the Host/owner's supported authority mechanism. A retained result, prompt, retrieved passage or administrator role does not grant another owner's private access. |

Stop remains the current authenticated control action. Its acknowledgement does
not assert that an already started remote request or effect was cancelled, nor
does it settle UNKNOWN usage. Do not edit SQL state, delete private journals,
replace source versions or reset a capacity/usage ledger to clear a warning.

For an incident, retain the separately verified artifact/profile/configuration
identities, opaque task/Root/operation IDs, original deadlines, safe field codes,
measured stage times and original receipt/accounting evidence in the authorized
private location. Keep credentials, provider bodies, source content and decrypted
histories out of general logs and public reports. A failed aggregate remains
failed even when a completed unaffected case is retained.

Readiness failure is not permission to migrate or reseed during startup. Validate
the selected artifact, declared component heads, current credentials and required
service bindings first. Use the supported Park/drain/maintenance and recovery
procedures below for changes; preserve running work and required recovery
material. Local acceptance, actual provider execution, deployed AWS/Temporal Cloud
qualification and controlled production activation require their own evidence.
Package installation or a fast synthetic response cannot substitute for them.

# Local coordinated recovery

The explicitly selected `coordinated-recovery/2` profile provides a held
six-component snapshot, restoration and authenticated privacy cleanup slice.
Original receipt observation and explicit current task runtime release have
separate actual qualification. G09 includes local M11/V08, safe maintenance, declared outage/load and provider-neutral contract conformance through cumulative 4,792-case evidence. Failed reports retain their outcomes. G10/final56 and hosting/live-provider profiles remain separate. Default startup continues to serve the health shell.

The `restoration-sql` development collection tests rollback-only privacy plans
under the actual owning database role. Frozen control0056 gives each plan an
append-only authority bound to the current transaction, an exact scoped receipt
and before/after row digests. It permits only listed erasure columns and
monotonic consent counters. The operator must authenticate surviving journals
and complete SDK, file and vector cleanup before committing a restoration.
These SQL checks alone grant no runtime readiness. Control0056 was applied on
an isolated held copy after protected populated rollback rehearsals; subsequent
DDL requires0057. Actual two-host all/entry/source cleanup checks preserve
independent corrections and measured provider usage. An actual private task
restore also erases derived files while preserving accepted host evidence,
accounting and original deadlines. These scopes form the explicit local synthetic G09 qualification. Historical owner commands, provider
state, measured usage, budgets and original deadlines retain their identities
and values.

Before the original snapshot, explicitly select an existing durable SDK root
outside the installation rollback domain. Missing SDK material is refused:

```sh
agentic-os recovery-sdk-select --manifest /absolute/owned/manifest.json --operator-key /absolute/private/operator.key --sdk-root /absolute/surviving/private-stage
```

On the restored BLOCKED target, prepare a bounded authenticated metadata intent,
then complete cancellation, vector and exact file erasure before its SQL commit:

```sh
agentic-os recovery-privacy-prepare --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION --journal-root /absolute/surviving/journals --controls-root /absolute/surviving/journals/controls
agentic-os recovery-privacy-finish --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --intent-id INTENT_UUID --journal-root /absolute/surviving/journals --controls-root /absolute/surviving/journals/controls
```

An unfinished consent acknowledgement, missing or changed ownership material,
or changed journal/row inventory keeps the target held. A lost local completion
acknowledgement resumes from the exact authoritative SQL commit without repeating
cleanup. These commands grant no runtime readiness and do not acknowledge old
pending owner commands.

The separately selected `surviving-consent/1` profile pins an independent journal
key through additive control revision0055. Provision it once for an active
application that already has its surviving deletion profile. Keep the journal
root outside the installation and snapshot rollback domain, on the same volume
as the explicitly selected capacity ledger:

```sh
agentic-os memory-controls-init --manifest /absolute/owned/manifest.json --operator-key /absolute/private/operator.key --application-id APPLICATION_UUID --journal-root /absolute/surviving/journals --capacity-root /absolute/same-volume/capacity
```

Provisioning seeds actual existing consent under application/settings locks. It
reserves32MiB through the SQL commit, creates a separate key, and refuses an
existing pin or orphan directory. A failed commit retains the private material;
there is no automatic adoption or reset. The operator command enables no lane.

Selected memory services check surviving consent before identity/settings locks
and private reads. Consent writes hold the consent journal before the deletion
journal, persist an intent after current authority and revision checks, and
acknowledge it only after the real SQL commit. A pending intent, missing or
changed key, corrupt material or older restored choice blocks access. An exact
retry can resolve a committed receipt after a lost acknowledgement; a different
command cannot clear that hold. Forget-all may advance unrelated epochs without
reopening a paused choice. New owners reserve only the exact default consent;
that never resets an existing surviving owner. Journal records contain opaque
owner MACs, consent booleans/profile references and bounded command metadata.
They contain no subject identifiers or personal content.

The `surviving-controls` component collection checks these service boundaries
through actual two-host HTTP, SQL rollback/commit, lost acknowledgement and
concurrent deletion. It does not replay consent into a restored database or
authorize a restored runtime. Legacy applications without this selected SQL pin
retain their previously qualified profile.
Snapshots hold both independent journals through all component copies, reject
pending privacy intents and verify the original SQL consent/deletion floors.
The receipt records opaque journal sequences, contract/workflow pins, active
registration/definition digests and original pending effect IDs. This supports
held backups; restoration replay and runtime activation remain pending. A passing
consent service check is not permission to restore an older consent choice.

The operator must stop the installation's gateway, dispatchers, workers, Temporal
and Core writers and dispose their pools before taking a snapshot. Park the OS
with the private installation operator credential:

```sh
agentic-os recovery-park --manifest /absolute/owned/manifest.json --operator-key /absolute/private/operator.key
agentic-os recovery-health --manifest /absolute/owned/manifest.json --operator-key /absolute/private/operator.key
```

Each control transaction holds a short shared recovery lock and checks the
authenticated gate. Parking takes its exclusive peer. New runtime connections
and transactions fail closed while parked, restoring or blocked. Corrupt gate
material cannot fall back to the historical unselected profile. Operator health
contains only a profile, state, generation, safe reason and empty enabled lanes;
it exposes no personal content or host authority.

Snapshot creation requires an explicitly parked installation, independently
placed new recovery key, and the already provisioned surviving journal root
outside the installation's rollback domain:

```sh
agentic-os recovery-snapshot --manifest /absolute/owned/manifest.json --operator-key /absolute/private/operator.key --recovery-key /absolute/separate/new-recovery.key --journal-root /absolute/surviving/journals --capacity-root /absolute/same-volume/capacity
```

The snapshot holds separate authenticated PostgreSQL control, retrieval, KB,
Temporal history, Temporal visibility and Core dumps. Each has its own observed
wall clocks, transaction/WAL watermarks, schema versions, row counts and row
fingerprints. These are separate component observations, not a global atomic
snapshot. All component runtime connections must be absent. Concurrent trusted
migrators must also remain stopped; compare-before/after fingerprints detect
changed component material.

Keys, encrypted artifacts, host credentials and protected KB key material are
inside a separate authenticated encrypted payload. The receipt contains only
opaque references, versions, counts and digests. A missing, pending or corrupt
surviving journal refuses snapshot creation. Snapshot limits are64MiB per SQL
dump,1GiB total source database storage,128MiB decoded file material,1million rows per table and128 application
journal checkpoints. A partial snapshot retains its material and failure marker
and is never accepted as a restore input.

Provision a fresh owned target for the same logical installation through the
guarded installer. It must have empty component databases and material stores
and its own new operator bootstrap. Restore into that target:

```sh
agentic-os recovery-restore --manifest /absolute/new-owned/manifest.json --operator-key /absolute/new-private/operator.key --backup /absolute/private/snapshot-uuid --recovery-key /absolute/separate/recovery.key --capacity-root /absolute/same-volume/capacity
```

The reader authenticates every component and all file paths before mutation.
Both commands reserve1GiB estimated host growth against the unchanged20GiB
floor through the signed ledger on the installation volume. The Docker estimate
is1GiB for snapshot and3GiB for restore, measured against its backing filesystem
separately. Reservations survive a failed or killed operation until explicit
accounting review. These estimates are conservative profile admission budgets,
not filesystem allocation guarantees or performance qualification.
Restoration verifies the original fingerprints and versions, restores component
metadata permissions and publishes `BLOCKED` with no enabled lanes. It never
restores an old operator credential, starts a workflow or sandbox, grants a
session, repeats a host effect or reopens recall. A partially restored target
also remains blocked. Preserve its evidence and use a new target for another
attempt; restoration into populated stores is refused.

Only an original parked installation with no registered host or task history
can use the internal idle-profile resume operation. Restored targets always
require the full reconciliation protocol. A working decryption probe is not
permission to disclose forgotten memory. The surviving journal and current
host receipts must be reconciled before any restored profile can be enabled.

Permitted old ciphertext remains decryptable after key rotation because existing
key IDs are retained. This does not authorize retention of forgotten private
content or revocation of an in-use key. Missing/wrong keys fail closed. Full
rotation/recovery, retention and privacy canary qualification belongs to G09.

For the implemented slice, run the guarded `--phase G09 --component
coordinated-snapshot` collection with the owned manifest and declared private
cache/capacity paths. It contains actual six-database restoration, exact row and
schema reconciliation, retained old-key decryption and blocked runtime checks,
plus hostile archive and parking concurrency cases. It is component evidence;
full G09 uses the complete cumulative case ledger; G10 release journeys remain separate.


Current snapshot receipts use coordinated-recovery/2. Authenticated version1
archives remain readable and restore held; they cannot authorize original-source
resume or imply current consent lineage. Version2 carries authenticated encrypted
relocation metadata for selected protected-knowledge purposes and the original
Temporal namespace/data/task queue. The target publishes a new operator-signed
held restoration binding; it never copies the source operator key or public-KB
password. Public model artifacts must be independently imported/verified in the
new placement before any private indexing lane can be considered.

To resume a populated original source after its exact snapshot, use:

```text
agentic-os recovery-resume-source --manifest /absolute/original/manifest.json --operator-key /absolute/private/operator.key --backup /absolute/authenticated/snapshot-id --recovery-key /absolute/separate/recovery.key --journal-root /absolute/surviving/journals --expected-generation 1
```

The command verifies the original run, parked generation, all six component
row/schema digests, protected material, current surviving privacy floors and
runtime pins. Any subsequent source change, journal advance or restored-target
marker refuses this path. A restored target requires the separate certified release below; idle source resume cannot release it.
For protecting an already BLOCKED copy before an additive migration, use
recovery-held-snapshot with the same snapshot arguments and a new independent
recovery key. Its gate mode/generation remain unchanged and runtime lanes stay
held. An explicit controls root may be supplied; otherwise it is journal-root/controls.

An operator can relocate selected knowledge purposes on an authenticated held
copy with its exact current generation:

```text
agentic-os recovery-knowledge-relocate --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation 2
```

This verifies every admitted knowledge key byte and the protected knowledge
schema, binds the retained key IDs to the new target, and issues a fresh public
metadata credential when that purpose was selected in the source. Unknown
bindings or global roles are refused. A signed pending operation retains the
exact credential before SQL; an interrupted commit can retry only that operation
and must attest all role privileges. Added raw-table privileges, changed keys or
missing verified roles refuse a retry. The operation enables no runtime lanes;
privacy restoration, workflow history and receipt reconciliation remain required
before any restored target can be released.

For a selected original Temporal namespace, the held operator can provision a
new owned service and inspect its restored opaque history catalog:

```text
agentic-os recovery-temporal-inspect --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation 2 --private-subnet 10.247.0.0/29 --rpc-subnet 10.247.0.8/29
```

The subnet pair must be distinct, canonical, private and unused. This verifies
the restored Temporal/visibility rows before the first service start, then
checks the original namespace identity, workflow/run IDs, profiles, queues and
bounded raw history digests. It returns no workflow client or decoded payload
and enables no workers, new starts, signals, cancellations or namespace
registration. Ordinary Temporal connection and start paths enforce the recovery
gate. Inspection alone cannot release a restored installation; current privacy,
receipt and program compatibility checks remain required.

Short control, retrieval and protected/public knowledge transactions hold a
shared recovery guard through SQL COMMIT, including connections already in a
pool. Operator parking waits for the current bounded transaction and blocks the
next borrower. Network and model requests cannot hold that SQL guard.

A held backup of an inspected relocated Temporal service preserves the original
logical namespace and task queues. Its physical database/service ownership still
belongs to the current copy. Pending inspection or an untracked service refuses
that backup path. Current relocation metadata also pins the original namespace
UUID; both the restored SQL namespace and its read RPC must match it. A separate
immutable signed lineage record retains the logical namespace across later hold
generations. Lineage authenticates identity and grants no runtime readiness.
Legacy relocation metadata remains readable with its original
source-run restriction. This does not release the held runtime.

Add --operator-diagnostics to an explicit owned lifecycle command to retain an
encrypted, bounded operator traceback when it fails. The ordinary error remains
safe and returns only an opaque diagnostic ID. The current installation operator
must authenticate; missing keys are never recreated. Private diagnostic library
access verifies installation/run binding, original encryption key and seven-day
retention. At most128 records are retained, and reaching the bound refuses new
diagnostics without replacing old evidence. This is not a personal-data API.

Owned control drift checks parse every current model CHECK on the same server,
including expressions and validation state. They also compare the complete
forward guard catalog: function signatures, bodies, invoker ownership and
settings, plus trigger arguments, deferral, enabled state and conditional
expressions. Unexpected programs, overloads or table ownership refuse readiness.
Untracked control schemas, views, row policies or row-security flags also refuse
this profile; these mechanisms are selected separately for the knowledge stores.
These checks use temporary objects and do not rewrite persistent data.


Original exact-input receipt selection is available before Park on an original
READY installation. Stop and drain its gateway, dispatchers, workers and live
execution first so every unresolved accepted effect has its original UNKNOWN
attempt, quarantined budget and closed public segment. The operator selects all
such admitted handles with their original observer credentials:

```sh
agentic-os recovery-receipt-select --manifest /absolute/original/manifest.json --operator-key /absolute/private/operator.key
```

Selection uses bounded READ ONLY metadata transactions and the maintained exact
binding inspector. It publishes one immutable recovery-metadata/receipts.json;
an existing selection cannot be replaced. Missing original observer credentials,
inconsistent accounting or history, unsupported handles and more than 128
handles refuse selection. It creates no execution authority and reads no owner
session, source, artifact ciphertext or controller credential. Include this
selection in the ordinary encrypted snapshot before restoring to a fresh owned
target.

While that target remains BLOCKED, observe one archived original handle:

```sh
agentic-os recovery-receipt-observe --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation 2 --attempt-id 00000000-0000-4000-8000-000000000001
```

The generation and opaque attempt ID must match the admitted snapshot. The
original authenticated host observer is authoritative. A terminal observation
may append its receipt and a new finished public segment; it preserves the
already closed segment and all original accounting, lease and deadline values.
Repeated observation is idempotent. PENDING remains pending, and UNKNOWN usage
stays held even after a COMMITTED receipt. Unavailable, altered or absent
observer evidence fails closed. This command neither repeats the effect nor
makes the runtime READY. Combined current privacy/history reconciliation,
M11/V08, runtime release and declared G09 mixed load are qualified together in the explicit local synthetic profile.

Exact-input capacity admission measures the fully attested owned container's
backing filesystems through the pinned local Engine 1.51 API and a fixed
unprivileged read-only command. It reserves capacity before obtaining fresh
remote preparation evidence; it does not cache headroom, renew finite grants
or change the 20GiB floor. Failed preparation can release only its known unused
new reservation. Any uncertain allocated work retains its recovery hold.


## Explicit restored task runtime

After actual privacy completion and original Temporal relocation, the operator
may request the selected restored task runtime release:

```sh
agentic-os recovery-workflow-quarantine --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION
agentic-os recovery-release --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION --intent-id INTENT_UUID --journal-root /absolute/surviving/journals --controls-root /absolute/surviving/journals/controls
```

Release verifies all six signed proofs: committed privacy cleanup, original
receipt observations, opaque original workflow quarantine, protected knowledge
purpose, known original material and the owned catalog. UNKNOWN usage remains
held even when a host receipt is COMMITTED. The certificate expires within
24 hours and binds the exact archive, owned target, code and gate generation.
Missing or changed proofs, keys or programs block runtime access. An exact
retry after acknowledgement loss returns the original published release.
The operator may select a shorter lifetime with `--release-seconds` (5 through
86,400); retry preserves the original expiry.

Archived sessions and embed challenges are permanently retired. Owners sign in
again through their ordinary HostBridge flow. New private task history checks
current owner, host policy, Stop, consent journals, source permission, knowledge
revisions and original deadlines before encryption key use. These checks also
fence the actual SQL commit. A changed classified consent version requires a
new index build through current source checks and the pinned embedding model;
old projections cannot be reused merely because restoration succeeded.

The current development profile supports fresh task and memory-task clients.
It preserves the original Temporal namespace and finite task/attempt limits;
it creates no replacement namespace and grants no archived workflow replay.
Restored native workers, learning and schedule execution are not enabled by
this certificate. Default startup stays health-only. Park invalidates the
certificate. Explicit maintenance recertification and key rotation/recovery
have actual local G09 qualification. The held receipt command retains its BLOCKED-only boundary.

Original admitted receipts have a separate operator purpose after Ready:

Current `agent-production/1` reviewed effects use these same selection, held
observation and Ready observation commands. Select an original `agent.effect`
attempt in `UNKNOWN`, `RUNNING` or `RESERVED` before Park. Its immutable decision, provider/observer
credential and original accounting metadata are included as
`recovery-metadata/production-receipts.json` in the signed encrypted archive.
The purpose-scoped reader cannot open preparation arguments, source artifacts,
private history or encryption keys, dispatch another effect, renew execution or
settle uncertain usage. A committed receipt remains visible to a fresh currently
authorized owner in History while the task reports unconfirmed usage. Restored
sessions and original execution tickets remain retired. Original `RUNNING` usage
remains held even when a committed Host receipt is available. A saved `RESERVED`
attempt proves that the atomic begin journal was never entered: recovery reports
`NOT_STARTED` / `NOT_SENT` without constructing or observing a Host receipt.
The release proof counts these journal facts separately from Host observations.
The current owner sees "Approved change not sent" only after verified retirement
of the original execution. Its original reservation remains held; a future attempt
requires a new request and separate review. Production repairs still require
separate reconciliation and keep release blocked. No pending attempt is treated
as zero usage or silently omitted.

```sh
agentic-os recovery-ready-receipt-observe --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION --attempt-id ORIGINAL_ATTEMPT_UUID
```

This command authenticates the exact original capsule, archive, six signed
proofs, current generation and observer credential. Each observation is bounded
to 20 seconds. It needs no private encryption keys, artifacts, execution
controller or other host credentials. A genuine expired execution certificate
can still prove the prior release for this receipt purpose; it grants no runtime
execution or decryption. Park, changed code/proofs, wrong generation or missing
observer evidence deny observation. A proof change after an actual SQL flush
rolls the transaction back. COMMITTED observations can append only their
original finished public receipt segment; PENDING remains truthful. Neither
state settles unknown usage, renews a deadline or repeats an effect.

The `restoration-runtime` component includes actual empty and populated
six-store restores, real accepted-source extraction through isolated Mem0,
owner approval, offline vectors, four knowledge layers, fresh ordinary logins,
proof-change SQL rollback, and missing-key/Stop/Revoke refusal before private
I/O. The `restoration-ready-receipts` component covers genuine COMMITTED/PENDING
receipts with absent private planes and real certificate expiry. The
`restoration-combined` component restores an older unresolved OS checkpoint
twice after newer host outcomes and surviving source Forget, Pause and Revoke;
it preserves independently authored corrections and unchanged host effect
counts. These components contribute actual passing case evidence to the complete cumulative G09/V08 qualification; they do not independently qualify other profiles.


## Restored key operations and maintenance

`recovery-status` probes all six owned stores and returns fixed availability
states. `recovery-metrics` returns aggregate queue, task and unknown-usage counts.
Neither command reads private encryption keys or returns owner identities,
inputs, error text or payloads. An unavailable count is not zero. All commands
require the installation operator key and independently validated manifest.

```sh
agentic-os recovery-status --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key
agentic-os recovery-metrics --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key
agentic-os recovery-key-inspect --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION
agentic-os recovery-key-rotate --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION --command-id COMMAND_UUID
agentic-os recovery-key-backup --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION --backup /absolute/independent/key-backup.json --recovery-key /absolute/independent/recovery.key
agentic-os recovery-key-recover --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION --command-id REPAIR_UUID --backup /absolute/independent/key-backup.json --recovery-key /absolute/independent/recovery.key
```

Rotation stages one new key, records its exact signed continuity and preserves
all original key bytes and ciphertext. Retry an interrupted rotation with the
same command and generation; an unfinished intent blocks runtime access. A lost
acknowledgment never permits generating a replacement staged key. The bounded
profile permits eight rotations and at most128 retained keys. Known missing or
changed material remains unavailable until explicit recovery authenticates the
exact current certificate, continuity, key pins and independent recovery key.
Corrupt bytes are retained in the private repair directory. Recovery neither
adopts unknown keys nor substitutes current keys for missing original ones.
For a restored managed AWS installation, supply `--recovery-config` with the
exact admitted managed recovery configuration to `recovery-key-rotate`,
`recovery-key-backup`, and `recovery-key-recover`. The current scoped AWS operator
is checked again before key publication and repair. Metadata-only key inspection
can authenticate a missing key directory; it grants no runtime transaction or
SQL operator access. Repair uses the independent encrypted backup and preserves
differing originals. Managed continuity records bind the admitted target and
original archive, not a Docker container. A rollback artifact must explicitly
support those records; unsupported readers are rejected before Park. Retain the
original keys and encrypted workflow histories throughout the handoff. Actual
AWS/Temporal Cloud qualification is separate from local synthetic acceptance.

Keep backup and recovery-key paths outside the installation in private owned
placement. A backup is immutable and generation-specific; create a new backup
after recertification or rotation. Keep its independent protection key separate
from the live encryption plane.

The same restored key operations support `--key-purpose knowledge` for the
separate protected-knowledge key plane; the default remains private history.
Purpose-specific signed continuity and independent backup records cannot be
replayed across planes. Original knowledge keys and ciphertext remain valid;
new encryption uses the authenticated new selector. Current runtime refuses
pending, unknown or altered material and cannot rotate or repair it on demand.
A current scoped operator may repair missing knowledge keys or their entire
key directory from the exact generation-specific encrypted backup. Preserve
all original protection, binding and continuity records. Older artifacts that
cannot read this purpose are refused before maintenance parks the installation.

Restored managed Cloud transport rollover uses the same maintenance commands.
Pass the currently admitted `--recovery-config` and an independently reviewed
`--replacement-recovery-config` to `recovery-maintenance-prepare`. The replacement
keeps the target, stores, namespace, retention, original run and secret ARN;
it selects a distinct immutable Cloud credential version and reviewed CA file.
The offline snapshot protection key is not needed for this transport change.
Preparation uses the proposed connection only for authenticated operator history
inspection. Current runtime remains bound to its published transport. Finish
`recovery-maintenance-release` with the exact command, artifact and replacement
recovery configuration; only complete signed history/privacy/key/accounting
recertification publishes the new pins. Retry the same preparation inputs after
an interrupted ACK. Keep every prior reviewed configuration/CA file immutable
for ancestry and rollback inspection. Unsupported older readers are refused
before another Park. This operation does not rotate SQL passwords, application
credentials, protected-knowledge keys or the installation operator credential.

Restored managed SQL credential/TLS rollover uses that same replacement option
when the `stores` configuration changes. Keep the installation, target,
logical databases/users, IAM/secret ARNs, expected schema heads, application
credentials, operator identity and Cloud transport unchanged. Select reviewed
immutable runtime/migrator secret versions and pinned SQL CA files. Prepare
with the current recovery configuration. Only after the exact command reports
`PARKED`, separately apply the reviewed PostgreSQL password/TLS cutover; the OS
command does not provision secrets or change database passwords. Release with
the replacement recovery configuration and the same command/artifact. Every
store, privacy, key, original-work and history check must pass before Ready.
An exact completed preparation can be acknowledged again without using retired
SQL credentials; this acknowledgment grants no runtime or current-data proof.
For an unfinished parked preparation after external cutover, select its signed
pending replacement configuration to finish with the new credentials. Keep all
prior configurations/CA files immutable. Current runtime rejects the old store
binding; unsupported older artifacts refuse before another Park. Operator
identity rotation remains a separate handoff.

For a restored managed operator handoff, prepare a replacement recovery
configuration with only the next operator generation and a distinct immutable
version of the same installation-owned operator Secret ARN. SQL credentials,
schema heads, application credentials and Cloud transport remain unchanged.
Use the current `--operator-key`, the existing
`--replacement-recovery-config` and a private 32-byte `--replacement-key` with
`recovery-maintenance-prepare`. The proposed secret must already resolve to that
replacement credential. The command stages it privately and Parks the original
finite operation; it does not provision or update an AWS Secret.

Release with the replacement recovery configuration and the new
`--operator-key`, preserving the command, artifact, parked generation and
surviving journal roots. The staged credential authorizes only that exact
handoff until publication. Interrupted key/state/publication writes resume the
same stage; an incomplete pre-Park stage is metadata-only operator recovery,
never ordinary runtime authority. After Ready, the old token and old
configuration cannot authorize current operations. Keep prior immutable
configurations, signed stages and private prior-key recovery evidence; do not
delete these as stale files. Ordinary maintenance and subsequent handoffs
retain the original operator ancestry and all work, privacy and accounting
checks. No admitted task deadline, allowance or UNKNOWN hold is renewed.

Maintenance chooses an immutable compatible wheel before Park. Preparation
waits for short active SQL transactions, validates current surviving privacy,
catalogs and keys, then records the exact old release and selected artifact.
Use the same command and artifact for release or an interrupted retry:

```sh
agentic-os recovery-maintenance-prepare --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --expected-generation GENERATION --command-id COMMAND_UUID --artifact /absolute/reviewed/agentic_os.whl --journal-root /absolute/surviving-deletion --controls-root /absolute/surviving-consent
agentic-os recovery-maintenance-release --manifest /absolute/restored/manifest.json --operator-key /absolute/restored/operator.key --command-id COMMAND_UUID --artifact /absolute/reviewed/agentic_os.whl --journal-root /absolute/surviving-deletion --controls-root /absolute/surviving-consent --release-seconds 86400
```

For code rollout, install the selected wheel independently while parked and run
release using that exact installed code. Preparation and recertification are
separate operations; replacement code cannot grant itself old runtime authority.
The new code must preserve original contracts and workflow programs. Raw drain
checks the original histories and appends truthful termination events without
private decryption. Revalidation preserves control rows, original deadlines and
UNKNOWN accounting. Ready publication retires all prior sessions, challenges,
workflows and queued task identities. Owners use fresh ordinary host sign-in;
poisoned or waiting retired dispatches cannot be repaired into execution.
A failed check leaves the installation parked. An exact successful retry returns
the original certificate and expiry rather than extending it.

Code rollback uses another prepare operation while running the selected release,
choosing the original wheel, followed by independent installation and release.
It does not downgrade schema or reopen old work. Signed certificate ancestry
retains original key continuity through rollout and rollback. Eight maintenance
operations are supported in this bounded profile. Actual local development
checks include two independent wheels, private workers on both releases, code
mismatch refusal and retired poisoned/waiting queues. G09 includes the frozen load and provider-neutral contract qualification; G10 final release qualification remains separate.


Explicit colocated SDK runtimes may borrow the same exact-manifest `ControlStore`
with `IdentityRuntime(..., control_store=owned.store)`. They retain distinct
admission services and current authority checks; closing a borrower does not
close the owner's pool. A selected profile may set `memory_sql_workers=4`;
the default remains eight, with the original finite queue and two-second wait.
Values outside one through eight are rejected before constructing the runtime.

The local G09 mixed-load declaration is frozen in
`tests/fixtures/g09-mixed-load-declaration.json`. Its component checks use a fresh
owned source for current-owner/native/schedule traffic and a genuine restored
original-receipt target with private execution planes absent. Per owner, actual
publication retains36 older vectors and64 current vectors. Stable samples and
actual PostgreSQL, embedding-child, pool and Park interruptions are recorded
separately. Failed cells retain their records and original deadlines/accounting.
The passing full declaration covers 384 actual requests, six native drafts, three schedule drivers and twelve interruptions. Receipt p95 remains bounded by the original 3 seconds; native tasks retain 45 seconds and recovery retains 20 seconds. The complete 4,792-case ledger retains compatible completed evidence under explicit impact review, with fresh affected receipt/authority, coherent and required host/data checks. Failed attempts remain failed. No single clean full final-source suite or production/live-provider/Linux/cloud qualification is claimed.

Artifact/key ports bind namespace, purpose and original ciphertext. The identity
port authenticates an interactive proof against method, path, origin and fresh
host state. The inference port streams the selected private provider transport;
original admission/usage bounds remain in the gateway. The sandbox port executes
or reconciles an original signed handle. These are consumed by actual local
adapters; structural compatibility never authorizes another provider or cloud.

The complete frozen G09 workload and current host gate were measured with
Docker Desktop bundled client/server 29.4.1 (API 1.54). This records the actual
local toolchain; other clients/engines need their own profile verification.
The selected client changes no image pin, owned-target guard, service deadline
or conservative capacity floor.

Declared mixed-load measurements use the selected Darwin ARM64 local synthetic profile with Docker Desktop's dashboard main process and renderer paused during verification to remove repeated whole-fleet statistics polling. The engine/VM settings, prior running services, image pins, 20 GiB floor and original workload/deadline/resource targets remain unchanged. The dashboard resumes before the local milestone commit. Transport failures and all original UNKNOWN holds retain their evidence.

Live running-state checks hold shared owner/control/task/segment/attempt row locks through commit. Stop, owner/session changes and execution mutations still require conflicting exclusive locks; all current-state, lease, context and budget checks remain. Mutating operations keep their original exclusive guard path. The base and native running-check helpers are pinned in restored release certificates.

Canonical encodings, hashes, signatures and rejected values remain unchanged. Exact ASCII strings skip a redundant surrogate scan; every non-ASCII string retains the original scan. The canonical helper is additionally pinned in restored release certificates.

Each fresh settings current-check keeps the original principal and bridge reads in their independent short transactions under one finite worker admission. The worker is released before the unchanged host RPC. Both current checks around consent/SQL work remain, with joined cancellation and no authority or result cache. The settings helper is additionally pinned in restored release certificates.

Canonical encoding retains fixed JSONEncoder configuration with per-call local encoding state. Every value is still checked and encoded afresh; exact type identity is read once per node, and validated ASCII keys need no repeated surrogate scan. Concurrent golden bytes/hashes and all original rejection rules remain qualified. No value, hash, authority or encoded result is cached.

A settings read uses two finite worker admissions. Its original read transaction and fresh post-read principal/bridge transactions execute consecutively, then the worker releases before the identical second host/policy RPC. Both current checks and all original transaction, deadline, cancellation and mutation fences remain; no result or authority is reused across requests.

The HTTP mixed-load driver owns a separate finite client executor bounded by the declared maximum 16 concurrent clients and joins it on success or failure. Waiting client sockets therefore cannot consume the service executor needed to answer them. Service worker, SQL pool, queue and request deadlines remain unchanged; the original complete declaration supplies the measurement evidence.
