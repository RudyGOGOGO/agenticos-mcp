# Local capacity, build cache and fixture retention

The independent runner and installer reserve estimated peak growth before
allocating writable build or storage state. The default floor is 20 GiB remaining
after all outstanding estimates. Host filesystem space and Docker backing-store
space are measured separately. Estimates are conservative and nested operations
may reserve additional capacity. They are admission limits, not performance
guarantees.

`tools/test_os.py` accepts `--cache`, `--capacity-root`, `--disk-floor-gib` and
`--peak-growth-gib`. One capacity root must be shared by all concurrent runs on
the selected storage placement, including runs with different cold caches. The
runner passes both roots to independent installations. Standalone installers
accept the operator-selected `AGENTIC_OS_BUILD_CACHE` and
`AGENTIC_OS_CAPACITY_ROOT`; otherwise they use private siblings of the explicit
installation root. No home-directory or historical-state discovery occurs.
Initialization refuses unrecognized root contents and existing resource data
whose ownership key is missing. It never adopts that data by creating a new key.

The pinned PostgreSQL image must already be explicitly installed for the
read-only Docker headroom probe. A missing image or unavailable measurement
refuses storage admission. Ordinary startup never downloads dependencies. The
probe has no network, host mounts or database volume.

## Verified immutable inputs

The Core migrator cache key binds source and toolchain pins, operating system,
architecture, build flags and the exact operator driver. A per-key lock covers
build, publication and use. Builds have private extraction/module/build caches;
published payloads are read-only and every use verifies their complete signed
inventory. Installations receive private copies of the migrator. Writable stores,
credentials, keys and artifacts are never shared through this cache.

Publication uses verified atomic rename and a total cache ceiling (2 GiB by
default). An oversized or changed entry is refused. Interrupted builds never
publish partial content. A failed or killed operation retains its capacity
reservation until the operator reviews cleanup. Live reservations cannot be
released; release changes accounting only and deletes no resource.

Run module tools from this independent module, using its frozen environment:

```sh
uv run --frozen python tools/resources.py cache-inventory --cache /absolute/private/cache
uv run --frozen python tools/resources.py capacity --cache /absolute/private/cache --capacity-root /absolute/private/capacity
```

After inspecting the saved capacity inventory and proving teardown, an operator
may use `release-reservation` with `--reservation`, `--review` and the same
capacity root. The exact record must still match. Cache retirement also requires
`cache-retirement-preview --cache-key` followed by
`cache-retirement-execute --cache-key --preview-digest`; active or unresolved
references deny retirement.
Pass the same `--capacity-root` to cache inventory and retirement commands when
using an explicitly selected shared admission ledger.

## Creation dispositions and provider retirement

New manifests retain their existing ownership signature format. A separate
versioned signed retention ledger records `active-retained` (default),
`recovery-hold`, or explicitly declared `disposable-synthetic`. The installer CLI
accepts `--disposition`. Historical installations without a ledger remain
retained and cannot be automatically adopted for deletion. Restore targets have
recovery holds.

The current reaper qualifies stopped PostgreSQL-only synthetic fixtures and
immutable cache entries. Other component/VM profiles remain retained until their
own lifecycle qualification exists. It never uses global prune or removes
database files directly. Keys, ownership manifests, backups, artifacts and
compact evidence stay on the host. Backup/artifact dependencies, incomplete
installation, unknown labels, foreign volume consumers, links, live leases and
active processes deny retirement.

Docker Desktop may retain the exact read-only bootstrap bind after an owned
container stops. Only that verified provider mount and its parent directory are
recognized; other open files/processes still deny retirement. The host bootstrap
file remains preserved.

```sh
uv run --frozen python tools/resources.py fixture-inventory --manifest /absolute/owned/manifest.json
uv run --frozen python tools/resources.py retirement-preview --manifest /absolute/owned/manifest.json
uv run --frozen python tools/resources.py retirement-execute --manifest /absolute/owned/manifest.json --preview-digest EXACT_PREVIEW_DIGEST
```

Execution revalidates the entire preview under exclusive fixture/retention locks.
It records retirement intent before provider deletion and never forces removal.
A partial provider failure remains visibly `retiring`; obtain a new preview to
retry the remaining exact resources. Logical provider byte counts and measured
host free-space changes have different meanings.

## Test evidence

The phase report requires an explicit pytest completion marker after the full
case lifecycle. Empty interrupted JUnit entries are reported as unfinished, and
missing/truncated evidence cannot qualify a gate. Source hashing excludes only
files named exactly `.DS_Store`; hidden source, contracts and locks remain hashed.
Old failed/interrupted reports retain their original status.
