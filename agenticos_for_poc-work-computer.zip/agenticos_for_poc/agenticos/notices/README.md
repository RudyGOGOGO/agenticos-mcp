# Dependency provenance

Python and JavaScript distributions are pinned by independent uv/npm locks, including
registry artifact integrity. No third-party source was copied into the OS kernel.
The G00 dependency audit and installed distribution/license inventory are generated
as local evidence, not an assertion of production certification. Subsequent phases
must add the selected component's license, source/artifact digest and actual tests
before enabling it. Meilisearch, NATS and cloud-emulator services are outside the
selected runtime. Mem0 brings the pinned `qdrant-client` library transitively;
the observed release inventory includes its licence and notices. Qualified
staging uses its owned SQLite store and canonical publication uses PostgreSQL;
no Qdrant server is selected, started or made a default retrieval service.

JSON Schema: Draft 2020-12 (offline references). Python validation: jsonschema (MIT).
JavaScript validation: Ajv (MIT), ajv-formats (MIT). HTTP: FastAPI (MIT), Starlette
(BSD-3-Clause), Uvicorn (BSD-3-Clause). Build: Hatchling (MIT). Test tooling: pytest
(MIT), HTTPX (BSD-3-Clause), TypeScript (Apache-2.0). Their transitive packages retain
their own license metadata/notices in the installed distributions. OS application
code remains repository-owned; this document grants no new application license.

The independent release builder retains actual installed Python notices in
`third-party-python.txt` and records their exact bytes/provenance in its observed
inventory. Tokenizers0.23.2 and FlatBuffers25.12.19 omit notice files from their
installed wheels; `deploy/release-notices/pins.json` pins the full original
Apache2 notices from their corresponding upstream version tags. The builder
refuses a missing notice or a mismatched installed/locked dependency. The
CycloneDX1.6 inventory distinguishes runtime dependencies from verification
tools and identifies the hash scope instead of implying upstream binary SBOMs.

Ajv 8.17.1 was rejected during dependency installation due to GHSA-2g4f-4pwh-qvx6;
the lock selects 8.20.0. Vulnerability disposition is recorded even though the
affected `$data` option is not used. Re-run dependency audits when locks change.

The isolated test dependency pytest 8.4.2 was also rejected after PYSEC-2026-1845
was reported; this module selects fixed pytest 9.0.3. The existing host's dependency
lock is separate and is not changed by the OS packaging milestone.

G01 storage: Psycopg/psycopg-pool (LGPL-3.0-or-later, binary package distribution
notices retained), SQLAlchemy and Alembic (MIT), cryptography (Apache-2.0 OR
BSD-3-Clause). PostgreSQL uses its PostgreSQL License and pgvector its upstream
license; locked container images retain their distribution notices. Temporal
server/admin tools are pinned to 1.32.0 digests and own their component migrations.
OpenAgentCore is pinned to commit 99ba9b48d06e79fdb0c8e602556c34c71da16309 and
its original MIT notice is retained in OpenAgentCore-LICENSE.md. Installation
builds a small operator driver around the original migrator from hash-verified
source using the pinned Go toolchain and unchanged go.sum. Go dependencies retain
their original upstream notices. This does not qualify Core native execution or
transfer its control-plane authority into the OS.

The disabled G06 native development profile pins Microsandbox runtime/firmware
and Go SDK0.7.6, Core99ba9b48, native Linux ARM64 Codex0.153.4 and the ARM64
Python OCI manifest together in `deploy/native-lock.json`. The original Apache
2.0 SDK notice is retained in `Microsandbox-LICENSE.txt`. Runtime, firmware,
harness and transitive native inventories remain separate qualification work;
the Python/JavaScript dependency audit does not certify these artifacts. The
native SDK bridge is repository-owned code and does not fork Core session logic.
The disabled native installer copies the original SDK/Core notices into each
private installation and records exact build inputs, observed Go module metadata
and output hashes in `native/provenance.json`. Complete runtime/firmware,
Codex Rust and guest-image notices/inventory remain required before activation.

The initial historical cryptography 46.0.5 pin was rejected by the G01 audit
(11 advisory records, including duplicate aliases). The module lock now selects
50.0.2, with OpenSSL 4.0.3 wheels; see the upstream [changelog](https://cryptography.io/en/latest/changelog/).
Artifact/backup authentication and clean installation are reverified against that
lock. Advisory audit results cover the audited Python/JavaScript packages only;
they do not certify containers, Go components or production placement.

G02 identity component: MCP Python SDK 2.2.0 and TypeScript SDK 1.32.0 (MIT),
PyJWT 2.15.1 (MIT), Temporal Python SDK 1.34.0 (MIT), and OPA 1.21.1
(Apache-2.0). OPA's platform binary is hash-locked in source-lock.json. MCP 2.2.0
uses its own HTTPX2/HTTPCore2 transport dependencies; the adapter is tested
against that actual SDK rather than assuming HTTPX 0.x interchangeability.
Example-host Express 5.2.1 (MIT) and Zod 4.6.5 (MIT) use a separate npm lock.
Temporal installation here does not yet qualify durable task execution.

G03 bounded cognition uses Agno 3.1.1 (Apache-2.0) without copying or modifying its
source; distribution notices remain in the installed dependency. AG-UI Python
protocol 1.0.0 (MIT) supplies the actual event models/SSE encoder. Its upstream
open metadata/raw/reasoning union is narrowed by the OS closed public profile.
Python lock artifact hashes and the installed-distribution inventory record
provenance. The streaming lock audit reports zero known advisories; it does not
certify containers, Go dependencies, external models or production deployment.
