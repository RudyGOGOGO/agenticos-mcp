# Agentic OS

The private worker review handoff now selects the original accepted
preparation's exact capability pin. Applications with several preparation
journals retain the same context, original model operation, authenticated
invocation and journal acceptance checks; no ambiguous default is selected.
The actual VF native request640eabbe reached four known model calls and the
CreateGeofence preparation, then failed before review because the old handoff
requested a default from four journals. Its Root8e7e0f93 remains CLOSED with
zero outstanding usage and the original deadline; no amendment, approval or
effect occurred. The failed run is retained. Two focused private handoff cases
pass for single/multiple capabilities and distinct application ownership.
Installed fresh native integration after this fix remains a separate open gate.

The following native attemptea4c37fd reached WAITING_APPROVAL, but its review
body was unavailable because saved review material selected a capability from
the invocation's top level rather than its immutable record. That reader now
uses the canonical record shape. A canonical-wire multi-journal regression
and the existing actual SQL owner amendment, stale approval refusal, fresh
confirmation and one authoritative receipt service case pass. The failed native
attempt expired without an amendment or effect; its original Root is CLOSED
with zero outstanding usage. Its conservative500000micros global UNKNOWN
reservation remains held, bringing the preserved allowance to51 UNKNOWN.
Component service evidence does not replace the remaining native S1 gate.

The third native attempt2c273d3e loaded the actual initial proposal fields, then
stopped before owner editing because native hit detection rejected a visible,
enabled control. It expired without an amendment or effect; its original Root
is CLOSED with zero outstanding usage. The global allowance now preserves52
UNKNOWN holds. No failed task is reopened or automatically resubmitted.

Direct due polling now skips expired or retired definitions. The unchanged
frozen SQL guard requires live reviewed authority even for an observational
UPDATE; an expired historical definition previously stopped the poll controller.
A rollback caused by that exact deferred expiry guard is retained without an
observation retry or authority renewal. Other SQL errors still propagate. The
focused actual PostgreSQL expiry-race check proves that the expired definition
stays unchanged and another reviewed definition continues polling with no task
allocated. The initial test's stale pre-expiry observation comparison failed
and is retained; the corrected final-observation check passes. Real Java due
execution and native schedule acceptance remain distinct integration gates.

The [local recovery operations guide](OPERATIONS.md) documents the explicitly
selected six-component snapshot/restore, surviving consent/control reconciliation and original receipt recovery. G09 has complete cumulative local synthetic qualification; G10 and all 56 final release journeys remain pending.

Explicit local Temporal provisioning can select two unused RFC1918 `/29`
subnets through `start(manifest, network_subnets={"private": ..., "rpc": ...})`.
The bounded Docker inventory must prove that both are available before creation.
The new signed service binding pins their exact address configuration and rejects
later changes. Existing version-1 service bindings retain their original networks.
This operator-only provisioning option preserves retained fixtures when Docker's
default address pools are exhausted; it enables no application lane or worker.

The explicitly selected `partial-evidence-read/1` harness reuses the ordinary
read journey and governed SDK tools. Core checks all causal accepted pages for
conflicting values of a requested resource/field; a model cannot select one
conflicting value as truth. If disagreement is the only remaining gap, a private
`AgentPartialReadVerification` retains all obtainable consistent facts and both
original sources, publishes specific integration guidance, and records a failed
goal rather than successful completion. Obtainable omissions return to the SDK
loop. Publication requires settled original usage; UNKNOWN stays held. Source
inspection and reload retain current authority checks. Four additive private
contracts use existing payload storage; frozen control0089 is unchanged. This
profile does not replace other gap handling or qualify live inference/deployment.

The explicit `agent-capability-read-journey/1` profile extends current governed
catalog discovery over the same read executor. Core accepts a missing-primitive
diagnosis only when a complete current catalog and the owned registry establish
that no qualified business primitive is enabled. An unavailable-adapter outcome
also requires the exact registered capability and no available business
alternative. Partial/hidden metadata or any usable primitive returns to planning;
this is no claim to prove arbitrary semantic impossibility. Rejected diagnoses
retain the original request and accepted metadata through the installed SDK.
Verified failures retain specific operator/developer guidance through History and
reload, with no invented business evidence. Publication requires current catalog
and owner authority, settled usage and the original deadline; UNKNOWN remains
held. One lost terminal acknowledgement observes the same accepted operation,
then waits if still uncertain. Five additive contracts reuse existing private
payload storage and frozen0089; no migration or production activation is implied.

Independent personal-assistant service product. Hosts retain their authentication,
business services, frameworks and databases and connect through remote contracts.
No host package, configuration, database or ignored design file is a setup dependency.

The explicit production development read profile now supports reviewed query pages
and exact derived summaries through the same authenticated conversation, installed
SDK worker, Temporal history and original resource ledger. Query contracts bind
grain, child grouping, cursors, snapshot and coverage. A closed Decimal/Fraction
operator preserves currency partitions, versioned unit conversions, latest accepted
revisions, null/zero meaning, ties and half-even rounding. Derived answers retain
their source lineage and require current Host authority on publication and reload.
The original summary presentation profile refuses more than64 rows or3 source pages;
its accepted histories retain that behavior. Frozen laboratory and actual WP
warehouse browser outcomes are verified locally with synthetic inference. They cover
exact sourced answers, History/reload/mobile and original-root closure; laboratory
coverage rejection continues under the same root. The WP outcome distinguishes total
property allocation, property/bill allocation and bill face amounts through its actual
login and assistant frame, with current authority and exact query credentials.
Neither result qualifies live inference, AWS deployment or production activation.

The separately selected `agent-adaptive-analysis-journey/1` profile permits
operator-pinned read discovery before binding its immutable analysis goal. Its
admitted harness reference fixes the discovery selection. Started discovery reads
must be accepted and settled; the planner's causal inputs and captured original
question are revalidated before binding. Current authority still governs reads,
reuse and publication, and the original question remains the sole user message.
Discovery supplies evidence and identifiers, never authority. The installed SDK
can checkpoint and resume this prelude under the original task/root. Frozen read
and analysis profiles retain their goal-before-tools rule. Selecting a newer local
engineering definition affects future admission and preserves existing roots,
deadlines, accounting and accepted-command replay.

The separately selected `agent-chart-analysis-journey/1` profile extends that same
discovery and exact-compute path with source-bound categorical bars and calendar
time-series lines. Accepted planner metadata selects a metric, dimension and unit;
it cannot supply chart amounts or executable content. Every plotted decimal retains
its exact derived row, source version, coverage and missing-value status. The owned
`agentic-os.charts/0.9.1` catalog adds fixed React/SVG rendering and accessible exact
tables. Clients without that registered catalog receive an explicit chart fallback
with the same exact tables and source inspection. Current authorization applies on
every view and source action, including History/reload. This bounded profile retains
the existing summary/source-page limits.

The additive `agent-paged-analysis-journey/1` profile presents larger exact results
through the same conversation and source dialog. Its immutable manifest indexes
bounded16-row private output pages; one accounted computation reuses the original
numerical operator. Missing output requires reconciliation, never free repeated
computation. Accepted query references keep raw source rows out of model context
without losing snapshot, cursor or causal bindings. Signed navigation binds the
owner, task, surface, result manifest and current visibility. Every page rechecks
current source authority. Saved execution inputs use this same observation lane,
with live original-root fences before and after; they grant no dispatch right.
The dialog switches metrics, missing populations and
original sources, and supports previous/next pages. Charts explicitly cover only
the displayed page; exact tables preserve full precision. Empty results remain
distinct from zero. Existing profiles, admitted roots and database limits retain
their original semantics. This is an explicitly selected engineering profile;
production, live-inference and complete recovery qualification remain separate.

The separately selected `agent-planned-analysis-journey/1` profile adds an
authoritative read/compute/join plan to this same path. It reuses the installed
SDK's parallel tool callbacks, dynamic instructions and supported checkpoints;
Temporal retains the original task and continuation. The kernel binds each
actual tool/compute operation to its current plan node before begin. Plan indexes
hold no resource balance and cannot authorize Host access. Patches may replace
or cancel only unbound, unstarted work; they preserve the immutable goal and
accepted branches. Identical simultaneous query bindings are rejected before
acceptance; explicit sequential repetitions remain distinct operations. Bounded
patches and paged dependency sets do not impose a total task-node count limit.

The conversation shows static, kernel-owned step labels and actual states through
the optional owner-scoped `/os/ui/tasks/{taskId}/plan` view. Its16-row pages bind
current plan, projection and visibility; changed authority clears stale views.
Private plan declarations and SDK controls stay in encrypted artifacts/history.
Terminal completion uses the existing closed read control, requiring no new
private history storage after publication closes the original root.
The SDK obtains fresh eligible work before every model decision. Complete query
chains, one accounted exact computation and an exhaustive accepted join are
required before publication. Lost acknowledgements observe the original facts;
missing output requires reconciliation. This engineering profile covers governed
query branches and the existing exact operator. Intent amendments, arbitrary
capability kinds, delegation, full long-task recovery and production/API/AWS
qualification retain their separate gates. Default startup remains health-only.
The explicit local planned fixture registers a20-second read window and15-second
MCP window within its existing30-second per-request reserve. This accommodates
measured repeated current-scope checks on the local verification environment;
it changes no SQL limit, resource ceiling or original task horizon. The legacy
read profiles retain their five-second windows. Latency qualification remains open.

The same local planned journey accepts six governed query instances in three
dependent waves of one, two and three reads after unknown-ID discovery. It
publishes six exact period datasets, including an explicitly empty month, with
eight verified plan steps, inspectable sources and persistent History. The actual
installed SDK/Temporal/WP service, browser, reload, mobile and current-access
withdrawal checks pass with synthetic inference. Arbitrary result rebinding,
other join policies, delegated children and full production acceptance remain open.

An unfinished planned query remains eligible after an accepted partial page.
The worker receives the accepted next cursor and completes the same read node
before exact computation and the exhaustive join can proceed. Started compute
or join nodes, unrelated tools and accepted/cancelled reads stay ineligible.
The local installed-worker/browser journey verifies two complete Host pages,
exact USD property totals of1500.00 and1600.00, all seven source rows across four
bills, three verified steps, History/reload and current-access clearing. Existing
SQL authority, cursor/snapshot, replay and original-root guards remain unchanged;
this scoped synthetic acceptance requires no schema revision.

Production conversation snapshots derive versioned `execution/1` guidance from
durable model-finish and accounting metadata. Confirmed configuration rejection,
known provider waits and unknown completion remain distinct. Guidance contains
fixed safe text, preserves the question and accepted work, and grants no retry,
refund, lease extension or completion. Unknown usage stays held through Stop and
reconciliation. Current-owner reload and registration withdrawal remain enforced;
raw provider errors and private source values are never used as guidance text.
Idle private task views recheck current identity through the existing FrameSession
every 15 seconds, serially within its existing request budget. Current denial or
changed identity continuity clears the private view; cleanup cancels observation.
This does not renew a task or repeat SDK/Host work. The local installed-worker and
browser outcomes cover known configuration failure and unknown provider completion
after an accepted read, History/reload, mobile and current-access clearing. The
existing closed-answer denial journey and independent package also pass. Inference
is synthetic; the complete input/resource/review/native and long-task fault matrix
and production/API/AWS qualification remain separate.

Trusted runtime configuration may select a finite `activity_timeout_ms` for the
enclosing Temporal boundary, separately from request resources. It must cover at
least the admitted request window; omitted configuration preserves that original
value. The local six-query iteration profile selects45seconds because observed
25.7-second Core calls plus private codec/current-source validation exceeded an
enclosing30-second Activity. This observation window grants no longer Host/HTTP,
operation/storage/acceptance lease, resource ceiling, session or original Root
deadline. On lost tool Activity acknowledgement, the selected read worker retains
its accepted parent model as a reconciliation hint. A current running or replacement
worker can resume only after the controller verifies accepted original work and
zero outstanding holds; replay still rechecks current access and the same tool
identities. UNKNOWN work stays held. Frozen histories retain their prior branch.
For an uncertain final-completion acknowledgement, a version-patched read/analysis
worker first reobserves the same candidate once through the existing completion
route. A known publication can finish Temporal after Root closure without another
model, tool, computation or private output. Further uncertainty keeps the original
reconciliation wait; Stop, expiry and current-source authorization remain enforced.
The conversation controller and outbox dispatcher manage only applications
explicitly selected for that runtime. Other installed applications retain their
own queued work, workers and reconciliation holds. This placement selection does
not authorize execution; every original admission and current-access fence remains.
New assigned read workflows also select the finite enclosing policy for Temporal
workflow-task observation, capped at120seconds and the original remaining execution
window. This covers private decoding/current-source I/O that exceeded Temporal's
default10seconds. Existing workflow histories keep their recorded settings. The
local six-query qualification's machine token covers setup and verification for
ten minutes, within the existing pinned workload verifier limit; the owner session
and original300-second task authority remain independently enforced.

The explicit `agent-extrema-comparison-journey/1` profile extends the same
planned comparison executor with minimum ranking and current/base ratios.
Minimum compares unrounded values within each unit partition and preserves every
tie. Ratio operands remain unranked sum metrics with matching complete group keys;
ratios divide by the signed base and round once at the requested output scale.
Missing periods, missing measurements and zero denominators remain inspectable
undefined rows. Source totals are explanatory rounded values, never arithmetic
inputs. The existing source/result portal, private storage and original resource
root remain authoritative. Its versioned operator and additive control0089 keep
older goal/operator semantics intact. Protected runtime, rollback/forward/catalog
and independent0088 recovery pass. Actual installed SDK/Temporal/WP service,
source/result browser and independent Core/worker packages pass locally with
synthetic inference: minimum600USD, ratio1.6667 and an explicit missing period.
Original deadlines/accounting and current source access remain enforced. Broader
derived privacy/lifecycle and production qualification are recorded separately.

The explicit `agent-comparison-journey/1` profile reuses this planned SDK/Temporal
journey, original compute/storage journals and conversation. Harness revision2
binds its digest to the reviewed `exact-period-comparison/1` operator. Immutable
comparison goals select two source sum metrics, complete matching group keys and
one source unit. Difference is current minus base; percentage change divides that
exact difference by the signed base and multiplies by100. Source sums remain exact
until final half-even output rounding. Rounded display values are explanatory.
This version requires sum/all metrics without latest/conversion; other combinations
fail prerequisite validation. Full outer group coverage retains missing periods,
unavailable measurements and zero percentage baselines as inspectable undefined
rows with reasons. Derived comparisons, source metrics, charts and original inputs
share the existing result portal and current-access checks. Additive control0073
preserves revision1 plan/goal/operator semantics and the original resource root.
Its protected runtime/catalog/rollback/forward/independent0072 recovery passes;
the actual installed SDK/Temporal/WP service and browser accept exact+400USD
and+66.67percent for the matching property, explicit missing-period results,
source inspection, History/reload, mobile and current-access clearing. Independent
wheel/HTTP startup also passes. Inference is synthetic; complete task, real API,
AWS and release qualification remain separate. Default startup stays health-only.

The explicit `agent-owner-input-journey/1` profile handles a missing record ID
before binding its read goal. The SDK asks without dispatching a Host read; the
current owner replies through the conversation, and accepted private input resumes
the same task, root and open segment. Command replay recovers a lost reply
acknowledgment, including after completion. Neither a reply nor a fresh UI session
renews execution authority. Control0074 binds the immutable owner command to its
settled encrypted payload and fences work during the wait. Protected migration
and recovery, actual installed SDK/Temporal sourced completion, and the browser
question/reply/History/mobile/current-denial path pass with synthetic inference.
This profile supports one pre-goal record selection; material intent amendments,
other input types and the complete wait/recovery matrix remain separate gates.

With grouped resource admission, a pending owner question can also wait for
private-history storage. A grant wakes only its exact history write; model/tool
admission stays blocked until the accepted reply. Reply-storage exhaustion returns
the safe capacity error and refreshes the conversation's resource controls while
retaining the original reply command. Finite grant and reply acknowledgment
recovery use the existing journals, original root and unchanged deadline.

The explicit `agent-reviewed-change-journey/1` engineering profile extends the
same conversation with one exact typed Host preparation. Preparation grants no
write authority. The installed SDK saves a durable review phase; the owner opens
the separate trusted review window, checks the application-normalized diff and
confirms through the independently configured assurance service. Original
decision replay recovers a lost acknowledgment. Control0076 binds the immutable
preparation, current owner decision and effect attempt to the original production
root; its applied bytes are frozen. The existing reviewed executor, private
provider permit and receipt observer own execution and recovery. A verified
COMMITTED receipt with settled usage can complete the request and persist its
receipt in History. A committed change with UNKNOWN usage remains reconciling;
Stop, replacement and minimal late receipt observation cannot repeat the write
or release that hold. Current authorization fences private review/history data.
Control0077 also retains a late contradictory receipt after completion by
quarantining the original root and task. That atomic transition cannot reopen
the root or change accounting; deferred guards require the retained anomaly.
Control0078 dispatches planned-analysis completion checks only to their admitted
profile, preserving legacy reviewed completion when no production harness exists.
All planned-node, final-result and settled-verification requirements remain intact.
This profile requires explicit local synthetic assurance and registered Host
guarantees. Default startup, production identity, actual inference and AWS
qualification retain their separate acceptance gates.

The separately selected `agent-sdk-serialized-reviewed-change/1` harness uses
this same reviewed journey and executor. Control0080 requires a registered
conflict policy at admission, pinned to the preparation, capability and provider.
Its record-key profile serializes the same installation/application/tenant/
provider record across owners and versions. The registered provider identity
must be canonical, and preparation must list the complete affected record scope;
this profile does not infer parent/group conflicts or aliases between providers.
Waiting records hold metadata without reserving an effect attempt. Once keys and
resources are available, the existing original-root work attempt owns dispatch.
Current approval, source versions and Host authorization are checked again.
A stale queued approval reports that its change was not sent and requires a
fresh request/review. An authoritative persisted terminal receipt releases the
business key independently of usage reconciliation. Started keys have no TTL;
Stop cancels only unstarted work, preserving UNKNOWN work and its held keys.
Protected migration/recovery, affected Python/Node services, installed SDK/Temporal
queue replacement and the trusted persistent browser pass locally with synthetic
inference. The browser shows the live queue, preserves exact approval/ACK replay,
and restores the specific not-sent outcome through History and mobile layout.
Independent installation and full task/API/AWS/release qualification have their
own acceptance gates; default startup enables no new lane.

The explicitly selected `agent-child-read-journey/1` profile delegates focused
reads to separate SDK Agent contexts inside the original Temporal task. An
operator-pinned policy maps reviewed ID/field selectors to current read lanes.
The kernel narrows every child from the accepted parent goal and binds its
model/tool operations, encrypted checkpoints and verification to the original
root and deadline. Active capacity bounds simultaneous work, not lifetime child
count. A child receives its own selector and accepted results; parent messages,
sibling history and protected knowledge are not copied into that context.
The parent can publish only after every required child and causal source passes
current authorization and server verification. Stop interrupts active child
metadata while preserving completed work and UNKNOWN accounting. Control0079
adds scope/lifecycle/graph indexes over the existing journals, without another
task or balance. This selected-record profile uses the existing finite answer
wire; larger public results require a paged presentation rather than truncation.
The private child controls and local synthetic profile enable no default or
production lane; complete deployment and acceptance gates remain separate.

The explicit `agent-reference-child-read-journey/1` variant performs literal
selected-field reads with accepted result, resource-version and field references
in the SDK context. Source values remain in the existing metered encrypted
artifacts. The server reconstructs every tool-result context from currently
authorized accepted evidence, verifies the selected fields and publishes their
exact values and inspectable sources in the same conversation. This avoids
copying large values into model continuations; it does not provide content
analysis, multi-window compaction or a larger public answer format. Both child
profiles share the same policy, journals, checkpoints, original root and frozen
control0079 schema.

The explicit `agent-parallel-child-read-journey/1` profile runs independent
focused SDK contexts concurrently inside that same Temporal task. The current
server-pinned child policy supplies active capacity; transport pages bound each
batch without imposing a lifetime child count. Each child keeps its own SDK
checkpoint and continuation. Every branch call settles before a shared wait or
history rollover, and the parent joins only after all required children pass
current verification. Worker replacement reuses accepted operations and child
completion; Stop preserves uncertain original-root usage. This profile does not
enable dynamic goal expansion, any/quorum joins or conflicting writes.

The explicit `agent-source-child-read-journey/1` profile first verifies one
narrow source field containing a JSON identifier set. Core derives the distinct
target selectors from that accepted evidence, preserving identifier spelling,
and runs them through the existing bounded parallel child executor. The worker
does not receive discovered IDs in its initial configuration. Source values
grant no authority: source and target evidence must still pass current Host
checks. Immutable metered private records link the original accepted intent,
source child/candidate and derived goal, using frozen control0079. Completion
requires every target and the causal source proof; an empty source produces an
explicit no-targets answer with its source evidence. Parent tools remain
disabled, and the original root/deadline, SDK contexts, checkpoints and journals
remain shared with the other child profiles. Literal fields use the existing
metered paged-result storage and bounded table; its result/source inspector
exposes all selected fields and actual input pages without expanding the public
answer wire. Coverage describes the accepted identifier set rather than the
entire Host population. Computed fan-out reduction and other join policies
retain their separate acceptance gates.

The explicit `agent-source-child-reduction-journey/1` variant binds typed exact
metrics to that accepted source intent. Scoped children retrieve numeric fields;
the existing metered exact engine computes sums, means, maxima, grouping and
ranking without model arithmetic. Identity/grain, units, filters and missing-data
policy are immutable goal parameters. Missing measurements remain separate from
zero, with available/eligible counts and an inspectable missing-record dataset.
The same result/source inspector serves bounded computed pages and every original
input. Current source/version/owner authority is rechecked for derived reuse and
publication. This additive profile shares the original Root, worker and compute
journals; its local acceptance and production qualification are recorded separately.

The explicit `agent-parallel-source-child-reduction-journey/1` profile places
independent accepted metrics in bounded concurrent compute batches. Each metric
keeps its own parameter-bound operation and archived output. A checked exhaustive
join binds their private output references and publishes exact values through the
same conversation and result/source inspector. Started siblings settle before a
shared failure or resource wait is returned; settled incomplete output requires
reconciliation and cannot trigger repeated computation. Placement grants no new
authority or budget and preserves the original Root and deadline. Local service,
browser and package acceptance remain separate from production qualification.

The explicit `agent-source-child-join-journey/1` profile binds an all, any or
minimum-quorum policy to the accepted source-driven objective. Eligible source
selectors grant no read permission. Each attempted child still needs current
scoped authority, and all started branches must settle before publication.
The answer distinguishes observed and unattempted records; a subset cannot
certify an exhaustive objective. An impossible policy produces a grounded gap
and failed task with no repeated model loop. The original Root closes only
without outstanding work or usage holds. Results and original sources use the
same inspector, including for an accepted non-success outcome. Default startup
and production activation remain unchanged.

The explicit `agent-paged-source-child-join-journey/1` profile extends that same
executor with linked private goal pages. The accepted intent freezes the page
width; each child binds the sealed whole goal, and completion checks every page.
Tail writes use existing original-root storage accounting and retain their exact
identity through acknowledgement loss. A missing, substituted or cyclic tail
cannot produce a successful result. Transport page width does not grant more
active children or define a lifetime fan-out allowance. The source input still
uses the declared JSON identifier field profile; larger query/artifact ingestion
requires its separately qualified adapter.

The explicit `agent-query-source-child-join-journey/1` profile composes the
existing governed query lane, exact arithmetic and narrowed child executor.
The initial accepted intent declares the queries, metrics, identity column,
target read and join policy. Stable complete query pages feed a separately
pinned chart-free summary artifact; every artifact page contributes selectors
to sealed private goal pages. Source data never grants target authority.
Missing selected-metric measurements produce a specific non-success outcome
with no target admission, rather than a successful empty all-join. Both source
calculations and child fields remain inspectable with all original inputs.
The bounded intent carries up to31 metrics plus its final join in the existing
manifest envelope; this does not impose a lifetime model/tool/child limit.
The256-character identifier, private-message, active-child and original-root
limits remain unchanged. Source refresh requires new accounted work; it cannot
rewrite an accepted intent or renew the original deadline. Local qualification,
real inference and AWS qualification remain separate.

The explicit `focused-child-reads/1` revision4 observation policy preserves the
existing single-part source/query intent wire. Its full implementation pin
permits current goal, answer and original-question History observation from the
accepted immutable planner after admission-capture expiry. Current derived-goal,
source-generation, owner and private-payload retention checks still apply.
Erasing the original intent withholds those views; observation grants no new
execution, deadline or resource allowance. Revision3 and legacy capture-bound
profiles keep their existing wire and semantics.

`VerifiedRetainedLogicalQueryJoins` selects a separate full implementation pin
within the existing revision3 wire. Observation validates every sealed part and
current query scope, then uses the original accepted first-planner input for
History after capture expiry. A missing or erased part withholds the entire
objective, derived result and question. The registered pin must match exactly;
legacy revision3 selection and new execution's original capture checks remain.

Compatible observer updates retain the two exact qualified source/linked pins
recorded in `goal_observation_compatibility.py`, alongside each current pin.
Saved contexts remain immutable; current owner/source/generation/private-expiry
checks still apply. Unknown digests are rejected. This bounded observation
compatibility does not qualify a complete binary upgrade or deployment.

The explicitly registered `focused-child-reads/1` revision3 selects
`VerifiedLogicalQueryJoins` over that same journey. Accepted bounded objective
parts link through existing private intent records; only a complete validated
chain seals the executable objective. The worker carries a small receipt/index
and requests bounded current query descriptors from Core. Core derives progress
from all retained current fact pages, rather than a cumulative worker key list.
An unchanged, freshly verified fact head is reused. A pending SDK checkpoint
retains only its bounded descriptor window in the encrypted journey; Core checks
current query scope before loading that checkpoint, and tool dispatch still
requires fresh authority. This reuse changes no original lease or deadline.
Every original metric remains in the sealed chain and is checked before the
composite metric-set seal can verify. Results retain the selection metric and a
paged “All declared exact metric results” table with view numbers, labels, exact
values, coverage and missing identities. Empty views remain explicit. Neither
the bounded proposal, descriptor window nor manifest determines a task-wide
query/metric limit. Exact stored-part receipts can be observed after Stop or
closure with current read-only authority; they grant no new execution or lease.
Legacy revisions and their operator pins remain unchanged. This profile uses
the same core, PostgreSQL guards, SDK/Temporal worker and deployment adapters;
it adds no persisted schema or separate local/cloud execution architecture.

New histories in this source profile use a scoped private query-context window.
A supported SDK tool round
finishes before a fresh context retains its accepted causal result heads and
exact query frontiers. Raw rows and the growing transcript stay outside that
context. Pending approvals retain the supported private RunState; an incomplete
candidate retains the bounded navigation and its new accepted head. Temporal
continuation and worker replacement keep the same objective, Root and deadline.
Navigation notes never replace current source authorization or completion checks.
Each frontier binds immutable query keys and its exact capability tool alias;
identical arguments/digests on different capabilities keep separate cursors.
Large accepted result heads use existing metered private input-result indexes.
Versioned workflow patches and the saved private format preserve earlier v1
windows and original SDK continuations across rollover. No task-wide query or
iteration ceiling is introduced. The bounded answer previews the child fields
and first metric; every metric remains inspectable through the persistent
results selector with all original inputs and current authorization.

The v3 query window keeps immutable current query facts in metered private
pages. Before a fresh query model turn, it discards every page of a changed
query snapshot, keeps unrelated current facts and restarts the affected query
as new accounted operations under the original Root and deadline. The immutable
intent is preserved.

New v3 histories can also refresh a source after its selector and child goal
are bound. A fresh, privately verified generation selects current targets;
earlier goals, results and usage remain immutable. The original Root and
deadline cover the new queries, calculations and child work. Superseded child
scopes cannot start new work. Running or uncertain usage retains its original
holds, and superseded active children retire only after accounting is known.
Current completion and source display use the current generation and fresh
authorization. Before approving a saved v3 query-tool checkpoint, the worker
checks current-only recovery metadata. Changed queries restart from fresh
accounted reads; unrelated facts and the accepted model's next-operation
identity are retained. Obsolete SDK prompts are withheld, scope withdrawal
denies recovery, and unresolved usage prevents replacement. Other pending
child calls retain their original reconciliation and acceptance gates.
At a completed v3 query round, a source change during the next provider request
also uses current-only recovery metadata. Core advances to a new semantic model
operation only after the obsolete, unaccepted return and both archives have
settled. It keeps unrelated current facts and all earlier operation/accounting
records, without returning obsolete model bytes. RUNNING/UNKNOWN holds prevent
replacement; accepted or already advanced steps cannot be rewound. The installed
worker can recover after physical replacement at the known-return boundary on
the same original Root and deadline. This private metadata extension introduces
no persisted type, migration, replacement executor or new resource balance.
Control revision0082 requires the pinned PostgreSQL profile's trusted pgcrypto1.3
extension for deterministic generation identities. Its metadata, ownership and
application guard catalog are checked during protected migration qualification.

An explicit local synthetic native-analysis extension uses the same query/source
journey and original production Root. Operator configuration supplies an immutable
`AgentNativeAnalysisToolProfile` and an `AnalysisSandbox` port through
`enable_agent_read_runtime(native_analysis_profile=..., analysis_sandbox=...)`.
The harness must declare native execution; capability registration, current Host
review, accepted SDK arguments and SQL reservation/begin remain required. A
source or model proposal grants no execution authority. Default startup enables
no native lane. Applied control0083 is immutable after protected populated runtime,
rollback/forward/catalog and independent0082 recovery. Actual local Core guest,
accepted replay, Stop/accounting, physical cleanup, installed SDK/Temporal four-child
completion, persistent desktop/current sources/authorization and independent packages
pass. Inference is synthetic; complete native recovery/lifecycle and production
qualification remain separate gates.

The private workload application can be assembled with `role="native"` to serve
only the existing `execute-native` action, or `role="core"` for its remaining
model, state and source-observation actions. The default `combined` role preserves
the local worker path. Deployment routing can direct the existing native URL to
the sandbox-capable EKS role while preserving the worker protocol and original
SQL admission, current authority, reservations and deadlines. Disallowed actions
are rejected before credentials, request bodies or dispatch are used. Role
selection neither enables a native profile nor substitutes for workload identity,
AWS configuration or deployment qualification. Normal public startup exposes
none of these private workload routes.

`IdentityRuntime(..., installation_ports=...)` accepts an explicit trusted
`InstallationPorts` bundle for the PostgreSQL connection, transaction/recovery
guard, installation operator, application-scoped Host credentials and encrypted
private artifacts. A borrowed `ControlStore` must use that exact bundle and
manifest; the registry and admission services share it. Short SQL limits,
current authority, original accounting and verification before commit remain
inside the existing services. These dependencies grant no Host or task authority.
`owned_installation_ports(manifest)` delegates to the existing owned local target,
operator, credential files, encryption keys and recovery guard. Omitting the
bundle preserves the original local construction. Neither construction creates
keys, migrates a database or provisions a deployment. This composition seam is
not qualification of concrete cloud adapters or production recovery.

Optional `ComponentPorts` bind the same installation's retrieval, private KB,
public metadata and operator-publication connections, protected KB keys and
pinned offline embedding client. Memory and knowledge services consume these
factories through the registry's installation bundle. Configured installations
without component adapters return `PROFILE_DISABLED` when those lanes are
selected; they never fall back to local Docker credentials. Local composition
delegates to the original owned stores. Pools retain their4connection component
and2connection public bounds, short SQL limits and recovery verification before
commit. Embedding and owner decisions remain outside SQL transactions.

### Selected production harness and capability support

The selected harness is the independently packaged OpenAI Agents SDK worker over
Temporal and the shared Core. The table describes explicitly registered, exact
version/digest profiles, not permissions granted by a model or by this document.
Core checks the current catalog, owner, operation, causal sources and original
resource root at dispatch, replay, resume and publication. Missing registered
adapters report their specific unavailable guarantee; there is no generic tool
fallback. Each row has cumulative local synthetic Core, installed SDK/Temporal,
persistent user-journey and independent-package evidence in the selected production
implementation register. Actual provider and deployment qualification is separate.

| Harness family / journey | Callable capability boundary | Supported behavior and limits |
| --- | --- | --- |
| Governed reads, discovery, partial evidence and focused child/source/query joins | `mcp.read/1`, `os.capabilities.discover/1` | Current scoped Host reads, paged catalog/results, retained facts, explicit partial/blocker outcomes, governed child fan-out and current-source refresh. Metadata and child output grant no authority. |
| Exact, adaptive, chart, paged, planned, comparison and clarified analysis | Governed reads plus Core's registered compute journal | Exact derived outcomes use accepted current inputs, finite original compute reservations and checked public consumers. Owner clarification uses the original durable task; no arbitrary Python or unregistered operator. |
| Reviewed change | `typed.prepare/1` proposal lane and existing trusted review/Host effect service | Exact input/version/intent/owner/operation approval, OCC/idempotency and authoritative receipts. Changed input requires new approval; known applied effects survive later failure/Stop and UNKNOWN stays held. |
| Approved owner memory (`memory-assisted-read/…`) | `owner.memory.read/1` | Explicit current learning/recall consent, canonical revision hydration and source inspection. Ranking is non-exhaustive and grants no authority. Recall enables no privileged learning. |
| Protected planner guidance (`private-planned-read/…`) | `private.knowledge.read/1` | Separate planner credentials/context, encrypted KB passages and fresh public synthesis. Public metadata cannot read protected chunks; retirement/forgetting rechecks current eligibility. |
| Reviewed schedules/events (`reviewed-proactivity/…`) | `os.proactivity.prepare/1` and separate trusted activation | Preparation is inactive. Owner review binds exact configuration; future firings have separately qualified finite delegation/budgets, never borrowed interactive credentials. No implicit recurring work. |
| Registered native offline analysis | `native.offline-analysis/1` through its separate native facade | Exact source-bound program/inputs use the original Root/controller lease. Known completion/replay/Stop/cleanup is distinct from UNKNOWN usage. Local Darwin ARM64 and Linux ARM64 nested-KVM evidence does not qualify AWS/amd64 containment. |

Profiles do not automatically combine all rows. Admission binds each exact
capability set, harness, SDK checkpoint format and configured lane. Private
planner/public synthesis and selected child profiles preserve their separate
boundaries. The worker rejects unknown starts, pins and unsupported provider
continuations. Full Claude Agent SDK is not selected; Anthropic qualification is
owner-deferred. No selected profile depends on personal desktop login. Provider-
hosted tools and unqualified built-ins remain disabled.

In the configured reviewed-change service, a serialized application also supplies
`write_conflict_policy`, an exact `AgentVersionPin` for its registered business-record
conflict policy. Its selected harness must be `agent-sdk-serialized-reviewed-change/1`;
the original single-change harness cannot select this field, and a serialized
harness cannot omit it. Current operator selection checks the policy against the
selected harness before admission. The original Root then retains its immutable
policy, resource keys, finite accounting and authoritative receipt requirements.
OIDC step-up uses the same exact-command review and execution path. A waiting
operation obtains no effect reservation, and after the earlier change completes
its current record version and approval must still pass before dispatch. An
interactive OIDC ceremony supplies no future background or repair authorization;
those profiles require their separately selected and qualified authority paths.

For separately approved repair, the configured OIDC review may explicitly supply
`review.repair_policy` with `origin`, `network`, `credential_ref`, `revision: 11`
and the exact `bundle_digest`. Select the registered repairable harness, without
`write_conflict_policy`. The inverse uses a new owner confirmation, decision and
invocation, retaining the original Root's remaining repair allowance and deadline.
The original receipt remains committed. Local policy HTTP requires the owned-local
profile; AWS policy transport requires the reviewed HTTPS endpoint.

Configured proactive or reusable-tool journeys may select
`activation: {kind: "oidc-step-up", provider: <AgentVersionPin>}`. Owner review
authenticates the exact configuration revision and command through the existing
OIDC service. Lost acknowledgement retries the original command. Future runs still
need separate finite delegation and current authority. Embedded activation requires
the Host's explicit `allowReviewPopups` placement option; the default denies popups.
Protected revision0095, installed service, affected browser and current independent
Core acceptance pass locally with a synthetic issuer and inference. Actual identity,
AWS/Cloud and full lifecycle qualification remain separate.

| Backend profile | Engineering / local evidence | Separate remaining qualification |
| --- | --- | --- |
| Explicit local | Local server, independently owned PostgreSQL, pinned offline embedding/sandbox, login-token identity, scheduler and local Temporal share Core/contracts. Accepted lane/UI/worker evidence is retained by exact affected boundary. | Complete system/fault/release gates and authorized live-provider qualification. No AWS or Temporal Cloud credential is required. |
| Configured AWS | Scoped control/component PostgreSQL, Secrets Manager, projected workload identity, configured public service and dispatch, initial bootstrap, embedding/memory/KB, native/SDK placement, scheduler and supported Cloud recovery/retention compose over the same Core. Locked role packaging/configuration has scoped local acceptance. | Current complete profile/conformance/release acceptance and actual AWS/Temporal Cloud identity, storage, network, containment, retention and outage qualification. Independent artifact or local acceptance does not establish deployment readiness; production activation remains blocked. |

For the EKS private roles, `TokenReviewWorkload` implements the existing async
workload verifier with Kubernetes `authentication.k8s.io/v1` TokenReview. Configure
one exact HTTPS API origin, its trusted CA context, a private service audience,
and server-owned `ServiceAccountAssignment` entries keyed by full service-account
username and immutable account UID. Every request obtains a current reviewer
credential and performs a bounded live review; successful reviews are not cached.
The response must confirm the private audience, exact account UID and a Pod-bound
identity. Groups and caller claims do not select application/model/meter authority.
Review failure/outage prevents dispatch and accepted-result disclosure. Original
admission, current Host scope, leases, Root/deadline and accounting still apply.

The independently installed worker's `ProjectedWorkloadToken(root)` supplies the
existing `RPCModelBoundary` token callback. Mount the projected volume read-only;
the reader follows only rotating links contained in that explicitly configured
mount and rejects mutable, oversized, special or escaping files. It rereads on
every RPC without retrying a command or extending its grant. The same callback
can supply the service's Kubernetes-review credential; use its separate API
audience, never the private worker token. Construct the TLS context with the
projected cluster CA and retain hostname verification.

`workload_identity(installation_id, namespace, accounts)` returns standard
Kubernetes ServiceAccount/RBAC resources and Pod/volume fragments for the distinct
`core`, `native` and `worker` accounts. Only the service roles can create
TokenReviews; the worker receives no Kubernetes API authority. Private and API
credentials use separate projections, 3600-second requested lifetimes and no
automatic default-token mount. Merge the returned read-only container mount and
Pod fragments into the corresponding deployment; pin actual service-account UIDs
after installation. This function creates no cluster resources. Full immutable
images, native node/KVM privileges, networking and backend deployment remain
separate requirements. Bind each installed account to its explicitly configured
application/model/meter; recreation requires reviewed UID configuration.

Kubernetes validates bound-object life through TokenReview. Its documented
deletion grace period still applies; a node claim is not proof that a node remains
valid. Real EKS CA/RBAC/rotation/deletion/outage behavior requires deployment
qualification. See [Kubernetes bound token validation](https://kubernetes.io/docs/reference/access-authn-authz/service-accounts-admin/#verifying-and-inspecting-private-claims),
[audience-aware TokenReview](https://kubernetes.io/docs/reference/kubernetes-api/authentication-resources/token-review-v1/)
and [EKS service accounts](https://docs.aws.amazon.com/eks/latest/userguide/service-accounts.html).

The explicit AWS backend adapters use the locked official Boto3 SDK. Supply its
session/credential source explicitly to `secrets_client`; the default local
runtime performs no AWS discovery or API call. `AWSSecrets` accepts exact regional
commercial-AWS Secrets Manager ARNs and immutable version IDs under the installation
and application/control namespace. `AWSHostCredentials` reads only configured
application references; its registration check cannot create or overwrite secrets.
Rotation requires a newly provisioned immutable reference. `AWSOperator` uses a
separate32-byte control secret and explicit generation. SDK errors and secret
contents are not returned as diagnostics; API retries remain disabled.

`RDSControl` requires the reviewed RDS endpoint, installation-specific control
database/runtime role and private digest-pinned CA. It connects with `verify-full`,
then applies the existing PostgreSQL16.15 privilege checks and the installed schema/
installation prerequisites. Failure closes the connection before pool admission.
This adapter selects password credentials from Secrets Manager; it does not grant
administrative or migration authority. `aws_installation_ports` combines these
dependencies with the existing encrypted filesystem artifacts and keys, suitable
for an explicitly provisioned private filesystem. It creates no keys or storage.
The default `CoordinatedControlRelease` borrows the existing gate-locked, finite
`TransactionRelease` for that exact certified restored installation. It discovers
no targets and creates no certificate. Core rechecks the original release before
SQL commit; expired, parked, foreign or unqualified original installations remain
disabled. Explicit alternative placement guards must still yield a verifiable
release proof. Initial preparation, component backends and configured public
startup use the supported paths below. Complete profile/release acceptance and
actual AWS qualification retain their separate gates.

The optional `aws.stores` object in installation configuration supplies all four
connections: `retrieval`, `knowledge`, `knowledge_public`, and
`knowledge_operator`. Each has the same explicit endpoint, CA digest and immutable
password-pin fields as `aws.postgres`. It is available only to the Core role;
omitting it keeps optional lanes disabled. `RDSComponent` requires separate
installation/component-scoped secret references, databases named
`aos_<installation UUID hex>_retrieval` or `aos_<installation UUID hex>_knowledge`,
and the corresponding `_r`, `_r_public`, or `_m` role. TLS and non-administrative
role checks apply to every physical connection. Private roles additionally check
the installed store revision, exact installation registry and pinned pgvector
extension; the public role retains the existing read-only metadata-only privilege
attestation and cannot select private chunks or revisions. Reviewed publication
uses its separate operator credential and the same finite recovery guard. The
existing signed protected-key binding and pinned local Unix-socket embedding
service must already be prepared; runtime startup creates neither. Local service
acceptance and SDK contract checks do not qualify live RDS/IAM or a complete AWS
deployment. Current profile/package acceptance and actual Cloud, RDS/IAM and
embedding-service placement qualification retain their separate gates.
See [Secrets Manager version reads](https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html)
and [RDS PostgreSQL TLS](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/PostgreSQL.Concepts.General.SSL.html).

Fresh AWS file identity preparation uses an explicit new private directory:

```sh
agentic-os aws-root-prepare --root /private/owned/new-installation
agentic-os aws-root-claim --manifest /private/owned/new-installation/manifest.json \
  --operator-key /private/owned/new-installation/operator-bootstrap.key
```

These commands use the existing signed ownership, private encryption and one-use
30-minute operator bootstrap. They report file references, never credentials.
The closed version2 `aws-eks/1` manifest carries no Docker endpoint, local database
roles or SQL passwords. Existing directories and ambiguous paths are refused.
Claiming creates an installation file-operator credential, not Host-user authority.
The installation remains PARKED with no enabled lanes. Even a missing gate or
a manually signed READY gate cannot grant runtime through the legacy local or
restoration path. Interrupted preparation preserves its files and cannot silently
adopt or replace that identity. Initial PostgreSQL/schema, storage, Cloud-history
and service readiness remain separate required engineering/acceptance gates;
preparation makes no AWS request and does not activate a deployable profile.

Initial OS schema preparation uses `aws-storage-plan`, `aws-storage-prepare` and
`aws-storage-check`, each with the exact owned `--manifest`, private operator
`--operator-key` and private JSON `--command-file`. Execution additionally
requires the current parked `--expected-generation`. The closed command schema
`aws-initial-store-preparation/1` contains `installation` (the existing complete
`agent-installation-configuration/1` AWS Core document), `migrators` (separate
immutable secret ARN/version pins for control, retrieval and knowledge), and
`expected_heads` for those same stores. A null expected head permits only an
empty isolated schema. An exact installed head permits catalog verification;
old/mismatched/populated schemas cannot be upgraded or silently adopted here.

Planning validates all role/namespace/CA and credential handoffs before SDK
setup and renders the distinct storage role's exact immutable secret reads.

For a currently released configured installation, `memory-recovery-init` and
`memory-controls-init` accept
that same storage `--command-file` with all three exact installed heads and the
current READY `--expected-generation`. Supply the existing manifest, private
operator key, application ID, surviving journal root and capacity root. The
scoped storage role verifies the control catalog. Initialize deletion first with
`memory-recovery-init`, which delegates to the unchanged canonical deletion
genesis and runtime grants; then initialize consent with `memory-controls-init`,
whose separate migrator alone can insert consent-profile pins. Runtime
credentials retain no permission to insert or change consent pins. Both the
journal root and its capacity root must use the surviving journal volume,
separate from the installation restore volume. Shared deletion/consent journals retain current
operator and release checks through SQL commit; failed commits preserve orphan
material and never adopt it on retry. The local command remains available
without a configuration file; AWS installations refuse that fallback. These operations create no AWS resources, migrate
no schema and activates no runtime lane.

The finite direct POC uses explicit Core installation
`aws.control_profile: "poc-direct-control/1"` with the complete RDSExact stores.
Its operator command is `poc-direct-initial-ready`, with the same manifest,
operator key and parked generation1 arguments as `aws-initial-ready`. Its closed
`poc-direct-initial-readiness/1` command file contains `schema`, `stores` (the
existing exact storage configuration) and `release_seconds` (60–86400). It
checks the same current schemas, separate runtime roles, empty owner/runtime
stores, private keys, code/configuration digests and operator before issuing
the existing signed `aws-initial-ready.json` proof and READY generation2.
It constructs no Temporal or embedding client. No workload or AWS resource is
created and no model call is made. The same transaction proof rechecks expiry,
gate, owner material and installed code through SQL commit.

Selection is explicit: the default Cloud proof rejects a direct POC proof,
and the direct proof cannot authorize Temporal, native or restored execution.
Expiry fails closed. This initial finite campaign profile does not implement
Cloud renewal or managed restore; those paths cannot adopt its proof. Seventeen
focused signed-proof/negative checks and actual configured adapter selection
pass with explicitly doubled AWS service IO. These are engineering checks,
not actual AWS qualification or complete configured runtime acceptance.

The direct operator flow also passes an actual PostgreSQL16.15 TLS rehearsal
with the RDSExact0.8.2 stores: current schema/catalog and separate roles, signed
finite release, both CLI journal geneses, real surviving pins/current consent,
runtime pin-mutation denial and repeat-genesis refusal. AWS identity uses the
official SDK with explicit immutable response stubs; no Temporal/embedding
client, business task or model call is constructed. The first run exposed an
AWS catalog bug that compared RDSExact constraints against legacy metadata.
The checker now selects the matching exact-profile metadata; legacy checks
stay unchanged. The failed aggregate is retained. The focused retry resumes
the same owned cluster and committed control head instead of recreating it;
its actual operator flow passes and stops only that disposable child cluster.
The active VF integration cluster is untouched. The original failure hold and
private fixture/evidence remain retained.

Preparation requires independently provisioned PostgreSQL16.15 TLS databases
and isolated roles with no PUBLIC database/schema grants, plus pgvector0.8.7 on
the two private component stores. It applies the existing packaged migrations,
catalog and protected metadata grants under their original two-second lock and
three-second statement limits. Each component commits independently; after an
interruption, inspect its actual head and explicitly select current-head checks
for completed stores. Never assume a failed command rolled back other stores.
The tool creates no AWS resource, database or role and performs no populated
upgrade. Successful schema verification keeps the installation PARKED; private
files, runtime-role readiness, Cloud history and full profile activation remain
separate gates. Local TLS/PostgreSQL acceptance uses synthetic AWS credentials
and explicit loopback routing; actual RDS/IAM qualification remains required.

The next explicit preparation steps are `aws-files-prepare` and
`aws-embedding-serve`, with the owned `--manifest`, private `--operator-key` and
current `--expected-generation`. File preparation requires initial PARKED
generation1 and a new protected-knowledge directory; it never adopts or replaces
keys. Its signed AWS binding pins the installation, knowledge database and
`planner.read/1` purpose without a local container. The ordinary pinned
`embedding-import` operation supplies the reviewed offline model first. The
AWS embedding command reuses the same private Unix listener and bounded offline
process as the local profile. Requests check current operator/gate state before
and after inference. Restart in READY requires the finite initial control proof;
expired, parked-after-release or blocked state cannot silently grant service.

`aws-initial-ready` takes the same manifest/operator/generation plus a private
`--command-file`. Its closed `aws-initial-readiness/1` document contains `stores`
(the complete current-head store-preparation document), `cloud_configuration`
(the private existing `temporal-cloud-operator/1` file) and integer
`release_seconds` between 60 and 86400. Store and Cloud configurations must select
the exact same installation and original run. Qualification checks current
catalogs/roles, empty stores through their separate table owners, private key
material, an actual offline embedding, and the exact healthy empty Cloud
namespace through supported APIs. Runtime RLS visibility cannot establish
private-store emptiness. SQL sessions close before every Cloud await.

Reviewed private-key rotation uses `aws-key-prepare` and `aws-key-ready`,
`--key-purpose history` or `knowledge`, the exact command file/ID/generation,
and immutable prior/current wheel selections. Both commands require the reviewed
purpose; preparation requires both `--prior-artifact` and `--artifact`, while
Ready selects only `--artifact`. A separately reviewed service credential/TLS
rollover can accompany preparation using `--prior-configuration`.

The material profile authenticates immutable initial key records separately from
the selected current inventory. Preparation stores one atomic private signed
stage inside the existing maintenance operation before Park or live-key mutation.
Only its exact key and selector can be applied. Every original key remains pinned
and readable; the other purpose is unchanged. Current schemas, original work,
Cloud history, current complete code and selected material must pass before
finite publication. Runtime checks the current material through COMMIT. Ordinary
renewal and compatible artifact rollover carry those same keys without another
rotation; ACK retry retains the existing generation/expiry and never mints keys.

The existing envelope permits eight reviewed rotations and at most 128 keys per
purpose. Unsupported readers cannot roll back a material-profile installation;
use supported code or forward recovery. Interrupted staged writes can resume the
same command. Missing/corrupt original or staged material stays unavailable and
Parked for explicit recovery; it is never replaced by newly generated keys.
Take a new independent backup after the accepted generation changes. Operator
identity/token rotation and coordinated remote-store recovery remain separate
qualification gates; this operation does not change original task horizons,
accounting, UNKNOWN holds or default runtime activation.

Reviewed operator credential handoff uses `aws-operator-prepare` with the current
`--operator-key`, a private `--replacement-key`, paired immutable prior/current
artifacts and `--prior-configuration`. Provision the new immutable Secret version
separately, keep its ARN/installation scope unchanged, and advance the selected
operator generation by exactly one. Configuration loading never provisions it.
`aws-operator-ready` accepts the staged new `--operator-key`, current command,
artifact and original parked generation. It does not accept a replacement file.

The existing signed maintenance operation retains original operator state and
stages the reviewed replacement before Park. Only that new credential can finish
the cutover. Verify its immutable remote Secret before replacing local files;
retain the original private credential as digest-bound recovery evidence. An
interrupted key/state/publication write resumes the same handoff. Old credentials
fail after cutover; ordinary renewal retains the accepted credential/generation.
The parked embedding service accepts only the bound staged new operator during
this handoff and uses the selected current release after Ready. Private-history
and knowledge keys, original ownership, work/accounting/deadlines and UNKNOWN
holds remain unchanged. Current-generation key backup/repair stays independent;
lost ownership identity and complete remote-store recovery remain separate gates.

`aws-key-backup` and `aws-key-recover` protect the original private-history and
protected-knowledge keys together using the existing independent AES-GCM/HMAC
backup and exact file-repair boundary. Supply `--manifest`, `--operator-key`,
`--expected-generation`, the **currently released** immutable wheel as
`--artifact`, an external private `--backup` file and a separately protected
`--recovery-key`. Repair also requires one `--command-id`. The operator tool may
be newer than the released Core; the explicit wheel authenticates that release
without authorizing changed runtime code.

Backup requires a current finite Ready release and intact, authenticated live
keys. Repair requires the original ownership/operator records, knowledge binding
and exact unchanged signed control-release snapshot. It validates both decrypted
key inventories against the original material digest before writing either set,
retains differing originals under the existing recovery-key-repair directory,
and restores only original key bytes, selectors and private modes. A lost repair
acknowledgment can retry the same command without generating keys. Wrong
protection, changed authority, unknown files or unsafe links refuse repair.

Take a new independent backup after a release/configuration generation changes.
This operation does not recover a lost ownership/operator identity, rotate keys,
restore SQL stores or replace a coordinated recovery archive. Repair changes no
control certificate, generation, task, balance, UNKNOWN hold or deadline. An
expired release remains expired after successful repair. Keep the recovery key
separate from the encrypted backup and preserve the authenticated installation
metadata required to use it.

Reviewed service credential rollover uses `aws-service-prepare` and
`aws-service-ready` over the same finite maintenance operation. Preparation
requires the selected command file, `--prior-configuration`, immutable
`--prior-artifact` and `--artifact` wheels, the original Ready generation and
one command ID. Ready consumes that exact operation, selected command file and
wheel at its parked generation. Preserve the old configuration and CA files as
immutable ancestry; expired old network credentials are not needed to inspect
that ancestry. Provision replacement service credentials separately before
preparation; these commands never create or rotate AWS secrets or RDS roles.

The service profile permits reviewed secret **versions** and TLS CA files to
change while retaining secret ARNs, installation/root/run, RDS endpoints,
databases/users, workload identity, registered application credentials, operator
generation, Temporal namespace UUID and retention. The new secret version for
the operator must authenticate the same original token. Existing schema guards,
private-key inventory, original SQL work and Cloud-history capture must pass
before finite publication. Ordinary renewal and compatible artifact rollover
retain this selected service configuration. Any failed qualification stays
Parked; the operation never extends original task deadlines or releases UNKNOWN.

This qualifies a control release only. Roll the configured Core and AWS-hosted
Temporal workers with their exact new configuration pins and existing supported
assignment lifecycle. Do not patch an active Kubernetes Job or change its pinned
configuration to adopt it; retain original workflow IDs, task queues and
horizons. Private-history/knowledge key rotation, operator-token rotation,
coordinated remote recovery and actual AWS/Cloud qualification have separate
gates. Local Temporal and local login-token E2E remain independent.

Successful qualification publishes a signed finite initial control proof under
the existing recovery gate. Current initial and ordinary finite profiles use
revision2 with a complete Core package-content digest; initial/finite revision1
records remain authenticated operator migration ancestry only. New code cannot
silently serve those legacy releases. Configured AWS transactions recheck its installation,
configuration, shared release programs, key material, generation and expiry
through COMMIT. Private Temporal connections additionally require its exact
namespace/UUID/retention/CA/run and immutable identity pin. Legacy local/restored
guards still refuse this AWS profile. The result reports `controlReady: true`,
`runtimeReady: false`, no enabled public lanes and no production qualification.
It does not register users/tasks, change balances/deadlines, release UNKNOWN,
rewrite an existing initial certificate, upgrade populated stores or implement
coordinated remote restore. Full profile composition, lifecycle/recovery and
actual AWS/Cloud qualification remain mandatory deployment gates. Local Temporal
and local E2E retain their existing credential-independent profile.

For the same deployed artifact, configuration and keys, `aws-renew-prepare`
and `aws-renew-ready` take that same private document plus `--command-id`.
Preparation requires the exact even READY `--expected-generation` (including
an expired proof), authenticates its immutable ancestry and explicitly Parks
the installation at the next generation. Stop the previous embedding service
and start `aws-embedding-serve` with this exact parked generation before Ready.
Ready requires that parked generation and the original command ID. It checks
current store catalogs and actual read grants, private materials, the offline
model, original Cloud namespace/history and unchanged bounded work checkpoints.
It publishes a new finite control proof at the following generation, retaining
the initial empty-installation proof unchanged. Exact preparation/publication
retries reuse the original operation and do not extend its published expiry.
Failure stays fenced; transactions recheck the selected finite proof through
COMMIT. Renewal never terminates workflows, changes task accounting/deadlines
or releases UNKNOWN. It reports control readiness separately from public runtime
or production qualification. Artifact, configuration, key and credential rollover
and coordinated remote recovery require their separate supported procedures;
these commands reject `--artifact`.

`aws-artifact-prepare` additionally requires private `--prior-artifact` and
`--artifact` wheels, the current even generation and a new command ID. The
operator tool authenticates the prior proof against the reviewed prior wheel,
checks unchanged original contracts/workflow programs and supported lifecycle
readers in the selected wheel, and Parks before deployment. After installing
that exact selected code, start the embedding service at the parked generation
and run `aws-artifact-ready` with the same document, command ID and selected
wheel. The artifact release binds every installed Core package file to the
wheel's content inventory, checking actual bytes through the existing bounded
public scanner before release and through guarded transaction COMMIT.
Restoration compatibility pins remain separate from complete package identity.
Legacy artifact proofs require explicit reviewed operator migration; they cannot
silently authorize the current runtime. Supported rollback follows this same
prior/selected-wheel path. Missing original programs or lifecycle readers reject
before Park; wrong or changed running code remains fenced. This procedure keeps
the same schema heads, keys, configuration, original task deadlines and UNKNOWN
holds. Schema upgrades, credential/key changes and full deployment qualification
retain their separate mandatory gates.

The coordinated source commands `aws-recovery-source-plan`, `aws-recovery-prepare`
and `aws-recovery-seal` use the private configuration
`aws-managed-cloud-recovery-source/1`. Its closed fields are `schema`, `current`
and `prior` complete readiness configurations, the currently released `artifact`
wheel, and `source` (`instance_id`, immutable `resource_id`, `kms_key_arn`,
`engine_version`, `port`). All three OS stores must share the inspected encrypted,
private RDS instance. The existing immutable-secret and scoped recovery-role
boundaries validate the source identity before preparation changes local state.

All commands require the exact manifest, operator key, command file, command ID
and expected generation. Preparation starts at the original even Ready generation;
it also requires an independently placed `--recovery-key`, `--journal-root` and
`--controls-root`. It durably Parks that source, checks the current schemas and
surviving owner floors, and encrypts the existing private files, three-store row
watermarks, original runtime/accounting checkpoint and supported Cloud history
catalog. It returns the exact snapshot identifier and capture tags for a separately
provisioned managed snapshot. The commands create no AWS resources and access no
Cloud persistence database. Ordinary local recovery commands cannot consume this
explicit managed archive.

Sealing requires the recorded odd Park generation and the same independent key.
It inspects the snapshot's immutable source, encryption, private restore attributes,
capture tags and creation time, then rechecks the source rows, privacy floors,
private material and original raw Cloud history prefixes. Exact completed retries
reuse the original key, ciphertext and receipt. Ambiguous partial preparation is
retained and refused for explicit recovery. Source selection remains durable and
Parked. An independently authenticated archive grants neither Ready nor target
restoration qualification: separately provisioned target identity/data, surviving
privacy replay, history/quarantine and current-code release remain required.

`aws-recovery-root-prepare --backup /absolute/sealed/archive --recovery-key
/absolute/independent/key --root /absolute/new/aws-root` prepares new local
ownership for the authenticated original logical installation. It creates no new
history or knowledge keys. Separately provision the restored private RDS target
and its scoped roles, TLS configuration and immutable credentials; these commands
do not provision, restore or migrate a managed database.

The private target configuration `aws-managed-cloud-recovery-target/1` contains
`schema`, complete three-store `stores`, `cloud_configuration`, `target`, `archive`
and `recovery_key`. `target` uses the source's instance/resource/KMS/version/port
field names, with distinct restored instance and resource identities. The target
must retain the source snapshot/capture tags plus `agentic-os.snapshot` naming the
sealed snapshot ARN. All schema heads, source rows and original runtime checkpoint
must match before admission. The archive and independent recovery key must remain
outside the new installation root. Cloud configuration preserves the original
namespace UUID, retention and logical run; current endpoint, CA and credential
pins require explicit operator review. No Temporal Cloud database access is used.
While this new root is still keyless, the existing operator connection permits
only read-only metadata checks at its original Parked/Restoring generation.
It cannot open runtime transactions or component ports, mint a key, or continue
in preparation mode after target admission. Ordinary assembly still requires
the active private keys.

`aws-recovery-target-plan` and `aws-recovery-target-admit` require the exact
`--manifest`, `--operator-key`, `--command-file` and initial
`--expected-generation 1`. Admission authenticates snapshot and restored target
metadata, SQL schemas/rows and supported original Cloud history before copying
the protected material. Interrupted copies resume only the same signed operation.
Successful admission stops at BLOCKED generation3 and grants no runtime access.

Use the existing held knowledge, privacy, Temporal inspection, quarantine,
receipt-observation and release commands with `--recovery-config` naming that
exact target document. Their shared release kernel uses the configured scoped
operator ports and explicit managed target identity. Surviving deletion/consent
reconciliation remains mandatory. A source with no privacy profiles or protected
privacy rows uses a distinct signed empty-profile proof, rechecking actual target
absence before completion; it neither fabricates an owner nor relaxes populated
privacy SQL guards. Final release certifies the current installed code and
original history/material/accounting facts before Ready. Historical admission
code is provenance, while current release code is checked on guarded runtime
transactions. Once admitted, ordinary runtime readers need the signed target
configuration and restored material, without keeping the archive key online.
Configured restored transactions use the same proof consumed by identity and
owner-retirement guards. Exact AWS configuration and Cloud namespace checks
remain additional adapter checks, including before SQL commit; the local proof
retains its existing behavior. A different proof type cannot bypass retirement.

Restored managed installations use the same `recovery-maintenance-prepare` and
`recovery-maintenance-release` commands with the exact `--recovery-config`,
`--command-id`, `--artifact`, original `--expected-generation` and surviving
`--journal-root` / `--controls-root`. Prepare runs under the current artifact and
parks the installation before replacement. Release requires the selected installed
wheel's full content identity, current scoped SQL catalogs, original Cloud history,
unchanged privacy floors and signed certificate ancestry. A rollback is another
explicit compatible selection; an artifact without the managed maintenance reader
is rejected before Park. Failures retain the parked operation and original work.
These adapters require no Temporal Cloud database access or new database schema.

Configured local stand-ins and official SDK response fixtures establish local
acceptance only. Populated base-copy/privacy/Ready, original encrypted-history
decoding, owner resumption and newer surviving source-erasure/consent floors have
scoped local evidence. The older copy preserves the independent owner correction,
other owner's revisions, original accounting/deadlines and UNKNOWN holds. Managed
artifact upgrade and rollback also have independent installed-candidate/current
owner acceptance with those original facts preserved. Full supported-profile and
actual RDS/Temporal Cloud qualification retain their separate required gates.

The separate operator commands `aws-recovery-plan` and `aws-recovery-inspect`
take the exact owned `--manifest`, private `--operator-key` and private
`--command-file`. Inspection additionally requires the current held
`--expected-generation`. Planning renders exact read-only IAM permissions without
an AWS request. Inspection uses the existing projected-token/immutable-secret
boundaries with a distinct `recovery` role; runtime roles cannot select RDS APIs.
It authenticates the operator and held generation before and after bounded reads.

The closed configuration schema is `aws-managed-snapshot-inspection/1`: fields
`manifest`, `region`, `account`, `token_root`, `operator` (`pin` ARN/version and
`generation`), and `snapshot`. Snapshot pins are `instance_id`, immutable
`resource_id`, `identifier`, `kms_key_arn`, `engine_version`, `port`,
`capture_digest`, original `source_run` and `source_generation`. This explicit
profile selects PostgreSQL16.15, an installation-prefixed instance and manual
snapshot (`aos-<installation UUID hex>-<command UUID hex>`). Required tags bind
`agentic-os.installation`, `agentic-os.capture`, `agentic-os.source-run` and
`agentic-os.source-generation`. The existing snapshot must match every pin,
be encrypted/available/complete, and have no public or shared restore attribute.

The result is metadata eligibility, explicitly `runtimeReady: false`,
`osControlReconciled: false` and `cloudHistoryReconciled: false`. It creates,
restores, shares or deletes no AWS resource and decrypts no customer data.
Coordinated remote control/private-file/privacy/history recovery and complete
deployment qualification remain mandatory. Local E2E needs none of these AWS
settings. See [RDS snapshot inspection](https://docs.aws.amazon.com/AmazonRDS/latest/APIReference/API_DescribeDBSnapshots.html),
[snapshot attributes](https://docs.aws.amazon.com/AmazonRDS/latest/APIReference/API_DescribeDBSnapshotAttributes.html)
and [RDS IAM resource scopes](https://docs.aws.amazon.com/service-authorization/latest/reference/list_rds.html).

`AWSWebIdentitySession` supplies the existing regional secrets/scheduler adapters
with official SDK temporary credentials for one reviewed installation, account,
region and `core`, `native` or `worker` role. Pass the existing rotating
Core `ProjectedTokenReader(...).read` callback for the separate AWS token mount.
The independently installed worker retains `ProjectedWorkloadToken`; its stdlib
guard is generated from that same source without combining package locks.
The SDK refreshes through the fixed regional STS endpoint with one bounded
attempt, rereading that token when credentials need refresh. Its credential
resolver contains only this provider; environment keys, personal profiles,
shared credential files and instance metadata cannot supply a fallback. Close
the session with its owning role. Credentials stay in memory and SDK errors
are replaced with metadata-only errors.

`aws_workload_identity` adds read-only STS-audience projections and exact IAM
trust-policy inputs to the existing Kubernetes role fragments. IAM role names
include the installation UUID because names are unique across an account even
when paths differ. AWS and private
RPC tokens use separate canonical `/run/agentic-os/` mounts and audiences; IAM
trust names the installation role, OIDC issuer and exact service account. These
inputs grant no IAM permissions and provision nothing. The current live
TokenReview/private-RPC gate, original owner/Host scope, Root and deadlines
remain authoritative. Explicit runnable Core/native role assembly uses the existing private RPC and
backend adapters; see the [role configuration guide](deploy/roles/README.md).
The existing image builder and `eks-native-plan`/`eks-native-job` entry points
provide explicitly selected Linux role artifacts and configuration over that
assembly. Complete current profile/release conformance and actual native platform,
EKS/IAM rotation and outage qualification retain their separate gates.
The explicit `agent-public-serve` composition now borrows those same Core
journals for the sourced-query conversation and installed worker. Its local
process/local Temporal profile requires no Cloud credentials; its AWS placement
uses Temporal Cloud, a private pinned worker configuration and standard Kubernetes
attach v5. `eks-public-plan` prepares the same service, scoped dispatcher RBAC
and explicit HTTPS ALB ingress without applying resources. See the
[public service configuration](deploy/roles/README.md#configured-public-core).
Full supported-profile/lifecycle/recovery and actual AWS/Cloud qualification remain
separate from configuration rendering and local acceptance.
See [AWS web-identity credentials](https://docs.aws.amazon.com/boto3/latest/guide/credentials.html)
and [STS web-identity sessions](https://docs.aws.amazon.com/STS/latest/APIReference/API_AssumeRoleWithWebIdentity.html).
The [IAM role-name contract](https://docs.aws.amazon.com/IAM/latest/APIReference/API_CreateRole.html)
also applies to the generated deployment inputs.

`EventBridgeSchedule` places installation-scoped wake/repair hints for the existing
`ScheduleTemporal` driver. It never chooses a slot or admits a task independently.
EventBridge's60-second precision does not replace the existing30-second missed-slot
rule: the original durable workflow, current owner/Host checks, SQL slot dedupe,
outbox and finite task Root remain authoritative in both profiles. Definition
review still starts/signals that workflow; a failed provider acknowledgement is
repairable from the committed definition. Exact scoped create tokens and observed
configuration guard repeated placement; conflicting resources cannot be adopted.
Removal checks the full owned placement and treats an absent resource idempotently.
Deployment-bound names keep old configuration cleanup separate from a replacement.

The trusted `ScheduleWakeHandler` factory supplies configured core activities and
the matching placement through an async context manager. It retains one event loop
across serial warm Lambda invocations and releases that context on explicit close.
Each invocation requires the configured qualified function ARN and existing typed
driver identity. Events contain opaque installation/application/definition IDs;
they supply no clock, credentials, task launch or execution authority. The handler
wakes the existing driver and dispatches only its already committed outbox. It
does not host an EKS worker or enable a public endpoint. Configure the function
timeout to30seconds; the handler preserves the existing25-second activity cap and
shortens it to the invocation's actual remaining time. Original task deadlines
and UNKNOWN holds are unaffected.

Provision the installation's schedule group separately. `SchedulerPlacement.permissions()`
returns controller, execution-role and trust policy fragments: only the exact
qualified Lambda target, installation group and execution role are allowed. The
trust conditions bind both source account and schedule-group ARN. No deployment
or resource creation occurs on import or default local startup. Real IAM, service
delivery, outage, retention and full deployment qualification remain separate.
See [AWS scheduling precision](https://docs.aws.amazon.com/scheduler/latest/UserGuide/schedule-types.html)
and [Scheduler role trust](https://docs.aws.amazon.com/scheduler/latest/UserGuide/cross-service-confused-deputy-prevention.html).

The original Temporal adapters accept an explicit `TemporalConnection` for a
secured remote frontend. Supply the same `InstallationPorts`, immutable run/queue
identity, private namespace, host/port, verified TLS server name, reviewed CA bytes
and SHA256, and a callable returning a current `TemporalIdentity` certificate/key.
The identity is loaded again for each connection, checked for validity, matching
key and client usage, and sent through the official SDK's mTLS configuration.
Existing Secrets Manager immutable pins can provide those bytes; no local AWS
credential discovery or certificate provisioning occurs in the transport.

Pass `connection=...` to the existing `ScheduleTemporal`, `TaskTemporal` or other
private workflow adapter. It uses the supplied short recovery guard and artifact
history keys, skips local Docker discovery, and verifies the original installation/
run namespace metadata before publishing a client. Namespace creation is a separate
operator action; `register=True` is refused for remote connections. Connection10s,
health5s and namespace RPC5s limits remain unchanged. TLS failure cannot fall back
to plaintext or a default namespace. Original workflow IDs, queues, histories,
timers, deadlines, replay and UNKNOWN accounting are unchanged. Omitting the
connection retains the existing AWS-independent owned local profile.

Deploy the remote frontend with enforced client authentication and namespace
authorization for the installation's certificate principals. Pinned server trust
and namespace metadata do not replace server-side ACLs, network policy, retention,
backup/restore or certificate rotation/revocation qualification. Local acceptance
uses synthetic certificates and an authenticated TLS termination forwarding solely
to an attested owned Temporal service; it does not qualify EKS or a public provider.
See the [official Python connection options](https://docs.temporal.io/develop/python/client/temporal-client)
and [self-hosted Temporal security](https://docs.temporal.io/self-hosted-guide/security).

Production orchestration selects Temporal Cloud with AWS-hosted workers. Local
development/E2E still uses the owned local Temporal service without Cloud or AWS
credentials. `AWSCloudTemporalIdentity` resolves a matching mTLS pair from one
installation-scoped immutable Secrets Manager version containing UTF-8 JSON fields
`certificate` and `privateKey`. `cloud_connection(...)` composes the existing
`TemporalConnection`: supply the fully qualified namespace (`name.account`), its
reviewed service UUID from DescribeNamespace, retention days, original run ID,
reviewed server CA/hash and identity provider. The endpoint is that namespace's
`name.account.tmprl.cloud:7233`. Connect verifies its registered service UUID/name
and exact declared closed-history retention (1–90 days), rather than requiring
customer-written self-hosted namespace metadata. No Cloud database is accessed.

`worker_configuration(connection, resume_existing=...)` produces secret material for the existing
bounded private assigned-worker configuration file. Write it only through the
private-file helper on protected encrypted storage; never put it in a ConfigMap,
environment variable, image, history, public event or report. Select
`assigned-read-cloud/1` (or `assigned-private-planned-read-cloud/1`), add its
`temporal` field, and set `target`/`namespace` to the same reviewed endpoint and
namespace. The installed worker requires TLS for Temporal and HTTPS for the
private Core RPC. Local profiles keep their loopback-only connection and require
no Cloud fields. Both use the same workflow, SDK plugin, encrypted converters,
phase queues, original horizon, current authority and replay/acceptance checks.
Select `resume_existing=False` only for the first authorized placement. For a
replacement, recovery or uncertain start acknowledgement select `True`: a missing
history fails closed without issuing a new Workflow start after retention.
Separate private-planner credentials/history keys remain mandatory. Certificates
are static for a connected client: rotate the reviewed secret version and perform
a controlled worker replacement over the original queues; no task is re-admitted.

Cloud recovery uses supported service APIs and the original workflow/run identities
with the retained client-side history keys. Worker replacement/result lookup is
not a restore of the OS control store. A missing/expired history or key is a hold
requiring reconciliation, never permission to recreate accepted work or release
UNKNOWN usage. Cloud owns persistence recovery; self-hosted SQL snapshots, schema
relocation and archival are inapplicable. Optional closed-history export is an
audit/retention path, not running-workflow backup or an import/restore facility.
`await inspect_parked_history(connection, token, expected_generation=...)` in the
AWS Temporal adapter captures the source-side prerequisite on an original parked
installation. It reads the actual configured control checkpoint and admitted IDs,
then inspects bounded raw history through the authenticated namespace API. It
checks namespace UUID/retention and the original operator/gate/checkpoint again
before returning opaque IDs/digests. A delayed visibility listing falls back only
to describing the exact admitted workflow ID and its original continued-run chain;
missing intermediate history, a broken chain or a cycle remains a refusal.
No private payload is decoded, workflow started or Ready certificate issued.
Keep the returned checkpoint/catalog on protected encrypted recovery storage.
For owned OS stores, `await snapshot_cloud(..., connection=...)` creates an explicit
authenticated four-store archive (control, retrieval, knowledge and legacy Core
metadata), excluding Cloud Temporal/visibility databases. Restore it with the
existing held `restore_into_empty` operation. Supply the exact original Cloud
connection, rebound to the target installation, to `relocate_temporal`,
`quarantine` and `release_restoration`; inspection checks every retained opaque
history prefix and the namespace UUID/retention before release. The existing
privacy, current-owner retirement, original accounting and release proofs remain
mandatory. This API has local installed SDK/HTTPS/mTLS and fresh-owner saved-answer/
source/denial acceptance with synthetic certificates. The unchanged local Temporal
profile retains its six-store archive and service relocation behavior.

`await held_snapshot_cloud(..., connection=..., expected_generation=...)` uses
the same four-store archive for a blocked restored copy. It rechecks original
Cloud history prefixes and current held control metadata, retaining the original
logical namespace/run and queues separately from physical target ownership.
The original Cloud source receives a signed durable selection before copying;
it remains parked even if copying fails. Local snapshots, idle/source resume and
runtime entry refuse that source, including an older local archive or a missing
gate file. This marker is not copied into restored targets. Unsupported Cloud
source resume remains a hold, rather than implicitly selecting local Temporal.

Configured remote OS stores use the explicit managed source capture/seal commands
above; the local snapshot API never substitutes an unrelated database. Managed
target restoration and full deployment/readiness remain engineering gates. Selected HA/region guarantees, residency,
export/retention/deletion and actual AWS/Cloud identity/rotation/outage qualification
remain explicit PA08.2 gates. Missing Cloud credentials block only live qualification.

The existing operator CLI accepts `--temporal-config /private/cloud.json` for
`recovery-snapshot`, `recovery-held-snapshot`, `recovery-temporal-inspect`, `recovery-workflow-quarantine`,
`recovery-release`, `recovery-maintenance-prepare`, `recovery-maintenance-release`
and `temporal-readiness`. Supply the exact `--manifest`, private
`--operator-key`, `--expected-generation` and the operation's normal inputs. Cloud
commands reject local subnet arguments; without this option the local Temporal
commands and six-store profile are unchanged. Readiness checks the current Cloud
service/namespace only and explicitly reports `runtimeReady: false` and
`storageChecked: false`; it grants no runtime or storage release.

The private configuration uses schema `temporal-cloud-operator/1`, the existing
`installation` configuration object, and exact fields `namespace`, `namespace_id`,
`retention_days`, `run_id`, `server_ca` (absolute private CA file),
`server_ca_sha256` and `identity`. `run_id` remains the original logical source run
after relocation; the installation manifest names the physical target. AWS uses
the Core installation role and `identity: {"provider":"aws-secrets-manager",
"pin":{"arn":"...","version":"..."}}`. Owned-store Cloud API development uses
`identity: {"provider":"private-files","certificate":"/private/client.pem",
"private_key":"/private/client.key"}`. Every connection rereads and validates the
current matching mTLS pair. This operator factory selects read-only control
inspection while parked; ordinary runtime composition keeps its recovery guard.
The default AWS-independent local profile requires none of these Cloud settings.

Cloud maintenance selects only the four authenticated owned stores and the
original namespace/service lineage. Use the existing maintenance commands with
the private Cloud configuration, original command ID, selected immutable wheel
and surviving privacy journals. Prepare takes the current Ready generation;
release takes that operation's original parked generation, including an ACK
retry after publication. Raw drain checks every original history prefix and
terminates only its exact original runs. No Cloud database is read or restored.
Original task deadlines, unresolved accounting and retirement ancestry survive
recertification. A prior artifact without Cloud maintenance support requires
the explicit held forward-recovery path; a mismatched release certificate never
authorizes an in-place code swap. Full upgrade/deployment qualification remains
separate from scoped local service acceptance.

See [Cloud connection](https://docs.temporal.io/develop/python/client/temporal-client),
[Cloud namespaces](https://docs.temporal.io/cloud/namespaces),
[Cloud high availability](https://docs.temporal.io/cloud/high-availability) and
[closed-history export](https://docs.temporal.io/cloud/export).

The local port runs one standard-library Python program in the pinned offline
microVM, without a model loop, Host mounts, credentials, network, ports or vsock
route. Guest JSONL contains complete currently authorized query rows and declared
criteria. Independently checked values retain the current sealed source generation;
bounded raw output pages, their manifest and the accepted result use encrypted,
metered private storage. Configured integer pricing meters the original attempt;
physical absence alone cannot settle unknown usage. Accepted replay launches no
new VM, and missing output requires reconciliation. A separate bounded Host scope
observation can check completed evidence after execution expiry; it cannot renew
the original lease or authorize dispatch. Actual local VM/user acceptance and AWS
Firecracker/deployment qualification remain separate requirements.

The explicit `FirecrackerAnalysisSandbox` adapter supplies the same original-attempt
port on a dedicated Linux Python3.12 supervisor. `FirecrackerInstallation.provision`
requires an explicit root operator, fresh private storage and SHA256/size pins for
the matching Firecracker/jailer pair, kernel,512MiB guest image and packaged runner.
It admits the bounded installation copy through the supplied capacity ledger;
the existing storage floor and unresolved reservations remain mandatory.
`deploy/firecracker/build_guest.py` builds the offline standard-library image from
an operator-pinned Linux Python base without downloads or mounted images. Its
build receipt inventories source bytes; deployment must pin the resulting image.
Provisioning and ordinary startup grant no task, capability or model authority.

The jailer uses default seccomp and an unprivileged dedicated UID. Explicit
operator selection checks KVM and prepares the volatile `agentic-os` cgroup-v2
parents with CPU/memory/PID controllers, including after host reboot. The jail
must reside on a device-capable filesystem: a `nodev` worker volume can run the
SDK but cannot supply the jailed KVM device. Keep its mount restrictions and
select the existing device-capable placement storage for physical checks. Attempt
groups are namespaced by installation and placement-owner identities; recovery
cannot clean another installation's group. One live placement per dedicated supervisor/UID
has one vCPU,1024MiB guest RAM, a1536MiB host-memory cap and64 host tasks. The
guest has a read-only disk,8MiB temporary filesystem, no network interfaces,
Host mounts, API socket or vsock route. A root guest supervisor shuts it down
within25seconds even if the input channel disappears; the existing original
lease and current-authority callbacks may stop it sooner. Its private serial
channel carries the existing bounded analysis frames, never credentials.
Recovery observes/kills only the original cgroup and removes its exact jail;
physical absence alone remains UNKNOWN usage. It never relaunches a guest.
Linux nested-KVM placement acceptance and AWS deployment/IAM/host hardening,
remote placement-service integration and release qualification are separate.

The Linux ARM64 nested-KVM profile has local acceptance through the actual installed
SDK, local Temporal, current Hosts and PostgreSQL: a result-dependent four-target
workflow runs one physical guest, publishes verified values and current sources,
survives reload, denies withdrawn access and closes its original resource root.
Seven completed private histories are collected before teardown. Separate physical
checks cover containment, Stop, replay, larger serialized inputs and actual
controller SIGKILL after guest output. A replacement acquires a new exclusive
generation and cleans the same placement without input hydration, a second guest
or invented usage; physical disk reclamation remains separate from UNKNOWN work.
The initialized
unprivileged Python reader announces serial readiness; fixed transfer counters
contain no program, input or credential text. Inference in these checks is synthetic.
Broader Linux Core/amd64, full fault/recovery and actual AWS/Cloud qualification remain
separate. Production runtime selection must address the documented
[Firecracker serial-interrupt defect](https://github.com/firecracker-microvm/firecracker/pull/6218):
the locally pinned1.17.0 release uses vm-superio0.8.1 and lacks that upstream fix.

The local Lima qualification host keeps normal NTP synchronization active and
removes `CAP_SYS_TIME` from `lima-guestagent` with a systemd service drop-in
(`CapabilityBoundingSet=~CAP_SYS_TIME`). This prevents the documented
[RPC time-sync backward steps](https://github.com/lima-vm/lima/issues/5543).
Apply host policy only after active checks finish, validate it before restarting
that helper, and verify clock synchronization and unchanged database/workflow
services. Never reset the clock, alter an original deadline or relax the private
history timestamp guard to accommodate a launcher clock. This local host policy
does not qualify AWS node timekeeping.

If output is already sealed but its final result write exhausts storage, the
current owner can grant resources through the existing request controls. The
worker resumes that exact write from its saved SDK proposal and original Native
call/lease; it starts neither another model response nor another guest. The
original task end time stays fixed. Missing or uncertain output still requires
reconciliation. Local four-target service/desktop grant, grant-ACK recovery,
History/current-source/authorization and independent package checks pass with
synthetic inference; full recovery and production qualification remain separate.

Private query-history navigation uses fresh Host/OPA authorization of the
original query scope without certifying obsolete rows or issuing an execution
credential. Current query rows, model dependencies, source verification and
publication still require full snapshot checks. Other history sources retain
their existing version checks. Missing or queued history responses retain owner
fences and disclose no ciphertext; ready envelopes recheck current sources
immediately before egress.

The production MCP adapter bounds network time separately from the enclosing
tool window. Local current-authority and journal checks do not spend the Host
network budget. Dispatch retains only the unspent network time and rechecks the
original credential and root expiry after those checks; neither horizon is
renewed.

Production profiles explicitly selecting grouped resource admission expose a
resource wait in the same conversation. The owner can inspect used, held and
authorized tokens, cost, work, compute and storage, and add finite amounts within
the admission's original lifetime ceiling when its policy allows grants.
`GET /os/ui/tasks/{task_id}/resources` observes the current owner's original root;
the corresponding POST accepts `AgentOwnerResourceGrantCommand` with the original
root/epoch, expected grant revision and exact resource vector. The existing grant
ledger owns idempotency and accounting. Control0075 separately records the current
approving session while retaining the original execution session. Both must remain
current for a new grant. Observing or replaying an accepted grant cannot renew the
root's deadline, erase spent resources or release UNKNOWN usage. The SDK wakes an
exact queued preparation when its original group is first and fits; normal
admission still performs every authority and resource check. Default startup and
ungrouped legacy profiles retain their existing behavior. Broader capability lanes
and the complete wait/recovery and production qualification gates remain separate.

The selected read worker also binds queued tool calls to their accepted parent
model and next original attempt. Private provider-input/tool-binding staging and
supported SDK checkpoint saves retain their exact write/schema/context digest.
A checkpoint resource pause keeps the pending envelope inside the existing save
loop; its versioned read-workflow patch retains the accepted parent identity for
resumption. A wake hint creates no attempt or authority, and no outstanding or
UNKNOWN usage is released to make it ready. This extension changes no contract,
resource balance or frozen migration.

Current-selector child recovery also authenticates an unstarted provider-input
write from the active child's original SDK instance, next turn and private
producer fingerprint. After a checked source change and known original usage,
Core cancels only that unused old reservation. Current-fact writes retain normal
FIFO admission and finite owner grants; obsolete input bytes are never stored.
A lost staging acknowledgement can resume through the existing resource guard
before a model has registered. UNKNOWN and unmatched private producers stay fenced.
Versioned scoped-query rounds can use the existing parallel tool path for independent
query chains, with separate checked cursors and accepted results. Legacy histories
retain serial selection. Current-fact dependency checks use the existing bounded
observation concurrency and finish every fresh source/owner check before egress.
The local synthetic recovery journey separately qualifies a20s original operation
profile with a5s provider timeout and unchanged300s Root; default30s Core coverage
and deadline-refusal evidence remain separate. No admitted horizon is renewed.

The same source-change recovery recognizes an unwritten child SDK checkpoint
only from its active child, accepted model turn, original SDK checkpoint ID and
exact private-producer fingerprint. A staged but unaccepted model cannot establish
checkpoint provenance. Core preserves any written, unmatched or uncertain producer.
Normal replay reconstructs the exact pending envelope from immutable accepted
results without another provider call; source replacement retires only the proven
unused obsolete reservation before current-generation work is admitted.

Unused child tool-binding and scope writes use the same checked recovery path.
Core derives a tool-binding write from the original accepted child function call;
a scope write comes from its sealed original goal pages and deterministic child
identity. Producer derivation waits until all original usage is known, then
rechecks the current binding, Root and exact producer fingerprint under the Root
lock. Written or unmatched producers and opaque history retain their existing
replay/FIFO/grant rules. No obsolete read is dispatched to make recovery progress.

Private Temporal-history storage waits carry the exact content-addressed write
identity in the existing closed control. The original schema/context/queued digest
must still match before a wake. Owner controls are available even when the initial
history payload cannot be stored before Temporal accepts the workflow. The existing
outbox leaves that request queued without consuming delivery attempts while its
first resource group cannot fit; other ready requests can proceed. After a finite
grant, the original launch or saved execution resumes through the same private
codec and ledger. Actual installed SDK/Temporal launch and execution waits pass
with synthetic inference, preserving accepted work, original roots and deadlines;
execution also survives worker replacement. Complete wait combinations, context
lifecycle, capability and production qualification retain separate acceptance gates.

If a model return is fully archived and settled before its acknowledgment is
lost, the controller can wake that exact original operation for normal acceptance.
The hint requires both accounted private archives and no outstanding work; it
cannot create a provider attempt or accept/disclose the response itself. UNKNOWN,
permanently failed and withdrawn work remain fenced. A versioned read-workflow patch preserves
the pending model identity when an Activity timeout hides it, while older histories
retain their previous semantics.

Known failed provider responses preserve their measured usage and declared retry
delay. The existing operation journal owns the next attempt and its earliest time;
the worker uses Temporal's durable wait and keeps the original operation, root and
horizon. The official HTTP clients issue no hidden retries. A retry header alone
does not establish known usage or release UNKNOWN work. Stop still denies the next
attempt while retaining already measured usage and accepted work.

If that known retryable failure loses its ACK before the worker returns provider
control, the recovery hint uses the journal's same retry eligibility and original
earliest time. Replay can admit a distinct charged attempt through normal authority
and resource checks. The failed result remains unaccepted and its charge is retained.

A current verified snapshot and surface can display the completed answer while
its actual activity events catch up over a slow connection. Stream continuation
retains only a validated prefix with matching conversation, visibility and
projection; authorization and source checks remain on the server. Credential-only
renewal preserves the owner's question, while changed visibility/projection
clears protected views. This does not fabricate terminal events or extend task
authority, resource ceilings or database limits.

`tools/verify_incremental.py` freezes an owned external source snapshot and selects
the existing guarded runner. Owned Temporal fixture preparation accepts the paired
`--temporal-private-subnet` and `--temporal-rpc-subnet` options when explicit addresses
are needed. Both must be canonical nonoverlapping private IPv4 `/29` networks;
the installer checks the complete bounded network inventory before creation and
cannot change an existing signed binding. The selected pair appears in the run
report. A control-migration rehearsal with inherited histories is not a fresh
Temporal installation: preserve those component databases and use a compatible
prepared full profile or the existing guarded original installer. This selection
creates no alternate runner, cleanup policy or acceptance gate.

The incremental workflow selects
affected cases through `tools/test_os.py`, or exact Host API cases through the
existing guarded Host runner. Iterations with an explicit cache retain dependencies
by exact lock/toolchain/platform and UI build/type/test output by relevant source,
contracts, fixtures and build inputs. Reports distinguish retained steps from new
checks. Backend or browser-driver edits do not rebuild unchanged UI. Target,
capacity, collection, migration and inference guards still run; full phase/release
gates remain separate. Draft migration preparation protects and rehearses a populated
owned copy, without upgrading the original target or certifying the draft by itself.
Composed WP checks require an explicit owned OS target through `--host-os-manifest`
and exact Host case selection. They keep the existing finance_test validator and
create/remove only fixture-owned rows. The isolated Next build uses the same signed
cache primitives; mutable dependency/runtime trees remain external. Cache identity
checks exact content and provenance while reporting current physical allocation,
which can change after filesystem writes settle. Capacity floors and holds remain.

The independent assistant includes ten original fluffy companions, a soft personal
workspace, saved names/appearance/response style and visible owner-private memory
controls. All artwork is bundled and pinned with the OS UI; hosts do not serve it.
Friendly character names map to the existing stored figure IDs, preserving saved
personas without a migration. Task-driven motion respects manual pause, reduced
motion and visibility. Appearance never changes resource access or memory consent.

The selected-record synthetic profile accepts explicit record/field selections;
it does not implement general natural-language tool planning or aggregate queries.
Submitted request labels stay visible within the authenticated frame, alongside
persistent clarification when input is unsupported. Memory preference confirmations
remain in the memory panel until dismissed or another action begins. Short-lived
frame credentials renew through a fresh Host-authorized bootstrap before expiry,
with a new proof key and exact owner/profile/session/policy continuity checks.
Renewal preserves conversation state and in-memory drafts; it never resubmits a
task or command. After sleep or an outage, private views are suspended until fresh
Host authorization succeeds. Logout or changed access still clears private content.
Credential rotation does not extend existing task grants or deadlines. Hosts with
a fixed-height placement may
pass `fit: 'container'` to the independent loader; content sizing remains the default.

An additive G10 development profile supports natural-language selection of
operator-registered read tools with closed reviewed JSON schemas and grounded
`EvidencePage` results. After explicitly selecting a fresh owned kernel and
assistant runtime, the operator may call `enable_governed_tools(profile, key,
local_synthetic=True)`. This profile cannot reinterpret existing task roots;
its model configuration and engine bytes are pinned to the installation.
Default startup and existing selected-record profiles remain unchanged.

The `local-chatgpt-tools/1` profile uses a separately pinned local Codex CLI
binary/version/model and its existing managed ChatGPT login. Its ephemeral
model subprocess has no host/OS credentials, database connection, application
tools, shell, browser, skills, memory, telemetry or transcript persistence.
It proposes one decision at a time; only the OS broker executes registered
reads after current host, bot, schema, resource, field and policy checks.
Generic query catalogs contain hashed scope summaries instead of enumerating
every authorized record ID. Record identifiers can come from the owner's
request or accepted search evidence; these values never grant authority.

At most five model decisions and four reads fit inside the original finite
120-second root. Known tokens/time are measured; this subscription profile
does not claim per-call monetary billing. Unknown usage remains held, accepted
work is lookup-only on recovery, and Stop fences future calls/publication.
Final output selects exact accepted evidence slots rather than model-invented
numerical prose. Tools & access shows currently available host reads. The
explicit `synthetic-tools/1` test profile accepts finite JSON call sequences;
it is not a natural-language model. Production inference, writes and full
G10/final-journey acceptance require separate qualification.

The local Codex response guidance asks for a direct answer, an explanation of
the compared scope, evidence-supported interpretation, material uncertainty and
an optional useful next step. Facts still use exact accepted evidence slots.
The local subscription model has a 30-second per-stage reservation/timeout;
the original 120-second task horizon and remaining resource budget still apply.
Synthetic model stages retain their 18-second bound. A changed engine requires
a freshly selected owned profile; do not overwrite a populated installation's
signed engine binding or reinterpret its earlier accepted results.

The local adapter constrains nested answer objects and accepted source choices
before converting them to the unchanged internal tool contract. Long explanations
are laid out within the existing wire bounds without truncating or splitting
exact fact slots. The workflow activity allows 40 seconds for the 30-second model
stage, a bounded Host read and settlement; the original root deadline is never
renewed. A failed, settled response after a successful read gives current-access
guidance explaining the response problem. It does not ask the owner to reword a
valid question or claim the Host lacks a capability. No automatic model retry is
introduced; unknown work stays held and accepted work remains lookup-only.

The production Agent SDK work starts with isolated engineering qualification in
[`qualification/agent-sdk`](qualification/agent-sdk/README.md). Its own frozen
lock preserves the current MCP 2.2 product environment while exercising actual
SDK loops, authority callbacks, private Temporal replay and supported saved-state
continuation. Run it through `tools/qualify_agent_sdk.py` with an explicit private
external root; it never uses live API credentials or promotes production/G10
acceptance. The private production accounting/admission and official provider
transport boundaries described below are independently implemented. Durable SDK
integration, live provider/deployment qualification and release remain pending.
The installed assistant is not switched by these checks.

The separate [`harnesses/agent-worker`](harnesses/agent-worker/README.md)
distribution now owns the selected SDK dependency graph and explicit worker
policy. Production Agent contracts are additive in `tools/schema_source.py`;
the generator emits the kernel/UI schemas and a closed worker-only subset from
the same authority. All 456 pre-existing schema definitions, versions and shared
structural vectors retain their frozen identities. The new `agent-resources/1`
wire describes tokens, cost, work, compute and storage, with no execution-count
coupons. It is not the old `BudgetLimits/1`; existing roots retain their legacy
accounting format and vectors.

`production/bindings.py` checks current context, explicit model/policy pins,
step/attempt/input consistency, aware time, the absolute horizon and coverage.
Its expected records must come from authenticated kernel state. These pure
checks issue no grants and cannot substitute for transactional admission.
`ports/agent.py` defines separate model transport, SDK harness and governed
execution boundaries. Additive control0057 now discriminates `legacy-budget/1`
and `agent-resources/1` on the same original root/attempt tables, including a
composite attempt-to-root format fence. Format, initial ceilings and original
horizons are immutable. Closed production vectors, capacity, state transitions
and deferred exact accounting conservation are enforced in PostgreSQL. The
protected populated0056 rollback/forward and separate encrypted backup recovery
preserve old rows, UNKNOWN reservations and private material. Applied0057 is
checksum frozen. Additive0058 is also frozen after protected populated rollback,
forward application and independent0057 backup recovery; further DDL starts0059.

`production/accounting.py` contains kernel-private short-transaction persistence
primitives for reserve, begin, measured settlement, UNKNOWN and unstarted release.
They do not establish remote authority, issue SDK grants or register routes.
The coordinator must bind current authenticated Host authority and stored task
context before execution. Descendants share the original resource root; counts
are not resource coupons. Stop/expiry cannot refund already started work, and
measured overruns remain charged while the root is quarantined. `storageBytes`
measures cumulative admitted bytes written; deleting data does not refund past
consumption. Work and compute are cumulative per-attempt resources, separate
from the original absolute authorization horizon.

The explicit `agent-resources` development component selects these owned SQL
checks through `tools/test_os.py --phase G03 --component agent-resources
--iteration --manifest /absolute/fresh-owned/manifest.json` with the normal
capacity/source/target guards. It is a persistence check, not production or G03
phase qualification. `production/resource_journal.py` binds an immutable policy
to a newly admitted original root. Database-paired movement proofs preserve exact
conservation through indexed lookups; existing0057 roots keep their recorded
full-history conservation path. No populated root is rebound automatically.

`production/resource_controls.py` supplies kernel-private current-owner grants
and durable FIFO resource waits. Grants are append-only, add to original resource
ceilings and preserve spent/outstanding amounts and the original horizon. Waits
hold metadata, not a SQL session or model request; Stop/revocation cleanup cannot
refund accepted or unknown work. Remote current-authority checks precede short
transactions. The owner/session/policy fences are checked again in SQL. Creation
times use the database clock, and concurrent resumes refresh state after acquiring
the original root lock. Cursor and movement records have indexed exact bindings.

These persistence/control operations do not register a production route or enable
SDK execution. Integrated task admission, execution journal/accepted results,
authenticated worker service, official metered APIs and production registration
remain separate work. Default CLI/profile selection and existing workflow
semantics remain unchanged.

`production/profiles.py` registers immutable application-scoped Agent configuration
independently of the old bot count-budget format. The operator command
`agent-profile-register --manifest /absolute/owned/manifest.json --operator-key
/absolute/private/operator.key --application-id UUID --command-file
/absolute/private/profile.json` validates model/harness/policy pins and stores
references, never secret values. Registration enables no route, worker or lane.

`host-register` accepts the same explicit manifest, private operator key,
application ID and private command file, containing a `HostRegistration`.
Both registration commands accept `--installation-config` for the existing
`agent-installation-configuration/1` adapters. Its manifest must exactly match
the command. AWS registrations use scoped immutable Secrets Manager references
already declared in that configuration before initial qualification; registering
a Host does not provision or rotate a secret or change the signed installation
binding. A changed configuration requires its applicable readiness/lifecycle
qualification, not reuse of an old certificate.

An explicitly selected `web-pki/1` Registry/IdentityRuntime admits reviewed HTTPS
Host endpoints and exact HTTPS browser origins with a `dpop-qualified` client.
HostBridge retains fixed routes, public CA verification, no environment proxy,
redirect or cookie forwarding, and its original three-second request bound.
The browser uses additive `RegisteredBrowserIdentity` and
`RegisteredCapabilitiesProfile` projections; older local contracts are unchanged.
The frame binds registered assurance through bootstrap, renewal and observation,
and clears private state after current Host denial. The default remains literal
loopback HTTP/local synthetic identity. Qualified high-risk review remains
disabled in this HTTPS profile; DPoP login alone grants no reviewed-write lane.
These onboarding boundaries do not enable public Agent execution or certify AWS,
Temporal Cloud, external identity, recovery or production deployment.

Selected production conversation services also maintain expired private payloads
through the shared `PrivatePayloadRetention` core. Each minute they scan at most
16 original write records using scoped metadata cursors. Erasure requires the
committed write/artifact deadlines, an exact settled storage pin, a terminal task,
a closed original Root and entirely known usage. Live or unresolved work and
independently retained Host evidence remain held. Authenticated erasure markers
make retries idempotent; cleanup does not change accounting or extend deadlines.
Artifact/key operations run outside SQL transactions. Local and AWS assemblies
use the same capability contract; actual AWS retention qualification is separate.
The existing installation recovery guard spans canonical preparation and file
erasure, so a concurrent park or restore cannot replace the checked generation.

An operator can run one owner-scoped page with `agent-payload-expire --manifest
/absolute/owned/manifest.json --operator-key /absolute/private/operator.key
--command-file /absolute/private/subject.json`. The private file contains a
`SubjectRef`; only stored deadlines authorize erasure. Use the returned `next`
write ID with `--after-write-id` while `more` is true. Invalid authority or
preparation stops before erasure. Per-artifact failures return a partial result
and nonzero exit; repeat the owner scan to retry them without skipping earlier
failures. Current public consumers continue to validate original payload expiry
and ciphertext pins, so erased derivatives cannot be served as saved answers.

`production/admission.py` provides the separately selected private admission
component. Real current Host identity and capability authority are checked before
SQL; current local owner/session/policy fences are held through the atomic task,
control, segment, input, outbox and original-root commit. Immutable profile,
definition, model, harness, resource policy, intent revision, control epoch,
application timezone and database admission time are bound to the original
absolute horizon. Additive0059 checks these bindings again at deferred commit and
preserves existing profiles. Its protected populated0058 rollback/forward and
independent recovery freeze0059. Later additive revisions are described below. Admission is available
only to the explicit owned engineering component. Default health, legacy task
routes and workers do not select it. Production activation, durable execution,
metered official transports and deployment qualification remain separate gates.

The isolated worker's `transport.py` uses the official OpenAI Responses and
Anthropic Messages clients with explicit immutable model/endpoint/credential
references, reusable connections, zero SDK/HTTP retries and disabled content
telemetry. Each request must pass an authenticated kernel begin boundary; its
provider evidence and candidate output return only to the private finish boundary.
Individual timeouts and request/response byte bounds do not limit task turns.
Rejected, interrupted or malformed requests without trustworthy usage remain
held. Known incomplete output is accounted without becoming a successful result.
Provider-hosted tools require their separately metered lane and are refused by
this initial text/function transport.

The assigned worker requires bounded resolved retention/residency documents in
`TransportConfig.privacy_configuration_json` before creating a provider network
client. Their canonical manifest pins must match the original model profile,
credential reference and explicit global endpoint. Unsupported regional or
zero-retention claims cannot fall back to that endpoint. See the independent
[worker configuration](harnesses/agent-worker/README.md) for the closed fields.
Actual provider account-policy qualification remains separate; deterministic
in-memory transport fixtures grant no live qualification.

`production/pricing.py` computes integer resource/cost estimates from disjoint
provider counters and pinned currency/rates. Cache reads/writes are counted once;
reasoning remains within output tokens. Missing cache-write TTL uses the higher
approved write rate. Cost and elapsed milliseconds round upward. These are
conservative resource estimates, not provider invoices. The private SQL model
journal is described below; authenticated worker RPC and SDK execution integration
remain required before production use.

`production/payloads.py` provides the governed local private-input prerequisite.
It commits an original-root storage reservation and start before encryption/disk
I/O, then records exact encrypted artifact bytes and upward-rounded elapsed/CPU
work in a separate short transaction. No SQL session spans the file operation.
A ready record is immutable, owner/root bound and paired with known accounting.
Retrying a completed identity compares private content without another write;
an interrupted write stays held and cannot run again under the same identity.
Canceling a waiting caller does not abandon the already started accounting thread.
An expired lease that never reached disk records known zero file usage.

Current-owner admission locks application/owner before controls/root. Private
post-Stop artifact accounting takes parent key-share locks before the root;
these metadata locks grant no live authority. This prevents inversion with the
artifact foreign keys while retaining revocation/Stop accounting. Additive0060
is frozen after protected populated0059 rollback/forward and independent recovery;
the subsequent model journal is described below. The existing local adapter's1 MiB per-object qualification
is explicit; paged/large-context adapters remain separate
work. Storage measures logical encrypted artifact bytes; database WAL/page and
infrastructure costs are separate operational accounting.

`production/model_policy.py` registers immutable operator-owned metering policies
for exact model/pricing pins. Its context window supplies the conservative input
reservation. Qualified request/output bounds fit the selected artifact adapter;
they impose no task-wide call/step/turn ceiling. Registration enables no route.

`production/model_journal.py` implements the kernel-private model lifecycle. One
semantic step reserves the provider call and both candidate/proof storage slots
on the same original root. A committed start returns executable private input
once. A duplicate or lost start acknowledgement cannot dispatch the call again.
Known usage is priced once; unknown work remains held. Output encryption/writes
have no open SQL transaction and measure their own storage/CPU/elapsed resources.
An owned accounting thread survives cancellation of a waiting caller. Partial
file acknowledgement loss cannot authorize a rewrite or accepted result.

Candidate/proof artifacts and outcome claims are private, immutable and distinct
from acceptance. Fresh Host session and capability-policy checks precede model
prepare/begin and result access. Exact tool/resource/field scope remains each
governed adapter's obligation. Already begun work can account/archive after Stop;
it cannot acquire new execution authority or disclose a result. Accepted results
survive replacement workers and original attempt lease expiry while current
owner/root/horizon and artifact integrity remain valid. Usage beyond the qualified
provider window is still charged and its output cannot become a success.

Additive0061 introduces the private journal. Its first runtime test exposed an
unsupported checksum-helper domain; frozen0061 is preserved and0062 corrects only
the new guards with the existing profile helper. Both have protected populated
rollback/forward/independent recovery evidence. Focused
SQL/remote-Host cases cover the lifecycle and revocation, not complete PA03.2.
The journal alone does not supply the supported SDK tool-call bindings,
checkpoint/Temporal continuation or a production activation path. The later
private worker and operation services below provide their own scoped evidence.

Additive0063 separates a provider's HTTP timeout from the original bounded
model operation window. New calls reserve the resource policy's operation time
for the model and its archive slots; the shorter HTTP request leaves time for
accounting, storage and current acceptance. Neither window can extend the
original root horizon. Existing prepared calls return their original lease.
An actual delayed-storage case passes after the HTTP duration while still inside
the operation lease. Protected populated0062 rollback/forward and independent
recovery pass;0063 is frozen and further DDL starts0064.

`production/provider_json.py` validates bounded opaque SDK documents separately
from canonical OS wires. Finite JSON decimals and Unicode schema keys survive
private input/output storage without being promoted to resource authority or
financial evidence. Duplicate keys, non-finite values, invalid Unicode, excessive
nesting and objects outside the selected byte bound fail closed. Exact original
bytes remain encrypted; canonical control/usage/financial validation is unchanged.

`production/model_rpc.py` supplies an explicitly constructed, unbound private
ASGI model-worker service. It is never attached to normal OS startup. Deploy it
only behind the approved private TLS/workload boundary. The supplied
`PinnedWorkloadJWT` adapter verifies explicit Ed25519 keys, issuer/audience,
current credential lifetime and a server-owned service assignment. Deployments
may provide an approved workload-identity adapter instead. Mobile/Host/browser
credentials, cookies and browser origins do not authorize this service. Renewable
service credentials cannot renew a task's original authority or resource horizon.

The service derives the owner/session from the immutable stored admission and
checks the assigned application/model/meter pins. Before begin, declared provider
endpoint/credential references and request/response limits must exactly match
the stored meter. The current private local profile accepts no inference-geo
override; concrete residency profiles require their separate qualification.
Begin returns private input once; finish truthfully accounts already begun work
after Stop; accept returns provider JSON only after current acceptance. Bounded
request parsing, no-store replies and safe machine errors keep private SQL/model
content out of public errors. No provider key is sent to the kernel service.

Private `stage` pins provider input bytes to a stable operation-derived write ID;
replay cannot rewrite or charge the same ready object again. Private
`prepare-operation` selects the current attempt from the stored journal rather
than trusting a caller's retry number. It returns a reservation, the already
accepted private result, the original provider wait, a terminal failure or a
reconciliation requirement. An UNKNOWN or begun call cannot become a new paid
attempt. Both commands enforce the original admission and exact transport pins.
The worker snapshots new command inputs before awaiting token renewal.

The independent worker's `RPCModelBoundary` uses one explicit HTTPS endpoint and
a renewable workload-token callback. Only explicitly selected local synthetic
loopback HTTP is allowed. It refuses redirects, proxies, hidden retries, ambiguous
control JSON and oversized responses. `OfficialTransport` binds its configuration
before input loading; one boundary cannot be rebound to different settings.
Malformed provider Unicode preserves known usage and private evidence while
rejecting the candidate. Actual SQL/Host private HTTP checks and independent SDK
protocol checks are engineering evidence, not TLS/cloud identity qualification or
one combined SDK-to-SQL E2E. Durable SDK model/tool/checkpoint integration remains
pending; the installed public assistant is unchanged.

The worker's `sdk_model.py` now implements the selected SDK's public
`Model`/`ModelProvider` interfaces. Its per-run public hooks carry a typed private
binding through `ModelSettings.metadata`; that binding is stripped before provider
I/O. A controller-owned SDK instance and turn identify each semantic operation;
neither provider IDs, request hashes nor Temporal Run IDs allocate that identity.
The controller must persist the sequence snapshot with supported SDK `RunState`.
Publishing the next binding in the public end hook preserves it when the SDK
copies settings to reset tool choice on the following turn.

One model call stages exact input, asks the kernel to select its stored attempt,
and returns only an accepted private provider result. Accepted replay skips the
provider. Original provider waits and UNKNOWN reconciliation are returned to the
controller without a local retry or sleep. Only function-tool definitions are
supported in this slice; hosted tools, handoffs, stored provider conversations,
raw provider streaming and unqualified SDK options fail closed. Governed tool
execution and narrowed delegation still require their later lane integration.
Encrypted reasoning continuation items remain private SDK context. The pinned
SDK's optional cache-write detail is normalized only in its local typed view;
accepted bytes and the kernel's measured accounting are unchanged.

Engineering checks cover an actual thirteen-response SDK loop with twelve local
test-function calls and synthetic kernel replies. A separate actual independent
worker/private-HTTP/SQL/current-Host case performs two SDK runs with one accepted
operation and one synthetic provider request. These are separate scoped proofs,
not combined Temporal/tool/topology conformance. The private production workflow,
durable checkpoints/waits and production activation remain pending.

`production/mcp_transport.py` adds a separate private, paged MCP transport using
the pinned official client. Reviewed endpoint profiles select HTTPS or explicitly
owned local HTTP. Short-lived credentials must match the owner, audience and
capability; each operation respects the original task horizon. Catalog pages are
bounded individually without imposing a total catalog size. Calls compare the
reviewed input/output schemas against one scoped schema page, freeze arguments,
and offer a current execution fence immediately before the business invocation.
Server instructions are not promoted into trusted configuration. Structured
results remain untrusted candidates; transport success grants neither resource
authority nor result acceptance. Specific connector problems identify the Host
developer action instead of asking the user to reword an otherwise valid goal.

Actual official-client protocol simulations cover paging beyond64 tools,
schema changes, revocation fences, frozen inputs, cancellation without retry,
structured errors and endpoint/credential failures. These are not live Host TLS
or production capability-facade qualification. Persisted catalog registration,
current scoped Host authorization, accounting and governed lane integration are
still required. The frozen local read-only broker remains unchanged.

`production/capability_catalog.py` persists individual operator-reviewed
capabilities outside the legacy64-tool bundle. Registration is immutable by
application generation and capability revision. Additive control0064 advances a
locked catalog version atomically with each append; mutations, skipped versions
and regressive revisions are refused. Bounded keyset pages and signed cursors
bind the exact task/intent context and catalog version. Changed registrations
invalidate an existing traversal instead of returning an obsolete enabled tool.

Discovery intersects the stored capability policy with a fresh scoped Host
response and rechecks the current owner/root after that remote await, with no
SQL held across it. Host pins outside the reviewed page are refused. A registered
capability with no configured governed adapter is explicitly unavailable and
identifies the OS developer action. This interface is private and issues no
credentials, reservations or accepted results. The current tests use actual
owned PostgreSQL and both remote Host scope implementations. Governed invocation
uses the separately selected lane journals; production identity/deployment and
live inference qualification remain separate.

The explicit `agent-discovered-read-journey/1` profile connects that catalog to
SDK planning through a metered metadata tool. It returns at most16 compact
entries per page and at most64 explicitly retained choices, rather than putting
every active tool schema in the launch or provider input. The SDK's supported
model-input filter runs before Temporal Activity serialization and the transport
repeats the same context checks after decoding. Pending tools use supported SDK
approval checkpoints. Completed metadata rounds reuse the existing query
rollover mechanism for a fresh bounded SDK context; all causal work remains in
the private journals and Temporal histories. Metadata is never business evidence
or execution authority.
Metadata pages also have a conservative16KiB bound after JSON-string expansion.
A wider page returns the existing metered, known tool-error without publishing
selection evidence. The SDK can retry the same cursor with fewer retained pins
or a smaller positive page limit on the original Root. Only settled errors from
this exact metadata profile may precede goal binding; missing/UNKNOWN work and
other discovery profiles retain their existing gates. Model input/output and
the actual public Temporal checkpoint encoding are checked before private
serialization; unsupported provider state is refused without tool dispatch or
an increase to the65536-byte private envelope.
After immutable read-goal binding, Core resolves only the goal's current exact
read pins and supplies their full execution schemas through the existing facade.
Every actual read still requires its accepted model proposal and current Host
authority. Committed metadata replay re-observes current owner/Host metadata
without reopening the original page or renewing its old disclosure expiry;
first acceptance retains fresh-page verification. Original Root, deadline,
accounting, cursor/version and Stop guards remain unchanged. This profile selects
`EvidencePage/1` reads; query, effect, native, memory and proactive workflows keep
their existing explicit lane contracts and authority requirements.
History observation combines metadata pages into bounded current Host scope
requests within one graph read, retaining every exact descriptor check before
and after the Host response. No authorization survives that read. Discovery
checkpoints name exactly their accepted parent model; one complete current
dependency traversal checks that parent and its immutable input ancestors.
Additive control0087 permits only the exact registered metadata policy and private
accepted-result type. Its populated runtime, seven negative guards,
rollback/forward/catalog and independent0086 recovery pass. The129-capability
service, installed recovery, sourced browser/History/reload and current artifacts
have cumulative local synthetic evidence; failed collector aggregates stay failed.
Full execution/lifecycle and actual API/AWS qualification remain separate.

`production/capability_schema.py` qualifies bounded self-contained JSON Schema,
including acyclic local definitions and finite decimal payloads. It refuses
remote references, schema-selected regexes, unbounded collections and excessive
schema expansion. Financial evidence still uses its separate exact contracts.
Eighteen schema checks and thirteen catalog/current-session SQL checks pass.
The populated0063 rollback rehearsal, forward0064 apply and independent original
backup recovery pass; both revisions are frozen. Further DDL starts0065.

`production/capability_host.py` implements the new scoped Host contract over an
explicit HTTPS or owned-loopback profile. An audience/credential-reference token
adapter supplies current service credentials. Responses and requests are bounded;
redirects, cookies, compression, cross-application requests and hidden retries
are refused. Current task/owner/policy/pin checks remain in the catalog after the
remote response. The independent Python/Node example Hosts implement this route
without kernel imports. Each requires its own reviewed capability pins and
current owner/read permission; an OS registration alone returns no Host grants.
These examples qualify the local read-scope protocol, not production OAuth,
Verizon identity or governed tool execution. Their explicit private
`agent-capabilities.json` fixture is never inferred from an OS registry.

`production/operations.py` adds the private model-operation journal. A semantic
operation pins its original context, input artifact, parent/iteration metadata
and already accepted result dependencies. Deliberate refreshes use new operation
IDs; replay uses the stored identity. A qualified retry retains that identity and
input while reserving a new independently metered model call. Preparation of that
call and its operation link share one SQL transaction. `ModelJournal.prepare_tx`
extracts the unchanged existing preparation body for this atomic composition.

Known returned model work can be accepted after controller replacement inside
the original operation lease without regeneration. Late unaccepted results and
expired, proven-unstarted reservations need their later recovery integration.
Begun or UNKNOWN work returns a reconciliation state, never new
executable input. Known nonretryable failures cannot create another attempt.
Retry-After is anchored to the original finish observation; the service returns
a wait without sleeping, holding SQL, shortening the delay or renewing the task
horizon. An unrepresentable absolute date retains the exact integer delay and
observation timestamp. The later durable controller must honor both that wait
and the original horizon. Count fields are observations, not call coupons.

Ten operation cases and two affected existing model cases pass on actual owned
PostgreSQL with synthetic provider returns. This includes twelve causally bound
model operations on one original root, with no four-call execution limit. It is
not a twelve-turn SDK integration claim. Control0065 is frozen after protected
populated0064 rollback/forward and independent recovery. The first rehearsal
failed because its old catalog probe used the Mac clock; its transaction rolled
back with exact parity. A new database-clock probe passed without changing the
maintained guard. Non-model operation lanes, authoritative plan revisions,
intent amendments, durable SDK waits/checkpoints and full workflow integration
remain pending. No public/default production runtime is enabled; next DDL0066.

Additive0066 introduces separate current-result checks for already settled model
work. An archived known result can be accepted after its attempt lease expires
only while the original owner/root/control/horizon and artifact integrity remain
current. The executable-work lease function is unchanged. An expired reservation
can be released and replaced only when no model start/finish exists and both
untouched output reservations are also provably unstarted. The release movements
and new metered ordinal share the owner/root transaction. Begun and UNKNOWN work
remain held. Protected populated0065 draft rollback, forward application and
independent recovery pass;0066 is frozen and further DDL starts0067. Targeted
runtime recovery has seven new and eight affected actual SQL/private HTTP/SDK
passes. Current core wheel and guarded Host checks pass; the unchanged worker
package retains exact compatible evidence. Durable Temporal/tool integration
and production qualification remain pending; no production route is enabled.

`production/tool_requests.py` projects an exact SDK tool proposal from an already
accepted model operation. It verifies the source response's call ID/index,
original arguments, the model input's reviewed schema and a stable capability
version alias. The resulting operation ID is namespaced by the semantic model
operation, so replay retains identity and intentional repeated calls stay
distinct. Exact catalog lookup intersects current Host permissions and rejects
withdrawn or superseded registrations without traversing the complete catalog.

An explicitly configured `ModelWorkerService(..., tools=ToolRequests(...))`
exposes the workload-authenticated private `resolve-tool` command. The independent
worker's `RPCModelBoundary.resolve_tool` validates the returned original context,
source result, operation identity, capability and argument digest. The default
private model service refuses this command when no resolver is supplied. This
returns a bound proposal only: no tool I/O, reservation, execution grant or result
acceptance is performed. Governed durable lane dispatch and Temporal checkpoint/
wait integration remain required before production execution can be enabled.

`production/read_lane.py` adds a private, explicitly reviewed MCP read adapter.

Its profile binds a capability version, provider, EvidencePage output contract,
Host read-authorization endpoint and separate OS policy bundle. Discovery scope
does not authorize execution: the Host must independently authorize the exact
accepted-model arguments and verify each returned resource/field against current
business permission. The bounded `read_host.py` client binds these decisions to
the request and current owner/policy generation; dispatch credentials remain
short-lived, audience/capability scoped, and absent from policy input and results.

`read_policy.py` uses the separately pinned `agent-governed-read/1` OPA bundle.
It intersects the original immutable capability ceiling, reviewed read adapter,
current Host decision and exact owner/root/intent/control bindings. It does not
reuse legacy call/stage coupons. Policy deployment is explicit; existing OPA
installations and frozen policies are unchanged. Undefined decisions, changed
bundles, stale authority and unqualified delegation fail closed.

The read adapter requires the durable journal's begin callback before tool I/O.
It rechecks current authority after metadata/policy waits. `observe` returns a
private untrusted observation, including structured tool errors, so the journal
can preserve returned work before acceptance. `verify` separately checks the
reviewed schema, typed provider/resource/field evidence, core digest and current
Host/OS permission. Replay can verify archived bytes without another tool call.

The explicitly selected local SDK read conversation connects authenticated
`/os/inputs` and `/os/tasks` to the existing SQL outbox, the separately installed
OpenAI Agents SDK/Temporal worker, and this governed read lane. The default
health shell remains unchanged. `IdentityRuntime.enable_agent_read_runtime`
requires a truthful model label and inference declaration; an optional local
worker factory creates its clients on the server's event loop. Its private
worker RPC accepts workload credentials, rejects browser credentials/headers,
and shares the same original admission, source and accounting services.

The current completion profile covers explicitly selected resource/field reads.
An accepted planner response is bound to the captured original request; the
server verifies exact accepted fact selectors against current Host/OS authority
and stores a metered verification artifact. Completion, public events and the
source surface commit together. A candidate, verification artifact or worker
control alone cannot certify completion. Renewed observation reads existing
accepted evidence under current owner/source permission without reopening a
closed root, dispatching a tool, or spending another inference allowance.
Legacy renderers refuse these production-format roots.

`LocalAgentWorkers` places one assigned task in the independent worker process;
the existing outbox and Temporal retain delivery/execution authority. Private
input crosses an ephemeral pipe, and delivery requires a matching typed
acknowledgement after workflow start. Replacement retains the original workflow,
root, input and horizon. Stop is persisted before remote signalling. Its
controller uses the production accounting journal for never-begun release and
uncertain-work holds, and the existing persistent public status writer.

This is local development integration with synthetic inference, not completion
of the frozen WP/laboratory analysis outcomes or API/deployment qualification.
Enumeration, exact derived analysis, authoritative plan/delegation, the remaining
recovery matrix and release gates stay separate obligations. Larger result sets
require their own complete coverage and paged presentation; this selected-record
verifier rejects unsupported coverage rather than truncating it into success.
Pages/cursors and partial coverage remain pages, not task-completion claims.
The new checks use actual owned SQL/current Host sessions and the pinned MCP/HTTP
clients with synthetic read-authority/MCP replies; separate real OPA HTTP checks
qualify the policy and its restricted route. Implementing the new Host read
protocol and the combined SDK/Temporal workflow remain pending. The separate
durable journal is described below. This adapter is not exposed by default startup, does
not issue accepted-result references, and does not enable production execution.

Additive0067 now supplies its separate durable tool journal. Operator-reviewed
profiles explicitly select non-inference elapsed Host reads. The journal stages
encrypted accepted-model bindings and reserves tool/output capacity before I/O,
claims dispatch once, and separately archives, accounts and accepts results.
Stop permits truthful completion accounting while blocking acceptance. Begun or
UNKNOWN work cannot be dispatched again. Only expired, proven-unstarted work
can receive a new metered ordinal under the original operation and root.
Populated rollback, protected forward application and independent recovery pass;
0067 is frozen and further DDL starts0068.

`ToolFacade` routes the private workload-authenticated `execute-tool` command
only to registered lanes. An independent installed worker executes and replays
accepted output through actual private HTTP/SQL without a second MCP call.
The public SDK FunctionTool callback preserves call IDs and original arguments;
the controller can recover private deferred conditions from the SDK's standard
exception cause. These component checks use synthetic Host/MCP/provider replies.
The combined durable Temporal workflow and production qualification remain
pending; default startup is unchanged. Causal input integration follows below.

Additive0068 introduces private encrypted input-result sets and permits exact
accepted tool references as model-operation dependencies. Each bounded set
indexes existing results under the original root; nested pages impose no total
task or branch count. Its populated rollback rehearsal, protected forward apply
and independent original-backup recovery pass.0068 is frozen; further DDL starts
0069. All previous schema definitions and applied migrations retain their bytes.

`production/dependencies.py` iteratively rechecks accepted model/tool ancestors,
decrypts bounded input pages after closing SQL, and rejects tool outputs without
a matching current accepted result. A known failed tool can supply only its
typed failure; UNKNOWN work cannot be presented as a settled error. Model
preparation, private egress/result access and checkpoint access apply these
checks. SDK end hooks reset the direct parent reference, governed callbacks add
accepted tool references, and larger batches use metered encrypted pages.

Actual installed SDK/private HTTP/SQL engineering now covers six successive
governed reads and full accepted replay with seven synthetic provider responses
and six MCP calls total. A separate actual SDK parallel batch exceeds128 tool
results using a bounded result set. These checks retain synthetic Host/MCP and
provider replies; combined Temporal recovery, the Host read-authority service,
later implementation packages and production qualification remain open.

`production/private_state.py` adds an explicitly configured workload-private
history/checkpoint service. The selected namespace, task workflow identity and
history key identifiers are checked before encrypted envelopes are stored. All
writes use existing metered `PrivateInputs` on the original root. Checkpoint
access retains causal/current-source verification. Stop withholds new ready
state/hydration while already written storage is truthfully accounted; unknown
writes remain held and cannot overwrite the original file.

The independent worker's separate history codec records only opaque payload
tickets in Temporal, with ciphertext archived through the private service. Its
keyed content identity and lookup-before-encryption preserve known replay and
uncertain-write identity. Actual installed codec/private HTTP/SQL checks and
separate converter/crypto/protocol tests cover these boundaries. Seven additive
contracts yield550, preserving all543 previous definitions; no DDL changes.
Default private/public startup remains disabled. Combined Temporal scheduling,
terminal outcomes/rollover/waits and later context/privacy/deployment gates are
still required; these transport checks do not qualify the complete workflow.

The new explicit worker `OSAgentTaskDriver/1` now composes the actual SDK,
official Temporal plugin, private history codec, original SQL model/tool journals
and supported RunState checkpoints. Four installed SDK/Temporal/private HTTP/SQL
cases cover two-segment continuation, worker replacement/replay, uncertain
provider/tool completion and checkpoint acknowledgement loss. Accepted work is
not redispatched; UNKNOWN usage remains held. Source hashes of the installed
worker are checked, and actual protobuf history payloads contain only private
claim checks or closed control metadata. Two additive control/start contracts
yield552 without changing previous definitions or frozen0068.

This read trajectory uses synthetic provider and Host/MCP returns. It returns a
private candidate reference for later completion assessment. Full resource/input/
review waits, closed-root replay/erasure, every crash boundary, authoritative
plans/delegation, actual Host read authorization and later plan packages remain
pending. There is no default/public runtime activation or AWS qualification.

The standalone Python notes and Node workspace Hosts now implement the selected
`/host-bridge/agent/v1/read` authorization protocol independently. Each requires
current Host-owned capability/profile review, verifies the original bound
arguments and issues a short-lived credential tied to the exact tool/arguments.
Disclosure re-reads every requested resource's current version and field values;
a matching hash alone grants no authority. The new bounded MCP profiles use
`agent_notes_read` and `agent_documents_read` (Node's explicit2020-12 profile is
at `/agent-mcp`). Legacy read schemas and credentials retain their own lane.

Actual two-Host SDK/Temporal/private HTTP/OPA/SQL trajectories now survive run
rollover, worker replacement and replay with one Host tool dispatch per task.
The only synthetic response boundary in those trajectories is the provider.
Separate checks reject changed sources, forged values/fields/versions, boolean
type substitutions, unreviewed pins, expired/foreign bindings, bad workload
credentials, duplicate JSON and scoped-token reuse. Legacy BFF/login/owner reads
and scoped catalog checks pass. These are explicit owned local Host profiles;
AWS identity, broad population/query coverage, other lanes, complete E2E and
production release remain unqualified. Default startup is unchanged.


New admissions may explicitly select `ProductionAdmission(..., resource_groups=True)`.
The persisted binding applies only to the root's creation transaction. Its
metadata-only FIFO groups atomically prepare one model and both archive slots,
one tool and its output slot, or one private write. Deferred SQL guards require
every member to match actual original source rows and scalar ledger attempts;
a group owns no resource balance. Waiting starts no external work and holds no
reservation or SQL session. Original roots retain their scalar queue protocol.

Protected populated migrations0069/0070 and independent original recovery are
verified.76 distinct affected checks include an installed SDK/Temporal resource
wait, worker replacement, an authorized grant on the original root and replay.
Four histories contain40 opaque tickets and6 typed controls. New production
reservations share the database clock with model facts; controlled local clock
skew cannot reverse their source timestamps or extend the original lease.
No existing lease, SQL guard or UNKNOWN hold is rewritten.556 contracts preserve
all552 previous definitions. Input/review waits, closed-root state observation,
full fault recovery, plans/delegation and later packages remain required. These
checks issue no paid API requests and enable no default or production runtime.

The worker's `checkpoint.py` uses the public SDK `RunState.to_json`/`from_json`
surface for an interrupted run. Its private envelope pins SDK0.19.4/state1.13,
the immutable task context, SDK instance, next model-operation binding and active
capability versions. Restoration rejects changed pins, tracing, provider-managed
conversation state and a finite turn ceiling. Continuation always selects the
governed model provider explicitly with tracing disabled and `max_turns=None`.
It never approves an interruption or grants permission to execute its tool.

`production/checkpoints.py` stores/loads these private envelopes through the
existing metered encrypted payload journal. The SDK instance/turn must identify
a currently accepted model operation on the original root. Restore rechecks the
registered harness's exact checkpoint format and durable-checkpoint feature,
original context, source dependencies, current Host authority and Stop. A lost
write acknowledgement retains its UNKNOWN reservation; retries do not rewrite
it. Stop during a successful write retains truthful storage accounting while
withholding ready state. The selected local artifact profile retains its existing
per-object capacity; paged context, compaction, complete Temporal rollover and
governed tool dispatch remain separate pending integration work.

Artifact/recovery freshness checks measure current bytes rather than treating a
stat timestamp as content proof. Same-size writes on coarse-clock filesystems
can preserve the entire previous fingerprint. Native preflight hashes each
opened artifact; the finite public-program worker hashes current source/schema
contents, and restoration/receipt inventories include signed metadata/capsule
content digests. Private encryption keys remain outside those content scans.
Parsed metadata can be reused only after a fresh matching content inventory;
current gate/operator, expiry, SQL and original UNKNOWN fences still apply.

Default startup exposes the health shell. Explicit local profiles implement the
G00–G03 foundations and the G04 backend trust slice: typed preparation, immutable
owner review, current-input editing/decisions, transactional reviewed or finite
delegated effects, private notification delivery and separately approved typed
repair. G05 qualifies governed memory and G06 qualifies the selected local
Darwin ARM64 native/offline profiles. The independent G07 local synthetic UI
implements governed memory, source paging, motion and exact-input top-level review.
G08 adds reviewed deterministic schedules, registered event admission, finite
independent tasks and private receipt controls. The cumulative qualification is
limited to explicit local synthetic profiles; coordinated restore, production
identity and final release journeys retain their later gates. Host integration
stays independent.

A constructor or short component selection does not certify G04. For this G04 closure the owner authorized cumulative qualification: a case ledger covers every registered identity using compatible actual passes, reruns failures/pending cases and invalidates tests affected by later changes. This is recorded as qualification across runs, not a single clean full-suite run. Serial current-source host HTTP/MCP and financial regression, protected upgrade proof, staged review and local commit remain required.
All56 final journeys retain their separate G10 acceptance; synthetic backend
qualification is not production or browser release acceptance.

The G10 distribution tooling builds separate API wheel, assistant UI archive and
module installation inputs, plus a CycloneDX1.6 SBOM, observed dependency inventory,
complete Python notices and a standalone offline verifier. Packaging records
`pending-final-acceptance` and keeps all default lanes disabled. The SBOM identifies
observed Python metadata and UI build inputs; candidate registry wheel hashes and
the separate native source/compiler inventory retain their precise scopes.

After the normal locked UI build and wheel build, choose a new private output
directory and the existing shared capacity ledger:

```sh
.venv/bin/python tools/build_release.py --wheel /absolute/artifacts/agentic_os-0.1.0-py3-none-any.whl --output /absolute/new-release --capacity-root /absolute/shared/capacity
```

Retain the returned manifest SHA-256 separately. Copy the entire release directory
outside the checkout, verify the standalone verifier against its retained artifact
pin before running it, and use the separately retained manifest digest:

```sh
python3 /absolute/release/verify-release.py --bundle /absolute/release --expected-manifest-sha256 RETAINED_DIGEST --extract-to /absolute/new-installation
cd /absolute/new-installation/module
uv sync --frozen --no-install-project --no-dev
uv pip install --python .venv/bin/python --no-deps /absolute/release/agentic_os-0.1.0-py3-none-any.whl
.venv/bin/agentic-os preflight
.venv/bin/agentic-os serve
```

Extraction refuses existing destinations, links, duplicate/traversing archive
members and divergent API/UI bytes. It creates only new module/UI files; service
provisioning continues to require the existing explicit owned lifecycle. The
guarded `G00 --iteration --suite tests/portability/test_release_distribution.py`
selection verifies a real external frozen installation, independent API startup
and installed restricted-Wasm execution. API/worker OCI artifacts, two-host
integrated conformance and all56 final journeys remain required for G10.

The `installed-hosts` G10 development component binds every service/browser case
to one independently distributed wheel and UI digest. Its interpreter imports
the installed product, and the runner compares every product member with both
the distributed artifact and selected maintained build before and after the
collection. Source-product imports, changed locks, extra files and incomplete
release arguments are refused. It installs only the frozen verification tools
into the independent environment; the product wheel is restored and rechecked.

Select an explicitly provisioned owned OS target, imported offline embedding
profile and prepared owned Temporal service. The G09 shared baseline remains a
separate retained installation. Use the extracted module directory and separately
retained bundle digest:

```sh
.venv/bin/python tools/test_os.py --phase G10 --component installed-hosts --manifest /absolute/new-owned/manifest.json --release-bundle /absolute/distributed-release --release-manifest-sha256 RETAINED_DIGEST --release-module /absolute/independent-install/module --cache /absolute/shared/build-cache --capacity-root /absolute/shared/capacity --report /absolute/private/work/installed-hosts.json
```

The component uses unrelated Python/SQLite and Node/document-store hosts with
deliberately colliding subject/resource IDs, persisted private persona/memory,
actual per-host outage isolation and real assistant/memory browsers. Their core
and UI artifacts stay identical. This component does not close the full G10
phase or any final journey; their complete conformance remains required. Existing
phases keep their ordinary guarded source verification unless this explicit
installed-artifact option is selected.

The delegated-effect outage regression stops an owned effect provider after
one-use consent has been granted. Both host languages must refuse
new dispatch without consuming consent, creating an attempt or notification, or
changing the original budgets. The other host's existing authority remains usable.
The provider supplies current delegated authority independently of the login
bridge. This check is separate from recovery of work already accepted before an outage.

Cached HostBridge and MCP clients each have a process-local availability circuit.
Three consecutive availability failures suppress new calls for five seconds;
then one probe may run. Success or a valid refusal closes the circuit, while
another availability failure or a cancelled probe starts a new cooldown.
Caller cancellation and time spent waiting for a local concurrency slot do not
count as host failures. Other applications retain separate clients and circuits.
This protection neither retries work nor grants authority, settles uncertain
usage, or replaces an existing effect receipt lookup with another invocation.
Circuit state is not shared across worker processes or persisted across restart.

The per-host read regression changes an owned source record and checks that the
actual MCP response preserves its new revision and exact text. Controlled hostile
descriptions and an extra tool are injected into the real SDK's catalog response;
they cannot expand registered discovery, row scope or field scope. Missing tools
and changed schemas refuse before execution. This tests the broker boundary with
both host languages; it does not claim general model resistance to prompt injection.

The guarded host launcher can select the `release-wp` component with complete
explicit release arguments:

```sh
python3 scripts/dev.py --test --os-manifest /absolute/owned/os/manifest.json --os-cache /absolute/shared/build-cache --os-capacity-root /absolute/shared/capacity --os-assistant-ui --os-release-bundle /absolute/distributed-release --os-release-manifest-sha256 RETAINED_DIGEST --os-release-module /absolute/independent-install/module
```

Run this from the host checkout. It retains the financial test target guard and
passes only remote fixture configuration to the installed OS. The component
checks WP/MySQL reads and its traditional closed financial draft, Node/SQLite
reviewed effects, private persona/memory, connector credential rotation/removal,
disablement and original lost-ACK receipt lookup. A synthetic query-driver outage
affects only the owned financial test process; shared MySQL stays running.
Traditional hosts continue after the owned OS API stops, and UNKNOWN usage stays
held. Each case owns a new registration; no disabled registration is revived.
The code lifecycle check independently installs the frozen release, observes
the original accepted receipt, removes only that fresh code subtree, reinstalls
it and observes the same receipt through the newly installed interpreter. Actual
OS keys, manifest, finite work accounting and host invocation/audit/outbox state
must remain exact. It never removes the shared test installation or held data.
The real browser uses the same release API/UI bindings. This is development
conformance; complete G10/final56 evidence remains required.

The `release-images` component verifies independently exported API/worker OCI
archives. `deploy/release/image-lock.json` pins the Linux ARM64 API base and
installer separately from the frozen native guest. Explicit builds verify the
installer's exact bytes, install only hash-checked runtime wheels and bind the
product wheel to each image. Dependency layers are retained across product
wheel updates. The observer verifies content-addressed blobs without extracting
layers, then starts only attested non-root, read-only, isolated containers.
API startup must remain health-only; the worker refuses missing owned
configuration. Private Linux placement, native Linux and production remain
disabled, and published dependency advisories require their own disposition.

```sh
.venv/bin/python tools/build_images.py --manifest /absolute/owned/manifest.json --wheel /absolute/agentic_os-0.1.0-py3-none-any.whl --output /absolute/new-images --capacity-root /absolute/shared/capacity
.venv/bin/python tools/test_os.py --phase G10 --component release-images --manifest /absolute/owned/manifest.json --release-bundle /absolute/distributed-release --release-manifest-sha256 RETAINED_BUNDLE_DIGEST --release-module /absolute/independent-install/module --image-manifest /absolute/new-images/manifest.json --image-manifest-sha256 RETAINED_IMAGE_DIGEST --cache /absolute/shared/build-cache --capacity-root /absolute/shared/capacity --report /absolute/private/image-conformance.json
```

Storage restart refreshes only a verified original PostgreSQL resource's
volatile loopback port in its signed creation ledger. It preserves holds,
disposition and container/volume/image identity. Owned-volume accounting uses
a fixed read-only metadata walk with the same apparent-byte/inode semantics as
the selected Engine. It mounts only that attested named volume, emits numeric
bytes and confirms helper teardown within the original twenty-second deadline.
Missing ownership, incomplete output or late/unconfirmed teardown stays a
failure. Keys, artifacts and unrelated resources are retained.

The owned capacity probe may open one fresh Unix socket after a connection is
refused before any HTTP bytes are sent. Both attempts share the original
deadline. Established HTTP requests, command creation and command start are
never replayed after uncertain transport or completion.

Qualification reports retain exact lifecycle timings and pinned private
measurement references from completed passing cases. Failed aggregates remain
failed and retain their independently installed package binding when available.
The bounded `tools/qualification_evidence.py` reader verifies report/source
archive pins and exact parameter/profile coverage; semantic journey review and
current dependency/artifact compatibility remain separate requirements.

The source-side `tools/final_qualification.py` checker requires all 56 journey
IDs and every facet in the maintained `tests/final_requirements.json` authority.
It binds reachable assertions to exact test, helper and fixture source, requires
reviewed runtime/physical/browser closure with matching referenced bytes, and
independently verifies each observed raw source archive and installed G10
artifact set. Missing parameters, changed dependencies, source-side tooling
reports and substituted evidence cannot qualify. Static reachability still needs
reviewed runtime evidence; JavaScript, generated programs and method dispatch
need their explicit closure review. Changed source or artifacts require a separate
source-side approval naming exact cases, profile, original report bytes, both
source/artifact sets, every changed dependency and pinned supporting evidence.
The report cannot approve itself. Expected refusals bind an exact reachable
`pytest.raises` block, exception expression and any separately approved transaction
context. Shadowed imports, dead blocks and uncalled helpers cannot supply proof.
Lexical helpers inside control blocks still require exact reachable calls;
ambiguous declarations and helpers from another lexical scope are refused.
Exact keyword-only callbacks also bind the dispatcher call, lexical leaf,
keyword and invocation AST with separate pinned execution proof. Reassigned,
shadowed, dead or expanded bindings are refused; complete runtime/fixture review
and compatible actual parameters remain required. Object dispatch stays separate.
Legacy reports that omitted installed metadata need separate source-side proof
for original execution logs, bundle/install receipts and exact package/source
verification. Their original bytes, status and completed subset stay unchanged.
A recovered receipt cannot replace existing metadata or waive current compatibility.
The reader does not infer semantic coverage or
update acceptance flags. G10 and all final journeys remain pending.

The controlled extraction benchmark freezes sixteen agent-authored synthetic
explicit, inferred, no-memory and conflict judgments before scoring actual
isolated SDK children. Planted omissions, unsupported suggestions and rejected
foreign attribution remain visible in its measurements. This qualifies the
measurement/staging boundary; learned-model accuracy, independent human gold
and canonical owner acceptance require their own evidence. Retrieval scores
remain a separate measurement.


Prerequisites: Python 3.12, uv and Node 22.18+ within 22.x. Install only from the
independent frozen locks:

```sh
cd modules/agentic-os
uv sync --frozen
npm ci --prefix ui --ignore-scripts
npm run build --prefix ui
uv run --frozen agentic-os preflight
uv run --frozen agentic-os serve
```

The explicitly labeled synthetic health shell opens at http://127.0.0.1:8890.
The existing application assistant remains the default. `preflight` performs no service
writes or host discovery; environment variables such as DATABASE_URL and APP_ENV
cannot choose an OS target. Nonlocal and production profiles are refused.

```sh
python3 tools/test_os.py --phase G00
python3 tools/generate_contracts.py --check
python3 tools/generate_vectors.py --check
uv build --wheel
```

The guarded phase runner builds the shell, validates shared Python/TypeScript
fixtures and installs the wheel outside the checkout before booting an actual
HTTP service. Unknown/unimplemented phases, foreign suite paths and skipped/empty
required collections fail rather than receiving a green status. Later integration
phases require a separately owned target manifest before collection.

### Development checks and acceptance

Use short development runs during edits. `--iteration` defaults to the registered
unit/contract suites; repeat `--suite` to select affected registered test files or
directories. All existing target, capacity, environment and source guards still
apply. A selected collection reports `scope: iteration` and cannot certify a
component, phase or final journey. Empty, skipped, failed or interrupted selections
remain unsuccessful.

For a failed parameterized case, repeat `--case file::test_function[parameter]`
within an explicitly selected `--suite`. Case selection requires `--iteration`,
cannot broaden that registered selection, and records exact `caseSelection`
metadata. Retain compatible completed passes and resume failed/unstarted cases;
keep the original failed report failed.

```sh
python3 tools/test_os.py --phase G00 --iteration --report /absolute/private/work/fast.json
python3 tools/test_os.py --phase G04 --component amended-input-preparation --iteration --suite tests/integration/effects/test_input_preparation.py --manifest /absolute/owned/state/manifest.json --report /absolute/private/work/affected.json
```

Run affected real-service regressions at a development checkpoint. Reserve the
complete cumulative collection for a coherent integrated feature checkpoint,
phase acceptance, release, or a shared-boundary change whose risk requires it.
Do not run it after every small edit or private slice. Development commits retain
their pending acceptance status; only the required complete matching-source gates
can verify a milestone. The host regression remains required before a completed
repository change is committed or handed off.

Without `--iteration`, the original registered acceptance collection is unchanged
and `--suite` / `--case` are refused. Reports retain each test's duration and available setup,
call and teardown timings, plus the slowest 20 cases. They omit JUnit failure
payloads and credentials; full private logs stay in the selected evidence area.

### Deterministic schedules and registered events (G08)

The explicit local synthetic schedule profile supports reviewed deterministic
reads, named staging results and previously owner-verified restricted Wasm tools.
It uses one `ScheduleDriverWorkflow/1`, durable Temporal timers and separately
admitted `ProactiveTaskWorkflow/1` tasks. The browser, API and worker repair loop
are not additional scheduling authorities. No model inference is repeated for a
deterministic cycle. Default startup remains the health shell.

Select an owned installation with applied/frozen control0054, installed reviewed
policy and ready private Temporal service. Run the API and proactive worker in
separate processes; the existing kernel worker remains necessary for interactive
chat tasks on its original queue. Use the same absolute private configuration,
manifest and actual local policy port in both proactive processes:

```sh
agentic-os schedule-serve --manifest /absolute/owned/manifest.json --config /absolute/private/local-config.json --policy-port 8891
agentic-os schedule-worker --manifest /absolute/owned/manifest.json --config /absolute/private/local-config.json --policy-port 8891
```

The chat shortcuts create a draft. Open Schedules to choose a registered workflow,
calendar or operator-approved event source, inspect the shared next-run preview
and review the exact revision before activation. Calendar inputs distinguish
wall-clock and elapsed intervals, pin tzdata2026.5 with an explicit
skipped/repeated-hour policy and overnight windows. SKIP is the default catch-up
policy; bounded coalescing is restricted to safe reads. Activation has a finite
validity, per-task limits and original causal-root/daily ceilings. It grants no
future high-risk write permission or shell execution.

Pause, revise, remove and revoke fence future admission. Stop targets an exact
already admitted private task. Unknown usage after a running worker dies remains
reserved and the original task is quarantined; restart cannot manufacture a
successful result or release that usage. Slot/event identities and dispatch
intents preserve deduplication and lost-acknowledgement recovery. Controls retain
the original command UUID and payload after an uncertain response.

Registered ingress authenticates exact wire bytes before parsing, binds audience,
source, event ID, timestamp and approved owner/resource scope, and quarantines
conflicting event IDs. Event payloads are hints; predicates read current governed
host state. Source control revocation works independently of usage-learning
consent. The bounded dispatcher preserves original causal roots and deadlines.
Private notifications support quiet, change-only and cooldown policies, link to
the actual encrypted task receipt, and acknowledge one owner's notification.
Schedules, notifications and paged execution history share the same owner-scoped
service and clear when the active owner changes.

G08 has complete cumulative coverage of 4,251 registered Python cases, 1,435
JavaScript checks and 444 closed contracts. The current complete fast/independent
artifact checks cover 2,453 cases; 64 new service/browser cases and 42 legacy
identity/task/history cases have actual passing evidence. The current required
serial host run passes 48 repository, 235 API and 58 frontend checks, migration
drift, build/types and the real WP embedded-assistant browser in 456.46 seconds.
Protected financial/source records, private material and frozen migration bytes
remain exact. Nine completed cases are retained from the original failed timer
aggregate; its corrected history-chain check and remaining 55 cases pass on
unchanged runtime bytes. Failed reports remain failed. No single full final-source
suite is claimed.

Qualification is cumulative under the recorded impact-based policy. It includes
actual two-host browser controls, browser/API closure with a killed/restarted
worker and minute-spaced tasks, physical running-worker death, both continuation
bounds, encrypted replay and a replacement worker with a compatible added query.
The query addition does not qualify arbitrary future worker builds. Restricted
Wasm pin checks execute the previously observed verification artifact; synthetic
unallocated Core metadata in that fixture does not claim another Core job or
native performance run. The protected populated0054 rehearsal preserves the
original G06/G07 installations; further DDL must start at0055. This local Chromium
and Darwin ARM64 scope leaves G09 recovery/load, production identity/placement,
Linux native and all 56 final release journeys separately pending.

Contracts are authored in tools/schema_source.py. Codegen v1 is deliberately
restricted to its supported schema vocabulary and emits JSON Schema 2020-12,
Python TypedDicts and TypeScript types. Runtime validators use the same packaged
schema without network resolution. Never edit generated artifacts. Semantic
authorization, DAG, freshness and resource normalization checks complement schema
validation in the owning service; structural fixtures alone do not prove them.

`agentic-os.hash/1` preserves values and array order, sorts ASCII keys and rejects
floats, unsafe integers, duplicate JSON keys and unpaired surrogates. Exact decimal
and large integer values use registered schema-normalized strings. Browser hashing
is inspection only; server decisions remain authoritative. The released safe A2UI
catalog is an OS-owned closed subset. The development assistant validates both
its owned contracts and the pinned upstream A2UI v0.9 server/client schemas,
offline. It executes no downloaded renderer, functions or arbitrary URLs.

### Independent assistant development profile

Task and source views fence superseded responses, including same-session erasure.
Uncertain persona and memory writes retain their original command and payload in
the private frame until explicit retry resolves the outcome. Memory controls block
unrelated writes during recovery; closing and reopening the memory panel retains
the pending command. Input capture and task admission also retain their exact
commands: retry uses the acknowledged input and recovers the original task instead
of submitting a second request. Typed replies must match the original command ID.
No command payload or session key is placed in browser storage. Session end discards
pending private state; it never replays an old owner's command for another owner.

An explicit local runtime can select `enable_assistant_ui(local_synthetic=True)`
after the task/presentation profile is selected. Registered parent origins and
the `agentic-os.safe/0.9.1` catalog are required. The separate OS frame owns its
nonextractable proof key, in-memory session, encrypted persona, accepted surfaces,
source inspection and selected memory controls. Hosts load the public
`/os/ui/assets/embed.js` placement adapter and supply authenticated bootstrap.
The synthetic host sign-in button stays disabled until its loader and event
handlers are ready. The two-host browser check delays the loader to verify this
boundary before exercising the real sign-in and assistant flows.

The frame requires no cookie or persistent browser storage. Default health startup
does not activate it. A browser checkbox cannot issue an owner approval.
Placement grants scripts, the frame's independent origin and native form events;
the OS content policy refuses native form destinations. Popups are denied by default.
Hosts that explicitly select the qualified review profile may pass
`allowReviewPopups: true` to permit its fixed top-level confirmation windows;
this browser permission supplies no server review or effect authority.

The separate development selection `enable_assistant_review(driver,
local_synthetic=True)` requires that same owned runtime, its qualified exact-input
driver and a registered profile that permits high-risk review. Registration
requires the operator to select that exact local profile through
`registry.select_local_synthetic_review_profile(application_id, profile, operator_token,
local_synthetic=True)` before registration; default registration still rejects
high-risk profiles, and a changed profile requires its own explicit selection.
Generic controls use the application's registered resource schema and preserve omitted fields,
explicit nulls and exact decimal strings. Preparation opens no effect lane.
The fixed OS `/review` window displays the current application-normalized diff;
a separate fixed local assurance origin requires a fresh owner credential for
approval or rejection. Window messages bind the exact origin, window and nonce.
Owner/session end clears private review state. Lost replies retain the original
input, admission, challenge or decision command for recovery. Edits use the
original finite task root; Stop remains truthful about accepted remote work.
Only an observed application receipt reports the effect outcome. This explicit
synthetic browser profile is under G07 development qualification.

When the separately provisioned memory-task profile is selected, the composer
offers General and the owner's active recall contexts. Admission binds that
exact context to the original task; lost replies retain it during recovery.
The profile accepts at most1,000 Unicode characters and never truncates input.
“Inspect memory used” checks the task's exact private memory revisions and current
projection before displaying them. Local memory changes clear derived views;
open task views recheck current memory and task access every15seconds. A failed
check withholds the prior reply. Protected application knowledge passages are
not exposed by this inspector.

The selected-source profile offers opaque choices from current completed tasks
at `/os/ui/tasks/{id}/learning-options`. The owner can select the original accepted
message or the bounded fact that an accepted read finished. Changing application
values are not retained as personal facts. Each selection uses the existing
consent/epoch/source checks and retains its exact command after a lost reply,
including across panel closure. Source selection and reviewed canonical memory
remain separate operations. These additions remain under G07 qualification.

Personalize offers a local preview of all ten companion moments, plus manual
motion pause. The live task keeps its actual status. Reduced motion and an
offscreen frame pause the rendered timelines. Source inspection fetches16 records
at a time and displays at most64 from the accepted owner selection. Compact signed
continuation cursors fit the frozen contract and bind the owner, surface, evidence,
revision, policy generation and accepted source digest. Each page checks current
host versions and permissions; a changed version or revocation clears old content.

Accepted Markdown headings, bounded tables and fenced code are rendered as text
through the owned catalog. Links, images, HTML and incomplete or oversized blocks
remain literal text. Native page navigation clears the frame's proof key, session,
pending requests and private view before history capture; a restored page cannot
reuse that session. Stop retains its original command after an uncertain reply
and blocks new work until recovery. Human-wait tasks continue polling an accepted
Stop until its original finite task reaches a terminal state. Trusted review also
ends a live confirmation window when Stop is requested and blocks new confirmations
while its reply is uncertain.

A reviewed task in `RECONCILING` remains stoppable when its canonical control is
`ACTIVE`, including after the foreground stream ends and History reloads. A lost
Stop response recovers the original command. A committed application receipt
stays visible under current owner access while uncertain usage remains held;
Stop neither repeats the effect nor turns that receipt into settled accounting.
The installed reviewed worker hands off its first accepted preparation for the
separate owner ceremony without issuing another model call.

`VerifiedRetainedComparison` adds an explicit retained-observation pin over the
same exact analysis, plan and SDK wire as `VerifiedNarratedComparison`. Bind-time
capture checks stay mandatory. Later authorized observation and History use the
accepted original planner input, the complete discovery lineage and the existing
private goal, without reopening an expired admission capture. This profile does
not renew execution, source authority, private retention or resource deadlines.
Erasing the committed goal with the existing maintenance path removes its answer
and retained question from observation; older profile pins keep their semantics.

The `assistant-ui` component's guarded iteration selects actual unrelated-host
browser, identity and streaming tests. Its partial scope cannot close G07.
The `wp-ui` component also requires explicit private `--host-config`, remote
`AGENTIC_OS_HOST_ORIGIN` and `AGENTIC_OS_BROWSER_ORIGIN` fixture bindings; host
credentials and database URLs never enter OS tests. Bundled UI dependency
inventories and full notices are published separately at
`/os/ui/assets/ui-inventory.json` and `/os/ui/assets/third-party-ui.txt`.
Upstream schema/license pins live in `ui/protocol/a2ui/pins.json` and are included
in the independently installed wheel.

Examples and test fixtures are synthetic, excluded from the wheel, and do not
authorize a private read or write connector. Build products, secrets, runtime state,
downloaded dependencies and evidence stay outside source control. See notices/ for
dependency license provenance and deploy/profiles/ for explicitly disabled lanes.

The G01 local foundation adds owned PostgreSQL 16.15/pgvector 0.8.7 storage,
separate migration/runtime roles for six component databases, encrypted immutable
artifacts, and original Temporal/Core migrations. These are storage components;
`storage-ready` does not enable agent, memory, write, native or schedule lanes.

The full foundation installer currently qualifies **macOS on Apple silicon with
Docker Desktop**, two Docker CPUs and at least 4 GiB Docker memory. API packaging
and wire contracts are independent of that placement; other installer/native
placements need their own qualification. Core source and its Go toolchain are
hash-locked in deploy/source-lock.json; archives are downloaded only by explicit
installation. Upstream migration code and licenses remain unmodified.

Select an explicit local Docker Unix socket and a **new** private state directory.
The installer rejects existing directories, remote Docker endpoints, inherited
host database settings and unqualified profiles. Do not enter credentials in CLI
arguments or logs. The following paths are examples; use your own new absolute
state directory and local Docker socket:

```sh
agentic-os preflight --docker-endpoint unix:///absolute/local/docker.sock
agentic-os plan --root /absolute/new/state --docker-endpoint unix:///absolute/local/docker.sock
agentic-os install --root /absolute/new/state --docker-endpoint unix:///absolute/local/docker.sock
agentic-os readiness --manifest /absolute/new/state/manifest.json
agentic-os serve --manifest /absolute/new/state/manifest.json
agentic-os stop --manifest /absolute/new/state/manifest.json
agentic-os start --manifest /absolute/new/state/manifest.json
python3 tools/test_os.py --phase G01 --manifest /absolute/new/state/manifest.json
```

Every physical test/migration connection checks the private signed manifest,
owner, resource labels, immutable image, endpoint, mounts, resource limits,
component database, selected role and server version. The runner attests before
collection and the OS conftest attests again. No host test suite/guard is imported.
Runtime roles cannot create permanent or temporary tables, create databases/roles,
connect to another component database or rewrite migration metadata. Component
pools have explicit caps and bounded waits; callers own short transactions.

`/os/health` describes the shell; `/os/readiness` with an explicit installation
reports component storage availability and returns 503 on degradation. Operator
credentials, DSNs and content are omitted. Installation failures retain private
state/evidence and block readiness; startup never seeds or reruns migrations.
Stop preserves labeled volumes and private artifacts. Start validates the existing
resource before restarting it. Local installation and tests reserve host/Docker
headroom and reuse verified immutable build inputs while keeping writable stores
and keys independent. Explicit retirement is limited to stopped fixtures declared
disposable at creation; historical and recovery-dependent resources stay retained.
See [local resource operations](LOCAL_RESOURCES.md) for capacity, cache, signed
dispositions, preview-first provider retirement and preserved recovery evidence.

```sh
agentic-os backup --manifest /absolute/new/state/manifest.json
agentic-os restore --backup /absolute/snapshot/uuid --root /absolute/new/restore-state --docker-endpoint unix:///absolute/local/docker.sock
```

This recovery profile supports **quiescent G01 foundation snapshots only**. It
refuses active tasks, pending dispatch, component execution and later schema
revisions. Snapshot encryption/receipt checks cover all six databases and owned
key/artifact files. Restore accepts only fresh empty labeled targets with the same
logical installation identity, reconciles counts and reestablishes role permissions.
A partial restore stays blocked; never retry by resetting populated stores.
Local recovery keys are private operator files beside the encrypted snapshot.
Separate key custody, live Temporal/Core watermarks, newer forget-journal replay
and host-effect reconciliation belong to the later recovery gate and are not
claimed here. Preserve the original installation and test the restore before any
consumer is enabled.

Installation also creates a 30-minute, one-use administrative bootstrap in the
private `operator-bootstrap.key` file and a signed state record. A local operator
adapter consumes it under an exclusive lock and rotates to `operator.key`; its
bootstrap credential never becomes an operator credential. Failed/expired/replayed
bootstrap cannot mint access. These keys never enter URLs or normal logs. Host
users and application admins do not acquire OS operator authority. Restore creates
a fresh bootstrap and does not restore an old operator credential. G02 owns the
administrative registration interface; no personal-data admin reader exists.

## Identity component and its original partial checkpoint

The component factory now connects two independent, authenticated Python/SQLite
and Node/document-store hosts over HostBridge/1 and actual MCP HTTP, with OPA
policy decisions. Operator-reviewed immutable registrations bind endpoints,
schemas, capability ceilings, bot revisions and local client profiles. No model
or browser chooses a connector, subject, permission or SQL target. The fixture
hosts are self-contained examples; their SDK locks do not become host framework
requirements.

The local synthetic frame transport uses a validated public P-256 key, strict
ES256 proofs, 30-second one-use bootstrap, persisted replay protection and
five-minute key-bound sessions. Bridge credentials, browser credentials and
resource-audience MCP tokens are distinct. Current host authority and local
revocation are checked before invocation and again before returning evidence.
Host failure, undefined/malformed/stale OPA decisions and unknown schemas deny.
This is not qualification of production OAuth, native clients or actual iframe
behavior; the browser frame matrix belongs to G07.

An explicit component run is different from a phase pass:

```sh
python3 tools/test_os.py --phase G02 --component identity --manifest /absolute/owned/state/manifest.json --report /absolute/private/evidence.json
```

A component report never closes a phase or the final journeys. The default CLI
still serves only the health shell. Owned migration head is now `os_pg_0007`;
head0005 enforces the finite dispatch repair bound and head0006 adds the
explicit partial G03 budget/attempt ledger. Additive head0007 labels immutable
accepted results with their closed contract; existing StageResult bytes retain
their original schema. The drift
check includes every named, validated model CHECK in addition to Alembic's
comparison; database rejection tests verify the relevant constraint semantics.
normal startup does not migrate it. The old G01 backup supports only
`os_pg_0002`, and refuses the new identity schema, even when apparently idle.
The retained backup regression uses a separate fresh foundation target. The
later recovery phase must handle session invalidation and privacy watermarks
before recovery for the new release can be enabled.

EvidenceCore/1 hashes the closed EvidenceBundle/2 fields excluding coreDigest,
plus records in the same order as resourceRefs, using hash/1 purpose `evidence`.
Each row must have unique requested fields; each unique resource must match the
requested type/IDs and current owner bounds. Empty selections are rejected;
they never mean implicit access to all records. Retrieval/evidence does not
create authority.


## Atomic admission and real Temporal transport (G02)

122 closed contracts now include an owner-only input-capture command. Raw user
text is encrypted provenance, never normalized intent or permission. One input
can admit one task. Command, task/control, visible segment, immutable admission
and dispatch commit together before HTTP 202. Matching retries return the same
accepted IDs; conflicting payloads reject. Bot definitions cannot change under
a previously published revision. Additional attachments remain disabled.

The explicit local Temporal lifecycle uses the digest-locked 1.32.0 image and
original component schemas, separate roles and an owner-signed service binding.
Private configuration is read-only mounted; no credentials are placed in CLI,
normal environment or logs. An owned internal PostgreSQL network and separate
owned RPC bridge publish only the frontend port on loopback. This local synthetic
profile uses the explicit no-auth server option; production networking/authentication
remain disabled and unqualified. No model or sandbox receives its service endpoint.

```sh
agentic-os temporal-start --manifest /absolute/owned/state/manifest.json
agentic-os temporal-readiness --manifest /absolute/owned/state/manifest.json
agentic-os temporal-stop --manifest /absolute/owned/state/manifest.json
python3 tools/test_os.py --phase G02 --manifest /absolute/owned/state/manifest.json
```

The dispatcher closes SQL before RPC. Random lease-token CAS, stable workflow IDs
and original-history input verification handle duplicate/lost starts. Claims are
bounded/fair across applications, retries finite, poison repair audited and capped.
A stopped/expired task is quarantined without asserting that remote work was undone.
Actual worker/service restart, concurrent claimers, late acknowledgments, rollback
and host-outage tests use the minimal G02 sink. That sink is test-owned, not an agent.
The runtime factory enables this transport only explicitly; default CLI remains a
health shell. G03 supplies actual cognition/budgets/streaming. G01 recovery still
refuses heads beyond 0002; live recovery belongs to G09. No backup readiness is implied.

WP adds a separately tested thin connector, with no OS import or financial migration.
Its host-owned conformance gate is documented in the host operating guide; independent
G02 tests need no WP database. Complete final E/P/M/V journeys remain pending.

The independent verification runner serializes dependency installation, build and
actual tests with a private, persistent checkout lock. Concurrent component
callers wait at most 15 minutes; they cannot replace Node/Python dependencies
under an active suite. This tooling lock grants no task or host-effect authority.


## Partial G03 execution ledger

The explicit budget component creates a frozen root and child binding in the
same admission transaction before 202. Subtasks and grandchildren consume the
original lifetime fan-out and share stage/read/token/duration ceilings; they
cannot create new roots. Integer usage is reserved before work. A started
uncertain attempt retains its reservation, including after Stop. Only trusted
measured usage settles it; unexpected overspend is recorded and quarantined.
An expired attempt cannot accept a result. Never-started reservations alone
may be released. Accepted internal results are encrypted, pinned and immutable.
They are not public chat messages or permission grants.

```sh
python3 tools/test_os.py --phase G03 --component budgets --manifest /absolute/owned/state/manifest.json --report /absolute/private/evidence.json
```

This component is deliberately opt-in and does not enable inference, product
workflows, SSE, effects, memory, native execution or schedules. G03 remains
unavailable until those required cognition/history/stream gates pass. Agno
3.1.1 is locked independently; its presence does not qualify an LLM provider.
The head0005-to-head0006 rehearsal preserves every existing control-table
fingerprint and leaves new tables empty. It is a schema-upgrade check, not
live recovery. Migration head0006 is immutable once applied.

## Partial G03 private workflow history

The separate product client encrypts Temporal payloads with an owned, versioned
codec bound to the actual namespace and installation/application/task workflow
identity. It retains old keys for rotation and rejects missing keys, foreign
context, corruption, oversized payloads and plaintext. The G02 transport sink
and its historical encoding remain unchanged. Encryption does not authorize
source hydration or disclose private planner output.

Product workers must use the qualified `private_worker` factory. Its asynchronous
Activity interceptor discards private exception messages, details, causes and
traces before the SDK logs them; timeout/cancellation semantics remain safe.
Reviewed workflow definitions use bounded concurrency and explicit pools. Sync,
standalone and Nexus Activities are disabled until separately qualified.

Actual server tests cover encrypted success, failures, validation errors,
heartbeat/timeout data, service and worker restart, key rotation and unavailable
old keys. Replay retains the real namespace: the SDK's default ReplayNamespace
cannot decrypt this bound profile. Incompatible reviewed workflow builds reject
replay. Logs and stored histories are checked with private canaries.

```sh
python3 tools/test_os.py --phase G03 --component history --manifest /absolute/owned/state/manifest.json --report /absolute/private/evidence.json
```

This is a component gate, not completed G03 or live recovery. Replay has a
2,000-event input bound and a 30-second asynchronous deadline; thread shutdown
is cooperative, not a hard CPU kill. Model-generated/native code requires the
later isolated executor. Inference, product task execution, public streaming,
effects, memory and schedules remain unavailable. See the SDK's
[data handling contracts](https://docs.temporal.io/develop/python/data-handling)
for converter/codec behavior; this module's explicit profile is stricter.


## Partial G03 bounded cognition

The explicitly enabled cognition component uses actual Agno 3.1.1, registered
bot definitions, current HostBridge/OPA authority and MCP reads. Its qualified
local-synthetic model proposes a bounded DAG from captured **typed user read
selections**; unknown natural-language targets return a targeted clarification.
Selected identifiers/fields are sealed with captured provenance. Model output
cannot invent resources, permissions, endpoints or trusted numeric facts.
The compiler rejects cycles, unknown references and missing evidence barriers.

Each fresh Agno instance makes at most one reserved provider call. SDK retries,
learning, persistence, automatic tools, reasoning models and telemetry are
explicitly disabled. Inherited AGNO_DEBUG/AGNO_TELEMETRY=true is refused because
the SDK can override constructor flags. The OS broker executes compiled reads
only after a live task/control/authority check immediately before the MCP call.
SQL sessions close before provider/network awaits. Two-stage root ceilings cover
planning/synthesis or one explicit semantic repair; repair recovery reuses its
own accepted invocation. UNKNOWN or settled-but-unaccepted calls are never
blindly regenerated. Cancellation retains truthful unresolved accounting.

Grounded output uses reviewed narrative templates plus exact typed field/table
slots from accepted host evidence, with structured citation refs. Decimal strings,
nulls, zeros and identifiers retain host semantics. Provider reasoning and raw
model claims never enter the public answer contract. This narrow formatter does
not establish arbitrary natural-language accuracy or qualify an external model;
external/subprocess profiles need separate usage, egress and lifecycle gates.

```sh
python3 tools/test_os.py --phase G03 --component cognition --manifest /absolute/owned/state/manifest.json --report /absolute/private/evidence.json
```

The gate includes earlier storage/identity/transport/budget/history suites and
actual two-host Agno/MCP tests, repair replay, lost acceptance ACK, pre-commit
failure, Stop, per-host saturation and cancellation. It does not activate a
product workflow, streaming endpoint, effects, memory or final journeys. The
populated head0006→0007 rehearsal preserves 2,596 old rows across 25 tables,
with old accepted results labeled StageResult. Applied migrations remain immutable.

## Partial G03 persisted public streams

An explicit test component exposes authenticated task snapshots, Stop requests
and fetch-SSE replay. Default startup remains health-only. A new closed AG-UI
profile uses the actual 1.0.0 event models/encoder; old PublicStreamEvent/1 and
Temporal transport histories remain unchanged. Provider reasoning, raw events,
arbitrary metadata, arguments and invented financial values cannot enter it.

Internal publication reconstructs the answer from exact accepted typed results,
captured selections and current HostBridge/OPA permission. Current control,
deadline, root budget and owner checks fence one transactional event batch plus
task/segment state. Per-conversation sequences and stable producer UUID/digests
deduplicate retries; a failed commit produces neither events nor completion.
Terminal segments reject later progress. Backlog is capped at 4,096 events per
conversation in this initial profile; reaching capacity parks publication.
Retention/compaction and private deletion belong to later qualified lifecycle.

Replay cursors are encrypted, owner/conversation/session/generation bound and
expire after five minutes. Reconnect repeats current resource authorization;
changed visibility never relabels old content. Projection/session changes emit
a safe reset; task snapshots provide current authorized state. Events page at
16, streams rotate after 30 seconds and human-input review closes immediately.
Each flush rechecks authority/projection. A five-second socket-send bound detaches
slow consumers; four streams per host and sixteen overall contain backlog.
Transport disconnect cannot cancel a persisted task. No SQL session crosses an
await. Stop acknowledges only the saved request: unresolved accepted work is not
claimed cancelled or rolled back. Its durable reconciliation is the next slice.

```sh
python3 tools/test_os.py --phase G03 --component streaming --manifest /absolute/owned/state/manifest.json --report /absolute/private/evidence.json
```

This service skeleton has actual two-host HTTP streams, current-access failures,
reset/replay, database commit failure and restart tests. It does not close G03:
the product task driver, durable >110-second input wait and bounded continuation
remain required. Actual A2UI rendering, avatars, memory and effects remain later
gates. The synthetic cognition profile produces validated structured blocks;
it does not simulate token streaming by typing out a completed answer.


## G03 private durable task driver

The new **OSTaskDriver/1** profile uses encrypted history on an owned os-kernel
queue. New migration os_pg_0008 adds an immutable dispatch profile; existing
rows remain OSAdmissionTransport/1 and its workflow is unchanged. Dispatchers
claim only their own profile, with the original stable workflow/command identity.

Actual Agno planning, each admitted MCP read and response compilation run in
separate bounded Activities with maximum attempts one. Activity failure permits
one accepted-result lookup recovery, never another generation/read based on an
empty result. Unknown started work remains reserved and quarantined. Downstream
steps cannot silently regenerate a missing plan/read. Stop settles known usage
and acknowledges only after no unexplained in-flight capacity remains; status
reconciliation cannot grant read/effect authority. Input waits close streams,
poll persisted control every five seconds and Continue-As-New at a bounded
history threshold from the main loop with bounded opaque state. A 60-second
workflow bookkeeping grace never extends the original task authority deadline.

Explicit local component commands (separate terminals/processes; reviewed OPA
installation/server and owned aligned storage/Temporal must already be ready):

```sh
agentic-os kernel-serve --manifest /absolute/owned/manifest.json --config /absolute/local-config.json --policy-port 8891
agentic-os kernel-worker --manifest /absolute/owned/manifest.json --config /absolute/local-config.json --policy-port 8891
python3 tools/test_os.py --phase G03 --manifest /absolute/owned/manifest.json --report /absolute/private/G03.json
```

Config selects the OS loopback port; policy credentials stay in owned private
files, never command arguments or host/browser environment. Normal startup does
not migrate/seed/install or auto-import host data. The worker consumes committed
PG dispatch intents and reconciles saved controls in finite rotating batches.
Default serve remains the health shell and WP's existing assistant is unchanged.
Effects, memory, sandbox jobs, schedules and the final assistant UI remain later
phase gates. This synthetic read profile is not production identity/inference
qualification. All 56 integrated final journeys remain pending.

The G03 gate includes actual two-host processing, phase-specific lost Activity
ACKs, current authority, truthful unknown/Stop accounting, independent worker
process startup, failed-commit rollback, encrypted replay, history continuation
and a real >110-second closed-stream wait spanning worker/service restarts.
A populated encrypted head0007-to-0008 rehearsal preserves all 8,655 old rows
across 25 tables. Retained keys/history/build compatibility and independent
host regression are mandatory before promoting this milestone.

## G04 host effect component (phase remains pending)

Separately owned Python and Node transactional hosts now exercise typed staging,
exact proposal/schema/version binding, authenticated permit introspection and
atomic local mutation/receipt/audit/outbox. The existing Python read host and
Node JSON host remain read-only. New effect envelopes wrap frozen contracts
without changing the meaning of earlier admissions or transport histories.

```sh
python3 tools/test_os.py --phase G04 --component host-effects --manifest /absolute/owned/manifest.json --report /absolute/private/host-effects.json
```

This component includes all earlier G03 suites and actual two-language provider
races, lost replies, restart, rollback, current policy, cancellation tombstones,
truthful pending work and bounded delegation. It uses an explicitly synthetic
permit fixture; it does not promote OS approval/continuation/effect workflows or
final acceptance. The default service still exposes no write lane. See the
transactional host example for guarantees and remaining limitations.

## G04 per-segment authority component (phase remains pending)

The trusted `effects.authority.ExecutionAuthority` primitive stores immutable,
owner-scoped interactive read grants separately from original task admission.
Grants pin source intent, segment/control epoch, bot/registration/policy revisions
and the original budget root, and expire no later than the current session or
immutable task/root deadline (five-minute maximum). Grant references are neither
browser credentials nor permission to execute: each admission repeats live host
and OPA checks plus local transactional guards. Revocation is separate and
immutable. No ORM session spans external checks.

This preparatory component has no model/browser endpoint and grants no writes or
background delegation. It does not extend G03's 45-second read task lifetime,
modify frozen v1 ledger/workflow semantics or complete OS HITL. A fresh read
segment may use a fresh session only through this separate grant factory. The
remaining G04 reviewed/delegated execution profiles must integrate their own
explicit authority-aware guards before consuming any grant.

Additive owned control migration `os_pg_0009` introduces scoped grant/revocation
tables and immutable guards; applied revisions 0001–0008 remain unchanged. A
quiescent encrypted populated clone rehearsal preserves every old column/row
before upgrading the owned target. Host financial schemas remain unchanged.

```sh
python3 tools/test_os.py --phase G04 --component execution-authority --manifest /absolute/owned/manifest.json --report /absolute/private/authority.json
```

The combined component gate includes all prior G03 suites and actual two-host
transactional envelopes. Component verification does not promote complete G04
or any final E/P/M/V journey.

## G04 typed preparation qualification (phase remains pending)

The separate internal `effects.broker.EffectBroker` preparation primitive
intersects current OS identity, the host login/session bridge, the separately
registered effect provider's resource/field policy, bot ceilings and a pinned
OPA preparation policy. The frozen read bundle stays revision 1. Preparation
revision 2 only reports eligibility for typed review; it never authorizes an
effect. Operator-pinned resource schemas cannot be replaced by model or provider
self-description. Validation preserves exact types, leading identifiers and
explicit nulls; immutable host stages are checked for current versions and exact
requested fields before returning a preview. Host receipts remain authoritative.

Additive `os_pg_0010` adds immutable registration-scoped resource schema pins.
Populated protected clone rehearsal is required before owned target migration.
Applied revisions 0001–0009 are preserved. No financial database is migrated.

```sh
python3 tools/test_os.py --phase G04 --component effect-preparation --manifest /absolute/owned/manifest.json --report /absolute/private/preparation.json
```

The `effect-preparation-probe` selector runs only the new provider boundary
preflight; it cannot replace the combined component gate. Neither selector
closes G04 or final acceptance. This internal qualification has no public
model/browser endpoint, review decision, execution permit or automatic task
dispatch. The later G04 trusted-task profile must reserve shared-root work and
resolve exact source intent and current reviewed/delegated authority before
consuming preparation. Default startup remains health-only.


### G04 typed durable admission component

`effects/admission.py` is an internal qualification profile. It accepts only an
exact registered typed update; it does not infer fields from prose. Capture
requires current login, connector-specific resource scope, operator-pinned
schema and separate preparation policy. Admission atomically persists the task,
control, first segment, immutable encrypted source copy, unchanged original
capture, fixed shared-root budget, immutable admission and durable dispatch
intent. The task deadline is independently bounded by the frozen bot definition
and seven-day ceiling. Work still has a separate 45-second ceiling.

`OSTrustedTaskDriver/1` is a reserved dispatch profile. The existing legacy and
G03 dispatchers cannot claim it, and the legacy budget ledger refuses its roots.
No public route, trusted worker, review decision or effect permit is enabled by
this component. A new current session may inspect its owner-private source;
that inspection does not mint authority, change the root or rewrite the initial
session provenance. An expired unadmitted capture cannot start a task.

Additive `os_pg_0011` adds immutable typed captures/task source pins and the new
dispatch profile. Applied migrations 0001–0010 remain unchanged. Protect and
rehearse populated upgrades before applying this revision; code rollback does
not downgrade storage. No financial schema or data is migrated.

```sh
python3 tools/test_os.py --phase G04 --component trusted-admission --manifest /absolute/owned/manifest.json --report /absolute/private/trusted-admission.json
```

`trusted-admission-probe` runs only the new actual two-host admission cases.
Neither selector closes G04. Full HITL continuation, reviewed/delegated effect
dispatch, reconciliation and compensation must pass before this profile can be
selected by the public kernel or later phases can advance.

### G04 current typed preparation authority component

`effects/preparation_authority.py` implements a disjoint internal grant factory
for the exact encrypted task source. It verifies the complete immutable
admission/capture/source/root binding, current login and provider authority,
operator-pinned schema, bot and preparation-policy revisions. Grant metadata
contains hashes rather than raw requested field values. A fresh session may
obtain a new grant while the task is active; neither original admission/source
expiry nor the shared root deadline/ceiling is extended. Grants expire with
the verified current session and within five minutes, and their cumulative
count is bounded to 64 per task. Revocation is immutable and expiry cannot renew
the same command. Local guards repeat after remote revalidation to catch a
concurrent local Stop/revocation before returning current authority.

`PreparationPrincipal` and `TypedPreparationGrant/1` cannot be cast into the
legacy read-grant family. Additive `os_pg_0012` admits only that explicit new
stored contract, preserving all existing grant rows/guards and applied
migrations. Rehearse populated upgrades with protected backups before applying;
code rollback must not downgrade storage. The host financial schema is unchanged.

```sh
python3 tools/test_os.py --phase G04 --component preparation-authority --manifest /absolute/owned/manifest.json --report /absolute/private/preparation-authority.json
```

`preparation-authority-probe` runs only its actual two-host preflight. These are
component gates, not G04 promotion. No public route, worker or execution permit
is selected. Grant-bound shared-root preparation work, accepted immutable stages,
HITL decision/dispatch, reconciliation, delegation and compensation remain
required before complete G04 qualification. Default startup remains health-only.

### G04 grant-bound preparation work component

`effects/preparation_ledger.py` and `preparation_executor.py` implement internal
bounded preparation against the two registered synthetic hosts. Reservation
atomically binds one invocation to the exact current preparation grant, task,
segment, control epoch, source pin and request digest under the original root.
No new grant or invocation can repeat an already attempted immutable intent.
Concurrent starts have one winner. The executor closes SQL sessions before
provider I/O, validates the actual existing host stage, records measured integer
work usage, and commits a protected encrypted accepted result before returning
its reference. No business record, approval or effect permit is created.

Lost acknowledgements, cancellation and failed acceptance retain uncertain
charges and quarantine the root. Cancellation joins bounded owned bookkeeping
before returning, including repeated cancellation during a late begin commit.
A committed accepted reference survives an acknowledgement loss. Current owner
inspection rechecks login, host/OPA scope, protected artifact and record version;
it does not repeat staging or require renewal of the expired work lease.
Metadata lookup is private workflow bookkeeping, never raw-data authorization.

Additive `os_pg_0013` adds immutable scoped preparation-attempt bindings, exact
parent fences and the explicit accepted-result contract. Applied migrations
0001–0012 are unchanged. Protect populated stores, rehearse the upgrade on an
isolated copy and compare every old table before applying. Code rollback does
not downgrade data. The host financial schema remains unchanged.

```sh
python3 tools/test_os.py --phase G04 --component preparation-work --manifest /absolute/owned/manifest.json --report /absolute/private/preparation-work.json
```

`preparation-work-probe` selects only the new actual two-host cases. Neither
selector closes G04 or enables a public trusted route/worker. OS-owned review,
decision/continuation atomics, reviewed/delegated effects, compensation and the
complete durable trust slice remain required before advancing to G05.

The owned Docker adapter exposes fixed failure categories without raw stderr,
arguments or credentials. Only exact metadata reads may repeat recognized
transport failures, at most once within their original timeout. Network inventory
uses the fixed `network ls --quiet --no-trunc` identity listing and
pages of up to32 unique exact daemon IDs; both receive the same
bounded read-only retry. Partial output is discarded and every returned ID and
subnet is revalidated before allocation. Unknown failures still stop the check.
Resource-changing operations never retry, and every successful inspection still passes the complete
ownership/image/network/mount/privilege checks. Missing resources, unknown errors,
malformed results and ownership mismatches remain failures. The phase runner
replaces prior successful evidence when a new run starts and retains failed test
counts/names without exception bodies; a failed run never promotes acceptance.

All owned control-store transactions establish the existing two-second row-lock
and three-second statement limits before exposing a session. This includes
private reconciliation after Stop and metadata lookups, which must not depend on
a later live-owner guard to bound contention. A lock timeout rolls back and leaves
uncertain reservations intact; it does not authorize remote retries or refunds.
Actual two-host lock-contention cases cover reconciliation, accepted lookup and
current grant verification. Network operations still receive detached DTOs after
the SQL transaction closes.

### G04 immutable proposal checkpoint

The preparation-work checkpoint passes 1021 Python / 462 JavaScript cases on
matching OS/WP source, with 17 financial fingerprints unchanged. The next
explicit component adds immutable Proposal/2 metadata and protected exact
diffs compiled only from accepted PreparedChangeResult artifacts. It preserves
the original root/source, rejects stale provider versions and grants no write
authority. Additive 0014 was protected and rehearsed on a restored populated
clone before application; all 93,245 original rows in 31 tables were preserved.
The applied migration is frozen. Checkpoint f23b7a2 passes1094 Python/484 JS/156 contracts,
serial full WP40/232/55/build/drift/remote conformance and17 protected fingerprints.
The complete G04 phase remains pending.

The separate trusted-presentation/1 profile persists safe review-required
metadata and a closed AG-UI segment in the same transaction as the proposal.
Current checked owner inspection returns the exact diff; SSE never carries
raw source, diff, tool arguments, grants or assurance bindings. A 110-second
review leaves SQL/model/SSE closed. The frozen read profile remains unchanged.
Known immutable review expiry reports a conflict without renewing authority;
missing or damaged protected artifacts remain unavailable. The login response
contains no private database session identifier.

Component command: `python3 tools/test_os.py --phase G04 --component proposals
--manifest /absolute/owned/manifest.json --report /absolute/proposals-report.json`
(on one command line from the module). The probe runs only the new actual
two-host service/HTTP cases; it cannot certify the combined milestone. Normal
startup exposes no new lane. Decisions, external assurance, durable reviewed
effects, amendments, delegation, notification and compensation remain pending;
this component cannot promote G04 or any final E/P/M/V journey.


### G04 separate assurance checkpoint a02d958

`ports/assurance.py` defines the pure registration/claim-verification boundary.
`adapters/assurance/local_synthetic.py` selects only an explicitly provisioned,
private, manifest-owned local ceremony service. Its two controller routes and
credentials are separate from host resource/effect routes and owner ceremony keys.
The fixed `local-synthetic-assurance/1` profile is not production step-up or SSO.
It grants no OS decision, effect authority or new public runtime lane.

Fixture provisioning is explicit and only creates new private synthetic resources.
Startup checks pinned existing DDL without schema creation, seed, adoption or
repair. Binding/claim rows are immutable, expire within60seconds, and exact
registration/claim retries preserve original values. Expiry is rechecked after
actual lock waits and response/current-configuration awaits. Exact fixture schema
attestation repeats under the acquired write lock and immediately before commit,
so a schema change during contention cannot authorize registration. No SQL session is
held over network operations. No new dependency or OS migration is required.

Focused command: `python3 tools/test_os.py --phase G04 --component assurance-probe
--manifest /absolute/owned/manifest.json --report /absolute/assurance-probe.json`.
Combined command selects `--component assurance` with the same arguments.
Checkpoint a02d958 passes1168 Python/502 JS/162 contracts, zero skips, full
WP40/232/55/build/drift/remote conformance and17 protected fingerprints.
Actual schema-race failure and corrected passing evidence are retained.
Challenges/decisions/reviewed dispatch are separate later slices.


### G04 registered challenges checkpoint aa7da4b

`effects/challenges.py` registers an immutable challenge intent under the exact
proposal revision/hash, original task/root/source and a fresh current session.
The intent and owner command commit before contacting the separate assurance
service. No SQL connection remains open across registration. Fresh host/OCC
checks and local control/session guards repeat before a separate immutable
verified registration commits. Only then is a closed opaque challenge returned.
Original nonce, creation time and expiry are reused for identical retry; expired
or unpublished intents still count toward the finite eight-challenge ceiling.
Challenge expiry is at most60seconds and no later than proposal/root/session.
Post-commit expiry cannot return usable success. Registration grants no decision
or execution authority.

The explicit fixture alone attaches
`POST /os/trusted/proposals/{id}/challenges`. The owner-only local-synthetic
`/ceremony/confirm` accepts only opaque challenge id and approve/reject; subject
and session resolve on the server. The controller cannot call that route. Old
`/ceremony` behavior and its separately qualified tests remain preserved. This
is not production step-up or the G07 browser assurance profile. Normal API/worker
startup exposes no new lane.

New immutable migration0015 adds exact owner/proposal/session foreign keys and
two review registry tables. Protected full-schema/data restore and populated
0014-to-0015 rehearsal passed with144,036 original rows/33 original tables
unchanged. Clone and primary exact model/CHECK drift pass; applied0001–0015
remain byte-frozen and checksum-protected. A data-only restore into live guards
correctly rejected terminal review history; that failed rehearsal is retained.
Never disable guards or restore over populated targets to bypass this safeguard. Actual two-host HTTP/PG and owner HTTP/SQLite gates
cover idempotence, wrong scope, claim-free public data, lost registration ACK,
Stop/removal, immutable/FK/expiry and actual deferred-commit failure.

Focused command: `python3 tools/test_os.py --phase G04 --component challenge-probe
--manifest /absolute/owned/manifest.json --report /absolute/challenge-probe.json`.
Combined command selects `--component challenges`. The focused129-case actual
service/HTTP gate passes with zero skips. The combined checkpoint passes1247
Python/508 JavaScript/164 contracts, zero skips, serial matching-source full
WP42/232/55/build/drift/remote conformance and17 protected financial fingerprints.
Decisions, reviewed grants, durable trusted execution, amendments, delegation,
notification and compensation remain pending; this component cannot promote
G04 or any final E/P/M/V journey.


### G04 reviewed-host and owner-decision eligibility qualification

The separately pinned OPA3 decision-eligibility profile intersects current host
execute scope, bot ceilings, exact immutable proposal fields/target/version and
the real registered owner assertion. Eligibility is private detached material,
not an owned approval, executable grant or permit. It expires no later than the
five-second observation window and every narrower host/proposal/challenge bound.
The fixed OPA route rejects malformed/undefined responses, changed provenance,
redirects, compressed/oversize responses and unavailable/stale authority.
No SQL session is held across host, ceremony or OPA calls.

An explicit synthetic reviewed-host-effect/1 profile is selected before task
admission in the Python/SQLite and Node/SQLite fixtures. It advertises current
execute scope and checks fresh read access for public receipt disclosure. A
separate observer key permits only a minimal receipt-state route; it cannot
execute, cancel, stage, authorize or create an absence tombstone. Missing receipt
remains UNKNOWN. Legacy host profiles preserve their original semantics.
Observer registration and consumption from stored admitted OS invocations are
separate later primitives, not supplied by these fixtures. Default startup and
existing host assistant routes are unchanged.

Focused command: python3 tools/test_os.py --phase G04 --component eligibility-probe
--manifest /absolute/owned/manifest.json --report /absolute/eligibility-probe.json
(on one command line). Combined qualification uses --component eligibility.
The focused62-case receipt-observer gate passes against both real host services,
including terminal cancellation and late identical retry. Earlier126-case probes
passed124 cases and exposed two incorrect test expectations; their failed
evidence is retained and no runtime guard was relaxed. Complete qualification
still requires the full combined gate and matching-source WP regression.
No new dependency or migration is introduced; all applied0001–0015 remain frozen.
Actual service/HTTP/OPA/SQLite/current-scope tests and same-source complete OS/WP
gates are required before its checkpoint. No phase or final journey is promoted.
Owned decisions, grants, durable trusted execution, delegation, notification,
compensation, governed memory and later UI/native/scheduling gates remain pending.


### G04 owned decisions and closed successor streams — qualification

The explicit owned-review component stores the exact owner decision, protected
core, successor segment and safe status batch atomically. Approval also stores
one immutable, single-invocation ReviewedExecutionGrant and durable continuation
intent with DUE delivery bookkeeping. It does not dispatch an effect. Accepted
approval means APPROVED/queued, never a host COMMITTED receipt. Rejecting uses
separate fresh current read scope and the registered owner ceremony; a changed
host record or loss of write permission does not prevent a current read-authorized
owner from rejecting it. Rejection grants no execution authority.

Known exact retries and accepted-result inspection use fresh read authorization,
independent of write permission/OCC. A fresh login may inspect a decision after
the original session/grant expires, but cannot renew that grant or invocation.
Decisions and continuations are immutable; exact owner/root/segment/grant/challenge
foreign keys and database transition constraints bound delivery bookkeeping. The
additive populated0015-to-0016 rehearsal preserves186,088 original rows across35
original tables. All applied0001–0016 bytes are frozen/checksum-protected. No host
financial schema or data is changed.

An explicitly attached qualification API composes frozen trusted proposal events
with closed reviewed status events. It shares the same finite SSE capacity with
the proposal stream. Separate reviewed cursors and current read checks govern
paging, reconnect and disclosure; private decision cores, assertions, operator
credentials and execution grants never enter public messages. Default startup
and the existing host assistant remain unchanged.

Focused service/HTTP/expiry qualification passes42 service cases,8 actual HTTP/SSE
cases and4 real deferred-commit expiry cases on both synthetic hosts. Strict
JavaScript validation passes561 cases and179 contracts. Retained initial failures
include a missing nested object schema type, a direct-script fixture import and
an unsupported test selector; the fixes preserve validator/target/process guards.
Combined same-source OS and complete WP regression are required before this
component checkpoint. G04 phase acceptance remains pending, including trusted
worker dispatch, server-resolved permits, receipt reconciliation, amendments,
delegation, private notifications and separately authorized compensation.

The first complete decision attempt failed on a closed-object schema check and
a fixture error during bounded owned Docker network inspection. The conditional
claim now uses its full closed schema; nested unknown/missing-field vectors are
included. Thirty subsequent actual metadata inspections and complete ownership
validation pass. The isolated Docker failure has not been reproduced or
reclassified as success. A later attempt was interrupted and did not qualify;
an unfinished JUnit entry cannot be counted as a completed pass. Earlier failed
and interrupted evidence stays retained. The focused regression component passes
127 cases, but the complete decisions gate and serial matching-source WP checks
remain required before this checkpoint. The runner now requires full pytest
lifecycle completion and excludes only exact Finder metadata from source hashing.

Run from the independent module (each command on one line):

```sh
python3 tools/test_os.py --phase G04 --component decisions-probe --manifest /absolute/owned/manifest.json --report /absolute/private/decisions-probe.json
python3 tools/test_os.py --phase G04 --component decisions-regression-probe --manifest /absolute/owned/manifest.json --report /absolute/private/decisions-regression-probe.json
python3 tools/test_os.py --phase G04 --component decisions --manifest /absolute/owned/manifest.json --report /absolute/private/decisions.json
```

No executable profile is promoted by a focused probe or accepted decision.


### G04 reviewed execution and private trusted worker verified

The complete owned-decision component passes1537 Python cases,561 JavaScript
checks and179 closed contracts, with no skipped or unfinished cases. Serial
matching-source full WP passes43 safety/232 API/55 UI plus build, types, drift
and real remote HTTP/MCP conformance. All17 protected financial fingerprints
are unchanged. Earlier failed/interrupted attempts remain retained. These
results qualify decisions only; the complete G04 phase and56 final journeys
remain pending.

The explicit reviewed-execution qualification component resolves only the stored
immutable original decision/grant and continuation. It reserves from the same
nine-dimensional root, admits one stable invocation, and uses a private fixed
provider permit endpoint with separate execution, introspection and receipt
observer credentials. Protected decision hydration follows original local and
remote owner/session checks. Reconciliation of already admitted work uses only
minimal original provider/attempt metadata and authoritative host receipts.
Known business receipt status does not settle unmeasured controller usage.
Late terminal receipts link a fresh closed status segment without renewing a
grant, reopening the original stream or issuing another invocation.
Reviewed providers advance a pending receipt's version with the terminal outcome
in their atomic transaction while preserving its identity. A regressed or
contradictory observation is retained and quarantines the original budget and
current task, including after completion. It invalidates old projection cursors
without rewriting closed historical events or erasing measured usage. Synthetic
host fault controls alter only observation responses; terminal receipt integrity
triggers remain enabled and stored proof stays unchanged.

Additive0017 requires a protected full-schema/data restore into a fresh owned
clone, exact old-column fingerprints, model/CHECK drift and maximum-width
Unicode SQL index/FK/immutability checks before primary upgrade. Applied0001–0017
are frozen. The reviewed-execution checkpoint passes 1,651 Python cases, 617
JavaScript checks and 197 closed contracts, plus matching-source full WP
43 safety/232 API/55 UI, build/types/drift and actual HTTP/MCP conformance. All
17 protected financial fingerprints remain unchanged. This qualifies one
component; complete G04 and all final journeys remain pending. Default startup
enables no trusted Temporal queue or public effect dispatch lane.

```sh
python3 tools/test_os.py --phase G04 --component reviewed-execution-probe --manifest /absolute/owned/manifest.json --report /absolute/private/reviewed-execution-probe.json
python3 tools/test_os.py --phase G04 --component reviewed-execution --manifest /absolute/owned/manifest.json --report /absolute/private/reviewed-execution.json
```

Bounded amendments, delegation, private notification
and separately authorized compensation remain later G04 prerequisites.


The protected0016-to-0017 clone and primary upgrade now pass: all259,324
original rows/38 tables unchanged, exact model/CHECK drift, and rolled-back
256-character/1024-byte tenant and subject namespace index/FK/immutable checks.
Applied0017 is checksum-protected. The reviewed-execution checkpoint is local
commit d22c295; prior failed probes and protected proofs remain retained.

### Explicit private trusted worker — verified component

The fixed internal `OSTrustedTaskDriver/1` factory binds the original installation,
private history codec and failure converter, one owned queue and one materialized
Activity service. It verifies actual callback namespace/profile/queue/current run
and the exact original first-run launch before protected work. Metadata polling
survives original session expiry without refreshing that session or hydrating
private source. Preparation and reviewed execution retain their separate current
authority checks and original shared root; uncertain preparation or execution
ACKs cannot admit replacement work. A failed metadata poll alone creates no write
uncertainty. The first driver profile permits one proposal/decision/invocation;
amendment, delegation and compensation require later qualified extensions.

Initial dispatch uses finite original outbox leases. Continuation hints conform
to frozen 0016: at most eight attempts, leases under three seconds, explicit
LEASED-to-DUE-to-LEASED recovery and a 1.5-second total transport budget. Fresh
database clocks fence leases after actual locks. Hints carry no business payload
or execution authority. No network call retains a SQL transaction. The Activity
has a fixed 120-second transport envelope (135 seconds including scheduling)
and a 45-second service budget, with time for owned cancellation bookkeeping.
These envelopes never renew root/grant/source deadlines or budget ceilings.

Actual queue/replay/lost-ACK/closed-review/host and restart tests are selected only
by the component runner; no default startup, public route or scheduler is added.
The first probe retained a lease mismatch against the frozen database guard;
the corrected snapshot passes fresh focused28 and cumulative1692 Python /
617 JavaScript /197 contracts, serial matching-source WP43 safety /232 API /55 UI,
build/types/drift/actual HTTP-MCP and all17 unchanged financial fingerprints.
Local milestone5fca00d retains earlier failed/interrupted evidence. Full G04 and
all final journeys remain pending.

```sh
python3 tools/test_os.py --phase G04 --component trusted-worker-probe --manifest /absolute/owned/manifest.json --report /absolute/private/trusted-worker-probe.json
python3 tools/test_os.py --phase G04 --component trusted-worker --manifest /absolute/owned/manifest.json --report /absolute/private/trusted-worker.json
```

### Registered high-risk execution — verified component

The `effect_high_risk_component` fixture selects high risk before either
Python/SQLite or Node/SQLite configuration, capability risk floor, registration
or immutable source capture. It requires the actual owned reviewed execution
service and does not start the synthetic permit authority. The ordinary
medium-risk fixtures retain their current profile.

Actual cases exercise exact owned review, no effect before approval, revoked
owner/session/host authority, changed record/schema, closed110-second review and
worker restart, lost ACK and Stop after accepted commit. Schema-valid lowered-risk
or delegation material must fail the semantic trust fence. The assurance remains
`local-synthetic`, using disposable notes/documents. These cases do not qualify
production identity, financial writes, genuine delegation, amended inputs,
notifications or repair. Default startup exposes no new effect lane.

```sh
python3 tools/test_os.py --phase G04 --component high-risk-probe --manifest /absolute/owned/manifest.json --report /absolute/private/high-risk-probe.json
python3 tools/test_os.py --phase G04 --component high-risk --manifest /absolute/owned/manifest.json --report /absolute/private/high-risk.json
```

A focused pass needs the complete cumulative and serial matching-source host
qualification, protected financial comparison and reviewed local milestone
commit before this component is recorded as verified. Full G04 remains partial.


High-risk local component milestone `6635fc3` passes50 focused and1742 unique
cumulative Python cases /617 JavaScript /197 contracts, serial same-source
WP43 safety /232 API /55 UI/build/types/drift/actual HTTP-MCP and17 unchanged
financial fingerprints. Earlier failures/interrupted installer evidence remain
retained. This is local-synthetic G04.2 component acceptance only.

### Amended input storage — verified foundation

Additive0018 introduces immutable scoped input profiles/versions/invalidations
and an exact current head with finite maximum four revisions. A new head requires
atomic invalidation, original admission/root/deadline and a distinct segment and
control epoch. Deferred commit checks expiry and current control/root/task state.
Closed metadata/command contracts grant no preparation/effect authority. The
reserved `OSTrustedTaskDriver/2` storage profile is rejected by current version-1
factories; no amended admission, edit route or new worker is enabled yet.

Qualification requires protected populated full-schema/data restore and clone
rehearsal before the disabled owned primary is upgraded, exact model/CHECK drift,
rolled-back maximum-width Unicode/FK/immutable/CAS/expiry-after-lock SQL tests and
bounded actual migration contention. SQL parent-row expiry checks do not qualify
amendment/approval/effect service races. Existing applied0001–0018 remain frozen.

```sh
python3 tools/test_os.py --phase G04 --component amended-input-foundation-probe --manifest /absolute/owned/manifest.json --report /absolute/private/input-foundation-probe.json
python3 tools/test_os.py --phase G04 --component amended-input-foundation --manifest /absolute/owned/manifest.json --report /absolute/private/input-foundation.json
```

Focused proof requires cumulative same-source OS, serial full host/conformance,
all17 protected financial fingerprints and reviewed normal local commit. Later
G04.3 checkpoints implement typed edits/invalidation, versioned preparation and
fresh review, then private worker/replay and actual edit/begin/Stop/ACK races.
No full G04/final journey acceptance is promoted by storage alone.

Immutable input foundation milestone `92e0459` passes890 bootstrap,17 focused
and1771 unique cumulative Python/629 JS/201 contracts, full serial same-source
host/actual HTTP-MCP and17 unchanged financial fingerprints. Protected populated
0018 preserves67,602 old rows across42 tables; the exact20-file normal commit
is verified. This storage qualification enables no new grant or worker.

### Typed amendment capture — verified private component

`build_input_capture_profile` must be explicitly selected with the existing
shared capacity ledger, unchanged20GiB floor and absolute owned manifest. It
admits fresh Driver/2 metadata and applies typed edits only before any work
attempt exists. The original admission/source/root/deadline remain immutable;
each edit charges one of three plan revisions and advances a distinct segment,
control epoch and expected input head. Stored provenance is metadata, not
preparation or effect authority. No public route or worker is selected.

Input allocation reserves separate bounded host/Docker growth before SQL, uses
an exact recoverable encrypted-file identity, exclusive writes and fresh AES-GCM
nonces. Failures after allocation starts retain their signed lease/files for
review; accepted duplicate retries return historical metadata without another
revision charge. Versioned preparation/review and effect reconciliation remain
later checkpoints. Capture is verified at `fc50317`: 1,848 Python / 632 JavaScript / 202 contracts, full matching-source host/HTTP-MCP checks and all 17 unchanged protected financial fingerprints. Its exact 23-path checkpoint changes no applied migration.

```sh
python3 tools/test_os.py --phase G04 --component amended-input-capture-probe --manifest /absolute/owned/manifest.json --report /absolute/private/input-capture-probe.json
python3 tools/test_os.py --phase G04 --component amended-input-capture --manifest /absolute/owned/manifest.json --report /absolute/private/input-capture.json
```

### Exact-version preparation — private candidate under qualification

`build_input_preparation_profile` explicitly composes the verified private capture
profile with a distinct `InputPreparationPrincipal`, three closed contract
families and three additive preparation binding tables at `os_pg_0019`.
The exact input identifier, revision and digest accompany the original source
pin, request digest, admission, root, control epoch and expiry. Fresh login,
provider and OPA checks precede staging and protected-result disclosure.
Old preparation principals, result families and workers reject this profile.

Each input version permits one staging invocation. Preparation reserves from the
original finite root, charges measured usage, and accepts an immutable protected
stage only after current record/schema verification and exact SQL commit guards.
Edits can follow an exact accepted completed preparation or a never-begun release;
foreign, reserved, running, uncertain and unaccepted settled work deny edits.
Fresh grants, text-only edits and retries cannot refund usage or renew deadlines.
Cancellation drains owned SQL threads; uncertain remote work retains its original
reservation, files and evidence and blocks another invocation.

Protected result allocation retains the existing owned keys, signed capacity
ledger and 20 GiB floor, with separate bounded host/Docker growth. Before any
populated upgrade, protect encrypted full control schema/data and local material,
restore into a new empty owned clone, reconcile original rows and qualify actual
Unicode indexes, composite foreign keys, immutability and post-wait/commit expiry.
Applied 0001–0030 are frozen. Protected0019 preparation,0020 private proposal
storage and0021 closed review rehearsals preserve their original populated rows.

Focused preparation/proposal/review checks have passed. The candidate still
requires integrated cumulative tests plus serial
matching-source WP/HTTP-MCP checks, unchanged financial fingerprints, exact source
review and a normal local commit. These private development checks grant no
trusted queue, public route or full G04 acceptance.

```sh
python3 tools/test_os.py --phase G04 --component amended-input-preparation-probe --manifest /absolute/owned/manifest.json --report /absolute/private/preparation-probe.json
python3 tools/test_os.py --phase G04 --component amended-input-preparation --manifest /absolute/owned/manifest.json --report /absolute/private/preparation.json
```

### Private exact-version proposal preview (G04.3 development)

`InputProposalService` accepts only the separately qualified input preparation
ledger and a closed `InputProposalCompileCommand`. It checks the current head,
settled immutable accepted result, original source pin, finite root and fresh
owner/provider scope before returning an `InputProposalDraft`. Its sealed draft
contains the complete input reference, prepared result reference and typed
proposal. A text-only successor changes both proposal and draft digests.

This private preview creates no review row, challenge, decision, execution grant
or business write. Existing review APIs cannot accept its enclosing family.
Durable publication and closed review activation now pass their private affected
checks; fresh decisions/grants, effect fencing and worker integration remain
pending. G04.3 and G04 are incomplete. Applied migrations0001–0030 stay frozen.

Use `--iteration --suite tests/integration/effects/test_input_proposals.py` with
component `amended-input-proposal-preview` for affected actual checks. The probe
contains its semantic unit and two-host service cases. Short runs record
development evidence only; integrate durable review and worker changes before
the cumulative acceptance checkpoint described in `docs/testing.md`.

`InputProposalService.publish` stores the sealed draft as a protected encrypted
artifact and a separate immutable `os_input_proposals` record. Its command,
accepted result, full input identity, original source, artifact and finite
expiry are scoped by exact foreign keys and current-head/deferred clock guards.
Publication leaves review and execution authority pending; it creates no legacy
review row. Retry after a lost commit acknowledgement resolves the same record.

### Exact-input review — private development

`InputReviewService` explicitly accepts the versioned proposal service. Fresh
current login/provider checks surround protected disclosure and stage verification.
Activation binds one immutable input/proposal pair and atomically closes four safe
events with WAITING_APPROVAL/REVIEW state. It creates no decision or executable
grant. Protected0021 preserves48,003 old rows across50 application tables;12
actual two-host activation/storage cases pass. These are development checks.

`InputReviewAmendmentService` separately qualifies completed preparation and a
closed review before advancing the head. Historical batches and approvals stay
immutable; the original budget/deadline remains finite. Capture/preparation
profiles cannot silently inherit review editing. `InputReviewChallengeService`
seals the exact input and activation in a separate private family and registers
the proposal digest with the existing separately authenticated synthetic owner
ceremony. Each activation has at most eight challenge intents. Lost or changed
acknowledgements cannot manufacture registration or execution authority.

Protected0022 preserves48,635 original rows across51 application tables. Its
maximum Unicode, exact binding, closed JSON, finite challenge ceiling and deferred
expiry proofs pass. All18 actual review-edit/challenge/storage cases pass in
218 seconds; these remain development evidence. Use component `amended-input-review-challenges` with `--iteration` and
explicit affected suites for development feedback. The integrated amended
workflow and complete G04 gate remain required. No normal startup route or new
trusted worker is enabled by these private constructors.

`InputReviewDecisionEligibility` is a private candidate that reuses the fixed
OPA3 eligibility protocol with explicit exact-input and registered challenge
bindings. Approval requires fresh execute scope; rejection requires fresh owner
read scope. It creates no decision, executable grant or continuation. Qualification
passes1,022 fast Python/676 JS/217 contracts and22 actual two-host cases in245 seconds. These are development checks; owned decisions and execution remain pending.

### Exact-input owned decision — private candidate

`InputReviewDecisionService` and its separate historical disclosure bind the
full input, activation, registered owner challenge and immutable decision core.
Approval atomically creates one independently pinned executable5 grant, one
continuation and finite delivery record; rejection closes a separate successor
without a grant. Current input and owner/clock checks repeat before commit.
Three-second delivery leases, at most eight attempts, original budgets and
deadlines remain finite. Exact acknowledgement recovery inspects accepted history
under fresh owner read scope without renewing authority.

Protected0023–0030 add exact-input decisions, execution/Driver2, finite consent,
private notification delivery, delegated dispatch and separate repair bindings.
All applied0001–0030 are byte-frozen. Populated upgrades require an encrypted
full-schema/data backup, a fresh owned copy and exact original-row reconciliation.
The protected0029-to0030 correction retains62521 original rows across81 tables;
0030 isolates registration-only fields in the shared deferred repair guard.

### Separate repair and receipt recovery

`RepairService` admits one registered typed-update inverse under an originally
repair-capable root. It resolves before-values only from protected accepted
original evidence and an authenticated exact committed host receipt. A root with
unknown usage cannot become repairable merely because its business receipt is
known. Existing deadlines, child/stage/tool/repair ceilings and the closed original
task remain unchanged. Unsupported operations or changed host versions deny repair.

A later result-publication failure remains separate from a committed host effect.
Only an exact committed receipt and measured SETTLED work allow the live executor
to record a still-running plan as FAILED. Receipt-only recovery preserves that
failure while publishing business truth. A lost publication acknowledgement
cannot reverse an already completed task. UNKNOWN usage stays held, and any
inverse still requires its own fresh approval within the original root limits.
Ordinary original-receipt polling preserves the failed plan while its separately
admitted repair is pending or has UNKNOWN usage; the root's held usage still
blocks new work. Receipt-anomaly quarantine remains enforced.
The assistant displays the failed plan separately from a known applied change.
An absent optional schedule profile leaves schedules unavailable without a
connection-error banner; ordinary request error codes and authentication
revocation remain unchanged.

The inverse has its own task, encrypted prepared proposal, finite registered owner
challenge, fresh approval, OPA7 grant, invocation, permit and receipt. It retains
the original registered host scope and independently records repair provenance.
Current owner, host permission, resource version, registration and exact proposal
are rechecked before reserve, begin, dispatch and provider introspection. SQL
transactions use short limits and close before remote requests or human review.

Stop fences future admission and requests cancellation of an admitted inverse.
An accepted host commit can still be observed after Stop or revoke. Cancellation
before begin may release only a drained RESERVED attempt; started work with lost
acknowledgement remains UNKNOWN with held usage and a quarantined root. The
explicit bounded rotating recovery controller reads only minimal receipts for
existing invocations after process restart/logout/expiry. It cannot hydrate source,
issue new authority or repeat the effect. Regressive observations remain retained
and report UNKNOWN; they never erase the original commit or measured usage.

Owner routes are attached explicitly with `attach_repairs`; normal startup does
not enable them. Provider introspection uses a separate credential. Public repair
commands cannot carry arbitrary inverse fields, provider URLs or renewed deadlines.
The `registered-repair` component registers the full inherited collection plus
80 actual repair cases across Python/Node hosts and reviewed/delegated originals.
Use `--iteration --suite tests/integration/effects/test_repairs.py` for affected
feedback, followed by complete G04 and matching-source host acceptance.


## G05 owner consent development foundation

The explicit `learning-settings` component stores owner-private conversation,
usage and recall choices in independent consent epochs. All choices default to
false. Current host sessions and exact expected-version/idempotent commands
protect changes; a saved consent and its immutable response commit together.
Learning epochs provide the invalidation binding for later extraction;
this component runs no extraction. Recall changes use a separate epoch.
Context revisions and index generations remain unchanged by settings edits.

Additive `os_pg_0031` introduces only the settings and command receipt tables.
Applied `0001–0031` migrations are checksum protected. The component is a local
synthetic processing profile (`synthetic-staging/1`, `synthetic-embedding/1`),
with no external egress. Consent records do not enable an extractor or index.
Default startup continues to serve the health shell. Candidate publication,
Mem0 staging, actual embedding/pgvector recall, protected KB and G05 quality/load
qualification remain required.

Affected checks use `tools/test_os.py --phase G05 --component learning-settings
--iteration --suite tests/integration/memory --manifest /absolute/owned/manifest.json
--report /absolute/private/report.json` (one command line). A short selection
records development evidence; it cannot qualify G05 or final journeys.

## G05 owner-authored knowledge development foundation

The explicit `knowledge-registry` component enables current-owner Save, inspect,
exact-version correction, pause/resume and forget routes. Direct Save requires
no learning or recall consent. Private content has an immutable, owner-bound
encrypted revision; corrections create another revision. Commands retain keyed
verification and content-free immutable receipts. A stale edit returns a conflict.

Canonical mutations increment only the owner context revision and commit their
entry, operation and pending projection intent together. Index generation and
consent epochs remain separate. No model, embedding or remote request runs inside
SQL. The synthetic projection is visibly pending and has no readiness publisher.
Owner reads recheck current host identity and fence concurrent entry changes.

Forget commits an immediate content barrier and an opaque deletion journal.
`GET /os/me/knowledge/operations/{id}` reports cleanup pending. A separate owner
`POST /os/me/knowledge/operations/{id}/cleanup` with the closed JSON body `{}`
erases all live registry revision ciphertext and earlier command verification,
then atomically records completion. Cleanup is idempotent through the original
forget operation ID and can finish from a fresh current session. Forgotten entries
cannot be corrected, resumed or resurrected by an old Save retry. Retained
operation receipts contain no private text. Backup/journal restore qualification
remains part of G09.

The profile bounds an owner to64 current entries and 64 content revisions per
entry, lists32 at a time and supports `general/1` context. Deterministic obvious
secret/policy canaries are rejected; linguistic quality is a separate gate.
Additive0032 supplies the registry;0033 corrects table-specific trigger field
resolution without weakening its guards. Applied0001–0034 are checksum protected.
Candidate/source review, durable extraction, actual retrieval, protected KB and
quality/load gates remain required. Default startup exposes no knowledge routes.

## G05 selected learning source development foundation

The explicit `learning-sources` component adds private source selection to the
registry component. `POST /os/me/knowledge/sources` accepts only a closed command
UUID, expected learning epoch and an owner-selected statement of at most4000
characters. Current conversation-learning consent is required. This source kind
is `owner-statement/1`; it cannot assert historical conversation/task evidence,
verified outcomes, host events or another actor. Those adapters remain separate.

Source content is encrypted in the owned registry and bound to its owner/source
ID. Admission atomically stores an immutable receipt and a bounded extraction
intent with a30-second debounce,8000-character processing ceiling and8-candidate
ceiling. Its truthful state is `PENDING_DISPATCH`; this component has no Temporal
dispatcher, background principal, model call or approved candidate. It changes no
canonical entry, context revision, recall epoch or index generation.

Owner `GET` source/list routes return at most32 sources with an opaque cursor.
Consent changes make older-epoch sources ineligible; retained owner inspection is
separate from extraction/recall.14-day expiry is checked on reads. At most64
nonforgotten sources are accepted. Forget uses an exact source revision, commits
an immediate barrier and cancels the intent. A fresh owner can inspect the opaque
forget operation and POST its `/cleanup` endpoint with `{}` to atomically erase
the source envelope and keyed command verification. Old source retries remain
blocked; a new explicitly selected statement has a new source identity.

Additive0034 owns this foundation. Its protected populated0033-to0034 upgrade preserves all old rows/private
material, and22 actual source cases have compatible completed passing evidence;
adjacent installer/host/data/review qualification is recorded separately; G05 candidate review, durable extraction/Mem0, actual
retrieval/KB/quality/load and G09 journal restore remain required. Normal startup
exposes only the health shell.

## G05 actual Mem0 staging adapter development

The independent lock pins `mem0ai==2.2.1`. `Mem0Stage` runs the inherited SDK
algorithms in one disposable private child per request. Its constructor injects
bounded process-local vector/entity overlays, a synthetic16-dimensional embedder,
a single-call extractor port and in-memory SQLite. No SDK provider factory or
canonical store is supplied. The transitive Qdrant client package does not select
a Qdrant runtime. Importing the OS adapter does not import Mem0 or create SDK files.

Closed private input bounds selected sources to20/8000 characters, approved
owner records to64/64000 characters and proposed operations to8. Every source
and target binds a supplied UUID/revision. Ownership must already be resolved
and authorized by the caller; these values confer no learning permission. Model
output with missing/foreign sources, extra authority fields, invalid JSON,
obvious secret/policy canaries or oversized content fails before SDK mutation.
This is deterministic validation, with semantic attribution/quality still pending.

Actual2.2.1 extraction produces ADD results. Explicit UPDATE/DELETE/MERGE staging
uses inherited update/delete methods against exact supplied targets; it cannot
publish or erase canonical knowledge. SDK text hashes and history are ephemeral
inside the child. Its fresh private HOME/MEM0_DIR is removed on teardown; no parent
environment change, SDK logs or raw history enters operational output. Telemetry
is disabled before SDK import. A Python network guard provides defense in depth
for this pinned SDK; native execution containment remains the separate G06 gate.
An installed spaCy package is rejected in this initial profile to prevent automatic
model downloads. Entity CRUD is tested separately; no NLP quality is claimed.

The child has a10-second CPU limit, at most512MiB monitored RSS, a20-second default
wall limit (30 maximum) and finite process-group teardown. One extractor call
allows2048 output tokens. Measured usage survives invalid replies; unmeasured
started calls return `OUTCOME_UNKNOWN`, without automatic retry. Cancellation
reaps the child and propagates to the caller, which must durably mark uncertainty.
The caller must close SQL before staging and recheck current authority/source
barriers afterward. No runtime route, background principal, Temporal dispatch,
candidate acceptance, embedding projection or recall is enabled by this adapter.

## G05 purpose-bound learning account checks development

`LearningAccountChecks` verifies a previously enrolled opaque owner against a
separate authenticated `/learning/accounts/check` HostBridge route. Its closed
`HostLearningAccountRequest/1` and `HostLearningAccountState/1` carry the fixed
`OSPersonalLearning/1` purpose, current activity/policy and bounded freshness.
The Python/SQLite, Node workspace and opt-in WP connectors implement this wire
boundary without importing OS internals or linking accounts by email.

An operator must explicitly register exactly one account-only connector in the
existing `HostRegistration/1`: transport/protocol `host-bridge` / `host-bridge/1`,
authority profile `OSPersonalLearning/1`, no capability references or tool
bindings, the application's existing bridge endpoint/credential, qualified
conformance, current-authority/live-revocation guarantees and fixed3000ms/4096-byte
bounds. Missing, ambiguous or unsupported profiles fail closed. No existing
registration is upgraded automatically; default startup remains the health shell.

The service checks application revision/generation/digest and enrolled subject
generation/policy before and after the remote await. SQL is closed during HTTP.
It rechecks response freshness after final SQL and detects disabled applications,
removed owners, changed policy/registration or unavailable credentials. The
separate HTTP adapter can call only the account route. Host account availability
can survive a login expiry/logout; WP still requires current `assistant.read`.
An account check cannot renew or create any interactive session.

The returned immutable observation is not a principal, consent or a job grant.
This component reads identity metadata only; it cannot inspect/decrypt selected
sources, invoke host tools or publish knowledge. Durable jobs must separately
bind current consent/epoch, exact source revisions, an owned finite lease and
budget before processing, then recheck these barriers before publication.
The separately selected learning job and candidate publication components build
on this source authority; source admission alone enables neither component.

## G05 durable learning jobs and private candidates

The explicit `learning-jobs` development component adds finite source-bound
extraction to the separately registered account-check profile. A durable job
claims an immutable range of at most20 selected sources /8000 characters after
the30-second debounce. Current conversation consent, epoch, application/subject
generations, exact source revisions and fresh account observations are checked
before processing and at commit. Interactive expiry does not renew a session or
turn an account observation into private-content authority.

The fixed job allowance is one provider call,16384 input tokens,2048 output
tokens,100000 cost micros,8 candidates,10 CPU seconds,30 wall seconds and512MiB
child RSS. A finite45-second lease uses both host and store clocks. The worker
commits call-start before inference and retains actual measured usage, including
over-budget usage, after consent/source changes or rejected output. A crash or
cancellation with unmeasured started inference becomes `OUTCOME_UNKNOWN` and
keeps its owner hold; recovery never repeats the call. SQL is closed during
account HTTP and isolated Mem0 execution. Deferred commit rejection settles the
same durable row without repeating inference or publishing candidates.

`LearningTemporal` uses the encrypted private history converter and a stable
job workflow ID. Lost start acknowledgement reconciles the exact type, queue,
memo and original launch input. An explicitly bound worker has two activity
slots and two workflow threads; workflow/activity retries cannot replay
inference. Neither normal startup nor this component installs a provider or
starts an automatic learning loop.

Success atomically records encrypted `KnowledgeCandidate/1` revisions, exact
source evidence and job completion. Fresh owner candidate GET/list routes return
at most32 results; wrong owners receive404. Learning opt-out preserves private
inspection while disabling acceptance eligibility. Source forgetting hides
derived candidates immediately; separate owned cleanup erases all candidate
ciphertext copies in the source transaction. Source views expose current job,
usage and candidate-count status separately from the historical admission
receipt. No candidate is canonical knowledge or a recall result.

Additive0035 owns these records and strict physical transition/commit guards.
Its protected populated0034-to0035 rehearsal preserves original rows, private
material and financial fingerprints. Applied0001–0036 remain frozen. Additional
source lanes, actual embedding/recall, protected KB, held-out quality and load
qualification remain required before G05 closes. This component is development
evidence only.

## G05 candidate review and canonical publication

The explicit `candidate-publication` component adds authenticated owner
accept/edit-and-accept/reject commands with exact candidate revision and private
digest, immutable command receipts and fresh identity, consent and source checks.
Editing creates a distinct encrypted candidate revision. Accepting commits the
reviewed canonical entry, provenance, owner context revision and pending indexing
intent in one transaction. No embedding or network call runs inside that
transaction, and pending indexing is not semantic recall readiness.

Supersession and merge require explicit exact target revisions. Sorted target
locks and expected versions prevent partial publication during competing edits.
Accepted source-derived entries expose their reviewed-learning origin and source
references; source availability is checked again after remote freshness checks.
Learning opt-out prevents acceptance while preserving private inspection and
rejection. Duplicate commands return their original receipt; altered commands
and competing decisions conflict.

Source forgetting immediately withholds derived content. Separate cleanup erases
the governed candidate and canonical revision ciphertext and keyed command
verification copies. Canonical entry forgetting also erases linked candidate
copies. Minimal decision/source identifiers remain to prevent stale replay;
independent host evidence follows its own retention policy.

Additive0036 supplies three scoped publication/decision/member tables and strict
physical transition, commit and erasure guards. Its protected populated0035
backup, full restore into an empty owned copy and additive upgrade preserve
original rows and private material. These explicitly selected local synthetic
components do not close G05, select a live extractor or enable a default memory
worker. Conversation/outcome/usage learning, actual embeddings and recall,
protected KB, held-out quality and bounded load remain phase requirements.

The explicit G05 usage-learning development component selects HostSemanticUsageIngress/2 on `/os/usage-events`. A registered authenticated host server binds the current account and an operator-pinned semantic vocabulary; conversation consent is insufficient. Encrypted observations retain exact event/stream sequence identity for14days. One consistent batch requires at least3 distinct events on2UTC dates and may run once per owner/day through private OSPersonalLearning/3; uncertain provider usage continues holding the owner slot. Suggestions are labeled behavior-inferred and require current owner review. Source forgetting removes encrypted payloads and keyed signal/command verification material, while retaining minimal opaque event identity. The frozen legacy ingress outside this explicitly selected component still retains no usage payload. Default startup enables no learning or model download. G05 acceptance remains pending retrieval, protected KB, held-out quality/load and integrated qualification.

Selected read outcomes additionally require one separately registered
`OSPersonalSourceValidity/1` host connector. Its fixed `/learning/sources/check`
route checks the original accepted resource versions and requested fields under
current host permission. It returns account/permission metadata for at most
three seconds, without resource values, sessions or grants. The explicit
development profile accepts1–32 resource references and1–32 field names within
64KiB; a larger or fieldless selection is unavailable in this profile.
Missing registration, changed records, revoked reads and unavailable hosts deny
source reuse even when the account remains active.

Source, candidate and canonical reads refresh this observation before private
hydration and after remote waits. Workers refresh it before inference and after
the provider returns; publication also refreshes any existing learned target.
Deferred database guards recheck expiry at commit. Unavailable old sources are
filtered before selecting a learning cohort, allowing eligible later kinds to
proceed. Forget immediately invalidates the observation; separate atomic cleanup
erases its keyed request verification alongside the source ciphertext. Key
rotation preserves the source's original verification key binding. Additive
0040/0041 own these records and guards; applied migrations remain frozen.
These changes require the explicitly selected synthetic host profiles and do
not enable default learning, embeddings, recall or full G05 acceptance.


## Explicit offline embedding development component

The `offline-embedding` G05 component imports the reviewed public
`sentence-transformers/all-MiniLM-L6-v2` revision
`1110a243fdf4706b3f48f1d95db1a4f5529b4d41` with exact configuration,
tokenizer and ONNX hashes. The English profile `minilm-english-onnx/1` uses
384 dimensions, identical query/document text, 256-token truncation,
attention-mask mean pooling and L2 normalization. Import requires the owned
installation operator key and existing reviewed local model files. It performs
no download or inference. Normal startup remains the health shell.

Use `agentic-os embedding-import --manifest /absolute/manifest.json
--model-source /absolute/reviewed-model --operator-key /absolute/operator.key
--capacity-root /absolute/capacity` to import into a new private profile root.
Then explicitly run `agentic-os embedding-serve --manifest /absolute/manifest.json`.
This fixed private Unix service shares one process ledger between consumers;
it does not discover providers, login credentials or business tools. Socket
paths must fit the portable 100-byte envelope.

One installation permits two active CPU children and fourteen queued requests.
A request waits at most ten seconds, then runs for at most thirty seconds with
a ten-second CPU limit and 512 MiB RSS ceiling. Frames are at most 1 MiB,
32 texts and 4,000 characters per text; inference uses microbatches of four.
Cancellation/disconnect joins owned children before returning. Unknown PID,
process-group or private-directory cleanup retains its opaque resource hold.
Only known empty child homes are removed; private prompts are never journaled.
The minimal child launch environment sets `ORT_DISABLE_TELEMETRY=1` before
ONNX Runtime import and calls its telemetry-disable API as defense in depth.
A missing startup switch refuses the child before import. Python network attempts
are denied and measured for this trusted pinned model.
Native sandbox qualification belongs to G06. This component by itself enables
no personal recall, canonical projection or G05 phase acceptance.

## Scoped retrieval projection development component

The explicit `scoped-retrieval` component owns immutable personal projection
rows in the separate retrieval database, with the pinned 384-dimensional
normalized English profile and PostgreSQL full-text lexemes. Publication is
idempotent only for identical scoped revision, generation, vector and lexemes.
Rows have four namespace axes, a declared memory lane and an opaque registered
context. Projection candidates confer no canonical or host authority.

Every search requires up to64 currently approved projection IDs from its
caller before ranking, plus the exact namespace, generation, profile, lanes
and contexts. Results carry opaque revision metadata, never canonical text.
The future governed caller must rehydrate current control records and source
permission after retrieval and before disclosure. This store alone enables
no recall route or canonical projection publisher.

Exact cosine is the baseline. English FTS uses disjunctive parsed lexemes;
hybrid RRF uses k=60 and stays disabled by default. Experimental HNSW also
stays disabled by default; its ef40/strict-order scan can fall back only to
exact search over the identical eligible scope when underfilled. Neither
similarity nor lexical ranking establishes authorization.

The owned retrieval pool permits four connections and sixteen waiting
borrowers, with a two-second pool/lock limit and three-second SQL statement
limit. No SQL transaction crosses inference or a remote await. Scoped purge,
abandoned-attempt discard and older-revision retirement are separate bounded
operations. Unknown child-home symlinks retain signed embedding resource holds.

Additive `os_store_0002` seeds only the validated component installation
registry and creates retrieval rows, CHECKs, indexes, immutability and owner
row-security policy. Runtime credentials cannot alter these guards or registry.
The owned migrator retains complete backup access. Component drift checks
compare PostgreSQL-parsed model CHECK and policy expressions and inspect the
enabled immutability trigger; temporary comparison tables roll back or disappear
at commit. Protected full-schema/data restore is required before first upgrade.

## Classified owner memory and learning development components

The explicitly selected `classified-memory` component stores owner-reviewed
preferences, episodes, personal context, relationship context and procedures.
Contexts and claim keys are owner-created opaque records with encrypted labels.
Procedure steps refer to current registered READ tools; saving a procedure
admits no task, effect, permission or executable grant. Unresolved claims are
omitted from recall. An explicitly selected project context takes precedence
over a general claim only for that context. Untyped legacy entries remain
inspectable and require explicit classification before typed recall.

The `classified-learning` development component adds `classified-staging/2`,
`OSMemoryStage/2` and private `OSPersonalLearning/4`. Its separate
`os-learning-<runId>-classified-4` queue allows frozen legacy learning workers
to keep their original queue and workflow semantics. The operator must
explicitly provide a selected extractor and worker; normal startup starts no
learning loop, external provider or model download.

Owner routes include `/os/me/learning/classified-settings`,
`/os/me/knowledge/candidates/classified` and
`/os/me/knowledge/classified`. Conversation and semantic usage consent
remain independent. Three consistent usage observations on two UTC dates may
produce one daily inferred suggestion; its typed value and context must match
the authenticated signal. Every inferred or extracted suggestion requires
owner review. Direct owner-authored Save remains an explicit decision.

Actual Mem0 ADD, UPDATE, MERGE and DELETE affect only a disposable overlay.
Proposed supersession, merge and forgetting bind exact approved entry versions.
Job snapshots retain opaque context/key/tool/revision metadata; private content
and labels are hydrated only for the bounded stage. Signed owner/job bindings
precede process admission. New and legacy stages share the existing finite
process envelope; unknown or unbound work keeps its recovery hold.

Fresh source, account, consent, context and target checks precede extraction
and repeat before candidate publication and approval. Editing a stale candidate
creates a new encrypted revision with current explicit bindings. Reviewed
DELETE commits the canonical forget barrier and reports separate cleanup status;
it does not delete unrelated owner-authored facts or independent host evidence.
Applied control0043–0046 and store0001–0003 are frozen. Runtime repairs use new
additive migrations with protected backup, empty-copy restoration and drift
qualification.

Affected actual checks use `tools/test_os.py --phase G05 --component
classified-memory --iteration --suite
tests/integration/memory/test_classified_learning.py --manifest
/absolute/owned/manifest.json`. This component evidence does not close G05:
task-context/output fences, forget-all recovery, protected KB layers and actual
held-out quality/load remain required. Live extractor linguistic quality and
data-egress permission are separate profile qualifications.

## G05 surviving deletion journal and atomic forgetting

The explicitly selected `memory-recovery` component binds an operator-provisioned
application journal outside the database/private-material restore directory.
Its private root must already exist; normal construction never initializes a
missing journal or adopts a replacement key. The database pins the journal ID,
key fingerprint and exact owner sequence. Missing, altered, pending or older
proof makes private memory unavailable. This is the G05 backend fence; coordinated
snapshot restoration and journal replay remain a separate G09 qualification.

`POST /os/me/knowledge/forget-all/atomic` accepts a command UUID and exact settings
and context revisions. It commits one batch receipt for all currently live
entries, sources and contexts. Consent choices and index generation stay current;
settings, learning, recall and context revisions advance once. Individual entry,
source and reviewed candidate deletions use the same surviving journal. A failed
SQL commit retains a pending intent for the exact authorized retry.

`GET /os/me/knowledge/forget-all/atomic/operations/{id}` and its `cleanup` action
report separate erasure status. Cleanup removes governed canonical ciphertext,
vectors, source candidates and forgotten context verification material. Selected
SDK worker roots are trusted configuration, never request paths. Only exact
signed owner process identities can be stopped; uncertain or unbound work retains
its home, reservation and cost state. Other owners and independent host evidence
retain their separate authority and retention.

Applied control0047 is frozen. Actual owner API, physical receipt, concurrency,
missing-journal, stale-watermark and in-flight embedding/extraction checks are
registered in `tests/integration/memory/test_recovery.py`. Shared regression,
installer and host qualification determine the integrated checkpoint. Task-derived
output erasure, protected KB and declared quality/load are now part of the G05
backend qualification collection. Their current reports and integrated checks
determine phase closure.

## G05 task memory and protected knowledge

Production SDK launch traverses the existing current-scope capability cursor,
including empty pages before an executable lane. Only implemented lanes for the
selected journey enter its bounded worker message. Catalog version changes,
Stop and expired scope prevent launch; replacement rediscovers under current
authority. OS-only memory and proactive compositions disclose no external tool
metadata when no Host discovery adapter is configured. This does not enlarge the
worker-message schema or qualify arbitrary dynamic tool batches.

The explicit production approved-memory composition uses
`IdentityRuntime.enable_agent_memory_context` before the existing
`enable_agent_read_runtime`, with `VerifiedMemoryReads`, `MemoryCapabilityCatalog`
and the registered `owner.memory.read/1` journal. It retains the shared installed
Agent SDK/Temporal executor and original resource root. `memory-assisted-read/`
harnesses require the atomic owner-selected `MemoryTaskCommand.contextRef`;
normal task admission cannot silently add a memory context. This profile binds
up to64 approved canonical references and returns ranked, non-exhaustive recall.
An empty accepted recall produces an explicitly unsatisfied goal, not an absence
claim. Memory text grants no application authority or protected-KB access.

Revision0084 adds the production binding, original storage-attempt derivative
inventory and immutable opaque accepted-source receipt. Current consent/source
checks fence execution, saved sources and presentation. Forgetting pages through
the existing derivative inventory, resumes after interruption, preserves
independent captured/Host evidence and keeps RUNNING/UNKNOWN usage held. The
existing owner UI supplies recall-context selection, memory/source inspection,
History and privacy cleanup. `/os/memory/mcp` advertises only configured tools;
the memory-only composition enables recall, while learning proposals and public
KB metadata require their separate configured services. Protected planner KB uses
the separately selected production composition below. This composition does not enable
default startup, live inference, completed production retention/recovery or AWS
qualification; those acceptance gates remain separate.

The explicit production KB composition calls
`IdentityRuntime.enable_agent_planning_context` before `enable_agent_read_runtime`,
with `VerifiedPrivatePlannedReads`, `PrivateKnowledgeCapabilityCatalog` and the
registered `private.knowledge.read/1` journal. Its operator-pinned
`AgentPrivatePlanningProfile` declares separate public/planner model pins, meter
policy, credentials, reviewed capability pins and read adapters. The existing
`MemoryTaskCommand` atomically binds opaque KB scope metadata; actual embedding,
ranking and protected passages are read only after original-root tool begin.
Provision and attest the protected KB keys and public metadata credential through
the existing explicit operator setup before constructing this profile. Missing
credentials disable it; ordinary startup never provisions or adopts them.

The installed worker's `assigned-private-planned-read-local/1` configuration
requires a separate `planner` object containing its workload token, transport,
API key, history key ID/bytes and canonical meter policy JSON. Core must also be
configured with disjoint public/private `planning_history_key_ids`. The existing
Temporal workflow continues through objective, private planner and fresh public
execution queues under the same workflow identity, Root and deadline. Only the
existing typed read control crosses phases. The private model may recommend an
exact permutation of already accepted public criterion UUIDs; Core rejects extra
IDs, resources, fields or private text. Current Host authorization still governs
each ordered read. Public contexts cannot resolve private model results, KB
passages, histories or checkpoints. The owner sees an opaque guidance-use notice;
the existing source/History/forget paths retain current access and erasure fences.

Revision0085 pairs these model-purpose and immutable KB source guards with the
existing private storage, accounting and derivative inventory. It is frozen
after protected populated positive/negative runtime, rollback, forward/catalog
and independent0084 recovery. The scoped local service, installed SDK/Temporal
private-plan commit-ACK loss and worker replacement, desktop answer/both sources,
History/reload, opaque guidance use, forgetting/physical cleanup and current
denial pass with synthetic inference. Independent Core/worker installation is
accepted cumulatively with the original failed cold-import aggregate retained;
the exact native check passes under its unchanged ten-second limit. Compatible
mobile/layout evidence is retained. Complete lifecycle/recovery/backend, live
inference and actual AWS qualification remain separate; default startup stays off.

The explicit production proactive composition supplies the existing
`ScheduleService` to `ProactiveCapabilityCatalog` and `ProactivePreparationLane`,
registers its exact `AgentProactiveToolProfile`, and selects `VerifiedProactivity`
over the same model/tool journals and `enable_agent_read_runtime`. Its single
`os.proactivity.prepare/1` tool prepares an inactive finite scheduled check or
registered-event subscription. Activation is never an SDK tool. The existing
Scheduled checks panel displays the exact configuration for current-owner review;
the task completes only from its canonical activation command receipt.

Preparation, private storage and the SDK objective/execution phases retain the
original production Root, accounting and deadline. The execution history waits
with existing minimal typed control after sealing review, without another private
continuation reservation racing owner activation. Stop, expiry and outstanding
UNKNOWN usage block activation. A manual revision is separate owner intent and
cannot satisfy the old task. A previously committed activation remains observable
as minimal receipt truth after interruption; current Host denial withholds the
configuration. Future checks use the existing separate finite delegation,
ScheduleTemporal/event driver, outbox, executor and private notifications.

Additive revision0086 links the original preparation operation to its existing
proactive revision with a nullable scoped foreign key. Manual definitions retain
their original behavior. Its protected populated runtime, negative guards,
rollback, forward/catalog and independent0085 recovery are qualified locally.
Actual local service acceptance covers scheduled and registered-event checks,
private notifications, rejection, manual revision and Stop. Installed SDK/Temporal
acceptance covers draft-ACK worker replacement, exact owner activation, persistent
desktop review/History/reload and current-access clearing. Independent Core/worker
artifacts pass; compatible mobile/layout evidence is retained. These checks use
synthetic inference and do not qualify live inference or actual AWS deployment.
The composition remains explicitly selected; default startup and live production
qualification are unchanged.

Configured scheduling can additionally select
`core.proactivity.restricted_wasm = {"profile":"wasmtime-i32-offline/1"}`.
This uses the existing `verified-wasm/1` owner configuration, immutable
`NativeVerification`/`NativeTool` catalog, tool decision routes and finite
`ProactiveExecutor`. The owner must separately activate the exact verified tool;
each schedule pins its active version and verification digest. Pause, expiration,
changed pins and current authority are rechecked before execution and publication.
Artifact loading occurs outside the control transaction and rechecks the exact
catalog pin afterwards. Future tasks retain their original separate delegation,
deadline, usage reservations and encrypted persisted results.
Unconfirmed physical cleanup quarantines that native run and preserves its
original work reservation; neither a candidate result nor elapsed time settles
UNKNOWN usage. Independent registered reads do not acquire that placement or
inherit its quarantine.

The existing Scheduled checks dialog lists these reusable tools, shows their
source and observed examples, and submits exact owner activation/pause commands.
Creating a check selects an active tool version and verification digest; its
ordered signed i32 inputs preserve repeated values. Schedule approval remains
separate from tool activation. Execution history can inspect the original saved
scalar and literal inputs without running the tool again. This view freshly
checks current owner/application scope, verification/artifact expiry and the
original encrypted result digest; it does not disclose saved Host records.
A paused tool cannot execute again, while a known saved result remains inspectable
with current access. UNKNOWN runs have no inspectable result.

The configured offline Wasm controller borrows explicit installation adapters,
uses the existing resource lease under the installation's `restricted-wasm`
directory and runs the same bounded fresh-process i32 ABI without WASI, imports,
network or inherited credentials. A second controller cannot acquire the lease;
unconfirmed scratch remains quarantined after replacement. Lambda supplies wake
and dispatch hints only and never starts this controller. The frozen Agent
planning profile remains `registered-read/1`; this option does not widen admitted
Agent instructions or enable tool creation. Existing legacy tool verifications
retain their original synthetic creation/accounting origin. Configured consumption
does not qualify production reusable-tool creation, Linux containment or deployed
AWS behavior; those require their separately recorded acceptance.

Original production creation has a separate explicit public selection:
`journey_schema: "agent-wasm-creation-journey/1"` with
`core.wasm_creation = {"profile":"wasmtime-i32-offline/1","policies":[...]}`.
Its policy is an `AgentWasmCreationToolProfile`; the existing configured
proactivity/controller profile is required for subsequent owner review and
finite scheduling. Both local and managed configuration use the same Core,
tool journal, private SDK worker and contracts. Selecting this journey offers
only its exact registered `native.verify-tool/1` capability.

In Scheduled checks, Create reusable tool captures a name, complete instruction
and one to eight independently specified examples with ordered signed integer
inputs and one expected output. This is the ordinary captured/admitted
conversation path. The SDK copies the original request into its private goal
and proposes WAT; Core compiles and runs every original example using fresh
restricted workers. The model cannot replace expected values or mint a receipt.
The existing original production Root pays native computation and encrypted
candidate storage. Known physical settlement and exact accepted-result bindings
create an immutable production verification origin and an inactive draft.
Original task completion, CLOSED zero-held Root and a separate exact current
owner decision are prerequisites for activation. Stop, changed authority and
uncertain cleanup cannot create an activatable draft or repeat begun work.

This profile bounds source at4096UTF-8bytes, compiled binary at8192bytes and the
private candidate at65536bytes. Before new admission, the selected model must
allow at least65536request bytes and262144response bytes within the existing
encrypted archive limit. Original admitted deadlines/budgets and legacy Wasm
limits remain unchanged. These are explicit profile limits, not a claim that
passing declared examples proves arbitrary-input correctness. Full installed
creation/browser/package acceptance and actual production qualification are
recorded separately; default startup remains disabled for this journey.

The explicitly selected `memory-task-serve` and `memory-task-worker` profile uses
`OSTaskMemoryDriver/1`. Ordinary startup remains the health shell. Provision the
surviving journal, pinned offline embedding profile and separate KB credentials
through the operator commands before selecting this profile. Applied control0048
and store0004 are frozen; startup never downloads a model or repairs missing keys.

`POST /os/memory/tasks` binds current owner-reviewed memory and reviewed KB
revisions to the original task admission, session and deadline. The
`/os/tasks/{id}/knowledge-context` inspector returns opaque references.
`/os/memory/tasks/{id}/output` discloses the protected final output only after
current owner, consent, revision and source checks. Corrections, pause, forgetting,
source revocation and KB retirement prevent late disclosure or acceptance.
Atomic and individual cleanup erase tracked cognition/output files and rewrite
grounded events to the explicit memory-erased notice. Independent accepted host
read evidence and truthful historical task outcomes retain their separate scope.
Uncertain provider completion keeps cleanup pending and its budget held.

Reviewed KB publication preserves independent business, architecture, system and
shared layers, trust, authority, steward, application/tenant ACL, purpose and
validity. Operator publication/retirement is CLI-only. A separate read-only
credential exposes approved public metadata; protected passages are available
only to the private planner. Each planner stage uses its own registered
`OSPrivatePlannerMCP/1` in-process endpoint, original task binding and expiring
credential. It is never mounted on the owner HTTP service. Public synthesis uses
a fresh provider and receives accepted host evidence and permitted owner memory.

The selected owner MCP endpoint `/os/memory/mcp` requires a fresh DPoP proof for
every protocol request. Its closed tools are `memory.retrieve`, `memory.propose`
and `knowledge.retrieve`. Proposals resolve exact accepted sources and require
registered host observation and independent learning consent. They perform no
owner acceptance or KB publication. Public knowledge retrieval supplies approved
metadata. Internal planner retrieval and operator actions are absent from this
catalog. No tool accepts caller-selected collections, owners or purposes.

Run `tools/test_os.py --phase G05 --manifest /absolute/owned/manifest.json` for
the complete registered backend collection, or select `--component
task-knowledge` / `--component retrieval-qualification` for focused qualification.
The load case installs a fresh owned target and builds100/500/2000 active-generation
vectors for32 authenticated owners across two unrelated hosts, preserving the64-entry
owner limit. It separately records all retained physical rows from prior generations.
It measures mixed semantic, lexical and owner-control traffic at
concurrency 1/4/16, actual worker RSS/queues/pools and unforced query plans.
Measurement artifacts remain private under each fixture's `qualification` folder.

The frozen120-query English benchmark and original revision9 corpus compare
exact, actual-planner ANN, FTS and fixed RRF. Labels are model-authored synthetic
judgments frozen before scores, not independent human gold. No-match queries may
return untrusted candidates; similarity never establishes relevance or authority.
The original receipt-query miss remains recorded. ANN and hybrid defaults remain
disabled. Human judgment, live extraction, multilingual and production relevance
remain unqualified. Browser M12 is G07; coordinated old-snapshot restore M11 is
G09. G05 backend qualification does not close the final release journeys.

## G06 native execution in the local synthetic profile

The native profile remains disabled. `deploy/native-lock.json` binds the Darwin
ARM64 Microsandbox runtime, firmware and Go SDK0.7.6 to pinned Core99ba9b48,
the Linux ARM64 Codex0.153.4 harness and an exact Python OCI manifest. Native
release preflight verifies ownership, canonical paths, artifact hashes and the
SDK's materialized FFI library before loading it. It performs no download or
automatic repair. Other platforms require their own qualification.

Explicit local synthetic provisioning installs the disabled profile from the
packaged locks and source files:

```sh
agentic-os native-provision --manifest /absolute/owned/state/manifest.json --native-home /absolute/short/sdk-home --capacity-root /absolute/private/capacity
agentic-os native-attest --manifest /absolute/owned/state/manifest.json --native-home /absolute/short/sdk-home
```

The existing synthetic installation manifest must validate. The SDK home must
have a canonical absolute path of at most 48 bytes, an owned protected parent,
and be new, empty or already bound to this installation. Existing settings or
another installation's home cannot be adopted. Signed records bind the home,
installation, exact release and packaged build recipe. Provisioning requires
the same capacity floor as the foundation installer and reserves estimated
growth before downloading or building.

The immutable shared build cache verifies all input archives, the selected
platform compiler/SDK, unchanged Go locks and resulting artifact hashes.
Each installation receives private copies and a separate mutable SDK home.
Owned build scratch is retired before publication. Runtime doctor and the
pinned image pull run before the signed installation receipt is published;
converted EROFS layers are bounded, hashed and verified directly because this
SDK can report null converted sizes. Explicit retries may resume matching
partial copies. Ordinary attestation checks existing bytes and rejects changed
artifacts or layers without repairing them. Neither command admits a task or
starts a VM; both retain disabled activation and an empty enabled-lane list.

The development controller keeps a separate signed, bounded lifecycle journal.
An exclusive process lease binds each immutable task attempt to its original
Core session, environment and SDK placement. Retries preserve that mapping;
restart recovery performs cleanup without starting execution again. Cleanup
records require repeated SDK metadata absence and independent absence of the
backing directory and host VM process. Incomplete observations retain unknown
work and quarantine the owner. These internal records grant no execution
authority by themselves. The separately selected development ledger binds
native reservations to the original admission, finite root and deadline. It
requires signed physical cleanup before known usage can settle; missing
mapping or unknown usage retains the reservation. The default task driver
cannot refund native work. Legacy root profiles retain their semantics.

The private usage meter prepares only authenticated journal metadata under its
existing file lock. Every mutation performs a fresh complete-byte controller
and lease check immediately before its signed commit; denied transitions also
check the current owner before returning. Read-only usage observations retain
their independent fresh check. Preparation grants no request or credential,
and interrupted provider usage remains pending through restart and revocation.
No artifact or authorization proof is cached across operations.

Quiet private Core status polls back off to at most500ms, capped by the
original lease. Each actual observation and source disclosure keeps its fresh
authority checks. Process/stream failures and cancellation wake the wait
immediately; task, operation and physical cleanup deadlines are unchanged.

Observed Go build metadata and original artifact/source provenance remain in
`native/provenance.json`. The supplemental `deploy/native-inventory.json` records
48 observed Go dependencies, the862-package Microsandbox and1,381-package Codex
source locks, exact firmware/kernel and native build inputs,105 observed Debian
image packages, CPython3.12.15, host system libraries and42 complete notices.
Source locks are conservative supersets; they do not assert that every package
was compiled into a released binary. The original installation receipt is preserved.
The separate disabled Linux ARM64 conformance lock records the stopped on-demand
Lima/KVM host and runtime pins; it grants no Linux Core or amd64 qualification.

Export a checked inventory from an independently installed package:

```sh
agentic-os native-inventory --manifest /absolute/owned/state/manifest.json --native-home /absolute/short/sdk-home --inventory-output /absolute/private/new-inventory.json
```

This read-only command verifies release/artifact pins, observed Go membership and
notice hashes before writing a new private file. It never starts a job or repairs
changed native artifacts. Unknown platform or build combinations are refused.

`deploy/native/provider.go` owns one SDK allocation and its cleanup. Installation,
task, attempt and request labels fence inspection and recovery; a supplied
placement identity must match. Recovery never restarts execution. The helper
checks persisted resources, image, lifecycle, deny policies and the single
bounded tmpfs mount, as well as the actual512MiB managed upper. The selected
filesystem guarantee is an immutable EROFS lower with a private writable upper;
the overlay root is not wholly read-only. UID1000, one CPU and1GiB guest memory
are verified in the assigned guest alongside actual process, memory, CPU and disk
pressure. The8MiB tmpfs/file limit,64-process ceiling and fixed120-second lifecycle
remain enforced; guest memory and host RSS are recorded separately.

The fixed guest bootstrap connects an explicitly registered Core environment
over authenticated, bounded SDK stdin/stdout. Assigned backend connectors supply
verified TLS for Core and the inference endpoint. The guest receives its scoped
executor credential and model endpoint token; operator keys, host database
credentials, host paths and host-vsock routes are absent. Frame authentication
does not grant tool authority. The original SDK connector assigns each reverse
TLS stream to its admitted attempt. The maintained gateway requires that
assignment, checks current authority, and routes closed read requests through
the registered HostBridge/MCP broker. Claimed subjects, arbitrary destinations
and effect dispatch are rejected. A configured receipt allowlist can expose an
existing current-owner effect receipt through the G04 reader; it cannot execute,
resume or repair the effect.

The explicit local synthetic component now has a maintained private Core
backend/client, original-root SDK executor and separate encrypted
`OSNativeTaskDriver/1` workflow. Its two-slot worker never claims a legacy queue.
The backend preserves its project and keys across restart and holds an exclusive
service lease. A lost workflow acknowledgement recovers original metadata;
it does not create another model turn, VM or admission. Each native allocation
reserves disk growth before execution; signed physical teardown releases that
reservation independently of unknown model usage. Repeated cancellation cannot
interrupt cleanup or leave its capacity lease descriptor held.

Actual development probes run a Core native turn and observe cancellation,
Core failure and SDK-controller crash recovery, including a surviving VM,
wrong placement rejection, same-identity cleanup and duplicate reconciliation.
Completion requires SDK process exit plus independent process, record and
directory checks; an `absent-record` response alone is no teardown proof.
These probes are complemented by actual OS-admitted containment, broker/effect
receipt, Stop during allocation, incompatible proposed rollback, model outage,
original controller-death recovery and repeated-run checks. Ordinary startup
continues to select the health shell. Production placement and the final release
journeys require their separate gates.

The gateway persists finite original-attempt usage before synthetic inference
or broker calls. Its explicit offline provider declares a150-token response
bound. Valid completion measures tokens and model calls; governed reads consume
one attempted call, including denial or outage. One read may overlap a finishing
model stream without widening the original allowance. Pending usage survives
restart and cannot grant another credential or a free retry. Cleanup revokes
the stream assignment and credential; settlement requires matching Core/model
usage plus signed physical teardown. The upstream credential stays backend.
This provider profile does not enable production inference.

Actual development checks cover governed reads on both unrelated hosts, invalid
identity and effect requests, Stop, and the original private workflow. A host
commit followed by a lost acknowledgment remains one commit when a native job
reads its existing receipt and retries; the original uncertain effect usage stays
held. Failed test reports retain their outcomes, and affected/unfinished cases
resume with exact source and case provenance.

The private development tool registry accepts untrusted WAT drafts only after
the controller observes the original owner's declared cases in restricted
Wasmtime49.0.0 processes. Each compile/run has a fresh engine and store, a finite
fuel and wall-time allowance, bounded linear memory and a fixed i32 ABI with no
imports or WASI. Stop hard-kills and reaps the process before scratch retirement.
Serialized native compiler caches are rejected. This offline integer function
profile does not provide general script or operating-system tools.

Additive control0049–0051 bind immutable Core identities, controller verification
receipts and named tool definitions. Applied migration files remain frozen;
0051 corrects the observed-case field guard introduced in0050. Populated-copy
rollback/upgrade rehearsals preserve existing rows and private material before
any fresh-target upgrade. The registry requires a settled original attempt,
signed physical teardown and a controller-sealed observation. It publishes only
a safe draft view. Current-owner activation/pause commands require exact
verification digests and versions and retain immutable idempotent decisions.
Compiled artifacts are encrypted, retained for at most seven days, and limited
to32 named tools per owner. Guest status text cannot mint verification or activate
a tool. The selected component publishes a safe completion atomically with
current task, owner, epoch, verified artifact and physical accounting fences.
Authenticated owner routes list only closed tool metadata and accept exact
activation/pause decisions. Source, Core items, reasoning and private credentials
have no public route. Default native execution and worker startup remain disabled. Explicit local
synthetic qualification does not enable production placement or inference.


The controller observes kernel process groups and the exact original VM name.
Core is bounded to512MiB host RSS and a cumulative1MiB private log; the provider
process group is bounded to2GiB and the VM-only sample to1.5GiB. The group includes
the VM during initial startup, so those peaks overlap and must not be added.
The original signed journal admits at most two unresolved placements, including
those inherited after restart; a new gateway also admits at most two attempts.
Unknown physical cleanup retains scratch/capacity and blocks adoption. Signed
lifecycle/model journals have128-attempt envelopes and fail closed when full.
The compiled worker allows256MiB RSS,8MiB linear memory, finite fuel/CPU/wall time
and one process per invocation; isolated Python never writes dependency bytecode.

The local20-job sequence produced19 verified drafts and one privately rejected
oversized-output job, whose uncertain usage stayed held. With a retained immutable
image cache, allocation p50/p95 were7.042/7.234seconds and total job p50/p95 were
22.312/22.574seconds (20samples; p95 uses nearest rank). Five first jobs in a fresh
Core service and15 jobs with an already running service are recorded separately;
these totals exclude service startup and are not cold-install measurements.
A separate fresh service start took1.380seconds (one sample). Two overlapping jobs
completed in34.473seconds, each used a512MiB logical private upper (about237MB
allocated), and both upper directories and scratch were removed. Idle Core host
RSS was41,369,600bytes. These measured local scenarios are not production performance
promises. Failed reports remain failed; source-compatible completed passes are
retained and affected/unfinished checks resume after fixes.


G06 qualifies this explicit local synthetic Darwin ARM64 native profile and the
restricted offline compiled profile through cumulative, source-bound evidence.
The registered collection includes the retained G05 backend suites and native
accounting, tools, containment, lifecycle, governed reads, receipt recovery,
private workflow replay and controller recovery. Compatible completed passes
remain credited after impact review; affected and unfinished cases are rerun,
and failed aggregates retain their original status. Fresh fast/contract/installed
artifact and required host/data checks cover the coherent closure source.
C2/C3 local scenarios are complete. G07 qualifies local browser interaction,
and G09 qualifies local combined recovery and load. Linux Core/amd64, production
placement and inference, G10 and all 56 final release journeys remain separate gates. Default startup continues to serve health only.


The current production development profile extends the existing coordinated
archive/held-restore/release path with a typed original-root checkpoint. It pins
the current control migration and checksum, parent/child workload ownership,
original deadlines and pending reserved/running/UNKNOWN operation identities.
The original frozen0056 checkpoint remains distinct. Restoration inspects the
original private Agent workflow namespace and exact objective/execution queues
without decoding its private payloads. Quarantine pins the production journals
as well as the original task/accounting tables; it cannot release uncertain usage
or renew execution authority. Archived Agent history tickets and interactive
sessions remain retired. A fresh authenticated owner may observe accepted results
only through current Host/source checks and the certified restored key material.
Pending production reviewed-effect/repair handles require their exact versioned
production receipt capsules before release; the legacy observer cannot certify
them. Production privacy/lifecycle/fault coverage, complete deployment
profiles and actual AWS qualification remain separate gates. This extension does
not enable restored workers or change default health-only startup. Original
captured-input expiry still governs request labels and source-bound goal
observation for existing profiles. An explicitly registered `focused-child-reads/1`
revision2 instead observes its original question through the already metered,
encrypted first-planner input and immutable Core-bound read goal. Binding still
requires the live original capture and an executing original Root. Saved observation
requires current owner/Host/source authority and unexpired retained artifacts; it
cannot reopen an execution lease, duplicate work or renew any deadline. No new
private input copy or SQL revision is introduced. Explicit retained context
profiles also cover approved-memory discovery, registered owner replies, catalog
outcomes and composition, partial reads, and clarified calendar-period analysis.
Their versioned pins preserve the existing harness references, revisions and
worker wires. Observation checks the accepted original input, current discovery
and registered reply, including private-input checks after reading. A pending
bound question can supply its original label only before any final goal write;
an erased goal cannot restore that fallback. Exact private-goal erasure withholds
the answer, surface and saved question without changing accounting. Legacy
profiles keep their existing behavior. Local synthetic acceptance and actual
production deployment/release qualification remain separate gates.

G09 qualifies coordinated six-component recovery, M11/V08 privacy and original
receipt reconciliation, operator health/metrics, same-key rotation and independent
exact-pin recovery, Park/raw drain/recertification and independent wheel
rollout/rollback. Restoring an older unresolved OS checkpoint twice after newer
host outcomes and surviving Forget/Pause/Revoke preserves independent corrections
and host effect counts. Retired poisoned/waiting queues and original deadlines
stay fenced. Ready receipt-only observation works with absent private planes and
real certificate expiry; it grants no execution authority and keeps UNKNOWN usage
held. Archived sessions, challenges and executions remain retired.

Production receipt capsules distinguish original unresolved states. Version1
continues to admit only `UNKNOWN`; version2 can also pin an original `RUNNING`
effect after controller loss. The metadata-only port matches that exact saved
state, original accounting/deadline, decision, grant, provider and history. It
can observe the original Host receipt without hydrating private inputs, dispatching
or cancelling an effect, or settling/releasing usage. Version3 also pins a never-
begun `RESERVED` effect as not sent, without manufacturing a Host receipt or
releasing its original reservation. Version4 adds separately approved production
inverses and mixed original/inverse archives. It pins the original settled effect,
Root policy, approval, prepared grant, provider and both task histories. Its narrow
shared observer can append the inverse receipt while preserving original
RESERVED/RUNNING/UNKNOWN state, accounting and deadlines. A never-started inverse
has no Host receipt. Certified retired executions permit receipt observation
without private payload/key access, effect dispatch or renewed authority.
A current terminal
receipt with unresolved running usage supplies read-only reconciliation guidance;
the existing UI projects its heading only for the matching current segment and
sequence. The original task/attempt records and public history remain unchanged.
This engineering boundary does not qualify the complete fault matrix or production
deployment; actual signed restore, release and current-owner acceptance is recorded
separately in the implementation register.

The explicit local engineering harness `agent-sdk-repairable-change/1` admits one
registered typed-update repair under the original Root and deadline. Select it
before original admission; an existing closed Root cannot acquire this authority.
The shared repair executor uses policy8, metered original-root preparation/storage,
an independently confirmed owner decision and a distinct inverse invocation. The
legacy repair profile retains policy7 and its original contracts and accounting.

`IdentityRuntime.enable_agent_repairs` composes the existing reviewed runtime and
one shared effect-permit endpoint. The authenticated original task's `/repair`
view supplies its current repair controls. `/os/repairs` admits the exact original
receipt; preparation, fresh challenges/approval, execution, Stop, revocation and
receipt-only reconciliation use its existing subroutes. Execution requires the
original captured session, current source/Host authority and known original usage.
A new session can inspect receipts but cannot renew that captured authority.

The trusted review shows the original and repair separately, restores their
receipts after History/reload and clears both on current-access withdrawal.
Internal repair children are not ordinary conversation entries. UNKNOWN usage
remains held even when the application receipt proves that the inverse committed.
Only the exact expired, known repair child's private derivative is eligible for
authenticated erasure. The existing selected controller closes unused repair
authority at the original deadline after all work is known and zero held. A known,
unexecuted abandoned repair child expires without changing the original outcome;
the existing retention sweep may erase its derivative at its committed retention
deadline. Pending reservations, RUNNING/UNKNOWN work and quarantine remain held.
Complete repair recovery/lifecycle, system and production
deployment qualification remain separate gates; local synthetic selection does
not activate a production profile or cloud services.

Local Temporal provisioning can finish the missing RPC network attachment of its
signed, never-started container. Image, configuration, mounts, privileges, labels,
IPAM and actual peers are checked first; a nonzero published port, prior start or
foreign attachment cannot use this path. A lost connection acknowledgement is
resolved only by strict inspection of actual completion. Ordinary runtime checks
still require both networks. This completion neither starts a service nor adopts
an unknown resource. Prepared local verification may also pass an explicit owned
capacity source to the existing installer: its Docker endpoint and image must match,
and the existing bounded unprivileged Engine measurement supplies fresh capacity.
All nested reservations and storage floors remain enforced. Cold installation keeps
its original isolated probe; invalid evidence never becomes available capacity.

The frozen workload uses 32 actual owners across two unrelated hosts, 100 physical
and 64 current vectors per owner, concurrency 1/4/16 and 128 samples per cell.
Six actual Core/native drafts retain their original 45-second deadlines; three
current schedule drivers and twelve real PostgreSQL/embedding/pool/Park
interruptions meet the declared recovery and resource limits. Measurements use
an authenticated offline synthetic HTTP model and actual native VM/processes;
handler thread CPU is labeled separately. This does not qualify neural/live or
production inference, Linux native or hosting profiles.

The complete 4,792-case ledger uses owner-authorized impact-based resumption:
compatible actual completed cases retain exact source/body/report provenance,
changed and unfinished boundaries are requalified, and failed aggregates remain
failed. It is cumulative qualification, not one clean full final-source suite.
Current coherent 1,435 JavaScript checks, 444 closed contracts, required host/browser
checks, protected financial/state inventories and normal commit guards accompany
closure. Default startup stays health-only; restored native/learning/schedule
execution remains disabled. G10 and all 56 final release journeys are separate.
See [the bounded operator sequence](OPERATIONS.md).
# Registered analysis clarification

The explicit `VerifiedClarifiedAnalysis` profile combines the existing paged
analysis executor with current discovery and the existing owner-question UI.
Its `AgentAnalysisClarificationPolicy` pins a bounded business question, exact
choice IDs, metric shapes, query capability and scope-field labels. The admitted
harness digest binds that policy and the discovery capabilities. Core contains
no WP fields or amount-basis routing; the operator supplies domain semantics.

Discovery may precede the question. The installed SDK retains its accepted
discovery transcript and causal references across the finite owner wait. An
authenticated `analysis-basis` reply selects a registered choice; it cannot
grant authority, renew the Root, or override the captured request. The server
rejects unregistered replies and goal metrics that conflict with the selected
grain, value field, units, filters or conversion policy. Complete query chains
and the existing exact operator still determine completion.

The persistent answer states the registered basis and meaning, resolved scope
arguments and admitted time zone. Public guidance uses registered metadata,
never private planner notes. Recorded coverage does not establish expected
statement coverage. Local synthetic acceptance and live API/AWS qualification
remain separate; consult the current implementation evidence before claiming
either. Control0088 is additive to the original owner-reply guards; earlier
record-selection wires, journals and horizons retain their behavior.

`VerifiedPeriodClarifiedAnalysis` adds a declared calendar-period policy over
that same executor. Its registered field mapping names the query's inclusive
start/end arguments. Core resolves a single supported English `last N months`
phrase against the **original admission's local date**, clamps month-end days,
and rejects different proposed query dates. Explicit `completed` months (and
bare `last month`) end on the previous month's last day; an explicit date request
keeps its own dates. Multiple or unsupported relative-month phrases require a
new explicit scope rather than one guessed window. The resolver never reads the
current clock or renews a session, operation or Root.

The additive worker transport carries that resolved period through the existing
SDK checkpoint, owner wait and reply. The original policy pin and existing goal
record retain the declared meaning and resolved arguments; no new persisted
record or migration is needed. The answer discloses its date bounds/time zone
and registered amount treatment, including signed credits and the distinction
between net amounts and gross charges. Existing explicit-date clarification
profiles and contracts retain their behavior.

The separately selected `VerifiedNarratedComparison` presentation compiles
conversational statements from those same verified comparison pages. It quotes
the exact recorded base/current totals and signed ratio, explains separate display
rounding, and limits interpretation to the selected scope without inferring a
cause or price change. All original tables, charts, missing groups and current
source checks remain available. Long exact values stay intact in the typed table.

Its selected harness digest additionally pins the narration compiler and wrapper;
the original comparison profile retains its answer semantics. The SDK journey,
goal/manifest/verification contracts, numerical operator and frozen0089 guards are
reused unchanged. No new worker protocol, persisted type or migration is added.
Local synthetic acceptance does not establish live-model or AWS qualification.
