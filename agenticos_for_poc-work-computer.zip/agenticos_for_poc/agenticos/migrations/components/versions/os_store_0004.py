"""Reviewed original knowledge layers, encrypted chunks and purpose-separated ACLs."""
from alembic import context,op

revision='os_store_0004'
down_revision='os_store_0003'
branch_labels=None
depends_on=None
TABLES=("\nCREATE TABLE knowledge_generations (\n\tid UUID NOT NULL, \n\tgeneration BIGINT NOT NULL, \n\tprofile_ref VARCHAR(128) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_kb_generation_scope_id UNIQUE (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT uq_kb_generation_ordinal UNIQUE (installation_id, generation), \n\tCONSTRAINT fk_kb_generation_installation FOREIGN KEY(installation_id) REFERENCES os_store_registry (installation_id), \n\tCONSTRAINT ck_kb_generation_version CHECK (generation BETWEEN 1 AND 9007199254740991), \n\tCONSTRAINT ck_kb_generation_profile CHECK (profile_ref='minilm-english-onnx/1')\n)\n\n", "\nCREATE TABLE knowledge_documents (\n\tid UUID NOT NULL, \n\trevision BIGINT NOT NULL, \n\tactive_revision_id UUID NOT NULL, \n\tgeneration_id UUID NOT NULL, \n\tstate VARCHAR(16) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tupdated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_kb_document_scope_id UNIQUE (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT fk_kb_document_installation FOREIGN KEY(installation_id) REFERENCES os_store_registry (installation_id), \n\tCONSTRAINT ck_kb_document_revision CHECK (revision BETWEEN 1 AND 32 OR (revision=33 AND state='RETIRED')), \n\tCONSTRAINT ck_kb_document_state CHECK (state IN ('ACTIVE','RETIRED')), \n\tCONSTRAINT ck_kb_document_time CHECK (updated_at>=created_at), \n\tCONSTRAINT fk_kb_document_generation FOREIGN KEY(installation_id, application_id, tenant_id, generation_id) REFERENCES knowledge_generations (installation_id, application_id, tenant_id, id)\n)\n\n", "\nCREATE TABLE knowledge_publications (\n\tid UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tdocument_id UUID NOT NULL, \n\texpected_revision BIGINT NOT NULL, \n\taccepted_revision BIGINT NOT NULL, \n\tkind VARCHAR(16) NOT NULL, \n\tmac_key_id UUID NOT NULL, \n\trequest_mac VARCHAR(64) NOT NULL, \n\treceipt JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_kb_publication_scope_id UNIQUE (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT fk_kb_publication_document FOREIGN KEY(installation_id, application_id, tenant_id, document_id) REFERENCES knowledge_documents (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT uq_kb_publication_command UNIQUE (installation_id, application_id, tenant_id, command_id), \n\tCONSTRAINT uq_kb_publication_version UNIQUE (installation_id, application_id, tenant_id, document_id, accepted_revision), \n\tCONSTRAINT ck_kb_publication_kind CHECK (kind IN ('PUBLISH','RETIRE')), \n\tCONSTRAINT ck_kb_publication_versions CHECK (expected_revision BETWEEN 0 AND 32 AND accepted_revision=expected_revision+1 AND ((kind='PUBLISH' AND accepted_revision<=32) OR (kind='RETIRE' AND expected_revision>0 AND accepted_revision<=33))), \n\tCONSTRAINT ck_kb_publication_mac CHECK (request_mac ~ '^[0-9a-f]{64}$'), \n\tCONSTRAINT ck_kb_publication_receipt CHECK (jsonb_typeof(receipt)='object' AND octet_length(receipt::text)<=16384)\n)\n\n", '\nCREATE TABLE knowledge_revisions (\n\tid UUID NOT NULL, \n\tdocument_id UUID NOT NULL, \n\trevision BIGINT NOT NULL, \n\tgeneration_id UUID NOT NULL, \n\tlayer VARCHAR(16) NOT NULL, \n\ttrust VARCHAR(16) NOT NULL, \n\tauthority_ref VARCHAR(256) NOT NULL, \n\tsteward_ref VARCHAR(256) NOT NULL, \n\taudience VARCHAR(16) NOT NULL, \n\tpurposes JSONB NOT NULL, \n\tvalid_from TIMESTAMP WITH TIME ZONE NOT NULL, \n\tvalid_until TIMESTAMP WITH TIME ZONE, \n\tschema_ref VARCHAR(128) NOT NULL, \n\tmac_key_id UUID NOT NULL, \n\tkeyed_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_kb_revision_scope_id UNIQUE (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT fk_kb_revision_document FOREIGN KEY(installation_id, application_id, tenant_id, document_id) REFERENCES knowledge_documents (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT fk_kb_revision_generation FOREIGN KEY(installation_id, application_id, tenant_id, generation_id) REFERENCES knowledge_generations (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT uq_kb_document_revision UNIQUE (installation_id, application_id, tenant_id, document_id, revision), \n\tCONSTRAINT uq_kb_revision_document_id UNIQUE (installation_id, application_id, tenant_id, document_id, id), \n\tCONSTRAINT ck_kb_revision_version CHECK (revision BETWEEN 1 AND 32), \n\tCONSTRAINT ck_kb_revision_layer CHECK (layer IN (\'business\',\'architecture\',\'system\',\'shared\')), \n\tCONSTRAINT ck_kb_revision_trust CHECK (trust IN (\'reviewed\',\'protected\')), \n\tCONSTRAINT ck_kb_revision_audience CHECK (audience IN (\'planner\',\'public\') AND (trust<>\'protected\' OR audience=\'planner\')), \n\tCONSTRAINT ck_kb_revision_purpose CHECK (jsonb_typeof(purposes)=\'array\' AND jsonb_array_length(purposes) BETWEEN 1 AND 2 AND purposes <@ \'["planner.read/1","public.metadata/1"]\'::jsonb), \n\tCONSTRAINT ck_kb_revision_validity CHECK (valid_until IS NULL OR valid_until>valid_from), \n\tCONSTRAINT ck_kb_revision_schema CHECK (schema_ref=\'OSReviewedKnowledge/1\'), \n\tCONSTRAINT ck_kb_revision_digest CHECK (keyed_digest ~ \'^[0-9a-f]{64}$\')\n)\n\n', "\nCREATE TABLE knowledge_chunks (\n\tid UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\tordinal INTEGER NOT NULL, \n\tembedding VECTOR(384) NOT NULL, \n\tenvelope JSONB NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_kb_chunk_scope_id UNIQUE (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT fk_kb_chunk_revision FOREIGN KEY(installation_id, application_id, tenant_id, revision_id) REFERENCES knowledge_revisions (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT uq_kb_chunk_ordinal UNIQUE (installation_id, application_id, tenant_id, revision_id, ordinal), \n\tCONSTRAINT ck_kb_chunk_ordinal CHECK (ordinal BETWEEN 0 AND 7), \n\tCONSTRAINT ck_kb_chunk_vector CHECK (vector_dims(embedding)=384 AND abs(vector_norm(embedding)-1)<0.00001), \n\tCONSTRAINT ck_kb_chunk_envelope CHECK (COALESCE(envelope=jsonb_build_object('version',1,'keyId',envelope->'keyId','nonce',envelope->'nonce','ciphertext',envelope->'ciphertext') AND jsonb_typeof(envelope->'keyId')='string' AND envelope->>'keyId' ~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' AND jsonb_typeof(envelope->'nonce')='string' AND length(envelope->>'nonce')=16 AND jsonb_typeof(envelope->'ciphertext')='string' AND length(envelope->>'ciphertext') BETWEEN 24 AND 12000,false)), \n\tCONSTRAINT ck_kb_chunk_digest CHECK (ciphertext_digest ~ '^[0-9a-f]{64}$')\n)\n\n", '\nCREATE TABLE knowledge_source_links (\n\trevision_id UUID NOT NULL, \n\tordinal INTEGER NOT NULL, \n\tsource_ref VARCHAR(256) NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (revision_id, ordinal), \n\tCONSTRAINT fk_kb_source_revision FOREIGN KEY(installation_id, application_id, tenant_id, revision_id) REFERENCES knowledge_revisions (installation_id, application_id, tenant_id, id), \n\tCONSTRAINT uq_kb_source_ref UNIQUE (installation_id, application_id, tenant_id, revision_id, source_ref), \n\tCONSTRAINT ck_kb_source_ordinal CHECK (ordinal BETWEEN 0 AND 31)\n)\n\n', 'ALTER TABLE knowledge_documents ADD CONSTRAINT fk_kb_document_active_revision FOREIGN KEY(installation_id, application_id, tenant_id, id, active_revision_id) REFERENCES knowledge_revisions (installation_id, application_id, tenant_id, document_id, id) DEFERRABLE INITIALLY DEFERRED', 'CREATE INDEX ix_kb_chunk_scope ON knowledge_chunks (installation_id, application_id, tenant_id, revision_id)')

GUARDS=r"""
CREATE FUNCTION os_guard_knowledge_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'knowledge_revision_retained';END $$;

CREATE FUNCTION os_guard_knowledge_document() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'knowledge_document_retained';END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.revision<>1 OR NEW.state<>'ACTIVE' OR NEW.created_at<>NEW.updated_at
   THEN RAISE EXCEPTION 'knowledge_document_initial';END IF;
 ELSE
  IF OLD.state<>'ACTIVE' OR NEW.revision<>OLD.revision+1 OR NEW.updated_at<OLD.updated_at
   OR (to_jsonb(NEW)-ARRAY['revision','active_revision_id','generation_id','state','updated_at']) IS DISTINCT FROM
      (to_jsonb(OLD)-ARRAY['revision','active_revision_id','generation_id','state','updated_at'])
   OR (NEW.state='RETIRED' AND ROW(NEW.active_revision_id,NEW.generation_id) IS DISTINCT FROM
      ROW(OLD.active_revision_id,OLD.generation_id))
   OR (NEW.state='ACTIVE' AND (NEW.active_revision_id=OLD.active_revision_id OR NEW.generation_id=OLD.generation_id))
   THEN RAISE EXCEPTION 'knowledge_document_transition';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_assert_knowledge_document(did uuid,accepted bigint) RETURNS void LANGUAGE plpgsql AS $$
DECLARE d knowledge_documents%ROWTYPE; r knowledge_revisions%ROWTYPE; g knowledge_generations%ROWTYPE;
 p knowledge_publications%ROWTYPE; chunks bigint; counter os_store_registry%ROWTYPE;
BEGIN
 SELECT * INTO d FROM knowledge_documents WHERE id=did;
 SELECT * INTO r FROM knowledge_revisions WHERE id=d.active_revision_id;
 SELECT * INTO g FROM knowledge_generations WHERE id=d.generation_id;
 SELECT * INTO p FROM knowledge_publications WHERE document_id=did AND accepted_revision=accepted;
 SELECT * INTO counter FROM os_store_registry WHERE installation_id=d.installation_id;
 SELECT count(*) INTO chunks FROM knowledge_chunks WHERE revision_id=r.id;
 IF d.id IS NULL OR r.id IS NULL OR g.id IS NULL OR p.id IS NULL OR r.document_id<>d.id
  OR r.generation_id<>g.id OR counter.component<>'knowledge' OR counter.generation<g.generation
  OR d.revision<>accepted OR chunks NOT BETWEEN 1 AND 8
  OR EXISTS(SELECT 1 FROM knowledge_chunks WHERE revision_id=r.id AND ordinal>=chunks)
  OR (SELECT count(*) FROM knowledge_documents WHERE installation_id=d.installation_id
      AND application_id=d.application_id AND tenant_id=d.tenant_id)>64
  OR p.receipt IS DISTINCT FROM jsonb_build_object('commandId',p.command_id,'documentId',d.id,
      'revision',accepted,'revisionId',r.id,'generation',g.generation,'state',d.state)
  OR (d.state='ACTIVE' AND (r.revision<>d.revision OR p.kind<>'PUBLISH' OR p.created_at<>r.created_at
      OR g.created_at<>r.created_at OR d.updated_at<>r.created_at))
  OR (d.state='RETIRED' AND (p.kind<>'RETIRE' OR r.revision<>d.revision-1 OR p.created_at<>d.updated_at))
  THEN RAISE EXCEPTION 'knowledge_exact_publication';END IF;
END $$;

CREATE FUNCTION os_commit_knowledge_publication() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_TABLE_NAME='knowledge_documents' THEN
  PERFORM os_assert_knowledge_document(NEW.id,NEW.revision);
 ELSE
  PERFORM os_assert_knowledge_document(NEW.document_id,NEW.accepted_revision);
 END IF;
 RETURN NULL;
END $$;

CREATE TRIGGER guard_knowledge_document BEFORE INSERT OR UPDATE OR DELETE ON knowledge_documents
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_document();
CREATE TRIGGER guard_knowledge_generation BEFORE UPDATE OR DELETE ON knowledge_generations
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_immutable();
CREATE TRIGGER guard_knowledge_revision BEFORE UPDATE OR DELETE ON knowledge_revisions
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_immutable();
CREATE TRIGGER guard_knowledge_chunk BEFORE UPDATE OR DELETE ON knowledge_chunks
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_immutable();
CREATE TRIGGER guard_knowledge_source BEFORE UPDATE OR DELETE ON knowledge_source_links
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_immutable();
CREATE TRIGGER guard_knowledge_publication BEFORE UPDATE OR DELETE ON knowledge_publications
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_knowledge_document AFTER INSERT OR UPDATE ON knowledge_documents
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_knowledge_publication();
CREATE CONSTRAINT TRIGGER commit_knowledge_publication AFTER INSERT ON knowledge_publications
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_knowledge_publication();
"""

POLICY=r"""current_setting('agentic.knowledge_purpose',true)='planner.read/1'
 AND installation_id::text=(nullif(current_setting('agentic.knowledge_scope',true),'')::jsonb->>'installationId')
 AND application_id::text=(nullif(current_setting('agentic.knowledge_scope',true),'')::jsonb->>'applicationId')
 AND tenant_id=(nullif(current_setting('agentic.knowledge_scope',true),'')::jsonb->>'tenantId')"""

VIEW=r"""
CREATE VIEW knowledge_public_metadata WITH (security_barrier=true) AS
 SELECT d.id AS document_id,r.revision,r.layer,r.authority_ref,r.steward_ref,r.schema_ref,g.profile_ref,r.valid_until
 FROM knowledge_documents d JOIN knowledge_revisions r ON r.id=d.active_revision_id
 JOIN knowledge_generations g ON g.id=r.generation_id
 WHERE current_setting('agentic.knowledge_purpose',true)='public.metadata/1'
 AND d.installation_id::text=(nullif(current_setting('agentic.knowledge_scope',true),'')::jsonb->>'installationId')
 AND d.application_id::text=(nullif(current_setting('agentic.knowledge_scope',true),'')::jsonb->>'applicationId')
 AND d.tenant_id=(nullif(current_setting('agentic.knowledge_scope',true),'')::jsonb->>'tenantId')
 AND d.state='ACTIVE' AND r.audience='public' AND r.trust='reviewed'
 AND r.purposes @> '["public.metadata/1"]'::jsonb
 AND r.valid_from<=clock_timestamp() AND (r.valid_until IS NULL OR r.valid_until>clock_timestamp())
"""

def upgrade():
    component=context.config.attributes.get('component')
    if component not in {'retrieval','knowledge'}:raise RuntimeError('Explicit validated component owner required')
    if component!='knowledge':return
    for statement in TABLES:op.execute(statement)
    op.execute(GUARDS)
    for table in ('knowledge_documents','knowledge_generations','knowledge_revisions','knowledge_chunks','knowledge_source_links','knowledge_publications'):
        op.execute('ALTER TABLE '+table+' ENABLE ROW LEVEL SECURITY')
        op.execute('CREATE POLICY knowledge_planner_scope ON '+table+' FOR SELECT USING ('+POLICY+')')
    op.execute(VIEW)

def downgrade():
    raise RuntimeError('Protected forward recovery required; reviewed knowledge is retained')
