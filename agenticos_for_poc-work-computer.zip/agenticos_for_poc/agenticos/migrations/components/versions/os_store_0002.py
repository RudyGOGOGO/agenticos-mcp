"""Owner-scoped immutable personal retrieval projections; no canonical authority."""
from alembic import op, context
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg
from pgvector.sqlalchemy import VECTOR
from uuid import UUID

revision="os_store_0002"
down_revision="os_store_0001"
branch_labels=None
depends_on=None
OWNER=["installation_id","application_id","tenant_id","subject_id"]


def upgrade():
    component=context.config.attributes.get("component")
    if component not in {"retrieval","knowledge"}:
        raise RuntimeError("Explicit validated component owner required")
    installation=context.config.attributes.get("installation_id")
    if type(installation) is not UUID:
        raise RuntimeError("Explicit validated component installation required")
    db=op.get_bind()
    db.execute(sa.text("INSERT INTO os_store_registry (installation_id,component,generation,content_revision) "
        "VALUES (:installation,:component,1,0) ON CONFLICT (installation_id) DO NOTHING"),
        dict(installation=installation,component=component))
    if db.execute(sa.text("SELECT component FROM os_store_registry WHERE installation_id=:installation"),
                  dict(installation=installation)).scalar_one()!=component:
        raise RuntimeError("Component registry ownership mismatch")
    if component!="retrieval":
        return
    op.create_table("personal_knowledge_vectors",
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),
        *[sa.Column(n,pg.UUID(as_uuid=True),nullable=False) for n in OWNER[:2]],
        *[sa.Column(n,sa.String(256),nullable=False) for n in OWNER[2:]],
        *[sa.Column(n,pg.UUID(as_uuid=True),nullable=False) for n in ("entry_id","revision_id")],
        *[sa.Column(n,sa.BigInteger,nullable=False) for n in ("entry_version","index_generation")],
        sa.Column("profile_ref",sa.String(64),nullable=False),sa.Column("lane",sa.String(16),nullable=False),
        sa.Column("context_ref",sa.String(64),nullable=False),
        sa.Column("embedding",VECTOR(384),nullable=False),sa.Column("lexemes",pg.TSVECTOR,nullable=False),
        sa.ForeignKeyConstraint(["installation_id"],["os_store_registry.installation_id"],name="fk_personal_vector_installation"),
        sa.UniqueConstraint(*OWNER,"id",name="uq_personal_vector_owner_id"),
        sa.UniqueConstraint(*OWNER,"entry_id","revision_id","entry_version","index_generation","profile_ref",
            name="uq_personal_vector_revision"),
        sa.CheckConstraint("entry_version>0 AND index_generation>0",name="ck_personal_vector_versions"),
        sa.CheckConstraint("profile_ref='minilm-english-onnx/1'",name="ck_personal_vector_profile"),
        sa.CheckConstraint("lane IN ('preference','episodic','semantic','procedural')",name="ck_personal_vector_lane"),
        sa.CheckConstraint("context_ref='general/1' OR context_ref ~ '^context/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/1$'",
            name="ck_personal_vector_context"),
        sa.CheckConstraint("vector_dims(embedding)=384 AND abs(vector_norm(embedding)-1)<0.00001",
            name="ck_personal_vector_normalization"))
    op.create_index("ix_personal_vector_scope","personal_knowledge_vectors",[*OWNER,"index_generation","profile_ref","lane","context_ref"])
    op.create_index("ix_personal_vector_fts","personal_knowledge_vectors",["lexemes"],postgresql_using="gin")
    op.create_index("ix_personal_vector_hnsw","personal_knowledge_vectors",["embedding"],postgresql_using="hnsw",
        postgresql_with={"m":16,"ef_construction":64},postgresql_ops={"embedding":"vector_cosine_ops"})
    op.execute(r"""
CREATE FUNCTION os_guard_personal_vector() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'personal_vector_immutable'; END $$;
CREATE TRIGGER immutable_personal_vector BEFORE UPDATE ON personal_knowledge_vectors
 FOR EACH ROW EXECUTE FUNCTION os_guard_personal_vector();
ALTER TABLE personal_knowledge_vectors ENABLE ROW LEVEL SECURITY;
CREATE POLICY personal_vector_owner ON personal_knowledge_vectors FOR ALL
 USING (
  installation_id::text=(nullif(current_setting('agentic.owner_scope',true),'')::jsonb->>'installationId')
  AND application_id::text=(nullif(current_setting('agentic.owner_scope',true),'')::jsonb->>'applicationId')
  AND tenant_id=(nullif(current_setting('agentic.owner_scope',true),'')::jsonb->>'tenantId')
  AND subject_id=(nullif(current_setting('agentic.owner_scope',true),'')::jsonb->>'subjectId'));
""")


def downgrade():
    raise RuntimeError("Protected forward recovery required; populated projections are governed private data")
