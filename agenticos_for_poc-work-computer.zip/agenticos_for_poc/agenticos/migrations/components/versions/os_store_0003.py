"""Monotonic private projection barriers; late writes cannot resurrect derivatives."""
from alembic import context, op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "os_store_0003"
down_revision = "os_store_0002"
branch_labels = None
depends_on = None
OWNER = ["installation_id", "application_id", "tenant_id", "subject_id"]


def upgrade():
    component = context.config.attributes.get("component")
    if component not in {"retrieval", "knowledge"}:
        raise RuntimeError("Explicit validated component owner required")
    if component != "retrieval":
        return
    op.create_table("personal_knowledge_fences",
        *[sa.Column(n, pg.UUID(as_uuid=True), nullable=False) for n in OWNER[:2]],
        *[sa.Column(n, sa.String(256), nullable=False) for n in OWNER[2:]],
        sa.Column("entry_id", pg.UUID(as_uuid=True), nullable=False),
        sa.Column("minimum_version", sa.BigInteger, nullable=False),
        sa.Column("forgotten", sa.Boolean, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint(*OWNER, "entry_id", name="pk_personal_fence_owner_entry"),
        sa.ForeignKeyConstraint(["installation_id"], ["os_store_registry.installation_id"],
                                name="fk_personal_fence_installation"),
        sa.CheckConstraint("minimum_version BETWEEN 1 AND 9007199254740991", name="ck_personal_fence_version"),
        sa.CheckConstraint("updated_at>=created_at", name="ck_personal_fence_time"))
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError("Protected forward recovery required; deletion barriers are retained")


GUARDS = r"""
CREATE FUNCTION os_guard_personal_fence() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'personal_fence_retained'; END IF;
 PERFORM set_config('lock_timeout','2s',true);
 PERFORM set_config('statement_timeout','3s',true);
 PERFORM pg_advisory_xact_lock(60501,hashtext(current_setting('agentic.owner_scope',true)));
 IF TG_OP='INSERT' THEN
  IF NEW.created_at<>NEW.updated_at THEN RAISE EXCEPTION 'personal_fence_initial'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['minimum_version','forgotten','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['minimum_version','forgotten','updated_at'])
   OR NEW.minimum_version<OLD.minimum_version OR (OLD.forgotten AND NOT NEW.forgotten)
   OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'personal_fence_monotonic'; END IF;
 END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER guard_personal_fence BEFORE INSERT OR UPDATE OR DELETE ON personal_knowledge_fences
 FOR EACH ROW EXECUTE FUNCTION os_guard_personal_fence();
CREATE FUNCTION os_guard_personal_vector_insert() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE barrier personal_knowledge_fences%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);
 PERFORM set_config('statement_timeout','3s',true);
 PERFORM pg_advisory_xact_lock(60501,hashtext(current_setting('agentic.owner_scope',true)));
 SELECT * INTO barrier FROM personal_knowledge_fences
  WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
   AND tenant_id=NEW.tenant_id AND subject_id=NEW.subject_id AND entry_id=NEW.entry_id;
 IF barrier.entry_id IS NOT NULL AND (barrier.forgotten OR NEW.entry_version<barrier.minimum_version)
  THEN RAISE EXCEPTION 'personal_vector_obsolete'; END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER guard_personal_vector_insert BEFORE INSERT ON personal_knowledge_vectors
 FOR EACH ROW EXECUTE FUNCTION os_guard_personal_vector_insert();
ALTER TABLE personal_knowledge_fences ENABLE ROW LEVEL SECURITY;
CREATE POLICY personal_fence_owner ON personal_knowledge_fences FOR ALL USING (
 installation_id::text=(nullif(current_setting('agentic.owner_scope',true),'')::jsonb->>'installationId')
 AND application_id::text=(nullif(current_setting('agentic.owner_scope',true),'')::jsonb->>'applicationId')
 AND tenant_id=(nullif(current_setting('agentic.owner_scope',true),'')::jsonb->>'tenantId')
 AND subject_id=(nullif(current_setting('agentic.owner_scope',true),'')::jsonb->>'subjectId'));
"""
