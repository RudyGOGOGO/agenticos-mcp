"""Component registry root; owning memory/KB phases add their own revisions."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision = 'os_store_0001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('os_store_registry',
        sa.Column('installation_id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('component', sa.String(16), nullable=False),
        sa.Column('generation', sa.BigInteger, nullable=False),
        sa.Column('content_revision', sa.BigInteger, nullable=False),
        sa.CheckConstraint("component IN ('retrieval','knowledge')", name='ck_store_component'),
        sa.CheckConstraint('generation>0 AND content_revision>=0', name='ck_store_versions'))


def downgrade():
    raise RuntimeError('Destructive downgrade disabled')
