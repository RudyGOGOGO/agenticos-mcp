from alembic import context
from agentic_os.adapters.postgres.component_checks import component_metadata
from agentic_os.adapters.postgres.migrate import bind_source_revisions
connection = context.config.attributes.get('connection')
if connection is None:
    raise RuntimeError('Explicit validated component connection required')
if context.is_offline_mode():
    raise RuntimeError('OS components require an explicit validated live connection')
context.configure(connection=connection,
    target_metadata=component_metadata(context.config.attributes.get('component'),storage_profile=context.config.attributes.get('storage_profile')),
    compare_type=True,compare_server_default=True)
bind_source_revisions(context.get_context().script,context.config.get_main_option('script_location'),storage_profile=context.config.attributes.get('storage_profile'))
with context.begin_transaction():
    context.run_migrations()
