"""Original-root bounded metadata discovery and exact selected read tools.

Draft87 requires protected populated runtime/negative and recovery acceptance.
Applied86 and earlier remain immutable; legacy guard branches are unchanged.
"""
from alembic import op

revision='os_pg_0087'
down_revision='os_pg_0086'
branch_labels=None
depends_on=None

HELPERS=r"""
CREATE FUNCTION os_agent_discovery_profile_valid(r jsonb, installation uuid, application uuid, generation bigint, registration bigint)
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE p jsonb;
BEGIN
 p=r->'planning';
 RETURN COALESCE(r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
  'harness',r->'harness','installationId',installation,'applicationId',application,
  'outputContract','AgentCapabilityDiscoveryPage/1','adapterRef','os.capabilities.discover/1',
  'scopePolicyRef','current-task-capability-metadata/1','providerRef','os.capability-catalog/1','planning',p)
  AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
  AND p=jsonb_build_object('id',p->'id','revision',p->'revision','capability',r->'capability',
   'selection','current-goal-read-tools/1','goalContract','AgentReadGoalDraft/1')
  AND p->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND jsonb_typeof(p->'revision')='number' AND p->>'revision' ~ '^[1-9][0-9]*$' AND (p->>'revision')::numeric<=9007199254740991
  AND r->'harness'->>'ref'='governed-read-discovery/'||os_agent_profile_digest('manifest',p)
  AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=installation
   AND registered.application_id=application AND registered.application_generation=generation
   AND registered.registration_revision=registration AND registered.payload->'harness'->'harness'=r->'harness'
   AND registered.payload->'capabilities'->'allowedKinds' @> '["read"]'::jsonb)
  AND EXISTS(SELECT 1 FROM os_agent_capabilities cap WHERE cap.installation_id=installation AND cap.application_id=application
   AND cap.application_generation=generation AND r->'capability'=os_agent_profile_pin(cap.payload,'manifest')
   AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='os.capabilities.discover/1'
   AND cap.payload->>'scopePolicyRef'='current-task-capability-metadata/1' AND cap.payload->'mcp'='null'::jsonb
   AND cap.payload->>'lifecycle'='qualified'),false);
END $$;

CREATE FUNCTION os_agent_discovery_profile(a os_admissions) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE app os_applications%ROWTYPE; lane os_agent_tool_profiles%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO app FROM os_applications WHERE installation_id=a.installation_id AND id=a.application_id;
 IF NOT COALESCE(app.active AND app.revision=a.registration_revision,false)
  OR (SELECT count(*) FROM os_agent_tool_profiles p WHERE p.installation_id=a.installation_id AND p.application_id=a.application_id
   AND p.application_generation=app.generation AND p.registration_revision=app.revision
   AND p.payload->'discovery'->'harness'=a.context->'harness')<>1 THEN RAISE EXCEPTION 'agent_discovery_profile_current';END IF;
 SELECT * INTO lane FROM os_agent_tool_profiles p WHERE p.installation_id=a.installation_id AND p.application_id=a.application_id
  AND p.application_generation=app.generation AND p.registration_revision=app.revision
  AND p.payload->'discovery'->'harness'=a.context->'harness';
 IF NOT COALESCE(lane.digest=os_agent_profile_digest('policy',lane.payload)
  AND lane.policy_digest=os_agent_profile_digest('manifest',lane.payload->'execution')
  AND lane.payload->'execution'->'discoveryProfile'=os_agent_profile_pin(lane.payload->'discovery','manifest')
  AND os_agent_discovery_profile_valid(lane.payload->'discovery',app.installation_id,app.id,app.generation,app.revision),false)
 THEN RAISE EXCEPTION 'agent_discovery_profile_binding';END IF;
 RETURN lane.payload->'discovery'->'planning';
END $$;
"""

GUARDS=r"""
CREATE OR REPLACE FUNCTION os_assert_agent_tool_current(o os_agent_tool_operations) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; app os_applications%ROWTYPE; parent os_agent_operations%ROWTYPE;
 accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; w os_agent_payload_writes%ROWTYPE; cap os_agent_capabilities%ROWTYPE;
 c jsonb; i jsonb; dep jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM os_assert_agent_memory_context(o.payload->'context',true);
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=o.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (o.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=o.root_id)) ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=o.root_id FOR UPDATE;SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=o.installation_id AND id=o.application_id;
 c:=o.payload->'context';i:=o.payload->'identity';dep:=o.payload->'modelResult';
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO parent FROM os_agent_operations WHERE id=o.parent_operation_id;
 SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=o.source_acceptance_id;
 SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
 SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=o.binding_id;
 SELECT * INTO w FROM os_agent_payload_writes WHERE id=f.write_id;
 SELECT * INTO cap FROM os_agent_capabilities WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND application_generation=app.generation AND capability_ref=o.payload->'capability'->>'ref' ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND r.accounting_format='agent-resources/1'
 AND ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
 AND os_agent_context_matches(a,c) AND o.task_id=r.root_task_id AND o.digest=os_agent_profile_digest('command',o.payload)
 AND o.payload=jsonb_build_object('context',c,'identity',i,'binding',o.payload->'binding','modelOperationId',o.parent_operation_id,
  'modelResult',dep,'capability',o.payload->'capability','profile',o.payload->'profile')
 AND i=jsonb_build_object('operationId',o.id,'taskId',o.task_id,'rootId',o.root_id,'segmentId',a.segment_id,
  'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','planRevision',parent.payload->'identity'->'planRevision',
  'parentOperationId',o.parent_operation_id,'iteration',parent.payload->'identity'->'iteration','kind','tool','inputDigest',i->'inputDigest')
 AND i->>'inputDigest' ~ '^[a-f0-9]{64}$' AND parent.root_id=o.root_id AND parent.payload->'context'=c
 AND producer.root_id=o.root_id AND producer.request->'context'=c AND producer.expires_at>clock_timestamp()
 AND EXISTS(SELECT 1 FROM os_agent_operation_models link WHERE link.operation_id=parent.id AND link.id=producer.id)
 AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
   'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
   'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
   'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
 AND (dep->>'acceptedAt')::timestamptz=accepted.created_at
 AND ROW(producer.installation_id,producer.application_id,producer.tenant_id,producer.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND (w.model_context=c OR w.model_context IS NULL AND c=a.context AND c->'harness'->>'ref' NOT LIKE 'private-planned-read/%')
 AND w.task_id=o.task_id AND w.root_id=o.root_id AND w.schema_ref='AgentSDKToolBinding' AND w.schema_version=1 AND w.expires_at>clock_timestamp()
 AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND o.payload->'binding'=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',w.plain_bytes,'schemaRef',w.schema_ref,'schemaVersion',w.schema_version)
 AND p.application_generation=app.generation AND p.registration_revision=app.revision AND p.digest=os_agent_profile_digest('policy',p.payload)
 AND o.payload->'profile'=jsonb_build_object('ref',p.payload->'execution'->'id','revision',p.payload->'execution'->'revision','digest',p.policy_digest)
 AND ((p.payload->'read'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='mcp.read/1')
 OR (p.payload->'preparation'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='propose'
  AND cap.payload->>'adapterRef'='typed.prepare/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'memory'->'capability'=o.payload->'capability' AND p.payload->'memory'->'harness'=c->'harness'
  AND p.payload->'memory'->>'installationId'=o.installation_id::text
  AND p.payload->'memory'->>'applicationId'=o.application_id::text AND cap.payload->>'kind'='memory'
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)
  AND cap.payload->>'adapterRef'='owner.memory.read/1' AND cap.payload->>'scopePolicyRef'='owner-approved-memory/1'
  AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'knowledge'->'capability'=o.payload->'capability' AND p.payload->'knowledge'->'harness'=c->'harness'
  AND c<>a.context AND p.payload->'knowledge'->'planning'=os_agent_planning_profile(a)
  AND p.payload->'knowledge'->>'installationId'=o.installation_id::text
  AND p.payload->'knowledge'->>'applicationId'=o.application_id::text
  AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='private.knowledge.read/1'
  AND cap.payload->>'scopePolicyRef'='private-reviewed-knowledge/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'discovery'->'capability'=o.payload->'capability' AND p.payload->'discovery'->'harness'=c->'harness'
  AND c=a.context AND p.payload->'discovery'->'planning'=os_agent_discovery_profile(a)
  AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='os.capabilities.discover/1'
  AND cap.payload->>'scopePolicyRef'='current-task-capability-metadata/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix))
 OR (p.payload->'proactive'->'capability'=o.payload->'capability' AND p.payload->'proactive'->'harness'=c->'harness'
  AND c=a.context AND p.payload->'proactive'->'planning'=os_agent_proactive_profile(a)
  AND cap.payload->>'kind'='schedule' AND cap.payload->>'adapterRef'='os.proactivity.prepare/1'
  AND cap.payload->>'scopePolicyRef'='owner-reviewed-proactivity/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)))
 AND os_agent_capability_matches(a,c,o.payload->'capability')
 AND cap.payload->>'lifecycle'='qualified' AND cap.payload->>'purpose'=c->>'purpose'
 AND o.payload->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
 AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=o.task_id
  AND k.state='ACTIVE' AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp()
  AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
 AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.task_id=o.task_id AND s.state='OPEN'),false)
 THEN RAISE EXCEPTION 'agent_tool_operation_binding'; END IF;
END $$;

CREATE OR REPLACE FUNCTION os_assert_agent_input_dependency(dep jsonb, c jsonb, root uuid, before_at timestamp with time zone) RETURNS void LANGUAGE plpgsql AS $$
DECLARE accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 tool_accepted os_agent_tool_acceptances%ROWTYPE; tool os_agent_tool_calls%ROWTYPE; tool_archive os_agent_tool_archives%ROWTYPE;
 page os_agent_input_result_sets%ROWTYPE; artifact os_artifacts%ROWTYPE; expected_schema text;
BEGIN

 IF dep->'payload'->>'schemaRef'='AgentNativeAnalysisResult' THEN
  PERFORM os_assert_agent_native_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 IF dep->'payload'->>'schemaRef'='AgentQueryFactSet' THEN
  PERFORM os_assert_agent_query_fact_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 IF dep->'payload'->>'schemaRef'='AgentOwnerReply' THEN
  PERFORM os_assert_agent_owner_reply_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF dep->'payload'->>'schemaRef'='AgentProviderResponse' THEN
  SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=(dep->>'resultId')::uuid;
  SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
  SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
  IF NOT COALESCE(producer.root_id=root AND os_agent_source_context(c,producer.request->'context') AND producer.request->'context'->'subject'=c->'subject'
   AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
    'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
     'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
    'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
   AND (dep->>'acceptedAt')::timestamptz=accepted.created_at AND accepted.created_at<=before_at AND producer.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSIF dep->'payload'->>'schemaRef' IN ('EvidencePage','AgentQueryPage','AgentMemoryPage','AgentPrivateKnowledgePage','AgentProactivePreparation','AgentCapabilityDiscoveryPage') THEN
  SELECT * INTO tool_accepted FROM os_agent_tool_acceptances WHERE id=(dep->>'resultId')::uuid;
  SELECT * INTO tool FROM os_agent_tool_calls WHERE id=tool_accepted.call_id;
  SELECT * INTO tool_archive FROM os_agent_tool_archives WHERE id=tool_accepted.artifact_id;
  SELECT CASE WHEN p.payload ? 'discovery' THEN 'AgentCapabilityDiscoveryPage' WHEN p.payload ? 'proactive' THEN 'AgentProactivePreparation' WHEN p.payload ? 'knowledge' THEN 'AgentPrivateKnowledgePage' WHEN p.payload ? 'memory' THEN 'AgentMemoryPage' ELSE CASE p.payload->'read'->>'outputContract' WHEN 'EvidencePage/1' THEN 'EvidencePage' WHEN 'AgentQueryPage/1' THEN 'AgentQueryPage' END END INTO expected_schema
   FROM os_agent_tool_profiles p WHERE p.installation_id=tool.installation_id AND p.application_id=tool.application_id
    AND p.policy_digest=tool.request->'record'->'profile'->>'digest';
  IF expected_schema='AgentPrivateKnowledgePage' THEN
   PERFORM os_assert_agent_memory_context(tool.request->'record'->'context',true);
   IF tool_accepted.knowledge_source->'result' IS DISTINCT FROM dep THEN RAISE EXCEPTION 'agent_knowledge_dependency_receipt';END IF;
  END IF;
  IF expected_schema='AgentMemoryPage' THEN
   PERFORM os_assert_agent_memory_context(tool.request->'record'->'context',true);
   IF tool_accepted.memory_source->'result' IS DISTINCT FROM dep THEN RAISE EXCEPTION 'agent_memory_dependency_receipt';END IF;
  END IF;
  IF NOT COALESCE(expected_schema=dep->'payload'->>'schemaRef' AND tool.root_id=root AND os_agent_source_context(c,tool.request->'record'->'context') AND tool.request->'record'->'context'->'subject'=c->'subject'
   AND dep=jsonb_build_object('subject',c->'subject','taskId',tool.request->'record'->'context'->'taskId','rootId',tool.root_id,
    'resultId',tool_accepted.id,'producerStepId',tool.id,'acceptedAttemptId',tool.attempt_id,
    'payload',jsonb_build_object('artifactRef','artifact/'||tool_archive.id,'ciphertextDigest',tool_archive.ciphertext_digest,
     'bytes',tool_archive.plain_bytes,'schemaRef',expected_schema,'schemaVersion',1),
    'lineageRef',null,'scopeRef',tool.request->'record'->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
   AND (dep->>'acceptedAt')::timestamptz=tool_accepted.created_at AND tool_accepted.created_at<=before_at AND tool.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSIF dep->'payload'->>'schemaRef'='AgentInputResultSet' THEN
  SELECT * INTO page FROM os_agent_input_result_sets WHERE id=(dep->>'producerStepId')::uuid;
  SELECT * INTO artifact FROM os_artifacts WHERE id=page.artifact_id;
  IF NOT COALESCE(page.root_id=root AND os_agent_source_context(c,page.record->'context') AND page.reference=dep
   AND page.created_at<=before_at AND artifact.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSE RAISE EXCEPTION 'agent_operation_dependency';
 END IF;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_tool_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_applications%ROWTYPE; p jsonb; r jsonb; e jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_profile_immutable'; END IF;
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 p:=NEW.payload;r:=p->'read';e:=p->'execution';


 IF p ? 'discovery' THEN
  r=p->'discovery';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('discovery',r,'execution',e)
   AND os_agent_discovery_profile_valid(r,NEW.installation_id,NEW.application_id,NEW.application_generation,NEW.registration_revision)
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','discoveryProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','catalog-discovery-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_discovery_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'proactive' THEN
  r=p->'proactive';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('proactive',r,'execution',e)
   AND os_agent_proactive_profile_valid(r,NEW.installation_id,NEW.application_id,NEW.application_generation,NEW.registration_revision)
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','proactiveProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','proactive-preparation-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_proactive_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'knowledge' THEN
  r=p->'knowledge';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('knowledge',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability','harness',r->'harness',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'providerRef',r->'providerRef',
    'planning',r->'planning','outputContract','AgentPrivateKnowledgePage/1','adapterRef','private.knowledge.read/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'harness'->>'ref' LIKE 'private-planned-read/%'
   AND r->'planning'->'knowledgeCapability'=r->'capability'
   AND os_agent_private_planning_valid(r->'planning',NEW.installation_id,NEW.application_id,NEW.application_generation,NEW.registration_revision,r->'harness')
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'capabilities'->'allowedKinds' @> '["memory"]'::jsonb)
   AND EXISTS(SELECT 1 FROM os_agent_capabilities cap WHERE cap.installation_id=NEW.installation_id
    AND cap.application_id=NEW.application_id AND cap.application_generation=NEW.application_generation
    AND r->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
    AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='private.knowledge.read/1'
    AND cap.payload->>'scopePolicyRef'='private-reviewed-knowledge/1' AND cap.payload->'mcp'='null'::jsonb
    AND cap.payload->>'lifecycle'='qualified')
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','knowledgeProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','private-knowledge-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_knowledge_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'memory' THEN
  r=p->'memory';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('memory',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability','harness',r->'harness',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'providerRef',r->'providerRef',
    'outputContract','AgentMemoryPage/1','adapterRef','owner.memory.read/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'harness'->>'ref' LIKE 'memory-assisted-read/%'
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'capabilities'->'allowedKinds' @> '["memory"]'::jsonb)
   AND EXISTS(SELECT 1 FROM os_agent_capabilities cap WHERE cap.installation_id=NEW.installation_id
    AND cap.application_id=NEW.application_id AND cap.application_generation=NEW.application_generation
    AND r->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
    AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='owner.memory.read/1'
    AND cap.payload->>'scopePolicyRef'='owner-approved-memory/1' AND cap.payload->'mcp'='null'::jsonb
    AND cap.payload->>'lifecycle'='qualified')
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','memoryProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','owner-memory-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_memory_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'native' THEN
  r:=p->'native';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('native',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'harness',r->'harness','runtime',r->'runtime','verifier',r->'verifier','placement',r->'placement','limits',r->'limits','meter',r->'meter','adapterRef','native.offline-analysis/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$'
   AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'harness'->'features' @> '["native-execution"]'::jsonb)
   AND jsonb_typeof(r->'capability'->'revision')='number' AND r->'capability'->>'revision' ~ '^[1-9][0-9]*$'
   AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->'runtime'=jsonb_build_object('ref',r->'runtime'->'ref','revision',r->'runtime'->'revision','digest',r->'runtime'->'digest')
   AND r->'runtime'->>'ref'='python-offline-analysis/1' AND r->'runtime'->'revision'='1'::jsonb
   AND r->'runtime'->>'digest' ~ '^[a-f0-9]{64}$'
   AND r->'verifier'=jsonb_build_object('ref','native-source-values/1','revision',1,'digest',r->'verifier'->'digest')
   AND r->'verifier'->>'digest' ~ '^[a-f0-9]{64}$'
   AND r->'placement'=jsonb_build_object('providerDigest',r->'placement'->'providerDigest','runtimeDigest',r->'placement'->'runtimeDigest')
   AND r->'placement'->>'providerDigest' ~ '^[a-f0-9]{64}$' AND r->'placement'->>'runtimeDigest' ~ '^[a-f0-9]{64}$'
   AND os_native_analysis_limits(r->'limits') AND os_native_analysis_meter(r->'meter',(r->'limits'->>'timeoutMs')::bigint)
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'nativeProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','native-one-vcpu-allocation/1','externalInference',false)
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(e->'revision')='number' AND e->>'revision' ~ '^[1-9][0-9]*$'
   AND (e->>'revision')::numeric<=9007199254740991 AND NEW.created_at<=clock_timestamp(),false)
   THEN RAISE EXCEPTION 'agent_native_profile_binding'; END IF;
  RETURN NEW;
 END IF;
 IF p ? 'preparation' THEN
  r:=p->'preparation';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('preparation',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'hostDefinitionRef',r->'hostDefinitionRef',
    'providerRef',r->'providerRef','outputContract','AgentPreparedChange/1','adapterRef','typed.prepare/1')
   AND jsonb_typeof(r->'id')='string' AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (r->>'revision') ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND (r->'capability'->>'revision') ~ '^[1-9][0-9]*$' AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->>'hostDefinitionRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'preparationProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','host-preparation-elapsed/1','externalInference',false,
    'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (e->>'revision') ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND (e->>'requestTimeoutMs') ~ '^[1-9][0-9]*$' AND (e->>'requestTimeoutMs')::numeric BETWEEN 25000 AND 900000
   AND (e->>'maxResultBytes') ~ '^[1-9][0-9]*$' AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576
   AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_preparation_profile_binding'; END IF;
  RETURN NEW;
 END IF;

 IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
 AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
 AND p-ARRAY['read','execution']='{}'::jsonb AND p ?& ARRAY['read','execution']
 AND e=jsonb_build_object('id',e->'id','revision',e->'revision','readProfile',jsonb_build_object('ref',r->'id','revision',r->'revision',
   'digest',os_agent_profile_digest('manifest',r)),'usageProfile','host-read-elapsed/1','externalInference',false,
   'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
 AND (e->>'requestTimeoutMs')::bigint BETWEEN 1 AND 900000 AND (e->>'maxResultBytes')::bigint BETWEEN 1024 AND 1048576
 AND (e->>'revision')::bigint BETWEEN 1 AND 9007199254740991 AND (r->>'outputContract'='EvidencePage/1' OR (
 r->>'outputContract'='AgentQueryPage/1'
 AND r-ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']='{}'::jsonb
 AND r ?& ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']
 AND jsonb_typeof(r->'cursorField')='string' AND r->>'cursorField' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
 AND jsonb_typeof(r->'grain')='array' AND jsonb_array_length(r->'grain') BETWEEN 1 AND 64
 AND jsonb_typeof(r->'pageGroupFields')='array' AND jsonb_array_length(r->'pageGroupFields') BETWEEN 0 AND 64
 AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements((r->'grain')||(r->'pageGroupFields')) v
  WHERE jsonb_typeof(v)<>'string' OR (v#>>'{}') !~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$')
 AND jsonb_array_length(r->'grain')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'grain') v)
 AND jsonb_array_length(r->'pageGroupFields')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'pageGroupFields') v)
 ))
 AND r->'host'->>'installationId'=NEW.installation_id::text AND r->'host'->>'applicationId'=NEW.application_id::text
 AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_tool_profile_binding'; END IF;
 RETURN NEW;
END $$;
"""

def upgrade():
    op.execute(HELPERS)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Agent discovery requires protected forward recovery')
