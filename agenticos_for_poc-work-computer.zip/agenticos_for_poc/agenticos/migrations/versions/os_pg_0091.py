"""Unapplied production step-up draft; complete flow/decision guards before freezing.

Additive to frozen0090. Catalog rows and mapped identity alone grant no approval.
Protected positive/negative runtime, populated rollback/forward and independent
0090 recovery remain mandatory before this revision can be accepted.
"""
from alembic import op

revision='os_pg_0091'
down_revision='os_pg_0090'
branch_labels=None
depends_on=None

CATALOG_GUARDS=r"""
CREATE FUNCTION os_oidc_endpoint(value text,network text,origin_only boolean DEFAULT false) RETURNS boolean LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE authority text; port_text text;
BEGIN
 IF value IS NULL OR value ~ '[?#%]' OR position(chr(92) IN value)>0
  OR value ~ ('[['||chr(58)||'space'||chr(58)||']]')
  OR value ~ '/[.][.]?(/|$)' THEN RETURN false; END IF;
 IF network='owned-local-http/1' THEN
  IF value !~ '^http://127[.]0[.]0[.]1:[1-9][0-9]{3,4}(/[^?#%\\]*)?$' THEN RETURN false; END IF;
  authority:=split_part(substring(value FROM 8),'/',1);port_text:=split_part(authority,':',2);
  RETURN port_text::integer BETWEEN 1024 AND 65535 AND (NOT origin_only OR value='http://'||authority);
 ELSIF network='web-pki/1' THEN
  IF value !~ '^https://[a-z0-9.-]+[.][a-z][a-z0-9-]*(:[1-9][0-9]{0,4})?(/[^?#%\\]*)?$' THEN RETURN false; END IF;
  authority:=split_part(substring(value FROM 9),'/',1);port_text:=split_part(authority,':',2);
  RETURN (port_text='' OR port_text::integer BETWEEN 1 AND 65535)
   AND (NOT origin_only OR value='https://'||authority);
 END IF;
 RETURN false;
EXCEPTION WHEN OTHERS THEN RETURN false;
END $$;

CREATE FUNCTION os_guard_oidc_assurance_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_applications%ROWTYPE; prior os_oidc_assurance_profiles%ROWTYPE; p jsonb; c jsonb; k jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'oidc_profile_immutable'; END IF;
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 SELECT * INTO prior FROM os_oidc_assurance_profiles WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
  AND profile_ref=NEW.profile_ref ORDER BY revision DESC LIMIT 1;
 p:=NEW.payload;c:=p->'client';
 IF NOT COALESCE(a.active AND NEW.run_id ~ '^[a-f0-9]{12}$' AND NEW.profile_ref ~ '^[A-Za-z0-9][A-Za-z0-9._:/-]{0,255}$'
  AND NEW.revision=COALESCE(prior.revision,0)+1
  AND NEW.digest=os_agent_profile_digest('manifest',p)
  AND p=jsonb_build_object('profileRef','oidc-step-up-assurance/1','id',NEW.profile_ref,'revision',NEW.revision,
   'active',p->'active','client',c,'clientProfile',p->'clientProfile','origin',p->'origin')
  AND jsonb_typeof(p->'active')='boolean'
  AND c ?& ARRAY['schema','installation_id','application_id','network','issuer','authorization_endpoint','token_endpoint',
   'redirect_uri','client_id','credential_ref','required_acr','required_amr','keys']
  AND c-ARRAY['schema','installation_id','application_id','network','issuer','authorization_endpoint','token_endpoint',
   'redirect_uri','client_id','credential_ref','required_acr','required_amr','keys']='{}'::jsonb
  AND c->>'schema'='oidc-step-up-client/1' AND c->>'installation_id'=NEW.installation_id::text
  AND c->>'application_id'=NEW.application_id::text AND c->>'network' IN ('web-pki/1','owned-local-http/1')
  AND os_oidc_endpoint(c->>'issuer',c->>'network') AND os_oidc_endpoint(c->>'authorization_endpoint',c->>'network')
  AND os_oidc_endpoint(c->>'token_endpoint',c->>'network') AND os_oidc_endpoint(p->>'origin',c->>'network',true)
  AND jsonb_typeof(c->'client_id')='string' AND c->>'client_id' ~ '^[A-Za-z0-9._-]+$'
  AND octet_length(c->>'client_id') BETWEEN 1 AND 256
  AND (c->'credential_ref'='null'::jsonb OR (jsonb_typeof(c->'credential_ref')='string'
   AND c->>'credential_ref' ~ '^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$'))
  AND jsonb_typeof(c->'required_acr')='string' AND octet_length(c->>'required_acr') BETWEEN 1 AND 256
  AND c->>'required_acr'<>'0' AND jsonb_typeof(c->'required_amr')='array'
  AND jsonb_array_length(c->'required_amr') BETWEEN 1 AND 8
  AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(c->'required_amr') m
   WHERE jsonb_typeof(m)<>'string' OR octet_length(m#>>'{}') NOT BETWEEN 1 AND 128)
  AND (SELECT count(DISTINCT m) FROM jsonb_array_elements(c->'required_amr') m)=jsonb_array_length(c->'required_amr')
  AND jsonb_typeof(c->'keys')='array' AND jsonb_array_length(c->'keys') BETWEEN 1 AND 16
  AND (SELECT count(DISTINCT j->>'kid') FROM jsonb_array_elements(c->'keys') j)=jsonb_array_length(c->'keys')
  AND c->>'redirect_uri'=(p->>'origin')||'/oidc/callback'
  AND (prior.revision IS NULL OR prior.payload->'client'->>'issuer'=c->>'issuer')
  AND p->'clientProfile'=jsonb_build_object('id',p->'clientProfile'->'id','revision',p->'clientProfile'->'revision',
   'catalogRefs',jsonb_build_array('agentic-os.safe/0.9.1'),'assurance',CASE WHEN c->>'network'='owned-local-http/1' THEN 'local-synthetic' ELSE 'dpop-qualified' END,
   'maxSurfaceBytes',p->'clientProfile'->'maxSurfaceBytes','fetchSSE',p->'clientProfile'->'fetchSSE','highRiskReview',true)
  AND p->'clientProfile'->>'id' ~ '^[A-Za-z0-9][A-Za-z0-9._:/-]{0,255}$'
  AND jsonb_typeof(p->'clientProfile'->'revision')='number' AND (p->'clientProfile'->>'revision') ~ '^[1-9][0-9]*$'
  AND (p->'clientProfile'->>'revision')::numeric<=9007199254740991
  AND jsonb_typeof(p->'clientProfile'->'maxSurfaceBytes')='number' AND (p->'clientProfile'->>'maxSurfaceBytes') ~ '^[1-9][0-9]*$'
  AND (p->'clientProfile'->>'maxSurfaceBytes')::numeric<=9007199254740991 AND jsonb_typeof(p->'clientProfile'->'fetchSSE')='boolean'
  AND NEW.created_at BETWEEN clock_timestamp()-interval '2 seconds' AND clock_timestamp(),false)
 THEN RAISE EXCEPTION 'oidc_profile_binding'; END IF;
 FOR k IN SELECT value FROM jsonb_array_elements(c->'keys') LOOP
  IF NOT COALESCE(k ?& ARRAY['kty','kid','n','e'] AND k-ARRAY['kty','kid','n','e','alg','use','key_ops']='{}'::jsonb
   AND k->>'kty'='RSA' AND (NOT k ? 'alg' OR k->'alg'='"RS256"'::jsonb)
   AND (NOT k ? 'use' OR k->'use'='"sig"'::jsonb)
   AND COALESCE(k->'key_ops',jsonb_build_array('verify'))=jsonb_build_array('verify')
   AND jsonb_typeof(k->'kid')='string' AND octet_length(k->>'kid') BETWEEN 1 AND 128
   AND k->>'e'='AQAB' AND k->>'n' ~ '^[A-Za-z0-9_-]+$'
   AND octet_length(k->>'n') BETWEEN 342 AND 683,false)
  THEN RAISE EXCEPTION 'oidc_profile_public_key'; END IF;
 END LOOP;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_oidc_assurance_profile BEFORE INSERT OR UPDATE OR DELETE ON os_oidc_assurance_profiles
 FOR EACH ROW EXECUTE FUNCTION os_guard_oidc_assurance_profile();

CREATE FUNCTION os_guard_oidc_subject_mapping() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_applications%ROWTYPE; s os_subjects%ROWTYPE; p os_oidc_assurance_profiles%ROWTYPE;
 prior os_oidc_subject_mappings%ROWTYPE; v jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'oidc_mapping_immutable'; END IF;
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 SELECT * INTO s FROM os_subjects WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
  AND tenant_id=NEW.tenant_id AND subject_id=NEW.subject_id FOR UPDATE;
 SELECT * INTO p FROM os_oidc_assurance_profiles WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
  AND profile_ref=NEW.provider_ref ORDER BY revision DESC LIMIT 1;
 SELECT * INTO prior FROM os_oidc_subject_mappings WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
  AND tenant_id=NEW.tenant_id AND subject_id=NEW.subject_id AND provider_ref=NEW.provider_ref ORDER BY revision DESC LIMIT 1;
 v:=NEW.payload;
 IF NOT COALESCE(a.active AND s.id IS NOT NULL AND p.revision IS NOT NULL AND NEW.run_id=p.run_id AND p.payload->'active'='true'::jsonb
  AND NEW.revision=COALESCE(prior.revision,0)+1 AND NEW.digest=os_agent_profile_digest('manifest',v)
  AND v=jsonb_build_object('id',NEW.id,'subject',jsonb_build_object('installationId',NEW.installation_id,
   'applicationId',NEW.application_id,'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id),
   'providerRef',NEW.provider_ref,'revision',NEW.revision,'issuer',p.payload->'client'->'issuer',
   'oidcSubject',v->'oidcSubject','active',v->'active')
  AND ((v->'active'='true'::jsonb AND s.active AND jsonb_typeof(v->'oidcSubject')='string'
   AND octet_length(v->>'oidcSubject') BETWEEN 1 AND 255)
   OR (v->'active'='false'::jsonb AND v->'oidcSubject'='null'::jsonb))
  AND NEW.created_at BETWEEN clock_timestamp()-interval '2 seconds' AND clock_timestamp(),false)
 THEN RAISE EXCEPTION 'oidc_mapping_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_oidc_subject_mapping BEFORE INSERT OR UPDATE OR DELETE ON os_oidc_subject_mappings
 FOR EACH ROW EXECUTE FUNCTION os_guard_oidc_subject_mapping();
"""

TABLES="""
CREATE TABLE os_oidc_assurance_profiles (
	installation_id UUID NOT NULL,\x20
	application_id UUID NOT NULL,\x20
	profile_ref VARCHAR(256) NOT NULL,\x20
	revision BIGINT NOT NULL,\x20
	run_id VARCHAR(12) NOT NULL,\x20
	digest VARCHAR(64) NOT NULL,\x20
	payload JSONB NOT NULL,\x20
	created_at TIMESTAMP WITH TIME ZONE NOT NULL,\x20
	PRIMARY KEY (installation_id, application_id, profile_ref, revision),\x20
	CONSTRAINT fk_oidc_assurance_profile_application FOREIGN KEY(installation_id, application_id) REFERENCES os_applications (installation_id, id),\x20
	CONSTRAINT uq_oidc_assurance_profile_pin UNIQUE (installation_id, application_id, profile_ref, revision, digest),\x20
	CONSTRAINT ck_oidc_assurance_profile_digest CHECK (digest ~ '^[a-f0-9]{64}$'),\x20
	CONSTRAINT ck_oidc_assurance_profile_bounds CHECK (revision>0 AND run_id ~ '^[a-f0-9]{12}$' AND jsonb_typeof(payload)='object' AND octet_length(payload::text)<=49152)
)

;

CREATE TABLE os_oidc_subject_mappings (
	id UUID NOT NULL,\x20
	provider_ref VARCHAR(256) NOT NULL,\x20
	revision BIGINT NOT NULL,\x20
	run_id VARCHAR(12) NOT NULL,\x20
	digest VARCHAR(64) NOT NULL,\x20
	payload JSONB NOT NULL,\x20
	created_at TIMESTAMP WITH TIME ZONE NOT NULL,\x20
	installation_id UUID NOT NULL,\x20
	application_id UUID NOT NULL,\x20
	tenant_id VARCHAR(256) NOT NULL,\x20
	subject_id VARCHAR(256) NOT NULL,\x20
	PRIMARY KEY (id),\x20
	CONSTRAINT uq_oidc_subject_mapping_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),\x20
	CONSTRAINT fk_oidc_mapping_owner FOREIGN KEY(installation_id, application_id, tenant_id, subject_id) REFERENCES os_subjects (installation_id, application_id, tenant_id, subject_id),\x20
	CONSTRAINT uq_oidc_subject_mapping_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, provider_ref, revision),\x20
	CONSTRAINT uq_oidc_subject_mapping_pin UNIQUE (installation_id, application_id, tenant_id, subject_id, id, revision, digest),\x20
	CONSTRAINT ck_oidc_subject_mapping_digest CHECK (digest ~ '^[a-f0-9]{64}$'),\x20
	CONSTRAINT ck_oidc_mapping_bounds CHECK (revision>0 AND run_id ~ '^[a-f0-9]{12}$' AND jsonb_typeof(payload)='object' AND octet_length(payload::text)<=8192)
)

;

CREATE TABLE os_oidc_assurance_flows (
	id UUID NOT NULL,\x20
	challenge_id UUID NOT NULL,\x20
	provider_ref VARCHAR(256) NOT NULL,\x20
	provider_revision BIGINT NOT NULL,\x20
	provider_digest VARCHAR(64) NOT NULL,\x20
	mapping_id UUID NOT NULL,\x20
	mapping_revision BIGINT NOT NULL,\x20
	mapping_digest VARCHAR(64) NOT NULL,\x20
	run_id VARCHAR(12) NOT NULL,\x20
	state_digest VARCHAR(64) NOT NULL,\x20
	payload JSONB NOT NULL,\x20
	digest VARCHAR(64) NOT NULL,\x20
	state VARCHAR(32) NOT NULL,\x20
	version BIGINT NOT NULL,\x20
	secret_envelope JSONB,\x20
	authentication JSONB,\x20
	assertion_id UUID,\x20
	claim JSONB,\x20
	failure_code VARCHAR(32),\x20
	created_at TIMESTAMP WITH TIME ZONE NOT NULL,\x20
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL,\x20
	installation_id UUID NOT NULL,\x20
	application_id UUID NOT NULL,\x20
	tenant_id VARCHAR(256) NOT NULL,\x20
	subject_id VARCHAR(256) NOT NULL,\x20
	PRIMARY KEY (id),\x20
	CONSTRAINT uq_oidc_assurance_flow_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),\x20
	CONSTRAINT fk_os_agent_review_challenges_challenge_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, challenge_id) REFERENCES os_agent_review_challenges (installation_id, application_id, tenant_id, subject_id, id),\x20
	CONSTRAINT fk_oidc_flow_provider FOREIGN KEY(installation_id, application_id, provider_ref, provider_revision, provider_digest) REFERENCES os_oidc_assurance_profiles (installation_id, application_id, profile_ref, revision, digest),\x20
	CONSTRAINT fk_oidc_flow_owner_mapping FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, mapping_id, mapping_revision, mapping_digest) REFERENCES os_oidc_subject_mappings (installation_id, application_id, tenant_id, subject_id, id, revision, digest),\x20
	CONSTRAINT uq_oidc_flow_challenge UNIQUE (installation_id, application_id, tenant_id, subject_id, challenge_id),\x20
	CONSTRAINT uq_oidc_flow_state_nonce UNIQUE (state_digest),\x20
	CONSTRAINT uq_oidc_flow_assertion UNIQUE (installation_id, application_id, tenant_id, subject_id, assertion_id),\x20
	CONSTRAINT ck_oidc_flow_provider_digest_digest CHECK (provider_digest ~ '^[a-f0-9]{64}$'),\x20
	CONSTRAINT ck_oidc_flow_mapping_digest_digest CHECK (mapping_digest ~ '^[a-f0-9]{64}$'),\x20
	CONSTRAINT ck_oidc_flow_state_digest_digest CHECK (state_digest ~ '^[a-f0-9]{64}$'),\x20
	CONSTRAINT ck_oidc_flow_digest_digest CHECK (digest ~ '^[a-f0-9]{64}$'),\x20
	CONSTRAINT ck_oidc_flow_bounds CHECK (run_id ~ '^[a-f0-9]{12}$' AND version>0 AND provider_revision>0 AND mapping_revision>0 AND expires_at>created_at AND expires_at<=created_at+interval '60 seconds'),\x20
	CONSTRAINT ck_oidc_flow_records CHECK (state IN ('CREATED','EXCHANGING','AUTHENTICATED','UNKNOWN','FAILED','CONSUMED') AND jsonb_typeof(payload)='object' AND octet_length(payload::text)<=16384 AND (secret_envelope IS NULL OR (jsonb_typeof(secret_envelope)='object' AND octet_length(secret_envelope::text)<=8192)) AND (authentication IS NULL OR (jsonb_typeof(authentication)='object' AND octet_length(authentication::text)<=4096)) AND (claim IS NULL OR (jsonb_typeof(claim)='object' AND octet_length(claim::text)<=16384))),\x20
	CONSTRAINT ck_oidc_flow_state_material CHECK ((state IN ('CREATED','EXCHANGING'))=(secret_envelope IS NOT NULL) AND (state IN ('AUTHENTICATED','CONSUMED'))=(authentication IS NOT NULL) AND (state IN ('AUTHENTICATED','CONSUMED'))=(assertion_id IS NOT NULL) AND (state='CONSUMED')=(claim IS NOT NULL) AND ((state IN ('UNKNOWN','FAILED') AND failure_code IS NOT NULL AND failure_code IN ('DENIED','UNAVAILABLE','EXPIRED','CANCELLED')) OR (state NOT IN ('UNKNOWN','FAILED') AND failure_code IS NULL)))
)

;"""


FLOW_GUARDS=r"""
CREATE FUNCTION os_oidc_assert_owner(v os_agent_reviews,s os_interactive_sessions,b jsonb,target_run text,phase text DEFAULT 'review')
 RETURNS void LANGUAGE plpgsql AS $$
DECLARE p os_oidc_assurance_profiles%ROWTYPE; m os_oidc_subject_mappings%ROWTYPE; a os_applications%ROWTYPE;
 registration os_registrations%ROWTYPE; e os_embed_registrations%ROWTYPE; u os_subjects%ROWTYPE; client_profile jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_applications WHERE installation_id=v.installation_id AND id=v.application_id;
 SELECT * INTO registration FROM os_registrations WHERE installation_id=v.installation_id AND application_id=v.application_id AND revision=a.revision;
 SELECT * INTO e FROM os_embed_registrations WHERE installation_id=v.installation_id AND application_id=v.application_id AND id=s.embed_ref;
 SELECT * INTO u FROM os_subjects WHERE installation_id=v.installation_id AND application_id=v.application_id AND tenant_id=v.tenant_id AND subject_id=v.subject_id;
 SELECT x INTO client_profile FROM jsonb_array_elements(registration.payload->'clientProfiles') x WHERE x->>'id'=e.payload->>'clientProfile';
 SELECT * INTO p FROM os_oidc_assurance_profiles WHERE installation_id=v.installation_id AND application_id=v.application_id
  AND profile_ref=b->'provider'->>'ref' ORDER BY revision DESC LIMIT 1;
 SELECT * INTO m FROM os_oidc_subject_mappings WHERE installation_id=v.installation_id AND application_id=v.application_id
  AND tenant_id=v.tenant_id AND subject_id=v.subject_id AND provider_ref=p.profile_ref ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(v.payload->'context'->'harness'->>'ref'='agent-sdk-reviewed-change/1'
  AND (b->>'expiresAt')::timestamptz>clock_timestamp()
  AND (b->>'expiresAt')::timestamptz<=v.expires_at AND (b->>'expiresAt')::timestamptz<=s.expires_at
  AND b->>'assuranceProfile'='oidc-step-up-assurance/1' AND b->>'requiredAssurance'='oidc-step-up/1'
  AND b->>'assuranceProviderRef'=p.profile_ref AND b->'provider'=jsonb_build_object('ref',p.profile_ref,'revision',p.revision,'digest',p.digest)
  AND b->'ownerMapping'=jsonb_build_object('ref',m.id,'revision',m.revision,'digest',m.digest)
  AND p.run_id=target_run AND m.run_id=target_run AND p.payload->'active'='true'::jsonb AND m.payload->'active'='true'::jsonb
  AND p.digest=os_agent_profile_digest('manifest',p.payload) AND m.digest=os_agent_profile_digest('manifest',m.payload)
  AND m.payload->>'issuer'=p.payload->'client'->>'issuer' AND client_profile=p.payload->'clientProfile'
  AND registration.digest=os_agent_profile_digest('manifest',registration.payload) AND registration.generation=a.generation
  AND e.application_generation=a.generation AND e.payload->'active'='true'::jsonb
  AND b->'subject'=jsonb_build_object('installationId',v.installation_id,'applicationId',v.application_id,'tenantId',v.tenant_id,'subjectId',v.subject_id)
  AND b->>'sessionId'=s.id::text AND (b->>'sessionGeneration')::bigint=s.session_generation
  AND b->>'hostSessionRef'=s.host_session_ref AND (b->>'policyGeneration')::bigint=u.host_policy_generation
  AND EXISTS(SELECT 1 FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=v.task_id
   AND ((phase='review' AND t.state='WAITING_APPROVAL') OR (phase='effect' AND t.state='RUNNING'))
   AND r.state='ACTIVE' AND r.deadline>clock_timestamp() AND (b->>'expiresAt')::timestamptz<=r.deadline),false)
 THEN RAISE EXCEPTION 'oidc_current_owner_binding'; END IF;
END $$;

CREATE FUNCTION os_oidc_assert_current(b jsonb,target_run text,phase text DEFAULT 'review') RETURNS void LANGUAGE plpgsql AS $$
DECLARE h os_agent_review_challenges%ROWTYPE; v os_agent_reviews%ROWTYPE; s os_interactive_sessions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO h FROM os_agent_review_challenges WHERE id=(b->>'challengeId')::uuid;
 v:=os_agent_review_current(h.review_id);s:=os_agent_review_session(v,h.session_id);
 IF h.id IS NULL OR h.binding IS DISTINCT FROM b OR h.expires_at<=clock_timestamp() THEN RAISE EXCEPTION 'oidc_current_challenge'; END IF;
 PERFORM os_oidc_assert_owner(v,s,b,target_run,phase);
END $$;

CREATE FUNCTION os_guard_oidc_assurance_flow() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE h os_agent_review_challenges%ROWTYPE; p os_oidc_assurance_profiles%ROWTYPE;
 m os_oidc_subject_mappings%ROWTYPE; v jsonb; b jsonb; fact jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'oidc_flow_immutable'; END IF;
 v:=NEW.payload;b:=v->'binding';
 IF TG_OP='INSERT' THEN
  PERFORM os_oidc_assert_current(b,NEW.run_id);
  SELECT * INTO h FROM os_agent_review_challenges WHERE id=NEW.challenge_id;
  IF NOT COALESCE(NEW.version=1 AND NEW.state='CREATED' AND NEW.created_at BETWEEN clock_timestamp()-interval '2 seconds' AND clock_timestamp()
   AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(h.installation_id,h.application_id,h.tenant_id,h.subject_id)
   AND h.binding=b AND NEW.digest=os_agent_profile_digest('command',v)
   AND v=jsonb_build_object('id',NEW.id,'binding',b,'decision',v->'decision','stateDigest',NEW.state_digest,
    'nonceDigest',v->'nonceDigest','createdAt',v->'createdAt','expiresAt',v->'expiresAt')
   AND v->>'decision' IN ('approve','reject') AND v->>'nonceDigest' ~ '^[a-f0-9]{64}$'
   AND (v->>'createdAt')::timestamptz=NEW.created_at AND (v->>'expiresAt')::timestamptz=NEW.expires_at AND NEW.expires_at<=h.expires_at
   AND b->'provider'=jsonb_build_object('ref',NEW.provider_ref,'revision',NEW.provider_revision,'digest',NEW.provider_digest)
   AND b->'ownerMapping'=jsonb_build_object('ref',NEW.mapping_id,'revision',NEW.mapping_revision,'digest',NEW.mapping_digest)
   AND NEW.authentication IS NULL AND NEW.assertion_id IS NULL AND NEW.claim IS NULL AND NEW.failure_code IS NULL,false)
  THEN RAISE EXCEPTION 'oidc_flow_initial_binding'; END IF;
 ELSE
  IF NOT COALESCE(ROW(NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.challenge_id,
   NEW.provider_ref,NEW.provider_revision,NEW.provider_digest,NEW.mapping_id,NEW.mapping_revision,NEW.mapping_digest,
   NEW.run_id,NEW.state_digest,NEW.payload,NEW.digest,NEW.created_at,NEW.expires_at)
   IS NOT DISTINCT FROM ROW(OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.challenge_id,
   OLD.provider_ref,OLD.provider_revision,OLD.provider_digest,OLD.mapping_id,OLD.mapping_revision,OLD.mapping_digest,
   OLD.run_id,OLD.state_digest,OLD.payload,OLD.digest,OLD.created_at,OLD.expires_at)
   AND NEW.version=OLD.version+1 AND (
    (OLD.state='CREATED' AND NEW.state='EXCHANGING' AND NEW.secret_envelope=OLD.secret_envelope)
    OR (OLD.state='EXCHANGING' AND NEW.state='AUTHENTICATED')
    OR (OLD.state='AUTHENTICATED' AND NEW.state='CONSUMED' AND NEW.authentication=OLD.authentication AND NEW.assertion_id=OLD.assertion_id)
    OR (OLD.state IN ('CREATED','EXCHANGING','AUTHENTICATED') AND NEW.state='FAILED')
    OR (OLD.state='EXCHANGING' AND NEW.state='UNKNOWN')),false)
  THEN RAISE EXCEPTION 'oidc_flow_transition'; END IF;
  IF NEW.state NOT IN ('FAILED','UNKNOWN') THEN PERFORM os_oidc_assert_current(b,NEW.run_id); END IF;
 END IF;
 IF NEW.state IN ('CREATED','EXCHANGING') THEN
  IF NEW.expires_at<=clock_timestamp() THEN RAISE EXCEPTION 'oidc_flow_expired'; END IF;
  IF NOT COALESCE(NEW.secret_envelope=jsonb_build_object('version',1,'keyId',NEW.secret_envelope->'keyId',
   'nonce',NEW.secret_envelope->'nonce','ciphertext',NEW.secret_envelope->'ciphertext')
   AND NEW.secret_envelope->>'keyId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   AND NEW.secret_envelope->>'nonce' ~ '^[A-Za-z0-9+/]{16}$'
   AND NEW.secret_envelope->>'ciphertext' ~ '^[A-Za-z0-9+/]+={0,2}$',false)
  THEN RAISE EXCEPTION 'oidc_flow_encrypted_secret'; END IF;
 END IF;
 IF NEW.state IN ('AUTHENTICATED','CONSUMED') THEN
  SELECT * INTO p FROM os_oidc_assurance_profiles WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
   AND profile_ref=NEW.provider_ref AND revision=NEW.provider_revision;
  SELECT * INTO m FROM os_oidc_subject_mappings WHERE id=NEW.mapping_id;
  fact:=NEW.authentication;
  IF NOT COALESCE(fact=jsonb_build_object('issuer',p.payload->'client'->'issuer','subject',m.payload->'oidcSubject',
   'authenticatedAt',fact->'authenticatedAt','acr',p.payload->'client'->'required_acr','amr',fact->'amr','expiresAt',fact->'expiresAt')
   AND (fact->>'authenticatedAt')::timestamptz BETWEEN NEW.created_at-interval '1 second' AND clock_timestamp()+interval '1 second'
   AND (fact->>'expiresAt')::timestamptz>clock_timestamp() AND (fact->>'expiresAt')::timestamptz<=NEW.expires_at
   AND jsonb_typeof(fact->'amr')='array' AND jsonb_array_length(fact->'amr') BETWEEN 1 AND 16
   AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(fact->'amr') method WHERE jsonb_typeof(method)<>'string')
   AND (p.payload->'client'->'required_amr') <@ (fact->'amr'),false)
  THEN RAISE EXCEPTION 'oidc_flow_fresh_identity'; END IF;
 END IF;
 IF NEW.state='CONSUMED' THEN
  IF NOT COALESCE(NEW.claim=jsonb_build_object('binding',b,'assertionRef','assertion/'||NEW.assertion_id::text,
   'commandId',NEW.claim->'commandId','commandDigest',NEW.claim->'commandDigest','decision',v->'decision')
   AND NEW.claim->>'commandId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   AND NEW.claim->>'commandDigest' ~ '^[a-f0-9]{64}$',false)
  THEN RAISE EXCEPTION 'oidc_flow_exact_command'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_oidc_assurance_flow BEFORE INSERT OR UPDATE OR DELETE ON os_oidc_assurance_flows
 FOR EACH ROW EXECUTE FUNCTION os_guard_oidc_assurance_flow();
"""


# Legacy trigger branches below retain the exact frozen0076 body. Only the
# explicit OIDC family selects the new current ceremony checks.
OIDC_REVIEW_GUARDS=r"""
CREATE FUNCTION os_check_oidc_agent_review_challenge(newrow os_agent_review_challenges) RETURNS os_agent_review_challenges LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; s os_interactive_sessions%ROWTYPE; b jsonb; t os_tasks%ROWTYPE; provider os_oidc_assurance_profiles%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);

 v:=os_agent_review_current(newrow.review_id);s:=os_agent_review_session(v,newrow.session_id);
 SELECT * INTO t FROM os_tasks WHERE id=v.task_id;
 b:=newrow.binding;
 SELECT * INTO provider FROM os_oidc_assurance_profiles WHERE installation_id=v.installation_id AND application_id=v.application_id
  AND profile_ref=b->'provider'->>'ref' ORDER BY revision DESC LIMIT 1;
 PERFORM os_oidc_assert_owner(v,s,b,provider.run_id);
 IF NOT COALESCE(ROW(newrow.installation_id,newrow.application_id,newrow.tenant_id,newrow.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND t.state='WAITING_APPROVAL'
  AND b=jsonb_build_object('subject',v.payload->'context'->'subject','sessionId',s.id,'sessionGeneration',s.session_generation,
   'hostSessionRef',s.host_session_ref,'policyGeneration',(SELECT host_policy_generation FROM os_subjects
    WHERE installation_id=v.installation_id AND application_id=v.application_id AND tenant_id=v.tenant_id AND subject_id=v.subject_id),
   'challengeId',newrow.id,'nonce',b->'nonce','proposalId',v.id,'proposalRevision',1,'proposalDigest',v.payload->'proposalDigest',
   'assuranceProfile','oidc-step-up-assurance/1','assuranceProviderRef',b->'assuranceProviderRef',
   'requiredAssurance','oidc-step-up/1','provider',b->'provider','ownerMapping',b->'ownerMapping','createdAt',b->'createdAt','expiresAt',b->'expiresAt')
  AND b->>'nonce' ~ '^[A-Za-z0-9_-]{43,128}$' AND b->>'assuranceProviderRef'=provider.profile_ref
  AND (b->>'createdAt')::timestamptz=newrow.created_at AND (b->>'expiresAt')::timestamptz=newrow.expires_at
  AND newrow.created_at<=clock_timestamp() AND newrow.expires_at>clock_timestamp()
  AND newrow.expires_at<=v.expires_at AND newrow.expires_at<=s.expires_at,false)
 THEN RAISE EXCEPTION 'agent_review_challenge_binding'; END IF;
 RETURN newrow;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_review_challenge() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; s os_interactive_sessions%ROWTYPE; b jsonb; t os_tasks%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_review_challenge_immutable'; END IF;
 IF NEW.binding->>'requiredAssurance'='oidc-step-up/1' THEN RETURN os_check_oidc_agent_review_challenge(NEW); END IF;
 v:=os_agent_review_current(NEW.review_id);s:=os_agent_review_session(v,NEW.session_id);
 SELECT * INTO t FROM os_tasks WHERE id=v.task_id;
 b:=NEW.binding;
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND t.state='WAITING_APPROVAL'
  AND b=jsonb_build_object('subject',v.payload->'context'->'subject','sessionId',s.id,'sessionGeneration',s.session_generation,
   'hostSessionRef',s.host_session_ref,'policyGeneration',(SELECT host_policy_generation FROM os_subjects
    WHERE installation_id=v.installation_id AND application_id=v.application_id AND tenant_id=v.tenant_id AND subject_id=v.subject_id),
   'challengeId',NEW.id,'nonce',b->'nonce','proposalId',v.id,'proposalRevision',1,'proposalDigest',v.payload->'proposalDigest',
   'assuranceProfile','local-synthetic-assurance/1','assuranceProviderRef',b->'assuranceProviderRef',
   'requiredAssurance','local-synthetic','createdAt',b->'createdAt','expiresAt',b->'expiresAt')
  AND b->>'nonce' ~ '^[A-Za-z0-9_-]{43,128}$' AND b->>'assuranceProviderRef' ~ '^assurance/[a-f0-9]{64}$'
  AND (b->>'createdAt')::timestamptz=NEW.created_at AND (b->>'expiresAt')::timestamptz=NEW.expires_at
  AND NEW.created_at<=clock_timestamp() AND NEW.expires_at>clock_timestamp()
  AND NEW.expires_at<=v.expires_at AND NEW.expires_at<=s.expires_at,false)
 THEN RAISE EXCEPTION 'agent_review_challenge_binding'; END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_check_oidc_agent_review_decision(newrow os_agent_review_decisions) RETURNS os_agent_review_decisions LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; s os_interactive_sessions%ROWTYPE; h os_agent_review_challenges%ROWTYPE;
 t os_tasks%ROWTYPE; p jsonb; c jsonb; claim jsonb; proof jsonb; authority jsonb; ceremony os_oidc_assurance_flows%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);

 v:=os_agent_review_current(newrow.review_id);s:=os_agent_review_session(v,newrow.session_id);
 SELECT * INTO h FROM os_agent_review_challenges WHERE id=newrow.challenge_id;
 SELECT * INTO t FROM os_tasks WHERE id=v.task_id;
 p:=newrow.payload;c:=p->'command';claim:=p->'claim';proof:=p->'attestation';authority:=p->'authority';
 SELECT * INTO ceremony FROM os_oidc_assurance_flows WHERE id=(proof->>'flowId')::uuid FOR SHARE;
 PERFORM os_oidc_assert_current(h.binding,ceremony.run_id);
 IF NOT COALESCE(ceremony.state='CONSUMED' AND ceremony.claim=claim AND ceremony.payload->'binding'=h.binding
  AND ceremony.challenge_id=h.id AND proof->'authentication'=ceremony.authentication
  AND ROW(ceremony.installation_id,ceremony.application_id,ceremony.tenant_id,ceremony.subject_id)=
   ROW(newrow.installation_id,newrow.application_id,newrow.tenant_id,newrow.subject_id)
  AND newrow.expires_at<=(proof->>'expiresAt')::timestamptz,false) THEN RAISE EXCEPTION 'oidc_review_exact_ceremony'; END IF;

 IF NOT COALESCE(ROW(newrow.installation_id,newrow.application_id,newrow.tenant_id,newrow.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND t.state='WAITING_APPROVAL' AND t.version=(c->>'expectedTaskVersion')::bigint
  AND h.review_id=v.id AND h.session_id=s.id AND h.expires_at>clock_timestamp()
  AND newrow.digest=os_agent_profile_digest('verification',p) AND newrow.command_digest=os_agent_profile_digest('command',c)
  AND c=jsonb_build_object('commandId',newrow.command_id,'taskId',t.id,'reviewId',v.id,'proposalDigest',v.payload->'proposalDigest',
   'expectedTaskVersion',t.version,'challengeId',h.id,'assertionRef',c->'assertionRef','decision',c->'decision')
  AND c->>'decision' IN ('approve','reject') AND c->>'assertionRef' ~ '^assertion/[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
  AND p=jsonb_build_object('review',v.payload,'command',c,'authority',authority,'claim',claim,'attestation',proof,
   'createdAt',p->'createdAt','expiresAt',p->'expiresAt')
  AND authority=jsonb_build_object('subject',h.binding->'subject','sessionId',s.id,'sessionGeneration',s.session_generation,
   'applicationGeneration',s.application_generation,'subjectGeneration',s.subject_generation,'hostSessionRef',s.host_session_ref,
   'profileRef',authority->'profileRef','policyGeneration',h.binding->'policyGeneration')
  AND claim=jsonb_build_object('binding',h.binding,'assertionRef',c->'assertionRef','commandId',newrow.command_id,
   'commandDigest',newrow.command_digest,'decision',c->'decision')
  AND proof=jsonb_build_object('subject',h.binding->'subject','sessionId',s.id,'challengeId',h.id,
   'bindingDigest',os_agent_profile_digest('verification',h.binding),'assertionRef',c->'assertionRef','commandId',newrow.command_id,
   'commandDigest',newrow.command_digest,'decision',c->'decision','assuranceRef','oidc-step-up/1',
   'provider',h.binding->'provider','ownerMapping',h.binding->'ownerMapping','flowId',ceremony.id,'authentication',ceremony.authentication,
   'observedAt',proof->'observedAt','expiresAt',proof->'expiresAt')
  AND (proof->>'observedAt')::timestamptz BETWEEN clock_timestamp()-interval '5 seconds' AND clock_timestamp()+interval '1 second'
  AND (proof->>'expiresAt')::timestamptz>clock_timestamp() AND (proof->>'expiresAt')::timestamptz<=h.expires_at
  AND EXISTS(SELECT 1 FROM os_commands k WHERE k.accepted_task_id=t.id AND k.kind='agent.review.register'
   AND k.request_digest=os_agent_profile_digest('verification',jsonb_build_object('challengeId',h.id,
    'bindingDigest',os_agent_profile_digest('verification',h.binding),'expiresAt',h.binding->'expiresAt')))
  AND (p->>'createdAt')::timestamptz=newrow.created_at AND (p->>'expiresAt')::timestamptz=newrow.expires_at
  AND newrow.created_at<=clock_timestamp() AND newrow.expires_at>clock_timestamp() AND newrow.expires_at<=h.expires_at
  AND NOT EXISTS(SELECT 1 FROM os_work_attempts w WHERE w.root_id=v.root_id AND w.state IN ('RESERVED','RUNNING','UNKNOWN')),false)
 THEN RAISE EXCEPTION 'agent_review_decision_binding'; END IF;
 RETURN newrow;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_review_decision() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; s os_interactive_sessions%ROWTYPE; h os_agent_review_challenges%ROWTYPE;
 t os_tasks%ROWTYPE; p jsonb; c jsonb; claim jsonb; proof jsonb; authority jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_review_decision_immutable'; END IF;
 IF NEW.payload->'claim'->'binding'->>'requiredAssurance'='oidc-step-up/1' THEN RETURN os_check_oidc_agent_review_decision(NEW); END IF;
 v:=os_agent_review_current(NEW.review_id);s:=os_agent_review_session(v,NEW.session_id);
 SELECT * INTO h FROM os_agent_review_challenges WHERE id=NEW.challenge_id;
 SELECT * INTO t FROM os_tasks WHERE id=v.task_id;
 p:=NEW.payload;c:=p->'command';claim:=p->'claim';proof:=p->'attestation';authority:=p->'authority';
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND t.state='WAITING_APPROVAL' AND t.version=(c->>'expectedTaskVersion')::bigint
  AND h.review_id=v.id AND h.session_id=s.id AND h.expires_at>clock_timestamp()
  AND NEW.digest=os_agent_profile_digest('verification',p) AND NEW.command_digest=os_agent_profile_digest('command',c)
  AND c=jsonb_build_object('commandId',NEW.command_id,'taskId',t.id,'reviewId',v.id,'proposalDigest',v.payload->'proposalDigest',
   'expectedTaskVersion',t.version,'challengeId',h.id,'assertionRef',c->'assertionRef','decision',c->'decision')
  AND c->>'decision' IN ('approve','reject') AND c->>'assertionRef' ~ '^assertion/[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
  AND p=jsonb_build_object('review',v.payload,'command',c,'authority',authority,'claim',claim,'attestation',proof,
   'createdAt',p->'createdAt','expiresAt',p->'expiresAt')
  AND authority=jsonb_build_object('subject',h.binding->'subject','sessionId',s.id,'sessionGeneration',s.session_generation,
   'applicationGeneration',s.application_generation,'subjectGeneration',s.subject_generation,'hostSessionRef',s.host_session_ref,
   'profileRef',authority->'profileRef','policyGeneration',h.binding->'policyGeneration')
  AND claim=jsonb_build_object('binding',h.binding,'assertionRef',c->'assertionRef','commandId',NEW.command_id,
   'commandDigest',NEW.command_digest,'decision',c->'decision')
  AND proof=jsonb_build_object('subject',h.binding->'subject','sessionId',s.id,'challengeId',h.id,
   'bindingDigest',os_agent_profile_digest('verification',h.binding),'assertionRef',c->'assertionRef','commandId',NEW.command_id,
   'commandDigest',NEW.command_digest,'decision',c->'decision','assuranceRef','local-synthetic',
   'observedAt',proof->'observedAt','expiresAt',proof->'expiresAt')
  AND (proof->>'observedAt')::timestamptz BETWEEN clock_timestamp()-interval '5 seconds' AND clock_timestamp()+interval '1 second'
  AND (proof->>'expiresAt')::timestamptz>clock_timestamp() AND (proof->>'expiresAt')::timestamptz<=h.expires_at
  AND EXISTS(SELECT 1 FROM os_commands k WHERE k.accepted_task_id=t.id AND k.kind='agent.review.register'
   AND k.request_digest=os_agent_profile_digest('verification',jsonb_build_object('challengeId',h.id,
    'bindingDigest',os_agent_profile_digest('verification',h.binding),'expiresAt',h.binding->'expiresAt')))
  AND (p->>'createdAt')::timestamptz=NEW.created_at AND (p->>'expiresAt')::timestamptz=NEW.expires_at
  AND NEW.created_at<=clock_timestamp() AND NEW.expires_at>clock_timestamp() AND NEW.expires_at<=h.expires_at
  AND NOT EXISTS(SELECT 1 FROM os_work_attempts w WHERE w.root_id=v.root_id AND w.state IN ('RESERVED','RUNNING','UNKNOWN')),false)
 THEN RAISE EXCEPTION 'agent_review_decision_binding'; END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_agent_reviewed_grant(decision uuid) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE d os_agent_review_decisions%ROWTYPE; v os_agent_reviews%ROWTYPE; c os_agent_tool_calls%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; a os_admissions%ROWTYPE; context jsonb; subject jsonb; result jsonb;
BEGIN
 SELECT * INTO d FROM os_agent_review_decisions WHERE id=decision;
 SELECT * INTO v FROM os_agent_reviews WHERE id=d.review_id;
 SELECT c0.* INTO c FROM os_agent_tool_calls c0 JOIN os_agent_tool_acceptances x ON x.call_id=c0.id WHERE x.id=v.preparation_id;
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=c.installation_id AND application_id=c.application_id
  AND policy_digest=c.request->'record'->'profile'->>'digest';
 SELECT a0.* INTO a FROM os_admissions a0 JOIN os_budget_roots r ON r.admission_id=a0.id WHERE r.id=v.root_id;
 IF d.id IS NULL OR v.id IS NULL OR c.id IS NULL OR p.policy_digest IS NULL OR a.id IS NULL
  OR d.payload->'command'->>'decision'<>'approve' OR d.payload->'review' IS DISTINCT FROM v.payload
  OR d.digest<>os_agent_profile_digest('verification',d.payload) OR v.digest<>os_agent_profile_digest('command',v.payload)
  OR v.payload->'context' IS DISTINCT FROM a.context THEN RAISE EXCEPTION 'agent_effect_not_approved'; END IF;

 IF d.payload->'claim'->'binding'->>'requiredAssurance'='oidc-step-up/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_oidc_assurance_flows f WHERE f.id=(d.payload->'attestation'->>'flowId')::uuid
   AND f.state='CONSUMED' AND f.claim=d.payload->'claim' AND f.authentication=d.payload->'attestation'->'authentication'
   AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(d.installation_id,d.application_id,d.tenant_id,d.subject_id))
  THEN RAISE EXCEPTION 'oidc_effect_ceremony_missing'; END IF;
 ELSIF d.payload->'claim'->'binding'->>'requiredAssurance' IS DISTINCT FROM 'local-synthetic'
 THEN RAISE EXCEPTION 'agent_effect_assurance_unsupported'; END IF;
 context:=a.context;subject:=context->'subject';
 result:=jsonb_build_object('profileRef',CASE WHEN d.payload->'claim'->'binding'->>'requiredAssurance'='oidc-step-up/1' THEN 'agent-oidc-reviewed-effect/1' ELSE 'agent-reviewed-effect/1' END,'id',d.id,'subject',subject,
  'taskId',context->'taskId','rootId',context->'rootId','segmentId',context->'segmentId','controlEpoch',context->'controlEpoch',
  'reviewId',v.id,'decision',jsonb_build_object('id',d.id,'proposalId',v.id,'proposalRevision',1,'digest',v.payload->'proposalDigest',
   'subject',subject,'expiresAt',d.payload->'expiresAt','assuranceRef',CASE WHEN d.payload->'claim'->'binding'->>'requiredAssurance'='oidc-step-up/1' THEN 'oidc-step-up/1' ELSE 'local-synthetic' END),
  'decisionCoreDigest',d.digest,'proposalId',v.id,'proposalRevision',1,'proposalDigest',v.payload->'proposalDigest',
  'stageId',v.payload->'stageId','capabilityRef',c.request->'record'->'capability'->'ref',
  'providerRef',p.payload->'preparation'->'providerRef','registrationRevision',a.registration_revision,
  'invocationId',d.id,'effectRequestDigest',os_agent_profile_digest('command',jsonb_build_object('subject',subject,
   'invocationId',d.id,'proposalDigest',v.payload->'proposalDigest','capabilityRef',c.request->'record'->'capability'->'ref')),
  'expiresAt',d.payload->'expiresAt');
 RETURN result||jsonb_build_object('grantDigest',os_agent_profile_digest('verification',result));
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_reviewed_effect() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE g jsonb; c jsonb; d os_agent_review_decisions%ROWTYPE; v os_agent_reviews%ROWTYPE; a os_admissions%ROWTYPE;
 units jsonb; request jsonb;
BEGIN
 IF NEW.accounting_format<>'agent-resources/1' OR NEW.kind<>'agent.effect' THEN RETURN NEW; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 g:=os_agent_reviewed_grant(NEW.invocation_id);
 SELECT * INTO d FROM os_agent_review_decisions WHERE id=NEW.invocation_id;
 SELECT * INTO v FROM os_agent_reviews WHERE id=d.review_id;
 c:=v.payload->'context';
 SELECT a0.* INTO a FROM os_admissions a0 JOIN os_budget_roots r ON r.admission_id=a0.id WHERE r.id=v.root_id;
 units:=jsonb_build_object('tokens',0,'costMicros',0,'workMs',NEW.reserved->'workMs','computeMs',0,'storageBytes',0);
 request:=jsonb_build_object('schema','agent-resource-reservation/1','taskId',NEW.task_id,'segmentId',NEW.segment_id,
  'epoch',NEW.control_epoch,'invocationId',NEW.invocation_id,'kind','agent.effect','inputDigest',g->'grantDigest',
  'units',units,'timeoutMs',units->'workMs');
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND NEW.task_id=v.task_id AND NEW.root_id=v.root_id AND NEW.segment_id=(c->>'segmentId')::uuid
  AND NEW.control_epoch=(c->>'controlEpoch')::bigint AND NEW.reserved=units
  AND (units->>'workMs')::bigint BETWEEN 1 AND LEAST(45000,(a.bot->'resources'->>'requestTimeoutMs')::bigint)
  AND NEW.request_digest=os_agent_profile_digest('command',request)
  AND NEW.lease_until<=(g->>'expiresAt')::timestamptz,false)
 THEN RAISE EXCEPTION 'agent_reviewed_effect_binding'; END IF;
 IF NEW.state IN ('RESERVED','RUNNING') AND (TG_OP='INSERT' OR NEW.state IS DISTINCT FROM OLD.state) THEN
  PERFORM os_agent_review_session(v,d.session_id);PERFORM os_assert_agent_work_current(NEW);
  IF g->'decision'->>'assuranceRef'='oidc-step-up/1' THEN
   PERFORM os_oidc_assert_current(d.payload->'claim'->'binding',(SELECT f.run_id FROM os_oidc_assurance_flows f
    WHERE f.id=(d.payload->'attestation'->>'flowId')::uuid),'effect');
  END IF;

  IF (g->>'expiresAt')::timestamptz<=clock_timestamp()
   OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state='RUNNING')
  THEN RAISE EXCEPTION 'agent_reviewed_effect_not_current'; END IF;
 END IF;
 RETURN NEW;
END $$;
"""

def upgrade():
    op.execute(TABLES)
    op.execute(CATALOG_GUARDS)
    op.execute(FLOW_GUARDS)
    op.execute(OIDC_REVIEW_GUARDS)


def downgrade():
    raise RuntimeError('Production OIDC requires protected forward recovery')
