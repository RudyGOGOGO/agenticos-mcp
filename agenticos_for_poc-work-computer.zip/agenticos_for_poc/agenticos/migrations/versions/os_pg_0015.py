"""Additive: immutable registered review challenges; no decisions or grants.

Protect/rehearse populated0014 before any application. Applied revisions stay
frozen. Qualification requires protected rehearsal and actual constraint tests.
"""

from alembic import op

revision = "os_pg_0015"
down_revision = "os_pg_0014"
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
ALTER TABLE os_review_proposals ADD CONSTRAINT uq_review_proposal_exact UNIQUE (installation_id, application_id, tenant_id, subject_id, id, revision, proposal_digest)
""")

    op.execute("""
ALTER TABLE os_interactive_sessions ADD CONSTRAINT uq_review_challenge_session_owner UNIQUE (installation_id, application_id, tenant_id, subject_id, id)
""")

    op.execute("""
CREATE TABLE os_review_challenge_intents (
	id UUID NOT NULL,
	command_id UUID NOT NULL,
	proposal_id UUID NOT NULL,
	proposal_revision BIGINT NOT NULL,
	proposal_digest VARCHAR(64) NOT NULL,
	session_id UUID NOT NULL,
	binding JSONB NOT NULL,
	binding_digest VARCHAR(64) NOT NULL,
	created_at TIMESTAMP WITH TIME ZONE NOT NULL,
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
	installation_id UUID NOT NULL,
	application_id UUID NOT NULL,
	tenant_id VARCHAR(256) NOT NULL,
	subject_id VARCHAR(256) NOT NULL,
	PRIMARY KEY (id),
	CONSTRAINT uq_review_challenge_intent_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_os_commands_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, command_id) REFERENCES os_commands (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_review_challenge_proposal_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, proposal_id, proposal_revision, proposal_digest) REFERENCES os_review_proposals (installation_id, application_id, tenant_id, subject_id, id, revision, proposal_digest),
	CONSTRAINT uq_review_challenge_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id),
	CONSTRAINT uq_review_challenge_binding UNIQUE (installation_id, application_id, tenant_id, subject_id, id, binding_digest),
	CONSTRAINT ck_review_challenge_revision CHECK (proposal_revision>0),
	CONSTRAINT ck_review_challenge_expiry CHECK (expires_at>created_at AND expires_at<=created_at+interval '60 seconds'),
	CONSTRAINT ck_review_challenge_binding_object CHECK (jsonb_typeof(binding)='object' AND octet_length(binding::text)<=16384),
	CONSTRAINT ck_review_challenge_proposal_digest CHECK (proposal_digest ~ '^[a-f0-9]{64}$'),
	CONSTRAINT ck_review_challenge_binding_digest CHECK (binding_digest ~ '^[a-f0-9]{64}$')
)
""")

    op.execute("""
CREATE INDEX ix_review_challenge_owner_proposal ON os_review_challenge_intents (installation_id, application_id, tenant_id, subject_id, proposal_id, created_at)
""")

    op.execute("""
CREATE TRIGGER immutable_os_review_challenge_intents BEFORE UPDATE OR DELETE ON os_review_challenge_intents FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','command_id','proposal_id','proposal_revision','proposal_digest','session_id','binding','binding_digest','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')
""")

    op.execute("""
CREATE TABLE os_review_assurance_registrations (
	id UUID NOT NULL,
	challenge_id UUID NOT NULL,
	binding_digest VARCHAR(64) NOT NULL,
	registration JSONB NOT NULL,
	registration_digest VARCHAR(64) NOT NULL,
	created_at TIMESTAMP WITH TIME ZONE NOT NULL,
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
	installation_id UUID NOT NULL,
	application_id UUID NOT NULL,
	tenant_id VARCHAR(256) NOT NULL,
	subject_id VARCHAR(256) NOT NULL,
	PRIMARY KEY (id),
	CONSTRAINT uq_review_assurance_registration_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_review_registration_challenge_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, challenge_id, binding_digest) REFERENCES os_review_challenge_intents (installation_id, application_id, tenant_id, subject_id, id, binding_digest),
	CONSTRAINT uq_review_registration_challenge UNIQUE (installation_id, application_id, tenant_id, subject_id, challenge_id),
	CONSTRAINT ck_review_registration_expiry CHECK (expires_at>created_at),
	CONSTRAINT ck_review_registration_object CHECK (jsonb_typeof(registration)='object' AND octet_length(registration::text)<=16384),
	CONSTRAINT ck_review_registration_binding_digest CHECK (binding_digest ~ '^[a-f0-9]{64}$'),
	CONSTRAINT ck_review_registration_value_digest CHECK (registration_digest ~ '^[a-f0-9]{64}$')
)
""")

    op.execute("""
CREATE TRIGGER immutable_os_review_assurance_registrations BEFORE UPDATE OR DELETE ON os_review_assurance_registrations FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','challenge_id','binding_digest','registration','registration_digest','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')
""")


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use tested fresh recovery")
