"""Registered inverse and separately approved finite original-root repair."""
from alembic import op
revision='os_pg_0029'
down_revision='os_pg_0028'
branch_labels=None
depends_on=None

GUARDS=r'''
CREATE FUNCTION os_assert_repair_current(d os_repair_admissions, a jsonb) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; t os_tasks%ROWTYPE; parent os_tasks%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; login os_interactive_sessions%ROWTYPE;
 original_work os_work_attempts%ROWTYPE; inv os_registered_inverses%ROWTYPE;
 receipt jsonb; original_task uuid; original_root uuid; original_attempt_id uuid;
 original_invocation uuid; original_request text; original_grant jsonb; now_at timestamptz;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 PERFORM 1 FROM os_task_controls WHERE
  (installation_id,application_id,tenant_id,subject_id)=(d.installation_id,d.application_id,d.tenant_id,d.subject_id)
  AND task_id IN (d.task_id,d.parent_task_id) ORDER BY task_id FOR UPDATE;
 IF EXISTS(SELECT 1 FROM os_task_controls WHERE task_id IN (d.task_id,d.parent_task_id) AND state<>'ACTIVE')
  OR (SELECT count(*) FROM os_task_controls WHERE task_id IN (d.task_id,d.parent_task_id))<>2
 THEN RAISE EXCEPTION 'repair_stopped'; END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id FOR UPDATE;
 SELECT * INTO owner FROM os_subjects WHERE
  (installation_id,application_id,tenant_id,subject_id)=(d.installation_id,d.application_id,d.tenant_id,d.subject_id) FOR UPDATE;
 SELECT * INTO login FROM os_interactive_sessions WHERE
  (installation_id,application_id,tenant_id,subject_id,id)=
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id,(a->>'sessionId')::uuid) FOR UPDATE;
 SELECT * INTO parent FROM os_tasks WHERE id=d.parent_task_id FOR UPDATE;
 SELECT * INTO t FROM os_tasks WHERE id=d.task_id FOR UPDATE;
 IF d.original_kind='input-delegated' THEN
  SELECT b.task_id,b.root_id,b.attempt_id,g.payload INTO original_task,original_root,original_attempt_id,original_grant
  FROM os_input_delegated_attempts b
  JOIN os_input_delegated_grants g ON g.id=b.grant_id
  WHERE b.id=d.delegated_binding_id;
  SELECT p.payload INTO receipt FROM os_input_delegated_receipts p WHERE
   (p.installation_id,p.application_id,p.tenant_id,p.subject_id,p.id,p.binding_id,p.observation_digest)=
   (d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.delegated_projection_id,d.delegated_binding_id,d.observation_digest)
   AND NOT EXISTS(SELECT 1 FROM os_input_delegated_receipts x WHERE x.binding_id=p.binding_id AND x.ordinal>p.ordinal);
 ELSE
  SELECT b.task_id,b.root_id,b.attempt_id,g.payload INTO original_task,original_root,original_attempt_id,original_grant
  FROM os_input_reviewed_effect_attempts b
  JOIN os_execution_grants g ON g.id=b.grant_id WHERE b.id=d.reviewed_binding_id;
  SELECT p.payload INTO receipt FROM os_input_reviewed_receipt_projections p WHERE
   (p.installation_id,p.application_id,p.tenant_id,p.subject_id,p.id,p.binding_id,p.observation_digest)=
   (d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.reviewed_projection_id,d.reviewed_binding_id,d.observation_digest)
   AND NOT EXISTS(SELECT 1 FROM os_input_reviewed_receipt_projections x WHERE x.binding_id=p.binding_id AND x.ordinal>p.ordinal);
 END IF;
 SELECT * INTO original_work FROM os_work_attempts WHERE id=original_attempt_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=d.root_id FOR UPDATE;
 SELECT * INTO inv FROM os_registered_inverses WHERE
  (installation_id,application_id,registration_revision,capability_ref)=
  (d.installation_id,d.application_id,d.registration_revision,d.capability_ref);
 now_at=clock_timestamp();
 IF COALESCE((app.active AND owner.active AND NOT login.revoked AND login.expires_at>now_at
  AND app.revision=d.registration_revision AND app.generation=(a->>'applicationGeneration')::bigint
  AND owner.generation=(a->>'subjectGeneration')::bigint
  AND owner.host_policy_generation=(a->>'policyGeneration')::bigint
  AND login.session_generation=(a->>'sessionGeneration')::bigint AND login.host_session_ref=a->>'hostSessionRef'
  AND a->'subject'=jsonb_build_object('installationId',d.installation_id,'applicationId',d.application_id,'tenantId',d.tenant_id,'subjectId',d.subject_id)
  AND original_work.state='SETTLED' AND original_work.actual IS NOT NULL
  AND original_work.task_id=d.parent_task_id AND original_work.root_id=d.root_id
  AND original_task=d.parent_task_id AND original_root=d.root_id
  AND original_grant->>'proposalId'=d.original_proposal_id::text AND original_grant->>'capabilityRef'=d.capability_ref
  AND receipt->>'status'='COMMITTED' AND receipt->>'receiptId'=d.original_receipt_id::text
  AND (receipt->>'version')::bigint=d.original_receipt_version
  AND receipt->>'invocationId'=original_work.invocation_id::text
  AND receipt->>'requestDigest'=original_grant->>'effectRequestDigest'
  AND inv.profile_ref='typed-update-restore/1' AND inv.provider_ref=original_grant->>'providerRef'
  AND r.state='ACTIVE' AND r.profile_ref='local-amendable-synthetic/1' AND r.root_task_id=d.parent_task_id
  AND r.definition_digest=d.definition_digest AND r.deadline=d.expires_at AND r.deadline>now_at
  AND parent.state IN ('COMPLETED','FAILED') AND parent.budget_root_id=r.id AND parent.deadline=r.deadline
  AND t.budget_root_id=r.id AND t.deadline=r.deadline AND t.id<>parent.id
  AND (r.ceiling->>'children')::bigint>=1 AND (r.ceiling->>'stages')::bigint>=2
  AND (r.ceiling->>'toolCalls')::bigint>=5 AND (r.ceiling->>'repairs')::bigint>=1),false) IS NOT TRUE
 THEN RAISE EXCEPTION 'repair_current_original_root'; END IF;
 IF NOT EXISTS(SELECT 1 FROM os_workload_bindings w WHERE
  (w.installation_id,w.application_id,w.tenant_id,w.subject_id,w.task_id,w.parent_task_id,w.root_id,w.node_ref)=
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.task_id,d.parent_task_id,d.root_id,'repair/'||d.id::text))
 THEN RAISE EXCEPTION 'repair_child_lineage'; END IF;
 IF (r.spent->>'children')::bigint < (SELECT count(*) FROM os_workload_bindings WHERE root_id=r.id AND parent_task_id IS NOT NULL)
 THEN RAISE EXCEPTION 'repair_child_charge'; END IF;
END $$;

CREATE FUNCTION os_assert_repair_grant(g os_repair_grants) RETURNS void LANGUAGE plpgsql AS $$
DECLARE d os_repair_admissions%ROWTYPE; p os_repair_prepared%ROWTYPE;
 approval os_repair_approvals%ROWTYPE; q os_repair_challenges%ROWTYPE; reg os_repair_registrations%ROWTYPE;
 now_at timestamptz;
BEGIN
 SELECT * INTO d FROM os_repair_admissions WHERE id=g.admission_id;
 PERFORM os_assert_repair_current(d,g.payload->'authority');
 SELECT * INTO approval FROM os_repair_approvals WHERE id=g.approval_id;
 SELECT * INTO p FROM os_repair_prepared WHERE id=approval.prepared_id;
 SELECT * INTO q FROM os_repair_challenges WHERE id=approval.challenge_id;
 SELECT * INTO reg FROM os_repair_registrations WHERE challenge_id=q.id;
 now_at=clock_timestamp();
 IF COALESCE((approval.decision='approve' AND approval.admission_id=d.id AND p.admission_id=d.id
  AND q.admission_id=d.id AND q.prepared_id=p.id AND approval.claim->'binding'=q.binding
  AND approval.claim->>'decision'='approve' AND approval.attestation->>'decision'='approve'
  AND approval.attestation->>'bindingDigest'=q.binding_digest
  AND reg.binding_digest=q.binding_digest AND reg.registration->>'bindingDigest'=q.binding_digest
  AND reg.registration->>'challengeId'=q.id::text AND reg.registration->>'expiresAt'=q.binding->>'expiresAt'
  AND q.binding->>'proposalId'=p.proposal_id::text AND q.binding->>'proposalDigest'=p.proposal_digest
  AND q.binding->>'proposalRevision'='1' AND q.binding->>'challengeId'=q.id::text
  AND q.session_id=(g.payload->'authority'->>'sessionId')::uuid
  AND g.payload->>'id'=g.id::text AND g.payload->>'repairId'=d.id::text
  AND g.payload->>'taskId'=d.task_id::text AND g.payload->>'parentTaskId'=d.parent_task_id::text
  AND g.payload->>'rootId'=d.root_id::text AND g.payload->>'segmentId'=approval.successor_segment_id::text
  AND g.payload->>'preparedId'=p.id::text AND g.payload->>'approvalId'=approval.id::text
  AND g.payload->>'grantDigest'=g.grant_digest AND g.payload->>'profileRef'='typed-update-repair-execution/1'
  AND g.payload->'subject'=g.payload->'authority'->'subject'
  AND g.payload->>'bundleRevision'='7' AND g.payload->>'controlEpoch'='1'
  AND g.payload->>'proposalId'=p.proposal_id::text AND g.payload->>'proposalDigest'=p.proposal_digest
  AND g.payload->>'proposalRevision'='1' AND g.payload->>'stageId'=p.stage_id::text
  AND g.payload->>'capabilityRef'=d.capability_ref AND g.payload->>'definitionDigest'=d.definition_digest
  AND g.payload->>'registrationRevision'=d.registration_revision::text
  AND g.payload->>'originalReceiptId'=d.original_receipt_id::text
  AND g.payload->>'originalReceiptVersion'=d.original_receipt_version::text
  AND g.payload->>'invocationId'<>(CASE WHEN d.original_kind='input-delegated' THEN
    (SELECT payload->>'invocationId' FROM os_input_delegated_receipts WHERE id=d.delegated_projection_id)
    ELSE (SELECT payload->>'invocationId' FROM os_input_reviewed_receipt_projections WHERE id=d.reviewed_projection_id) END)
  AND g.payload->'authorization'=jsonb_build_object('kind','review_decision','decision',approval.decision_ref)
  AND approval.decision_ref->>'id'=approval.id::text AND approval.decision_ref->>'proposalId'=p.proposal_id::text
  AND approval.decision_ref->>'digest'=p.proposal_digest AND approval.decision_ref->>'proposalRevision'='1'
  AND approval.decision_ref->>'assuranceRef'='local-synthetic'
  AND (approval.decision_ref->>'expiresAt')::timestamptz=g.expires_at
  AND (g.payload->>'createdAt')::timestamptz=g.created_at AND (g.payload->>'expiresAt')::timestamptz=g.expires_at
  AND g.created_at<=now_at AND g.expires_at>now_at AND g.expires_at<=approval.expires_at
  AND g.expires_at<=q.expires_at AND g.expires_at<=p.expires_at AND g.expires_at<=d.expires_at),false) IS NOT TRUE
  OR EXISTS(SELECT 1 FROM os_repair_revocations WHERE approval_id=approval.id)
 THEN RAISE EXCEPTION 'repair_fresh_grant'; END IF;
END $$;

CREATE FUNCTION os_guard_repair_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_repair_admissions%ROWTYPE; p os_repair_prepared%ROWTYPE; b os_repair_work%ROWTYPE;
 w os_work_attempts%ROWTYPE; q os_repair_challenges%ROWTYPE; approval os_repair_approvals%ROWTYPE;
 g os_repair_grants%ROWTYPE; artifact os_artifacts%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 command os_commands%ROWTYPE; now_at timestamptz;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_repair_admissions' THEN
  PERFORM os_assert_repair_current(NEW,NEW.authority);
  SELECT * INTO command FROM os_commands WHERE id=NEW.command_id;
  IF command.kind<>'repair.admit' OR command.accepted_task_id<>NEW.task_id OR command.request_digest<>NEW.command_digest
   OR NEW.session_id IS DISTINCT FROM (NEW.authority->>'sessionId')::uuid
   OR NEW.created_at>clock_timestamp() OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state='ACCEPTED')
  THEN RAISE EXCEPTION 'repair_admission_binding'; END IF;
 ELSIF TG_TABLE_NAME='os_repair_work' OR TG_TABLE_NAME='os_work_attempts' THEN
  IF TG_TABLE_NAME='os_repair_work' THEN b=NEW;
  ELSE
   SELECT * INTO b FROM os_repair_work WHERE attempt_id=NEW.id;
   IF b.id IS NULL THEN
    IF EXISTS(SELECT 1 FROM os_repair_admissions WHERE task_id=NEW.task_id) THEN RAISE EXCEPTION 'repair_orphan_work'; END IF;
    RETURN NULL;
   END IF;
   IF TG_OP='UPDATE' AND (NEW.state<>'RUNNING' OR OLD.state=NEW.state) THEN RETURN NULL; END IF;
  END IF;
  SELECT * INTO d FROM os_repair_admissions WHERE id=b.admission_id;
  PERFORM os_assert_repair_current(d,b.authority);
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  IF w.task_id<>d.task_id OR w.root_id<>d.root_id OR w.control_epoch<>1 OR w.lease_until<=clock_timestamp()
   OR w.lease_until>d.expires_at OR w.created_at<>b.created_at OR w.actual IS NOT NULL
   OR w.state<>(CASE WHEN TG_TABLE_NAME='os_work_attempts' AND TG_OP='UPDATE' THEN 'RUNNING' ELSE 'RESERVED' END)
   OR b.session_id IS DISTINCT FROM (b.authority->>'sessionId')::uuid
  THEN RAISE EXCEPTION 'repair_work_binding'; END IF;
  IF b.phase='prepare' THEN
   IF w.kind<>'read' OR w.segment_id<>d.segment_id OR (w.reserved->>'workMs')::bigint NOT BETWEEN 1 AND 25000
    OR w.reserved<>jsonb_build_object('stages',0,'children',0,'tokens',0,'toolCalls',2,'nativeJobs',0,'costMicros',0,'workMs',(w.reserved->>'workMs')::bigint,'repairs',0,'planRevisions',0)
   THEN RAISE EXCEPTION 'repair_preparation_budget'; END IF;
  ELSE
   SELECT * INTO g FROM os_repair_grants WHERE id=b.grant_id;
   PERFORM os_assert_repair_grant(g);
   IF g.admission_id<>d.id OR b.authority<>g.payload->'authority' OR w.kind<>'effect'
    OR w.invocation_id::text<>g.payload->>'invocationId' OR b.effect_request_digest<>g.payload->>'effectRequestDigest'
    OR w.segment_id::text<>g.payload->>'segmentId' OR w.lease_until>g.expires_at
    OR (w.reserved->>'workMs')::bigint NOT BETWEEN 1 AND 45000
    OR w.reserved<>jsonb_build_object('stages',1,'children',0,'tokens',0,'toolCalls',1,'nativeJobs',0,'costMicros',0,'workMs',(w.reserved->>'workMs')::bigint,'repairs',1,'planRevisions',0)
   THEN RAISE EXCEPTION 'repair_effect_budget'; END IF;
  END IF;
  IF w.lease_until>w.created_at+((w.reserved->>'workMs')::bigint*interval '1 millisecond')
   OR NOT EXISTS(SELECT 1 FROM os_segments WHERE id=w.segment_id AND task_id=d.task_id AND state='OPEN')
   OR EXISTS(SELECT 1 FROM os_budget_roots r,jsonb_object_keys(w.reserved) k WHERE r.id=d.root_id AND (r.outstanding->>k)::bigint<(w.reserved->>k)::bigint)
  THEN RAISE EXCEPTION 'repair_original_reservation'; END IF;
 ELSIF TG_TABLE_NAME='os_repair_prepared' THEN
  SELECT * INTO d FROM os_repair_admissions WHERE id=NEW.admission_id;
  SELECT * INTO b FROM os_repair_work WHERE id=NEW.work_binding_id;
  PERFORM os_assert_repair_current(d,b.authority);
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  SELECT * INTO artifact FROM os_artifacts WHERE id=NEW.artifact_id;
  IF b.phase<>'prepare' OR b.admission_id<>d.id OR w.state<>'SETTLED' OR w.lease_until<=clock_timestamp()
   OR artifact.purpose<>'artifact' OR artifact.classification<>'protected' OR artifact.ciphertext_digest<>NEW.ciphertext_digest
   OR artifact.expires_at<>NEW.expires_at OR NEW.expires_at>d.expires_at OR NEW.expires_at<=clock_timestamp()
   OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=d.task_id AND state='WAITING_APPROVAL')
  THEN RAISE EXCEPTION 'repair_prepared_result'; END IF;
 ELSIF TG_TABLE_NAME='os_repair_challenges' OR TG_TABLE_NAME='os_repair_registrations' OR TG_TABLE_NAME='os_repair_approvals' THEN
  IF TG_TABLE_NAME='os_repair_challenges' THEN q=NEW;
  ELSE SELECT * INTO q FROM os_repair_challenges WHERE id=NEW.challenge_id; END IF;
  SELECT * INTO d FROM os_repair_admissions WHERE id=q.admission_id;
  SELECT * INTO p FROM os_repair_prepared WHERE id=q.prepared_id;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=q.session_id;
  PERFORM os_assert_repair_current(d,jsonb_build_object('subject',q.binding->'subject','sessionId',q.session_id,
   'sessionGeneration',session.session_generation,'applicationGeneration',session.application_generation,'subjectGeneration',session.subject_generation,
   'hostSessionRef',q.binding->>'hostSessionRef','profileRef','local-synthetic','policyGeneration',(q.binding->>'policyGeneration')::bigint));
  now_at=clock_timestamp();
  SELECT * INTO command FROM os_commands WHERE id=q.command_id;
  IF COALESCE((q.binding->>'challengeId'=q.id::text AND q.binding->>'sessionId'=q.session_id::text
   AND q.binding->>'proposalId'=p.proposal_id::text AND q.binding->>'proposalDigest'=p.proposal_digest
   AND q.binding->>'proposalRevision'='1' AND q.binding->>'requiredAssurance'='local-synthetic'
   AND q.binding->>'assuranceProfile'='local-synthetic-assurance/1'
   AND length(q.binding->>'nonce') BETWEEN 32 AND 128 AND p.admission_id=d.id
   AND (q.binding->>'createdAt')::timestamptz=q.created_at AND (q.binding->>'expiresAt')::timestamptz=q.expires_at
   AND q.expires_at>now_at AND q.expires_at<=p.expires_at AND q.expires_at<=session.expires_at
   AND (q.binding->>'sessionGeneration')::bigint=session.session_generation),false) IS NOT TRUE
   OR command.kind<>'repair.challenge' OR command.accepted_task_id<>d.task_id OR command.request_digest<>q.command_digest
  THEN RAISE EXCEPTION 'repair_fresh_challenge'; END IF;
  IF (SELECT count(*) FROM os_repair_challenges WHERE admission_id=d.id)>8 THEN RAISE EXCEPTION 'repair_challenge_ceiling'; END IF;
  IF TG_TABLE_NAME='os_repair_registrations' AND (NEW.binding_digest<>q.binding_digest OR NEW.registration<>jsonb_build_object('challengeId',q.id,'bindingDigest',q.binding_digest,'expiresAt',q.binding->>'expiresAt'))
  THEN RAISE EXCEPTION 'repair_registered_challenge'; END IF;
  IF TG_TABLE_NAME='os_repair_approvals' THEN
   SELECT * INTO command FROM os_commands WHERE id=NEW.command_id;
   IF COALESCE((NEW.admission_id=d.id AND NEW.prepared_id=p.id AND NEW.claim->'binding'=q.binding
    AND NEW.claim->>'decision'=NEW.decision AND NEW.claim->>'commandDigest'=NEW.command_digest
    AND NEW.attestation->>'bindingDigest'=q.binding_digest AND NEW.attestation->>'subject'=q.binding->>'subject'
    AND NEW.attestation->>'sessionId'=q.session_id::text AND NEW.attestation->>'challengeId'=q.id::text
    AND NEW.attestation->>'decision'=NEW.decision AND NEW.attestation->>'commandDigest'=NEW.command_digest
    AND NEW.attestation->>'assertionRef'=NEW.claim->>'assertionRef' AND NEW.attestation->>'commandId'=NEW.claim->>'commandId'
    AND command.kind='repair.approval' AND command.accepted_task_id=d.task_id AND command.request_digest=NEW.command_digest
    AND NEW.claim->>'commandId'=command.command_id::text
    AND (NEW.attestation->>'observedAt')::timestamptz BETWEEN now_at-interval '5 seconds' AND now_at+interval '1 second'
    AND NEW.expires_at>now_at AND NEW.expires_at<=q.expires_at AND NEW.expires_at<=(NEW.attestation->>'expiresAt')::timestamptz
    AND EXISTS(SELECT 1 FROM os_repair_registrations WHERE challenge_id=q.id AND binding_digest=q.binding_digest)),false) IS NOT TRUE
   THEN RAISE EXCEPTION 'repair_fresh_approval'; END IF;
  END IF;
 ELSIF TG_TABLE_NAME='os_repair_grants' THEN PERFORM os_assert_repair_grant(NEW);
 ELSIF TG_TABLE_NAME='os_repair_revocations' THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE
   (installation_id,application_id,tenant_id,subject_id,id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
  IF session.revoked OR session.expires_at<=clock_timestamp() OR session.id IS NULL
   OR NOT EXISTS(SELECT 1 FROM os_applications a JOIN os_subjects s ON s.installation_id=a.installation_id AND s.application_id=a.id
    WHERE (s.installation_id,s.application_id,s.tenant_id,s.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
    AND a.active AND s.active AND a.generation=session.application_generation AND s.generation=session.subject_generation)
  THEN RAISE EXCEPTION 'repair_revocation_owner'; END IF;
 ELSE
  SELECT * INTO b FROM os_repair_work WHERE id=NEW.binding_id;
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  SELECT * INTO g FROM os_repair_grants WHERE id=b.grant_id;
  IF COALESCE((b.phase='effect' AND w.state IN ('RUNNING','UNKNOWN','SETTLED')
   AND NEW.payload->>'providerRef'=g.payload->>'providerRef' AND NEW.payload->'subject'=g.payload->'subject'
   AND NEW.payload->>'invocationId'=g.payload->>'invocationId' AND NEW.payload->>'requestDigest'=g.payload->>'effectRequestDigest'
   AND NEW.payload->>'attestationProfile'='atomic-host-receipt-observation/1'),false) IS NOT TRUE
  THEN RAISE EXCEPTION 'repair_admitted_receipt_only'; END IF;
 END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_guard_repair_child() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.node_ref LIKE 'repair/%' AND NOT EXISTS(SELECT 1 FROM os_repair_admissions d WHERE
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.task_id,d.parent_task_id,d.root_id)=
  (NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.task_id,NEW.parent_task_id,NEW.root_id)
  AND NEW.node_ref='repair/'||d.id::text) THEN RAISE EXCEPTION 'repair_orphan_child'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_repair_child AFTER INSERT ON os_workload_bindings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_child();
CREATE CONSTRAINT TRIGGER commit_os_repair_work_insert AFTER INSERT ON os_work_attempts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit();
CREATE CONSTRAINT TRIGGER commit_os_repair_work_begin AFTER UPDATE ON os_work_attempts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit();

CREATE FUNCTION os_guard_registered_inverse() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM os_reviewed_effect_providers p WHERE
  (p.installation_id,p.application_id,p.registration_revision,p.capability_ref,p.provider_ref,p.descriptor_digest,p.schema_digest)=
  (NEW.installation_id,NEW.application_id,NEW.registration_revision,NEW.capability_ref,NEW.provider_ref,NEW.descriptor_digest,NEW.schema_digest)
  AND p.profile_ref='reviewed-host-effect/1') THEN RAISE EXCEPTION 'repair_registered_provider'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER insert_os_registered_inverse BEFORE INSERT ON os_registered_inverses
 FOR EACH ROW EXECUTE FUNCTION os_guard_registered_inverse();

CREATE FUNCTION os_guard_repair_root_charge() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE current_root os_budget_roots%ROWTYPE;
BEGIN
 IF EXISTS(SELECT 1 FROM os_repair_admissions WHERE root_id=NEW.id) THEN
  SELECT * INTO current_root FROM os_budget_roots WHERE id=NEW.id;
  IF (current_root.spent->>'children')::bigint <
    (SELECT count(*) FROM os_workload_bindings WHERE root_id=NEW.id AND parent_task_id IS NOT NULL)
   OR EXISTS(SELECT 1 FROM jsonb_object_keys(OLD.spent) k WHERE (NEW.spent->>k)::bigint<(OLD.spent->>k)::bigint)
  THEN RAISE EXCEPTION 'repair_root_charge_preserved'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_repair_root_charge AFTER UPDATE ON os_budget_roots
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_root_charge();
'''


def upgrade():
    op.execute("\nCREATE TABLE os_registered_inverses (\n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\tregistration_revision BIGINT NOT NULL, \n\tcapability_ref VARCHAR(256) NOT NULL, \n\tprofile_ref VARCHAR(64) NOT NULL, \n\tprovider_ref VARCHAR(256) NOT NULL, \n\tdescriptor_digest VARCHAR(64) NOT NULL, \n\tschema_digest VARCHAR(64) NOT NULL, \n\tbinding_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tPRIMARY KEY (installation_id, application_id, registration_revision, capability_ref), \n\tCONSTRAINT ck_inverse_profile CHECK (profile_ref='typed-update-restore/1' AND registration_revision>0), \n\tCONSTRAINT ck_inverse_descriptor_digest_digest CHECK (descriptor_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_inverse_schema_digest_digest CHECK (schema_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_inverse_binding_digest_digest CHECK (binding_digest ~ '^[a-f0-9]{64}$')\n)\n\n")
    op.execute("\nCREATE TABLE os_repair_admissions (\n\tid UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tparent_task_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\toriginal_kind VARCHAR(32) NOT NULL, \n\treviewed_binding_id UUID, \n\treviewed_projection_id UUID, \n\tdelegated_binding_id UUID, \n\tdelegated_projection_id UUID, \n\tobservation_digest VARCHAR(64) NOT NULL, \n\toriginal_proposal_id UUID NOT NULL, \n\toriginal_receipt_id UUID NOT NULL, \n\toriginal_receipt_version BIGINT NOT NULL, \n\tsession_id UUID NOT NULL, \n\tauthority JSONB NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tcommand_digest VARCHAR(64) NOT NULL, \n\tcapability_ref VARCHAR(256) NOT NULL, \n\tregistration_revision BIGINT NOT NULL, \n\tdefinition_digest VARCHAR(64) NOT NULL, \n\trepair_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_admission_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_task_once UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id), \n\tCONSTRAINT uq_repair_original_root_once UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id), \n\tCONSTRAINT uq_repair_command_once UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT ck_repair_original_family CHECK ((original_kind='input-reviewed' AND reviewed_binding_id IS NOT NULL AND reviewed_projection_id IS NOT NULL AND delegated_binding_id IS NULL AND delegated_projection_id IS NULL) OR (original_kind='input-delegated' AND delegated_binding_id IS NOT NULL AND delegated_projection_id IS NOT NULL AND reviewed_binding_id IS NULL AND reviewed_projection_id IS NULL)), \n\tCONSTRAINT ck_repair_identity_time CHECK (task_id<>parent_task_id AND expires_at>created_at AND original_receipt_version>0 AND registration_revision>0), \n\tCONSTRAINT ck_repair_authority_closed CHECK (jsonb_typeof((authority))='object' AND (authority) ?& ARRAY['subject','sessionId','sessionGeneration','applicationGeneration','subjectGeneration','hostSessionRef','profileRef','policyGeneration'] AND ((authority) - ARRAY['subject','sessionId','sessionGeneration','applicationGeneration','subjectGeneration','hostSessionRef','profileRef','policyGeneration'])='{}'::jsonb), \n\tCONSTRAINT ck_repair_observation_digest_digest CHECK (observation_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_command_digest_digest CHECK (command_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_definition_digest_digest CHECK (definition_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_repair_digest_digest CHECK (repair_digest ~ '^[a-f0-9]{64}$')\n)\n\n")
    op.execute("\nCREATE TABLE os_repair_approvals (\n\tid UUID NOT NULL, \n\tadmission_id UUID NOT NULL, \n\tprepared_id UUID NOT NULL, \n\tchallenge_id UUID NOT NULL, \n\tsuccessor_segment_id UUID, \n\tcommand_id UUID NOT NULL, \n\tcommand_digest VARCHAR(64) NOT NULL, \n\tdecision VARCHAR(16) NOT NULL, \n\tclaim JSONB NOT NULL, \n\tattestation JSONB NOT NULL, \n\tdecision_ref JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_approval_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_approval_once UNIQUE (installation_id, application_id, tenant_id, subject_id, admission_id), \n\tCONSTRAINT uq_repair_approval_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT ck_repair_approval_time CHECK (((decision='approve' AND successor_segment_id IS NOT NULL) OR (decision='reject' AND successor_segment_id IS NULL)) AND expires_at>created_at), \n\tCONSTRAINT ck_repair_approval_digest CHECK (command_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_claim_closed CHECK (jsonb_typeof((claim))='object' AND (claim) ?& ARRAY['binding','assertionRef','commandId','commandDigest','decision'] AND ((claim) - ARRAY['binding','assertionRef','commandId','commandDigest','decision'])='{}'::jsonb), \n\tCONSTRAINT ck_repair_attestation_closed CHECK (jsonb_typeof((attestation))='object' AND (attestation) ?& ARRAY['subject','sessionId','challengeId','bindingDigest','assertionRef','commandId','commandDigest','decision','assuranceRef','observedAt','expiresAt'] AND ((attestation) - ARRAY['subject','sessionId','challengeId','bindingDigest','assertionRef','commandId','commandDigest','decision','assuranceRef','observedAt','expiresAt'])='{}'::jsonb), \n\tCONSTRAINT ck_repair_decision_closed CHECK (jsonb_typeof((decision_ref))='object' AND (decision_ref) ?& ARRAY['id','subject','proposalId','proposalRevision','digest','assuranceRef','expiresAt'] AND ((decision_ref) - ARRAY['id','subject','proposalId','proposalRevision','digest','assuranceRef','expiresAt'])='{}'::jsonb)\n)\n\n")
    op.execute("\nCREATE TABLE os_repair_challenges (\n\tid UUID NOT NULL, \n\tadmission_id UUID NOT NULL, \n\tprepared_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tcommand_digest VARCHAR(64) NOT NULL, \n\tbinding_digest VARCHAR(64) NOT NULL, \n\tbinding JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_challenge_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_challenge_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT ck_repair_challenge_time CHECK (expires_at>created_at AND expires_at<=created_at+interval '60 seconds'), \n\tCONSTRAINT ck_repair_challenge_closed CHECK (jsonb_typeof((binding))='object' AND (binding) ?& ARRAY['subject','sessionId','sessionGeneration','hostSessionRef','policyGeneration','challengeId','nonce','proposalId','proposalRevision','proposalDigest','assuranceProfile','assuranceProviderRef','requiredAssurance','createdAt','expiresAt'] AND ((binding) - ARRAY['subject','sessionId','sessionGeneration','hostSessionRef','policyGeneration','challengeId','nonce','proposalId','proposalRevision','proposalDigest','assuranceProfile','assuranceProviderRef','requiredAssurance','createdAt','expiresAt'])='{}'::jsonb), \n\tCONSTRAINT ck_repair_challenge_command_digest_digest CHECK (command_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_challenge_binding_digest_digest CHECK (binding_digest ~ '^[a-f0-9]{64}$')\n)\n\n")
    op.execute("\nCREATE TABLE os_repair_grants (\n\tid UUID NOT NULL, \n\tadmission_id UUID NOT NULL, \n\tapproval_id UUID NOT NULL, \n\tgrant_digest VARCHAR(64) NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_grant_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_grant_once UNIQUE (installation_id, application_id, tenant_id, subject_id, admission_id), \n\tCONSTRAINT uq_repair_grant_approval_once UNIQUE (installation_id, application_id, tenant_id, subject_id, approval_id), \n\tCONSTRAINT ck_repair_grant_time CHECK (expires_at>created_at AND expires_at<=created_at+interval '60 seconds'), \n\tCONSTRAINT ck_repair_grant_digest CHECK (grant_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_grant_size CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536), \n\tCONSTRAINT ck_repair_grant_closed CHECK (jsonb_typeof((payload))='object' AND (payload) ?& ARRAY['profileRef','id','subject','repairId','taskId','parentTaskId','rootId','segmentId','controlEpoch','preparedId','approvalId','authorization','proposalId','proposalRevision','proposalDigest','stageId','capabilityRef','providerRef','invocationId','effectRequestDigest','originalReceiptId','originalReceiptVersion','authority','registrationRevision','definitionDigest','bundleRevision','bundleDigest','createdAt','expiresAt','grantDigest'] AND ((payload) - ARRAY['profileRef','id','subject','repairId','taskId','parentTaskId','rootId','segmentId','controlEpoch','preparedId','approvalId','authorization','proposalId','proposalRevision','proposalDigest','stageId','capabilityRef','providerRef','invocationId','effectRequestDigest','originalReceiptId','originalReceiptVersion','authority','registrationRevision','definitionDigest','bundleRevision','bundleDigest','createdAt','expiresAt','grantDigest'])='{}'::jsonb)\n)\n\n")
    op.execute("\nCREATE TABLE os_repair_prepared (\n\tid UUID NOT NULL, \n\tadmission_id UUID NOT NULL, \n\twork_binding_id UUID NOT NULL, \n\tartifact_id UUID NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\tproposal_id UUID NOT NULL, \n\tproposal_digest VARCHAR(64) NOT NULL, \n\tstage_id UUID NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_prepared_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_prepared_once UNIQUE (installation_id, application_id, tenant_id, subject_id, admission_id), \n\tCONSTRAINT ck_repair_prepared_time CHECK (expires_at>created_at AND expires_at<=created_at+interval '10 minutes'), \n\tCONSTRAINT ck_repair_prepared_ciphertext_digest_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_prepared_proposal_digest_digest CHECK (proposal_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_prepared_request_digest_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n)\n\n")
    op.execute("\nCREATE TABLE os_repair_receipts (\n\tid UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tordinal BIGINT NOT NULL, \n\tprovider_binding_digest VARCHAR(64) NOT NULL, \n\tobservation_digest VARCHAR(64) NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_receipt_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_receipt_ordinal UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id, ordinal), \n\tCONSTRAINT ck_repair_receipt_ordinal CHECK (ordinal BETWEEN 1 AND 32), \n\tCONSTRAINT ck_repair_receipt_provider_binding_digest_digest CHECK (provider_binding_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_receipt_observation_digest_digest CHECK (observation_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_receipt_closed CHECK (jsonb_typeof((payload))='object' AND (payload) ?& ARRAY['subject','providerRef','invocationId','requestDigest','receiptId','status','version','observedAt','attestationProfile'] AND ((payload) - ARRAY['subject','providerRef','invocationId','requestDigest','receiptId','status','version','observedAt','attestationProfile'])='{}'::jsonb)\n)\n\n")
    op.execute("\nCREATE TABLE os_repair_registrations (\n\tid UUID NOT NULL, \n\tchallenge_id UUID NOT NULL, \n\tbinding_digest VARCHAR(64) NOT NULL, \n\tregistration JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_registration_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_registration_once UNIQUE (installation_id, application_id, tenant_id, subject_id, challenge_id), \n\tCONSTRAINT ck_repair_registration_digest CHECK (binding_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_repair_registration_closed CHECK (jsonb_typeof((registration))='object' AND (registration) ?& ARRAY['challengeId','bindingDigest','expiresAt'] AND ((registration) - ARRAY['challengeId','bindingDigest','expiresAt'])='{}'::jsonb)\n)\n\n")
    op.execute('\nCREATE TABLE os_repair_revocations (\n\tid UUID NOT NULL, \n\tapproval_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_revocation_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_revocation_once UNIQUE (installation_id, application_id, tenant_id, subject_id, approval_id), \n\tCONSTRAINT uq_repair_revocation_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id)\n)\n\n')
    op.execute("\nCREATE TABLE os_repair_work (\n\tid UUID NOT NULL, \n\tadmission_id UUID NOT NULL, \n\tattempt_id UUID NOT NULL, \n\tphase VARCHAR(16) NOT NULL, \n\tsession_id UUID NOT NULL, \n\tauthority JSONB NOT NULL, \n\tgrant_id UUID, \n\tpermit_id UUID, \n\teffect_request_digest VARCHAR(64), \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_repair_work_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_repair_phase_once UNIQUE (installation_id, application_id, tenant_id, subject_id, admission_id, phase), \n\tCONSTRAINT uq_repair_work_once UNIQUE (installation_id, application_id, tenant_id, subject_id, attempt_id), \n\tCONSTRAINT uq_repair_permit_once UNIQUE (installation_id, application_id, tenant_id, subject_id, permit_id), \n\tCONSTRAINT ck_repair_work_family CHECK ((phase='prepare' AND grant_id IS NULL AND permit_id IS NULL AND effect_request_digest IS NULL) OR (phase='effect' AND grant_id IS NOT NULL AND permit_id IS NOT NULL AND effect_request_digest IS NOT NULL AND effect_request_digest ~ '^[a-f0-9]{64}$')), \n\tCONSTRAINT ck_repair_work_authority_closed CHECK (jsonb_typeof((authority))='object' AND (authority) ?& ARRAY['subject','sessionId','sessionGeneration','applicationGeneration','subjectGeneration','hostSessionRef','profileRef','policyGeneration'] AND ((authority) - ARRAY['subject','sessionId','sessionGeneration','applicationGeneration','subjectGeneration','hostSessionRef','profileRef','policyGeneration'])='{}'::jsonb)\n)\n\n")
    op.execute('ALTER TABLE os_registered_inverses ADD CONSTRAINT fk_inverse_reviewed_provider FOREIGN KEY(installation_id, application_id, registration_revision, capability_ref) REFERENCES os_reviewed_effect_providers (installation_id, application_id, registration_revision, capability_ref)')
    op.execute("CREATE TRIGGER immutable_os_registered_inverses BEFORE UPDATE OR DELETE ON os_registered_inverses FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('installation_id','application_id','registration_revision','capability_ref','profile_ref','provider_ref','descriptor_digest','schema_digest','binding_digest','created_at')")
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_os_commands_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, command_id) REFERENCES os_commands (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_os_input_proposals_original_proposal_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, original_proposal_id) REFERENCES os_input_proposals (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_os_segments_segment_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, segment_id) REFERENCES os_segments (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_os_tasks_parent_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, parent_task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_repair_delegated_original_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, delegated_projection_id, delegated_binding_id, observation_digest) REFERENCES os_input_delegated_receipts (installation_id, application_id, tenant_id, subject_id, id, binding_id, observation_digest)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_repair_registered_inverse FOREIGN KEY(installation_id, application_id, registration_revision, capability_ref) REFERENCES os_registered_inverses (installation_id, application_id, registration_revision, capability_ref)')
    op.execute('ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_repair_reviewed_original_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, reviewed_projection_id, reviewed_binding_id, observation_digest) REFERENCES os_input_reviewed_receipt_projections (installation_id, application_id, tenant_id, subject_id, id, binding_id, observation_digest)')
    op.execute("CREATE TRIGGER immutable_os_repair_admissions BEFORE UPDATE OR DELETE ON os_repair_admissions FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','task_id','parent_task_id','root_id','segment_id','original_kind','reviewed_binding_id','reviewed_projection_id','delegated_binding_id','delegated_projection_id','observation_digest','original_proposal_id','original_receipt_id','original_receipt_version','session_id','authority','command_id','command_digest','capability_ref','registration_revision','definition_digest','repair_digest','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('ALTER TABLE os_repair_approvals ADD CONSTRAINT fk_os_commands_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, command_id) REFERENCES os_commands (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_approvals ADD CONSTRAINT fk_os_repair_admissions_admission_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, admission_id) REFERENCES os_repair_admissions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_approvals ADD CONSTRAINT fk_os_repair_challenges_challenge_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, challenge_id) REFERENCES os_repair_challenges (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_approvals ADD CONSTRAINT fk_os_repair_prepared_prepared_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, prepared_id) REFERENCES os_repair_prepared (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_approvals ADD CONSTRAINT fk_os_segments_successor_segment_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, successor_segment_id) REFERENCES os_segments (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute("CREATE TRIGGER immutable_os_repair_approvals BEFORE UPDATE OR DELETE ON os_repair_approvals FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','admission_id','prepared_id','challenge_id','successor_segment_id','command_id','command_digest','decision','claim','attestation','decision_ref','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('ALTER TABLE os_repair_challenges ADD CONSTRAINT fk_os_commands_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, command_id) REFERENCES os_commands (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_challenges ADD CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_challenges ADD CONSTRAINT fk_os_repair_admissions_admission_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, admission_id) REFERENCES os_repair_admissions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_challenges ADD CONSTRAINT fk_os_repair_prepared_prepared_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, prepared_id) REFERENCES os_repair_prepared (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute("CREATE TRIGGER immutable_os_repair_challenges BEFORE UPDATE OR DELETE ON os_repair_challenges FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','admission_id','prepared_id','session_id','command_id','command_digest','binding_digest','binding','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('ALTER TABLE os_repair_grants ADD CONSTRAINT fk_os_repair_admissions_admission_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, admission_id) REFERENCES os_repair_admissions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_grants ADD CONSTRAINT fk_os_repair_approvals_approval_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, approval_id) REFERENCES os_repair_approvals (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute("CREATE TRIGGER immutable_os_repair_grants BEFORE UPDATE OR DELETE ON os_repair_grants FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','admission_id','approval_id','grant_digest','payload','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('ALTER TABLE os_repair_prepared ADD CONSTRAINT fk_os_artifacts_artifact_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, artifact_id) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_prepared ADD CONSTRAINT fk_os_repair_admissions_admission_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, admission_id) REFERENCES os_repair_admissions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_prepared ADD CONSTRAINT fk_os_repair_work_work_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, work_binding_id) REFERENCES os_repair_work (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute("CREATE TRIGGER immutable_os_repair_prepared BEFORE UPDATE OR DELETE ON os_repair_prepared FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','admission_id','work_binding_id','artifact_id','ciphertext_digest','proposal_id','proposal_digest','stage_id','request_digest','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('ALTER TABLE os_repair_receipts ADD CONSTRAINT fk_os_repair_work_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES os_repair_work (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute("CREATE TRIGGER immutable_os_repair_receipts BEFORE UPDATE OR DELETE ON os_repair_receipts FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','binding_id','ordinal','provider_binding_digest','observation_digest','payload','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('ALTER TABLE os_repair_registrations ADD CONSTRAINT fk_os_repair_challenges_challenge_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, challenge_id) REFERENCES os_repair_challenges (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute("CREATE TRIGGER immutable_os_repair_registrations BEFORE UPDATE OR DELETE ON os_repair_registrations FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','challenge_id','binding_digest','registration','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('ALTER TABLE os_repair_revocations ADD CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_revocations ADD CONSTRAINT fk_os_repair_approvals_approval_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, approval_id) REFERENCES os_repair_approvals (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute("CREATE TRIGGER immutable_os_repair_revocations BEFORE UPDATE OR DELETE ON os_repair_revocations FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','approval_id','session_id','command_id','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('ALTER TABLE os_repair_work ADD CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_work ADD CONSTRAINT fk_os_repair_admissions_admission_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, admission_id) REFERENCES os_repair_admissions (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_work ADD CONSTRAINT fk_os_repair_grants_grant_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, grant_id) REFERENCES os_repair_grants (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute('ALTER TABLE os_repair_work ADD CONSTRAINT fk_os_work_attempts_attempt_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id)')
    op.execute("CREATE TRIGGER immutable_os_repair_work BEFORE UPDATE OR DELETE ON os_repair_work FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','admission_id','attempt_id','phase','session_id','authority','grant_id','permit_id','effect_request_digest','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute(GUARDS)
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_admissions AFTER INSERT ON os_repair_admissions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_approvals AFTER INSERT ON os_repair_approvals DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_challenges AFTER INSERT ON os_repair_challenges DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_grants AFTER INSERT ON os_repair_grants DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_prepared AFTER INSERT ON os_repair_prepared DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_receipts AFTER INSERT ON os_repair_receipts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_registrations AFTER INSERT ON os_repair_registrations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_revocations AFTER INSERT ON os_repair_revocations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')
    op.execute('CREATE CONSTRAINT TRIGGER commit_os_repair_work AFTER INSERT ON os_repair_work DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_repair_commit()')


def downgrade():
    raise RuntimeError('Protected additive repair revision; no automatic downgrade')
