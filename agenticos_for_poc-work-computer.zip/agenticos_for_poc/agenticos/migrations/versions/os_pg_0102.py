"""Draft canonical keyword-only memory publication profile."""
from alembic import op

revision='os_pg_0102'
down_revision='os_pg_0101'
branch_labels=None
depends_on=None

UPGRADE=r"""ALTER TABLE personal_learning_settings DROP CONSTRAINT ck_learning_settings_choice;
ALTER TABLE personal_learning_settings ADD CONSTRAINT ck_learning_settings_choice CHECK (COALESCE(jsonb_typeof(choice->'learnConversation')='boolean' AND jsonb_typeof(choice->'learnUsage')='boolean' AND jsonb_typeof(choice->'useMemory')='boolean' AND choice=jsonb_build_object('learnConversation',choice->'learnConversation','learnUsage',choice->'learnUsage','useMemory',choice->'useMemory','retentionProfile','private-local/1','extractorProfile',choice->'extractorProfile','embeddingProfile',choice->'embeddingProfile') AND choice->>'extractorProfile' IN ('synthetic-staging/1','classified-staging/2') AND choice->>'embeddingProfile' IN ('synthetic-embedding/1','minilm-english-onnx/1','keyword-fts/1'),false));
ALTER TABLE personal_knowledge_projection_jobs DROP CONSTRAINT ck_knowledge_job_states;
ALTER TABLE personal_knowledge_projection_jobs ADD CONSTRAINT ck_knowledge_job_states CHECK (profile_ref IN ('synthetic-embedding/1','minilm-english-onnx/1','keyword-fts/1') AND operation IN ('INDEX','PURGE') AND state IN ('PENDING','CANCELLED','COMPLETE'));
ALTER TABLE personal_index_generations DROP CONSTRAINT ck_personal_index_profile;
ALTER TABLE personal_index_generations ADD CONSTRAINT ck_personal_index_profile CHECK (profile_ref IN ('minilm-english-onnx/1','keyword-fts/1') AND expected_entries BETWEEN 0 AND 64);
CREATE OR REPLACE FUNCTION os_assert_task_memory(bid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $$
DECLARE b task_memory_bindings%ROWTYPE; s personal_learning_settings%ROWTYPE;
 t os_tasks%ROWTYPE; a os_admissions%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; k task_knowledge_snapshots%ROWTYPE;
 n bigint; watermark bigint;
BEGIN
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 IF os_restoration_erased('task_memory_bindings',to_jsonb(b)) THEN
  IF live THEN RAISE EXCEPTION 'restored_private_content_erased';END IF;
  RETURN;
 END IF;

 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 SELECT * INTO t FROM os_tasks WHERE id=b.task_id;
 SELECT * INTO a FROM os_admissions WHERE id=b.admission_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
 SELECT * INTO k FROM task_knowledge_snapshots WHERE binding_id=bid;
 SELECT count(*) INTO n FROM task_memory_references WHERE binding_id=bid;
 IF b.id IS NULL OR t.id IS NULL OR a.id IS NULL OR s.id IS NULL OR a.task_id<>t.id
  OR b.deadline<>t.deadline OR a.authority->>'sessionId' IS DISTINCT FROM b.session_id::text
  OR n<>b.reference_count OR EXISTS(SELECT 1 FROM task_memory_references r WHERE r.binding_id=bid AND r.ordinal>=n)
  OR (SELECT count(*) FROM task_memory_bindings WHERE settings_id=s.id)>128
  OR NOT EXISTS(SELECT 1 FROM os_dispatches WHERE task_id=t.id AND (workflow_profile=
   CASE b.profile_ref WHEN 'OSTaskMemory/1' THEN 'OSTaskMemoryDriver/1' WHEN 'OSAgentMemory/1' THEN 'OSAgentTaskDriver/1' WHEN 'OSAgentPlannerMemory/1' THEN 'OSAgentTaskDriver/1' END
   OR b.profile_ref='OSAgentMemory/1' AND workflow_profile='OSAgentDirectDriver/1'))
  OR (b.profile_ref='OSTaskMemory/1' AND b.reference_count>8)
  OR (b.profile_ref='OSAgentMemory/1' AND (b.reference_count>64 OR b.knowledge_profile_ref IS NOT NULL
   OR a.context->'harness'->>'ref' NOT LIKE 'memory-assisted-read/%'
   OR NOT EXISTS(SELECT 1 FROM os_budget_roots WHERE id=t.budget_root_id AND root_task_id=t.id
    AND accounting_format='agent-resources/1' AND admission_id=a.id)))
  OR (b.profile_ref='OSAgentPlannerMemory/1' AND (b.reference_count>64 OR b.knowledge_profile_ref IS DISTINCT FROM 'OSProtectedPlanning/1'
   OR a.context->'harness'->>'ref' NOT LIKE 'private-planned-read/%' OR k.reference_metadata IS DISTINCT FROM '[]'::jsonb
   OR NOT os_agent_context_matches(a,a.context)
   OR NOT EXISTS(SELECT 1 FROM os_budget_roots WHERE id=t.budget_root_id AND root_task_id=t.id
    AND accounting_format='agent-resources/1' AND admission_id=a.id)))
  OR (b.knowledge_profile_ref IS NULL) IS DISTINCT FROM (k.id IS NULL)
  OR (k.id IS NOT NULL AND b.knowledge_binding_mac IS DISTINCT FROM k.binding_mac)
  OR (k.id IS NOT NULL AND EXISTS(SELECT 1 FROM jsonb_array_elements(k.reference_metadata) r
   WHERE r IS DISTINCT FROM jsonb_build_object('chunkId',r->'chunkId','documentId',r->'documentId',
    'revisionId',r->'revisionId','revision',r->'revision','layer',r->'layer','generationId',r->'generationId',
    'ciphertextDigest',r->'ciphertextDigest') OR r->>'layer' NOT IN ('business','architecture','system','shared')
    OR r->>'ciphertextDigest' !~ '^[0-9a-f]{64}$' OR jsonb_typeof(r->'revision')<>'number'))
  THEN RAISE EXCEPTION 'task_memory_exact_binding';END IF;
 IF NOT live THEN RETURN;END IF;
 SELECT sequence INTO watermark FROM memory_recovery_owners WHERE settings_id=s.id;
 IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation)
   IS DISTINCT FROM ROW(b.settings_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation)
  OR watermark IS DISTINCT FROM b.journal_sequence
  OR EXISTS(SELECT 1 FROM task_memory_erasures WHERE binding_id=bid)
  OR t.deadline<=clock_timestamp() OR session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR (k.valid_until IS NOT NULL AND k.valid_until<=clock_timestamp())
  THEN RAISE EXCEPTION 'task_memory_obsolete';END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
  AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
 IF app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
  OR owner.host_policy_generation IS DISTINCT FROM (a.authority->>'policyGeneration')::bigint
  THEN RAISE EXCEPTION 'task_memory_owner_obsolete';END IF;
 IF b.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=b.context_id
  AND settings_id=s.id AND kind='context' AND state='ACTIVE') THEN RAISE EXCEPTION 'task_memory_context_obsolete';END IF;
 IF (n>0 OR b.profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1')) AND (s.choice->>'useMemory' IS DISTINCT FROM 'true' OR s.choice->>'embeddingProfile' NOT IN ('minilm-english-onnx/1','keyword-fts/1'))
  THEN RAISE EXCEPTION 'task_memory_choice_obsolete';END IF;
 IF EXISTS(SELECT 1 FROM task_memory_references r JOIN personal_knowledge_entries e ON e.id=r.entry_id
  JOIN personal_knowledge_revisions v ON v.id=r.revision_id
  LEFT JOIN classified_knowledge_bindings c ON c.revision_id=r.revision_id
  WHERE r.binding_id=bid AND (e.settings_id<>s.id OR e.state<>'ACTIVE' OR e.version<>r.entry_version
   OR e.active_revision_id<>r.revision_id OR v.envelope IS NULL OR c.revision_id IS NULL
   OR c.lane<>r.lane OR r.context_ref IS DISTINCT FROM CASE WHEN c.context_id IS NULL THEN 'general/1'
     ELSE 'context/'||c.context_id::text||'/1' END
   OR r.context_ref NOT IN ('general/1',b.context_ref) OR os_revision_source_forgotten(r.revision_id)
   OR (e.valid_until IS NOT NULL AND e.valid_until<=clock_timestamp())
   OR (c.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=c.context_id AND state='ACTIVE'))
   OR (c.claim_key_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=c.claim_key_id AND state='ACTIVE'))
   OR NOT EXISTS(SELECT 1 FROM personal_index_pointers p JOIN personal_index_generations g ON g.id=p.generation_id
    WHERE p.entry_id=r.entry_id AND p.revision_id=r.revision_id AND p.entry_version=r.entry_version
    AND p.projection_id=r.projection_id AND g.settings_id=s.id AND g.generation=b.index_generation AND g.state='READY')))
  THEN RAISE EXCEPTION 'task_memory_reference_obsolete';END IF;
END $$"""

def upgrade():
    op.execute(UPGRADE)

def downgrade():
    op.execute(r"""DO $$ BEGIN IF EXISTS(SELECT 1 FROM personal_learning_settings WHERE choice->>'embeddingProfile'='keyword-fts/1')
 OR EXISTS(SELECT 1 FROM personal_index_generations WHERE profile_ref='keyword-fts/1')
 OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE profile_ref='keyword-fts/1')
 OR EXISTS(SELECT 1 FROM task_memory_bindings b JOIN os_dispatches d ON d.task_id=b.task_id
  WHERE b.profile_ref='OSAgentMemory/1' AND d.workflow_profile='OSAgentDirectDriver/1')
 THEN RAISE EXCEPTION 'keyword_memory_downgrade_refused'; END IF; END $$;
ALTER TABLE personal_learning_settings DROP CONSTRAINT ck_learning_settings_choice;
ALTER TABLE personal_learning_settings ADD CONSTRAINT ck_learning_settings_choice CHECK (COALESCE(jsonb_typeof(choice->'learnConversation')='boolean' AND jsonb_typeof(choice->'learnUsage')='boolean' AND jsonb_typeof(choice->'useMemory')='boolean' AND choice=jsonb_build_object('learnConversation',choice->'learnConversation','learnUsage',choice->'learnUsage','useMemory',choice->'useMemory','retentionProfile','private-local/1','extractorProfile',choice->'extractorProfile','embeddingProfile',choice->'embeddingProfile') AND choice->>'extractorProfile' IN ('synthetic-staging/1','classified-staging/2') AND choice->>'embeddingProfile' IN ('synthetic-embedding/1','minilm-english-onnx/1'),false));
ALTER TABLE personal_knowledge_projection_jobs DROP CONSTRAINT ck_knowledge_job_states;
ALTER TABLE personal_knowledge_projection_jobs ADD CONSTRAINT ck_knowledge_job_states CHECK (profile_ref IN ('synthetic-embedding/1','minilm-english-onnx/1') AND operation IN ('INDEX','PURGE') AND state IN ('PENDING','CANCELLED','COMPLETE'));
ALTER TABLE personal_index_generations DROP CONSTRAINT ck_personal_index_profile;
ALTER TABLE personal_index_generations ADD CONSTRAINT ck_personal_index_profile CHECK (profile_ref='minilm-english-onnx/1' AND expected_entries BETWEEN 0 AND 64);
CREATE OR REPLACE FUNCTION os_assert_task_memory(bid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $$
DECLARE b task_memory_bindings%ROWTYPE; s personal_learning_settings%ROWTYPE;
 t os_tasks%ROWTYPE; a os_admissions%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; k task_knowledge_snapshots%ROWTYPE;
 n bigint; watermark bigint;
BEGIN
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 IF os_restoration_erased('task_memory_bindings',to_jsonb(b)) THEN
  IF live THEN RAISE EXCEPTION 'restored_private_content_erased';END IF;
  RETURN;
 END IF;

 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 SELECT * INTO t FROM os_tasks WHERE id=b.task_id;
 SELECT * INTO a FROM os_admissions WHERE id=b.admission_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
 SELECT * INTO k FROM task_knowledge_snapshots WHERE binding_id=bid;
 SELECT count(*) INTO n FROM task_memory_references WHERE binding_id=bid;
 IF b.id IS NULL OR t.id IS NULL OR a.id IS NULL OR s.id IS NULL OR a.task_id<>t.id
  OR b.deadline<>t.deadline OR a.authority->>'sessionId' IS DISTINCT FROM b.session_id::text
  OR n<>b.reference_count OR EXISTS(SELECT 1 FROM task_memory_references r WHERE r.binding_id=bid AND r.ordinal>=n)
  OR (SELECT count(*) FROM task_memory_bindings WHERE settings_id=s.id)>128
  OR NOT EXISTS(SELECT 1 FROM os_dispatches WHERE task_id=t.id AND workflow_profile=
   CASE b.profile_ref WHEN 'OSTaskMemory/1' THEN 'OSTaskMemoryDriver/1' WHEN 'OSAgentMemory/1' THEN 'OSAgentTaskDriver/1' WHEN 'OSAgentPlannerMemory/1' THEN 'OSAgentTaskDriver/1' END)
  OR (b.profile_ref='OSTaskMemory/1' AND b.reference_count>8)
  OR (b.profile_ref='OSAgentMemory/1' AND (b.reference_count>64 OR b.knowledge_profile_ref IS NOT NULL
   OR a.context->'harness'->>'ref' NOT LIKE 'memory-assisted-read/%'
   OR NOT EXISTS(SELECT 1 FROM os_budget_roots WHERE id=t.budget_root_id AND root_task_id=t.id
    AND accounting_format='agent-resources/1' AND admission_id=a.id)))
  OR (b.profile_ref='OSAgentPlannerMemory/1' AND (b.reference_count>64 OR b.knowledge_profile_ref IS DISTINCT FROM 'OSProtectedPlanning/1'
   OR a.context->'harness'->>'ref' NOT LIKE 'private-planned-read/%' OR k.reference_metadata IS DISTINCT FROM '[]'::jsonb
   OR NOT os_agent_context_matches(a,a.context)
   OR NOT EXISTS(SELECT 1 FROM os_budget_roots WHERE id=t.budget_root_id AND root_task_id=t.id
    AND accounting_format='agent-resources/1' AND admission_id=a.id)))
  OR (b.knowledge_profile_ref IS NULL) IS DISTINCT FROM (k.id IS NULL)
  OR (k.id IS NOT NULL AND b.knowledge_binding_mac IS DISTINCT FROM k.binding_mac)
  OR (k.id IS NOT NULL AND EXISTS(SELECT 1 FROM jsonb_array_elements(k.reference_metadata) r
   WHERE r IS DISTINCT FROM jsonb_build_object('chunkId',r->'chunkId','documentId',r->'documentId',
    'revisionId',r->'revisionId','revision',r->'revision','layer',r->'layer','generationId',r->'generationId',
    'ciphertextDigest',r->'ciphertextDigest') OR r->>'layer' NOT IN ('business','architecture','system','shared')
    OR r->>'ciphertextDigest' !~ '^[0-9a-f]{64}$' OR jsonb_typeof(r->'revision')<>'number'))
  THEN RAISE EXCEPTION 'task_memory_exact_binding';END IF;
 IF NOT live THEN RETURN;END IF;
 SELECT sequence INTO watermark FROM memory_recovery_owners WHERE settings_id=s.id;
 IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation)
   IS DISTINCT FROM ROW(b.settings_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation)
  OR watermark IS DISTINCT FROM b.journal_sequence
  OR EXISTS(SELECT 1 FROM task_memory_erasures WHERE binding_id=bid)
  OR t.deadline<=clock_timestamp() OR session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR (k.valid_until IS NOT NULL AND k.valid_until<=clock_timestamp())
  THEN RAISE EXCEPTION 'task_memory_obsolete';END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
  AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
 IF app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
  OR owner.host_policy_generation IS DISTINCT FROM (a.authority->>'policyGeneration')::bigint
  THEN RAISE EXCEPTION 'task_memory_owner_obsolete';END IF;
 IF b.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=b.context_id
  AND settings_id=s.id AND kind='context' AND state='ACTIVE') THEN RAISE EXCEPTION 'task_memory_context_obsolete';END IF;
 IF (n>0 OR b.profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1')) AND (s.choice->>'useMemory' IS DISTINCT FROM 'true' OR s.choice->>'embeddingProfile'<>'minilm-english-onnx/1')
  THEN RAISE EXCEPTION 'task_memory_choice_obsolete';END IF;
 IF EXISTS(SELECT 1 FROM task_memory_references r JOIN personal_knowledge_entries e ON e.id=r.entry_id
  JOIN personal_knowledge_revisions v ON v.id=r.revision_id
  LEFT JOIN classified_knowledge_bindings c ON c.revision_id=r.revision_id
  WHERE r.binding_id=bid AND (e.settings_id<>s.id OR e.state<>'ACTIVE' OR e.version<>r.entry_version
   OR e.active_revision_id<>r.revision_id OR v.envelope IS NULL OR c.revision_id IS NULL
   OR c.lane<>r.lane OR r.context_ref IS DISTINCT FROM CASE WHEN c.context_id IS NULL THEN 'general/1'
     ELSE 'context/'||c.context_id::text||'/1' END
   OR r.context_ref NOT IN ('general/1',b.context_ref) OR os_revision_source_forgotten(r.revision_id)
   OR (e.valid_until IS NOT NULL AND e.valid_until<=clock_timestamp())
   OR (c.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=c.context_id AND state='ACTIVE'))
   OR (c.claim_key_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=c.claim_key_id AND state='ACTIVE'))
   OR NOT EXISTS(SELECT 1 FROM personal_index_pointers p JOIN personal_index_generations g ON g.id=p.generation_id
    WHERE p.entry_id=r.entry_id AND p.revision_id=r.revision_id AND p.entry_version=r.entry_version
    AND p.projection_id=r.projection_id AND g.settings_id=s.id AND g.generation=b.index_generation AND g.state='READY')))
  THEN RAISE EXCEPTION 'task_memory_reference_obsolete';END IF;
END $$""")
