"""Original-root Agent preparation and reviewed finite proactive delegation.

Draft86 requires protected populated positive/negative runtime and recovery
qualification before application. Applied85 and earlier remain immutable.
"""
from alembic import op

revision='os_pg_0086'
down_revision='os_pg_0085'
branch_labels=None
depends_on=None

DDL=r"""
ALTER TABLE os_proactive_revisions ADD COLUMN agent_operation_id uuid;
ALTER TABLE os_proactive_revisions ADD CONSTRAINT fk_os_agent_tool_operations_agent_operation_id
 FOREIGN KEY (installation_id,application_id,tenant_id,subject_id,agent_operation_id)
 REFERENCES os_agent_tool_operations (installation_id,application_id,tenant_id,subject_id,id);
ALTER TABLE os_proactive_revisions ADD CONSTRAINT uq_proactive_agent_operation
 UNIQUE (installation_id,application_id,tenant_id,subject_id,agent_operation_id);
"""

HELPERS=r"""
CREATE FUNCTION os_agent_proactive_profile_valid(r jsonb, installation uuid, application uuid, generation bigint, registration bigint)
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE p jsonb;
BEGIN
 p=r->'planning';
 RETURN COALESCE(r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
  'harness',r->'harness','installationId',installation,'applicationId',application,
  'outputContract','AgentProactivePreparation/1','adapterRef','os.proactivity.prepare/1','planning',p)
  AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
  AND p=jsonb_build_object('id',p->'id','revision',p->'revision','capability',r->'capability',
   'kinds',p->'kinds','workflowRefs',jsonb_build_array('registered-read/1'),
   'review','current-owner-exact-configuration/1','futureAuthority','qualified-proactive-delegation/1')
  AND p->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND jsonb_typeof(p->'revision')='number' AND p->>'revision' ~ '^[1-9][0-9]*$' AND (p->>'revision')::numeric<=9007199254740991
  AND jsonb_typeof(p->'kinds')='array' AND jsonb_array_length(p->'kinds') BETWEEN 1 AND 2
  AND p->'kinds' <@ '["schedule","subscription"]'::jsonb
  AND jsonb_array_length(p->'kinds')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(p->'kinds') v)
  AND r->'harness'->>'ref'='reviewed-proactivity/'||os_agent_profile_digest('manifest',p)
  AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=installation
   AND registered.application_id=application AND registered.application_generation=generation
   AND registered.registration_revision=registration AND registered.payload->'harness'->'harness'=r->'harness'
   AND registered.payload->'capabilities'->'allowedKinds' @> '["schedule"]'::jsonb)
  AND EXISTS(SELECT 1 FROM os_agent_capabilities cap WHERE cap.installation_id=installation AND cap.application_id=application
   AND cap.application_generation=generation AND r->'capability'=os_agent_profile_pin(cap.payload,'manifest')
   AND cap.payload->>'kind'='schedule' AND cap.payload->>'adapterRef'='os.proactivity.prepare/1'
   AND cap.payload->>'scopePolicyRef'='owner-reviewed-proactivity/1' AND cap.payload->'mcp'='null'::jsonb
   AND cap.payload->>'lifecycle'='qualified'),false);
END $$;

CREATE FUNCTION os_agent_proactive_profile(a os_admissions) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE app os_applications%ROWTYPE; lane os_agent_tool_profiles%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO app FROM os_applications WHERE installation_id=a.installation_id AND id=a.application_id;
 IF NOT COALESCE(app.active AND app.revision=a.registration_revision,false)
  OR (SELECT count(*) FROM os_agent_tool_profiles p WHERE p.installation_id=a.installation_id AND p.application_id=a.application_id
   AND p.application_generation=app.generation AND p.registration_revision=app.revision
   AND p.payload->'proactive'->'harness'=a.context->'harness')<>1 THEN RAISE EXCEPTION 'agent_proactive_profile_current';END IF;
 SELECT * INTO lane FROM os_agent_tool_profiles p WHERE p.installation_id=a.installation_id AND p.application_id=a.application_id
  AND p.application_generation=app.generation AND p.registration_revision=app.revision
  AND p.payload->'proactive'->'harness'=a.context->'harness';
 IF NOT COALESCE(lane.digest=os_agent_profile_digest('policy',lane.payload)
  AND lane.policy_digest=os_agent_profile_digest('manifest',lane.payload->'execution')
  AND lane.payload->'execution'->'proactiveProfile'=os_agent_profile_pin(lane.payload->'proactive','manifest')
  AND os_agent_proactive_profile_valid(lane.payload->'proactive',app.installation_id,app.id,app.generation,app.revision),false)
 THEN RAISE EXCEPTION 'agent_proactive_profile_binding';END IF;
 RETURN lane.payload->'proactive'->'planning';
END $$;

CREATE FUNCTION os_assert_agent_proactive_link(v os_proactive_revisions, phase text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE o os_agent_tool_operations%ROWTYPE; a os_admissions%ROWTYPE; t os_tasks%ROWTYPE;
 c os_agent_tool_calls%ROWTYPE; w os_work_attempts%ROWTYPE; profile jsonb;
BEGIN
 IF v.agent_operation_id IS NULL THEN RETURN;END IF;
 IF phase NOT IN ('draft','accept','activate') THEN RAISE EXCEPTION 'agent_proactive_link_phase';END IF;
 SELECT * INTO o FROM os_agent_tool_operations WHERE id=v.agent_operation_id;
 PERFORM os_assert_agent_tool_current(o);
 SELECT d.* INTO a FROM os_admissions d JOIN os_budget_roots r ON r.admission_id=d.id WHERE r.id=o.root_id;
 SELECT * INTO t FROM os_tasks WHERE id=o.task_id;
 profile=os_agent_proactive_profile(a);
 SELECT * INTO c FROM os_agent_tool_calls WHERE operation_id=o.id ORDER BY ordinal DESC LIMIT 1;
 SELECT * INTO w FROM os_work_attempts WHERE id=c.attempt_id;
 IF NOT COALESCE(ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND v.revision=1 AND v.session_id=(a.authority->>'sessionId')::uuid AND v.configuration_digest=os_agent_profile_digest('definition',v.configuration)
  AND v.configuration->>'workflowRef'='registered-read/1'
  AND profile->'kinds' @> jsonb_build_array((SELECT kind FROM os_proactive_definitions WHERE id=v.definition_id))
  AND o.payload->'capability'=profile->'capability' AND w.kind='agent.schedule' AND w.root_id=o.root_id AND w.task_id=o.task_id
  AND EXISTS(SELECT 1 FROM os_agent_tool_starts WHERE id=c.id)
  AND (phase<>'draft' OR (w.state='RUNNING' AND w.lease_until>clock_timestamp() AND t.state IN ('ACCEPTED','PLANNING','VALIDATING','RUNNING')))
  AND (phase='draft' OR (w.state='SETTLED' AND w.actual IS NOT NULL))
  AND EXISTS(SELECT 1 FROM os_agent_payload_writes p JOIN os_agent_private_payloads f ON f.write_id=p.id
   JOIN os_work_attempts storage ON storage.id=p.attempt_id JOIN os_artifacts artifact ON artifact.id=f.id
   WHERE p.id=os_query_source_uuid5(o.task_id,'proactive-goal/1') AND p.root_id=o.root_id AND p.task_id=o.task_id
    AND p.schema_ref='AgentProactiveGoalRecord' AND p.schema_version=1 AND storage.state='SETTLED'
    AND p.expires_at>clock_timestamp() AND artifact.expires_at>clock_timestamp()),false)
 THEN RAISE EXCEPTION 'agent_proactive_original_operation';END IF;
 IF phase='activate' AND NOT COALESCE(t.state='WAITING_APPROVAL'
  AND NOT EXISTS(SELECT 1 FROM os_budget_roots root,LATERAL jsonb_each_text(root.outstanding) held
   WHERE root.id=o.root_id AND held.value::numeric<>0)
  AND EXISTS(SELECT 1 FROM os_agent_tool_acceptances accepted WHERE accepted.call_id=c.id)
  AND EXISTS(SELECT 1 FROM os_agent_payload_writes p JOIN os_agent_private_payloads f ON f.write_id=p.id
   JOIN os_work_attempts storage ON storage.id=p.attempt_id JOIN os_artifacts artifact ON artifact.id=f.id
   WHERE p.id=os_query_source_uuid5(o.task_id,'proactive-review/1') AND p.root_id=o.root_id AND p.task_id=o.task_id
    AND p.schema_ref='AgentProactiveReviewRecord' AND p.schema_version=1 AND storage.state='SETTLED'
    AND p.expires_at>clock_timestamp() AND artifact.expires_at>clock_timestamp()),false)
 THEN RAISE EXCEPTION 'agent_proactive_exact_review_required';END IF;
END $$;
"""

GUARDS=r"""
CREATE OR REPLACE FUNCTION os_assert_agent_tool_current(o os_agent_tool_operations) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; app os_applications%ROWTYPE; parent os_agent_operations%ROWTYPE;
 accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; w os_agent_payload_writes%ROWTYPE; cap os_agent_capabilities%ROWTYPE;
 c jsonb; i jsonb; dep jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM os_assert_agent_memory_context(o.payload->'context',true);
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=o.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (o.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=o.root_id)) ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=o.root_id FOR UPDATE;SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=o.installation_id AND id=o.application_id;
 c:=o.payload->'context';i:=o.payload->'identity';dep:=o.payload->'modelResult';
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO parent FROM os_agent_operations WHERE id=o.parent_operation_id;
 SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=o.source_acceptance_id;
 SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
 SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=o.binding_id;
 SELECT * INTO w FROM os_agent_payload_writes WHERE id=f.write_id;
 SELECT * INTO cap FROM os_agent_capabilities WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND application_generation=app.generation AND capability_ref=o.payload->'capability'->>'ref' ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND r.accounting_format='agent-resources/1'
 AND ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
 AND os_agent_context_matches(a,c) AND o.task_id=r.root_task_id AND o.digest=os_agent_profile_digest('command',o.payload)
 AND o.payload=jsonb_build_object('context',c,'identity',i,'binding',o.payload->'binding','modelOperationId',o.parent_operation_id,
  'modelResult',dep,'capability',o.payload->'capability','profile',o.payload->'profile')
 AND i=jsonb_build_object('operationId',o.id,'taskId',o.task_id,'rootId',o.root_id,'segmentId',a.segment_id,
  'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','planRevision',parent.payload->'identity'->'planRevision',
  'parentOperationId',o.parent_operation_id,'iteration',parent.payload->'identity'->'iteration','kind','tool','inputDigest',i->'inputDigest')
 AND i->>'inputDigest' ~ '^[a-f0-9]{64}$' AND parent.root_id=o.root_id AND parent.payload->'context'=c
 AND producer.root_id=o.root_id AND producer.request->'context'=c AND producer.expires_at>clock_timestamp()
 AND EXISTS(SELECT 1 FROM os_agent_operation_models link WHERE link.operation_id=parent.id AND link.id=producer.id)
 AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
   'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
   'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
   'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
 AND (dep->>'acceptedAt')::timestamptz=accepted.created_at
 AND ROW(producer.installation_id,producer.application_id,producer.tenant_id,producer.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND (w.model_context=c OR w.model_context IS NULL AND c=a.context AND c->'harness'->>'ref' NOT LIKE 'private-planned-read/%')
 AND w.task_id=o.task_id AND w.root_id=o.root_id AND w.schema_ref='AgentSDKToolBinding' AND w.schema_version=1 AND w.expires_at>clock_timestamp()
 AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND o.payload->'binding'=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',w.plain_bytes,'schemaRef',w.schema_ref,'schemaVersion',w.schema_version)
 AND p.application_generation=app.generation AND p.registration_revision=app.revision AND p.digest=os_agent_profile_digest('policy',p.payload)
 AND o.payload->'profile'=jsonb_build_object('ref',p.payload->'execution'->'id','revision',p.payload->'execution'->'revision','digest',p.policy_digest)
 AND ((p.payload->'read'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='mcp.read/1')
 OR (p.payload->'preparation'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='propose'
  AND cap.payload->>'adapterRef'='typed.prepare/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'memory'->'capability'=o.payload->'capability' AND p.payload->'memory'->'harness'=c->'harness'
  AND p.payload->'memory'->>'installationId'=o.installation_id::text
  AND p.payload->'memory'->>'applicationId'=o.application_id::text AND cap.payload->>'kind'='memory'
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)
  AND cap.payload->>'adapterRef'='owner.memory.read/1' AND cap.payload->>'scopePolicyRef'='owner-approved-memory/1'
  AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'knowledge'->'capability'=o.payload->'capability' AND p.payload->'knowledge'->'harness'=c->'harness'
  AND c<>a.context AND p.payload->'knowledge'->'planning'=os_agent_planning_profile(a)
  AND p.payload->'knowledge'->>'installationId'=o.installation_id::text
  AND p.payload->'knowledge'->>'applicationId'=o.application_id::text
  AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='private.knowledge.read/1'
  AND cap.payload->>'scopePolicyRef'='private-reviewed-knowledge/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'proactive'->'capability'=o.payload->'capability' AND p.payload->'proactive'->'harness'=c->'harness'
  AND c=a.context AND p.payload->'proactive'->'planning'=os_agent_proactive_profile(a)
  AND cap.payload->>'kind'='schedule' AND cap.payload->>'adapterRef'='os.proactivity.prepare/1'
  AND cap.payload->>'scopePolicyRef'='owner-reviewed-proactivity/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)))
 AND os_agent_capability_matches(a,c,o.payload->'capability')
 AND cap.payload->>'lifecycle'='qualified' AND cap.payload->>'purpose'=c->>'purpose'
 AND o.payload->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
 AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=o.task_id
  AND k.state='ACTIVE' AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp()
  AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
 AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.task_id=o.task_id AND s.state='OPEN'),false)
 THEN RAISE EXCEPTION 'agent_tool_operation_binding'; END IF;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_resource_group() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_group_accounts%ROWTYPE; original os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE;
 d os_admissions%ROWTYPE; c jsonb; member jsonb; required jsonb; w os_work_attempts%ROWTYPE; expected_kind text; expected_count integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_group_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_agent_group_accounts WHERE id=NEW.group_account_id;
 SELECT * INTO original FROM os_agent_resource_accounts WHERE id=a.account_id;
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state') THEN RAISE EXCEPTION 'agent_group_transition'; END IF;
  IF NEW.state='ADMITTED' THEN
   PERFORM os_agent_resource_owner(original);
   w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
   w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
   PERFORM os_assert_agent_work_current(w);
   IF EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
    THEN RAISE EXCEPTION 'agent_group_fifo'; END IF;
  END IF;
  RETURN NEW;
 END IF;
 PERFORM os_agent_resource_owner(original);
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 c=NEW.request->'context';required=os_agent_group_required(NEW.request->'members');
 expected_kind=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 'agent.model' WHEN 'tool-reservation/1' THEN CASE WHEN c->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END WHEN 'compute-reservation/1' THEN 'agent.compute' WHEN 'effect-reservation/1' THEN 'agent.effect' WHEN 'native-reservation/1' THEN 'agent.native' WHEN 'memory-reservation/1' THEN 'agent.memory' ELSE 'agent.storage' END;
 expected_count=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 3 WHEN 'tool-reservation/1' THEN 2 WHEN 'memory-reservation/1' THEN 2 ELSE 1 END;
 IF a.id IS NULL OR a.root_id<>r.id OR NEW.group_account_id<>a.id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline OR NOT COALESCE(os_agent_context_matches(d,c),false)
  OR NEW.request IS DISTINCT FROM jsonb_build_object('context',c,'groupId',NEW.id::text,'profile',NEW.profile_ref,'sourceId',NEW.source_id::text,'members',NEW.request->'members')
  OR c->>'rootId'<>NEW.root_id::text OR c->>'taskId'<>NEW.task_id::text OR c->>'segmentId'<>NEW.segment_id::text
  OR (c->>'controlEpoch')::bigint<>NEW.control_epoch
  OR NEW.request_digest<>os_agent_profile_digest('command',NEW.request||jsonb_build_object('schema','agent-resource-group/1'))
  OR jsonb_array_length(NEW.request->'members')<>expected_count
  OR NEW.request->'members'->0->>'kind'<>expected_kind OR NEW.request->'members'->0->>'invocationId'<>NEW.source_id::text
  OR (SELECT count(DISTINCT value->>'invocationId') FROM jsonb_array_elements(NEW.request->'members'))<>expected_count
  THEN RAISE EXCEPTION 'agent_group_binding'; END IF;
 FOR member IN SELECT value FROM jsonb_array_elements(NEW.request->'members') LOOP
  IF member IS DISTINCT FROM jsonb_build_object('taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,'controlEpoch',NEW.control_epoch,
    'invocationId',member->'invocationId','kind',member->'kind','inputDigest',member->'inputDigest','units',member->'units','timeoutMs',member->'timeoutMs')
   OR jsonb_typeof(member->'invocationId') IS DISTINCT FROM 'string' OR (member->>'invocationId') !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   OR jsonb_typeof(member->'inputDigest') IS DISTINCT FROM 'string' OR (member->>'inputDigest') !~ '^[a-f0-9]{64}$'
   OR member->>'kind' NOT IN ('agent.model','agent.tool','agent.storage','agent.compute','agent.effect','agent.native','agent.memory','agent.schedule')
   OR jsonb_typeof(member->'kind') IS DISTINCT FROM 'string'
   OR jsonb_typeof(member->'timeoutMs') IS DISTINCT FROM 'number' OR (member->>'timeoutMs') !~ '^[1-9][0-9]*$'
   OR (member->>'timeoutMs')::numeric>(original.policy->>'requestTimeoutMs')::numeric
   OR (member->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
   OR (member->'units'->>'workMs')::numeric<1 THEN RAISE EXCEPTION 'agent_group_member_request'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.request->'members') WITH ORDINALITY AS m(value,ordinal) WHERE ordinal>1 AND value->>'kind'<>'agent.storage')
  THEN RAISE EXCEPTION 'agent_group_member_kind'; END IF;
 IF expected_kind='agent.schedule' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id
   AND tool.payload->'context'=c AND tool.payload->'capability'=os_agent_proactive_profile(d)->'capability'
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_proactive_group_source';END IF;
 IF NEW.profile_ref='memory-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND (p.payload ? 'memory' OR p.payload ? 'knowledge')
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_memory_group_source';END IF;
 IF NEW.profile_ref='native-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_native_operations native WHERE native.root_id=NEW.root_id AND native.task_id=NEW.task_id
   AND native.payload->'context'=c AND os_query_source_uuid5(native.id,'tool-attempt/1')=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_native_group_source'; END IF;
 IF NEW.profile_ref='effect-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
   JOIN os_tasks task ON task.id=review.task_id
  WHERE decision.id=NEW.source_id AND review.root_id=NEW.root_id AND review.task_id=NEW.task_id
   AND review.payload->'context'=c AND decision.payload->'command'->>'decision'='approve'
   AND decision.expires_at>clock_timestamp() AND task.state='RUNNING'
   AND (NEW.request->'members'->0->>'inputDigest')=(os_agent_reviewed_grant(decision.id)->>'grantDigest'))
 THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));PERFORM os_assert_agent_work_current(w);
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_check_agent_group_complete() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE gid uuid; g os_agent_resource_groups%ROWTYPE; expected_count integer; actual uuid[]; claimed uuid[];
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_agent_resource_groups' THEN gid=NEW.id;
 ELSIF TG_TABLE_NAME='os_agent_group_members' THEN gid=NEW.group_id;
 ELSE SELECT group_id INTO gid FROM os_agent_group_members WHERE id=NEW.member_id; END IF;
 SELECT * INTO g FROM os_agent_resource_groups WHERE id=gid;
 IF g.id IS NULL THEN RAISE EXCEPTION 'agent_group_missing'; END IF;
 expected_count=jsonb_array_length(g.request->'members');
 SELECT array_agg(c.attempt_id ORDER BY c.attempt_id) INTO claimed FROM os_agent_group_claims c JOIN os_agent_group_members m ON m.id=c.member_id WHERE m.group_id=gid;
 IF g.state<>'ADMITTED' THEN
  IF EXISTS(SELECT 1 FROM os_agent_group_members WHERE group_id=gid) THEN RAISE EXCEPTION 'agent_group_unadmitted_work'; END IF;
  RETURN NEW;
 END IF;
 IF (SELECT count(*) FROM os_agent_group_members WHERE group_id=gid)<>expected_count OR cardinality(claimed) IS DISTINCT FROM expected_count
  THEN RAISE EXCEPTION 'agent_group_incomplete'; END IF;
 IF g.profile_ref='model-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_model_calls WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND request->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_model_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_model_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_model_slots WHERE call_id=g.source_id) s;
 ELSIF g.profile_ref IN ('tool-reservation/1','memory-reservation/1') THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
    WHERE c.id=g.source_id AND c.root_id=g.root_id AND o.task_id=g.task_id AND o.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_tool_source'; END IF;
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_work_attempts w ON w.id=c.attempt_id
   WHERE c.id=g.source_id AND w.kind=CASE WHEN g.profile_ref='memory-reservation/1' THEN 'agent.memory'
    WHEN g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END)
   OR (g.profile_ref='tool-reservation/1' AND g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%'
    AND NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
     JOIN os_budget_roots r ON r.id=o.root_id JOIN os_admissions a ON a.id=r.admission_id
     JOIN os_agent_tool_profiles p ON p.installation_id=o.installation_id AND p.application_id=o.application_id
      AND p.policy_digest=o.payload->'profile'->>'digest'
     WHERE c.id=g.source_id AND p.payload ? 'proactive'
      AND p.payload->'proactive'->'capability'=o.payload->'capability'
      AND o.payload->'capability'=os_agent_proactive_profile(a)->'capability'))
  THEN RAISE EXCEPTION 'agent_group_tool_lane';END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_tool_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_tool_slots WHERE id=g.source_id) s;
 ELSIF g.profile_ref='effect-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
    WHERE decision.id=g.source_id AND review.root_id=g.root_id AND review.task_id=g.task_id
     AND review.payload->'context'=g.request->'context' AND decision.payload->'command'->>'decision'='approve')
   THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.effect';
 ELSIF g.profile_ref='native-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_native_calls call JOIN os_agent_native_operations native ON native.id=call.operation_id
   WHERE call.id=g.source_id AND call.root_id=g.root_id AND native.task_id=g.task_id AND native.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_native_source'; END IF;
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_native_calls WHERE id=g.source_id;
 ELSIF g.profile_ref='compute-reservation/1' THEN
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.compute';
 ELSE
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_payload_writes
   WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND segment_id=g.segment_id AND control_epoch=g.control_epoch;
 END IF;
 IF actual IS DISTINCT FROM claimed THEN RAISE EXCEPTION 'agent_group_source_members'; END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_tool_call() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE o os_agent_tool_operations%ROWTYPE; w os_work_attempts%ROWTYPE; p os_agent_tool_profiles%ROWTYPE;
 prior os_agent_tool_calls%ROWTYPE; previous os_work_attempts%ROWTYPE; c jsonb; a jsonb; units jsonb; expected_kind text;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_call_immutable'; END IF;
 SELECT * INTO o FROM os_agent_tool_operations WHERE id=NEW.operation_id;PERFORM os_assert_agent_tool_current(o);
 SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;PERFORM os_assert_agent_work_current(w);
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO prior FROM os_agent_tool_calls WHERE operation_id=NEW.operation_id ORDER BY ordinal DESC LIMIT 1;
 expected_kind=CASE WHEN p.payload ? 'proactive' THEN 'agent.schedule' WHEN (p.payload ? 'memory' OR p.payload ? 'knowledge') THEN 'agent.memory' ELSE 'agent.tool' END;
 c:=o.payload->'context';a:=NEW.request->'attempt';units:=jsonb_build_object('tokens',0,'costMicros',0,'workMs',w.reserved->'workMs','computeMs',0,'storageBytes',0);
 IF NOT COALESCE(w.state='RESERVED' AND w.kind=expected_kind AND w.root_id=NEW.root_id AND o.root_id=NEW.root_id AND w.invocation_id=NEW.id
 AND ROW(w.installation_id,w.application_id,w.tenant_id,w.subject_id)=ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
 AND w.task_id=o.task_id AND w.segment_id=(c->>'segmentId')::uuid AND w.control_epoch=(c->>'controlEpoch')::bigint
 AND NEW.profile_digest=p.digest AND NEW.request_digest=os_agent_profile_digest('command',NEW.request)
 AND NEW.request=jsonb_build_object('record',o.payload,'callId',NEW.id,'attemptNumber',NEW.ordinal,'attempt',a,'reserved',units)
 AND w.reserved=units AND units->'workMs'=(SELECT policy->'requestTimeoutMs' FROM os_agent_resource_accounts WHERE root_id=o.root_id)
 AND (p.payload->'execution'->>'requestTimeoutMs')::bigint<(units->>'workMs')::bigint AND NEW.ordinal=COALESCE(prior.ordinal,0)+1
 AND a=jsonb_build_object('subject',c->'subject','id',w.id,'taskId',w.task_id,'segmentId',w.segment_id,'rootId',w.root_id,
  'controlEpoch',w.control_epoch,'leaseToken',w.lease_token,'leaseUntil',a->'leaseUntil','state','RESERVED')
 AND (a->>'leaseUntil')::timestamptz=w.lease_until
 AND w.request_digest=os_agent_profile_digest('command',jsonb_build_object('schema','agent-resource-reservation/1','taskId',w.task_id,
  'segmentId',w.segment_id,'epoch',w.control_epoch,'invocationId',NEW.id,'kind',expected_kind,'inputDigest',o.digest,'units',units,'timeoutMs',units->'workMs'))
 AND NEW.created_at<=clock_timestamp() AND NEW.expires_at=(SELECT expires_at FROM os_agent_payload_writes WHERE artifact_id=o.binding_id),false)
 THEN RAISE EXCEPTION 'agent_tool_call_binding'; END IF;
 IF prior.id IS NOT NULL THEN
  SELECT * INTO previous FROM os_work_attempts WHERE id=prior.attempt_id;
  IF NOT COALESCE(previous.state='RELEASED' AND previous.lease_until<=clock_timestamp()
   AND NOT EXISTS(SELECT 1 FROM os_agent_tool_starts WHERE id=prior.id)
   AND NOT EXISTS(SELECT 1 FROM os_agent_tool_finishes WHERE id=prior.id),false)
  THEN RAISE EXCEPTION 'agent_tool_retry_not_admitted'; END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_assert_agent_input_dependency(dep jsonb, c jsonb, root uuid, before_at timestamp with time zone) RETURNS void LANGUAGE plpgsql AS $$
DECLARE accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 tool_accepted os_agent_tool_acceptances%ROWTYPE; tool os_agent_tool_calls%ROWTYPE; tool_archive os_agent_tool_archives%ROWTYPE;
 page os_agent_input_result_sets%ROWTYPE; artifact os_artifacts%ROWTYPE; expected_schema text;
BEGIN

 IF dep->'payload'->>'schemaRef'='AgentNativeAnalysisResult' THEN
  PERFORM os_assert_agent_native_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 IF dep->'payload'->>'schemaRef'='AgentQueryFactSet' THEN
  PERFORM os_assert_agent_query_fact_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 IF dep->'payload'->>'schemaRef'='AgentOwnerReply' THEN
  PERFORM os_assert_agent_owner_reply_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF dep->'payload'->>'schemaRef'='AgentProviderResponse' THEN
  SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=(dep->>'resultId')::uuid;
  SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
  SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
  IF NOT COALESCE(producer.root_id=root AND os_agent_source_context(c,producer.request->'context') AND producer.request->'context'->'subject'=c->'subject'
   AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
    'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
     'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
    'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
   AND (dep->>'acceptedAt')::timestamptz=accepted.created_at AND accepted.created_at<=before_at AND producer.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSIF dep->'payload'->>'schemaRef' IN ('EvidencePage','AgentQueryPage','AgentMemoryPage','AgentPrivateKnowledgePage','AgentProactivePreparation') THEN
  SELECT * INTO tool_accepted FROM os_agent_tool_acceptances WHERE id=(dep->>'resultId')::uuid;
  SELECT * INTO tool FROM os_agent_tool_calls WHERE id=tool_accepted.call_id;
  SELECT * INTO tool_archive FROM os_agent_tool_archives WHERE id=tool_accepted.artifact_id;
  SELECT CASE WHEN p.payload ? 'proactive' THEN 'AgentProactivePreparation' WHEN p.payload ? 'knowledge' THEN 'AgentPrivateKnowledgePage' WHEN p.payload ? 'memory' THEN 'AgentMemoryPage' ELSE CASE p.payload->'read'->>'outputContract' WHEN 'EvidencePage/1' THEN 'EvidencePage' WHEN 'AgentQueryPage/1' THEN 'AgentQueryPage' END END INTO expected_schema
   FROM os_agent_tool_profiles p WHERE p.installation_id=tool.installation_id AND p.application_id=tool.application_id
    AND p.policy_digest=tool.request->'record'->'profile'->>'digest';
  IF expected_schema='AgentPrivateKnowledgePage' THEN
   PERFORM os_assert_agent_memory_context(tool.request->'record'->'context',true);
   IF tool_accepted.knowledge_source->'result' IS DISTINCT FROM dep THEN RAISE EXCEPTION 'agent_knowledge_dependency_receipt';END IF;
  END IF;
  IF expected_schema='AgentMemoryPage' THEN
   PERFORM os_assert_agent_memory_context(tool.request->'record'->'context',true);
   IF tool_accepted.memory_source->'result' IS DISTINCT FROM dep THEN RAISE EXCEPTION 'agent_memory_dependency_receipt';END IF;
  END IF;
  IF NOT COALESCE(expected_schema=dep->'payload'->>'schemaRef' AND tool.root_id=root AND os_agent_source_context(c,tool.request->'record'->'context') AND tool.request->'record'->'context'->'subject'=c->'subject'
   AND dep=jsonb_build_object('subject',c->'subject','taskId',tool.request->'record'->'context'->'taskId','rootId',tool.root_id,
    'resultId',tool_accepted.id,'producerStepId',tool.id,'acceptedAttemptId',tool.attempt_id,
    'payload',jsonb_build_object('artifactRef','artifact/'||tool_archive.id,'ciphertextDigest',tool_archive.ciphertext_digest,
     'bytes',tool_archive.plain_bytes,'schemaRef',expected_schema,'schemaVersion',1),
    'lineageRef',null,'scopeRef',tool.request->'record'->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
   AND (dep->>'acceptedAt')::timestamptz=tool_accepted.created_at AND tool_accepted.created_at<=before_at AND tool.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSIF dep->'payload'->>'schemaRef'='AgentInputResultSet' THEN
  SELECT * INTO page FROM os_agent_input_result_sets WHERE id=(dep->>'producerStepId')::uuid;
  SELECT * INTO artifact FROM os_artifacts WHERE id=page.artifact_id;
  IF NOT COALESCE(page.root_id=root AND os_agent_source_context(c,page.record->'context') AND page.reference=dep
   AND page.created_at<=before_at AND artifact.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSE RAISE EXCEPTION 'agent_operation_dependency';
 END IF;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_tool_acceptance() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE c os_agent_tool_calls%ROWTYPE; o os_agent_tool_operations%ROWTYPE; w os_work_attempts%ROWTYPE; storage os_work_attempts%ROWTYPE; archive os_agent_tool_archives%ROWTYPE; revision os_proactive_revisions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_acceptance_immutable'; END IF;
 SELECT * INTO c FROM os_agent_tool_calls WHERE id=NEW.call_id;SELECT * INTO o FROM os_agent_tool_operations WHERE id=c.operation_id;PERFORM os_assert_agent_tool_current(o);
 SELECT * INTO w FROM os_work_attempts WHERE id=c.attempt_id;SELECT * INTO archive FROM os_agent_tool_archives WHERE id=NEW.artifact_id;
 SELECT x.* INTO storage FROM os_work_attempts x JOIN os_agent_tool_slots s ON x.id=s.attempt_id WHERE s.id=c.id;
 IF NOT COALESCE(w.state='SETTLED' AND storage.state='SETTLED' AND archive.slot_id=c.id AND c.expires_at>clock_timestamp()
 AND (SELECT kind FROM os_agent_tool_finishes WHERE id=c.id)='candidate'
 AND ROW(w.installation_id,w.application_id,w.tenant_id,w.subject_id)=ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
 AND NEW.created_at>=archive.created_at AND NEW.created_at<=clock_timestamp(),false)
 THEN RAISE EXCEPTION 'agent_tool_acceptance_binding'; END IF;
 IF EXISTS(SELECT 1 FROM os_agent_tool_profiles p WHERE p.installation_id=c.installation_id
  AND p.application_id=c.application_id AND p.digest=c.profile_digest AND p.payload ? 'knowledge') THEN
  PERFORM os_assert_agent_knowledge_receipt(NEW,c,o);
 ELSIF NEW.knowledge_source IS NOT NULL THEN RAISE EXCEPTION 'agent_nonknowledge_source_receipt';END IF;
 IF EXISTS(SELECT 1 FROM os_agent_tool_profiles p WHERE p.installation_id=c.installation_id
  AND p.application_id=c.application_id AND p.digest=c.profile_digest AND p.payload ? 'memory') THEN
  PERFORM os_assert_agent_memory_receipt(NEW,c,o);
 ELSIF NEW.memory_source IS NOT NULL THEN RAISE EXCEPTION 'agent_nonmemory_source_receipt';END IF;
 IF EXISTS(SELECT 1 FROM os_agent_tool_profiles p WHERE p.installation_id=c.installation_id
  AND p.application_id=c.application_id AND p.digest=c.profile_digest AND p.payload ? 'proactive') THEN
  SELECT * INTO revision FROM os_proactive_revisions WHERE agent_operation_id=o.id;
  IF revision.id IS NULL THEN RAISE EXCEPTION 'agent_proactive_missing_draft';END IF;
  PERFORM os_assert_agent_proactive_link(revision,'accept');
  IF NOT EXISTS(SELECT 1 FROM os_proactive_commands command WHERE command.definition_id=revision.definition_id
   AND command.command_id=os_query_source_uuid5(o.id,'proactive-draft/1') AND command.kind='draft'
   AND command.expected_version=0 AND command.accepted_version=1
   AND command.receipt->'definition'->'configuration'=revision.configuration
   AND command.receipt->'definition'->>'configurationDigest'=revision.configuration_digest)
  THEN RAISE EXCEPTION 'agent_proactive_missing_receipt';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_tool_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_applications%ROWTYPE; p jsonb; r jsonb; e jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_profile_immutable'; END IF;
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 p:=NEW.payload;r:=p->'read';e:=p->'execution';


 IF p ? 'proactive' THEN
  r=p->'proactive';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('proactive',r,'execution',e)
   AND os_agent_proactive_profile_valid(r,NEW.installation_id,NEW.application_id,NEW.application_generation,NEW.registration_revision)
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','proactiveProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','proactive-preparation-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_proactive_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'knowledge' THEN
  r=p->'knowledge';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('knowledge',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability','harness',r->'harness',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'providerRef',r->'providerRef',
    'planning',r->'planning','outputContract','AgentPrivateKnowledgePage/1','adapterRef','private.knowledge.read/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'harness'->>'ref' LIKE 'private-planned-read/%'
   AND r->'planning'->'knowledgeCapability'=r->'capability'
   AND os_agent_private_planning_valid(r->'planning',NEW.installation_id,NEW.application_id,NEW.application_generation,NEW.registration_revision,r->'harness')
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'capabilities'->'allowedKinds' @> '["memory"]'::jsonb)
   AND EXISTS(SELECT 1 FROM os_agent_capabilities cap WHERE cap.installation_id=NEW.installation_id
    AND cap.application_id=NEW.application_id AND cap.application_generation=NEW.application_generation
    AND r->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
    AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='private.knowledge.read/1'
    AND cap.payload->>'scopePolicyRef'='private-reviewed-knowledge/1' AND cap.payload->'mcp'='null'::jsonb
    AND cap.payload->>'lifecycle'='qualified')
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','knowledgeProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','private-knowledge-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_knowledge_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'memory' THEN
  r=p->'memory';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('memory',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability','harness',r->'harness',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'providerRef',r->'providerRef',
    'outputContract','AgentMemoryPage/1','adapterRef','owner.memory.read/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'harness'->>'ref' LIKE 'memory-assisted-read/%'
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'capabilities'->'allowedKinds' @> '["memory"]'::jsonb)
   AND EXISTS(SELECT 1 FROM os_agent_capabilities cap WHERE cap.installation_id=NEW.installation_id
    AND cap.application_id=NEW.application_id AND cap.application_generation=NEW.application_generation
    AND r->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
    AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='owner.memory.read/1'
    AND cap.payload->>'scopePolicyRef'='owner-approved-memory/1' AND cap.payload->'mcp'='null'::jsonb
    AND cap.payload->>'lifecycle'='qualified')
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','memoryProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','owner-memory-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_memory_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'native' THEN
  r:=p->'native';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('native',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'harness',r->'harness','runtime',r->'runtime','verifier',r->'verifier','placement',r->'placement','limits',r->'limits','meter',r->'meter','adapterRef','native.offline-analysis/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$'
   AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'harness'->'features' @> '["native-execution"]'::jsonb)
   AND jsonb_typeof(r->'capability'->'revision')='number' AND r->'capability'->>'revision' ~ '^[1-9][0-9]*$'
   AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->'runtime'=jsonb_build_object('ref',r->'runtime'->'ref','revision',r->'runtime'->'revision','digest',r->'runtime'->'digest')
   AND r->'runtime'->>'ref'='python-offline-analysis/1' AND r->'runtime'->'revision'='1'::jsonb
   AND r->'runtime'->>'digest' ~ '^[a-f0-9]{64}$'
   AND r->'verifier'=jsonb_build_object('ref','native-source-values/1','revision',1,'digest',r->'verifier'->'digest')
   AND r->'verifier'->>'digest' ~ '^[a-f0-9]{64}$'
   AND r->'placement'=jsonb_build_object('providerDigest',r->'placement'->'providerDigest','runtimeDigest',r->'placement'->'runtimeDigest')
   AND r->'placement'->>'providerDigest' ~ '^[a-f0-9]{64}$' AND r->'placement'->>'runtimeDigest' ~ '^[a-f0-9]{64}$'
   AND os_native_analysis_limits(r->'limits') AND os_native_analysis_meter(r->'meter',(r->'limits'->>'timeoutMs')::bigint)
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'nativeProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','native-one-vcpu-allocation/1','externalInference',false)
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(e->'revision')='number' AND e->>'revision' ~ '^[1-9][0-9]*$'
   AND (e->>'revision')::numeric<=9007199254740991 AND NEW.created_at<=clock_timestamp(),false)
   THEN RAISE EXCEPTION 'agent_native_profile_binding'; END IF;
  RETURN NEW;
 END IF;
 IF p ? 'preparation' THEN
  r:=p->'preparation';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('preparation',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'hostDefinitionRef',r->'hostDefinitionRef',
    'providerRef',r->'providerRef','outputContract','AgentPreparedChange/1','adapterRef','typed.prepare/1')
   AND jsonb_typeof(r->'id')='string' AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (r->>'revision') ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND (r->'capability'->>'revision') ~ '^[1-9][0-9]*$' AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->>'hostDefinitionRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'preparationProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','host-preparation-elapsed/1','externalInference',false,
    'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (e->>'revision') ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND (e->>'requestTimeoutMs') ~ '^[1-9][0-9]*$' AND (e->>'requestTimeoutMs')::numeric BETWEEN 25000 AND 900000
   AND (e->>'maxResultBytes') ~ '^[1-9][0-9]*$' AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576
   AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_preparation_profile_binding'; END IF;
  RETURN NEW;
 END IF;

 IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
 AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
 AND p-ARRAY['read','execution']='{}'::jsonb AND p ?& ARRAY['read','execution']
 AND e=jsonb_build_object('id',e->'id','revision',e->'revision','readProfile',jsonb_build_object('ref',r->'id','revision',r->'revision',
   'digest',os_agent_profile_digest('manifest',r)),'usageProfile','host-read-elapsed/1','externalInference',false,
   'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
 AND (e->>'requestTimeoutMs')::bigint BETWEEN 1 AND 900000 AND (e->>'maxResultBytes')::bigint BETWEEN 1024 AND 1048576
 AND (e->>'revision')::bigint BETWEEN 1 AND 9007199254740991 AND (r->>'outputContract'='EvidencePage/1' OR (
 r->>'outputContract'='AgentQueryPage/1'
 AND r-ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']='{}'::jsonb
 AND r ?& ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']
 AND jsonb_typeof(r->'cursorField')='string' AND r->>'cursorField' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
 AND jsonb_typeof(r->'grain')='array' AND jsonb_array_length(r->'grain') BETWEEN 1 AND 64
 AND jsonb_typeof(r->'pageGroupFields')='array' AND jsonb_array_length(r->'pageGroupFields') BETWEEN 0 AND 64
 AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements((r->'grain')||(r->'pageGroupFields')) v
  WHERE jsonb_typeof(v)<>'string' OR (v#>>'{}') !~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$')
 AND jsonb_array_length(r->'grain')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'grain') v)
 AND jsonb_array_length(r->'pageGroupFields')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'pageGroupFields') v)
 ))
 AND r->'host'->>'installationId'=NEW.installation_id::text AND r->'host'->>'applicationId'=NEW.application_id::text
 AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_tool_profile_binding'; END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_proactive_revision_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_proactive_definitions%ROWTYPE;c jsonb;l jsonb;
BEGIN
 PERFORM os_proactive_session(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
 PERFORM os_assert_agent_proactive_link(NEW,'draft');
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id FOR UPDATE;c=NEW.configuration;l=c->'limits';
 IF (NEW.application_generation,NEW.subject_generation,NEW.policy_generation,NEW.registration_revision)
  IS DISTINCT FROM (d.application_generation,d.subject_generation,d.policy_generation,d.registration_revision)
 THEN RAISE EXCEPTION 'proactive_original_revision_generations';END IF;
 IF COALESCE((d.state<>'awaiting-review' OR d.configuration_revision<>NEW.revision OR NEW.created_at>clock_timestamp()+interval '5 seconds'
  OR (c->>'validUntil')::timestamptz<=clock_timestamp() OR (c->>'validUntil')::timestamptz>NEW.created_at+interval '7 days'
  OR (c->>'workflowRevision')::bigint<>1 OR c->>'workflowRef' NOT IN ('registered-read/1','registered-staging/1','verified-wasm/1')
  OR (d.kind='schedule') IS DISTINCT FROM (c->'calendar'<>'null'::jsonb) OR (c->'calendar'='null'::jsonb)=(c->'event'='null'::jsonb)
  OR jsonb_array_length(c->'arguments'->'externalIds')<1 OR jsonb_array_length(c->'arguments'->'fieldNames')<1
  OR (l->>'taskDeadlineMs')::bigint>LEAST((l->>'rootWorkMs')::bigint,(l->>'dailyWorkMs')::bigint)
  OR (l->>'rootTaskLimit')::bigint>(l->>'dailyTaskLimit')::bigint OR (l->>'rootToolCallLimit')::bigint>(l->>'dailyToolCallLimit')::bigint
  OR (c->'calendar'<>'null'::jsonb AND (c->'calendar'->>'tzdataRef'<>'tzdata/2026.5' OR c->'calendar'->>'overlap'<>'SKIP'
   OR (c->'calendar'->'intervalSeconds'<>'null'::jsonb AND (c->'calendar'->>'intervalSeconds')::bigint<60)
   OR (c->'calendar'->>'catchUp'='COALESCE_READ' AND c->>'workflowRef'<>'registered-read/1')))),true)
 THEN RAISE EXCEPTION 'proactive_reviewed_configuration';END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_proactive_command_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_proactive_definitions%ROWTYPE; r os_proactive_revisions%ROWTYPE;
BEGIN
 PERFORM os_proactive_session(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id FOR UPDATE;
 IF d.version<>NEW.accepted_version OR NEW.receipt->>'commandId'<>NEW.command_id::text
  OR NEW.receipt->'definition'->'subject'<>jsonb_build_object('installationId',NEW.installation_id::text,'applicationId',NEW.application_id::text,
   'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id) THEN RAISE EXCEPTION 'proactive_command_binding';END IF;
 SELECT * INTO r FROM os_proactive_revisions WHERE definition_id=d.id AND revision=d.configuration_revision;
 IF r.agent_operation_id IS NOT NULL AND NEW.kind='draft' AND NOT COALESCE(
  NEW.expected_version=0 AND NEW.accepted_version=1 AND NEW.command_id=os_query_source_uuid5(r.agent_operation_id,'proactive-draft/1')
  AND NEW.request_digest=os_agent_profile_digest('command',jsonb_build_object('commandId',NEW.command_id,'expectedRevision',null,'configuration',r.configuration)),false)
 THEN RAISE EXCEPTION 'agent_proactive_draft_command';END IF;
 IF r.agent_operation_id IS NOT NULL AND NEW.kind='activate' AND NOT COALESCE(NEW.expected_version=1 AND NEW.accepted_version=2
  AND NEW.request_digest=os_agent_profile_digest('command',jsonb_build_object('commandId',NEW.command_id,'expectedRevision',1,
   'configurationDigest',r.configuration_digest,'decision','activate')),false)
 THEN RAISE EXCEPTION 'agent_proactive_review_command';END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_proactive_delegation_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_proactive_revisions%ROWTYPE;c os_proactive_commands%ROWTYPE;d os_proactive_definitions%ROWTYPE;b jsonb;
BEGIN
 SELECT * INTO r FROM os_proactive_revisions WHERE id=NEW.revision_id;
 PERFORM os_assert_agent_proactive_link(r,'activate');
 SELECT * INTO c FROM os_proactive_commands WHERE id=NEW.review_command_id;
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id;
 b=jsonb_build_array(jsonb_build_object('resourceType',r.configuration->'arguments'->>'resourceType',
  'externalIds',r.configuration->'arguments'->'externalIds','fieldNames',r.configuration->'arguments'->'fieldNames'));
 IF COALESCE((r.definition_id<>d.id OR c.definition_id<>d.id OR c.kind<>'activate' OR c.expected_version<>r.revision OR c.accepted_version<>r.revision+1
  OR NEW.expires_at<>(r.configuration->>'validUntil')::timestamptz OR NEW.expires_at<=clock_timestamp()
  OR NEW.payload->>'id'<>NEW.id::text OR (NEW.payload->>'revision')::bigint<>r.revision OR NEW.payload->'active'<>'true'::jsonb
  OR NEW.payload->>'purpose'<>'assistant.read' OR NEW.payload->>'maxRisk'<>'low'
  OR NEW.payload->'subject'<>c.receipt->'definition'->'subject' OR NEW.payload->'resourceBounds'<>b
  OR NEW.payload->'capabilityRefs'<>jsonb_build_array(r.configuration->>'capabilityRef')
  OR (NEW.payload->>'validUntil')::timestamptz<>NEW.expires_at),true)
 THEN RAISE EXCEPTION 'proactive_exact_finite_delegation';END IF;
 RETURN NULL;
END $$;
"""


def upgrade():
    op.execute(DDL)
    op.execute(HELPERS)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Agent proactive definitions require protected forward recovery')
