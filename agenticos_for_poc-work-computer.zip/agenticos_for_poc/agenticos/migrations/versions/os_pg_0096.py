"""Draft: bind corrected source planners to current child admission.

Only a known planner ancestor of the verified current source can use the later
model branch. Legacy initial planners, immutable rows, original horizons and
all original child/Root/Stop/UNKNOWN/capacity guards remain intact.
"""
from alembic import op

revision='os_pg_0096'
down_revision='os_pg_0095'
branch_labels=None
depends_on=None

TABLES=r"""
ALTER TABLE os_agent_query_source_bindings ADD COLUMN planner_operation_id uuid;
ALTER TABLE os_agent_query_source_bindings ADD COLUMN planner_acceptance_id uuid;
ALTER TABLE os_agent_query_source_bindings ADD CONSTRAINT fk_os_agent_operations_planner_operation_id
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,planner_operation_id)
 REFERENCES os_agent_operations(installation_id,application_id,tenant_id,subject_id,id);
ALTER TABLE os_agent_query_source_bindings ADD CONSTRAINT fk_os_agent_model_acceptances_planner_acceptance_id
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,planner_acceptance_id)
 REFERENCES os_agent_model_acceptances(installation_id,application_id,tenant_id,subject_id,id);
ALTER TABLE os_agent_query_source_bindings ADD CONSTRAINT ck_query_source_binding_planner
 CHECK((planner_operation_id IS NULL)=(planner_acceptance_id IS NULL));
"""

PLANNER_GUARD=r"""
CREATE FUNCTION os_query_source_planner_ancestor(rid uuid,tid uuid,planner uuid,acceptance uuid,candidate uuid)
 RETURNS boolean LANGUAGE sql STABLE AS $$
 WITH RECURSIVE chain AS (
  SELECT op.id,op.parent_operation_id,op.payload FROM os_agent_model_acceptances accepted
   JOIN os_agent_operation_models link ON link.id=accepted.call_id
   JOIN os_agent_operations op ON op.id=link.operation_id
   WHERE accepted.id=candidate AND op.root_id=rid AND op.task_id=tid
  UNION
  SELECT parent.id,parent.parent_operation_id,parent.payload FROM os_agent_operations parent
   JOIN chain child ON child.parent_operation_id=parent.id
   WHERE parent.root_id=rid AND parent.task_id=tid
 )
 SELECT COALESCE(
  EXISTS(SELECT 1 FROM chain WHERE id=planner)
  AND EXISTS(SELECT 1 FROM chain WHERE parent_operation_id IS NULL AND payload->'identity'->>'iteration'='0')
  AND EXISTS(SELECT 1 FROM os_agent_model_acceptances accepted
   JOIN os_agent_operation_models link ON link.id=accepted.call_id
   JOIN os_agent_model_calls model ON model.id=link.id
   JOIN os_work_attempts work ON work.id=model.attempt_id
   WHERE accepted.id=acceptance AND link.operation_id=planner AND link.root_id=rid
    AND work.root_id=rid AND work.task_id=tid AND work.state='SETTLED')
  AND NOT EXISTS(SELECT 1 FROM chain parent WHERE NOT EXISTS(
   SELECT 1 FROM os_agent_operation_models link
    JOIN os_agent_model_acceptances accepted ON accepted.call_id=link.id
    JOIN os_agent_model_calls model ON model.id=link.id
    JOIN os_work_attempts work ON work.id=model.attempt_id
    WHERE link.operation_id=parent.id AND link.root_id=rid AND work.root_id=rid
     AND work.task_id=tid AND work.state='SETTLED')),false)
$$;
"""

BINDING_GUARD=r"""

CREATE OR REPLACE FUNCTION os_guard_query_source_binding() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; a os_admissions%ROWTYPE; prior os_agent_query_source_bindings%ROWTYPE;
 p jsonb; c jsonb; retired jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'query_source_binding_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO prior FROM os_agent_query_source_bindings WHERE root_id=r.id ORDER BY revision DESC LIMIT 1;
 p:=NEW.payload;c:=p->'context';
 SELECT COALESCE(jsonb_agg(jsonb_build_object('childId',id::text,'scopeDigest',scope_digest) ORDER BY id),'[]'::jsonb)
  INTO retired FROM os_agent_child_reads WHERE root_id=r.id AND state='ACTIVE';
 IF NOT COALESCE(r.state='ACTIVE' AND r.root_task_id=NEW.task_id AND a.context=c
  AND c->>'accountingFormat'='agent-resources/1' AND c->'harness'->>'ref'='focused-child-reads/1'
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
      ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
  AND NEW.segment_id=(c->>'segmentId')::uuid AND NEW.intent_revision=(c->>'intentRevision')::bigint
  AND NEW.control_epoch=(c->>'controlEpoch')::bigint AND NEW.created_at<=clock_timestamp()
  AND NEW.created_at>=(c->>'admittedAt')::timestamptz AND NEW.created_at<r.deadline AND NEW.expires_at=r.deadline
  AND EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=NEW.task_id AND state='ACTIVE')
  AND NEW.id=os_query_source_uuid5(NEW.task_id,'query-source-binding/1/'||NEW.candidate_acceptance_id)
  AND NEW.revision=COALESCE(prior.revision,0)+1 AND NEW.previous_id IS NOT DISTINCT FROM prior.id
  AND (prior.id IS NULL OR NEW.created_at>=prior.created_at)
  AND p-ARRAY['context','bindingId','revision','previousId','queryGoalDigest','goalDigest','goalSourceDigest',
      'sourceCandidate','verificationWriteId','goalWriteId','pageNamespace','targetCount','requiredChildren','sourceComplete','retiredChildren']='{}'::jsonb
  AND (SELECT count(*) FROM jsonb_object_keys(p))=15
  AND p->>'bindingId'=NEW.id::text AND (p->>'revision')::bigint=NEW.revision
  AND (p->>'previousId')::uuid IS NOT DISTINCT FROM NEW.previous_id
  AND p->>'goalDigest'=NEW.goal_digest AND p->>'goalSourceDigest' ~ '^[a-f0-9]{64}$'
  AND p->>'queryGoalDigest' ~ '^[a-f0-9]{64}$' AND NEW.payload_digest=os_agent_profile_digest('command',p)
  AND p->>'pageNamespace'=NEW.id::text AND p->'sourceCandidate'->>'resultId'=NEW.candidate_acceptance_id::text
  AND p->>'verificationWriteId'=NEW.verification_write_id::text AND p->>'goalWriteId'=NEW.goal_write_id::text
  AND NEW.verification_write_id=os_query_source_uuid5(NEW.task_id,'verified-query-source/1/'||NEW.id)
  AND NEW.goal_write_id=os_query_source_uuid5(NEW.task_id,'query-source-child-goal/1/'||NEW.id)
  AND jsonb_typeof(p->'targetCount')='number' AND p->>'targetCount' ~ '^[0-9]+$'
  AND (p->>'targetCount')::numeric<=9007199254740991
  AND jsonb_typeof(p->'requiredChildren')='number' AND p->>'requiredChildren' ~ '^[0-9]+$'
  AND (p->>'requiredChildren')::numeric<=9007199254740991 AND jsonb_typeof(p->'sourceComplete')='boolean'
  AND jsonb_typeof(p->'retiredChildren')='array' AND jsonb_array_length(p->'retiredChildren')<=64
  AND p->'retiredChildren'=retired
  AND os_query_source_payload(os_query_source_uuid5(NEW.task_id,'query-source-intent/1'),'AgentQuerySourceIntentRecord',c,NEW.created_at)
  AND os_query_source_payload(NEW.verification_write_id,'AgentQuerySourceVerification',c,NEW.created_at)
  AND os_query_source_payload(NEW.goal_write_id,'AgentQuerySourceGoalRecord',c,NEW.created_at)
  AND NOT EXISTS(SELECT 1 FROM os_agent_model_acceptances accepted
    JOIN os_agent_operation_models link ON link.id=accepted.call_id JOIN os_agent_child_operations child ON child.id=link.operation_id
    WHERE accepted.id=NEW.candidate_acceptance_id),false)
  THEN RAISE EXCEPTION 'query_source_binding_admission'; END IF;
 PERFORM os_assert_agent_input_dependency(p->'sourceCandidate',c,r.id,NEW.created_at);
 IF NEW.planner_operation_id IS NULL OR NEW.planner_acceptance_id IS NULL
  OR NOT os_query_source_planner_ancestor(
   NEW.root_id,NEW.task_id,NEW.planner_operation_id,NEW.planner_acceptance_id,NEW.candidate_acceptance_id)
  THEN RAISE EXCEPTION 'query_source_planner_binding'; END IF;
 RETURN NEW;
END $$;
"""

CHILD_GUARD=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_child_read() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; binding os_agent_child_roots%ROWTYPE; policy os_agent_child_policies%ROWTYPE;
 w os_agent_payload_writes%ROWTYPE; allowed boolean; source os_agent_query_source_bindings%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_child_read_retained'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO binding FROM os_agent_child_roots WHERE id=NEW.root_binding_id AND root_id=r.id;
 SELECT * INTO policy FROM os_agent_child_policies WHERE installation_id=binding.installation_id
  AND application_id=binding.application_id AND policy_digest=binding.policy_digest;
 IF TG_OP='INSERT' THEN
  SELECT * INTO source FROM os_agent_query_source_bindings WHERE id=NEW.source_binding_id AND root_id=r.id;
  IF source.planner_operation_id IS NOT NULL AND
   ROW(NEW.parent_operation_id,NEW.parent_acceptance_id) IS DISTINCT FROM
    ROW(source.planner_operation_id,source.planner_acceptance_id)
   THEN RAISE EXCEPTION 'query_child_planner_binding'; END IF;
  SELECT * INTO w FROM os_agent_payload_writes WHERE id=NEW.scope_write_id;
  IF NOT COALESCE(NEW.state='ACTIVE' AND NEW.version=1 AND NEW.checkpoint_write_id IS NULL
   AND NEW.candidate_acceptance_id IS NULL AND NEW.verification_write_id IS NULL
   AND NEW.updated_at=NEW.created_at AND NEW.created_at>=w.created_at AND NEW.created_at<=clock_timestamp()
   AND NEW.expires_at<=LEAST(r.deadline,NEW.created_at+make_interval(secs=>(policy.payload->>'workTimeoutMs')::numeric/1000))
   AND NEW.expires_at>clock_timestamp() AND r.state='ACTIVE' AND r.root_task_id=NEW.task_id
   AND w.root_id=r.id AND w.task_id=NEW.task_id AND w.schema_ref='AgentChildReadScope' AND w.schema_version=1
   AND w.expires_at>=NEW.expires_at AND EXISTS(SELECT 1 FROM os_agent_private_payloads WHERE write_id=w.id)
   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=w.attempt_id AND state='SETTLED')
   AND EXISTS(SELECT 1 FROM os_agent_operations op JOIN os_agent_operation_models link ON link.operation_id=op.id
    JOIN os_agent_model_acceptances accepted ON accepted.call_id=link.id
    WHERE op.id=NEW.parent_operation_id AND op.root_id=r.id AND op.task_id=NEW.task_id
     AND accepted.id=NEW.parent_acceptance_id AND (
     (op.parent_operation_id IS NULL AND op.payload->'identity'->>'iteration'='0')
     OR EXISTS(SELECT 1 FROM os_agent_query_source_bindings current_source
      WHERE current_source.id=NEW.source_binding_id AND current_source.root_id=r.id
       AND current_source.task_id=NEW.task_id AND current_source.expires_at>clock_timestamp()
       AND NEW.created_at>=current_source.created_at
       AND current_source.id=(SELECT head.id FROM os_agent_query_source_bindings head
        WHERE head.root_id=r.id ORDER BY head.revision DESC LIMIT 1)
       AND current_source.planner_operation_id=op.id
       AND current_source.planner_acceptance_id=accepted.id
       AND os_query_source_planner_ancestor(r.id,NEW.task_id,op.id,accepted.id,current_source.candidate_acceptance_id))))
   AND EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=NEW.task_id AND state='ACTIVE'),false)
   THEN RAISE EXCEPTION 'agent_child_read_admission'; END IF;
  IF (SELECT count(*) FROM os_agent_child_reads WHERE root_id=r.id AND state='ACTIVE')
   >=(policy.payload->>'maxActiveChildren')::bigint THEN RAISE EXCEPTION 'agent_child_active_capacity'; END IF;
 ELSE
  IF NOT COALESCE(OLD.state='ACTIVE' AND NEW.version=OLD.version+1 AND NEW.updated_at>=OLD.updated_at
   AND NEW.updated_at<=clock_timestamp()
   AND (to_jsonb(NEW)-ARRAY['state','version','checkpoint_write_id','candidate_acceptance_id','verification_write_id','updated_at'])
    =(to_jsonb(OLD)-ARRAY['state','version','checkpoint_write_id','candidate_acceptance_id','verification_write_id','updated_at']),false)
   THEN RAISE EXCEPTION 'agent_child_read_transition'; END IF;
  IF NEW.checkpoint_write_id IS DISTINCT FROM OLD.checkpoint_write_id AND NOT EXISTS(
   SELECT 1 FROM os_agent_payload_writes payload JOIN os_agent_private_payloads ready ON ready.write_id=payload.id
   JOIN os_work_attempts work ON work.id=payload.attempt_id WHERE payload.id=NEW.checkpoint_write_id
    AND payload.root_id=r.id AND payload.task_id=NEW.task_id AND payload.schema_ref='AgentSDKCheckpointState'
    AND payload.schema_version=1 AND work.state='SETTLED' AND payload.expires_at>clock_timestamp())
   THEN RAISE EXCEPTION 'agent_child_checkpoint_binding'; END IF;
  IF NEW.state='COMPLETED' THEN
   SELECT EXISTS(SELECT 1 FROM os_agent_model_acceptances accepted
    JOIN os_agent_operation_models link ON link.id=accepted.call_id
    JOIN os_agent_child_operations child ON child.id=link.operation_id
    WHERE accepted.id=NEW.candidate_acceptance_id AND child.child_id=NEW.id AND child.root_id=r.id) INTO allowed;
   IF NOT COALESCE(allowed AND EXISTS(SELECT 1 FROM os_agent_payload_writes payload
    JOIN os_agent_private_payloads ready ON ready.write_id=payload.id JOIN os_work_attempts work ON work.id=payload.attempt_id
    WHERE payload.id=NEW.verification_write_id AND payload.root_id=r.id AND payload.task_id=NEW.task_id
     AND payload.schema_ref='AgentChildReadVerification' AND payload.schema_version=1
     AND payload.expires_at>clock_timestamp() AND work.state='SETTLED')
    AND NOT EXISTS(SELECT 1 FROM os_agent_child_operations child JOIN os_agent_operation_models link ON link.operation_id=child.id
     JOIN os_agent_model_calls model ON model.id=link.id JOIN os_work_attempts work ON work.id=model.attempt_id
     WHERE child.child_id=NEW.id AND work.state IN ('RESERVED','RUNNING','UNKNOWN'))
    AND NOT EXISTS(SELECT 1 FROM os_agent_child_operations child JOIN os_agent_tool_operations op ON op.parent_operation_id=child.id
     JOIN os_agent_tool_calls tool ON tool.operation_id=op.id JOIN os_work_attempts work ON work.id=tool.attempt_id
     WHERE child.child_id=NEW.id AND work.state IN ('RESERVED','RUNNING','UNKNOWN')),false)
    THEN RAISE EXCEPTION 'agent_child_completion_incomplete'; END IF;
  ELSIF NEW.state='INTERRUPTED' AND NOT COALESCE(r.deadline<=clock_timestamp() OR NEW.expires_at<=clock_timestamp()
   OR EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=NEW.task_id AND state<>'ACTIVE')
   OR EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state IN ('RECONCILING','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
   OR os_query_source_child_retired(NEW.id,NEW.root_id,NEW.scope_digest),false)
   THEN RAISE EXCEPTION 'agent_child_interruption_unproven'; END IF;
 END IF;
 RETURN NEW;
END $$;
"""

def upgrade():
    op.execute(TABLES)
    op.execute(PLANNER_GUARD)
    op.execute(BINDING_GUARD)
    op.execute(CHILD_GUARD)


def downgrade():
    raise RuntimeError('Corrected source planner metadata requires retained forward recovery')
