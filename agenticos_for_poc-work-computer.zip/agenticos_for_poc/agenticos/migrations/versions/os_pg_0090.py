"""Unapplied draft: explicit original-root production repair bindings.

Complete the shared phase adapter and its current/grant/commit guards before
populated positive/negative rollback, forward/catalog and independent0089
recovery qualification. No production repair admission is enabled by this draft.
"""
from alembic import op

revision='os_pg_0090'
down_revision='os_pg_0089'
branch_labels=None
depends_on=None

TABLES=r"""
CREATE TABLE os_agent_repair_roots (
 id uuid PRIMARY KEY,root_id uuid NOT NULL,admission_id uuid NOT NULL,policy jsonb NOT NULL,
 digest varchar(64) NOT NULL,created_at timestamptz NOT NULL,
 installation_id uuid NOT NULL,application_id uuid NOT NULL,tenant_id varchar(256) NOT NULL,subject_id varchar(256) NOT NULL,
 CONSTRAINT uq_agent_repair_root_owner_id UNIQUE(installation_id,application_id,tenant_id,subject_id,id),
 CONSTRAINT uq_agent_repair_root_once UNIQUE(installation_id,application_id,tenant_id,subject_id,root_id),
 CONSTRAINT uq_agent_repair_admission_once UNIQUE(installation_id,application_id,tenant_id,subject_id,admission_id),
 CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,root_id)
  REFERENCES os_budget_roots(installation_id,application_id,tenant_id,subject_id,id),
 CONSTRAINT fk_os_admissions_admission_id FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,admission_id)
  REFERENCES os_admissions(installation_id,application_id,tenant_id,subject_id,id),
 CONSTRAINT ck_agent_repair_root_digest CHECK(digest ~ '^[a-f0-9]{64}$'),
 CONSTRAINT ck_agent_repair_root_policy CHECK(jsonb_typeof(policy)='object'
  AND policy ?& ARRAY['profileRef','context','maxRepairs','inverseProfile']
  AND policy-ARRAY['profileRef','context','maxRepairs','inverseProfile']='{}'::jsonb),
 CONSTRAINT ck_agent_repair_root_size CHECK(jsonb_typeof(policy)='object' AND octet_length(policy::text)<=16384)
);
ALTER TABLE os_agent_effect_receipts ADD CONSTRAINT uq_agent_effect_receipt_exact
 UNIQUE(installation_id,application_id,tenant_id,subject_id,id,binding_id,observation_digest);
ALTER TABLE os_repair_admissions ADD COLUMN production_binding_id uuid;
ALTER TABLE os_repair_admissions ADD COLUMN production_projection_id uuid;
ALTER TABLE os_repair_admissions ADD COLUMN production_review_id uuid;
ALTER TABLE os_repair_admissions ADD COLUMN production_original jsonb;
ALTER TABLE os_repair_admissions ALTER COLUMN original_proposal_id DROP NOT NULL;
ALTER TABLE os_repair_admissions DROP CONSTRAINT ck_repair_original_family;
ALTER TABLE os_repair_admissions ADD CONSTRAINT ck_repair_original_family CHECK(
 ((original_kind='input-reviewed' AND reviewed_binding_id IS NOT NULL AND reviewed_projection_id IS NOT NULL
  AND delegated_binding_id IS NULL AND delegated_projection_id IS NULL)
 OR (original_kind='input-delegated' AND delegated_binding_id IS NOT NULL AND delegated_projection_id IS NOT NULL
  AND reviewed_binding_id IS NULL AND reviewed_projection_id IS NULL))
 AND original_proposal_id IS NOT NULL AND production_binding_id IS NULL AND production_projection_id IS NULL
 AND production_review_id IS NULL AND production_original IS NULL
 OR (original_kind='agent-reviewed' AND reviewed_binding_id IS NULL AND reviewed_projection_id IS NULL
  AND delegated_binding_id IS NULL AND delegated_projection_id IS NULL AND original_proposal_id IS NULL
  AND production_binding_id IS NOT NULL AND production_projection_id IS NOT NULL AND production_review_id IS NOT NULL
  AND production_original IS NOT NULL AND jsonb_typeof(production_original)='object'
  AND octet_length(production_original::text)<=16384));
ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_repair_production_original_exact
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,production_projection_id,production_binding_id,observation_digest)
 REFERENCES os_agent_effect_receipts(installation_id,application_id,tenant_id,subject_id,id,binding_id,observation_digest);
ALTER TABLE os_repair_admissions ADD CONSTRAINT fk_os_agent_reviews_production_review_id
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,production_review_id)
 REFERENCES os_agent_reviews(installation_id,application_id,tenant_id,subject_id,id);
DROP TRIGGER immutable_os_repair_admissions ON os_repair_admissions;
CREATE TRIGGER immutable_os_repair_admissions BEFORE UPDATE OR DELETE ON os_repair_admissions
 FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','task_id','parent_task_id','root_id','segment_id','original_kind',
 'reviewed_binding_id','reviewed_projection_id','delegated_binding_id','delegated_projection_id',
 'production_binding_id','production_projection_id','production_review_id','production_original',
 'observation_digest','original_proposal_id','original_receipt_id','original_receipt_version','session_id','authority',
 'command_id','command_digest','capability_ref','registration_revision','definition_digest','repair_digest','created_at','expires_at',
 'installation_id','application_id','tenant_id','subject_id');
"""

ROOT_GUARDS=r"""
CREATE FUNCTION os_guard_agent_repair_root() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE;a os_admissions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_repair_root_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=NEW.admission_id;
 IF NOT COALESCE(r.id IS NOT NULL AND a.id=r.admission_id AND a.task_id=r.root_task_id
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
  AND r.accounting_format='agent-resources/1' AND r.profile_ref='agent-production/1'
  AND r.state='ACTIVE' AND r.version=1 AND r.granted IS NULL AND r.deadline>clock_timestamp()
  AND a.context->'harness'->>'ref'='agent-sdk-repairable-change/1'
  AND NEW.id=os_query_source_uuid5(r.id,'agent-original-root-repair/1')
  AND NEW.policy=jsonb_build_object('profileRef','agent-original-root-repair/1','context',a.context,
   'maxRepairs',1,'inverseProfile','typed-update-restore/1')
  AND NEW.digest=os_agent_profile_digest('policy',NEW.policy) AND NEW.created_at<=clock_timestamp()
  AND NOT EXISTS(SELECT 1 FROM jsonb_each(r.spent) x WHERE x.value<>'0'::jsonb)
  AND NOT EXISTS(SELECT 1 FROM jsonb_each(r.outstanding) x WHERE x.value<>'0'::jsonb)
  AND NOT EXISTS(SELECT 1 FROM os_work_attempts WHERE root_id=r.id),false)
 THEN RAISE EXCEPTION 'agent_repair_original_policy'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_repair_root BEFORE INSERT OR UPDATE OR DELETE ON os_agent_repair_roots
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_repair_root();
CREATE FUNCTION os_check_agent_repair_policy() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.context->'harness'->>'ref' IS DISTINCT FROM 'agent-sdk-repairable-change/1' THEN RETURN NULL; END IF;
 IF NOT EXISTS(SELECT 1 FROM os_agent_repair_roots p WHERE p.admission_id=NEW.id
  AND p.root_id=(NEW.context->>'rootId')::uuid AND p.policy->'context'=NEW.context)
  OR NOT EXISTS(SELECT 1 FROM os_agent_group_accounts g JOIN os_agent_resource_accounts account ON account.id=g.account_id
   WHERE g.root_id=(NEW.context->>'rootId')::uuid AND account.root_id=g.root_id AND g.protocol='resource-groups/1')
 THEN RAISE EXCEPTION 'agent_repair_missing_original_policy'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_repair_policy AFTER INSERT ON os_admissions DEFERRABLE INITIALLY DEFERRED
 FOR EACH ROW EXECUTE FUNCTION os_check_agent_repair_policy();
"""

REVIEW_GUARD=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_review() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_tool_acceptances%ROWTYPE; c os_agent_tool_calls%ROWTYPE; o os_agent_tool_operations%ROWTYPE;
 f os_agent_tool_archives%ROWTYPE; p os_agent_tool_profiles%ROWTYPE; r os_budget_roots%ROWTYPE;
 v jsonb; context jsonb; reference jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_review_immutable'; END IF;
 SELECT * INTO a FROM os_agent_tool_acceptances WHERE id=NEW.preparation_id;
 SELECT * INTO c FROM os_agent_tool_calls WHERE id=a.call_id;
 SELECT * INTO o FROM os_agent_tool_operations WHERE id=c.operation_id;
 PERFORM os_assert_agent_tool_current(o);
 SELECT * INTO f FROM os_agent_tool_archives WHERE id=a.artifact_id;
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id;
 v:=NEW.payload;context:=o.payload->'context';reference:=v->'preparation';
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND p.payload->'preparation'->>'outputContract'='AgentPreparedChange/1'
  AND o.task_id=NEW.task_id AND o.root_id=NEW.root_id
  AND (context->'harness'->>'ref'='agent-sdk-reviewed-change/1'
   OR context->'harness'->>'ref'='agent-sdk-serialized-reviewed-change/1' AND EXISTS(SELECT 1 FROM os_agent_write_conflict_roots b
    JOIN os_agent_write_conflict_policies policy ON policy.installation_id=b.installation_id AND policy.application_id=b.application_id
     AND policy.policy_digest=b.policy_digest WHERE b.root_id=r.id AND policy.payload->'harness'=context->'harness')
   OR context->'harness'->>'ref'='agent-sdk-repairable-change/1' AND EXISTS(SELECT 1 FROM os_agent_repair_roots repair
    WHERE repair.root_id=r.id AND repair.admission_id=r.admission_id AND repair.policy->'context'=context))
  AND NEW.digest=os_agent_profile_digest('command',v)
  AND v=jsonb_build_object('context',context,'preparation',reference,'proposalId',NEW.id,'proposalDigest',v->'proposalDigest','stageId',v->'stageId','expiresAt',v->'expiresAt')
  AND v->>'stageId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
  AND v->>'proposalDigest' ~ '^[a-f0-9]{64}$'
  AND reference=jsonb_build_object('subject',context->'subject','taskId',NEW.task_id,'rootId',NEW.root_id,
   'resultId',a.id,'producerStepId',c.id,'acceptedAttemptId',c.attempt_id,
   'payload',jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',f.plain_bytes,
    'schemaRef','AgentPreparedChange','schemaVersion',1),'lineageRef',null,'scopeRef',context->'scopeRef','acceptedAt',reference->'acceptedAt')
  AND (reference->>'acceptedAt')::timestamptz=a.created_at AND a.created_at<=NEW.created_at
  AND (v->>'expiresAt')::timestamptz=NEW.expires_at AND NEW.expires_at<=r.deadline AND NEW.expires_at<=c.expires_at
  AND NEW.expires_at>clock_timestamp() AND NEW.created_at<=clock_timestamp()
  AND NOT EXISTS(SELECT 1 FROM jsonb_each(r.outstanding) x WHERE x.value<>'0'::jsonb),false)
 THEN RAISE EXCEPTION 'agent_review_binding'; END IF;
 RETURN NEW;
END $$;
"""


# Exact maintained89 group bodies; only the named repair/storage child boundary
# and repair source/member branch are additive. Generic model context is unchanged.
GROUP_GUARDS=r"""
ALTER TABLE os_agent_resource_groups DROP CONSTRAINT ck_agent_group_bounds;
ALTER TABLE os_agent_resource_groups ADD CONSTRAINT ck_agent_group_bounds CHECK(
 control_epoch>0 AND ticket BETWEEN 1 AND 9007199254740991 AND state IN ('WAITING','ADMITTED','CANCELLED','EXPIRED')
 AND profile_ref IN ('model-reservation/1','tool-reservation/1','storage-reservation/1','compute-reservation/1',
  'effect-reservation/1','native-reservation/1','memory-reservation/1','repair-reservation/1')
 AND jsonb_typeof(request)='object' AND octet_length(request::text)<=65536);
CREATE FUNCTION os_agent_repair_child_context(a os_admissions,c jsonb) RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE repair os_repair_admissions%ROWTYPE;r os_budget_roots%ROWTYPE;child os_tasks%ROWTYPE;seg os_segments%ROWTYPE;
BEGIN
 IF a.context->'harness'->>'ref' IS DISTINCT FROM 'agent-sdk-repairable-change/1' THEN RETURN false; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=(c->>'rootId')::uuid;
 SELECT * INTO repair FROM os_repair_admissions WHERE root_id=r.id AND task_id=(c->>'taskId')::uuid AND original_kind='agent-reviewed';
 SELECT * INTO child FROM os_tasks WHERE id=repair.task_id;
 SELECT * INTO seg FROM os_segments WHERE id=(c->>'segmentId')::uuid;
 RETURN COALESCE(r.admission_id=a.id AND r.state='ACTIVE' AND r.deadline>clock_timestamp()
  AND child.budget_root_id=r.id AND child.deadline=r.deadline AND child.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')
  AND ROW(repair.installation_id,repair.application_id,repair.tenant_id,repair.subject_id)=ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND EXISTS(SELECT 1 FROM os_agent_repair_roots p WHERE p.root_id=r.id AND p.admission_id=a.id AND p.policy->'context'=a.context)
  AND seg.task_id=repair.task_id AND seg.state='OPEN' AND (seg.id=repair.segment_id OR EXISTS(
   SELECT 1 FROM os_repair_approvals approval WHERE approval.admission_id=repair.id AND approval.successor_segment_id=seg.id AND approval.decision='approve'))
  AND EXISTS(SELECT 1 FROM os_task_controls control WHERE control.task_id=child.id AND control.state='ACTIVE' AND control.epoch=1)
  AND c=a.context||jsonb_build_object('taskId',child.id,'segmentId',seg.id,'controlEpoch',1),false);
END $$;
CREATE OR REPLACE FUNCTION public.os_guard_agent_resource_group()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE a os_agent_group_accounts%ROWTYPE; original os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE;
 d os_admissions%ROWTYPE; c jsonb; member jsonb; required jsonb; w os_work_attempts%ROWTYPE; expected_kind text; expected_count integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_group_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_agent_group_accounts WHERE id=NEW.group_account_id;
 SELECT * INTO original FROM os_agent_resource_accounts WHERE id=a.account_id;
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state') THEN RAISE EXCEPTION 'agent_group_transition'; END IF;
  IF NEW.state='ADMITTED' THEN
   PERFORM os_agent_resource_owner(original);
   w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
   w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
   PERFORM os_assert_agent_work_current(w);
   IF EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
    THEN RAISE EXCEPTION 'agent_group_fifo'; END IF;
  END IF;
  RETURN NEW;
 END IF;
 PERFORM os_agent_resource_owner(original);
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 c=NEW.request->'context';required=os_agent_group_required(NEW.request->'members');
 expected_kind=CASE NEW.profile_ref WHEN 'repair-reservation/1' THEN 'agent.repair' WHEN 'model-reservation/1' THEN 'agent.model' WHEN 'tool-reservation/1' THEN CASE WHEN c->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END WHEN 'compute-reservation/1' THEN 'agent.compute' WHEN 'effect-reservation/1' THEN 'agent.effect' WHEN 'native-reservation/1' THEN 'agent.native' WHEN 'memory-reservation/1' THEN 'agent.memory' ELSE 'agent.storage' END;
 expected_count=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 3 WHEN 'tool-reservation/1' THEN 2 WHEN 'memory-reservation/1' THEN 2 ELSE 1 END;
 IF a.id IS NULL OR a.root_id<>r.id OR NEW.group_account_id<>a.id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline OR NOT COALESCE(os_agent_context_matches(d,c) OR (NEW.profile_ref IN ('repair-reservation/1','storage-reservation/1') AND os_agent_repair_child_context(d,c)),false)
  OR NEW.request IS DISTINCT FROM jsonb_build_object('context',c,'groupId',NEW.id::text,'profile',NEW.profile_ref,'sourceId',NEW.source_id::text,'members',NEW.request->'members')
  OR c->>'rootId'<>NEW.root_id::text OR c->>'taskId'<>NEW.task_id::text OR c->>'segmentId'<>NEW.segment_id::text
  OR (c->>'controlEpoch')::bigint<>NEW.control_epoch
  OR NEW.request_digest<>os_agent_profile_digest('command',NEW.request||jsonb_build_object('schema','agent-resource-group/1'))
  OR jsonb_array_length(NEW.request->'members')<>expected_count
  OR NEW.request->'members'->0->>'kind'<>expected_kind OR NEW.request->'members'->0->>'invocationId'<>NEW.source_id::text
  OR (SELECT count(DISTINCT value->>'invocationId') FROM jsonb_array_elements(NEW.request->'members'))<>expected_count
  THEN RAISE EXCEPTION 'agent_group_binding'; END IF;
 FOR member IN SELECT value FROM jsonb_array_elements(NEW.request->'members') LOOP
  IF member IS DISTINCT FROM jsonb_build_object('taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,'controlEpoch',NEW.control_epoch,
    'invocationId',member->'invocationId','kind',member->'kind','inputDigest',member->'inputDigest','units',member->'units','timeoutMs',member->'timeoutMs')
   OR jsonb_typeof(member->'invocationId') IS DISTINCT FROM 'string' OR (member->>'invocationId') !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   OR jsonb_typeof(member->'inputDigest') IS DISTINCT FROM 'string' OR (member->>'inputDigest') !~ '^[a-f0-9]{64}$'
   OR member->>'kind' NOT IN ('agent.model','agent.tool','agent.storage','agent.compute','agent.effect','agent.native','agent.memory','agent.schedule','agent.repair')
   OR jsonb_typeof(member->'kind') IS DISTINCT FROM 'string'
   OR jsonb_typeof(member->'timeoutMs') IS DISTINCT FROM 'number' OR (member->>'timeoutMs') !~ '^[1-9][0-9]*$'
   OR (member->>'timeoutMs')::numeric>(original.policy->>'requestTimeoutMs')::numeric
   OR (member->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
   OR (member->'units'->>'workMs')::numeric<1 THEN RAISE EXCEPTION 'agent_group_member_request'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.request->'members') WITH ORDINALITY AS m(value,ordinal) WHERE ordinal>1 AND value->>'kind'<>'agent.storage')
  THEN RAISE EXCEPTION 'agent_group_member_kind'; END IF;
 IF expected_kind='agent.schedule' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id
   AND tool.payload->'context'=c AND tool.payload->'capability'=os_agent_proactive_profile(d)->'capability'
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_proactive_group_source';END IF;
 IF NEW.profile_ref='memory-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND (p.payload ? 'memory' OR p.payload ? 'knowledge')
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_memory_group_source';END IF;
 IF NEW.profile_ref='native-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_native_operations native WHERE native.root_id=NEW.root_id AND native.task_id=NEW.task_id
   AND native.payload->'context'=c AND os_query_source_uuid5(native.id,'tool-attempt/1')=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_native_group_source'; END IF;
 IF NEW.profile_ref='effect-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
   JOIN os_tasks task ON task.id=review.task_id
  WHERE decision.id=NEW.source_id AND review.root_id=NEW.root_id AND review.task_id=NEW.task_id
   AND review.payload->'context'=c AND decision.payload->'command'->>'decision'='approve'
   AND decision.expires_at>clock_timestamp() AND task.state='RUNNING'
   AND (NEW.request->'members'->0->>'inputDigest')=(os_agent_reviewed_grant(decision.id)->>'grantDigest'))
 THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
 IF NEW.profile_ref='repair-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_repair_admissions repair JOIN os_tasks child ON child.id=repair.task_id
   LEFT JOIN os_repair_grants grant_row ON grant_row.admission_id=repair.id
  WHERE repair.original_kind='agent-reviewed' AND repair.root_id=NEW.root_id AND repair.task_id=NEW.task_id
   AND os_agent_repair_child_context(d,c) AND (
    (NEW.source_id=os_query_source_uuid5(repair.id,'preparation/1') AND NEW.segment_id=repair.segment_id
     AND child.state='ACCEPTED' AND NEW.request->'members'->0->>'inputDigest'=os_agent_profile_digest('command',
      jsonb_build_object('profile','agent-repair-work/1','repairDigest',repair.repair_digest,'phase','prepare',
       'workMs',(NEW.request->'members'->0->'units'->>'workMs')::bigint,'grantId',null)))
    OR (NEW.source_id=(grant_row.payload->>'invocationId')::uuid AND child.state='VALIDATING'
     AND NEW.segment_id=(grant_row.payload->>'segmentId')::uuid AND grant_row.expires_at>clock_timestamp()
     AND NEW.request->'members'->0->>'inputDigest'=os_agent_profile_digest('command',
      jsonb_build_object('profile','agent-repair-work/1','repairDigest',repair.repair_digest,'phase','effect',
       'workMs',(NEW.request->'members'->0->'units'->>'workMs')::bigint,'grantId',grant_row.id)))))
 THEN RAISE EXCEPTION 'agent_group_repair_source'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));PERFORM os_assert_agent_work_current(w);
 RETURN NEW;
END $function$
;
CREATE OR REPLACE FUNCTION public.os_check_agent_group_complete()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE gid uuid; g os_agent_resource_groups%ROWTYPE; expected_count integer; actual uuid[]; claimed uuid[];
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_agent_resource_groups' THEN gid=NEW.id;
 ELSIF TG_TABLE_NAME='os_agent_group_members' THEN gid=NEW.group_id;
 ELSE SELECT group_id INTO gid FROM os_agent_group_members WHERE id=NEW.member_id; END IF;
 SELECT * INTO g FROM os_agent_resource_groups WHERE id=gid;
 IF g.id IS NULL THEN RAISE EXCEPTION 'agent_group_missing'; END IF;
 expected_count=jsonb_array_length(g.request->'members');
 SELECT array_agg(c.attempt_id ORDER BY c.attempt_id) INTO claimed FROM os_agent_group_claims c JOIN os_agent_group_members m ON m.id=c.member_id WHERE m.group_id=gid;
 IF g.state<>'ADMITTED' THEN
  IF EXISTS(SELECT 1 FROM os_agent_group_members WHERE group_id=gid) THEN RAISE EXCEPTION 'agent_group_unadmitted_work'; END IF;
  RETURN NEW;
 END IF;
 IF (SELECT count(*) FROM os_agent_group_members WHERE group_id=gid)<>expected_count OR cardinality(claimed) IS DISTINCT FROM expected_count
  THEN RAISE EXCEPTION 'agent_group_incomplete'; END IF;
 IF g.profile_ref='model-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_model_calls WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND request->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_model_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_model_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_model_slots WHERE call_id=g.source_id) s;
 ELSIF g.profile_ref IN ('tool-reservation/1','memory-reservation/1') THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
    WHERE c.id=g.source_id AND c.root_id=g.root_id AND o.task_id=g.task_id AND o.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_tool_source'; END IF;
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_work_attempts w ON w.id=c.attempt_id
   WHERE c.id=g.source_id AND w.kind=CASE WHEN g.profile_ref='memory-reservation/1' THEN 'agent.memory'
    WHEN g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END)
   OR (g.profile_ref='tool-reservation/1' AND g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%'
    AND NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
     JOIN os_budget_roots r ON r.id=o.root_id JOIN os_admissions a ON a.id=r.admission_id
     JOIN os_agent_tool_profiles p ON p.installation_id=o.installation_id AND p.application_id=o.application_id
      AND p.policy_digest=o.payload->'profile'->>'digest'
     WHERE c.id=g.source_id AND p.payload ? 'proactive'
      AND p.payload->'proactive'->'capability'=o.payload->'capability'
      AND o.payload->'capability'=os_agent_proactive_profile(a)->'capability'))
  THEN RAISE EXCEPTION 'agent_group_tool_lane';END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_tool_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_tool_slots WHERE id=g.source_id) s;
 ELSIF g.profile_ref='effect-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
    WHERE decision.id=g.source_id AND review.root_id=g.root_id AND review.task_id=g.task_id
     AND review.payload->'context'=g.request->'context' AND decision.payload->'command'->>'decision'='approve')
   THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.effect';
 ELSIF g.profile_ref='native-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_native_calls call JOIN os_agent_native_operations native ON native.id=call.operation_id
   WHERE call.id=g.source_id AND call.root_id=g.root_id AND native.task_id=g.task_id AND native.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_native_source'; END IF;
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_native_calls WHERE id=g.source_id;
 ELSIF g.profile_ref='repair-reservation/1' THEN
  SELECT array_agg(w.id ORDER BY w.id) INTO actual FROM os_work_attempts w
   JOIN os_repair_work b ON b.attempt_id=w.id JOIN os_repair_admissions repair ON repair.id=b.admission_id
   WHERE w.invocation_id=g.source_id AND w.root_id=g.root_id AND w.task_id=g.task_id
    AND w.segment_id=g.segment_id AND w.control_epoch=g.control_epoch AND w.kind='agent.repair'
    AND w.accounting_format='agent-resources/1' AND repair.original_kind='agent-reviewed'
    AND repair.root_id=g.root_id AND repair.task_id=g.task_id;
 ELSIF g.profile_ref='compute-reservation/1' THEN
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.compute';
 ELSE
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_payload_writes
   WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND segment_id=g.segment_id AND control_epoch=g.control_epoch;
 END IF;
 IF actual IS DISTINCT FROM claimed THEN RAISE EXCEPTION 'agent_group_source_members'; END IF;
 RETURN NEW;
END $function$
;
"""


# Legacy phase checks remain; only the explicit production family has new
# source/accounting/storage branches. Applied0089 bodies are never modified.
PHASE_GUARDS=r"""
CREATE OR REPLACE FUNCTION public.os_assert_repair_current(d os_repair_admissions, a jsonb)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE r os_budget_roots%ROWTYPE; t os_tasks%ROWTYPE; parent os_tasks%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; login os_interactive_sessions%ROWTYPE;
 original_work os_work_attempts%ROWTYPE; inv os_registered_inverses%ROWTYPE;
 receipt jsonb; original_task uuid; original_root uuid; original_attempt_id uuid;
 original_invocation uuid; original_request text; original_grant jsonb; now_at timestamptz;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 PERFORM 1 FROM os_task_controls WHERE
  (installation_id,application_id,tenant_id,subject_id)=(d.installation_id,d.application_id,d.tenant_id,d.subject_id)
  AND task_id IN (d.task_id,d.parent_task_id) ORDER BY task_id FOR UPDATE;
 IF EXISTS(SELECT 1 FROM os_task_controls WHERE task_id IN (d.task_id,d.parent_task_id) AND state<>'ACTIVE')
  OR (SELECT count(*) FROM os_task_controls WHERE task_id IN (d.task_id,d.parent_task_id))<>2
 THEN RAISE EXCEPTION 'repair_stopped'; END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id FOR UPDATE;
 SELECT * INTO owner FROM os_subjects WHERE
  (installation_id,application_id,tenant_id,subject_id)=(d.installation_id,d.application_id,d.tenant_id,d.subject_id) FOR UPDATE;
 SELECT * INTO login FROM os_interactive_sessions WHERE
  (installation_id,application_id,tenant_id,subject_id,id)=
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id,(a->>'sessionId')::uuid) FOR UPDATE;
 SELECT * INTO parent FROM os_tasks WHERE id=d.parent_task_id FOR UPDATE;
 SELECT * INTO t FROM os_tasks WHERE id=d.task_id FOR UPDATE;
 IF d.original_kind='agent-reviewed' THEN
  SELECT w.task_id,w.root_id,w.id,os_agent_reviewed_grant(w.invocation_id)
   INTO original_task,original_root,original_attempt_id,original_grant
   FROM os_work_attempts w WHERE w.id=d.production_binding_id
    AND w.kind='agent.effect' AND w.accounting_format='agent-resources/1';
  SELECT p.payload INTO receipt FROM os_agent_effect_receipts p WHERE
   ROW(p.installation_id,p.application_id,p.tenant_id,p.subject_id,p.id,p.binding_id,p.observation_digest)=
   ROW(d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.production_projection_id,d.production_binding_id,d.observation_digest)
   AND d.production_original=jsonb_build_object('subject',a->'subject','id',p.id,'bindingId',p.binding_id,
    'invocationId',p.invocation_id,'requestDigest',p.effect_request_digest,'providerBindingDigest',p.provider_binding_digest,
    'observationDigest',p.observation_digest,'observation',p.payload,'createdAt',d.production_original->'createdAt')
   AND (d.production_original->>'createdAt')::timestamptz=p.created_at
   AND NOT EXISTS(SELECT 1 FROM os_agent_effect_receipts newer WHERE newer.binding_id=p.binding_id AND newer.ordinal>p.ordinal);
 ELSIF d.original_kind='input-delegated' THEN
  SELECT b.task_id,b.root_id,b.attempt_id,g.payload INTO original_task,original_root,original_attempt_id,original_grant
  FROM os_input_delegated_attempts b
  JOIN os_input_delegated_grants g ON g.id=b.grant_id
  WHERE b.id=d.delegated_binding_id;
  SELECT p.payload INTO receipt FROM os_input_delegated_receipts p WHERE
   (p.installation_id,p.application_id,p.tenant_id,p.subject_id,p.id,p.binding_id,p.observation_digest)=
   (d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.delegated_projection_id,d.delegated_binding_id,d.observation_digest)
   AND NOT EXISTS(SELECT 1 FROM os_input_delegated_receipts x WHERE x.binding_id=p.binding_id AND x.ordinal>p.ordinal);
 ELSE
  SELECT b.task_id,b.root_id,b.attempt_id,g.payload INTO original_task,original_root,original_attempt_id,original_grant
  FROM os_input_reviewed_effect_attempts b
  JOIN os_execution_grants g ON g.id=b.grant_id WHERE b.id=d.reviewed_binding_id;
  SELECT p.payload INTO receipt FROM os_input_reviewed_receipt_projections p WHERE
   (p.installation_id,p.application_id,p.tenant_id,p.subject_id,p.id,p.binding_id,p.observation_digest)=
   (d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.reviewed_projection_id,d.reviewed_binding_id,d.observation_digest)
   AND NOT EXISTS(SELECT 1 FROM os_input_reviewed_receipt_projections x WHERE x.binding_id=p.binding_id AND x.ordinal>p.ordinal);
 END IF;
 SELECT * INTO original_work FROM os_work_attempts WHERE id=original_attempt_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=d.root_id FOR UPDATE;
 SELECT * INTO inv FROM os_registered_inverses WHERE
  (installation_id,application_id,registration_revision,capability_ref)=
  (d.installation_id,d.application_id,d.registration_revision,d.capability_ref);
 now_at=clock_timestamp();
 IF COALESCE((app.active AND owner.active AND NOT login.revoked AND login.expires_at>now_at
  AND app.revision=d.registration_revision AND app.generation=(a->>'applicationGeneration')::bigint
  AND owner.generation=(a->>'subjectGeneration')::bigint
  AND owner.host_policy_generation=(a->>'policyGeneration')::bigint
  AND login.session_generation=(a->>'sessionGeneration')::bigint AND login.host_session_ref=a->>'hostSessionRef'
  AND a->'subject'=jsonb_build_object('installationId',d.installation_id,'applicationId',d.application_id,'tenantId',d.tenant_id,'subjectId',d.subject_id)
  AND original_work.state='SETTLED' AND original_work.actual IS NOT NULL
  AND original_work.task_id=d.parent_task_id AND original_work.root_id=d.root_id
  AND original_task=d.parent_task_id AND original_root=d.root_id
  AND original_grant->>'proposalId'=(CASE WHEN d.original_kind='agent-reviewed' THEN d.production_review_id ELSE d.original_proposal_id END)::text AND original_grant->>'capabilityRef'=d.capability_ref
  AND receipt->>'status'='COMMITTED' AND receipt->>'receiptId'=d.original_receipt_id::text
  AND (receipt->>'version')::bigint=d.original_receipt_version
  AND receipt->>'invocationId'=original_work.invocation_id::text
  AND receipt->>'requestDigest'=original_grant->>'effectRequestDigest'
  AND inv.profile_ref='typed-update-restore/1' AND inv.provider_ref=original_grant->>'providerRef'
  AND r.state='ACTIVE' AND r.profile_ref=(CASE WHEN d.original_kind='agent-reviewed' THEN 'agent-production/1' ELSE 'local-amendable-synthetic/1' END) AND r.root_task_id=d.parent_task_id
  AND r.definition_digest=d.definition_digest AND r.deadline=d.expires_at AND r.deadline>now_at
  AND parent.state IN ('COMPLETED','FAILED') AND parent.budget_root_id=r.id AND parent.deadline=r.deadline
  AND t.budget_root_id=r.id AND t.deadline=r.deadline AND t.id<>parent.id
  AND (d.original_kind='agent-reviewed' OR (
   (r.ceiling->>'children')::bigint>=1 AND (r.ceiling->>'stages')::bigint>=2
   AND (r.ceiling->>'toolCalls')::bigint>=5 AND (r.ceiling->>'repairs')::bigint>=1))),false) IS NOT TRUE
 THEN RAISE EXCEPTION 'repair_current_original_root'; END IF;
 IF NOT EXISTS(SELECT 1 FROM os_workload_bindings w WHERE
  (w.installation_id,w.application_id,w.tenant_id,w.subject_id,w.task_id,w.parent_task_id,w.root_id,w.node_ref)=
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.task_id,d.parent_task_id,d.root_id,'repair/'||d.id::text))
 THEN RAISE EXCEPTION 'repair_child_lineage'; END IF;
 IF d.original_kind<>'agent-reviewed' AND (r.spent->>'children')::bigint < (SELECT count(*) FROM os_workload_bindings WHERE root_id=r.id AND parent_task_id IS NOT NULL)
 THEN RAISE EXCEPTION 'repair_child_charge'; END IF;
 IF d.original_kind='agent-reviewed' THEN
  IF NOT COALESCE(r.accounting_format='agent-resources/1'
   AND ROW(original_work.installation_id,original_work.application_id,original_work.tenant_id,original_work.subject_id)=
    ROW(d.installation_id,d.application_id,d.tenant_id,d.subject_id)
   AND original_grant->>'reviewId'=d.production_review_id::text
   AND d.id=os_query_source_uuid5(d.production_projection_id,'agent-typed-update-repair/1')
   AND d.task_id=os_query_source_uuid5(d.id,'child/1') AND d.segment_id=os_query_source_uuid5(d.id,'prepare-segment/1')
   AND d.session_id=(a->>'sessionId')::uuid AND d.authority=a
   AND d.repair_digest=os_agent_profile_digest('command',jsonb_build_object(
    'profileRef','agent-typed-update-repair/1','id',d.id,'subject',a->'subject','taskId',d.task_id,
    'parentTaskId',d.parent_task_id,'rootId',d.root_id,'segmentId',d.segment_id,'original',d.production_original,
    'createdAt',regexp_replace(to_char(d.created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'[.]000000Z$','Z'),
    'expiresAt',regexp_replace(to_char(d.expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'[.]000000Z$','Z')))
   AND EXISTS(SELECT 1 FROM os_admissions admitted JOIN os_agent_repair_roots policy ON policy.admission_id=admitted.id
    JOIN os_agent_reviews review ON review.id=d.production_review_id
    WHERE admitted.id=r.admission_id AND admitted.authority=a AND policy.root_id=r.id
     AND policy.policy=jsonb_build_object('profileRef','agent-original-root-repair/1','context',admitted.context,
      'maxRepairs',1,'inverseProfile','typed-update-restore/1')
     AND policy.digest=os_agent_profile_digest('policy',policy.policy)
     AND review.root_id=r.id AND review.task_id=d.parent_task_id AND review.payload->'context'=admitted.context)
   AND EXISTS(SELECT 1 FROM os_agent_group_accounts groups JOIN os_agent_resource_accounts account ON account.id=groups.account_id
    WHERE groups.root_id=r.id AND account.root_id=r.id AND groups.protocol='resource-groups/1')
   AND NOT EXISTS(SELECT 1 FROM os_work_attempts held WHERE held.root_id=r.id AND held.state IN ('RESERVED','RUNNING','UNKNOWN')
    AND NOT (held.task_id=d.task_id AND held.state IN ('RESERVED','RUNNING') AND (
     held.kind='agent.repair' AND EXISTS(SELECT 1 FROM os_repair_work binding WHERE binding.attempt_id=held.id AND binding.admission_id=d.id)
     OR held.kind='agent.storage' AND EXISTS(SELECT 1 FROM os_agent_payload_writes write WHERE write.attempt_id=held.id
      AND write.id=os_query_source_uuid5(d.id,'prepared-content/1') AND write.root_id=r.id AND write.task_id=d.task_id
      AND write.schema_ref='AgentRepairPreparedContent' AND write.schema_version=1)))),false)
   THEN RAISE EXCEPTION 'agent_repair_original_finite_binding'; END IF;
 END IF;
END $function$
;
CREATE OR REPLACE FUNCTION public.os_assert_repair_grant(g os_repair_grants)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE d os_repair_admissions%ROWTYPE; p os_repair_prepared%ROWTYPE;
 approval os_repair_approvals%ROWTYPE; q os_repair_challenges%ROWTYPE; reg os_repair_registrations%ROWTYPE;
 now_at timestamptz;
BEGIN
 SELECT * INTO d FROM os_repair_admissions WHERE id=g.admission_id;
 PERFORM os_assert_repair_current(d,g.payload->'authority');
 SELECT * INTO approval FROM os_repair_approvals WHERE id=g.approval_id;
 SELECT * INTO p FROM os_repair_prepared WHERE id=approval.prepared_id;
 SELECT * INTO q FROM os_repair_challenges WHERE id=approval.challenge_id;
 SELECT * INTO reg FROM os_repair_registrations WHERE challenge_id=q.id;
 now_at=clock_timestamp();
 IF COALESCE((approval.decision='approve' AND approval.admission_id=d.id AND p.admission_id=d.id
  AND q.admission_id=d.id AND q.prepared_id=p.id AND approval.claim->'binding'=q.binding
  AND approval.claim->>'decision'='approve' AND approval.attestation->>'decision'='approve'
  AND approval.attestation->>'bindingDigest'=q.binding_digest
  AND reg.binding_digest=q.binding_digest AND reg.registration->>'bindingDigest'=q.binding_digest
  AND reg.registration->>'challengeId'=q.id::text AND reg.registration->>'expiresAt'=q.binding->>'expiresAt'
  AND q.binding->>'proposalId'=p.proposal_id::text AND q.binding->>'proposalDigest'=p.proposal_digest
  AND q.binding->>'proposalRevision'='1' AND q.binding->>'challengeId'=q.id::text
  AND q.session_id=(g.payload->'authority'->>'sessionId')::uuid
  AND g.payload->>'id'=g.id::text AND g.payload->>'repairId'=d.id::text
  AND g.payload->>'taskId'=d.task_id::text AND g.payload->>'parentTaskId'=d.parent_task_id::text
  AND g.payload->>'rootId'=d.root_id::text AND g.payload->>'segmentId'=approval.successor_segment_id::text
  AND g.payload->>'preparedId'=p.id::text AND g.payload->>'approvalId'=approval.id::text
  AND g.payload->>'grantDigest'=g.grant_digest AND g.payload->>'profileRef'=(CASE WHEN d.original_kind='agent-reviewed' THEN 'agent-typed-update-repair-execution/1' ELSE 'typed-update-repair-execution/1' END)
  AND g.payload->'subject'=g.payload->'authority'->'subject'
  AND (d.original_kind<>'agent-reviewed' OR g.grant_digest=os_agent_profile_digest('command',g.payload-'grantDigest'))
  AND g.payload->>'bundleRevision'=(CASE WHEN d.original_kind='agent-reviewed' THEN '8' ELSE '7' END) AND g.payload->>'controlEpoch'='1'
  AND g.payload->>'proposalId'=p.proposal_id::text AND g.payload->>'proposalDigest'=p.proposal_digest
  AND g.payload->>'proposalRevision'='1' AND g.payload->>'stageId'=p.stage_id::text
  AND g.payload->>'capabilityRef'=d.capability_ref AND g.payload->>'definitionDigest'=d.definition_digest
  AND g.payload->>'registrationRevision'=d.registration_revision::text
  AND g.payload->>'originalReceiptId'=d.original_receipt_id::text
  AND g.payload->>'originalReceiptVersion'=d.original_receipt_version::text
  AND g.payload->>'invocationId'<>(CASE WHEN d.original_kind='agent-reviewed' THEN d.production_original->>'invocationId' WHEN d.original_kind='input-delegated' THEN
    (SELECT payload->>'invocationId' FROM os_input_delegated_receipts WHERE id=d.delegated_projection_id)
    ELSE (SELECT payload->>'invocationId' FROM os_input_reviewed_receipt_projections WHERE id=d.reviewed_projection_id) END)
  AND g.payload->'authorization'=jsonb_build_object('kind','review_decision','decision',approval.decision_ref)
  AND approval.decision_ref->>'id'=approval.id::text AND approval.decision_ref->>'proposalId'=p.proposal_id::text
  AND approval.decision_ref->>'digest'=p.proposal_digest AND approval.decision_ref->>'proposalRevision'='1'
  AND approval.decision_ref->>'assuranceRef'='local-synthetic'
  AND (approval.decision_ref->>'expiresAt')::timestamptz=g.expires_at
  AND (g.payload->>'createdAt')::timestamptz=g.created_at AND (g.payload->>'expiresAt')::timestamptz=g.expires_at
  AND g.created_at<=now_at AND g.expires_at>now_at AND g.expires_at<=approval.expires_at
  AND g.expires_at<=q.expires_at AND g.expires_at<=p.expires_at AND g.expires_at<=d.expires_at),false) IS NOT TRUE
  OR EXISTS(SELECT 1 FROM os_repair_revocations WHERE approval_id=approval.id)
 THEN RAISE EXCEPTION 'repair_fresh_grant'; END IF;
END $function$
;
CREATE OR REPLACE FUNCTION public.os_guard_repair_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE d os_repair_admissions%ROWTYPE; p os_repair_prepared%ROWTYPE; b os_repair_work%ROWTYPE;
 w os_work_attempts%ROWTYPE; q os_repair_challenges%ROWTYPE; approval os_repair_approvals%ROWTYPE;
 g os_repair_grants%ROWTYPE; artifact os_artifacts%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 command os_commands%ROWTYPE; now_at timestamptz;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_repair_admissions' THEN
  PERFORM os_assert_repair_current(NEW,NEW.authority);
  SELECT * INTO command FROM os_commands WHERE id=NEW.command_id;
  IF command.kind<>(CASE WHEN NEW.original_kind='agent-reviewed' THEN 'agent.repair.admit' ELSE 'repair.admit' END) OR command.accepted_task_id<>NEW.task_id OR command.request_digest<>NEW.command_digest
   OR NEW.session_id IS DISTINCT FROM (NEW.authority->>'sessionId')::uuid
   OR NEW.created_at>clock_timestamp() OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state='ACCEPTED')
  THEN RAISE EXCEPTION 'repair_admission_binding'; END IF;
  IF NEW.original_kind='agent-reviewed' THEN
   IF NEW.command_digest<>os_agent_profile_digest('command',jsonb_build_object('commandId',command.command_id,'original',NEW.production_original))
    OR EXISTS(SELECT 1 FROM os_budget_roots root,jsonb_each(root.outstanding) held WHERE root.id=NEW.root_id AND held.value<>'0'::jsonb)
    OR EXISTS(SELECT 1 FROM os_budget_roots root JOIN os_admissions admitted ON admitted.id=root.admission_id,
     jsonb_each(jsonb_build_object('workMs',70000+(admitted.bot->'resources'->>'requestTimeoutMs')::bigint,
      'computeMs',(admitted.bot->'resources'->>'requestTimeoutMs')::bigint,'storageBytes',2101248)) needed
     WHERE root.id=NEW.root_id AND (root.spent->>needed.key)::bigint+(needed.value::text)::bigint>
      (root.ceiling->>needed.key)::bigint+COALESCE((root.granted->>needed.key)::bigint,0))
    THEN RAISE EXCEPTION 'agent_repair_original_allowance'; END IF;
  END IF;
 ELSIF TG_TABLE_NAME='os_repair_work' OR TG_TABLE_NAME='os_work_attempts' THEN
  IF TG_TABLE_NAME='os_repair_work' THEN b=NEW;
  ELSE
   SELECT * INTO b FROM os_repair_work WHERE attempt_id=NEW.id;
   IF b.id IS NULL THEN
    SELECT * INTO d FROM os_repair_admissions WHERE task_id=NEW.task_id;
    IF d.id IS NOT NULL AND NOT COALESCE(d.original_kind='agent-reviewed' AND NEW.kind='agent.storage'
     AND NEW.accounting_format='agent-resources/1' AND NEW.root_id=d.root_id AND NEW.segment_id=d.segment_id
     AND NEW.control_epoch=1 AND EXISTS(SELECT 1 FROM os_agent_payload_writes write
      WHERE write.attempt_id=NEW.id AND write.id=os_query_source_uuid5(d.id,'prepared-content/1')
       AND write.root_id=d.root_id AND write.task_id=d.task_id AND write.segment_id=d.segment_id
       AND write.schema_ref='AgentRepairPreparedContent' AND write.schema_version=1),false)
     THEN RAISE EXCEPTION 'repair_orphan_work'; END IF;
    RETURN NULL;
   END IF;
   IF TG_OP='UPDATE' AND (NEW.state<>'RUNNING' OR OLD.state=NEW.state) THEN RETURN NULL; END IF;
  END IF;
  SELECT * INTO d FROM os_repair_admissions WHERE id=b.admission_id;
  PERFORM os_assert_repair_current(d,b.authority);
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  IF w.task_id<>d.task_id OR w.root_id<>d.root_id OR w.control_epoch<>1 OR w.lease_until<=clock_timestamp()
   OR w.lease_until>d.expires_at OR w.created_at<>b.created_at OR w.actual IS NOT NULL
   OR w.state<>(CASE WHEN TG_TABLE_NAME='os_work_attempts' AND TG_OP='UPDATE' THEN 'RUNNING' ELSE 'RESERVED' END)
   OR b.session_id IS DISTINCT FROM (b.authority->>'sessionId')::uuid
  THEN RAISE EXCEPTION 'repair_work_binding'; END IF;
  IF d.original_kind='agent-reviewed' THEN
   IF NOT COALESCE(w.kind='agent.repair' AND w.accounting_format='agent-resources/1'
    AND w.reserved=jsonb_build_object('tokens',0,'costMicros',0,'computeMs',0,'storageBytes',0,'workMs',(w.reserved->>'workMs')::bigint)
    AND (w.reserved->>'workMs')::bigint BETWEEN 1 AND CASE WHEN b.phase='prepare' THEN 25000 ELSE 45000 END
    AND w.request_digest=os_agent_profile_digest('command',jsonb_build_object('schema','agent-resource-reservation/1',
     'taskId',w.task_id,'segmentId',w.segment_id,'epoch',1,'invocationId',w.invocation_id,'kind','agent.repair',
     'inputDigest',os_agent_profile_digest('command',jsonb_build_object('profile','agent-repair-work/1','repairDigest',d.repair_digest,
      'phase',b.phase,'workMs',(w.reserved->>'workMs')::bigint,'grantId',b.grant_id)),
     'units',w.reserved,'timeoutMs',(w.reserved->>'workMs')::bigint)),false)
    THEN RAISE EXCEPTION 'agent_repair_work_binding'; END IF;
   IF b.phase='prepare' THEN
    IF w.segment_id<>d.segment_id OR w.invocation_id<>os_query_source_uuid5(d.id,'preparation/1')
     OR b.grant_id IS NOT NULL OR b.permit_id IS NOT NULL THEN RAISE EXCEPTION 'agent_repair_preparation_binding'; END IF;
   ELSE
    SELECT * INTO g FROM os_repair_grants WHERE id=b.grant_id;
    PERFORM os_assert_repair_grant(g);
    IF NOT COALESCE(g.admission_id=d.id AND b.authority=g.payload->'authority'
     AND w.invocation_id::text=g.payload->>'invocationId' AND b.effect_request_digest=g.payload->>'effectRequestDigest'
     AND w.segment_id::text=g.payload->>'segmentId' AND w.lease_until<=g.expires_at
     AND b.permit_id=os_query_source_uuid5(w.id,'repair-permit/1'),false)
     THEN RAISE EXCEPTION 'agent_repair_effect_binding'; END IF;
   END IF;
  ELSIF b.phase='prepare' THEN
   IF w.kind<>'read' OR w.segment_id<>d.segment_id OR (w.reserved->>'workMs')::bigint NOT BETWEEN 1 AND 25000
    OR w.reserved<>jsonb_build_object('stages',0,'children',0,'tokens',0,'toolCalls',2,'nativeJobs',0,'costMicros',0,'workMs',(w.reserved->>'workMs')::bigint,'repairs',0,'planRevisions',0)
   THEN RAISE EXCEPTION 'repair_preparation_budget'; END IF;
  ELSE
   SELECT * INTO g FROM os_repair_grants WHERE id=b.grant_id;
   PERFORM os_assert_repair_grant(g);
   IF g.admission_id<>d.id OR b.authority<>g.payload->'authority' OR w.kind<>'effect'
    OR w.invocation_id::text<>g.payload->>'invocationId' OR b.effect_request_digest<>g.payload->>'effectRequestDigest'
    OR w.segment_id::text<>g.payload->>'segmentId' OR w.lease_until>g.expires_at
    OR (w.reserved->>'workMs')::bigint NOT BETWEEN 1 AND 45000
    OR w.reserved<>jsonb_build_object('stages',1,'children',0,'tokens',0,'toolCalls',1,'nativeJobs',0,'costMicros',0,'workMs',(w.reserved->>'workMs')::bigint,'repairs',1,'planRevisions',0)
   THEN RAISE EXCEPTION 'repair_effect_budget'; END IF;
  END IF;
  IF w.lease_until>w.created_at+((w.reserved->>'workMs')::bigint*interval '1 millisecond')
   OR NOT EXISTS(SELECT 1 FROM os_segments WHERE id=w.segment_id AND task_id=d.task_id AND state='OPEN')
   OR EXISTS(SELECT 1 FROM os_budget_roots r,jsonb_object_keys(w.reserved) k WHERE r.id=d.root_id AND (r.outstanding->>k)::bigint<(w.reserved->>k)::bigint)
  THEN RAISE EXCEPTION 'repair_original_reservation'; END IF;
 ELSIF TG_TABLE_NAME='os_repair_prepared' THEN
  SELECT * INTO d FROM os_repair_admissions WHERE id=NEW.admission_id;
  SELECT * INTO b FROM os_repair_work WHERE id=NEW.work_binding_id;
  PERFORM os_assert_repair_current(d,b.authority);
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  SELECT * INTO artifact FROM os_artifacts WHERE id=NEW.artifact_id;
  IF b.phase<>'prepare' OR b.admission_id<>d.id OR w.state<>'SETTLED' OR w.lease_until<=clock_timestamp()
   OR artifact.purpose<>'artifact' OR artifact.classification<>'protected' OR artifact.ciphertext_digest<>NEW.ciphertext_digest
   OR (CASE WHEN d.original_kind='agent-reviewed' THEN NOT COALESCE(
    NEW.expires_at<=artifact.expires_at AND EXISTS(SELECT 1 FROM os_agent_private_payloads ready
     JOIN os_agent_payload_writes write ON write.id=ready.write_id JOIN os_work_attempts storage ON storage.id=write.attempt_id
     WHERE ready.id=artifact.id AND ready.root_id=d.root_id AND ready.ciphertext_digest=NEW.ciphertext_digest
      AND write.id=os_query_source_uuid5(d.id,'prepared-content/1') AND write.root_id=d.root_id AND write.task_id=d.task_id
      AND write.segment_id=d.segment_id AND write.schema_ref='AgentRepairPreparedContent' AND write.schema_version=1
      AND storage.state='SETTLED' AND storage.actual IS NOT NULL),false)
    ELSE artifact.expires_at<>NEW.expires_at END) OR NEW.expires_at>d.expires_at OR NEW.expires_at<=clock_timestamp()
   OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=d.task_id AND state='WAITING_APPROVAL')
  THEN RAISE EXCEPTION 'repair_prepared_result'; END IF;
 ELSIF TG_TABLE_NAME='os_repair_challenges' OR TG_TABLE_NAME='os_repair_registrations' OR TG_TABLE_NAME='os_repair_approvals' THEN
  IF TG_TABLE_NAME='os_repair_challenges' THEN q=NEW;
  ELSE SELECT * INTO q FROM os_repair_challenges WHERE id=NEW.challenge_id; END IF;
  SELECT * INTO d FROM os_repair_admissions WHERE id=q.admission_id;
  SELECT * INTO p FROM os_repair_prepared WHERE id=q.prepared_id;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=q.session_id;
  PERFORM os_assert_repair_current(d,jsonb_build_object('subject',q.binding->'subject','sessionId',q.session_id,
   'sessionGeneration',session.session_generation,'applicationGeneration',session.application_generation,'subjectGeneration',session.subject_generation,
   'hostSessionRef',q.binding->>'hostSessionRef','profileRef',CASE WHEN d.original_kind='agent-reviewed' THEN d.authority->>'profileRef' ELSE 'local-synthetic' END,
   'policyGeneration',(q.binding->>'policyGeneration')::bigint));
  now_at=clock_timestamp();
  SELECT * INTO command FROM os_commands WHERE id=q.command_id;
  IF COALESCE((q.binding->>'challengeId'=q.id::text AND q.binding->>'sessionId'=q.session_id::text
   AND q.binding->>'proposalId'=p.proposal_id::text AND q.binding->>'proposalDigest'=p.proposal_digest
   AND q.binding->>'proposalRevision'='1' AND q.binding->>'requiredAssurance'='local-synthetic'
   AND q.binding->>'assuranceProfile'='local-synthetic-assurance/1'
   AND length(q.binding->>'nonce') BETWEEN 32 AND 128 AND p.admission_id=d.id
   AND (q.binding->>'createdAt')::timestamptz=q.created_at AND (q.binding->>'expiresAt')::timestamptz=q.expires_at
   AND q.expires_at>now_at AND q.expires_at<=p.expires_at AND q.expires_at<=session.expires_at
   AND (q.binding->>'sessionGeneration')::bigint=session.session_generation),false) IS NOT TRUE
   OR command.kind<>'repair.challenge' OR command.accepted_task_id<>d.task_id OR command.request_digest<>q.command_digest
  THEN RAISE EXCEPTION 'repair_fresh_challenge'; END IF;
  IF (SELECT count(*) FROM os_repair_challenges WHERE admission_id=d.id)>8 THEN RAISE EXCEPTION 'repair_challenge_ceiling'; END IF;
  IF TG_TABLE_NAME='os_repair_registrations' THEN
   IF NEW.binding_digest<>q.binding_digest OR NEW.registration<>jsonb_build_object('challengeId',q.id,'bindingDigest',q.binding_digest,'expiresAt',q.binding->>'expiresAt')
   THEN RAISE EXCEPTION 'repair_registered_challenge'; END IF;
  END IF;
  IF TG_TABLE_NAME='os_repair_approvals' THEN
   SELECT * INTO command FROM os_commands WHERE id=NEW.command_id;
   IF COALESCE((NEW.admission_id=d.id AND NEW.prepared_id=p.id AND NEW.claim->'binding'=q.binding
    AND NEW.claim->>'decision'=NEW.decision AND NEW.claim->>'commandDigest'=NEW.command_digest
    AND NEW.attestation->>'bindingDigest'=q.binding_digest AND NEW.attestation->>'subject'=q.binding->>'subject'
    AND NEW.attestation->>'sessionId'=q.session_id::text AND NEW.attestation->>'challengeId'=q.id::text
    AND NEW.attestation->>'decision'=NEW.decision AND NEW.attestation->>'commandDigest'=NEW.command_digest
    AND NEW.attestation->>'assertionRef'=NEW.claim->>'assertionRef' AND NEW.attestation->>'commandId'=NEW.claim->>'commandId'
    AND command.kind='repair.approval' AND command.accepted_task_id=d.task_id AND command.request_digest=NEW.command_digest
    AND NEW.claim->>'commandId'=command.command_id::text
    AND (NEW.attestation->>'observedAt')::timestamptz BETWEEN now_at-interval '5 seconds' AND now_at+interval '1 second'
    AND NEW.expires_at>now_at AND NEW.expires_at<=q.expires_at AND NEW.expires_at<=(NEW.attestation->>'expiresAt')::timestamptz
    AND EXISTS(SELECT 1 FROM os_repair_registrations WHERE challenge_id=q.id AND binding_digest=q.binding_digest)),false) IS NOT TRUE
   THEN RAISE EXCEPTION 'repair_fresh_approval'; END IF;
  END IF;
 ELSIF TG_TABLE_NAME='os_repair_grants' THEN PERFORM os_assert_repair_grant(NEW);
 ELSIF TG_TABLE_NAME='os_repair_revocations' THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE
   (installation_id,application_id,tenant_id,subject_id,id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
  IF session.revoked OR session.expires_at<=clock_timestamp() OR session.id IS NULL
   OR NOT EXISTS(SELECT 1 FROM os_applications a JOIN os_subjects s ON s.installation_id=a.installation_id AND s.application_id=a.id
    WHERE (s.installation_id,s.application_id,s.tenant_id,s.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
    AND a.active AND s.active AND a.generation=session.application_generation AND s.generation=session.subject_generation)
  THEN RAISE EXCEPTION 'repair_revocation_owner'; END IF;
 ELSE
  SELECT * INTO b FROM os_repair_work WHERE id=NEW.binding_id;
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  SELECT * INTO g FROM os_repair_grants WHERE id=b.grant_id;
  IF COALESCE((b.phase='effect' AND w.state IN ('RUNNING','UNKNOWN','SETTLED')
   AND NEW.payload->>'providerRef'=g.payload->>'providerRef' AND NEW.payload->'subject'=g.payload->'subject'
   AND NEW.payload->>'invocationId'=g.payload->>'invocationId' AND NEW.payload->>'requestDigest'=g.payload->>'effectRequestDigest'
   AND NEW.payload->>'attestationProfile'='atomic-host-receipt-observation/1'),false) IS NOT TRUE
  THEN RAISE EXCEPTION 'repair_admitted_receipt_only'; END IF;
 END IF;
 RETURN NULL;
END $function$
;
"""

COMPLETION_GUARDS=r"""
CREATE FUNCTION os_check_agent_repair_completion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_repair_admissions%ROWTYPE;r os_budget_roots%ROWTYPE;b os_repair_work%ROWTYPE;
 w os_work_attempts%ROWTYPE;p os_repair_receipts%ROWTYPE;approved os_repair_approvals%ROWTYPE;known_no_effect boolean;
BEGIN
 IF NEW.state NOT IN ('COMPLETED','FAILED','CANCELLED') THEN RETURN NULL; END IF;
 SELECT * INTO d FROM os_repair_admissions WHERE
  ROW(installation_id,application_id,tenant_id,subject_id,task_id)=
   ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.id)
  AND original_kind='agent-reviewed';
 IF d.id IS NULL THEN RETURN NULL; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO r FROM os_budget_roots WHERE id=d.root_id;
 IF NOT COALESCE(r.accounting_format='agent-resources/1' AND r.profile_ref='agent-production/1'
  AND r.state<>'QUARANTINED' AND NEW.budget_root_id=r.id AND NEW.deadline=r.deadline AND d.expires_at=r.deadline
  AND EXISTS(SELECT 1 FROM os_agent_repair_roots policy WHERE policy.root_id=r.id AND policy.admission_id=r.admission_id)
  AND NOT EXISTS(SELECT 1 FROM jsonb_each(r.outstanding) held WHERE held.value<>'0'::jsonb)
  AND NOT EXISTS(SELECT 1 FROM os_work_attempts work WHERE work.root_id=r.id AND work.state NOT IN ('SETTLED','RELEASED')),false)
 THEN RAISE EXCEPTION 'agent_repair_terminal_usage'; END IF;
 SELECT * INTO b FROM os_repair_work WHERE
  ROW(installation_id,application_id,tenant_id,subject_id,admission_id)=
   ROW(d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.id) AND phase='effect';
 SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
 SELECT * INTO p FROM os_repair_receipts WHERE
  ROW(installation_id,application_id,tenant_id,subject_id,binding_id)=
   ROW(d.installation_id,d.application_id,d.tenant_id,d.subject_id,b.id) ORDER BY ordinal DESC LIMIT 1;
 SELECT * INTO approved FROM os_repair_approvals WHERE
  ROW(installation_id,application_id,tenant_id,subject_id,admission_id)=
   ROW(d.installation_id,d.application_id,d.tenant_id,d.subject_id,d.id);
 known_no_effect:=COALESCE(w.state='RELEASED' OR w.state='SETTLED' AND w.actual IS NOT NULL
   AND p.payload->>'status' IN ('REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED'),false);
 IF NEW.state='COMPLETED' THEN
  IF NOT COALESCE(w.state='SETTLED' AND w.actual IS NOT NULL AND p.payload->>'status'='COMMITTED',false)
   THEN RAISE EXCEPTION 'agent_repair_terminal_outcome'; END IF;
 ELSIF NEW.state='FAILED' THEN
  IF NOT COALESCE(approved.decision='reject' AND b.id IS NULL OR known_no_effect,false)
   THEN RAISE EXCEPTION 'agent_repair_terminal_outcome'; END IF;
 ELSE
  IF NOT COALESCE((b.id IS NULL OR known_no_effect) AND (
   EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=d.task_id AND state='STOP_ACKNOWLEDGED')
   OR EXISTS(SELECT 1 FROM os_repair_revocations WHERE approval_id=approved.id)),false)
   THEN RAISE EXCEPTION 'agent_repair_terminal_outcome'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_repair_completion AFTER INSERT OR UPDATE ON os_tasks
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_repair_completion();
"""


def upgrade():
    op.execute(TABLES)
    op.execute(ROOT_GUARDS)
    op.execute(REVIEW_GUARD)
    op.execute(GROUP_GUARDS)
    op.execute(PHASE_GUARDS)
    op.execute(COMPLETION_GUARDS)


def downgrade():
    raise RuntimeError('Production repair requires protected forward recovery')
