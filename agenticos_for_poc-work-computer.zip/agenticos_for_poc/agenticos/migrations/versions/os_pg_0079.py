"""Draft original-root focused child scope and expanded-operation indexes.

Not applied or frozen. Representative positive/negative runtime and protected
populated rollback/forward/independent recovery remain required.
"""
from alembic import op

revision='os_pg_0079'
down_revision='os_pg_0078'
branch_labels=None
depends_on=None

TABLES=r"""
CREATE TABLE os_agent_child_policies (
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	policy_digest VARCHAR(64) NOT NULL, 
	application_generation BIGINT NOT NULL, 
	registration_revision BIGINT NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	payload JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (installation_id, application_id, policy_digest), 
	CONSTRAINT fk_agent_child_policy_app FOREIGN KEY(installation_id, application_id) REFERENCES os_applications (installation_id, id), 
	CONSTRAINT ck_agent_child_policy_bounds CHECK (application_generation>0 AND registration_revision>0 AND jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536), 
	CONSTRAINT ck_agent_child_policy_pin_digest CHECK (policy_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_child_policy_digest CHECK (digest ~ '^[a-f0-9]{64}$')
);

CREATE TABLE os_agent_child_roots (
	id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	policy_digest VARCHAR(64) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_child_root_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_child_root_policy FOREIGN KEY(installation_id, application_id, policy_digest) REFERENCES os_agent_child_policies (installation_id, application_id, policy_digest), 
	CONSTRAINT uq_agent_child_root UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id), 
	CONSTRAINT uq_agent_child_root_fence UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id)
);

CREATE TABLE os_agent_child_reads (
	id UUID NOT NULL, 
	root_binding_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	task_id UUID NOT NULL, 
	sdk_instance_id UUID NOT NULL, 
	parent_operation_id UUID NOT NULL, 
	parent_acceptance_id UUID NOT NULL, 
	scope_write_id UUID NOT NULL, 
	scope_digest VARCHAR(64) NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	version BIGINT NOT NULL, 
	checkpoint_write_id UUID, 
	candidate_acceptance_id UUID, 
	verification_write_id UUID, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_child_read_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_child_read_original_root FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_binding_id, root_id) REFERENCES os_agent_child_roots (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT fk_agent_child_read_task FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id, root_id) REFERENCES os_workload_bindings (installation_id, application_id, tenant_id, subject_id, task_id, root_id), 
	CONSTRAINT fk_agent_child_read_parent FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, parent_operation_id, root_id) REFERENCES os_agent_operations (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT fk_os_agent_model_acceptances_parent_acceptance_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, parent_acceptance_id) REFERENCES os_agent_model_acceptances (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_payload_writes_scope_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, scope_write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_payload_writes_checkpoint_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, checkpoint_write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_model_acceptances_candidate_acceptance_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_acceptance_id) REFERENCES os_agent_model_acceptances (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_payload_writes_verification_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, verification_write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_agent_child_read_root UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT uq_agent_child_read_instance UNIQUE (installation_id, application_id, tenant_id, subject_id, sdk_instance_id), 
	CONSTRAINT uq_agent_child_read_scope UNIQUE (installation_id, application_id, tenant_id, subject_id, scope_write_id), 
	CONSTRAINT ck_agent_child_read_state CHECK (state IN ('ACTIVE','COMPLETED','INTERRUPTED') AND version>0 AND updated_at>=created_at AND expires_at>created_at AND ((state='COMPLETED')=(candidate_acceptance_id IS NOT NULL AND verification_write_id IS NOT NULL)) AND ((candidate_acceptance_id IS NULL)=(verification_write_id IS NULL))), 
	CONSTRAINT ck_agent_child_read_scope_digest CHECK (scope_digest ~ '^[a-f0-9]{64}$')
);

CREATE INDEX ix_agent_child_read_active ON os_agent_child_reads (root_id, state, id);

CREATE TABLE os_agent_child_inputs (
	id UUID NOT NULL, 
	child_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	operation_id UUID NOT NULL, 
	turn BIGINT NOT NULL, 
	record_digest VARCHAR(64) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_child_input_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_payload_writes_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_child_input_original_root FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, child_id, root_id) REFERENCES os_agent_child_reads (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT uq_agent_child_input_operation UNIQUE (installation_id, application_id, tenant_id, subject_id, operation_id), 
	CONSTRAINT uq_agent_child_input_turn UNIQUE (installation_id, application_id, tenant_id, subject_id, child_id, turn), 
	CONSTRAINT uq_agent_child_input_fence UNIQUE (installation_id, application_id, tenant_id, subject_id, id, child_id, root_id), 
	CONSTRAINT ck_agent_child_input_turn CHECK (turn BETWEEN 1 AND 9007199254740991), 
	CONSTRAINT ck_agent_child_input_record_digest CHECK (record_digest ~ '^[a-f0-9]{64}$')
);

CREATE TABLE os_agent_child_operations (
	id UUID NOT NULL, 
	child_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	input_id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_child_operation_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_child_operation_original FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, id, root_id) REFERENCES os_agent_operations (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT fk_agent_child_operation_input FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, input_id, child_id, root_id) REFERENCES os_agent_child_inputs (installation_id, application_id, tenant_id, subject_id, id, child_id, root_id), 
	CONSTRAINT uq_agent_child_operation_input UNIQUE (installation_id, application_id, tenant_id, subject_id, input_id)
);

CREATE INDEX ix_agent_child_operation_graph ON os_agent_child_operations (child_id, id);
"""

GUARDS=r"""
CREATE FUNCTION os_guard_agent_child_policy() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_applications%ROWTYPE; p jsonb; adapter jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_child_policy_immutable'; END IF;
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 p:=NEW.payload;
 IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
  AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',p)
  AND p=jsonb_build_object('id',p->'id','revision',p->'revision','harness',p->'harness','scopeProfile','scoped-id-read/1',
   'maxActiveChildren',p->'maxActiveChildren','workTimeoutMs',p->'workTimeoutMs','maxRequestBytes',p->'maxRequestBytes','adapters',p->'adapters')
  AND p->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND (p->>'revision') ~ '^[1-9][0-9]*$' AND (p->>'revision')::numeric<=9007199254740991
  AND p->'harness'=jsonb_build_object('ref','focused-child-reads/1','revision',p->'harness'->'revision','digest',p->'harness'->'digest')
  AND (p->'harness'->>'revision') ~ '^[1-9][0-9]*$' AND p->'harness'->>'digest' ~ '^[a-f0-9]{64}$'
  AND (p->>'maxActiveChildren') ~ '^[1-9][0-9]*$' AND (p->>'maxActiveChildren')::numeric BETWEEN 1 AND 64
  AND (p->>'workTimeoutMs') ~ '^[1-9][0-9]*$' AND (p->>'workTimeoutMs')::numeric BETWEEN 1 AND 900000
  AND (p->>'maxRequestBytes') ~ '^[1-9][0-9]*$' AND (p->>'maxRequestBytes')::numeric BETWEEN 1024 AND 49152
  AND jsonb_typeof(p->'adapters')='array' AND jsonb_array_length(p->'adapters') BETWEEN 1 AND 64,false)
  THEN RAISE EXCEPTION 'agent_child_policy_binding'; END IF;
 FOR adapter IN SELECT value FROM jsonb_array_elements(p->'adapters') LOOP
  IF NOT COALESCE(adapter=jsonb_build_object('capability',adapter->'capability','providerRef',adapter->'providerRef',
    'readProfile',adapter->'readProfile','inputSchemaDigest',adapter->'inputSchemaDigest','resourceTypeField',adapter->'resourceTypeField',
    'externalIdsField',adapter->'externalIdsField','fieldNamesField',adapter->'fieldNamesField')
   AND adapter->>'inputSchemaDigest' ~ '^[a-f0-9]{64}$'
   AND adapter->>'resourceTypeField'<>adapter->>'externalIdsField'
   AND adapter->>'resourceTypeField'<>adapter->>'fieldNamesField'
   AND adapter->>'externalIdsField'<>adapter->>'fieldNamesField'
   AND EXISTS(SELECT 1 FROM os_agent_capabilities capability
    WHERE capability.installation_id=NEW.installation_id AND capability.application_id=NEW.application_id
     AND capability.application_generation=NEW.application_generation AND capability.capability_ref=adapter->'capability'->>'ref'
     AND capability.revision=(adapter->'capability'->>'revision')::bigint
     AND capability.digest=adapter->'capability'->>'digest' AND capability.payload->>'kind'='read'
     AND capability.payload->>'adapterRef'='mcp.read/1' AND capability.payload->>'lifecycle'='qualified')
   AND EXISTS(SELECT 1 FROM os_agent_tool_profiles tool
    WHERE tool.installation_id=NEW.installation_id AND tool.application_id=NEW.application_id
     AND tool.application_generation=NEW.application_generation AND tool.registration_revision=NEW.registration_revision
     AND tool.payload->'read'->'capability'=adapter->'capability'
     AND tool.payload->'read'->>'providerRef'=adapter->>'providerRef' AND tool.payload->'read'->>'outputContract'='EvidencePage/1'
     AND os_agent_profile_digest('manifest',tool.payload->'read')=adapter->'readProfile'->>'digest'),false)
   THEN RAISE EXCEPTION 'agent_child_adapter_binding'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(p->'adapters') value
  GROUP BY value->'capability',value->'providerRef' HAVING count(*)>1)
  THEN RAISE EXCEPTION 'agent_child_adapter_ambiguous'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_child_policy BEFORE INSERT OR UPDATE OR DELETE ON os_agent_child_policies
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_child_policy();

CREATE FUNCTION os_guard_agent_child_root() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; a os_admissions%ROWTYPE; p os_agent_child_policies%ROWTYPE; app os_applications%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_child_root_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id;
 SELECT * INTO p FROM os_agent_child_policies WHERE installation_id=NEW.installation_id
  AND application_id=NEW.application_id AND policy_digest=NEW.policy_digest;
 IF NOT COALESCE(r.accounting_format='agent-resources/1' AND r.profile_ref='agent-production/1' AND r.state='ACTIVE'
  AND r.deadline>clock_timestamp() AND r.root_task_id=a.task_id AND a.context->>'harness' IS NOT NULL
  AND a.context->'harness'=p.payload->'harness' AND a.context->'harness'->>'ref'='focused-child-reads/1'
  AND a.bot->'harness'->'features' ? 'child-workflows' AND app.active
  AND app.generation=p.application_generation AND app.revision=p.registration_revision,false)
  THEN RAISE EXCEPTION 'agent_child_original_root'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_child_root BEFORE INSERT OR UPDATE OR DELETE ON os_agent_child_roots
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_child_root();

CREATE FUNCTION os_guard_agent_child_read() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; binding os_agent_child_roots%ROWTYPE; policy os_agent_child_policies%ROWTYPE;
 w os_agent_payload_writes%ROWTYPE; allowed boolean;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_child_read_retained'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO binding FROM os_agent_child_roots WHERE id=NEW.root_binding_id AND root_id=r.id;
 SELECT * INTO policy FROM os_agent_child_policies WHERE installation_id=binding.installation_id
  AND application_id=binding.application_id AND policy_digest=binding.policy_digest;
 IF TG_OP='INSERT' THEN
  SELECT * INTO w FROM os_agent_payload_writes WHERE id=NEW.scope_write_id;
  IF NOT COALESCE(NEW.state='ACTIVE' AND NEW.version=1 AND NEW.checkpoint_write_id IS NULL
   AND NEW.candidate_acceptance_id IS NULL AND NEW.verification_write_id IS NULL
   AND NEW.updated_at=NEW.created_at AND NEW.created_at>=w.created_at AND NEW.created_at<=clock_timestamp()
   AND NEW.expires_at<=LEAST(r.deadline,NEW.created_at+make_interval(secs=>(policy.payload->>'workTimeoutMs')::numeric/1000))
   AND NEW.expires_at>clock_timestamp() AND r.state='ACTIVE' AND r.root_task_id=NEW.task_id
   AND w.root_id=r.id AND w.task_id=NEW.task_id AND w.schema_ref='AgentChildReadScope' AND w.schema_version=1
   AND w.expires_at>=NEW.expires_at AND EXISTS(SELECT 1 FROM os_agent_private_payloads WHERE write_id=w.id)
   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=w.attempt_id AND state='SETTLED')
   AND EXISTS(SELECT 1 FROM os_agent_operations op JOIN os_agent_operation_models link ON link.operation_id=op.id
    JOIN os_agent_model_acceptances accepted ON accepted.call_id=link.id
    WHERE op.id=NEW.parent_operation_id AND op.root_id=r.id AND op.task_id=NEW.task_id
     AND accepted.id=NEW.parent_acceptance_id AND op.parent_operation_id IS NULL
     AND op.payload->'identity'->>'iteration'='0')
   AND EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=NEW.task_id AND state='ACTIVE'),false)
   THEN RAISE EXCEPTION 'agent_child_read_admission'; END IF;
  IF (SELECT count(*) FROM os_agent_child_reads WHERE root_id=r.id AND state='ACTIVE')
   >=(policy.payload->>'maxActiveChildren')::bigint THEN RAISE EXCEPTION 'agent_child_active_capacity'; END IF;
 ELSE
  IF NOT COALESCE(OLD.state='ACTIVE' AND NEW.version=OLD.version+1 AND NEW.updated_at>=OLD.updated_at
   AND NEW.updated_at<=clock_timestamp()
   AND (to_jsonb(NEW)-ARRAY['state','version','checkpoint_write_id','candidate_acceptance_id','verification_write_id','updated_at'])
    =(to_jsonb(OLD)-ARRAY['state','version','checkpoint_write_id','candidate_acceptance_id','verification_write_id','updated_at']),false)
   THEN RAISE EXCEPTION 'agent_child_read_transition'; END IF;
  IF NEW.checkpoint_write_id IS DISTINCT FROM OLD.checkpoint_write_id AND NOT EXISTS(
   SELECT 1 FROM os_agent_payload_writes payload JOIN os_agent_private_payloads ready ON ready.write_id=payload.id
   JOIN os_work_attempts work ON work.id=payload.attempt_id WHERE payload.id=NEW.checkpoint_write_id
    AND payload.root_id=r.id AND payload.task_id=NEW.task_id AND payload.schema_ref='AgentSDKCheckpointState'
    AND payload.schema_version=1 AND work.state='SETTLED' AND payload.expires_at>clock_timestamp())
   THEN RAISE EXCEPTION 'agent_child_checkpoint_binding'; END IF;
  IF NEW.state='COMPLETED' THEN
   SELECT EXISTS(SELECT 1 FROM os_agent_model_acceptances accepted
    JOIN os_agent_operation_models link ON link.id=accepted.call_id
    JOIN os_agent_child_operations child ON child.id=link.operation_id
    WHERE accepted.id=NEW.candidate_acceptance_id AND child.child_id=NEW.id AND child.root_id=r.id) INTO allowed;
   IF NOT COALESCE(allowed AND EXISTS(SELECT 1 FROM os_agent_payload_writes payload
    JOIN os_agent_private_payloads ready ON ready.write_id=payload.id JOIN os_work_attempts work ON work.id=payload.attempt_id
    WHERE payload.id=NEW.verification_write_id AND payload.root_id=r.id AND payload.task_id=NEW.task_id
     AND payload.schema_ref='AgentChildReadVerification' AND payload.schema_version=1
     AND payload.expires_at>clock_timestamp() AND work.state='SETTLED')
    AND NOT EXISTS(SELECT 1 FROM os_agent_child_operations child JOIN os_agent_operation_models link ON link.operation_id=child.id
     JOIN os_agent_model_calls model ON model.id=link.id JOIN os_work_attempts work ON work.id=model.attempt_id
     WHERE child.child_id=NEW.id AND work.state IN ('RESERVED','RUNNING','UNKNOWN'))
    AND NOT EXISTS(SELECT 1 FROM os_agent_child_operations child JOIN os_agent_tool_operations op ON op.parent_operation_id=child.id
     JOIN os_agent_tool_calls tool ON tool.operation_id=op.id JOIN os_work_attempts work ON work.id=tool.attempt_id
     WHERE child.child_id=NEW.id AND work.state IN ('RESERVED','RUNNING','UNKNOWN')),false)
    THEN RAISE EXCEPTION 'agent_child_completion_incomplete'; END IF;
  ELSIF NEW.state='INTERRUPTED' AND NOT COALESCE(r.deadline<=clock_timestamp() OR NEW.expires_at<=clock_timestamp()
   OR EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=NEW.task_id AND state<>'ACTIVE')
   OR EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state IN ('RECONCILING','FAILED','CANCELLED','EXPIRED','QUARANTINED')),false)
   THEN RAISE EXCEPTION 'agent_child_interruption_unproven'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_child_read BEFORE INSERT OR UPDATE OR DELETE ON os_agent_child_reads
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_child_read();

CREATE FUNCTION os_guard_agent_child_input() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE child os_agent_child_reads%ROWTYPE; w os_agent_payload_writes%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_child_input_immutable'; END IF;
 SELECT * INTO child FROM os_agent_child_reads WHERE id=NEW.child_id;
 SELECT * INTO w FROM os_agent_payload_writes WHERE id=NEW.id;
 IF NOT COALESCE(child.state='ACTIVE' AND child.expires_at>clock_timestamp() AND child.root_id=NEW.root_id
  AND w.root_id=NEW.root_id AND w.task_id=child.task_id AND w.schema_ref='AgentProviderInput' AND w.schema_version=1
  AND EXISTS(SELECT 1 FROM os_agent_private_payloads WHERE write_id=w.id)
  AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=w.attempt_id AND state='SETTLED'),false)
  THEN RAISE EXCEPTION 'agent_child_input_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_child_input BEFORE INSERT OR UPDATE OR DELETE ON os_agent_child_inputs
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_child_input();

CREATE FUNCTION os_guard_agent_child_operation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE child os_agent_child_reads%ROWTYPE; staged os_agent_child_inputs%ROWTYPE; op os_agent_operations%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_child_operation_immutable'; END IF;
 SELECT * INTO child FROM os_agent_child_reads WHERE id=NEW.child_id;
 SELECT * INTO staged FROM os_agent_child_inputs WHERE id=NEW.input_id;
 SELECT * INTO op FROM os_agent_operations WHERE id=NEW.id;
 IF NOT COALESCE(child.state='ACTIVE' AND child.expires_at>clock_timestamp() AND child.root_id=NEW.root_id
  AND staged.operation_id=op.id AND staged.child_id=child.id AND staged.root_id=child.root_id
  AND op.root_id=child.root_id AND op.task_id=child.task_id AND op.digest=staged.record_digest
  AND (op.payload->'identity'->>'iteration')::bigint=staged.turn-1
  AND ((staged.turn=1 AND op.parent_operation_id=child.parent_operation_id AND op.payload->'inputResults'='[]'::jsonb)
   OR (staged.turn>1 AND EXISTS(SELECT 1 FROM os_agent_child_operations previous
    JOIN os_agent_child_inputs previous_input ON previous_input.id=previous.input_id
    JOIN os_agent_operation_models link ON link.operation_id=previous.id
    JOIN os_agent_model_acceptances accepted ON accepted.call_id=link.id
    WHERE previous.id=op.parent_operation_id AND previous.child_id=child.id AND previous_input.turn=staged.turn-1))),false)
  THEN RAISE EXCEPTION 'agent_child_operation_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_child_operation BEFORE INSERT OR UPDATE OR DELETE ON os_agent_child_operations
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_child_operation();

CREATE FUNCTION os_check_agent_child_staged_operation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF EXISTS(SELECT 1 FROM os_agent_child_inputs WHERE operation_id=NEW.id)
  AND NOT EXISTS(SELECT 1 FROM os_agent_child_operations child JOIN os_agent_child_inputs staged ON staged.id=child.input_id
   WHERE child.id=NEW.id AND staged.operation_id=NEW.id AND staged.record_digest=NEW.digest)
  THEN RAISE EXCEPTION 'agent_child_operation_missing'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_child_staged_operation AFTER INSERT ON os_agent_operations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_child_staged_operation();

CREATE FUNCTION os_check_agent_child_model_begin() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE child os_agent_child_reads%ROWTYPE; work os_work_attempts%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT c.* INTO child FROM os_agent_child_reads c JOIN os_agent_child_operations op ON op.child_id=c.id
  JOIN os_agent_operation_models link ON link.operation_id=op.id WHERE link.id=NEW.id;
 IF child.id IS NULL THEN RETURN NEW; END IF;
 SELECT w.* INTO work FROM os_work_attempts w JOIN os_agent_model_calls model ON model.attempt_id=w.id WHERE model.id=NEW.id;
 IF NOT COALESCE(child.state='ACTIVE' AND child.expires_at>clock_timestamp() AND work.lease_until<=child.expires_at,false)
  THEN RAISE EXCEPTION 'agent_child_model_expired'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER check_agent_child_model_begin BEFORE INSERT ON os_agent_model_starts
 FOR EACH ROW EXECUTE FUNCTION os_check_agent_child_model_begin();

CREATE FUNCTION os_check_agent_child_task_completion() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.state<>'COMPLETED' OR OLD.state='COMPLETED' THEN RETURN NULL; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF NOT EXISTS(SELECT 1 FROM os_admissions WHERE task_id=NEW.id AND context->'harness'->>'ref'='focused-child-reads/1')
  THEN RETURN NULL; END IF;
 IF NOT EXISTS(SELECT 1 FROM os_agent_child_reads WHERE task_id=NEW.id)
  OR EXISTS(SELECT 1 FROM os_agent_child_reads WHERE task_id=NEW.id AND state<>'COMPLETED')
  THEN RAISE EXCEPTION 'agent_child_task_incomplete'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_child_task_completion AFTER UPDATE ON os_tasks
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_child_task_completion();
"""


def upgrade():
    op.execute(TABLES)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Child delegation requires protected forward recovery')
