"""Immutable source selector generations over original Root accounting.

Runtime/negative guards, protected rollback, forward/catalog and independent
0081 recovery are required for qualification. Applied bytes remain immutable.
"""
from alembic import op

revision='os_pg_0082'
down_revision='os_pg_0081'
branch_labels=None
depends_on=None

HELPERS=r"""
CREATE FUNCTION os_query_source_uuid5(ns uuid,name text) RETURNS uuid LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE raw bytea;
BEGIN
 raw:=substring(digest(uuid_send(ns)||convert_to(name,'UTF8'),'sha1') from 1 for 16);
 raw:=set_byte(raw,6,(get_byte(raw,6)&15)|80);
 raw:=set_byte(raw,8,(get_byte(raw,8)&63)|128);
 RETURN encode(raw,'hex')::uuid;
END $$;

CREATE FUNCTION os_query_source_payload(wid uuid,expected text,c jsonb,before_at timestamptz)
RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT COALESCE(EXISTS(SELECT 1 FROM os_agent_payload_writes p
  JOIN os_agent_private_payloads f ON f.write_id=p.id JOIN os_artifacts a ON a.id=f.id
  JOIN os_work_attempts w ON w.id=p.attempt_id
  WHERE p.id=wid AND p.root_id=(c->>'rootId')::uuid AND p.task_id=(c->>'taskId')::uuid
   AND p.segment_id=(c->>'segmentId')::uuid AND p.control_epoch=(c->>'controlEpoch')::bigint
   AND p.schema_ref=expected AND p.schema_version=1 AND w.kind='agent.storage'
   AND w.root_id=p.root_id AND w.state='SETTLED' AND p.expires_at>clock_timestamp()
   AND a.expires_at=p.expires_at AND a.ciphertext_digest=f.ciphertext_digest
   AND p.created_at<=f.created_at AND f.created_at<=before_at AND before_at<=clock_timestamp()
   AND ROW(p.installation_id::text,p.application_id::text,p.tenant_id,p.subject_id)=
       ROW(c->'subject'->>'installationId',c->'subject'->>'applicationId',c->'subject'->>'tenantId',c->'subject'->>'subjectId')
   AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=
       ROW(p.installation_id,p.application_id,p.tenant_id,p.subject_id)),false)
$$;

CREATE FUNCTION os_query_source_child_retired(cid uuid,rid uuid,scope text)
RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT COALESCE(EXISTS(SELECT 1 FROM os_agent_query_source_bindings b WHERE b.root_id=rid
   AND b.payload->'retiredChildren' @> jsonb_build_array(jsonb_build_object('childId',cid::text,'scopeDigest',scope)))
  AND NOT EXISTS(SELECT 1 FROM os_work_attempts w WHERE w.root_id=rid AND w.state IN ('RESERVED','RUNNING','UNKNOWN'))
  AND NOT EXISTS(SELECT 1 FROM os_budget_roots r,jsonb_each_text(r.outstanding) v WHERE r.id=rid AND v.value::numeric<>0),false)
$$;
"""

BINDING_GUARD=r"""
CREATE FUNCTION os_guard_query_source_binding() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; a os_admissions%ROWTYPE; prior os_agent_query_source_bindings%ROWTYPE;
 p jsonb; c jsonb; retired jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'query_source_binding_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO prior FROM os_agent_query_source_bindings WHERE root_id=r.id ORDER BY revision DESC LIMIT 1;
 p:=NEW.payload;c:=p->'context';
 SELECT COALESCE(jsonb_agg(jsonb_build_object('childId',id::text,'scopeDigest',scope_digest) ORDER BY id),'[]'::jsonb)
  INTO retired FROM os_agent_child_reads WHERE root_id=r.id AND state='ACTIVE';
 IF NOT COALESCE(r.state='ACTIVE' AND r.root_task_id=NEW.task_id AND a.context=c
  AND c->>'accountingFormat'='agent-resources/1' AND c->'harness'->>'ref'='focused-child-reads/1'
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
      ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
  AND NEW.segment_id=(c->>'segmentId')::uuid AND NEW.intent_revision=(c->>'intentRevision')::bigint
  AND NEW.control_epoch=(c->>'controlEpoch')::bigint AND NEW.created_at<=clock_timestamp()
  AND NEW.created_at>=(c->>'admittedAt')::timestamptz AND NEW.created_at<r.deadline AND NEW.expires_at=r.deadline
  AND EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=NEW.task_id AND state='ACTIVE')
  AND NEW.id=os_query_source_uuid5(NEW.task_id,'query-source-binding/1/'||NEW.candidate_acceptance_id)
  AND NEW.revision=COALESCE(prior.revision,0)+1 AND NEW.previous_id IS NOT DISTINCT FROM prior.id
  AND (prior.id IS NULL OR NEW.created_at>=prior.created_at)
  AND p-ARRAY['context','bindingId','revision','previousId','queryGoalDigest','goalDigest','goalSourceDigest',
      'sourceCandidate','verificationWriteId','goalWriteId','pageNamespace','targetCount','requiredChildren','sourceComplete','retiredChildren']='{}'::jsonb
  AND (SELECT count(*) FROM jsonb_object_keys(p))=15
  AND p->>'bindingId'=NEW.id::text AND (p->>'revision')::bigint=NEW.revision
  AND (p->>'previousId')::uuid IS NOT DISTINCT FROM NEW.previous_id
  AND p->>'goalDigest'=NEW.goal_digest AND p->>'goalSourceDigest' ~ '^[a-f0-9]{64}$'
  AND p->>'queryGoalDigest' ~ '^[a-f0-9]{64}$' AND NEW.payload_digest=os_agent_profile_digest('command',p)
  AND p->>'pageNamespace'=NEW.id::text AND p->'sourceCandidate'->>'resultId'=NEW.candidate_acceptance_id::text
  AND p->>'verificationWriteId'=NEW.verification_write_id::text AND p->>'goalWriteId'=NEW.goal_write_id::text
  AND NEW.verification_write_id=os_query_source_uuid5(NEW.task_id,'verified-query-source/1/'||NEW.id)
  AND NEW.goal_write_id=os_query_source_uuid5(NEW.task_id,'query-source-child-goal/1/'||NEW.id)
  AND jsonb_typeof(p->'targetCount')='number' AND p->>'targetCount' ~ '^[0-9]+$'
  AND (p->>'targetCount')::numeric<=9007199254740991
  AND jsonb_typeof(p->'requiredChildren')='number' AND p->>'requiredChildren' ~ '^[0-9]+$'
  AND (p->>'requiredChildren')::numeric<=9007199254740991 AND jsonb_typeof(p->'sourceComplete')='boolean'
  AND jsonb_typeof(p->'retiredChildren')='array' AND jsonb_array_length(p->'retiredChildren')<=64
  AND p->'retiredChildren'=retired
  AND os_query_source_payload(os_query_source_uuid5(NEW.task_id,'query-source-intent/1'),'AgentQuerySourceIntentRecord',c,NEW.created_at)
  AND os_query_source_payload(NEW.verification_write_id,'AgentQuerySourceVerification',c,NEW.created_at)
  AND os_query_source_payload(NEW.goal_write_id,'AgentQuerySourceGoalRecord',c,NEW.created_at)
  AND NOT EXISTS(SELECT 1 FROM os_agent_model_acceptances accepted
    JOIN os_agent_operation_models link ON link.id=accepted.call_id JOIN os_agent_child_operations child ON child.id=link.operation_id
    WHERE accepted.id=NEW.candidate_acceptance_id),false)
  THEN RAISE EXCEPTION 'query_source_binding_admission'; END IF;
 PERFORM os_assert_agent_input_dependency(p->'sourceCandidate',c,r.id,NEW.created_at);
 RETURN NEW;
END $$;
CREATE TRIGGER guard_query_source_binding BEFORE INSERT OR UPDATE OR DELETE ON os_agent_query_source_bindings
 FOR EACH ROW EXECUTE FUNCTION os_guard_query_source_binding();
"""

WORK_GUARDS=r"""
CREATE FUNCTION os_assert_query_child_current(cid uuid,rid uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE head os_agent_query_source_bindings%ROWTYPE; child os_agent_child_reads%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM 1 FROM os_budget_roots WHERE id=rid FOR UPDATE;
 SELECT * INTO head FROM os_agent_query_source_bindings WHERE root_id=rid ORDER BY revision DESC LIMIT 1;
 IF head.id IS NULL THEN RETURN; END IF;
 SELECT * INTO child FROM os_agent_child_reads WHERE id=cid AND root_id=rid;
 IF NOT COALESCE(child.source_binding_id=head.id AND child.state='ACTIVE'
   AND (head.payload->>'sourceComplete')::boolean AND (head.payload->>'targetCount')::bigint>0,false)
  THEN RAISE EXCEPTION 'query_child_generation_fenced'; END IF;
END $$;

CREATE FUNCTION os_guard_child_source_binding() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE head os_agent_query_source_bindings%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' THEN
  IF NEW.source_binding_id IS DISTINCT FROM OLD.source_binding_id THEN
   RAISE EXCEPTION 'query_child_binding_immutable';
  END IF;
  RETURN NEW;
 END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM 1 FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO head FROM os_agent_query_source_bindings WHERE root_id=NEW.root_id ORDER BY revision DESC LIMIT 1;
 IF NEW.source_binding_id IS DISTINCT FROM head.id
   OR head.id IS NOT NULL AND (NOT (head.payload->>'sourceComplete')::boolean OR (head.payload->>'targetCount')::bigint=0)
  THEN RAISE EXCEPTION 'query_child_binding_admission'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_child_source_binding BEFORE INSERT OR UPDATE ON os_agent_child_reads
 FOR EACH ROW EXECUTE FUNCTION os_guard_child_source_binding();

CREATE FUNCTION os_guard_query_child_operation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM os_assert_query_child_current(NEW.child_id,NEW.root_id);
 RETURN NEW;
END $$;
CREATE TRIGGER guard_query_child_operation BEFORE INSERT ON os_agent_child_operations
 FOR EACH ROW EXECUTE FUNCTION os_guard_query_child_operation();

CREATE FUNCTION os_guard_query_child_tool_operation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT child_id INTO cid FROM os_agent_child_operations WHERE id=NEW.parent_operation_id AND root_id=NEW.root_id;
 IF cid IS NOT NULL THEN PERFORM os_assert_query_child_current(cid,NEW.root_id); END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_query_child_tool_operation BEFORE INSERT ON os_agent_tool_operations
 FOR EACH ROW EXECUTE FUNCTION os_guard_query_child_tool_operation();

CREATE FUNCTION os_guard_query_child_tool_call() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT child.child_id INTO cid FROM os_agent_tool_operations op JOIN os_agent_child_operations child
  ON child.id=op.parent_operation_id WHERE op.id=NEW.operation_id AND child.root_id=NEW.root_id;
 IF cid IS NOT NULL THEN PERFORM os_assert_query_child_current(cid,NEW.root_id); END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_query_child_tool_call BEFORE INSERT ON os_agent_tool_calls
 FOR EACH ROW EXECUTE FUNCTION os_guard_query_child_tool_call();

CREATE FUNCTION os_guard_query_child_work_begin() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT child.child_id INTO cid FROM os_agent_model_calls model JOIN os_agent_operation_models link ON link.id=model.id
  JOIN os_agent_child_operations child ON child.id=link.operation_id WHERE model.attempt_id=NEW.id;
 IF cid IS NULL THEN
  SELECT child.child_id INTO cid FROM os_agent_tool_calls tool JOIN os_agent_tool_operations op ON op.id=tool.operation_id
   JOIN os_agent_child_operations child ON child.id=op.parent_operation_id WHERE tool.attempt_id=NEW.id;
 END IF;
 IF cid IS NOT NULL THEN PERFORM os_assert_query_child_current(cid,NEW.root_id); END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_query_child_work_begin BEFORE UPDATE ON os_work_attempts
 FOR EACH ROW WHEN (OLD.state='RESERVED' AND NEW.state='RUNNING') EXECUTE FUNCTION os_guard_query_child_work_begin();
"""

TASK_GUARD=r"""
CREATE OR REPLACE FUNCTION os_check_agent_child_task_completion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE head os_agent_query_source_bindings%ROWTYPE;
BEGIN
 IF NEW.state<>'COMPLETED' OR OLD.state='COMPLETED' THEN RETURN NULL; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF NOT EXISTS(SELECT 1 FROM os_admissions WHERE task_id=NEW.id AND context->'harness'->>'ref'='focused-child-reads/1')
  THEN RETURN NULL; END IF;
 SELECT * INTO head FROM os_agent_query_source_bindings WHERE task_id=NEW.id ORDER BY revision DESC LIMIT 1;
 IF head.id IS NULL THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_child_reads WHERE task_id=NEW.id)
   OR EXISTS(SELECT 1 FROM os_agent_child_reads WHERE task_id=NEW.id AND state<>'COMPLETED')
   THEN RAISE EXCEPTION 'agent_child_task_incomplete'; END IF;
 ELSE
  IF NOT (head.payload->>'sourceComplete')::boolean
   OR (SELECT count(*) FROM os_agent_child_reads WHERE task_id=NEW.id AND source_binding_id=head.id AND state='COMPLETED')
      <(head.payload->>'requiredChildren')::bigint
   OR EXISTS(SELECT 1 FROM os_agent_child_reads child WHERE child.task_id=NEW.id AND child.state<>'COMPLETED'
    AND NOT (child.state='INTERRUPTED' AND os_query_source_child_retired(child.id,child.root_id,child.scope_digest)))
   THEN RAISE EXCEPTION 'query_source_task_incomplete'; END IF;
 END IF;
 RETURN NULL;
END $$;
"""

TABLES="\nCREATE TABLE os_agent_query_source_bindings (\n\tid UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\tintent_revision BIGINT NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\trevision BIGINT NOT NULL, \n\tprevious_id UUID, \n\tcandidate_acceptance_id UUID NOT NULL, \n\tverification_write_id UUID NOT NULL, \n\tgoal_write_id UUID NOT NULL, \n\tgoal_digest VARCHAR(64) NOT NULL, \n\tpayload_digest VARCHAR(64) NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_agent_query_source_binding_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_segments_segment_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, segment_id) REFERENCES os_segments (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_agent_model_acceptances_candidate_acceptance_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_acceptance_id) REFERENCES os_agent_model_acceptances (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_agent_payload_writes_verification_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, verification_write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_agent_payload_writes_goal_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, goal_write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_query_source_binding_task FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id, root_id) REFERENCES os_workload_bindings (installation_id, application_id, tenant_id, subject_id, task_id, root_id), \n\tCONSTRAINT uq_query_source_binding_root UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT uq_query_source_binding_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id, revision), \n\tCONSTRAINT uq_query_source_binding_candidate UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id, candidate_acceptance_id), \n\tCONSTRAINT fk_query_source_binding_previous FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, previous_id, root_id) REFERENCES os_agent_query_source_bindings (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT ck_query_source_binding_bounds CHECK (revision>0 AND intent_revision>0 AND control_epoch>0 AND expires_at>created_at AND ((revision=1)=(previous_id IS NULL)) AND jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536), \n\tCONSTRAINT ck_query_source_binding_goal_digest CHECK (goal_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_query_source_binding_payload_digest CHECK (payload_digest ~ '^[a-f0-9]{64}$')\n)\n\n;\nCREATE INDEX ix_query_source_binding_head ON os_agent_query_source_bindings (root_id, revision);\nCREATE INDEX ix_query_source_binding_task ON os_agent_query_source_bindings (task_id, revision);\nALTER TABLE os_agent_child_reads ADD COLUMN source_binding_id uuid;\nALTER TABLE os_agent_child_reads ADD CONSTRAINT fk_child_read_source_binding\n FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,source_binding_id,root_id)\n REFERENCES os_agent_query_source_bindings(installation_id,application_id,tenant_id,subject_id,id,root_id);\n"

CHILD_GUARD="CREATE OR REPLACE FUNCTION os_guard_agent_child_read() RETURNS trigger LANGUAGE plpgsql AS $$\nDECLARE r os_budget_roots%ROWTYPE; binding os_agent_child_roots%ROWTYPE; policy os_agent_child_policies%ROWTYPE;\n w os_agent_payload_writes%ROWTYPE; allowed boolean;\nBEGIN\n PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);\n IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_child_read_retained'; END IF;\n SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;\n SELECT * INTO binding FROM os_agent_child_roots WHERE id=NEW.root_binding_id AND root_id=r.id;\n SELECT * INTO policy FROM os_agent_child_policies WHERE installation_id=binding.installation_id\n  AND application_id=binding.application_id AND policy_digest=binding.policy_digest;\n IF TG_OP='INSERT' THEN\n  SELECT * INTO w FROM os_agent_payload_writes WHERE id=NEW.scope_write_id;\n  IF NOT COALESCE(NEW.state='ACTIVE' AND NEW.version=1 AND NEW.checkpoint_write_id IS NULL\n   AND NEW.candidate_acceptance_id IS NULL AND NEW.verification_write_id IS NULL\n   AND NEW.updated_at=NEW.created_at AND NEW.created_at>=w.created_at AND NEW.created_at<=clock_timestamp()\n   AND NEW.expires_at<=LEAST(r.deadline,NEW.created_at+make_interval(secs=>(policy.payload->>'workTimeoutMs')::numeric/1000))\n   AND NEW.expires_at>clock_timestamp() AND r.state='ACTIVE' AND r.root_task_id=NEW.task_id\n   AND w.root_id=r.id AND w.task_id=NEW.task_id AND w.schema_ref='AgentChildReadScope' AND w.schema_version=1\n   AND w.expires_at>=NEW.expires_at AND EXISTS(SELECT 1 FROM os_agent_private_payloads WHERE write_id=w.id)\n   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=w.attempt_id AND state='SETTLED')\n   AND EXISTS(SELECT 1 FROM os_agent_operations op JOIN os_agent_operation_models link ON link.operation_id=op.id\n    JOIN os_agent_model_acceptances accepted ON accepted.call_id=link.id\n    WHERE op.id=NEW.parent_operation_id AND op.root_id=r.id AND op.task_id=NEW.task_id\n     AND accepted.id=NEW.parent_acceptance_id AND op.parent_operation_id IS NULL\n     AND op.payload->'identity'->>'iteration'='0')\n   AND EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=NEW.task_id AND state='ACTIVE'),false)\n   THEN RAISE EXCEPTION 'agent_child_read_admission'; END IF;\n  IF (SELECT count(*) FROM os_agent_child_reads WHERE root_id=r.id AND state='ACTIVE')\n   >=(policy.payload->>'maxActiveChildren')::bigint THEN RAISE EXCEPTION 'agent_child_active_capacity'; END IF;\n ELSE\n  IF NOT COALESCE(OLD.state='ACTIVE' AND NEW.version=OLD.version+1 AND NEW.updated_at>=OLD.updated_at\n   AND NEW.updated_at<=clock_timestamp()\n   AND (to_jsonb(NEW)-ARRAY['state','version','checkpoint_write_id','candidate_acceptance_id','verification_write_id','updated_at'])\n    =(to_jsonb(OLD)-ARRAY['state','version','checkpoint_write_id','candidate_acceptance_id','verification_write_id','updated_at']),false)\n   THEN RAISE EXCEPTION 'agent_child_read_transition'; END IF;\n  IF NEW.checkpoint_write_id IS DISTINCT FROM OLD.checkpoint_write_id AND NOT EXISTS(\n   SELECT 1 FROM os_agent_payload_writes payload JOIN os_agent_private_payloads ready ON ready.write_id=payload.id\n   JOIN os_work_attempts work ON work.id=payload.attempt_id WHERE payload.id=NEW.checkpoint_write_id\n    AND payload.root_id=r.id AND payload.task_id=NEW.task_id AND payload.schema_ref='AgentSDKCheckpointState'\n    AND payload.schema_version=1 AND work.state='SETTLED' AND payload.expires_at>clock_timestamp())\n   THEN RAISE EXCEPTION 'agent_child_checkpoint_binding'; END IF;\n  IF NEW.state='COMPLETED' THEN\n   SELECT EXISTS(SELECT 1 FROM os_agent_model_acceptances accepted\n    JOIN os_agent_operation_models link ON link.id=accepted.call_id\n    JOIN os_agent_child_operations child ON child.id=link.operation_id\n    WHERE accepted.id=NEW.candidate_acceptance_id AND child.child_id=NEW.id AND child.root_id=r.id) INTO allowed;\n   IF NOT COALESCE(allowed AND EXISTS(SELECT 1 FROM os_agent_payload_writes payload\n    JOIN os_agent_private_payloads ready ON ready.write_id=payload.id JOIN os_work_attempts work ON work.id=payload.attempt_id\n    WHERE payload.id=NEW.verification_write_id AND payload.root_id=r.id AND payload.task_id=NEW.task_id\n     AND payload.schema_ref='AgentChildReadVerification' AND payload.schema_version=1\n     AND payload.expires_at>clock_timestamp() AND work.state='SETTLED')\n    AND NOT EXISTS(SELECT 1 FROM os_agent_child_operations child JOIN os_agent_operation_models link ON link.operation_id=child.id\n     JOIN os_agent_model_calls model ON model.id=link.id JOIN os_work_attempts work ON work.id=model.attempt_id\n     WHERE child.child_id=NEW.id AND work.state IN ('RESERVED','RUNNING','UNKNOWN'))\n    AND NOT EXISTS(SELECT 1 FROM os_agent_child_operations child JOIN os_agent_tool_operations op ON op.parent_operation_id=child.id\n     JOIN os_agent_tool_calls tool ON tool.operation_id=op.id JOIN os_work_attempts work ON work.id=tool.attempt_id\n     WHERE child.child_id=NEW.id AND work.state IN ('RESERVED','RUNNING','UNKNOWN')),false)\n    THEN RAISE EXCEPTION 'agent_child_completion_incomplete'; END IF;\n  ELSIF NEW.state='INTERRUPTED' AND NOT COALESCE(r.deadline<=clock_timestamp() OR NEW.expires_at<=clock_timestamp()\n   OR EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=NEW.task_id AND state<>'ACTIVE')\n   OR EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state IN ('RECONCILING','FAILED','CANCELLED','EXPIRED','QUARANTINED'))\n   OR os_query_source_child_retired(NEW.id,NEW.root_id,NEW.scope_digest),false)\n   THEN RAISE EXCEPTION 'agent_child_interruption_unproven'; END IF;\n END IF;\n RETURN NEW;\nEND $$;"


def upgrade():
    op.execute('CREATE EXTENSION IF NOT EXISTS pgcrypto')
    op.execute(TABLES)
    op.execute(HELPERS)
    op.execute(BINDING_GUARD)
    op.execute(WORK_GUARDS)
    op.execute(CHILD_GUARD)
    op.execute(TASK_GUARD)


def downgrade():
    raise RuntimeError('Source binding generations require retained forward recovery')
