"""Immutable typed preparation attempts and accepted protected stage contract."""

from alembic import op

revision = "os_pg_0013"
down_revision = "os_pg_0012"
branch_labels = None
depends_on = None


def upgrade():
    op.create_unique_constraint(
        "uq_attempt_root_fence",
        "os_work_attempts",
        [
            "installation_id",
            "application_id",
            "tenant_id",
            "subject_id",
            "id",
            "task_id",
            "segment_id",
            "root_id",
            "control_epoch",
        ],
    )
    op.create_unique_constraint(
        "uq_grant_exact_fence",
        "os_execution_grants",
        [
            "installation_id",
            "application_id",
            "tenant_id",
            "subject_id",
            "id",
            "task_id",
            "segment_id",
            "root_id",
            "control_epoch",
            "contract_ref",
            "digest",
        ],
    )
    op.execute(
        "CREATE TABLE os_preparation_attempt_bindings (\n\tid UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\tattempt_id UUID NOT NULL, \n\tgrant_id UUID NOT NULL, \n\tgrant_contract_ref VARCHAR(64) NOT NULL, \n\tgrant_digest VARCHAR(64) NOT NULL, \n\tsource_pin_digest VARCHAR(64) NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_preparation_attempt_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_preparation_attempt_fence FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id, task_id, segment_id, root_id, control_epoch) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, root_id, control_epoch), \n\tCONSTRAINT fk_preparation_grant_fence FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, grant_id, task_id, segment_id, root_id, control_epoch, grant_contract_ref, grant_digest) REFERENCES os_execution_grants (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, root_id, control_epoch, contract_ref, digest), \n\tCONSTRAINT uq_preparation_attempt UNIQUE (installation_id, application_id, tenant_id, subject_id, attempt_id), \n\tCONSTRAINT uq_preparation_intent_once UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id, source_pin_digest, request_digest), \n\tCONSTRAINT ck_preparation_attempt_epoch CHECK (control_epoch>0), \n\tCONSTRAINT ck_preparation_attempt_family CHECK (grant_contract_ref='TypedPreparationGrant'), \n\tCONSTRAINT ck_preparation_grant_digest CHECK (grant_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_preparation_source_digest CHECK (source_pin_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_preparation_request_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n)"
    )
    op.execute(
        "CREATE TRIGGER immutable_os_preparation_attempt_bindings BEFORE UPDATE OR DELETE ON os_preparation_attempt_bindings FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','task_id','segment_id','root_id','control_epoch','attempt_id','grant_id','grant_contract_ref','grant_digest','source_pin_digest','request_digest','created_at','installation_id','application_id','tenant_id','subject_id')"
    )
    op.execute("ALTER TABLE os_accepted_results DROP CONSTRAINT ck_result_contract")
    op.execute(
        "ALTER TABLE os_accepted_results ADD CONSTRAINT ck_result_contract CHECK (contract_ref IN ('StageResult','CognitiveStageResult','ReadStageResult','PreparedChangeResult')) NOT VALID"
    )
    op.execute("ALTER TABLE os_accepted_results VALIDATE CONSTRAINT ck_result_contract")


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use tested fresh recovery")
