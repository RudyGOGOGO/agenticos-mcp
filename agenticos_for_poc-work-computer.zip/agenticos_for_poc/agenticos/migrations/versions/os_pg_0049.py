"""Native dispatch, immutable Core mappings and owner-activated compiled tools."""
from alembic import op

revision='os_pg_0049'
down_revision='os_pg_0048'
branch_labels=None
depends_on=None
TABLES=("\nCREATE TABLE os_native_jobs (\n\tid UUID NOT NULL, \n\tattempt_id UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\tinvocation_id UUID NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\tcore_session_id UUID NOT NULL, \n\tenvironment_id UUID NOT NULL, \n\tbinding JSONB NOT NULL, \n\tbinding_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_native_job_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_native_job_exact_attempt FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id, task_id, segment_id, root_id, control_epoch, invocation_id, request_digest) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, root_id, control_epoch, invocation_id, request_digest), \n\tCONSTRAINT uq_native_job_attempt UNIQUE (installation_id, application_id, tenant_id, subject_id, attempt_id), \n\tCONSTRAINT uq_native_job_core_session UNIQUE (installation_id, core_session_id), \n\tCONSTRAINT uq_native_job_environment UNIQUE (installation_id, environment_id), \n\tCONSTRAINT ck_native_job_binding CHECK (control_epoch>0 AND jsonb_typeof(binding)='object' AND octet_length(binding::text)<=8192), \n\tCONSTRAINT ck_native_job_request_digest CHECK (request_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_native_job_binding_digest CHECK (binding_digest ~ '^[a-f0-9]{64}$')\n)\n\n", "\nCREATE TABLE os_native_verifications (\n\tid UUID NOT NULL, \n\tjob_id UUID NOT NULL, \n\tartifact_id UUID NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\tcompiled_digest VARCHAR(64) NOT NULL, \n\tteardown_digest VARCHAR(64) NOT NULL, \n\treceipt JSONB NOT NULL, \n\treceipt_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_native_verification_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_native_jobs_job_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, job_id) REFERENCES os_native_jobs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_artifacts_artifact_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, artifact_id) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_native_verification_job UNIQUE (installation_id, application_id, tenant_id, subject_id, job_id), \n\tCONSTRAINT uq_native_verification_tool_binding UNIQUE (installation_id, application_id, tenant_id, subject_id, id, artifact_id, compiled_digest, receipt_digest), \n\tCONSTRAINT ck_native_verification_receipt CHECK (jsonb_typeof(receipt)='object' AND receipt->>'status'='verified' AND octet_length(receipt::text)<=16384), \n\tCONSTRAINT ck_native_verification_ciphertext_digest_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_native_verification_compiled_digest_digest CHECK (compiled_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_native_verification_teardown_digest_digest CHECK (teardown_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_native_verification_receipt_digest_digest CHECK (receipt_digest ~ '^[a-f0-9]{64}$')\n)\n\n", "\nCREATE TABLE os_native_tools (\n\tid UUID NOT NULL, \n\tname VARCHAR(64) NOT NULL, \n\tverification_id UUID NOT NULL, \n\tartifact_id UUID NOT NULL, \n\tcompiled_digest VARCHAR(64) NOT NULL, \n\treceipt_digest VARCHAR(64) NOT NULL, \n\tversion BIGINT NOT NULL, \n\tstate VARCHAR(16) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_native_tool_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_native_tool_exact_verification FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, verification_id, artifact_id, compiled_digest, receipt_digest) REFERENCES os_native_verifications (installation_id, application_id, tenant_id, subject_id, id, artifact_id, compiled_digest, receipt_digest), \n\tCONSTRAINT uq_native_tool_name UNIQUE (installation_id, application_id, tenant_id, subject_id, name), \n\tCONSTRAINT uq_native_tool_verification UNIQUE (installation_id, application_id, tenant_id, subject_id, verification_id), \n\tCONSTRAINT ck_native_tool_state CHECK (name ~ '^[a-zA-Z][a-zA-Z0-9._-]{0,63}$' AND version>0 AND state IN ('DRAFT','ACTIVE','PAUSED')), \n\tCONSTRAINT ck_native_tool_compiled_digest CHECK (compiled_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_native_tool_receipt_digest CHECK (receipt_digest ~ '^[a-f0-9]{64}$')\n)\n\n", "\nCREATE TABLE os_native_tool_decisions (\n\tid UUID NOT NULL, \n\ttool_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\texpected_version BIGINT NOT NULL, \n\taccepted_version BIGINT NOT NULL, \n\taction VARCHAR(16) NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_native_tool_decision_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_native_tools_tool_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, tool_id) REFERENCES os_native_tools (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_native_tool_decision_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT uq_native_tool_decision_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, tool_id, accepted_version), \n\tCONSTRAINT ck_native_tool_decision_versions CHECK (expected_version>0 AND accepted_version=expected_version+1 AND action IN ('activate','pause')), \n\tCONSTRAINT ck_native_tool_decision_request_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n)\n\n")

GUARDS=r"""
CREATE FUNCTION os_native_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'immutable_native_record';END IF;
 IF to_jsonb(OLD) IS DISTINCT FROM to_jsonb(NEW) THEN RAISE EXCEPTION 'immutable_native_record';END IF;
 RETURN NEW;
END $$;
CREATE FUNCTION os_guard_native_job() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_work_attempts%ROWTYPE; r os_budget_roots%ROWTYPE; admission os_admissions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_work_attempts WHERE id=NEW.attempt_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id;
 SELECT * INTO admission FROM os_admissions WHERE id=r.admission_id;
 IF a.id IS NULL OR r.id IS NULL OR admission.id IS NULL OR a.kind<>'native'
  OR r.profile_ref<>'local-native-synthetic/1' OR admission.bot->>'modelProfile'<>'native-core-codex/1'
  OR admission.context->>'executionClass'<>'durable'
  OR NEW.binding IS DISTINCT FROM jsonb_build_object(
   'subject',jsonb_build_object('installationId',NEW.installation_id,'applicationId',NEW.application_id,'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id),
   'taskId',NEW.task_id,'segmentId',NEW.segment_id,'rootId',NEW.root_id,'attemptId',NEW.attempt_id,
   'invocationId',NEW.invocation_id,'controlEpoch',NEW.control_epoch,'requestDigest',NEW.request_digest,
   'artifactDigest',NEW.binding->'artifactDigest','policyDigest',NEW.binding->'policyDigest','inputDigest',NEW.binding->'inputDigest',
   'coreSessionId',NEW.core_session_id,'environmentId',NEW.environment_id,'deadline',NEW.binding->'deadline','profileRef','microsandbox-darwin-arm64/1')
  OR NEW.binding->>'artifactDigest' IS NULL OR NEW.binding->>'policyDigest' IS NULL OR NEW.binding->>'inputDigest' IS NULL
  OR jsonb_typeof(NEW.binding->'deadline') IS DISTINCT FROM 'string'
  OR NEW.binding->>'artifactDigest' !~ '^[a-f0-9]{64}$' OR NEW.binding->>'policyDigest' !~ '^[a-f0-9]{64}$'
  OR NEW.binding->>'inputDigest' !~ '^[a-f0-9]{64}$' OR (NEW.binding->>'deadline')::timestamptz<>a.lease_until
 THEN RAISE EXCEPTION 'native_job_exact_binding';END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER exact_native_job BEFORE INSERT ON os_native_jobs FOR EACH ROW EXECUTE FUNCTION os_guard_native_job();

CREATE FUNCTION os_guard_native_verification() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE j os_native_jobs%ROWTYPE; a os_work_attempts%ROWTYPE; r os_budget_roots%ROWTYPE;
 c os_task_controls%ROWTYPE; t os_tasks%ROWTYPE; f os_artifacts%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO j FROM os_native_jobs WHERE id=NEW.job_id;
 SELECT * INTO a FROM os_work_attempts WHERE id=j.attempt_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=j.root_id;
 SELECT * INTO c FROM os_task_controls WHERE task_id=j.task_id FOR UPDATE;
 SELECT * INTO t FROM os_tasks WHERE id=j.task_id;
 SELECT * INTO f FROM os_artifacts WHERE id=NEW.artifact_id;
 IF j.id IS NULL OR a.state IS DISTINCT FROM 'SETTLED' OR a.kind IS DISTINCT FROM 'native'
  OR r.state IS DISTINCT FROM 'ACTIVE' OR r.deadline<=clock_timestamp()
  OR c.state IS DISTINCT FROM 'ACTIVE' OR c.epoch IS DISTINCT FROM j.control_epoch
  OR t.deadline<=clock_timestamp() OR t.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')
  OR f.id IS NULL OR f.purpose<>'artifact' OR f.classification<>'protected' OR f.expires_at<=clock_timestamp()
  OR f.ciphertext_digest<>NEW.ciphertext_digest
  OR NEW.receipt IS DISTINCT FROM jsonb_build_object(
   'subject',jsonb_build_object('installationId',NEW.installation_id,'applicationId',NEW.application_id,'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id),
   'jobId',NEW.job_id,'taskId',j.task_id,'attemptId',j.attempt_id,'inputDigest',j.binding->'inputDigest','policyDigest',j.binding->'policyDigest',
   'artifactRef','artifact/'||NEW.artifact_id::text,'ciphertextDigest',NEW.ciphertext_digest,'compiledDigest',NEW.compiled_digest,
   'teardownDigest',NEW.teardown_digest,'profileRef','wasmtime-i32-offline/1','cases',NEW.receipt->'cases','status','verified','verifiedAt',NEW.receipt->'verifiedAt')
  OR jsonb_typeof(NEW.receipt->'cases') IS DISTINCT FROM 'array'
  OR jsonb_array_length(NEW.receipt->'cases') NOT BETWEEN 1 AND 8
  OR jsonb_typeof(NEW.receipt->'verifiedAt') IS DISTINCT FROM 'string'
  OR (NEW.receipt->>'verifiedAt')::timestamptz>clock_timestamp()
 THEN RAISE EXCEPTION 'native_verification_exact_binding';END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER exact_native_verification BEFORE INSERT ON os_native_verifications FOR EACH ROW EXECUTE FUNCTION os_guard_native_verification();

CREATE FUNCTION os_guard_native_tool() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'native_tool_immutable';END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.state<>'DRAFT' THEN RAISE EXCEPTION 'native_tool_needs_activation';END IF;
  PERFORM 1 FROM os_subjects WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
   AND tenant_id=NEW.tenant_id AND subject_id=NEW.subject_id FOR UPDATE;
  IF (SELECT count(*) FROM os_native_tools WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
   AND tenant_id=NEW.tenant_id AND subject_id=NEW.subject_id)>=32 THEN RAISE EXCEPTION 'native_tool_capacity';END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['version','state']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','state'])
   OR NEW.version<>OLD.version+1 OR NEW.state=OLD.state OR NEW.state='DRAFT'
   OR NOT EXISTS(SELECT 1 FROM os_native_tool_decisions d JOIN os_interactive_sessions s ON s.id=d.session_id
    WHERE d.tool_id=OLD.id AND d.expected_version=OLD.version AND d.accepted_version=NEW.version
    AND NOT s.revoked AND s.expires_at>clock_timestamp()
    AND NEW.state=CASE WHEN d.action='activate' THEN 'ACTIVE' ELSE 'PAUSED' END)
   THEN RAISE EXCEPTION 'native_tool_owner_decision';END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER reviewed_native_tool BEFORE INSERT OR UPDATE OR DELETE ON os_native_tools FOR EACH ROW EXECUTE FUNCTION os_guard_native_tool();
"""


def upgrade():
    op.execute("ALTER TABLE os_dispatches DROP CONSTRAINT ck_dispatch_profile")
    op.execute("ALTER TABLE os_dispatches ADD CONSTRAINT ck_dispatch_profile CHECK (workflow_profile IN ('OSAdmissionTransport/1','OSTaskDriver/1','OSTrustedTaskDriver/1','OSTrustedTaskDriver/2','OSTaskMemoryDriver/1','OSNativeTaskDriver/1'))")
    for statement in TABLES:op.execute(statement)
    op.execute(GUARDS)
    for table in ('os_native_jobs','os_native_verifications','os_native_tool_decisions'):
        op.execute('CREATE TRIGGER immutable_'+table+' BEFORE UPDATE OR DELETE ON '+table+' FOR EACH ROW EXECUTE FUNCTION os_native_immutable()')


def downgrade():
    raise RuntimeError('Native jobs and owner decisions require reviewed forward recovery')
