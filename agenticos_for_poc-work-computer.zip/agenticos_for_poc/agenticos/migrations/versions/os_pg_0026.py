"""Finite one-input consent and receipt-bound private inbox; additive0026."""
from alembic import op
revision="os_pg_0026"
down_revision="os_pg_0025"
branch_labels=None
depends_on=None


CURRENT_GUARDS = r"""
CREATE FUNCTION os_assert_input_delegation_current(d os_input_delegations, phase integer)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE c os_task_controls%ROWTYPE; t os_tasks%ROWTYPE; r os_budget_roots%ROWTYPE;
 v os_task_input_versions%ROWTYPE; h os_task_input_heads%ROWTYPE; s os_segments%ROWTYPE;
 p os_input_proposals%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
 login os_interactive_sessions%ROWTYPE; cmd os_commands%ROWTYPE; now_at timestamptz; a jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO r FROM os_budget_roots WHERE id=d.root_id;
 PERFORM 1 FROM os_task_controls x WHERE
  (x.installation_id,x.application_id,x.tenant_id,x.subject_id)=
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id)
  AND x.task_id IN (d.task_id,r.root_task_id) ORDER BY x.task_id FOR UPDATE;
 SELECT * INTO c FROM os_task_controls WHERE task_id=d.task_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id FOR UPDATE;
 SELECT * INTO owner FROM os_subjects x WHERE
  (x.installation_id,x.application_id,x.tenant_id,x.subject_id)=
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id) FOR UPDATE;
 SELECT * INTO login FROM os_interactive_sessions WHERE id=d.session_id;
 SELECT * INTO cmd FROM os_commands WHERE id=d.command_id;
 SELECT * INTO v FROM os_task_input_versions WHERE id=d.input_version_id;
 SELECT * INTO h FROM os_task_input_heads x WHERE
  (x.installation_id,x.application_id,x.tenant_id,x.subject_id,x.profile_id)=
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id,v.profile_id) FOR UPDATE;
 SELECT * INTO t FROM os_tasks WHERE id=d.task_id FOR UPDATE;
 SELECT * INTO s FROM os_segments WHERE id=d.segment_id FOR UPDATE;
 PERFORM 1 FROM os_work_attempts WHERE task_id=t.id ORDER BY id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=d.root_id FOR UPDATE;
 SELECT * INTO p FROM os_input_proposals WHERE id=d.proposal_id;
 now_at=clock_timestamp(); a=d.payload->'authority';
 IF c.id IS NULL OR t.id IS NULL OR r.id IS NULL OR v.id IS NULL OR h.profile_id IS NULL OR s.id IS NULL
  OR p.id IS NULL OR app.id IS NULL OR owner.subject_id IS NULL OR login.id IS NULL OR cmd.id IS NULL
 THEN RAISE EXCEPTION 'delegation_missing_parent'; END IF;
 IF COALESCE((h.current_version_id<>v.id OR h.revision<>v.revision OR h.version<>h.revision
  OR v.revision<>d.input_revision OR v.input_digest<>d.input_digest
  OR v.control_epoch<>d.control_epoch OR c.epoch<>d.control_epoch OR c.state<>'ACTIVE'
  OR EXISTS(SELECT 1 FROM os_task_controls x WHERE x.task_id=r.root_task_id AND x.state<>'ACTIVE')
  OR v.task_id<>t.id OR v.root_id<>r.id OR v.segment_id<>s.id OR s.task_id<>t.id OR s.state<>'OPEN'
  OR t.state NOT IN ('ACCEPTED','VALIDATING','RUNNING')
  OR (phase=0 AND t.state<>'ACCEPTED') OR (phase>0 AND t.state NOT IN ('VALIDATING','RUNNING'))
  OR r.state<>'ACTIVE' OR r.profile_ref<>'local-amendable-synthetic/1' OR r.root_task_id<>t.id
  OR t.budget_root_id<>r.id OR t.deadline<>r.deadline OR v.expires_at<>r.deadline
  OR p.input_version_id<>v.id OR p.input_digest<>v.input_digest OR p.input_revision<>v.revision
  OR cmd.kind<>'input.delegation.consent' OR cmd.accepted_task_id<>t.id OR cmd.request_digest<>d.command_digest
  OR d.payload->>'commandId'<>cmd.command_id::text
  OR d.payload->'record'->>'bindingDigest'<>p.binding_digest
  OR d.payload->>'sourcePinDigest'<>p.source_pin_digest OR d.payload->>'requestDigest'<>p.request_digest
  OR d.payload->>'definitionDigest'<>r.definition_digest OR d.payload->>'requestDigest'<>v.request_digest
  OR d.payload->'delegation'->'capabilityRefs'<>jsonb_build_array(p.capability_ref)
  OR NOT app.active OR NOT owner.active OR app.generation<>(a->>'applicationGeneration')::bigint
  OR app.revision<>(d.payload->>'registrationRevision')::bigint OR owner.generation<>(a->>'subjectGeneration')::bigint
  OR owner.host_policy_generation<>(a->>'policyGeneration')::bigint
  OR (d.payload->>'createdAt')::timestamptz<>d.created_at OR (d.payload->>'expiresAt')::timestamptz<>d.expires_at
  OR d.payload->'delegation'->>'validFrom'<>d.payload->>'createdAt'
  OR d.payload->'delegation'->>'validUntil'<>d.payload->>'expiresAt'
  OR (d.payload->'delegation'->'budget'->>'deadlineMs')::bigint<>extract(epoch FROM d.expires_at-d.created_at)*1000
  OR d.created_at>now_at+interval '1 second' OR d.expires_at<=now_at OR d.expires_at>p.expires_at
  OR d.expires_at>v.expires_at OR r.deadline<=now_at
  OR EXISTS(SELECT 1 FROM os_input_delegation_revocations x WHERE x.delegation_id=d.id)
  OR EXISTS(SELECT 1 FROM os_task_input_invalidations x WHERE x.invalidated_version_id=v.id)
  OR EXISTS(SELECT 1 FROM os_input_review_activations x WHERE x.input_version_id=v.id)
  OR EXISTS(SELECT 1 FROM os_work_attempts w WHERE w.task_id=t.id AND
      (w.state='UNKNOWN' OR (w.kind='read' AND w.state NOT IN ('SETTLED','RELEASED'))
       OR NOT EXISTS(SELECT 1 FROM os_input_preparation_attempts a WHERE a.attempt_id=w.id)
          AND NOT EXISTS(SELECT 1 FROM os_input_delegated_attempts a WHERE a.attempt_id=w.id)))),true)
 THEN RAISE EXCEPTION 'delegation_current_fence'; END IF;
 IF COALESCE((phase=0 AND (login.revoked OR login.expires_at<=now_at OR login.session_generation<>(a->>'sessionGeneration')::bigint
  OR login.host_session_ref<>a->>'hostSessionRef' OR login.application_generation<>app.generation
  OR login.subject_generation<>owner.generation OR d.created_at<now_at-interval '5 seconds'
  OR (d.payload->'creationHostAuthority'->>'checkedAt')::timestamptz<now_at-interval '5 seconds'
  OR (d.payload->'creationHostAuthority'->>'checkedAt')::timestamptz>now_at+interval '1 second'
  OR (d.payload->'creationHostAuthority'->>'validUntil')::timestamptz<=now_at)),true)
 THEN RAISE EXCEPTION 'delegation_fresh_consent'; END IF;
END $$;

CREATE FUNCTION os_guard_input_delegation_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM os_assert_input_delegation_current(NEW,0); RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_input_delegation AFTER INSERT ON os_input_delegations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_input_delegation_commit();

CREATE FUNCTION os_assert_input_delegated_grant(g os_input_delegated_grants)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE d os_input_delegations%ROWTYPE;
BEGIN
 SELECT * INTO d FROM os_input_delegations WHERE id=g.delegation_id;
 IF d.id IS NULL THEN RAISE EXCEPTION 'delegated_grant_missing_consent'; END IF;
 PERFORM os_assert_input_delegation_current(d,1);
 IF COALESCE((g.payload->'authorization'<>jsonb_build_object('kind','bounded_delegation','delegation',d.payload->'delegation')
  OR g.payload->>'sourcePinDigest'<>d.payload->>'sourcePinDigest'
  OR g.payload->>'requestDigest'<>d.payload->>'requestDigest'
  OR g.payload->>'definitionDigest'<>d.payload->>'definitionDigest'
  OR g.payload->>'registrationRevision'<>d.payload->>'registrationRevision'
  OR g.payload->>'capabilityRef'<>d.payload->'delegation'->'capabilityRefs'->>0
  OR (g.payload->>'createdAt')::timestamptz<>g.created_at OR (g.payload->>'expiresAt')::timestamptz<>g.expires_at
  OR g.created_at<d.created_at OR g.created_at>clock_timestamp()+interval '1 second'
  OR g.expires_at>d.expires_at OR g.expires_at<=clock_timestamp()),true)
 THEN RAISE EXCEPTION 'delegated_grant_exact_fence'; END IF;
END $$;
CREATE FUNCTION os_guard_input_delegated_grant_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM os_assert_input_delegated_grant(NEW); RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_input_delegated_grant AFTER INSERT ON os_input_delegated_grants
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_input_delegated_grant_commit();

CREATE FUNCTION os_assert_input_delegated_attempt(bound os_input_delegated_attempts, begun boolean)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE g os_input_delegated_grants%ROWTYPE; w os_work_attempts%ROWTYPE;
 r os_budget_roots%ROWTYPE; t os_tasks%ROWTYPE; d os_input_delegations%ROWTYPE; now_at timestamptz;
BEGIN
 SELECT * INTO g FROM os_input_delegated_grants WHERE id=bound.grant_id;
 IF g.id IS NULL THEN RAISE EXCEPTION 'delegated_work_missing_grant'; END IF;
 PERFORM os_assert_input_delegated_grant(g);
 SELECT * INTO d FROM os_input_delegations WHERE id=g.delegation_id;
 SELECT * INTO w FROM os_work_attempts WHERE id=bound.attempt_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=bound.root_id;
 SELECT * INTO t FROM os_tasks WHERE id=bound.task_id;
 now_at=clock_timestamp();
 IF COALESCE((w.id IS NULL OR r.id IS NULL OR t.id IS NULL OR w.kind<>'effect' OR w.actual IS NOT NULL
  OR w.created_at<>bound.created_at OR w.state<>(CASE WHEN begun THEN 'RUNNING' ELSE 'RESERVED' END)
  OR w.version<>(CASE WHEN begun THEN 2 ELSE 1 END) OR (begun AND t.state<>'RUNNING')
  OR w.lease_until<=now_at OR w.lease_until>g.expires_at OR w.lease_until>r.deadline
  OR (w.reserved->>'workMs')::bigint NOT BETWEEN 1 AND 45000
  OR w.reserved<>jsonb_build_object('stages',1,'children',0,'tokens',0,'toolCalls',1,'nativeJobs',0,
       'costMicros',0,'workMs',(w.reserved->>'workMs')::bigint,'repairs',0,'planRevisions',0)
  OR w.lease_until>w.created_at+((w.reserved->>'workMs')::bigint*interval '1 millisecond')
  OR bound.visibility_generation<>(d.payload->'authority'->>'policyGeneration')::bigint
  OR EXISTS(SELECT 1 FROM jsonb_object_keys(w.reserved) k WHERE
       (r.outstanding->>k)::bigint<(w.reserved->>k)::bigint
       OR (r.spent->>k)::bigint+(r.outstanding->>k)::bigint>(r.ceiling->>k)::bigint)
  OR EXISTS(SELECT 1 FROM os_work_attempts x WHERE x.task_id=t.id AND x.id<>w.id
       AND x.state IN ('RESERVED','RUNNING','UNKNOWN'))),true)
 THEN RAISE EXCEPTION 'delegated_work_current_fence'; END IF;
END $$;
CREATE FUNCTION os_guard_input_delegated_attempt_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM os_assert_input_delegated_attempt(NEW,false); RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_input_delegated_attempt AFTER INSERT ON os_input_delegated_attempts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_input_delegated_attempt_commit();
CREATE FUNCTION os_guard_input_delegated_begin() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE bound os_input_delegated_attempts%ROWTYPE;
BEGIN
 IF NEW.state<>'RUNNING' OR NEW.state=OLD.state THEN RETURN NULL; END IF;
 SELECT * INTO bound FROM os_input_delegated_attempts WHERE attempt_id=NEW.id;
 IF FOUND THEN PERFORM os_assert_input_delegated_attempt(bound,true); END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_input_delegated_begin AFTER UPDATE ON os_work_attempts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_input_delegated_begin();

CREATE FUNCTION os_guard_current_input_effect_family() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.kind='effect' AND EXISTS(SELECT 1 FROM os_task_input_profiles WHERE task_id=NEW.task_id)
  AND (SELECT count(*) FROM (
    SELECT id FROM os_input_reviewed_effect_attempts WHERE attempt_id=NEW.id
    UNION ALL SELECT id FROM os_input_delegated_attempts WHERE attempt_id=NEW.id) x)<>1
 THEN RAISE EXCEPTION 'current_input_effect_requires_exact_family'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_current_input_effect_family AFTER INSERT ON os_work_attempts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_current_input_effect_family();
CREATE FUNCTION os_guard_input_review_delegation_exclusive() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM os_input_delegations WHERE input_version_id=NEW.input_version_id)
 THEN RAISE EXCEPTION 'input_consent_review_exclusive'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_input_review_delegation_exclusive AFTER INSERT ON os_input_review_activations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_input_review_delegation_exclusive();

CREATE FUNCTION os_assert_current_private_session(scope jsonb, session_id uuid)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; login os_interactive_sessions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO app FROM os_applications WHERE installation_id=(scope->>'installationId')::uuid
  AND id=(scope->>'applicationId')::uuid FOR UPDATE;
 SELECT * INTO owner FROM os_subjects x WHERE
  (x.installation_id,x.application_id,x.tenant_id,x.subject_id)=
  ((scope->>'installationId')::uuid,(scope->>'applicationId')::uuid,scope->>'tenantId',scope->>'subjectId') FOR UPDATE;
 SELECT * INTO login FROM os_interactive_sessions x WHERE x.id=session_id AND
  (x.installation_id,x.application_id,x.tenant_id,x.subject_id)=
  (owner.installation_id,owner.application_id,owner.tenant_id,owner.subject_id) FOR UPDATE;
 IF COALESCE((app.id IS NULL OR owner.subject_id IS NULL OR login.id IS NULL OR NOT app.active OR NOT owner.active
  OR login.revoked OR login.expires_at<=clock_timestamp() OR login.application_generation<>app.generation
  OR login.subject_generation<>owner.generation),true)
 THEN RAISE EXCEPTION 'private_current_owner_session'; END IF;
END $$;
CREATE FUNCTION os_guard_consent_revocation_or_notification_ack() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM os_assert_current_private_session(jsonb_build_object('installationId',NEW.installation_id,
  'applicationId',NEW.application_id,'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id),NEW.session_id);
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_input_delegation_revocation AFTER INSERT ON os_input_delegation_revocations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_consent_revocation_or_notification_ack();
CREATE CONSTRAINT TRIGGER commit_os_private_notification_ack AFTER INSERT ON os_private_notification_acknowledgements
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_consent_revocation_or_notification_ack();

CREATE FUNCTION os_guard_private_notification_receipt() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE p os_input_delegated_receipts%ROWTYPE;
BEGIN
 SELECT * INTO p FROM os_input_delegated_receipts WHERE id=NEW.projection_id;
 IF COALESCE((p.id IS NULL OR p.payload->>'status' NOT IN ('COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED')
  OR p.payload->>'receiptId' IS NULL OR p.payload->>'version' IS NULL
  OR EXISTS(SELECT 1 FROM os_input_delegated_receipts x WHERE x.binding_id=p.binding_id AND x.ordinal>p.ordinal)
  OR NEW.payload->>'safeSummary'<>(CASE WHEN p.payload->>'status'='COMMITTED'
      THEN 'Delegated change was applied.' ELSE 'Delegated change was not applied.' END)
  OR (NEW.payload->>'createdAt')::timestamptz<>NEW.created_at),true)
 THEN RAISE EXCEPTION 'notification_requires_accepted_terminal_receipt'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_private_notification_receipt AFTER INSERT ON os_private_notification_intents
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_private_notification_receipt();

CREATE FUNCTION os_guard_private_notification_delivery() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.state<>'DUE' OR NEW.attempts<>0 OR NEW.lease_token IS NOT NULL
   OR NEW.lease_until IS NOT NULL OR NEW.next_attempt_at>clock_timestamp()+interval '1 second'
  THEN RAISE EXCEPTION 'notification_initial_delivery'; END IF;
 ELSE
  IF NEW.version<>OLD.version+1 OR OLD.state IN ('DELIVERED','POISON')
   OR NEW.next_attempt_at<>OLD.next_attempt_at
   OR NOT ((NEW.state='LEASED' AND NEW.attempts=OLD.attempts+1 AND NEW.attempts<=8
       AND (OLD.state='DUE' OR OLD.state='LEASED' AND OLD.lease_until<=clock_timestamp())
       AND NEW.lease_until>clock_timestamp() AND NEW.lease_until<=clock_timestamp()+interval '2.5 seconds'
       AND OLD.lease_token IS DISTINCT FROM NEW.lease_token)
     OR (NEW.state='DELIVERED' AND OLD.state='LEASED' AND OLD.lease_until>clock_timestamp()
       AND NEW.attempts=OLD.attempts)
     OR (NEW.state='POISON' AND OLD.attempts=8 AND NEW.attempts=8
       AND (OLD.state='DUE' OR OLD.state='LEASED' AND OLD.lease_until<=clock_timestamp())))
  THEN RAISE EXCEPTION 'notification_bounded_delivery_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_os_private_notification_delivery BEFORE INSERT OR UPDATE ON os_private_notification_deliveries
 FOR EACH ROW EXECUTE FUNCTION os_guard_private_notification_delivery();
CREATE FUNCTION os_guard_private_notification_inbox_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE delivery os_private_notification_deliveries%ROWTYPE; ident uuid;
BEGIN
 ident=NEW.notification_id;
 SELECT * INTO delivery FROM os_private_notification_deliveries x WHERE
  (x.installation_id,x.application_id,x.tenant_id,x.subject_id,x.notification_id)=
  (NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,ident);
 IF delivery.id IS NULL OR delivery.state<>'DELIVERED' OR delivery.attempts<1
  OR NOT EXISTS(SELECT 1 FROM os_private_notification_inbox x WHERE
    (x.installation_id,x.application_id,x.tenant_id,x.subject_id,x.notification_id)=
    (NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,ident))
 THEN RAISE EXCEPTION 'notification_delivery_inbox_atomic'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_private_notification_inbox AFTER INSERT ON os_private_notification_inbox
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_private_notification_inbox_commit();
CREATE FUNCTION os_guard_private_notification_delivered_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.state='LEASED' AND NEW.lease_until<=clock_timestamp() THEN
  RAISE EXCEPTION 'notification_delivery_lease_expired'; END IF;
 IF NEW.state='DELIVERED' AND (OLD.state<>'LEASED' OR OLD.lease_until<=clock_timestamp()) THEN
  RAISE EXCEPTION 'notification_delivery_lease_expired'; END IF;
 IF NEW.state='DELIVERED' AND NOT EXISTS(SELECT 1 FROM os_private_notification_inbox x WHERE
  (x.installation_id,x.application_id,x.tenant_id,x.subject_id,x.notification_id)=
  (NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.notification_id))
 THEN RAISE EXCEPTION 'notification_delivery_inbox_atomic'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_private_notification_delivery AFTER UPDATE ON os_private_notification_deliveries
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_private_notification_delivered_commit();
"""


def upgrade():
    op.execute('ALTER TABLE os_input_proposals ADD CONSTRAINT uq_input_delegation_proposal_exact UNIQUE (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, root_id, input_version_id, input_revision, input_digest, control_epoch, proposal_digest)')
    op.execute("\nCREATE TABLE os_input_delegation_providers (\n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\tregistration_revision BIGINT NOT NULL, \n\tcapability_ref VARCHAR(256) NOT NULL, \n\tcredential_ref VARCHAR(256) NOT NULL, \n\tbinding_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tPRIMARY KEY (installation_id, application_id, registration_revision, capability_ref), \n\tCONSTRAINT fk_input_delegation_registered_provider FOREIGN KEY(installation_id, application_id, registration_revision, capability_ref) REFERENCES os_reviewed_effect_providers (installation_id, application_id, registration_revision, capability_ref), \n\tCONSTRAINT ck_input_delegation_provider_digest CHECK (binding_digest ~ '^[a-f0-9]{64}$')\n)\n\n")
    op.execute("CREATE TRIGGER immutable_os_input_delegation_providers BEFORE UPDATE OR DELETE ON os_input_delegation_providers FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('installation_id','application_id','registration_revision','capability_ref','credential_ref','binding_digest','created_at')")
    op.execute("\nCREATE TABLE os_input_delegations (\n\tid UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tinput_version_id UUID NOT NULL, \n\tinput_revision BIGINT NOT NULL, \n\tinput_digest VARCHAR(64) NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\tproposal_id UUID NOT NULL, \n\tproposal_digest VARCHAR(64) NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tcommand_digest VARCHAR(64) NOT NULL, \n\tdelegation_digest VARCHAR(64) NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_input_delegation_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_input_delegation_subject FOREIGN KEY(installation_id, application_id, tenant_id, subject_id) REFERENCES os_subjects (installation_id, application_id, tenant_id, subject_id), \n\tCONSTRAINT uq_input_delegation_head_once UNIQUE (installation_id, application_id, tenant_id, subject_id, input_version_id), \n\tCONSTRAINT uq_input_delegation_command_once UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT uq_input_delegation_exact UNIQUE (installation_id, application_id, tenant_id, subject_id, id, delegation_digest, task_id, segment_id, root_id, input_version_id, input_revision, input_digest, control_epoch, proposal_id, proposal_digest), \n\tCONSTRAINT fk_input_delegation_proposal_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, proposal_id, task_id, segment_id, root_id, input_version_id, input_revision, input_digest, control_epoch, proposal_digest) REFERENCES os_input_proposals (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, root_id, input_version_id, input_revision, input_digest, control_epoch, proposal_digest), \n\tCONSTRAINT fk_os_commands_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, command_id) REFERENCES os_commands (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_input_delegation_consent_session FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT ck_input_delegation_versions CHECK (input_revision BETWEEN 1 AND 4 AND control_epoch>0), \n\tCONSTRAINT ck_input_delegation_time CHECK (expires_at>created_at AND expires_at<=created_at+interval '5 minutes'), \n\tCONSTRAINT ck_input_delegation_json CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536), \n\tCONSTRAINT ck_input_delegation_input_digest CHECK (input_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegation_proposal_digest CHECK (proposal_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegation_command_digest CHECK (command_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegation_delegation_digest CHECK (delegation_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegation_closed_binding CHECK (jsonb_typeof((payload))='object' AND (payload) ?& ARRAY['profileRef','id','subject','input','record','delegation','notificationPolicy','authority','creationHostAuthority','registrationRevision','definitionDigest','sourcePinDigest','requestDigest','commandId','commandDigest','createdAt','expiresAt','delegationDigest'] AND ((payload) - ARRAY['profileRef','id','subject','input','record','delegation','notificationPolicy','authority','creationHostAuthority','registrationRevision','definitionDigest','sourcePinDigest','requestDigest','commandId','commandDigest','createdAt','expiresAt','delegationDigest'])='{}'::jsonb AND jsonb_typeof((payload->'delegation'))='object' AND (payload->'delegation') ?& ARRAY['id','subject','revision','capabilityRefs','resourceBounds','purpose','maxRisk','validFrom','validUntil','budget','active'] AND ((payload->'delegation') - ARRAY['id','subject','revision','capabilityRefs','resourceBounds','purpose','maxRisk','validFrom','validUntil','budget','active'])='{}'::jsonb AND COALESCE((payload->>'id'=id::text AND payload->>'delegationDigest'=delegation_digest AND payload->>'commandDigest'=command_digest AND payload->>'profileRef'='input-bounded-delegation/1' AND payload->>'notificationPolicy'='private-result/1' AND payload->'subject'=jsonb_build_object('installationId',installation_id::text,'applicationId',application_id::text,'tenantId',tenant_id,'subjectId',subject_id) AND payload->'input'->>'id'=input_version_id::text AND payload->'input'->>'inputDigest'=input_digest AND payload->'input'->>'revision'=input_revision::text AND payload->'input'->>'taskId'=task_id::text AND payload->'input'->>'segmentId'=segment_id::text AND payload->'input'->>'rootId'=root_id::text AND payload->'input'->>'controlEpoch'=control_epoch::text AND payload->'record'->>'id'=proposal_id::text AND payload->'record'->>'proposalDigest'=proposal_digest AND payload->'authority'->>'sessionId'=session_id::text AND payload->'authority'->'subject'=payload->'subject' AND payload->'delegation'->'subject'=payload->'subject' AND payload->'delegation'->>'id'=id::text AND payload->'delegation'->>'purpose'='assistant.change' AND payload->'delegation'->>'maxRisk'='medium' AND payload->'delegation'->'active'='true'::jsonb AND payload->'delegation'->'budget'->'maxToolCalls'='1'::jsonb AND payload->'delegation'->'budget'->'maxStages'='1'::jsonb AND payload->'delegation'->'budget'->'maxChildren'='0'::jsonb AND payload->'delegation'->'budget'->'maxNativeJobs'='0'::jsonb AND payload->'delegation'->'budget'->'maxTokens'='1'::jsonb AND NOT jsonb_path_exists(payload,'$.* ? (@ == null)')),false)), \n\tCONSTRAINT ck_input_delegation_nested_closed CHECK (jsonb_typeof((payload->'authority'))='object' AND (payload->'authority') ?& ARRAY['subject','sessionId','sessionGeneration','applicationGeneration','subjectGeneration','hostSessionRef','profileRef','policyGeneration'] AND ((payload->'authority') - ARRAY['subject','sessionId','sessionGeneration','applicationGeneration','subjectGeneration','hostSessionRef','profileRef','policyGeneration'])='{}'::jsonb AND jsonb_typeof((payload->'creationHostAuthority'))='object' AND (payload->'creationHostAuthority') ?& ARRAY['id','subject','active','policyGeneration','capabilityRefs','resourceBounds','purpose','checkedAt','validUntil','assuranceRef','delegationRef'] AND ((payload->'creationHostAuthority') - ARRAY['id','subject','active','policyGeneration','capabilityRefs','resourceBounds','purpose','checkedAt','validUntil','assuranceRef','delegationRef'])='{}'::jsonb AND jsonb_typeof((payload->'input'))='object' AND (payload->'input') ?& ARRAY['id','subject','taskId','rootId','admissionId','profileId','segmentId','controlEpoch','revision','predecessorId','predecessorRevision','commandId','commandDigest','inputDigest','requestDigest','artifactRef','ciphertextDigest','createdAt','expiresAt'] AND ((payload->'input') - ARRAY['id','subject','taskId','rootId','admissionId','profileId','segmentId','controlEpoch','revision','predecessorId','predecessorRevision','commandId','commandDigest','inputDigest','requestDigest','artifactRef','ciphertextDigest','createdAt','expiresAt'])='{}'::jsonb AND jsonb_typeof((payload->'record'))='object' AND (payload->'record') ?& ARRAY['profileRef','id','subject','taskId','rootId','segmentId','controlEpoch','inputId','inputRevision','inputDigest','acceptedId','proposalDigest','bindingDigest','artifactRef','ciphertextDigest','createdAt','expiresAt'] AND ((payload->'record') - ARRAY['profileRef','id','subject','taskId','rootId','segmentId','controlEpoch','inputId','inputRevision','inputDigest','acceptedId','proposalDigest','bindingDigest','artifactRef','ciphertextDigest','createdAt','expiresAt'])='{}'::jsonb AND jsonb_typeof((payload->'delegation'->'budget'))='object' AND (payload->'delegation'->'budget') ?& ARRAY['maxStages','maxChildren','maxTokens','maxToolCalls','maxNativeJobs','deadlineMs'] AND ((payload->'delegation'->'budget') - ARRAY['maxStages','maxChildren','maxTokens','maxToolCalls','maxNativeJobs','deadlineMs'])='{}'::jsonb AND COALESCE((payload->'input'->'subject'=payload->'subject' AND payload->'record'->'subject'=payload->'subject' AND payload->'creationHostAuthority'->'subject'=payload->'subject' AND payload->'delegation'->'revision'='1'::jsonb AND payload->'creationHostAuthority'->'active'='true'::jsonb AND payload->'creationHostAuthority'->>'purpose'='assistant.prepare' AND payload->'creationHostAuthority'->'delegationRef'='null'::jsonb AND payload->'authority'->>'profileRef'='local-synthetic' AND NOT jsonb_path_exists(payload->'authority','$.* ? (@ == null)')),false))\n)\n\n")
    op.execute("CREATE TRIGGER immutable_os_input_delegations BEFORE UPDATE OR DELETE ON os_input_delegations FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','task_id','segment_id','root_id','input_version_id','input_revision','input_digest','control_epoch','proposal_id','proposal_digest','session_id','command_id','command_digest','delegation_digest','payload','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute("\nCREATE TABLE os_input_delegated_grants (\n\tid UUID NOT NULL, \n\tdelegation_id UUID NOT NULL, \n\tdelegation_digest VARCHAR(64) NOT NULL, \n\ttask_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tinput_version_id UUID NOT NULL, \n\tinput_revision BIGINT NOT NULL, \n\tinput_digest VARCHAR(64) NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\tproposal_id UUID NOT NULL, \n\tproposal_digest VARCHAR(64) NOT NULL, \n\tgrant_digest VARCHAR(64) NOT NULL, \n\tinvocation_id UUID NOT NULL, \n\teffect_request_digest VARCHAR(64) NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_input_delegated_grant_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_input_delegated_grant_once UNIQUE (installation_id, application_id, tenant_id, subject_id, delegation_id), \n\tCONSTRAINT uq_input_delegated_grant_exact UNIQUE (installation_id, application_id, tenant_id, subject_id, id, grant_digest, task_id, segment_id, root_id, control_epoch, invocation_id, effect_request_digest), \n\tCONSTRAINT fk_input_delegated_grant_consent_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, delegation_id, delegation_digest, task_id, segment_id, root_id, input_version_id, input_revision, input_digest, control_epoch, proposal_id, proposal_digest) REFERENCES os_input_delegations (installation_id, application_id, tenant_id, subject_id, id, delegation_digest, task_id, segment_id, root_id, input_version_id, input_revision, input_digest, control_epoch, proposal_id, proposal_digest), \n\tCONSTRAINT ck_input_delegated_grant_versions CHECK (control_epoch>0 AND input_revision BETWEEN 1 AND 4), \n\tCONSTRAINT ck_input_delegated_grant_time CHECK (expires_at>created_at AND expires_at<=created_at+interval '5 minutes'), \n\tCONSTRAINT ck_input_delegated_grant_json CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536), \n\tCONSTRAINT ck_input_delegated_grant_delegation_digest CHECK (delegation_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_grant_input_digest CHECK (input_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_grant_proposal_digest CHECK (proposal_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_grant_grant_digest CHECK (grant_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_grant_effect_request_digest CHECK (effect_request_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_grant_closed_binding CHECK (jsonb_typeof((payload))='object' AND (payload) ?& ARRAY['profileRef','id','subject','taskId','segmentId','rootId','controlEpoch','delegationId','delegationDigest','authorization','inputId','inputRevision','inputDigest','proposalId','proposalRevision','proposalDigest','sourcePinDigest','requestDigest','stageId','capabilityRef','providerRef','invocationId','effectRequestDigest','registrationRevision','definitionDigest','bundleRevision','bundleDigest','createdAt','expiresAt','grantDigest'] AND ((payload) - ARRAY['profileRef','id','subject','taskId','segmentId','rootId','controlEpoch','delegationId','delegationDigest','authorization','inputId','inputRevision','inputDigest','proposalId','proposalRevision','proposalDigest','sourcePinDigest','requestDigest','stageId','capabilityRef','providerRef','invocationId','effectRequestDigest','registrationRevision','definitionDigest','bundleRevision','bundleDigest','createdAt','expiresAt','grantDigest'])='{}'::jsonb AND jsonb_typeof((payload->'authorization'))='object' AND (payload->'authorization') ?& ARRAY['kind','delegation'] AND ((payload->'authorization') - ARRAY['kind','delegation'])='{}'::jsonb AND jsonb_typeof((payload->'authorization'->'delegation'))='object' AND (payload->'authorization'->'delegation') ?& ARRAY['id','subject','revision','capabilityRefs','resourceBounds','purpose','maxRisk','validFrom','validUntil','budget','active'] AND ((payload->'authorization'->'delegation') - ARRAY['id','subject','revision','capabilityRefs','resourceBounds','purpose','maxRisk','validFrom','validUntil','budget','active'])='{}'::jsonb AND COALESCE((payload->>'id'=id::text AND payload->>'grantDigest'=grant_digest AND payload->>'delegationId'=delegation_id::text AND payload->>'delegationDigest'=delegation_digest AND payload->>'taskId'=task_id::text AND payload->>'segmentId'=segment_id::text AND payload->>'rootId'=root_id::text AND payload->>'controlEpoch'=control_epoch::text AND payload->>'inputId'=input_version_id::text AND payload->>'inputRevision'=input_revision::text AND payload->>'inputDigest'=input_digest AND payload->>'proposalId'=proposal_id::text AND payload->>'proposalDigest'=proposal_digest AND payload->>'invocationId'=invocation_id::text AND payload->>'effectRequestDigest'=effect_request_digest AND payload->'subject'=jsonb_build_object('installationId',installation_id::text,'applicationId',application_id::text,'tenantId',tenant_id,'subjectId',subject_id) AND payload->>'profileRef'='input-delegated-execution/1' AND payload->'authorization'->>'kind'='bounded_delegation' AND payload->'bundleRevision'='6'::jsonb AND NOT jsonb_path_exists(payload,'$.* ? (@ == null)')),false))\n)\n\n")
    op.execute("CREATE TRIGGER immutable_os_input_delegated_grants BEFORE UPDATE OR DELETE ON os_input_delegated_grants FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','delegation_id','delegation_digest','task_id','segment_id','root_id','input_version_id','input_revision','input_digest','control_epoch','proposal_id','proposal_digest','grant_digest','invocation_id','effect_request_digest','payload','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('\nCREATE TABLE os_input_delegation_revocations (\n\tid UUID NOT NULL, \n\tdelegation_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_input_delegation_revocation_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_input_delegations_delegation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, delegation_id) REFERENCES os_input_delegations (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_input_delegation_revoked_once UNIQUE (installation_id, application_id, tenant_id, subject_id, delegation_id), \n\tCONSTRAINT uq_input_delegation_revoke_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT fk_input_delegation_revoke_session FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id)\n)\n\n')
    op.execute("CREATE TRIGGER immutable_os_input_delegation_revocations BEFORE UPDATE OR DELETE ON os_input_delegation_revocations FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','delegation_id','session_id','command_id','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute("\nCREATE TABLE os_input_delegated_attempts (\n\tid UUID NOT NULL, \n\tattempt_id UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\tinvocation_id UUID NOT NULL, \n\treservation_digest VARCHAR(64) NOT NULL, \n\tgrant_id UUID NOT NULL, \n\tgrant_digest VARCHAR(64) NOT NULL, \n\teffect_request_digest VARCHAR(64) NOT NULL, \n\tpermit_id UUID NOT NULL, \n\tvisibility_generation BIGINT NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_input_delegated_attempt_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_input_delegated_attempt_once UNIQUE (installation_id, application_id, tenant_id, subject_id, attempt_id), \n\tCONSTRAINT uq_input_delegated_effect_once UNIQUE (installation_id, application_id, tenant_id, subject_id, grant_id), \n\tCONSTRAINT uq_input_delegated_permit UNIQUE (installation_id, application_id, tenant_id, subject_id, permit_id), \n\tCONSTRAINT uq_input_delegated_observation_source UNIQUE (installation_id, application_id, tenant_id, subject_id, id, invocation_id, effect_request_digest), \n\tCONSTRAINT fk_input_delegated_work_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id, task_id, segment_id, root_id, control_epoch, invocation_id, reservation_digest) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, root_id, control_epoch, invocation_id, request_digest), \n\tCONSTRAINT fk_input_delegated_attempt_grant_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, grant_id, grant_digest, task_id, segment_id, root_id, control_epoch, invocation_id, effect_request_digest) REFERENCES os_input_delegated_grants (installation_id, application_id, tenant_id, subject_id, id, grant_digest, task_id, segment_id, root_id, control_epoch, invocation_id, effect_request_digest), \n\tCONSTRAINT ck_input_delegated_attempt_versions CHECK (control_epoch>0 AND visibility_generation>0), \n\tCONSTRAINT ck_input_delegated_attempt_reservation_digest CHECK (reservation_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_attempt_grant_digest CHECK (grant_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_attempt_effect_request_digest CHECK (effect_request_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT uq_input_delegated_notification_task UNIQUE (installation_id, application_id, tenant_id, subject_id, id, task_id)\n)\n\n")
    op.execute("CREATE TRIGGER immutable_os_input_delegated_attempts BEFORE UPDATE OR DELETE ON os_input_delegated_attempts FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','attempt_id','task_id','segment_id','root_id','control_epoch','invocation_id','reservation_digest','grant_id','grant_digest','effect_request_digest','permit_id','visibility_generation','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute("\nCREATE TABLE os_input_delegated_receipts (\n\tid UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tinvocation_id UUID NOT NULL, \n\teffect_request_digest VARCHAR(64) NOT NULL, \n\tprovider_binding_digest VARCHAR(64) NOT NULL, \n\tobservation_digest VARCHAR(64) NOT NULL, \n\tordinal BIGINT NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_input_delegated_receipt_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_input_delegated_receipt_ordinal UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id, ordinal), \n\tCONSTRAINT uq_input_delegated_receipt_link UNIQUE (installation_id, application_id, tenant_id, subject_id, id, binding_id, observation_digest), \n\tCONSTRAINT fk_input_delegated_receipt_source FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id, invocation_id, effect_request_digest) REFERENCES os_input_delegated_attempts (installation_id, application_id, tenant_id, subject_id, id, invocation_id, effect_request_digest), \n\tCONSTRAINT ck_input_delegated_receipt_ordinal CHECK (ordinal BETWEEN 1 AND 32), \n\tCONSTRAINT ck_input_delegated_receipt_json CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=16384), \n\tCONSTRAINT ck_input_delegated_receipt_effect_request_digest CHECK (effect_request_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_receipt_provider_binding_digest CHECK (provider_binding_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_receipt_observation_digest CHECK (observation_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegated_receipt_closed CHECK (jsonb_typeof((payload))='object' AND (payload) ?& ARRAY['subject','providerRef','invocationId','requestDigest','receiptId','status','version','observedAt','attestationProfile'] AND ((payload) - ARRAY['subject','providerRef','invocationId','requestDigest','receiptId','status','version','observedAt','attestationProfile'])='{}'::jsonb AND COALESCE((payload->>'attestationProfile'='atomic-host-receipt-observation/1' AND payload->>'invocationId'=invocation_id::text AND payload->>'requestDigest'=effect_request_digest AND payload->'subject'=jsonb_build_object('installationId',installation_id::text,'applicationId',application_id::text,'tenantId',tenant_id,'subjectId',subject_id) AND payload->>'status' IN ('PENDING','COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED','UNKNOWN')),false))\n)\n\n")
    op.execute("CREATE TRIGGER immutable_os_input_delegated_receipts BEFORE UPDATE OR DELETE ON os_input_delegated_receipts FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','binding_id','invocation_id','effect_request_digest','provider_binding_digest','observation_digest','ordinal','payload','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute("\nCREATE TABLE os_private_notification_intents (\n\tid UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tprojection_id UUID NOT NULL, \n\tobservation_digest VARCHAR(64) NOT NULL, \n\tterminal_digest VARCHAR(64) NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_private_notification_intent_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_private_notification_terminal_once UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id, terminal_digest), \n\tCONSTRAINT fk_private_notification_exact_receipt FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, projection_id, binding_id, observation_digest) REFERENCES os_input_delegated_receipts (installation_id, application_id, tenant_id, subject_id, id, binding_id, observation_digest), \n\tCONSTRAINT ck_private_notification_safe_json CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=2048), \n\tCONSTRAINT ck_private_notification_observation_digest CHECK (observation_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_private_notification_terminal_digest CHECK (terminal_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT fk_private_notification_source_task FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id, task_id) REFERENCES os_input_delegated_attempts (installation_id, application_id, tenant_id, subject_id, id, task_id), \n\tCONSTRAINT ck_private_notification_closed CHECK (jsonb_typeof((payload))='object' AND (payload) ?& ARRAY['id','taskId','createdAt','kind','safeSummary','acknowledged'] AND ((payload) - ARRAY['id','taskId','createdAt','kind','safeSummary','acknowledged'])='{}'::jsonb AND COALESCE((payload->>'id'=id::text AND payload->>'taskId'=task_id::text AND payload->>'kind'='delegated-effect' AND payload->'acknowledged'='false'::jsonb AND payload->>'safeSummary' IN ('Delegated change was applied.','Delegated change was not applied.')),false))\n)\n\n")
    op.execute("CREATE TRIGGER immutable_os_private_notification_intents BEFORE UPDATE OR DELETE ON os_private_notification_intents FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','task_id','binding_id','projection_id','observation_digest','terminal_digest','payload','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute("\nCREATE TABLE os_private_notification_deliveries (\n\tid UUID NOT NULL, \n\tnotification_id UUID NOT NULL, \n\tversion BIGINT NOT NULL, \n\tstate VARCHAR(16) NOT NULL, \n\tattempts BIGINT NOT NULL, \n\tlease_token UUID, \n\tlease_until TIMESTAMP WITH TIME ZONE, \n\tnext_attempt_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_private_notification_delivery_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_private_notification_intents_notification_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, notification_id) REFERENCES os_private_notification_intents (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_private_notification_delivery_once UNIQUE (installation_id, application_id, tenant_id, subject_id, notification_id), \n\tCONSTRAINT ck_private_notification_delivery_versions CHECK (version>0 AND attempts BETWEEN 0 AND 8), \n\tCONSTRAINT ck_private_notification_delivery_state CHECK (state IN ('DUE','LEASED','DELIVERED','POISON')), \n\tCONSTRAINT ck_private_notification_delivery_lease CHECK ((state='LEASED' AND lease_token IS NOT NULL AND lease_until IS NOT NULL) OR (state<>'LEASED' AND lease_token IS NULL AND lease_until IS NULL))\n)\n\n")
    op.execute('CREATE INDEX ix_private_notification_due ON os_private_notification_deliveries (state, next_attempt_at)')
    op.execute("CREATE TRIGGER immutable_os_private_notification_deliveries BEFORE UPDATE OR DELETE ON os_private_notification_deliveries FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','notification_id','installation_id','application_id','tenant_id','subject_id')")
    op.execute('\nCREATE TABLE os_private_notification_inbox (\n\tid UUID NOT NULL, \n\tnotification_id UUID NOT NULL, \n\tdelivered_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_private_notification_inbox_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_private_notification_intents_notification_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, notification_id) REFERENCES os_private_notification_intents (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_private_notification_inbox_once UNIQUE (installation_id, application_id, tenant_id, subject_id, notification_id)\n)\n\n')
    op.execute("CREATE TRIGGER immutable_os_private_notification_inbox BEFORE UPDATE OR DELETE ON os_private_notification_inbox FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','notification_id','delivered_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute('\nCREATE TABLE os_private_notification_acknowledgements (\n\tid UUID NOT NULL, \n\tnotification_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_private_notification_acknowledgement_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_private_notification_intents_notification_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, notification_id) REFERENCES os_private_notification_intents (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_private_notification_ack_once UNIQUE (installation_id, application_id, tenant_id, subject_id, notification_id), \n\tCONSTRAINT uq_private_notification_ack_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT fk_private_notification_ack_session FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_private_notification_delivered_ack FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, notification_id) REFERENCES os_private_notification_inbox (installation_id, application_id, tenant_id, subject_id, notification_id)\n)\n\n')
    op.execute("CREATE TRIGGER immutable_os_private_notification_acknowledgements BEFORE UPDATE OR DELETE ON os_private_notification_acknowledgements FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','notification_id','session_id','command_id','created_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute(CURRENT_GUARDS)


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use protected fresh recovery")
