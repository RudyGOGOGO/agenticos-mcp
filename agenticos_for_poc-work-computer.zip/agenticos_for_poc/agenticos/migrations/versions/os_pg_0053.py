"""Use the application primary key in current assistant owner guards."""
from alembic import op

revision="os_pg_0053"
down_revision="os_pg_0052"
branch_labels=None
depends_on=None
GUARDS=r"""
CREATE OR REPLACE FUNCTION os_assistant_owner(i uuid,a uuid,t text,s text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM 1 FROM os_applications WHERE installation_id=i AND id=a AND active FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'assistant_current_application';END IF;
 PERFORM 1 FROM os_subjects WHERE installation_id=i AND application_id=a AND tenant_id=t AND subject_id=s AND active FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'assistant_current_owner';END IF;
END $$;

CREATE OR REPLACE FUNCTION os_assistant_persona_command_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE p os_assistant_personas%ROWTYPE; sess os_interactive_sessions%ROWTYPE;
BEGIN
 PERFORM os_assistant_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 SELECT * INTO p FROM os_assistant_personas WHERE id=NEW.persona_id FOR UPDATE;
 SELECT * INTO sess FROM os_interactive_sessions WHERE id=NEW.session_id FOR UPDATE;
 IF p.version IS DISTINCT FROM NEW.expected_version OR sess.id IS NULL OR sess.revoked OR sess.expires_at<=clock_timestamp()
  OR sess.application_generation IS DISTINCT FROM (SELECT generation FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id)
  OR sess.subject_generation IS DISTINCT FROM (SELECT generation FROM os_subjects WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id AND tenant_id=NEW.tenant_id AND subject_id=NEW.subject_id)
 THEN RAISE EXCEPTION 'assistant_persona_current_command';END IF;
 RETURN NEW;
END $$;
"""

def upgrade():
    op.execute(GUARDS)

def downgrade():
    raise RuntimeError("Assistant owner guards require reviewed forward recovery")
