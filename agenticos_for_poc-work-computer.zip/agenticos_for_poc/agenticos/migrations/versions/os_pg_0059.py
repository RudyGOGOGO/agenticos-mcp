"""Bind new production admissions to immutable server-owned configuration.

Frozen profiles and existing rows are not rebound. No workflow is activated.
"""
from alembic import op

revision='os_pg_0059'
down_revision='os_pg_0058'
branch_labels=None
depends_on=None

TABLES = "\nCREATE TABLE os_agent_profiles (\n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\tdefinition_ref VARCHAR(256) NOT NULL, \n\trevision BIGINT NOT NULL, \n\tregistration_revision BIGINT NOT NULL, \n\tapplication_generation BIGINT NOT NULL, \n\tdigest VARCHAR(64) NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tPRIMARY KEY (installation_id, application_id, definition_ref, revision), \n\tCONSTRAINT fk_agent_profile_application FOREIGN KEY(installation_id, application_id) REFERENCES os_applications (installation_id, id), \n\tCONSTRAINT ck_agent_profile_revision CHECK (revision>0 AND registration_revision>0 AND application_generation>0), \n\tCONSTRAINT ck_agent_profile_payload CHECK (jsonb_typeof(payload)='object'), \n\tCONSTRAINT ck_agent_profile_digest CHECK (digest ~ '^[a-f0-9]{64}$')\n)\n\n;\nALTER TABLE os_dispatches DROP CONSTRAINT ck_dispatch_profile;\nALTER TABLE os_dispatches ADD CONSTRAINT ck_dispatch_profile CHECK (workflow_profile IN ('OSAdmissionTransport/1','OSTaskDriver/1','OSTrustedTaskDriver/1','OSTrustedTaskDriver/2','OSTaskMemoryDriver/1','OSNativeTaskDriver/1','OSAgentTaskDriver/1'));\n"

GUARDS = r"""
CREATE FUNCTION os_agent_profile_canonical(v jsonb,depth integer) RETURNS text LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE result text;
BEGIN
 IF depth>64 THEN RAISE EXCEPTION 'agent_profile_nesting'; END IF;
 IF jsonb_typeof(v)='object' THEN
  IF EXISTS(SELECT 1 FROM jsonb_object_keys(v) AS k WHERE octet_length(k)<>char_length(k))
   THEN RAISE EXCEPTION 'agent_profile_key'; END IF;
  SELECT '{'||COALESCE(string_agg(to_jsonb(key)::text||':'||os_agent_profile_canonical(value,depth+1),',' ORDER BY key COLLATE "C"),'')||'}'
   INTO result FROM jsonb_each(v);
  RETURN result;
 ELSIF jsonb_typeof(v)='array' THEN
  SELECT '['||COALESCE(string_agg(os_agent_profile_canonical(value,depth+1),',' ORDER BY ordinal),'')||']'
   INTO result FROM jsonb_array_elements(v) WITH ORDINALITY AS a(value,ordinal);
  RETURN result;
 END IF;
 IF jsonb_typeof(v)='number' AND (v::text !~ '^-?(0|[1-9][0-9]*)$' OR abs(v::numeric)>9007199254740991)
  THEN RAISE EXCEPTION 'agent_profile_number'; END IF;
 RETURN v::text;
END $$;

CREATE FUNCTION os_agent_profile_digest(purpose text,v jsonb) RETURNS text LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
 IF purpose NOT IN ('manifest','definition','policy','command') THEN RAISE EXCEPTION 'agent_profile_hash_purpose'; END IF;
 RETURN encode(sha256(convert_to('agentic-os.hash/1','UTF8')||decode('00','hex')||convert_to(purpose,'UTF8')||decode('00','hex')||convert_to(os_agent_profile_canonical(v,0),'UTF8')),'hex');
END $$;

CREATE FUNCTION os_agent_profile_pin(v jsonb,purpose text) RETURNS jsonb LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
 RETURN jsonb_build_object('ref',v->'id','revision',v->'revision','digest',os_agent_profile_digest(purpose,v));
END $$;

CREATE FUNCTION os_guard_agent_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE app os_applications%ROWTYPE; d jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_profile_immutable'; END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR SHARE;
 d:=NEW.payload->'definition';
 IF NOT COALESCE(app.id IS NOT NULL AND app.active AND app.revision=NEW.registration_revision
  AND app.generation=NEW.application_generation AND NEW.created_at<=clock_timestamp()
  AND NEW.digest=os_agent_profile_digest('manifest',NEW.payload)
  AND NEW.payload=jsonb_build_object('definition',d,'runtime',NEW.payload->'runtime','harness',NEW.payload->'harness',
   'model',NEW.payload->'model','resources',NEW.payload->'resources','grantCeiling',NEW.payload->'grantCeiling','capabilities',NEW.payload->'capabilities')
  AND d->>'id'=NEW.definition_ref AND d->>'revision'=NEW.revision::text AND d->>'schema'='agent-production/1'
  AND d->'profile'=os_agent_profile_pin(NEW.payload->'runtime','manifest')
  AND d->'model'=os_agent_profile_pin(NEW.payload->'model','manifest')
  AND d->'harness'=NEW.payload->'harness'->'harness'
  AND d->'capabilityPolicy'=os_agent_profile_pin(NEW.payload->'capabilities','policy')
  AND d->'resourcePolicy'->>'digest'=os_agent_profile_digest('policy',NEW.payload->'resources')
  AND d->'purpose'=NEW.payload->'capabilities'->'purpose'
  AND NEW.payload->'runtime'->>'workflowProfile'='OSAgentTaskDriver/1',false)
  THEN RAISE EXCEPTION 'agent_profile_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_profile BEFORE INSERT OR UPDATE OR DELETE ON os_agent_profiles
FOR EACH ROW EXECUTE FUNCTION os_guard_agent_profile();

CREATE FUNCTION os_assert_agent_admission(aid uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; p os_agent_profiles%ROWTYPE; t os_tasks%ROWTYPE;
 r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; s os_segments%ROWTYPE;
 i os_source_inputs%ROWTYPE; c os_commands%ROWTYPE; d os_dispatches%ROWTYPE; ctrl os_task_controls%ROWTYPE;
 owner_json jsonb; configured jsonb; admitted timestamptz; horizon timestamptz;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_admissions WHERE id=aid;
 IF a.context->>'accountingFormat' IS DISTINCT FROM 'agent-resources/1' THEN RETURN; END IF;
 SELECT * INTO t FROM os_tasks WHERE id=a.task_id;
 SELECT * INTO p FROM os_agent_profiles WHERE installation_id=a.installation_id AND application_id=a.application_id
  AND definition_ref=t.definition_ref AND revision=t.definition_revision;
 SELECT * INTO r FROM os_budget_roots WHERE id=t.budget_root_id;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=r.id;
 SELECT * INTO s FROM os_segments WHERE id=a.segment_id;
 SELECT * INTO i FROM os_source_inputs WHERE id=a.source_input_id;
 SELECT * INTO c FROM os_commands WHERE accepted_task_id=t.id AND kind='agent.task.start';
 SELECT * INTO d FROM os_dispatches WHERE task_id=t.id;
 SELECT * INTO ctrl FROM os_task_controls WHERE task_id=t.id;
 owner_json:=jsonb_build_object('installationId',a.installation_id,'applicationId',a.application_id,'tenantId',a.tenant_id,'subjectId',a.subject_id);
 configured:=p.payload->'definition';
 admitted:=(a.context->>'admittedAt')::timestamptz; horizon:=(a.context->>'authorizationHorizon')::timestamptz;
 IF NOT COALESCE(p.definition_ref IS NOT NULL AND a.bot=p.payload
  AND p.digest=os_agent_profile_digest('manifest',p.payload) AND p.registration_revision=a.registration_revision
  AND p.application_generation=q.application_generation
  AND configured->>'lifecycle'='qualified' AND p.payload->'model'->>'lifecycle'='qualified'
  AND r.id IS NOT NULL AND r.accounting_format='agent-resources/1' AND r.profile_ref='agent-production/1'
  AND r.root_task_id=t.id AND r.admission_id=a.id AND r.definition_digest=os_agent_profile_digest('definition',configured)
  AND q.id IS NOT NULL AND q.policy=p.payload->'resources' AND q.grant_ceiling=p.payload->'grantCeiling'
  AND q.policy_ref=configured->'resourcePolicy'->>'ref' AND q.policy_revision::text=configured->'resourcePolicy'->>'revision'
  AND q.policy_digest=configured->'resourcePolicy'->>'digest' AND q.purpose=configured->>'purpose'
  AND r.ceiling=p.payload->'resources'->'limits' AND q.horizon=r.deadline AND t.deadline=r.deadline AND horizon=r.deadline
  AND admitted=c.created_at AND admitted<=clock_timestamp() AND admitted<horizon
  AND horizon<=admitted+((p.payload->'runtime'->>'authorizationHorizonMs')::bigint*interval '1 millisecond')
  AND EXISTS(SELECT 1 FROM pg_timezone_names WHERE name=p.payload->'runtime'->>'timeZone')
  AND a.context=jsonb_build_object('subject',owner_json,'taskId',t.id,'conversationId',t.conversation_id,'segmentId',s.id,
   'purpose',configured->'purpose','definition',os_agent_profile_pin(configured,'definition'),
   'profile',configured->'profile','harness',configured->'harness','model',configured->'model','resourcePolicy',configured->'resourcePolicy',
   'authorityRef',a.context->'authorityRef','scopeRef',a.context->'scopeRef','delegationRef',NULL,
   'rootId',r.id,'accountingFormat','agent-resources/1','intentRevision',1,'controlEpoch',1,
   'admittedAt',a.context->'admittedAt','authorizationHorizon',a.context->'authorizationHorizon','timeZone',p.payload->'runtime'->'timeZone')
  AND s.task_id=t.id AND s.conversation_id=t.conversation_id AND s.ordinal=1 AND s.state='OPEN'
  AND ctrl.epoch=1 AND ctrl.state='ACTIVE' AND i.admitted_task_id=t.id AND i.expires_at>admitted
  AND c.id IS NOT NULL AND d.command_id=c.id AND d.workflow_profile='OSAgentTaskDriver/1'
  AND a.authority->'subject'=owner_json AND q.session_id::text=a.authority->>'sessionId'
  AND a.digest=os_agent_profile_digest('command',jsonb_build_object('commandDigest',c.request_digest,
   'context',a.context,'bot',a.bot,'authority',a.authority,'sourceDigest',i.digest,'registrationRevision',a.registration_revision))
  AND a.launch=jsonb_build_object('installationId',a.installation_id,'applicationId',a.application_id,'taskId',t.id,'admissionDigest',a.digest),false)
  THEN RAISE EXCEPTION 'agent_admission_binding'; END IF;
 PERFORM os_agent_resource_owner(q);
END $$;

CREATE FUNCTION os_guard_agent_admission_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_TABLE_NAME='os_admissions' THEN PERFORM os_assert_agent_admission(NEW.id);
 ELSIF NEW.workflow_profile='OSAgentTaskDriver/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_admissions WHERE task_id=NEW.task_id AND context->>'accountingFormat'='agent-resources/1')
   THEN RAISE EXCEPTION 'agent_dispatch_admission'; END IF;
  PERFORM os_assert_agent_admission((SELECT id FROM os_admissions WHERE task_id=NEW.task_id));
 END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_agent_admission AFTER INSERT ON os_admissions
DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_agent_admission_commit();
CREATE CONSTRAINT TRIGGER commit_agent_dispatch AFTER INSERT ON os_dispatches
DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_agent_admission_commit();
"""


def upgrade():
    op.execute(TABLES)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Production admission requires protected forward recovery')
