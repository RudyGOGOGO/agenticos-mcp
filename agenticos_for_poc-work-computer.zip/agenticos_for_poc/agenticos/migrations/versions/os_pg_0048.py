"""Immutable selected task memory, protected KB snapshots and exact erasure."""
from alembic import op

revision='os_pg_0048'
down_revision='os_pg_0047'
branch_labels=None
depends_on=None
TABLES=("\nCREATE TABLE task_memory_bindings (\n\tid UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tadmission_id UUID NOT NULL, \n\tsettings_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcontext_id UUID, \n\tcontext_ref VARCHAR(128) NOT NULL, \n\tprofile_ref VARCHAR(64) NOT NULL, \n\tsettings_version BIGINT NOT NULL, \n\tlearning_epoch BIGINT NOT NULL, \n\trecall_epoch BIGINT NOT NULL, \n\tcontext_revision BIGINT NOT NULL, \n\tindex_generation BIGINT NOT NULL, \n\tjournal_sequence BIGINT NOT NULL, \n\treference_count BIGINT NOT NULL, \n\tmac_key_id UUID NOT NULL, \n\tknowledge_profile_ref VARCHAR(64), \n\tknowledge_binding_mac VARCHAR(64), \n\tbinding_mac VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tdeadline TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_task_memory_binding_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_admissions_admission_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, admission_id) REFERENCES os_admissions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_learning_settings_settings_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, settings_id) REFERENCES personal_learning_settings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_owner_memory_contexts_context_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, context_id) REFERENCES owner_memory_contexts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_task_memory_task_once UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id), \n\tCONSTRAINT ck_task_memory_profile CHECK (profile_ref='OSTaskMemory/1'), \n\tCONSTRAINT ck_task_memory_epochs CHECK (settings_version>0 AND learning_epoch>0 AND recall_epoch>0 AND context_revision>0 AND index_generation>0 AND journal_sequence>=0), \n\tCONSTRAINT ck_task_memory_reference_count CHECK (reference_count BETWEEN 0 AND 8), \n\tCONSTRAINT ck_task_memory_deadline CHECK (deadline>created_at), \n\tCONSTRAINT ck_task_memory_context CHECK ((context_id IS NULL AND context_ref='general/1') OR (context_id IS NOT NULL AND context_ref='context/'||context_id::text||'/1')), \n\tCONSTRAINT ck_task_memory_knowledge_profile CHECK ((knowledge_profile_ref IS NULL AND knowledge_binding_mac IS NULL) OR (knowledge_profile_ref IS NOT NULL AND knowledge_binding_mac IS NOT NULL AND knowledge_profile_ref='OSProtectedPlanning/1' AND knowledge_binding_mac ~ '^[0-9a-f]{64}$')), \n\tCONSTRAINT ck_task_memory_binding_digest CHECK (binding_mac ~ '^[a-f0-9]{64}$')\n)\n\n", "\nCREATE TABLE task_knowledge_snapshots (\n\tid UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tkey_id UUID NOT NULL, \n\tcontent_revision BIGINT NOT NULL, \n\tvalid_until TIMESTAMP WITH TIME ZONE, \n\treference_metadata JSONB NOT NULL, \n\tbinding_mac VARCHAR(64) NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_task_knowledge_snapshot_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_bindings_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES task_memory_bindings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_task_knowledge_binding_once UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id), \n\tCONSTRAINT ck_task_knowledge_content_revision CHECK (content_revision>=0), \n\tCONSTRAINT ck_task_knowledge_references CHECK (jsonb_typeof(reference_metadata)='array' AND jsonb_array_length(reference_metadata)<=16 AND octet_length(reference_metadata::text)<=16384), \n\tCONSTRAINT ck_task_knowledge_snapshot_digest CHECK (binding_mac ~ '^[a-f0-9]{64}$')\n)\n\n", "\nCREATE TABLE task_memory_erasures (\n\tid UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tbatch_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcleanup_session_id UUID, \n\tstate VARCHAR(16) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tcompleted_at TIMESTAMP WITH TIME ZONE, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_task_memory_erasure_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_bindings_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES task_memory_bindings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_memory_forget_batches_batch_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, batch_id) REFERENCES memory_forget_batches (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_cleanup_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, cleanup_session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_task_memory_erasure_once UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id), \n\tCONSTRAINT ck_task_memory_erasure_state CHECK ((state='PENDING' AND completed_at IS NULL AND cleanup_session_id IS NULL) OR (state='COMPLETE' AND completed_at>=created_at AND cleanup_session_id IS NOT NULL))\n)\n\n", "\nCREATE TABLE task_memory_references (\n\tid UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tentry_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\tentry_version BIGINT NOT NULL, \n\tprojection_id UUID NOT NULL, \n\tlane VARCHAR(16) NOT NULL, \n\tcontext_ref VARCHAR(128) NOT NULL, \n\tordinal BIGINT NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_task_memory_reference_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_bindings_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES task_memory_bindings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_reference_exact_revision FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, entry_id, id), \n\tCONSTRAINT uq_task_memory_entry_once UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id, entry_id), \n\tCONSTRAINT uq_task_memory_ordinal UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id, ordinal), \n\tCONSTRAINT ck_task_memory_reference_versions CHECK (entry_version>0 AND ordinal BETWEEN 0 AND 7), \n\tCONSTRAINT ck_task_memory_reference_lane CHECK (lane IN ('preference','episodic','semantic','procedural'))\n)\n\n", '\nCREATE TABLE task_memory_events (\n\tid UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tevent_id UUID NOT NULL, \n\terasure_id UUID, \n\terased_at TIMESTAMP WITH TIME ZONE, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_task_memory_event_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_bindings_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES task_memory_bindings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_public_events_event_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, event_id) REFERENCES os_public_events (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_erasures_erasure_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, erasure_id) REFERENCES task_memory_erasures (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_task_memory_event_once UNIQUE (installation_id, application_id, tenant_id, subject_id, event_id), \n\tCONSTRAINT ck_task_memory_event_erasure CHECK ((erasure_id IS NULL AND erased_at IS NULL) OR (erasure_id IS NOT NULL AND erased_at IS NOT NULL))\n)\n\n', "\nCREATE TABLE task_memory_outputs (\n\tid UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tartifact_id UUID NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\terasure_id UUID, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\terased_at TIMESTAMP WITH TIME ZONE, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_task_memory_output_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_bindings_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES task_memory_bindings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_artifacts_artifact_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, artifact_id) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_erasures_erasure_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, erasure_id) REFERENCES task_memory_erasures (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_task_memory_output_once UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id), \n\tCONSTRAINT ck_task_memory_output_erasure CHECK ((erasure_id IS NULL AND erased_at IS NULL) OR (erasure_id IS NOT NULL AND erased_at>=created_at)), \n\tCONSTRAINT ck_task_memory_output_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$')\n)\n\n", '\nCREATE TABLE task_memory_artifacts (\n\tid UUID NOT NULL, \n\tbinding_id UUID NOT NULL, \n\tresult_id UUID NOT NULL, \n\tartifact_id UUID NOT NULL, \n\terasure_id UUID, \n\terased_at TIMESTAMP WITH TIME ZONE, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_task_memory_artifact_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_bindings_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES task_memory_bindings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_accepted_results_result_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, result_id) REFERENCES os_accepted_results (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_artifacts_artifact_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, artifact_id) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_task_memory_erasures_erasure_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, erasure_id) REFERENCES task_memory_erasures (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_task_memory_result_once UNIQUE (installation_id, application_id, tenant_id, subject_id, result_id), \n\tCONSTRAINT ck_task_memory_artifact_erasure CHECK ((erasure_id IS NULL AND erased_at IS NULL) OR (erasure_id IS NOT NULL AND erased_at IS NOT NULL))\n)\n\n')

GUARDS=r"""
CREATE FUNCTION os_assert_task_memory(bid uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE b task_memory_bindings%ROWTYPE; s personal_learning_settings%ROWTYPE;
 t os_tasks%ROWTYPE; a os_admissions%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; k task_knowledge_snapshots%ROWTYPE;
 n bigint; watermark bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 SELECT * INTO t FROM os_tasks WHERE id=b.task_id;
 SELECT * INTO a FROM os_admissions WHERE id=b.admission_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
 SELECT * INTO k FROM task_knowledge_snapshots WHERE binding_id=bid;
 SELECT count(*) INTO n FROM task_memory_references WHERE binding_id=bid;
 IF b.id IS NULL OR t.id IS NULL OR a.id IS NULL OR s.id IS NULL OR a.task_id<>t.id
  OR b.deadline<>t.deadline OR a.authority->>'sessionId' IS DISTINCT FROM b.session_id::text
  OR n<>b.reference_count OR EXISTS(SELECT 1 FROM task_memory_references r WHERE r.binding_id=bid AND r.ordinal>=n)
  OR (SELECT count(*) FROM task_memory_bindings WHERE settings_id=s.id)>128
  OR NOT EXISTS(SELECT 1 FROM os_dispatches WHERE task_id=t.id AND workflow_profile='OSTaskMemoryDriver/1')
  OR (b.knowledge_profile_ref IS NULL) IS DISTINCT FROM (k.id IS NULL)
  OR (k.id IS NOT NULL AND b.knowledge_binding_mac IS DISTINCT FROM k.binding_mac)
  OR (k.id IS NOT NULL AND EXISTS(SELECT 1 FROM jsonb_array_elements(k.reference_metadata) r
   WHERE r IS DISTINCT FROM jsonb_build_object('chunkId',r->'chunkId','documentId',r->'documentId',
    'revisionId',r->'revisionId','revision',r->'revision','layer',r->'layer','generationId',r->'generationId',
    'ciphertextDigest',r->'ciphertextDigest') OR r->>'layer' NOT IN ('business','architecture','system','shared')
    OR r->>'ciphertextDigest' !~ '^[0-9a-f]{64}$' OR jsonb_typeof(r->'revision')<>'number'))
  THEN RAISE EXCEPTION 'task_memory_exact_binding';END IF;
 IF NOT live THEN RETURN;END IF;
 SELECT sequence INTO watermark FROM memory_recovery_owners WHERE settings_id=s.id;
 IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation)
   IS DISTINCT FROM ROW(b.settings_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation)
  OR watermark IS DISTINCT FROM b.journal_sequence
  OR EXISTS(SELECT 1 FROM task_memory_erasures WHERE binding_id=bid)
  OR t.deadline<=clock_timestamp() OR session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR (k.valid_until IS NOT NULL AND k.valid_until<=clock_timestamp())
  THEN RAISE EXCEPTION 'task_memory_obsolete';END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
  AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
 IF app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
  OR owner.host_policy_generation IS DISTINCT FROM (a.authority->>'policyGeneration')::bigint
  THEN RAISE EXCEPTION 'task_memory_owner_obsolete';END IF;
 IF b.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=b.context_id
  AND settings_id=s.id AND kind='context' AND state='ACTIVE') THEN RAISE EXCEPTION 'task_memory_context_obsolete';END IF;
 IF n>0 AND (s.choice->>'useMemory' IS DISTINCT FROM 'true' OR s.choice->>'embeddingProfile'<>'minilm-english-onnx/1')
  THEN RAISE EXCEPTION 'task_memory_choice_obsolete';END IF;
 IF EXISTS(SELECT 1 FROM task_memory_references r JOIN personal_knowledge_entries e ON e.id=r.entry_id
  JOIN personal_knowledge_revisions v ON v.id=r.revision_id
  LEFT JOIN classified_knowledge_bindings c ON c.revision_id=r.revision_id
  WHERE r.binding_id=bid AND (e.settings_id<>s.id OR e.state<>'ACTIVE' OR e.version<>r.entry_version
   OR e.active_revision_id<>r.revision_id OR v.envelope IS NULL OR c.revision_id IS NULL
   OR c.lane<>r.lane OR r.context_ref IS DISTINCT FROM CASE WHEN c.context_id IS NULL THEN 'general/1'
     ELSE 'context/'||c.context_id::text||'/1' END
   OR r.context_ref NOT IN ('general/1',b.context_ref) OR os_revision_source_forgotten(r.revision_id)
   OR (e.valid_until IS NOT NULL AND e.valid_until<=clock_timestamp())
   OR (c.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=c.context_id AND state='ACTIVE'))
   OR (c.claim_key_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=c.claim_key_id AND state='ACTIVE'))
   OR NOT EXISTS(SELECT 1 FROM personal_index_pointers p JOIN personal_index_generations g ON g.id=p.generation_id
    WHERE p.entry_id=r.entry_id AND p.revision_id=r.revision_id AND p.entry_version=r.entry_version
    AND p.projection_id=r.projection_id AND g.settings_id=s.id AND g.generation=b.index_generation AND g.state='READY')))
  THEN RAISE EXCEPTION 'task_memory_reference_obsolete';END IF;
END $$;

CREATE FUNCTION os_task_memory_affected(bid uuid,fid uuid) RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE b task_memory_bindings%ROWTYPE; f memory_forget_batches%ROWTYPE;
BEGIN
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 SELECT * INTO f FROM memory_forget_batches WHERE id=fid;
 IF b.id IS NULL OR f.id IS NULL OR b.settings_id<>f.settings_id OR f.journal_sequence<=b.journal_sequence
  OR b.reference_count=0 THEN RETURN false;END IF;
 RETURN (f.kind='all' AND b.learning_epoch<=f.prior_learning_epoch)
  OR EXISTS(SELECT 1 FROM task_memory_references r JOIN memory_forget_entries m ON m.entry_id=r.entry_id
   WHERE r.binding_id=bid AND m.batch_id=fid)
  OR EXISTS(SELECT 1 FROM memory_forget_contexts WHERE batch_id=fid AND context_id=b.context_id)
  OR EXISTS(SELECT 1 FROM task_memory_references r JOIN personal_knowledge_publications p ON p.revision_id=r.revision_id
   JOIN personal_knowledge_candidate_sources c ON c.candidate_id=p.candidate_id
   JOIN memory_forget_sources m ON m.source_id=c.source_id WHERE r.binding_id=bid AND m.batch_id=fid);
END $$;

CREATE FUNCTION os_guard_task_memory_derivative() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'task_memory_use_retained';END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.erasure_id IS NOT NULL OR NEW.erased_at IS NOT NULL THEN RAISE EXCEPTION 'task_memory_derivative_initial';END IF;
 ELSE
  IF OLD.erasure_id IS NOT NULL OR NEW.erasure_id IS NULL OR NEW.erased_at IS NULL
   OR (to_jsonb(NEW)-ARRAY['erasure_id','erased_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['erasure_id','erased_at'])
   OR NOT EXISTS(SELECT 1 FROM task_memory_erasures WHERE id=NEW.erasure_id AND binding_id=NEW.binding_id AND state='PENDING')
   THEN RAISE EXCEPTION 'task_memory_derivative_erasure';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_guard_task_memory_erasure() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'task_memory_erasure_retained';END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'PENDING' OR NEW.completed_at IS NOT NULL OR NEW.cleanup_session_id IS NOT NULL
   OR NOT os_task_memory_affected(NEW.binding_id,NEW.batch_id) THEN RAISE EXCEPTION 'task_memory_erasure_initial';END IF;
 ELSE
  IF OLD.state<>'PENDING' OR NEW.state<>'COMPLETE' OR NEW.completed_at IS NULL OR NEW.cleanup_session_id IS NULL
   OR (to_jsonb(NEW)-ARRAY['state','completed_at','cleanup_session_id']) IS DISTINCT FROM
      (to_jsonb(OLD)-ARRAY['state','completed_at','cleanup_session_id'])
   THEN RAISE EXCEPTION 'task_memory_erasure_monotonic';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_commit_task_memory() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE bid uuid; b task_memory_bindings%ROWTYPE; e task_memory_erasures%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='task_memory_bindings' THEN bid=NEW.id;ELSE bid=NEW.binding_id;END IF;
 PERFORM os_assert_task_memory(bid,TG_OP='INSERT' AND TG_TABLE_NAME<>'task_memory_erasures');
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 IF TG_TABLE_NAME='task_memory_artifacts' THEN
  IF NOT EXISTS(SELECT 1 FROM os_accepted_results r JOIN os_artifacts a ON a.id=r.artifact_id
   WHERE r.id=NEW.result_id AND r.task_id=b.task_id AND r.artifact_id=NEW.artifact_id
    AND r.contract_ref='CognitiveStageResult' AND a.ciphertext_digest=r.ciphertext_digest AND a.purpose='artifact')
   THEN RAISE EXCEPTION 'task_memory_artifact_binding';END IF;
 ELSIF TG_TABLE_NAME='task_memory_outputs' THEN
  IF NOT EXISTS(SELECT 1 FROM os_artifacts WHERE id=NEW.artifact_id AND ciphertext_digest=NEW.ciphertext_digest
   AND purpose='artifact' AND classification='protected') THEN RAISE EXCEPTION 'task_memory_output_binding';END IF;
 ELSIF TG_TABLE_NAME='task_memory_events' THEN
  IF NOT EXISTS(SELECT 1 FROM os_public_events p JOIN os_segments s ON s.id=p.segment_id WHERE p.id=NEW.event_id
   AND s.task_id=b.task_id AND ((NEW.erasure_id IS NULL AND p.payload->>'name'='os.grounded/1') OR
    (NEW.erasure_id IS NOT NULL AND p.payload=jsonb_build_object('type','CUSTOM','name','os.memory-erased/1',
     'value',jsonb_build_object('erasureId',NEW.erasure_id))))) THEN RAISE EXCEPTION 'task_memory_event_binding';END IF;
 ELSIF TG_TABLE_NAME='task_memory_erasures' THEN
  SELECT * INTO e FROM task_memory_erasures WHERE id=NEW.id;
  IF NOT os_task_memory_affected(bid,e.batch_id) THEN RAISE EXCEPTION 'task_memory_erasure_scope';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=COALESCE(e.cleanup_session_id,e.session_id);
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'task_memory_erasure_owner';END IF;
  IF e.state='COMPLETE' AND (EXISTS(SELECT 1 FROM os_work_attempts WHERE task_id=b.task_id
    AND kind IN ('inference','repair') AND state IN ('RUNNING','UNKNOWN'))
   OR EXISTS(SELECT 1 FROM task_memory_artifacts WHERE binding_id=bid AND erasure_id IS NULL)
   OR EXISTS(SELECT 1 FROM task_memory_outputs WHERE binding_id=bid AND erasure_id IS NULL)
   OR EXISTS(SELECT 1 FROM task_memory_events WHERE binding_id=bid AND erasure_id IS NULL))
   THEN RAISE EXCEPTION 'task_memory_erasure_incomplete';END IF;
 END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_guard_task_memory_event() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE eid uuid; bid uuid; bound_task uuid;
BEGIN
 IF TG_OP<>'INSERT' THEN
  SELECT s.task_id INTO bound_task FROM os_segments s WHERE s.id=OLD.segment_id;
 ELSE
  SELECT s.task_id INTO bound_task FROM os_segments s WHERE s.id=NEW.segment_id;
 END IF;
 SELECT id INTO bid FROM task_memory_bindings WHERE task_id=bound_task;
 IF bid IS NULL THEN
  IF TG_OP='UPDATE' AND EXISTS(SELECT 1 FROM task_memory_bindings b JOIN os_segments s ON s.task_id=b.task_id
   WHERE s.id=NEW.segment_id) THEN RAISE EXCEPTION 'task_memory_event_scope_changed';END IF;
  IF TG_OP='DELETE' THEN RETURN OLD;ELSE RETURN NEW;END IF;
 END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.payload->>'name'='os.memory-erased/1' THEN RAISE EXCEPTION 'task_memory_erasure_forged';END IF;
  IF NEW.payload->>'name'='os.grounded/1' THEN PERFORM os_assert_task_memory(bid,true);END IF;
  RETURN NEW;
 END IF;
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'task_memory_event_retained';END IF;
 SELECT erasure_id INTO eid FROM task_memory_events WHERE event_id=OLD.id AND binding_id=bid;
 IF OLD.payload->>'name' IS DISTINCT FROM 'os.grounded/1' OR eid IS NULL
  OR (to_jsonb(NEW)-ARRAY['payload','event_digest']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['payload','event_digest'])
  OR NEW.payload IS DISTINCT FROM jsonb_build_object('type','CUSTOM','name','os.memory-erased/1',
   'value',jsonb_build_object('erasureId',eid))
  OR NOT EXISTS(SELECT 1 FROM task_memory_erasures WHERE id=eid AND binding_id=bid AND state='PENDING')
  THEN RAISE EXCEPTION 'task_memory_event_immutable';END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_commit_task_memory_forget() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE f memory_forget_batches%ROWTYPE;
BEGIN
 SELECT * INTO f FROM memory_forget_batches WHERE id=NEW.id;
 IF f.completed_at IS NOT NULL AND EXISTS(SELECT 1 FROM task_memory_bindings b WHERE b.settings_id=f.settings_id
  AND os_task_memory_affected(b.id,f.id) AND NOT EXISTS(SELECT 1 FROM task_memory_erasures e
   WHERE e.binding_id=b.id AND e.state='COMPLETE')) THEN RAISE EXCEPTION 'task_memory_forget_incomplete';END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_commit_task_memory_result() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE bid uuid;
BEGIN
 SELECT id INTO bid FROM task_memory_bindings WHERE task_id=NEW.task_id;
 IF bid IS NULL THEN RETURN NULL;END IF;
 PERFORM os_assert_task_memory(bid,true);
 IF NEW.contract_ref='CognitiveStageResult' AND NOT EXISTS(SELECT 1 FROM task_memory_artifacts
  WHERE binding_id=bid AND result_id=NEW.id AND artifact_id=NEW.artifact_id AND erasure_id IS NULL)
  THEN RAISE EXCEPTION 'task_memory_result_untracked';END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_commit_task_memory_completion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE bid uuid;
BEGIN
 IF NEW.state<>'COMPLETED' OR OLD.state='COMPLETED' THEN RETURN NULL;END IF;
 SELECT id INTO bid FROM task_memory_bindings WHERE task_id=NEW.id;
 IF bid IS NULL THEN RETURN NULL;END IF;
 PERFORM os_assert_task_memory(bid,true);
 IF NOT EXISTS(SELECT 1 FROM task_memory_outputs WHERE binding_id=bid AND erasure_id IS NULL)
  OR NOT EXISTS(SELECT 1 FROM task_memory_events WHERE binding_id=bid AND erasure_id IS NULL)
  THEN RAISE EXCEPTION 'task_memory_final_untracked';END IF;
 RETURN NULL;
END $$;

CREATE TRIGGER guard_task_memory_binding BEFORE UPDATE OR DELETE ON task_memory_bindings
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE TRIGGER guard_task_memory_reference BEFORE UPDATE OR DELETE ON task_memory_references
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE TRIGGER guard_task_knowledge_snapshot BEFORE UPDATE OR DELETE ON task_knowledge_snapshots
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE TRIGGER guard_task_memory_erasure BEFORE INSERT OR UPDATE OR DELETE ON task_memory_erasures
 FOR EACH ROW EXECUTE FUNCTION os_guard_task_memory_erasure();
CREATE TRIGGER guard_task_memory_artifact BEFORE INSERT OR UPDATE OR DELETE ON task_memory_artifacts
 FOR EACH ROW EXECUTE FUNCTION os_guard_task_memory_derivative();
CREATE TRIGGER guard_task_memory_output BEFORE INSERT OR UPDATE OR DELETE ON task_memory_outputs
 FOR EACH ROW EXECUTE FUNCTION os_guard_task_memory_derivative();
CREATE TRIGGER guard_task_memory_event BEFORE INSERT OR UPDATE OR DELETE ON task_memory_events
 FOR EACH ROW EXECUTE FUNCTION os_guard_task_memory_derivative();
CREATE TRIGGER guard_task_memory_public_event BEFORE INSERT OR UPDATE OR DELETE ON os_public_events
 FOR EACH ROW EXECUTE FUNCTION os_guard_task_memory_event();
CREATE CONSTRAINT TRIGGER commit_task_memory_binding AFTER INSERT ON task_memory_bindings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory();
CREATE CONSTRAINT TRIGGER commit_task_memory_reference AFTER INSERT ON task_memory_references
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory();
CREATE CONSTRAINT TRIGGER commit_task_knowledge_snapshot AFTER INSERT ON task_knowledge_snapshots
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory();
CREATE CONSTRAINT TRIGGER commit_task_memory_erasure AFTER INSERT OR UPDATE ON task_memory_erasures
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory();
CREATE CONSTRAINT TRIGGER commit_task_memory_artifact AFTER INSERT OR UPDATE ON task_memory_artifacts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory();
CREATE CONSTRAINT TRIGGER commit_task_memory_output AFTER INSERT OR UPDATE ON task_memory_outputs
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory();
CREATE CONSTRAINT TRIGGER commit_task_memory_event AFTER INSERT OR UPDATE ON task_memory_events
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory();
CREATE CONSTRAINT TRIGGER commit_task_memory_forget AFTER UPDATE ON memory_forget_batches
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory_forget();
CREATE CONSTRAINT TRIGGER commit_task_memory_result AFTER INSERT ON os_accepted_results
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory_result();
CREATE CONSTRAINT TRIGGER commit_task_memory_completion AFTER UPDATE ON os_tasks
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_task_memory_completion();
"""

def upgrade():
    for statement in TABLES:op.execute(statement)
    op.execute("ALTER TABLE os_dispatches DROP CONSTRAINT ck_dispatch_profile")
    op.execute("ALTER TABLE os_dispatches ADD CONSTRAINT ck_dispatch_profile CHECK (workflow_profile IN ('OSAdmissionTransport/1','OSTaskDriver/1','OSTrustedTaskDriver/1','OSTrustedTaskDriver/2','OSTaskMemoryDriver/1'))")
    op.execute(GUARDS)

def downgrade():
    raise RuntimeError('Protected forward recovery required; task use and erasure audit are retained')
