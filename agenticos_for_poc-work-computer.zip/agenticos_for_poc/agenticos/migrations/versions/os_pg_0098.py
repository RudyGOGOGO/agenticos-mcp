"""Keep settled obsolete returns in query planner control ancestry.

An obsolete response remains unaccepted. Only its fully settled, archived
control node followed by current query facts may connect the original planner
to a later accepted source candidate. No response bytes become evidence.
"""
from alembic import op

revision='os_pg_0098'
down_revision='os_pg_0097'
branch_labels=None
depends_on=None

PLANNER_GUARD=r"""
CREATE OR REPLACE FUNCTION os_query_source_planner_ancestor(rid uuid,tid uuid,planner uuid,acceptance uuid,candidate uuid)
 RETURNS boolean LANGUAGE sql STABLE AS $$
 WITH RECURSIVE chain AS (
  SELECT op.id,op.parent_operation_id,op.payload FROM os_agent_model_acceptances accepted
   JOIN os_agent_operation_models link ON link.id=accepted.call_id
   JOIN os_agent_operations op ON op.id=link.operation_id
   WHERE accepted.id=candidate AND op.root_id=rid AND op.task_id=tid
  UNION
  SELECT parent.id,parent.parent_operation_id,parent.payload FROM os_agent_operations parent
   JOIN chain child ON child.parent_operation_id=parent.id
   WHERE parent.root_id=rid AND parent.task_id=tid
 )
 SELECT COALESCE(
  EXISTS(SELECT 1 FROM chain WHERE id=planner)
  AND EXISTS(SELECT 1 FROM chain WHERE parent_operation_id IS NULL AND payload->'identity'->>'iteration'='0')
  AND EXISTS(SELECT 1 FROM os_agent_model_acceptances accepted
   JOIN os_agent_operation_models link ON link.id=accepted.call_id
   JOIN os_agent_model_calls model ON model.id=link.id
   JOIN os_work_attempts work ON work.id=model.attempt_id
   WHERE accepted.id=acceptance AND link.operation_id=planner AND link.root_id=rid
    AND work.root_id=rid AND work.task_id=tid AND work.state='SETTLED')
  AND NOT EXISTS(SELECT 1 FROM chain parent WHERE NOT (
   EXISTS(SELECT 1 FROM os_agent_operation_models link
    JOIN os_agent_model_acceptances accepted ON accepted.call_id=link.id
    JOIN os_agent_model_calls model ON model.id=link.id
    JOIN os_work_attempts work ON work.id=model.attempt_id
    WHERE link.operation_id=parent.id AND link.root_id=rid AND work.root_id=rid
     AND work.task_id=tid AND work.state='SETTLED')
   OR EXISTS(SELECT 1 FROM os_agent_operation_models link
    JOIN os_agent_model_calls model ON model.id=link.id
    JOIN os_agent_model_finishes finish ON finish.id=model.id
    JOIN os_work_attempts work ON work.id=model.attempt_id
    WHERE link.operation_id=parent.id AND link.root_id=rid
     AND model.root_id=rid AND model.task_id=tid AND work.root_id=rid AND work.task_id=tid
     AND work.state='SETTLED' AND finish.observation->'result'->'operation'->>'state'='succeeded'
     AND link.ordinal=(SELECT max(latest.ordinal) FROM os_agent_operation_models latest WHERE latest.operation_id=parent.id)
     AND NOT EXISTS(SELECT 1 FROM os_agent_operation_models attempted
      JOIN os_agent_model_acceptances accepted ON accepted.call_id=attempted.id WHERE attempted.operation_id=parent.id)
     AND (SELECT count(*) FROM os_agent_model_slots slot WHERE slot.call_id=model.id)=2
     AND (SELECT count(DISTINCT slot.role) FROM os_agent_model_slots slot
      JOIN os_agent_model_archives archive ON archive.id=slot.artifact_id AND archive.slot_id=slot.id
      JOIN os_work_attempts stored ON stored.id=slot.attempt_id
      WHERE slot.call_id=model.id AND slot.role IN ('candidate','evidence') AND stored.root_id=rid
       AND stored.task_id=tid AND stored.state='SETTLED')=2
     AND EXISTS(SELECT 1 FROM chain resumed
      WHERE resumed.parent_operation_id=parent.id AND resumed.payload->'context'=parent.payload->'context'
       AND resumed.payload->'identity'->'planRevision'=parent.payload->'identity'->'planRevision'
       AND (resumed.payload->'identity'->>'iteration')::bigint=(parent.payload->'identity'->>'iteration')::bigint+1
       AND parent.id=os_query_source_uuid5(os_query_source_uuid5(tid,'sdk-instance/1'),
        'model-turn/'||((parent.payload->'identity'->>'iteration')::bigint+1)::text)
       AND resumed.id=os_query_source_uuid5(os_query_source_uuid5(tid,'sdk-instance/1'),
        'model-turn/'||((resumed.payload->'identity'->>'iteration')::bigint+1)::text)
       AND jsonb_array_length(resumed.payload->'inputResults')>0
       AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(resumed.payload->'inputResults') dep
        WHERE dep->'payload'->>'schemaRef' IS DISTINCT FROM 'AgentQueryFactSet'))
  ))),false)
$$;
"""


def upgrade():
    op.execute(PLANNER_GUARD)


def downgrade():
    raise RuntimeError('Query control ancestry requires protected forward recovery')
