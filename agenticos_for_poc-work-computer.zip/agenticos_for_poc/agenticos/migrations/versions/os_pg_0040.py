"""Fresh source-only observations fence selected host result reuse."""
from alembic import op
revision="os_pg_0040"
down_revision="os_pg_0039"
branch_labels=None
depends_on=None


def upgrade():
    op.get_bind().exec_driver_sql(TABLE)
    op.execute(GUARDS)

TABLE = "\nCREATE TABLE personal_source_observations (\n\tid UUID NOT NULL,\n\tsource_id UUID NOT NULL,\n\tartifact_id UUID NOT NULL,\n\tciphertext_digest VARCHAR(64) NOT NULL,\n\trequest_digest VARCHAR(64) NOT NULL,\n\tapplication_revision BIGINT NOT NULL,\n\tapplication_generation BIGINT NOT NULL,\n\tsubject_generation BIGINT NOT NULL,\n\tpolicy_generation BIGINT NOT NULL,\n\tactive BOOLEAN NOT NULL,\n\tchecked_at TIMESTAMP WITH TIME ZONE NOT NULL,\n\tvalid_until TIMESTAMP WITH TIME ZONE NOT NULL,\n\tinstallation_id UUID NOT NULL,\n\tapplication_id UUID NOT NULL,\n\ttenant_id VARCHAR(256) NOT NULL,\n\tsubject_id VARCHAR(256) NOT NULL,\n\tPRIMARY KEY (id),\n\tCONSTRAINT uq_source_observation_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),\n\tCONSTRAINT fk_personal_learning_sources_source_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_id) REFERENCES personal_learning_sources (installation_id, application_id, tenant_id, subject_id, id),\n\tCONSTRAINT fk_os_artifacts_artifact_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, artifact_id) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id),\n\tCONSTRAINT uq_source_observation_source UNIQUE (installation_id, application_id, tenant_id, subject_id, source_id),\n\tCONSTRAINT ck_source_observation_cipher_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$'),\n\tCONSTRAINT ck_source_observation_request_digest CHECK (request_digest ~ '^[a-f0-9]{64}$'),\n\tCONSTRAINT ck_source_observation_versions CHECK (application_revision>0 AND application_generation>0 AND subject_generation>0 AND policy_generation>0),\n\tCONSTRAINT ck_source_observation_time CHECK (valid_until>checked_at AND valid_until<=checked_at+interval '3 seconds')\n)\n"

GUARDS = r"""
CREATE FUNCTION os_personal_source_observation_current(sid uuid) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
 v personal_source_observations%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO v FROM personal_source_observations WHERE source_id=sid;
 SELECT * INTO app FROM os_applications WHERE installation_id=s.installation_id AND id=s.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 RETURN COALESCE(s.kind='accepted-outcome/1' AND o.id IS NOT NULL AND v.id IS NOT NULL
  AND v.active AND app.active AND owner.active AND v.artifact_id=o.artifact_id
  AND v.ciphertext_digest=o.ciphertext_digest
  AND v.checked_at>=clock_timestamp()-interval '3 seconds' AND v.checked_at<=clock_timestamp()+interval '1 second'
  AND v.valid_until>clock_timestamp()
  AND ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   =ROW(v.application_revision,v.application_generation,v.subject_generation,v.policy_generation),false);
END $$;
CREATE OR REPLACE FUNCTION os_selected_learning_source_current(sid uuid) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM personal_learning_sources WHERE id=sid AND kind='usage-event/2')
 THEN RETURN os_usage_source_current(sid); END IF;
 IF NOT COALESCE(os_conversation_learning_source_current(sid),false) THEN RETURN false; END IF;
 IF EXISTS(SELECT 1 FROM personal_learning_sources WHERE id=sid AND kind='accepted-outcome/1')
 THEN RETURN os_personal_source_observation_current(sid); END IF;
 RETURN true;
END $$;
CREATE FUNCTION os_guard_personal_source_observation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'personal_source_observation_retained'; END IF;
 IF TG_OP='UPDATE' THEN
  IF ROW(NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.source_id,
    NEW.artifact_id,NEW.ciphertext_digest,NEW.request_digest)
   IS DISTINCT FROM ROW(OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.source_id,
    OLD.artifact_id,OLD.ciphertext_digest,OLD.request_digest)
  THEN RAISE EXCEPTION 'personal_source_observation_immutable'; END IF;
  -- A negative invalidation cannot grant authority and need not renew time.
  IF NOT NEW.active AND (to_jsonb(NEW)-'active') IS NOT DISTINCT FROM (to_jsonb(OLD)-'active') THEN RETURN NEW; END IF;
  IF NEW.checked_at<=OLD.checked_at THEN RAISE EXCEPTION 'personal_source_observation_order'; END IF;
 END IF;
 IF NEW.checked_at<clock_timestamp()-interval '3 seconds' OR NEW.checked_at>clock_timestamp()+interval '1 second'
  OR NEW.valid_until<=clock_timestamp()
 THEN RAISE EXCEPTION 'personal_source_observation_expired'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_personal_source_observation BEFORE INSERT OR UPDATE OR DELETE ON personal_source_observations
 FOR EACH ROW EXECUTE FUNCTION os_guard_personal_source_observation();
CREATE FUNCTION os_commit_personal_source_observation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
BEGIN
 IF NOT NEW.active THEN RETURN NULL; END IF;
 SELECT * INTO s FROM personal_learning_sources WHERE id=NEW.source_id;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=NEW.source_id;
 IF s.kind IS DISTINCT FROM 'accepted-outcome/1' OR s.state IS DISTINCT FROM 'AVAILABLE'
  OR s.envelope IS NULL OR s.expires_at<=clock_timestamp()
  OR NOT COALESCE(os_conversation_learning_source_current(s.id),false)
  OR NOT COALESCE(os_personal_source_observation_current(s.id),false)
  OR NEW.artifact_id IS DISTINCT FROM o.artifact_id OR NEW.ciphertext_digest IS DISTINCT FROM o.ciphertext_digest
 THEN RAISE EXCEPTION 'personal_source_observation_binding'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_personal_source_observation AFTER INSERT OR UPDATE ON personal_source_observations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_personal_source_observation();
"""
