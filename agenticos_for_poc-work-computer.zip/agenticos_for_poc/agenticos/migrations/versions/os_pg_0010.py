"""Immutable operator-pinned resource schema, not a write authorization."""

from alembic import op

revision = "os_pg_0010"
down_revision = "os_pg_0009"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "CREATE TABLE os_resource_schemas (\n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\tregistration_revision BIGINT NOT NULL, \n\tcapability_ref VARCHAR(256) NOT NULL, \n\tdescriptor_digest VARCHAR(64) NOT NULL, \n\tschema_digest VARCHAR(64) NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tPRIMARY KEY (installation_id, application_id, registration_revision, capability_ref), \n\tCONSTRAINT fk_schema_registration FOREIGN KEY(installation_id, application_id, registration_revision) REFERENCES os_registrations (installation_id, application_id, revision), \n\tCONSTRAINT ck_schema_registration_revision CHECK (registration_revision>0), \n\tCONSTRAINT ck_resource_schema_payload CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536), \n\tCONSTRAINT ck_resource_descriptor_digest CHECK (descriptor_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_resource_schema_digest CHECK (schema_digest ~ '^[a-f0-9]{64}$')\n)"
    )
    op.execute(
        "CREATE TRIGGER immutable_os_resource_schemas BEFORE UPDATE OR DELETE ON os_resource_schemas FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('installation_id','application_id','registration_revision','capability_ref','descriptor_digest','schema_digest','payload','created_at')"
    )


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use tested fresh recovery")
