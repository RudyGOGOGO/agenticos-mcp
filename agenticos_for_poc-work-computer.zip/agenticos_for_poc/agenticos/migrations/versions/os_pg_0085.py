"""Purpose-separated private KB planning over original production journals.

Draft85: requires protected populated positive/negative runtime, rollback,
forward/catalog and independent84 recovery before application or freezing.
"""
from alembic import op

revision='os_pg_0085'
down_revision='os_pg_0084'
branch_labels=None
depends_on=None

DDL=r"""
ALTER TABLE os_agent_payload_writes ADD COLUMN model_context jsonb;
ALTER TABLE os_agent_payload_writes ADD CONSTRAINT ck_agent_payload_write_context CHECK (
 model_context IS NULL OR (jsonb_typeof(model_context)='object' AND octet_length(model_context::text)<=32768));
ALTER TABLE os_agent_tool_acceptances ADD COLUMN knowledge_source jsonb;
ALTER TABLE os_agent_tool_acceptances ADD CONSTRAINT ck_agent_tool_knowledge_source CHECK (
 knowledge_source IS NULL OR (jsonb_typeof(knowledge_source)='object' AND octet_length(knowledge_source::text)<=32768));
ALTER TABLE task_memory_bindings DROP CONSTRAINT ck_task_memory_profile;
ALTER TABLE task_memory_bindings ADD CONSTRAINT ck_task_memory_profile CHECK (
 profile_ref IN ('OSTaskMemory/1','OSAgentMemory/1','OSAgentPlannerMemory/1'));
ALTER TABLE task_memory_bindings DROP CONSTRAINT ck_task_memory_reference_count;
ALTER TABLE task_memory_bindings ADD CONSTRAINT ck_task_memory_reference_count CHECK (
 (profile_ref='OSTaskMemory/1' AND reference_count BETWEEN 0 AND 8) OR
 (profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1') AND reference_count BETWEEN 0 AND 64));
"""

HELPERS=r"""
CREATE FUNCTION os_agent_private_planning_valid(p jsonb,installation uuid,application uuid,generation bigint,registration bigint,harness jsonb)
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE public_model jsonb; meter os_agent_model_meters%ROWTYPE; item jsonb; lane os_agent_tool_profiles%ROWTYPE; cap os_agent_capabilities%ROWTYPE;
BEGIN
 IF NOT COALESCE(p=jsonb_build_object('id',p->'id','revision',p->'revision',
  'plannerModel',p->'plannerModel','plannerMeterDigest',p->'plannerMeterDigest','publicModel',p->'publicModel',
  'knowledgeCapability',p->'knowledgeCapability','publicCapabilities',p->'publicCapabilities','readAdapters',p->'readAdapters',
  'directiveContract','AgentPublicReadOrder/1','separation','private-planner-fresh-public/1')
  AND p->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND jsonb_typeof(p->'revision')='number' AND p->>'revision' ~ '^[1-9][0-9]*$'
  AND (p->>'revision')::numeric<=9007199254740991
  AND harness->>'ref'='private-planned-read/'||os_agent_profile_digest('manifest',p)
  AND p->'plannerModel'<>p->'publicModel'
  AND jsonb_typeof(p->'publicCapabilities')='array' AND jsonb_array_length(p->'publicCapabilities') BETWEEN 1 AND 32
  AND jsonb_array_length(p->'publicCapabilities')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(p->'publicCapabilities') v)
  AND NOT p->'publicCapabilities' @> jsonb_build_array(p->'knowledgeCapability')
  AND jsonb_typeof(p->'readAdapters')='array' AND jsonb_array_length(p->'readAdapters') BETWEEN 1 AND 32,false)
 THEN RETURN false;END IF;
 SELECT m.payload->'model' INTO public_model FROM os_agent_model_meters m WHERE m.installation_id=installation
  AND m.application_id=application AND m.model_digest=p->'publicModel'->>'digest'
  AND m.application_generation=generation AND m.registration_revision=registration
  AND m.digest=os_agent_profile_digest('policy',m.payload);
 SELECT * INTO meter FROM os_agent_model_meters m WHERE m.installation_id=installation AND m.application_id=application
  AND m.model_digest=p->'plannerModel'->>'digest' AND m.application_generation=generation AND m.registration_revision=registration;
 IF NOT COALESCE(public_model IS NOT NULL AND os_agent_profile_pin(public_model,'manifest')=p->'publicModel'
  AND os_agent_profile_pin(meter.payload->'model','manifest')=p->'plannerModel'
  AND meter.digest=p->>'plannerMeterDigest' AND meter.digest=os_agent_profile_digest('policy',meter.payload)
  AND meter.payload->'model'->>'credentialRef'<>public_model->>'credentialRef',false) THEN RETURN false;END IF;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(p->'publicCapabilities') pin WHERE NOT EXISTS(
  SELECT 1 FROM jsonb_array_elements(p->'readAdapters') adapter WHERE adapter->'capability'=pin))
  OR (SELECT count(DISTINCT (v->'capability',v->>'providerRef')) FROM jsonb_array_elements(p->'readAdapters') v)
   <>jsonb_array_length(p->'readAdapters') THEN RETURN false;END IF;
 FOR item IN SELECT value FROM jsonb_array_elements(p->'readAdapters') LOOP
  IF NOT COALESCE(item=jsonb_build_object('capability',item->'capability','providerRef',item->'providerRef',
   'readProfile',item->'readProfile','inputSchemaDigest',item->'inputSchemaDigest','resourceTypeField',item->'resourceTypeField',
   'externalIdsField',item->'externalIdsField','fieldNamesField',item->'fieldNamesField')
   AND p->'publicCapabilities' @> jsonb_build_array(item->'capability')
   AND item->>'resourceTypeField'<>item->>'externalIdsField' AND item->>'resourceTypeField'<>item->>'fieldNamesField'
   AND item->>'externalIdsField'<>item->>'fieldNamesField',false) THEN RETURN false;END IF;
  SELECT * INTO cap FROM os_agent_capabilities c WHERE c.installation_id=installation AND c.application_id=application
   AND c.application_generation=generation AND c.capability_ref=item->'capability'->>'ref' ORDER BY revision DESC LIMIT 1;
  SELECT * INTO lane FROM os_agent_tool_profiles l WHERE l.installation_id=installation AND l.application_id=application
   AND l.application_generation=generation AND l.registration_revision=registration
   AND os_agent_profile_pin(l.payload->'read','manifest')=item->'readProfile';
  IF NOT COALESCE(cap.digest=os_agent_profile_digest('manifest',cap.payload)
   AND item->'capability'=os_agent_profile_pin(cap.payload,'manifest') AND cap.payload->>'kind'='read'
   AND cap.payload->>'adapterRef'='mcp.read/1' AND cap.payload->>'lifecycle'='qualified'
   AND lane.digest=os_agent_profile_digest('policy',lane.payload)
   AND item->'readProfile'=os_agent_profile_pin(lane.payload->'read','manifest')
   AND lane.payload->'read'->'capability'=item->'capability' AND lane.payload->'read'->>'providerRef'=item->>'providerRef'
   AND lane.payload->'read'->>'outputContract'='EvidencePage/1'
   AND item->>'inputSchemaDigest'=encode(sha256(convert_to(cap.payload->>'inputSchemaJson','UTF8')),'hex'),false)
   THEN RETURN false;END IF;
 END LOOP;
 RETURN true;
END $$;

CREATE FUNCTION os_agent_planning_profile(a os_admissions) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE p os_agent_tool_profiles%ROWTYPE; app os_applications%ROWTYPE; result jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO app FROM os_applications WHERE installation_id=a.installation_id AND id=a.application_id;
 IF NOT COALESCE(app.active AND app.revision=a.registration_revision,false) THEN RAISE EXCEPTION 'agent_planning_profile_obsolete';END IF;
 IF (SELECT count(*) FROM os_agent_tool_profiles t WHERE t.installation_id=a.installation_id
  AND t.application_id=a.application_id AND t.application_generation=app.generation AND t.registration_revision=app.revision
  AND t.payload->'knowledge'->'harness'=a.context->'harness')<>1 THEN RAISE EXCEPTION 'agent_planning_profile_ambiguous';END IF;
 SELECT * INTO p FROM os_agent_tool_profiles t WHERE t.installation_id=a.installation_id
  AND t.application_id=a.application_id AND t.application_generation=app.generation AND t.registration_revision=app.revision
  AND t.payload->'knowledge'->'harness'=a.context->'harness';
 result=p.payload->'knowledge'->'planning';
 IF NOT COALESCE(p.digest=os_agent_profile_digest('policy',p.payload)
  AND result->'publicModel'=a.context->'model' AND result->'publicModel'=os_agent_profile_pin(a.bot->'model','manifest')
  AND os_agent_private_planning_valid(result,a.installation_id,a.application_id,app.generation,app.revision,a.context->'harness'),false)
 THEN RAISE EXCEPTION 'agent_planning_profile_binding';END IF;
 RETURN result;
END $$;

CREATE FUNCTION os_agent_context_matches(a os_admissions,c jsonb) RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE p jsonb;
BEGIN
 IF COALESCE(a.context->'harness'->>'ref','') NOT LIKE 'private-planned-read/%' THEN RETURN c=a.context;END IF;
 p=os_agent_planning_profile(a);
 RETURN COALESCE(c=a.context OR c=jsonb_set(a.context,'{model}',p->'plannerModel'),false);
END $$;

CREATE FUNCTION os_agent_context_model(a os_admissions,c jsonb,m jsonb) RETURNS boolean LANGUAGE plpgsql AS $$
BEGIN
 IF NOT os_agent_context_matches(a,c) THEN RETURN false;END IF;
 RETURN COALESCE(os_agent_profile_pin(m,'manifest')=c->'model'
  AND (c<>a.context OR m=a.bot->'model'),false);
END $$;

CREATE FUNCTION os_agent_source_context(consumer jsonb,producer jsonb) RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE;
BEGIN
 SELECT d.* INTO a FROM os_admissions d JOIN os_budget_roots r ON r.admission_id=d.id WHERE r.id=(consumer->>'rootId')::uuid;
 IF a.id IS NULL OR NOT COALESCE(os_agent_context_matches(a,consumer) AND os_agent_context_matches(a,producer),false)
 THEN RETURN false;END IF;
 RETURN consumer=producer OR (consumer<>a.context AND producer=a.context);
END $$;

CREATE FUNCTION os_agent_capability_matches(a os_admissions,c jsonb,cap jsonb) RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE p jsonb;
BEGIN
 IF COALESCE(a.context->'harness'->>'ref','') NOT LIKE 'private-planned-read/%' THEN RETURN c=a.context;END IF;
 IF NOT os_agent_context_matches(a,c) THEN RETURN false;END IF;
 IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
  WHERE left(cap->>'ref',length(prefix))=prefix) THEN RETURN false;END IF;
 p=os_agent_planning_profile(a);
 RETURN CASE WHEN c=a.context THEN a.bot->'capabilities'->'allowedKinds' @> '["read"]'::jsonb
  AND p->'publicCapabilities' @> jsonb_build_array(cap)
  ELSE a.bot->'capabilities'->'allowedKinds' @> '["memory"]'::jsonb AND p->'knowledgeCapability'=cap END;
END $$;
"""

# Complete predecessor definitions and affected guard replacements are kept in
# this additive revision. No installed migration or external plan is imported.
GUARDS=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_operation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 c jsonb; i jsonb; f os_agent_private_payloads%ROWTYPE; p os_agent_payload_writes%ROWTYPE; dep jsonb;
 accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_operation_immutable'; END IF;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=NEW.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (NEW.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=NEW.root_id)) ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 c:=NEW.payload->'context';i:=NEW.payload->'identity';
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=substring(NEW.payload->'input'->>'artifactRef' from 10)::uuid;
 SELECT * INTO p FROM os_agent_payload_writes WHERE id=f.write_id;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND r.accounting_format='agent-resources/1'
 AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
 AND os_agent_context_matches(a,c) AND NEW.task_id=r.root_task_id AND NEW.segment_id=a.segment_id AND NEW.digest=os_agent_profile_digest('command',NEW.payload)
 AND NEW.payload-ARRAY['context','identity','input','inputResults']='{}'::jsonb AND NEW.payload ?& ARRAY['context','identity','input','inputResults']
 AND i=jsonb_build_object('operationId',NEW.id,'taskId',NEW.task_id,'rootId',NEW.root_id,'segmentId',NEW.segment_id,
  'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','planRevision',i->'planRevision','parentOperationId',NEW.parent_operation_id,
  'iteration',i->'iteration','kind','model','inputDigest',os_agent_profile_digest('command',NEW.payload->'input'))
 AND jsonb_typeof(i->'planRevision')='number' AND (i->>'planRevision')::bigint BETWEEN 1 AND 9007199254740991
 AND jsonb_typeof(i->'iteration')='number' AND (i->>'iteration')::bigint BETWEEN 0 AND 9007199254740991
 AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=NEW.task_id
  AND k.state='ACTIVE' AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp()
  AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
 AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=NEW.segment_id AND s.task_id=NEW.task_id AND s.state='OPEN')
 AND p.task_id=NEW.task_id AND p.root_id=NEW.root_id AND p.expires_at>clock_timestamp() AND (p.model_context IS NULL AND c=a.context AND c->'harness'->>'ref' NOT LIKE 'private-planned-read/%' OR os_agent_source_context(c,p.model_context))
 AND p.schema_ref='AgentProviderInput' AND p.schema_version=1
 AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
 AND NEW.payload->'input'=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',p.plain_bytes,'schemaRef',p.schema_ref,'schemaVersion',p.schema_version)
 AND (NEW.parent_operation_id IS NULL OR EXISTS(SELECT 1 FROM os_agent_operations parent WHERE parent.id=NEW.parent_operation_id AND parent.root_id=NEW.root_id AND os_agent_source_context(c,parent.payload->'context') AND parent.created_at<=NEW.created_at))
 AND jsonb_typeof(NEW.payload->'inputResults')='array' AND jsonb_array_length(NEW.payload->'inputResults')<=128
 AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_operation_binding'; END IF;
 FOR dep IN SELECT value FROM jsonb_array_elements(NEW.payload->'inputResults') LOOP
  PERFORM os_assert_agent_input_dependency(dep,c,NEW.root_id,NEW.created_at);
 END LOOP;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_model_call() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE w os_work_attempts%ROWTYPE; r os_budget_roots%ROWTYPE; a os_admissions%ROWTYPE; q os_agent_resource_accounts%ROWTYPE;
 m os_agent_model_meters%ROWTYPE; p os_agent_payload_writes%ROWTYPE; f os_agent_private_payloads%ROWTYPE; req jsonb; c jsonb; s jsonb; g jsonb; h text;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_model_call_immutable'; END IF;
 SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=r.id;
 SELECT * INTO m FROM os_agent_model_meters WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id AND model_digest=NEW.request->'context'->'model'->>'digest';
 req:=NEW.request;c:=req->'context';s:=req->'step';g:=req->'grant';
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=substring(req->'input'->>'artifactRef' from 10)::uuid;
 SELECT * INTO p FROM os_agent_payload_writes WHERE id=f.write_id;
 h:=os_agent_profile_digest('command',jsonb_build_object('schema','agent-model-operation/1','context',c,'step',s,'input',req->'input',
 'meterDigest',m.digest,'maxOutputTokens',req->'maxOutputTokens','requestTimeoutMs',req->'requestTimeoutMs'));
 IF NOT COALESCE(w.kind='agent.model' AND w.state='RESERVED' AND w.invocation_id=NEW.id
 AND w.accounting_format='agent-resources/1' AND os_agent_context_matches(a,c) AND m.digest=NEW.meter_digest
 AND os_agent_context_model(a,c,m.payload->'model') AND m.payload->'pricing'->>'currency'=q.policy->>'costCurrency'
 AND w.reserved=os_agent_model_units(m.payload,(req->>'maxOutputTokens')::bigint,(q.policy->>'requestTimeoutMs')::bigint)
 AND (req->>'maxOutputTokens')::bigint BETWEEN 1 AND (m.payload->>'maxOutputTokens')::bigint
 AND (req->>'requestTimeoutMs')::bigint BETWEEN 1 AND least((m.payload->>'requestTimeoutMs')::bigint,(q.policy->>'requestTimeoutMs')::bigint-1)
 AND NEW.request_digest=os_agent_profile_digest('command',req)
 AND req-ARRAY['context','step','grant','input','maxOutputTokens','requestTimeoutMs']='{}'::jsonb
 AND s=jsonb_build_object('taskId',c->'taskId','rootId',c->'rootId','segmentId',c->'segmentId',
 'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','stepId',NEW.id,
 'parentStepId',s->'parentStepId','inputDigest',s->'inputDigest','kind','model')
 AND c->>'taskId'=NEW.task_id::text AND c->>'rootId'=NEW.root_id::text AND c->>'segmentId'=NEW.segment_id::text
 AND (c->>'controlEpoch')::bigint=NEW.control_epoch AND s->>'stepId'=NEW.id::text AND s->>'kind'='model'
 AND s->>'taskId'=c->>'taskId' AND s->>'rootId'=c->>'rootId' AND s->>'segmentId'=c->>'segmentId'
 AND s->'intentRevision'=c->'intentRevision' AND s->'controlEpoch'=c->'controlEpoch'
 AND s->>'inputDigest'=os_agent_profile_digest('command',req->'input')
 AND (s->>'parentStepId' IS NULL OR EXISTS(SELECT 1 FROM os_agent_model_calls pc WHERE pc.id=(s->>'parentStepId')::uuid AND pc.root_id=r.id AND os_agent_source_context(c,pc.request->'context')
 AND pc.installation_id=NEW.installation_id AND pc.application_id=NEW.application_id AND pc.tenant_id=NEW.tenant_id AND pc.subject_id=NEW.subject_id))
 AND g=jsonb_build_object('subject',c->'subject','taskId',c->'taskId','rootId',c->'rootId','segmentId',c->'segmentId',
 'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','accountingFormat','agent-resources/1','stepId',NEW.id,
 'attemptId',w.id,'leaseToken',w.lease_token,'inputDigest',s->'inputDigest','input',req->'input','reserved',w.reserved,'expiresAt',g->'expiresAt')
 AND (g->>'expiresAt')::timestamptz=w.lease_until AND w.lease_until<=r.deadline
 AND NEW.created_at<=clock_timestamp() AND NEW.created_at>=w.created_at
 AND p.task_id=NEW.task_id AND p.root_id=NEW.root_id AND NEW.expires_at=p.expires_at AND p.schema_ref='AgentProviderInput'
 AND (p.model_context IS NULL AND c=a.context AND c->'harness'->>'ref' NOT LIKE 'private-planned-read/%' OR os_agent_source_context(c,p.model_context))
 AND p.schema_version=1 AND p.plain_bytes<=(m.payload->>'maxRequestBytes')::bigint
 AND req->'input'=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',p.plain_bytes,
 'schemaRef',p.schema_ref,'schemaVersion',p.schema_version)
 AND f.installation_id=NEW.installation_id AND f.application_id=NEW.application_id AND f.tenant_id=NEW.tenant_id AND f.subject_id=NEW.subject_id
 AND w.request_digest=os_agent_profile_digest('command',jsonb_build_object('schema','agent-resource-reservation/1','taskId',NEW.task_id,
 'segmentId',NEW.segment_id,'epoch',NEW.control_epoch,'invocationId',NEW.id,'kind','agent.model','inputDigest',h,
 'units',w.reserved,'timeoutMs',q.policy->'requestTimeoutMs')),false) THEN RAISE EXCEPTION 'agent_model_call_binding'; END IF;
 PERFORM os_assert_agent_work_current(w);PERFORM os_agent_resource_owner(q);
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_input_result_set() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; p os_agent_payload_writes%ROWTYPE; artifact os_artifacts%ROWTYPE; w os_work_attempts%ROWTYPE;
 c jsonb; reference jsonb; payload jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_input_result_set_immutable'; END IF;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=NEW.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (NEW.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=NEW.root_id)) ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=NEW.artifact_id;
 SELECT * INTO p FROM os_agent_payload_writes WHERE id=f.write_id;
 SELECT * INTO artifact FROM os_artifacts WHERE id=NEW.artifact_id;SELECT * INTO w FROM os_work_attempts WHERE id=p.attempt_id;
 c:=NEW.record->'context';reference:=NEW.reference;
 payload:=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',p.plain_bytes,'schemaRef',p.schema_ref,'schemaVersion',p.schema_version);
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND r.accounting_format='agent-resources/1'
 AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
 AND os_agent_context_matches(a,c) AND NEW.task_id=r.root_task_id AND NEW.record=jsonb_build_object('context',c,'setId',NEW.id,'payload',payload)
 AND (p.model_context=c OR p.model_context IS NULL AND c=a.context AND c->'harness'->>'ref' NOT LIKE 'private-planned-read/%')
 AND p.root_id=NEW.root_id AND p.task_id=NEW.task_id AND p.schema_ref='AgentInputResultSet' AND p.schema_version=1
 AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
 AND w.state='SETTLED' AND w.kind='agent.storage' AND p.expires_at>clock_timestamp() AND artifact.expires_at=p.expires_at
 AND reference=jsonb_build_object('subject',c->'subject','taskId',NEW.task_id,'rootId',NEW.root_id,'resultId',reference->'resultId',
  'producerStepId',NEW.id,'acceptedAttemptId',p.attempt_id,'payload',payload,'lineageRef',null,'scopeRef',c->'scopeRef','acceptedAt',reference->'acceptedAt')
 AND (reference->>'acceptedAt')::timestamptz=NEW.created_at AND NEW.created_at>=p.created_at AND NEW.created_at<=clock_timestamp()
 AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=NEW.task_id AND k.state='ACTIVE'
  AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp() AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
 AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.task_id=NEW.task_id AND s.state='OPEN'),false)
 THEN RAISE EXCEPTION 'agent_input_result_set_binding'; END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_assert_agent_tool_current(o os_agent_tool_operations) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; app os_applications%ROWTYPE; parent os_agent_operations%ROWTYPE;
 accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; w os_agent_payload_writes%ROWTYPE; cap os_agent_capabilities%ROWTYPE;
 c jsonb; i jsonb; dep jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM os_assert_agent_memory_context(o.payload->'context',true);
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=o.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (o.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=o.root_id)) ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=o.root_id FOR UPDATE;SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=o.installation_id AND id=o.application_id;
 c:=o.payload->'context';i:=o.payload->'identity';dep:=o.payload->'modelResult';
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO parent FROM os_agent_operations WHERE id=o.parent_operation_id;
 SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=o.source_acceptance_id;
 SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
 SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=o.binding_id;
 SELECT * INTO w FROM os_agent_payload_writes WHERE id=f.write_id;
 SELECT * INTO cap FROM os_agent_capabilities WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND application_generation=app.generation AND capability_ref=o.payload->'capability'->>'ref' ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND r.accounting_format='agent-resources/1'
 AND ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
 AND os_agent_context_matches(a,c) AND o.task_id=r.root_task_id AND o.digest=os_agent_profile_digest('command',o.payload)
 AND o.payload=jsonb_build_object('context',c,'identity',i,'binding',o.payload->'binding','modelOperationId',o.parent_operation_id,
  'modelResult',dep,'capability',o.payload->'capability','profile',o.payload->'profile')
 AND i=jsonb_build_object('operationId',o.id,'taskId',o.task_id,'rootId',o.root_id,'segmentId',a.segment_id,
  'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','planRevision',parent.payload->'identity'->'planRevision',
  'parentOperationId',o.parent_operation_id,'iteration',parent.payload->'identity'->'iteration','kind','tool','inputDigest',i->'inputDigest')
 AND i->>'inputDigest' ~ '^[a-f0-9]{64}$' AND parent.root_id=o.root_id AND parent.payload->'context'=c
 AND producer.root_id=o.root_id AND producer.request->'context'=c AND producer.expires_at>clock_timestamp()
 AND EXISTS(SELECT 1 FROM os_agent_operation_models link WHERE link.operation_id=parent.id AND link.id=producer.id)
 AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
   'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
   'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
   'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
 AND (dep->>'acceptedAt')::timestamptz=accepted.created_at
 AND ROW(producer.installation_id,producer.application_id,producer.tenant_id,producer.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND (w.model_context=c OR w.model_context IS NULL AND c=a.context AND c->'harness'->>'ref' NOT LIKE 'private-planned-read/%')
 AND w.task_id=o.task_id AND w.root_id=o.root_id AND w.schema_ref='AgentSDKToolBinding' AND w.schema_version=1 AND w.expires_at>clock_timestamp()
 AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND o.payload->'binding'=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',w.plain_bytes,'schemaRef',w.schema_ref,'schemaVersion',w.schema_version)
 AND p.application_generation=app.generation AND p.registration_revision=app.revision AND p.digest=os_agent_profile_digest('policy',p.payload)
 AND o.payload->'profile'=jsonb_build_object('ref',p.payload->'execution'->'id','revision',p.payload->'execution'->'revision','digest',p.policy_digest)
 AND ((p.payload->'read'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='mcp.read/1')
 OR (p.payload->'preparation'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='propose'
  AND cap.payload->>'adapterRef'='typed.prepare/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'memory'->'capability'=o.payload->'capability' AND p.payload->'memory'->'harness'=c->'harness'
  AND p.payload->'memory'->>'installationId'=o.installation_id::text
  AND p.payload->'memory'->>'applicationId'=o.application_id::text AND cap.payload->>'kind'='memory'
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)
  AND cap.payload->>'adapterRef'='owner.memory.read/1' AND cap.payload->>'scopePolicyRef'='owner-approved-memory/1'
  AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'knowledge'->'capability'=o.payload->'capability' AND p.payload->'knowledge'->'harness'=c->'harness'
  AND c<>a.context AND p.payload->'knowledge'->'planning'=os_agent_planning_profile(a)
  AND p.payload->'knowledge'->>'installationId'=o.installation_id::text
  AND p.payload->'knowledge'->>'applicationId'=o.application_id::text
  AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='private.knowledge.read/1'
  AND cap.payload->>'scopePolicyRef'='private-reviewed-knowledge/1' AND cap.payload->'mcp'='null'::jsonb))
 AND os_agent_capability_matches(a,c,o.payload->'capability')
 AND cap.payload->>'lifecycle'='qualified' AND cap.payload->>'purpose'=c->>'purpose'
 AND o.payload->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
 AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=o.task_id
  AND k.state='ACTIVE' AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp()
  AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
 AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.task_id=o.task_id AND s.state='OPEN'),false)
 THEN RAISE EXCEPTION 'agent_tool_operation_binding'; END IF;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_resource_group() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_group_accounts%ROWTYPE; original os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE;
 d os_admissions%ROWTYPE; c jsonb; member jsonb; required jsonb; w os_work_attempts%ROWTYPE; expected_kind text; expected_count integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_group_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_agent_group_accounts WHERE id=NEW.group_account_id;
 SELECT * INTO original FROM os_agent_resource_accounts WHERE id=a.account_id;
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state') THEN RAISE EXCEPTION 'agent_group_transition'; END IF;
  IF NEW.state='ADMITTED' THEN
   PERFORM os_agent_resource_owner(original);
   w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
   w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
   PERFORM os_assert_agent_work_current(w);
   IF EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
    THEN RAISE EXCEPTION 'agent_group_fifo'; END IF;
  END IF;
  RETURN NEW;
 END IF;
 PERFORM os_agent_resource_owner(original);
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 c=NEW.request->'context';required=os_agent_group_required(NEW.request->'members');
 expected_kind=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 'agent.model' WHEN 'tool-reservation/1' THEN 'agent.tool' WHEN 'compute-reservation/1' THEN 'agent.compute' WHEN 'effect-reservation/1' THEN 'agent.effect' WHEN 'native-reservation/1' THEN 'agent.native' WHEN 'memory-reservation/1' THEN 'agent.memory' ELSE 'agent.storage' END;
 expected_count=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 3 WHEN 'tool-reservation/1' THEN 2 WHEN 'memory-reservation/1' THEN 2 ELSE 1 END;
 IF a.id IS NULL OR a.root_id<>r.id OR NEW.group_account_id<>a.id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline OR NOT COALESCE(os_agent_context_matches(d,c),false)
  OR NEW.request IS DISTINCT FROM jsonb_build_object('context',c,'groupId',NEW.id::text,'profile',NEW.profile_ref,'sourceId',NEW.source_id::text,'members',NEW.request->'members')
  OR c->>'rootId'<>NEW.root_id::text OR c->>'taskId'<>NEW.task_id::text OR c->>'segmentId'<>NEW.segment_id::text
  OR (c->>'controlEpoch')::bigint<>NEW.control_epoch
  OR NEW.request_digest<>os_agent_profile_digest('command',NEW.request||jsonb_build_object('schema','agent-resource-group/1'))
  OR jsonb_array_length(NEW.request->'members')<>expected_count
  OR NEW.request->'members'->0->>'kind'<>expected_kind OR NEW.request->'members'->0->>'invocationId'<>NEW.source_id::text
  OR (SELECT count(DISTINCT value->>'invocationId') FROM jsonb_array_elements(NEW.request->'members'))<>expected_count
  THEN RAISE EXCEPTION 'agent_group_binding'; END IF;
 FOR member IN SELECT value FROM jsonb_array_elements(NEW.request->'members') LOOP
  IF member IS DISTINCT FROM jsonb_build_object('taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,'controlEpoch',NEW.control_epoch,
    'invocationId',member->'invocationId','kind',member->'kind','inputDigest',member->'inputDigest','units',member->'units','timeoutMs',member->'timeoutMs')
   OR jsonb_typeof(member->'invocationId') IS DISTINCT FROM 'string' OR (member->>'invocationId') !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   OR jsonb_typeof(member->'inputDigest') IS DISTINCT FROM 'string' OR (member->>'inputDigest') !~ '^[a-f0-9]{64}$'
   OR member->>'kind' NOT IN ('agent.model','agent.tool','agent.storage','agent.compute','agent.effect','agent.native','agent.memory')
   OR jsonb_typeof(member->'kind') IS DISTINCT FROM 'string'
   OR jsonb_typeof(member->'timeoutMs') IS DISTINCT FROM 'number' OR (member->>'timeoutMs') !~ '^[1-9][0-9]*$'
   OR (member->>'timeoutMs')::numeric>(original.policy->>'requestTimeoutMs')::numeric
   OR (member->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
   OR (member->'units'->>'workMs')::numeric<1 THEN RAISE EXCEPTION 'agent_group_member_request'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.request->'members') WITH ORDINALITY AS m(value,ordinal) WHERE ordinal>1 AND value->>'kind'<>'agent.storage')
  THEN RAISE EXCEPTION 'agent_group_member_kind'; END IF;
 IF NEW.profile_ref='memory-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND (p.payload ? 'memory' OR p.payload ? 'knowledge')
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_memory_group_source';END IF;
 IF NEW.profile_ref='native-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_native_operations native WHERE native.root_id=NEW.root_id AND native.task_id=NEW.task_id
   AND native.payload->'context'=c AND os_query_source_uuid5(native.id,'tool-attempt/1')=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_native_group_source'; END IF;
 IF NEW.profile_ref='effect-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
   JOIN os_tasks task ON task.id=review.task_id
  WHERE decision.id=NEW.source_id AND review.root_id=NEW.root_id AND review.task_id=NEW.task_id
   AND review.payload->'context'=c AND decision.payload->'command'->>'decision'='approve'
   AND decision.expires_at>clock_timestamp() AND task.state='RUNNING'
   AND (NEW.request->'members'->0->>'inputDigest')=(os_agent_reviewed_grant(decision.id)->>'grantDigest'))
 THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));PERFORM os_assert_agent_work_current(w);
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_payload_write() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE w os_work_attempts%ROWTYPE; r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE;
 a os_admissions%ROWTYPE; reg os_registrations%ROWTYPE; expected text; units jsonb; command jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_payload_write_immutable'; END IF;
 SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=NEW.root_id;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO reg FROM os_registrations WHERE installation_id=NEW.installation_id
  AND application_id=NEW.application_id AND revision=a.registration_revision;
 command:=jsonb_build_object('schema','agent-private-input-write/1',
  'writeId',NEW.id,'taskId',NEW.task_id,'segmentId',NEW.segment_id,'controlEpoch',NEW.control_epoch,
  'schemaRef',NEW.schema_ref,'schemaVersion',NEW.schema_version,'plainBytes',NEW.plain_bytes);
 IF a.context->'harness'->>'ref' LIKE 'private-planned-read/%' THEN
  IF NEW.model_context IS NULL OR NOT COALESCE(os_agent_context_matches(a,NEW.model_context),false)
   THEN RAISE EXCEPTION 'agent_payload_purpose_binding';END IF;
  command=command||jsonb_build_object('context',NEW.model_context);
 ELSIF NEW.model_context IS NOT NULL THEN RAISE EXCEPTION 'agent_payload_legacy_purpose';END IF;
 expected:=os_agent_resource_digest('command',command);
 units:=jsonb_build_object('tokens',0,'costMicros',0,'workMs',NEW.timeout_ms,'computeMs',NEW.timeout_ms,'storageBytes',2*NEW.plain_bytes+4096);
 IF NOT COALESCE(w.id IS NOT NULL AND w.kind='agent.storage' AND w.accounting_format='agent-resources/1'
  AND w.state='RUNNING' AND w.invocation_id=NEW.id AND q.id IS NOT NULL
  AND a.context->>'accountingFormat'='agent-resources/1' AND reg.revision IS NOT NULL
  AND NEW.request_digest=expected AND w.reserved=units
  AND NEW.timeout_ms<=(q.policy->>'requestTimeoutMs')::bigint
  AND NEW.created_at<=clock_timestamp() AND NEW.expires_at=NEW.created_at+((reg.payload->'application'->>'retentionDays')::bigint*interval '1 day')
  AND NOT EXISTS(SELECT 1 FROM os_artifacts WHERE id=NEW.artifact_id)
  AND w.request_digest=os_agent_resource_digest('command',jsonb_build_object('schema','agent-resource-reservation/1',
   'taskId',NEW.task_id,'segmentId',NEW.segment_id,'epoch',NEW.control_epoch,'invocationId',NEW.id,
   'kind','agent.storage','inputDigest',expected,'units',units,'timeoutMs',NEW.timeout_ms)),false)
  THEN RAISE EXCEPTION 'agent_payload_write_binding'; END IF;
 PERFORM os_assert_agent_work_current(w);
 PERFORM os_agent_resource_owner(q);
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_tool_call() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE o os_agent_tool_operations%ROWTYPE; w os_work_attempts%ROWTYPE; p os_agent_tool_profiles%ROWTYPE;
 prior os_agent_tool_calls%ROWTYPE; previous os_work_attempts%ROWTYPE; c jsonb; a jsonb; units jsonb; expected_kind text;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_call_immutable'; END IF;
 SELECT * INTO o FROM os_agent_tool_operations WHERE id=NEW.operation_id;PERFORM os_assert_agent_tool_current(o);
 SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;PERFORM os_assert_agent_work_current(w);
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO prior FROM os_agent_tool_calls WHERE operation_id=NEW.operation_id ORDER BY ordinal DESC LIMIT 1;
 expected_kind=CASE WHEN (p.payload ? 'memory' OR p.payload ? 'knowledge') THEN 'agent.memory' ELSE 'agent.tool' END;
 c:=o.payload->'context';a:=NEW.request->'attempt';units:=jsonb_build_object('tokens',0,'costMicros',0,'workMs',w.reserved->'workMs','computeMs',0,'storageBytes',0);
 IF NOT COALESCE(w.state='RESERVED' AND w.kind=expected_kind AND w.root_id=NEW.root_id AND o.root_id=NEW.root_id AND w.invocation_id=NEW.id
 AND ROW(w.installation_id,w.application_id,w.tenant_id,w.subject_id)=ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
 AND w.task_id=o.task_id AND w.segment_id=(c->>'segmentId')::uuid AND w.control_epoch=(c->>'controlEpoch')::bigint
 AND NEW.profile_digest=p.digest AND NEW.request_digest=os_agent_profile_digest('command',NEW.request)
 AND NEW.request=jsonb_build_object('record',o.payload,'callId',NEW.id,'attemptNumber',NEW.ordinal,'attempt',a,'reserved',units)
 AND w.reserved=units AND units->'workMs'=(SELECT policy->'requestTimeoutMs' FROM os_agent_resource_accounts WHERE root_id=o.root_id)
 AND (p.payload->'execution'->>'requestTimeoutMs')::bigint<(units->>'workMs')::bigint AND NEW.ordinal=COALESCE(prior.ordinal,0)+1
 AND a=jsonb_build_object('subject',c->'subject','id',w.id,'taskId',w.task_id,'segmentId',w.segment_id,'rootId',w.root_id,
  'controlEpoch',w.control_epoch,'leaseToken',w.lease_token,'leaseUntil',a->'leaseUntil','state','RESERVED')
 AND (a->>'leaseUntil')::timestamptz=w.lease_until
 AND w.request_digest=os_agent_profile_digest('command',jsonb_build_object('schema','agent-resource-reservation/1','taskId',w.task_id,
  'segmentId',w.segment_id,'epoch',w.control_epoch,'invocationId',NEW.id,'kind',expected_kind,'inputDigest',o.digest,'units',units,'timeoutMs',units->'workMs'))
 AND NEW.created_at<=clock_timestamp() AND NEW.expires_at=(SELECT expires_at FROM os_agent_payload_writes WHERE artifact_id=o.binding_id),false)
 THEN RAISE EXCEPTION 'agent_tool_call_binding'; END IF;
 IF prior.id IS NOT NULL THEN
  SELECT * INTO previous FROM os_work_attempts WHERE id=prior.attempt_id;
  IF NOT COALESCE(previous.state='RELEASED' AND previous.lease_until<=clock_timestamp()
   AND NOT EXISTS(SELECT 1 FROM os_agent_tool_starts WHERE id=prior.id)
   AND NOT EXISTS(SELECT 1 FROM os_agent_tool_finishes WHERE id=prior.id),false)
  THEN RAISE EXCEPTION 'agent_tool_retry_not_admitted'; END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_agent_memory_artifact_source(bid uuid, attempt uuid, artifact uuid) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT COALESCE(EXISTS(SELECT 1 FROM task_memory_bindings b JOIN os_tasks t ON t.id=b.task_id
  JOIN os_budget_roots r ON r.id=t.budget_root_id JOIN os_work_attempts w ON w.id=attempt
  JOIN os_artifacts a ON a.id=artifact
  WHERE b.id=bid AND b.profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1') AND w.kind='agent.storage' AND w.state='SETTLED'
   AND w.task_id=b.task_id AND w.root_id=r.id AND r.root_task_id=b.task_id AND r.admission_id=b.admission_id
   AND ROW(w.installation_id,w.application_id,w.tenant_id,w.subject_id)=ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   AND ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)=ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   AND a.purpose='artifact' AND a.classification='protected'
   AND (EXISTS(SELECT 1 FROM os_agent_payload_writes p JOIN os_agent_private_payloads f ON f.write_id=p.id
     WHERE p.attempt_id=w.id AND p.root_id=w.root_id AND p.task_id=w.task_id AND f.id=a.id
      AND a.ciphertext_digest=f.ciphertext_digest)
    OR EXISTS(SELECT 1 FROM os_agent_model_slots s JOIN os_agent_model_calls c ON c.id=s.call_id
     JOIN os_agent_model_archives f ON f.slot_id=s.id WHERE s.attempt_id=w.id AND c.root_id=w.root_id
      AND c.task_id=w.task_id AND f.id=a.id AND a.ciphertext_digest=f.ciphertext_digest)
    OR EXISTS(SELECT 1 FROM os_agent_tool_slots s JOIN os_agent_tool_calls c ON c.id=s.id
     JOIN os_agent_tool_operations o ON o.id=c.operation_id JOIN os_agent_tool_archives f ON f.slot_id=c.id
     JOIN os_agent_tool_profiles p ON p.installation_id=c.installation_id AND p.application_id=c.application_id
      AND p.digest=c.profile_digest
     WHERE s.attempt_id=w.id AND c.root_id=w.root_id AND o.task_id=w.task_id AND (p.payload ? 'memory' OR p.payload ? 'knowledge')
      AND f.id=a.id AND a.ciphertext_digest=f.ciphertext_digest))),false)
$$;

CREATE OR REPLACE FUNCTION os_commit_agent_memory_source() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE b task_memory_bindings%ROWTYPE; w os_work_attempts%ROWTYPE; ident uuid; aid uuid; tid uuid;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_public_events' THEN
  SELECT task_id INTO tid FROM os_segments WHERE id=NEW.segment_id;
  SELECT * INTO b FROM task_memory_bindings WHERE task_id=tid AND profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1');
  IF b.id IS NOT NULL AND (NEW.payload->>'name'='os.grounded/1' OR NEW.payload->>'type' IN
   ('TEXT_MESSAGE_START','TEXT_MESSAGE_CONTENT','TEXT_MESSAGE_END')) AND NOT EXISTS(
    SELECT 1 FROM task_memory_events WHERE binding_id=b.id AND event_id=NEW.id AND erasure_id IS NULL)
  THEN RAISE EXCEPTION 'agent_memory_public_source_untracked';END IF;
  RETURN NULL;
 ELSIF TG_TABLE_NAME='os_agent_private_payloads' THEN
  SELECT attempt_id INTO ident FROM os_agent_payload_writes WHERE id=NEW.write_id;aid=NEW.id;
 ELSIF TG_TABLE_NAME='os_agent_model_archives' THEN
  SELECT attempt_id INTO ident FROM os_agent_model_slots WHERE id=NEW.slot_id;aid=NEW.id;
 ELSE
  SELECT s.attempt_id INTO ident FROM os_agent_tool_slots s JOIN os_agent_tool_calls c ON c.id=s.id
   JOIN os_agent_tool_profiles p ON p.installation_id=c.installation_id AND p.application_id=c.application_id
    AND p.digest=c.profile_digest WHERE s.id=NEW.slot_id AND (p.payload ? 'memory' OR p.payload ? 'knowledge');aid=NEW.id;
 END IF;
 IF ident IS NULL THEN RETURN NULL;END IF;
 SELECT * INTO w FROM os_work_attempts WHERE id=ident;
 SELECT * INTO b FROM task_memory_bindings WHERE task_id=w.task_id AND profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1');
 IF b.id IS NULL OR NOT EXISTS(SELECT 1 FROM os_agent_tool_starts start JOIN os_agent_tool_calls c ON c.id=start.id
  JOIN os_agent_tool_profiles p ON p.installation_id=c.installation_id AND p.application_id=c.application_id
   AND p.digest=c.profile_digest WHERE c.root_id=w.root_id AND (p.payload ? 'memory' OR p.payload ? 'knowledge')
    AND start.created_at<=NEW.created_at) THEN RETURN NULL;END IF;
 IF NOT os_agent_memory_artifact_source(b.id,ident,aid) OR NOT EXISTS(SELECT 1 FROM task_memory_artifacts
  WHERE binding_id=b.id AND agent_attempt_id=ident AND artifact_id=aid AND result_id IS NULL AND erasure_id IS NULL)
 THEN RAISE EXCEPTION 'agent_memory_private_source_untracked';END IF;
 RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION os_assert_agent_input_dependency(dep jsonb, c jsonb, root uuid, before_at timestamp with time zone) RETURNS void LANGUAGE plpgsql AS $$
DECLARE accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 tool_accepted os_agent_tool_acceptances%ROWTYPE; tool os_agent_tool_calls%ROWTYPE; tool_archive os_agent_tool_archives%ROWTYPE;
 page os_agent_input_result_sets%ROWTYPE; artifact os_artifacts%ROWTYPE; expected_schema text;
BEGIN

 IF dep->'payload'->>'schemaRef'='AgentNativeAnalysisResult' THEN
  PERFORM os_assert_agent_native_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 IF dep->'payload'->>'schemaRef'='AgentQueryFactSet' THEN
  PERFORM os_assert_agent_query_fact_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 IF dep->'payload'->>'schemaRef'='AgentOwnerReply' THEN
  PERFORM os_assert_agent_owner_reply_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF dep->'payload'->>'schemaRef'='AgentProviderResponse' THEN
  SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=(dep->>'resultId')::uuid;
  SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
  SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
  IF NOT COALESCE(producer.root_id=root AND os_agent_source_context(c,producer.request->'context') AND producer.request->'context'->'subject'=c->'subject'
   AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
    'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
     'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
    'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
   AND (dep->>'acceptedAt')::timestamptz=accepted.created_at AND accepted.created_at<=before_at AND producer.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSIF dep->'payload'->>'schemaRef' IN ('EvidencePage','AgentQueryPage','AgentMemoryPage','AgentPrivateKnowledgePage') THEN
  SELECT * INTO tool_accepted FROM os_agent_tool_acceptances WHERE id=(dep->>'resultId')::uuid;
  SELECT * INTO tool FROM os_agent_tool_calls WHERE id=tool_accepted.call_id;
  SELECT * INTO tool_archive FROM os_agent_tool_archives WHERE id=tool_accepted.artifact_id;
  SELECT CASE WHEN p.payload ? 'knowledge' THEN 'AgentPrivateKnowledgePage' WHEN p.payload ? 'memory' THEN 'AgentMemoryPage' ELSE CASE p.payload->'read'->>'outputContract' WHEN 'EvidencePage/1' THEN 'EvidencePage' WHEN 'AgentQueryPage/1' THEN 'AgentQueryPage' END END INTO expected_schema
   FROM os_agent_tool_profiles p WHERE p.installation_id=tool.installation_id AND p.application_id=tool.application_id
    AND p.policy_digest=tool.request->'record'->'profile'->>'digest';
  IF expected_schema='AgentPrivateKnowledgePage' THEN
   PERFORM os_assert_agent_memory_context(tool.request->'record'->'context',true);
   IF tool_accepted.knowledge_source->'result' IS DISTINCT FROM dep THEN RAISE EXCEPTION 'agent_knowledge_dependency_receipt';END IF;
  END IF;
  IF expected_schema='AgentMemoryPage' THEN
   PERFORM os_assert_agent_memory_context(tool.request->'record'->'context',true);
   IF tool_accepted.memory_source->'result' IS DISTINCT FROM dep THEN RAISE EXCEPTION 'agent_memory_dependency_receipt';END IF;
  END IF;
  IF NOT COALESCE(expected_schema=dep->'payload'->>'schemaRef' AND tool.root_id=root AND os_agent_source_context(c,tool.request->'record'->'context') AND tool.request->'record'->'context'->'subject'=c->'subject'
   AND dep=jsonb_build_object('subject',c->'subject','taskId',tool.request->'record'->'context'->'taskId','rootId',tool.root_id,
    'resultId',tool_accepted.id,'producerStepId',tool.id,'acceptedAttemptId',tool.attempt_id,
    'payload',jsonb_build_object('artifactRef','artifact/'||tool_archive.id,'ciphertextDigest',tool_archive.ciphertext_digest,
     'bytes',tool_archive.plain_bytes,'schemaRef',expected_schema,'schemaVersion',1),
    'lineageRef',null,'scopeRef',tool.request->'record'->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
   AND (dep->>'acceptedAt')::timestamptz=tool_accepted.created_at AND tool_accepted.created_at<=before_at AND tool.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSIF dep->'payload'->>'schemaRef'='AgentInputResultSet' THEN
  SELECT * INTO page FROM os_agent_input_result_sets WHERE id=(dep->>'producerStepId')::uuid;
  SELECT * INTO artifact FROM os_artifacts WHERE id=page.artifact_id;
  IF NOT COALESCE(page.root_id=root AND os_agent_source_context(c,page.record->'context') AND page.reference=dep
   AND page.created_at<=before_at AND artifact.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSE RAISE EXCEPTION 'agent_operation_dependency';
 END IF;
END $$;

CREATE OR REPLACE FUNCTION os_commit_task_memory() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE bid uuid; b task_memory_bindings%ROWTYPE; e task_memory_erasures%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_TABLE_NAME='task_memory_bindings' THEN bid=NEW.id;ELSE bid=NEW.binding_id;END IF;
 PERFORM os_assert_task_memory(bid,TG_OP='INSERT' AND TG_TABLE_NAME<>'task_memory_erasures'
  AND NOT (TG_TABLE_NAME='task_memory_artifacts' AND EXISTS(SELECT 1 FROM task_memory_bindings
   WHERE id=bid AND profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1'))));
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 IF TG_TABLE_NAME='task_memory_artifacts' AND b.profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1') THEN
  IF NEW.result_id IS NOT NULL OR NEW.agent_attempt_id IS NULL
   OR NOT os_agent_memory_artifact_source(bid,NEW.agent_attempt_id,NEW.artifact_id)
   OR (TG_OP='INSERT' AND EXISTS(SELECT 1 FROM task_memory_erasures WHERE binding_id=bid AND state='COMPLETE'))
   THEN RAISE EXCEPTION 'agent_memory_artifact_binding';END IF;
 ELSIF TG_TABLE_NAME='task_memory_artifacts' THEN
  IF NEW.agent_attempt_id IS NOT NULL THEN RAISE EXCEPTION 'legacy_memory_artifact_producer';END IF;
  IF NOT EXISTS(SELECT 1 FROM os_accepted_results r JOIN os_artifacts a ON a.id=r.artifact_id
   WHERE r.id=NEW.result_id AND r.task_id=b.task_id AND r.artifact_id=NEW.artifact_id
    AND r.contract_ref='CognitiveStageResult' AND a.ciphertext_digest=r.ciphertext_digest AND a.purpose='artifact')
   THEN RAISE EXCEPTION 'task_memory_artifact_binding';END IF;
 ELSIF TG_TABLE_NAME='task_memory_outputs' THEN
  IF b.profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1') THEN RAISE EXCEPTION 'agent_memory_output_requires_metered_payload';END IF;
  IF NOT EXISTS(SELECT 1 FROM os_artifacts WHERE id=NEW.artifact_id AND ciphertext_digest=NEW.ciphertext_digest
   AND purpose='artifact' AND classification='protected') THEN RAISE EXCEPTION 'task_memory_output_binding';END IF;
 ELSIF TG_TABLE_NAME='task_memory_events' THEN
  IF NOT EXISTS(SELECT 1 FROM os_public_events p JOIN os_segments s ON s.id=p.segment_id WHERE p.id=NEW.event_id
   AND s.task_id=b.task_id AND ((NEW.erasure_id IS NULL AND (p.payload->>'name'='os.grounded/1' OR
     (b.profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1') AND p.payload->>'type' IN ('TEXT_MESSAGE_START','TEXT_MESSAGE_CONTENT','TEXT_MESSAGE_END')))) OR
    (NEW.erasure_id IS NOT NULL AND p.payload=jsonb_build_object('type','CUSTOM','name','os.memory-erased/1',
     'value',jsonb_build_object('erasureId',NEW.erasure_id))))) THEN RAISE EXCEPTION 'task_memory_event_binding';END IF;
 ELSIF TG_TABLE_NAME='task_memory_erasures' THEN
  SELECT * INTO e FROM task_memory_erasures WHERE id=NEW.id;
  IF NOT os_task_memory_affected(bid,e.batch_id) THEN RAISE EXCEPTION 'task_memory_erasure_scope';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=COALESCE(e.cleanup_session_id,e.session_id);
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'task_memory_erasure_owner';END IF;
  IF e.state='COMPLETE' AND (EXISTS(SELECT 1 FROM os_work_attempts WHERE task_id=b.task_id
    AND (kind IN ('inference','repair') OR (b.profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1') AND kind LIKE 'agent.%')) AND state IN ('RUNNING','UNKNOWN'))
   OR EXISTS(SELECT 1 FROM task_memory_artifacts WHERE binding_id=bid AND erasure_id IS NULL)
   OR EXISTS(SELECT 1 FROM task_memory_outputs WHERE binding_id=bid AND erasure_id IS NULL)
   OR EXISTS(SELECT 1 FROM task_memory_events WHERE binding_id=bid AND erasure_id IS NULL))
   THEN RAISE EXCEPTION 'task_memory_erasure_incomplete';END IF;
 END IF;
 RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION os_guard_task_memory_event() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE eid uuid; bid uuid; bound_task uuid;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_OP<>'INSERT' THEN
  SELECT s.task_id INTO bound_task FROM os_segments s WHERE s.id=OLD.segment_id;
 ELSE
  SELECT s.task_id INTO bound_task FROM os_segments s WHERE s.id=NEW.segment_id;
 END IF;
 SELECT id INTO bid FROM task_memory_bindings WHERE task_id=bound_task;
 IF bid IS NULL THEN
  IF TG_OP='UPDATE' AND EXISTS(SELECT 1 FROM task_memory_bindings b JOIN os_segments s ON s.task_id=b.task_id
   WHERE s.id=NEW.segment_id) THEN RAISE EXCEPTION 'task_memory_event_scope_changed';END IF;
  IF TG_OP='DELETE' THEN RETURN OLD;ELSE RETURN NEW;END IF;
 END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.payload->>'name'='os.memory-erased/1' THEN RAISE EXCEPTION 'task_memory_erasure_forged';END IF;
  IF NEW.payload->>'name'='os.grounded/1' OR (NEW.payload->>'type' IN ('TEXT_MESSAGE_START','TEXT_MESSAGE_CONTENT','TEXT_MESSAGE_END')
   AND EXISTS(SELECT 1 FROM task_memory_bindings WHERE id=bid AND profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1')))
   THEN PERFORM os_assert_task_memory(bid,true);END IF;
  RETURN NEW;
 END IF;
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'task_memory_event_retained';END IF;
 SELECT erasure_id INTO eid FROM task_memory_events WHERE event_id=OLD.id AND binding_id=bid;
 IF NOT COALESCE((OLD.payload->>'name'='os.grounded/1' OR (OLD.payload->>'type' IN
   ('TEXT_MESSAGE_START','TEXT_MESSAGE_CONTENT','TEXT_MESSAGE_END') AND EXISTS(SELECT 1 FROM task_memory_bindings
    WHERE id=bid AND profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1')))),false) OR eid IS NULL
  OR (to_jsonb(NEW)-ARRAY['payload','event_digest']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['payload','event_digest'])
  OR NEW.payload IS DISTINCT FROM jsonb_build_object('type','CUSTOM','name','os.memory-erased/1',
   'value',jsonb_build_object('erasureId',eid))
  OR NOT EXISTS(SELECT 1 FROM task_memory_erasures WHERE id=eid AND binding_id=bid AND state='PENDING')
  THEN RAISE EXCEPTION 'task_memory_event_immutable';END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_commit_task_memory_completion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE bid uuid;
BEGIN
 IF NEW.state<>'COMPLETED' OR OLD.state='COMPLETED' THEN RETURN NULL;END IF;
 SELECT id INTO bid FROM task_memory_bindings WHERE task_id=NEW.id;
 IF bid IS NULL THEN RETURN NULL;END IF;
 PERFORM os_assert_task_memory(bid,true);
 IF EXISTS(SELECT 1 FROM task_memory_bindings WHERE id=bid AND profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1')) THEN
  IF NOT EXISTS(SELECT 1 FROM task_memory_artifacts d JOIN os_agent_private_payloads f ON f.id=d.artifact_id
    JOIN os_agent_payload_writes p ON p.id=f.write_id WHERE d.binding_id=bid AND d.erasure_id IS NULL
     AND p.id=os_query_source_uuid5(NEW.id,CASE WHEN EXISTS(SELECT 1 FROM task_memory_bindings WHERE id=bid AND profile_ref='OSAgentPlannerMemory/1') THEN 'verified-read-answer/1' ELSE 'verified-memory-read-answer/1' END)
     AND p.schema_ref=CASE WHEN EXISTS(SELECT 1 FROM task_memory_bindings WHERE id=bid AND profile_ref='OSAgentPlannerMemory/1') THEN 'AgentReadVerification' ELSE 'AgentMemoryReadVerification' END AND p.schema_version=1 AND d.agent_attempt_id=p.attempt_id)
   OR NOT EXISTS(SELECT 1 FROM task_memory_events d JOIN os_public_events e ON e.id=d.event_id
    WHERE d.binding_id=bid AND d.erasure_id IS NULL AND e.payload->>'name'='os.grounded/1')
  THEN RAISE EXCEPTION 'agent_memory_final_untracked';END IF;
  RETURN NULL;
 END IF;
 IF NOT EXISTS(SELECT 1 FROM task_memory_outputs WHERE binding_id=bid AND erasure_id IS NULL)
  OR NOT EXISTS(SELECT 1 FROM task_memory_events WHERE binding_id=bid AND erasure_id IS NULL)
  THEN RAISE EXCEPTION 'task_memory_final_untracked';END IF;
 RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION os_assert_task_memory(bid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE b task_memory_bindings%ROWTYPE; s personal_learning_settings%ROWTYPE;
 t os_tasks%ROWTYPE; a os_admissions%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; k task_knowledge_snapshots%ROWTYPE;
 n bigint; watermark bigint;
BEGIN
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 IF os_restoration_erased('task_memory_bindings',to_jsonb(b)) THEN
  IF live THEN RAISE EXCEPTION 'restored_private_content_erased';END IF;
  RETURN;
 END IF;

 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM task_memory_bindings WHERE id=bid;
 SELECT * INTO t FROM os_tasks WHERE id=b.task_id;
 SELECT * INTO a FROM os_admissions WHERE id=b.admission_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
 SELECT * INTO k FROM task_knowledge_snapshots WHERE binding_id=bid;
 SELECT count(*) INTO n FROM task_memory_references WHERE binding_id=bid;
 IF b.id IS NULL OR t.id IS NULL OR a.id IS NULL OR s.id IS NULL OR a.task_id<>t.id
  OR b.deadline<>t.deadline OR a.authority->>'sessionId' IS DISTINCT FROM b.session_id::text
  OR n<>b.reference_count OR EXISTS(SELECT 1 FROM task_memory_references r WHERE r.binding_id=bid AND r.ordinal>=n)
  OR (SELECT count(*) FROM task_memory_bindings WHERE settings_id=s.id)>128
  OR NOT EXISTS(SELECT 1 FROM os_dispatches WHERE task_id=t.id AND workflow_profile=
   CASE b.profile_ref WHEN 'OSTaskMemory/1' THEN 'OSTaskMemoryDriver/1' WHEN 'OSAgentMemory/1' THEN 'OSAgentTaskDriver/1' WHEN 'OSAgentPlannerMemory/1' THEN 'OSAgentTaskDriver/1' END)
  OR (b.profile_ref='OSTaskMemory/1' AND b.reference_count>8)
  OR (b.profile_ref='OSAgentMemory/1' AND (b.reference_count>64 OR b.knowledge_profile_ref IS NOT NULL
   OR a.context->'harness'->>'ref' NOT LIKE 'memory-assisted-read/%'
   OR NOT EXISTS(SELECT 1 FROM os_budget_roots WHERE id=t.budget_root_id AND root_task_id=t.id
    AND accounting_format='agent-resources/1' AND admission_id=a.id)))
  OR (b.profile_ref='OSAgentPlannerMemory/1' AND (b.reference_count>64 OR b.knowledge_profile_ref IS DISTINCT FROM 'OSProtectedPlanning/1'
   OR a.context->'harness'->>'ref' NOT LIKE 'private-planned-read/%' OR k.reference_metadata IS DISTINCT FROM '[]'::jsonb
   OR NOT os_agent_context_matches(a,a.context)
   OR NOT EXISTS(SELECT 1 FROM os_budget_roots WHERE id=t.budget_root_id AND root_task_id=t.id
    AND accounting_format='agent-resources/1' AND admission_id=a.id)))
  OR (b.knowledge_profile_ref IS NULL) IS DISTINCT FROM (k.id IS NULL)
  OR (k.id IS NOT NULL AND b.knowledge_binding_mac IS DISTINCT FROM k.binding_mac)
  OR (k.id IS NOT NULL AND EXISTS(SELECT 1 FROM jsonb_array_elements(k.reference_metadata) r
   WHERE r IS DISTINCT FROM jsonb_build_object('chunkId',r->'chunkId','documentId',r->'documentId',
    'revisionId',r->'revisionId','revision',r->'revision','layer',r->'layer','generationId',r->'generationId',
    'ciphertextDigest',r->'ciphertextDigest') OR r->>'layer' NOT IN ('business','architecture','system','shared')
    OR r->>'ciphertextDigest' !~ '^[0-9a-f]{64}$' OR jsonb_typeof(r->'revision')<>'number'))
  THEN RAISE EXCEPTION 'task_memory_exact_binding';END IF;
 IF NOT live THEN RETURN;END IF;
 SELECT sequence INTO watermark FROM memory_recovery_owners WHERE settings_id=s.id;
 IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation)
   IS DISTINCT FROM ROW(b.settings_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation)
  OR watermark IS DISTINCT FROM b.journal_sequence
  OR EXISTS(SELECT 1 FROM task_memory_erasures WHERE binding_id=bid)
  OR t.deadline<=clock_timestamp() OR session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR (k.valid_until IS NOT NULL AND k.valid_until<=clock_timestamp())
  THEN RAISE EXCEPTION 'task_memory_obsolete';END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
  AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
 IF app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
  OR owner.host_policy_generation IS DISTINCT FROM (a.authority->>'policyGeneration')::bigint
  THEN RAISE EXCEPTION 'task_memory_owner_obsolete';END IF;
 IF b.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=b.context_id
  AND settings_id=s.id AND kind='context' AND state='ACTIVE') THEN RAISE EXCEPTION 'task_memory_context_obsolete';END IF;
 IF (n>0 OR b.profile_ref IN ('OSAgentMemory/1','OSAgentPlannerMemory/1')) AND (s.choice->>'useMemory' IS DISTINCT FROM 'true' OR s.choice->>'embeddingProfile'<>'minilm-english-onnx/1')
  THEN RAISE EXCEPTION 'task_memory_choice_obsolete';END IF;
 IF EXISTS(SELECT 1 FROM task_memory_references r JOIN personal_knowledge_entries e ON e.id=r.entry_id
  JOIN personal_knowledge_revisions v ON v.id=r.revision_id
  LEFT JOIN classified_knowledge_bindings c ON c.revision_id=r.revision_id
  WHERE r.binding_id=bid AND (e.settings_id<>s.id OR e.state<>'ACTIVE' OR e.version<>r.entry_version
   OR e.active_revision_id<>r.revision_id OR v.envelope IS NULL OR c.revision_id IS NULL
   OR c.lane<>r.lane OR r.context_ref IS DISTINCT FROM CASE WHEN c.context_id IS NULL THEN 'general/1'
     ELSE 'context/'||c.context_id::text||'/1' END
   OR r.context_ref NOT IN ('general/1',b.context_ref) OR os_revision_source_forgotten(r.revision_id)
   OR (e.valid_until IS NOT NULL AND e.valid_until<=clock_timestamp())
   OR (c.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=c.context_id AND state='ACTIVE'))
   OR (c.claim_key_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts WHERE id=c.claim_key_id AND state='ACTIVE'))
   OR NOT EXISTS(SELECT 1 FROM personal_index_pointers p JOIN personal_index_generations g ON g.id=p.generation_id
    WHERE p.entry_id=r.entry_id AND p.revision_id=r.revision_id AND p.entry_version=r.entry_version
    AND p.projection_id=r.projection_id AND g.settings_id=s.id AND g.generation=b.index_generation AND g.state='READY')))
  THEN RAISE EXCEPTION 'task_memory_reference_obsolete';END IF;
END $$;

CREATE OR REPLACE FUNCTION os_assert_agent_memory_context(c jsonb, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE b task_memory_bindings%ROWTYPE; a os_admissions%ROWTYPE; r os_budget_roots%ROWTYPE;
 q os_agent_resource_accounts%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF COALESCE(c->'harness'->>'ref','') NOT LIKE 'memory-assisted-read/%' AND COALESCE(c->'harness'->>'ref','') NOT LIKE 'private-planned-read/%' THEN RETURN;END IF;
 SELECT * INTO b FROM task_memory_bindings WHERE task_id=(c->>'taskId')::uuid;
 SELECT * INTO a FROM os_admissions WHERE id=b.admission_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=(c->>'rootId')::uuid;
 IF NOT COALESCE(((b.profile_ref='OSAgentMemory/1' AND a.context=c AND b.knowledge_profile_ref IS NULL AND b.knowledge_binding_mac IS NULL)
   OR (b.profile_ref='OSAgentPlannerMemory/1' AND os_agent_context_matches(a,c) AND b.knowledge_profile_ref='OSProtectedPlanning/1' AND b.knowledge_binding_mac IS NOT NULL)) AND a.task_id=b.task_id
  AND r.root_task_id=b.task_id AND r.admission_id=a.id AND r.accounting_format='agent-resources/1'
  AND a.bot->'capabilities'->'allowedKinds' @> '["memory"]'::jsonb,false)
 THEN RAISE EXCEPTION 'agent_memory_context_binding';END IF;
 IF live THEN
  SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=r.id;
  PERFORM os_agent_resource_owner(q);
  PERFORM 1 FROM personal_learning_settings WHERE id=b.settings_id FOR UPDATE;
 END IF;
 PERFORM os_assert_task_memory(b.id,live);
END $$;
CREATE OR REPLACE FUNCTION os_assert_agent_knowledge_receipt(accepted os_agent_tool_acceptances, c os_agent_tool_calls, o os_agent_tool_operations) RETURNS void LANGUAGE plpgsql AS $$
DECLARE b task_memory_bindings%ROWTYPE; a os_agent_tool_archives%ROWTYPE; value jsonb; item jsonb; expected jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM task_memory_bindings WHERE task_id=o.task_id;
 SELECT * INTO a FROM os_agent_tool_archives WHERE id=accepted.artifact_id;
 value=accepted.knowledge_source;
 expected=jsonb_build_object('subject',o.payload->'context'->'subject','taskId',o.task_id,'rootId',o.root_id,
  'resultId',accepted.id,'producerStepId',c.id,'acceptedAttemptId',c.attempt_id,'payload',jsonb_build_object(
   'artifactRef','artifact/'||a.id,'ciphertextDigest',a.ciphertext_digest,'bytes',a.plain_bytes,
   'schemaRef','AgentPrivateKnowledgePage','schemaVersion',1),'lineageRef',null,'scopeRef',o.payload->'context'->'scopeRef',
   'acceptedAt',value->'result'->'acceptedAt');
 IF NOT COALESCE(b.profile_ref='OSAgentPlannerMemory/1' AND value=jsonb_build_object('bindingId',b.id,
   'bindingMac',b.binding_mac,'result',expected,'knowledge',value->'knowledge')
  AND (value->'result'->>'acceptedAt')::timestamptz=accepted.created_at
  AND value->'knowledge'=jsonb_build_object('keyId',value->'knowledge'->'keyId','mac',value->'knowledge'->'mac','value',value->'knowledge'->'value')
  AND value->'knowledge'->>'keyId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
  AND value->'knowledge'->>'mac' ~ '^[a-f0-9]{64}$'
  AND value->'knowledge'->'value'=jsonb_build_object('scope',jsonb_build_object('installationId',b.installation_id,
   'applicationId',b.application_id,'tenantId',b.tenant_id),'contentRevision',value->'knowledge'->'value'->'contentRevision',
   'validUntil',value->'knowledge'->'value'->'validUntil','references',value->'knowledge'->'value'->'references')
  AND jsonb_typeof(value->'knowledge'->'value'->'contentRevision')='number'
  AND (value->'knowledge'->'value'->>'contentRevision') ~ '^[0-9]+$'
  AND (value->'knowledge'->'value'->>'contentRevision')::numeric<=9007199254740991
  AND (value->'knowledge'->'value'->'validUntil'='null'::jsonb OR (value->'knowledge'->'value'->>'validUntil')::timestamptz>clock_timestamp())
  AND jsonb_typeof(value->'knowledge'->'value'->'references')='array'
  AND jsonb_array_length(value->'knowledge'->'value'->'references')<=16
  AND (SELECT count(DISTINCT v->>'chunkId') FROM jsonb_array_elements(value->'knowledge'->'value'->'references') v)
   =jsonb_array_length(value->'knowledge'->'value'->'references'),false)
 THEN RAISE EXCEPTION 'agent_knowledge_accepted_source_binding';END IF;
 FOR item IN SELECT jsonb_array_elements(value->'knowledge'->'value'->'references') LOOP
  IF NOT COALESCE(item=jsonb_build_object('chunkId',item->'chunkId','documentId',item->'documentId','revisionId',item->'revisionId',
   'revision',item->'revision','layer',item->'layer','generationId',item->'generationId','ciphertextDigest',item->'ciphertextDigest')
   AND item->>'layer' IN ('business','architecture','system','shared') AND item->>'ciphertextDigest' ~ '^[a-f0-9]{64}$'
   AND jsonb_typeof(item->'revision')='number' AND item->>'revision' ~ '^[1-9][0-9]*$' AND (item->>'revision')::numeric<=32
   AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements_text(jsonb_build_array(item->'chunkId',item->'documentId',item->'revisionId',item->'generationId')) id
    WHERE id !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'),false)
   THEN RAISE EXCEPTION 'agent_knowledge_accepted_reference_binding';END IF;
 END LOOP;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_tool_acceptance() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE c os_agent_tool_calls%ROWTYPE; o os_agent_tool_operations%ROWTYPE; w os_work_attempts%ROWTYPE; storage os_work_attempts%ROWTYPE; archive os_agent_tool_archives%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_acceptance_immutable'; END IF;
 SELECT * INTO c FROM os_agent_tool_calls WHERE id=NEW.call_id;SELECT * INTO o FROM os_agent_tool_operations WHERE id=c.operation_id;PERFORM os_assert_agent_tool_current(o);
 SELECT * INTO w FROM os_work_attempts WHERE id=c.attempt_id;SELECT * INTO archive FROM os_agent_tool_archives WHERE id=NEW.artifact_id;
 SELECT x.* INTO storage FROM os_work_attempts x JOIN os_agent_tool_slots s ON x.id=s.attempt_id WHERE s.id=c.id;
 IF NOT COALESCE(w.state='SETTLED' AND storage.state='SETTLED' AND archive.slot_id=c.id AND c.expires_at>clock_timestamp()
 AND (SELECT kind FROM os_agent_tool_finishes WHERE id=c.id)='candidate'
 AND ROW(w.installation_id,w.application_id,w.tenant_id,w.subject_id)=ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
 AND NEW.created_at>=archive.created_at AND NEW.created_at<=clock_timestamp(),false)
 THEN RAISE EXCEPTION 'agent_tool_acceptance_binding'; END IF;
 IF EXISTS(SELECT 1 FROM os_agent_tool_profiles p WHERE p.installation_id=c.installation_id
  AND p.application_id=c.application_id AND p.digest=c.profile_digest AND p.payload ? 'knowledge') THEN
  PERFORM os_assert_agent_knowledge_receipt(NEW,c,o);
 ELSIF NEW.knowledge_source IS NOT NULL THEN RAISE EXCEPTION 'agent_nonknowledge_source_receipt';END IF;
 IF EXISTS(SELECT 1 FROM os_agent_tool_profiles p WHERE p.installation_id=c.installation_id
  AND p.application_id=c.application_id AND p.digest=c.profile_digest AND p.payload ? 'memory') THEN
  PERFORM os_assert_agent_memory_receipt(NEW,c,o);
 ELSIF NEW.memory_source IS NOT NULL THEN RAISE EXCEPTION 'agent_nonmemory_source_receipt';END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_tool_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_applications%ROWTYPE; p jsonb; r jsonb; e jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_profile_immutable'; END IF;
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 p:=NEW.payload;r:=p->'read';e:=p->'execution';


 IF p ? 'knowledge' THEN
  r=p->'knowledge';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('knowledge',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability','harness',r->'harness',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'providerRef',r->'providerRef',
    'planning',r->'planning','outputContract','AgentPrivateKnowledgePage/1','adapterRef','private.knowledge.read/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'harness'->>'ref' LIKE 'private-planned-read/%'
   AND r->'planning'->'knowledgeCapability'=r->'capability'
   AND os_agent_private_planning_valid(r->'planning',NEW.installation_id,NEW.application_id,NEW.application_generation,NEW.registration_revision,r->'harness')
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'capabilities'->'allowedKinds' @> '["memory"]'::jsonb)
   AND EXISTS(SELECT 1 FROM os_agent_capabilities cap WHERE cap.installation_id=NEW.installation_id
    AND cap.application_id=NEW.application_id AND cap.application_generation=NEW.application_generation
    AND r->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
    AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='private.knowledge.read/1'
    AND cap.payload->>'scopePolicyRef'='private-reviewed-knowledge/1' AND cap.payload->'mcp'='null'::jsonb
    AND cap.payload->>'lifecycle'='qualified')
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','knowledgeProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','private-knowledge-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_knowledge_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'memory' THEN
  r=p->'memory';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('memory',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability','harness',r->'harness',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'providerRef',r->'providerRef',
    'outputContract','AgentMemoryPage/1','adapterRef','owner.memory.read/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'harness'->>'ref' LIKE 'memory-assisted-read/%'
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'capabilities'->'allowedKinds' @> '["memory"]'::jsonb)
   AND EXISTS(SELECT 1 FROM os_agent_capabilities cap WHERE cap.installation_id=NEW.installation_id
    AND cap.application_id=NEW.application_id AND cap.application_generation=NEW.application_generation
    AND r->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
    AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='owner.memory.read/1'
    AND cap.payload->>'scopePolicyRef'='owner-approved-memory/1' AND cap.payload->'mcp'='null'::jsonb
    AND cap.payload->>'lifecycle'='qualified')
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision','memoryProfile',os_agent_profile_pin(r,'manifest'),
    'usageProfile','owner-memory-elapsed/1','externalInference',false,'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND jsonb_typeof(e->'revision')='number'
   AND e->>'revision' ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND jsonb_typeof(e->'requestTimeoutMs')='number' AND e->>'requestTimeoutMs' ~ '^[1-9][0-9]*$'
   AND (e->>'requestTimeoutMs')::numeric BETWEEN 1 AND 29000
   AND jsonb_typeof(e->'maxResultBytes')='number' AND e->>'maxResultBytes' ~ '^[1-9][0-9]*$'
   AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576 AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_memory_tool_profile';END IF;
  RETURN NEW;
 END IF;
 IF p ? 'native' THEN
  r:=p->'native';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('native',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'harness',r->'harness','runtime',r->'runtime','verifier',r->'verifier','placement',r->'placement','limits',r->'limits','meter',r->'meter','adapterRef','native.offline-analysis/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$'
   AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'harness'->'features' @> '["native-execution"]'::jsonb)
   AND jsonb_typeof(r->'capability'->'revision')='number' AND r->'capability'->>'revision' ~ '^[1-9][0-9]*$'
   AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->'runtime'=jsonb_build_object('ref',r->'runtime'->'ref','revision',r->'runtime'->'revision','digest',r->'runtime'->'digest')
   AND r->'runtime'->>'ref'='python-offline-analysis/1' AND r->'runtime'->'revision'='1'::jsonb
   AND r->'runtime'->>'digest' ~ '^[a-f0-9]{64}$'
   AND r->'verifier'=jsonb_build_object('ref','native-source-values/1','revision',1,'digest',r->'verifier'->'digest')
   AND r->'verifier'->>'digest' ~ '^[a-f0-9]{64}$'
   AND r->'placement'=jsonb_build_object('providerDigest',r->'placement'->'providerDigest','runtimeDigest',r->'placement'->'runtimeDigest')
   AND r->'placement'->>'providerDigest' ~ '^[a-f0-9]{64}$' AND r->'placement'->>'runtimeDigest' ~ '^[a-f0-9]{64}$'
   AND os_native_analysis_limits(r->'limits') AND os_native_analysis_meter(r->'meter',(r->'limits'->>'timeoutMs')::bigint)
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'nativeProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','native-one-vcpu-allocation/1','externalInference',false)
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(e->'revision')='number' AND e->>'revision' ~ '^[1-9][0-9]*$'
   AND (e->>'revision')::numeric<=9007199254740991 AND NEW.created_at<=clock_timestamp(),false)
   THEN RAISE EXCEPTION 'agent_native_profile_binding'; END IF;
  RETURN NEW;
 END IF;
 IF p ? 'preparation' THEN
  r:=p->'preparation';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('preparation',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'hostDefinitionRef',r->'hostDefinitionRef',
    'providerRef',r->'providerRef','outputContract','AgentPreparedChange/1','adapterRef','typed.prepare/1')
   AND jsonb_typeof(r->'id')='string' AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (r->>'revision') ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND (r->'capability'->>'revision') ~ '^[1-9][0-9]*$' AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->>'hostDefinitionRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'preparationProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','host-preparation-elapsed/1','externalInference',false,
    'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (e->>'revision') ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND (e->>'requestTimeoutMs') ~ '^[1-9][0-9]*$' AND (e->>'requestTimeoutMs')::numeric BETWEEN 25000 AND 900000
   AND (e->>'maxResultBytes') ~ '^[1-9][0-9]*$' AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576
   AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_preparation_profile_binding'; END IF;
  RETURN NEW;
 END IF;

 IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
 AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
 AND p-ARRAY['read','execution']='{}'::jsonb AND p ?& ARRAY['read','execution']
 AND e=jsonb_build_object('id',e->'id','revision',e->'revision','readProfile',jsonb_build_object('ref',r->'id','revision',r->'revision',
   'digest',os_agent_profile_digest('manifest',r)),'usageProfile','host-read-elapsed/1','externalInference',false,
   'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
 AND (e->>'requestTimeoutMs')::bigint BETWEEN 1 AND 900000 AND (e->>'maxResultBytes')::bigint BETWEEN 1024 AND 1048576
 AND (e->>'revision')::bigint BETWEEN 1 AND 9007199254740991 AND (r->>'outputContract'='EvidencePage/1' OR (
 r->>'outputContract'='AgentQueryPage/1'
 AND r-ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']='{}'::jsonb
 AND r ?& ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']
 AND jsonb_typeof(r->'cursorField')='string' AND r->>'cursorField' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
 AND jsonb_typeof(r->'grain')='array' AND jsonb_array_length(r->'grain') BETWEEN 1 AND 64
 AND jsonb_typeof(r->'pageGroupFields')='array' AND jsonb_array_length(r->'pageGroupFields') BETWEEN 0 AND 64
 AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements((r->'grain')||(r->'pageGroupFields')) v
  WHERE jsonb_typeof(v)<>'string' OR (v#>>'{}') !~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$')
 AND jsonb_array_length(r->'grain')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'grain') v)
 AND jsonb_array_length(r->'pageGroupFields')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'pageGroupFields') v)
 ))
 AND r->'host'->>'installationId'=NEW.installation_id::text AND r->'host'->>'applicationId'=NEW.application_id::text
 AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_tool_profile_binding'; END IF;
 RETURN NEW;
END $$;
"""


def upgrade():
    op.execute(DDL)
    op.execute(HELPERS)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Private planning requires protected forward recovery')
