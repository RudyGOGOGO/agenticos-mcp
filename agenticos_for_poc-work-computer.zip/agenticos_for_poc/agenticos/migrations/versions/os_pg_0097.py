"""Dispatch production tool completion only on a positively matched profile.

Legacy admissions have no harness field. Preserve their original completion
contract and every production-origin predicate from frozen0093.
"""
from alembic import op

revision='os_pg_0097'
down_revision='os_pg_0096'
branch_labels=None
depends_on=None

COMPLETION=r"""
CREATE OR REPLACE FUNCTION os_check_wasm_creation_completion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; a os_admissions%ROWTYPE;
BEGIN
 IF NEW.state<>'COMPLETED' THEN RETURN NEW;END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.budget_root_id;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 -- Non-Agent tasks have no production admission; SQL NULL is not FALSE.
 IF a.id IS NULL THEN RETURN NEW;END IF;
 IF NOT COALESCE(a.context->'harness'->>'ref' LIKE 'verified-wasm-creation/%',false) THEN RETURN NEW;END IF;
 IF NOT COALESCE(r.root_task_id=NEW.id AND r.state='CLOSED'
  AND r.outstanding=jsonb_build_object('tokens',0,'costMicros',0,'workMs',0,'computeMs',0,'storageBytes',0)
  AND EXISTS(SELECT 1 FROM os_native_verifications v JOIN os_native_tools tool ON tool.verification_id=v.id
   JOIN os_agent_tool_acceptances accepted ON accepted.call_id=v.agent_call_id AND accepted.artifact_id=v.artifact_id
   JOIN os_agent_tool_calls call ON call.id=v.agent_call_id
   JOIN os_agent_tool_operations operation ON operation.id=call.operation_id
   JOIN os_work_attempts work ON work.id=call.attempt_id
   WHERE call.root_id=r.id AND operation.task_id=NEW.id AND operation.payload->'context'=a.context
    AND v.job_id IS NULL AND v.receipt->>'origin'='agent-resources/1' AND work.state='SETTLED'
    AND tool.id=os_query_source_uuid5(call.id,'verified-tool/1')
    AND ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)=ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)),false)
 THEN RAISE EXCEPTION 'agent_wasm_creation_incomplete'; END IF;
 RETURN NEW;
END $$;
"""


def upgrade():
    op.execute(COMPLETION)


def downgrade():
    raise RuntimeError('Completion scope requires protected forward recovery')
