"""Atomic finite-consent workflow outbox; additive0028."""
from alembic import op
revision="os_pg_0028"
down_revision="os_pg_0027"
branch_labels=None
depends_on=None

GUARDS = r"""
CREATE FUNCTION os_guard_input_delegation_dispatch() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_input_delegations%ROWTYPE; now_at timestamptz;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 now_at=clock_timestamp();
 SELECT * INTO d FROM os_input_delegations WHERE id=NEW.delegation_id;
 IF TG_OP='INSERT' THEN
  IF COALESCE((d.id IS NULL OR NEW.version<>1 OR NEW.state<>'DUE' OR NEW.attempts<>0
   OR NEW.created_at<>d.created_at OR NEW.next_attempt_at<>d.created_at
   OR NEW.created_at<now_at-interval '5 seconds' OR NEW.created_at>now_at+interval '1 second'),true)
  THEN RAISE EXCEPTION 'delegated_dispatch_initial'; END IF;
 ELSE
  IF COALESCE((NEW.version<>OLD.version+1 OR OLD.state IN ('STARTED','CLOSED','POISON')
   OR NOT ((NEW.state='LEASED' AND NEW.attempts=OLD.attempts+1 AND NEW.attempts<=8
      AND (OLD.state='DUE' AND OLD.next_attempt_at<=now_at OR OLD.state='LEASED' AND OLD.lease_until<=now_at)
      AND OLD.lease_token IS DISTINCT FROM NEW.lease_token AND NEW.lease_until>now_at
      AND NEW.lease_until<=now_at+interval '25 seconds' AND NEW.next_attempt_at=OLD.next_attempt_at)
     OR (OLD.state='LEASED' AND OLD.lease_until>now_at AND NEW.attempts=OLD.attempts
       AND NEW.state IN ('STARTED','CLOSED','DUE','POISON')
       AND (NEW.state='DUE' AND NEW.next_attempt_at>=now_at AND NEW.next_attempt_at<=now_at+interval '16 seconds'
         OR NEW.state<>'DUE' AND NEW.next_attempt_at=OLD.next_attempt_at)
       AND (NEW.state<>'POISON' OR OLD.attempts=8))
     OR (NEW.state='POISON' AND NEW.attempts=8 AND OLD.attempts=8
       AND (OLD.state='DUE' OR OLD.state='LEASED' AND OLD.lease_until<=now_at)
       AND NEW.next_attempt_at=OLD.next_attempt_at))),true)
  THEN RAISE EXCEPTION 'delegated_dispatch_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_os_input_delegation_dispatch BEFORE INSERT OR UPDATE ON os_input_delegation_dispatches
 FOR EACH ROW EXECUTE FUNCTION os_guard_input_delegation_dispatch();
CREATE FUNCTION os_guard_input_delegation_dispatch_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.state='LEASED' AND NEW.lease_until<=clock_timestamp()
  OR OLD.state='LEASED' AND NEW.state IN ('STARTED','CLOSED','DUE') AND OLD.lease_until<=clock_timestamp()
 THEN RAISE EXCEPTION 'delegated_dispatch_expired_lease'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_input_delegation_dispatch AFTER UPDATE ON os_input_delegation_dispatches
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_input_delegation_dispatch_commit();
CREATE FUNCTION os_guard_input_delegation_outbox_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM os_input_delegation_dispatches x WHERE
   (x.installation_id,x.application_id,x.tenant_id,x.subject_id,x.delegation_id,x.delegation_digest,x.task_id)=
   (NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.id,NEW.delegation_digest,NEW.task_id)
   AND x.state='DUE' AND x.version=1 AND x.attempts=0 AND x.created_at=NEW.created_at)
 THEN RAISE EXCEPTION 'delegated_consent_outbox_atomic'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_os_input_delegation_outbox AFTER INSERT ON os_input_delegations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_input_delegation_outbox_commit();
"""

def upgrade():
    op.execute('ALTER TABLE os_input_delegations ADD CONSTRAINT uq_input_delegation_dispatch_parent UNIQUE (installation_id, application_id, tenant_id, subject_id, id, delegation_digest, task_id)')
    op.execute("\nCREATE TABLE os_input_delegation_dispatches (\n\tid UUID NOT NULL, \n\tdelegation_id UUID NOT NULL, \n\tdelegation_digest VARCHAR(64) NOT NULL, \n\ttask_id UUID NOT NULL, \n\tworkflow_id VARCHAR(256) NOT NULL, \n\tstate VARCHAR(16) NOT NULL, \n\tversion BIGINT NOT NULL, \n\tattempts BIGINT NOT NULL, \n\tlease_token UUID, \n\tlease_until TIMESTAMP WITH TIME ZONE, \n\tnext_attempt_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tfirst_execution_run_id UUID, \n\tclosed_reason VARCHAR(32), \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_input_delegation_dispatch_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_input_delegation_dispatch_once UNIQUE (installation_id, application_id, tenant_id, subject_id, delegation_id), \n\tCONSTRAINT uq_input_delegation_dispatch_workflow UNIQUE (installation_id, workflow_id), \n\tCONSTRAINT fk_input_delegation_dispatch_exact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, delegation_id, delegation_digest, task_id) REFERENCES os_input_delegations (installation_id, application_id, tenant_id, subject_id, id, delegation_digest, task_id), \n\tCONSTRAINT ck_input_delegation_dispatch_digest CHECK (delegation_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_input_delegation_dispatch_states CHECK (state IN ('DUE','LEASED','STARTED','CLOSED','POISON') AND version>0 AND attempts BETWEEN 0 AND 8), \n\tCONSTRAINT ck_input_delegation_dispatch_workflow CHECK (workflow_id='os:'||installation_id::text||':'||application_id::text||':'||delegation_id::text), \n\tCONSTRAINT ck_input_delegation_dispatch_lease CHECK ((state='LEASED' AND lease_token IS NOT NULL AND lease_until IS NOT NULL) OR (state<>'LEASED' AND lease_token IS NULL AND lease_until IS NULL)), \n\tCONSTRAINT ck_input_delegation_dispatch_first_run CHECK ((state='STARTED' AND first_execution_run_id IS NOT NULL) OR (state<>'STARTED' AND first_execution_run_id IS NULL)), \n\tCONSTRAINT ck_input_delegation_dispatch_closed CHECK ((state='CLOSED' AND closed_reason IS NOT NULL AND closed_reason IN ('EXPIRED','REVOKED','STOPPED','ALREADY_SETTLED','CURRENT_AUTHORITY_DENIED')) OR (state<>'CLOSED' AND closed_reason IS NULL))\n)\n\n")
    op.execute('CREATE INDEX ix_input_delegation_dispatch_due ON os_input_delegation_dispatches (state, next_attempt_at)')
    op.execute("CREATE TRIGGER immutable_os_input_delegation_dispatch BEFORE UPDATE OR DELETE ON os_input_delegation_dispatches FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','installation_id','application_id','tenant_id','subject_id','delegation_id','delegation_digest','task_id','workflow_id','created_at')")
    op.execute(GUARDS)

def downgrade():
    raise RuntimeError("Destructive downgrade refused; use protected fresh recovery")
