"""New-root resource journal, append-only grants and durable FIFO waits."""
from alembic import op

revision = 'os_pg_0058'
down_revision = 'os_pg_0057'
branch_labels = None
depends_on = None

# Frozen literal DDL is populated from the reviewed metadata before rehearsal.
TABLES = "ALTER TABLE os_budget_roots ADD COLUMN granted jsonb NULL;\nALTER TABLE os_budget_roots DROP CONSTRAINT ck_budget_capacity;\nALTER TABLE os_budget_roots ADD CONSTRAINT ck_budget_capacity CHECK ((accounting_format='legacy-budget/1' AND (state<>'ACTIVE' OR ((spent->>'stages')::numeric + (outstanding->>'stages')::numeric <= (ceiling->>'stages')::numeric AND (spent->>'children')::numeric + (outstanding->>'children')::numeric <= (ceiling->>'children')::numeric AND (spent->>'tokens')::numeric + (outstanding->>'tokens')::numeric <= (ceiling->>'tokens')::numeric AND (spent->>'toolCalls')::numeric + (outstanding->>'toolCalls')::numeric <= (ceiling->>'toolCalls')::numeric AND (spent->>'nativeJobs')::numeric + (outstanding->>'nativeJobs')::numeric <= (ceiling->>'nativeJobs')::numeric AND (spent->>'costMicros')::numeric + (outstanding->>'costMicros')::numeric <= (ceiling->>'costMicros')::numeric AND (spent->>'workMs')::numeric + (outstanding->>'workMs')::numeric <= (ceiling->>'workMs')::numeric AND (spent->>'repairs')::numeric + (outstanding->>'repairs')::numeric <= (ceiling->>'repairs')::numeric AND (spent->>'planRevisions')::numeric + (outstanding->>'planRevisions')::numeric <= (ceiling->>'planRevisions')::numeric))) OR (accounting_format='agent-resources/1' AND ((((ceiling->>'tokens')::numeric + COALESCE((granted->>'tokens')::numeric,0))<=9007199254740991 AND ((ceiling->>'costMicros')::numeric + COALESCE((granted->>'costMicros')::numeric,0))<=9007199254740991 AND ((ceiling->>'workMs')::numeric + COALESCE((granted->>'workMs')::numeric,0))<=9007199254740991 AND ((ceiling->>'computeMs')::numeric + COALESCE((granted->>'computeMs')::numeric,0))<=9007199254740991 AND ((ceiling->>'storageBytes')::numeric + COALESCE((granted->>'storageBytes')::numeric,0))<=9007199254740991) AND (state<>'ACTIVE' OR ((spent->>'tokens')::numeric + (outstanding->>'tokens')::numeric <= ((ceiling->>'tokens')::numeric + COALESCE((granted->>'tokens')::numeric,0)) AND (spent->>'costMicros')::numeric + (outstanding->>'costMicros')::numeric <= ((ceiling->>'costMicros')::numeric + COALESCE((granted->>'costMicros')::numeric,0)) AND (spent->>'workMs')::numeric + (outstanding->>'workMs')::numeric <= ((ceiling->>'workMs')::numeric + COALESCE((granted->>'workMs')::numeric,0)) AND (spent->>'computeMs')::numeric + (outstanding->>'computeMs')::numeric <= ((ceiling->>'computeMs')::numeric + COALESCE((granted->>'computeMs')::numeric,0)) AND (spent->>'storageBytes')::numeric + (outstanding->>'storageBytes')::numeric <= ((ceiling->>'storageBytes')::numeric + COALESCE((granted->>'storageBytes')::numeric,0)))))));\nALTER TABLE os_budget_roots ADD CONSTRAINT ck_budget_grants CHECK ((accounting_format='legacy-budget/1' AND granted IS NULL) OR (accounting_format='agent-resources/1' AND (granted IS NULL OR (jsonb_typeof(granted)='object' AND granted ?& ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] AND granted - ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']='{}'::jsonb AND jsonb_typeof(granted->'tokens')='number' AND (granted->>'tokens') ~ '^(0|[1-9][0-9]*)$' AND (granted->>'tokens')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(granted->'costMicros')='number' AND (granted->>'costMicros') ~ '^(0|[1-9][0-9]*)$' AND (granted->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(granted->'workMs')='number' AND (granted->>'workMs') ~ '^(0|[1-9][0-9]*)$' AND (granted->>'workMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(granted->'computeMs')='number' AND (granted->>'computeMs') ~ '^(0|[1-9][0-9]*)$' AND (granted->>'computeMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(granted->'storageBytes')='number' AND (granted->>'storageBytes') ~ '^(0|[1-9][0-9]*)$' AND (granted->>'storageBytes')::numeric BETWEEN 0 AND 9007199254740991))));\nCREATE TABLE os_agent_resource_accounts (\n\tid UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tapplication_generation BIGINT NOT NULL, \n\tsubject_generation BIGINT NOT NULL, \n\tpolicy_generation BIGINT NOT NULL, \n\tpolicy_ref VARCHAR(256) NOT NULL, \n\tpolicy_revision BIGINT NOT NULL, \n\tpolicy_digest VARCHAR(64) NOT NULL, \n\tpurpose VARCHAR(256) NOT NULL, \n\tprotocol VARCHAR(32) NOT NULL, \n\tpolicy JSONB NOT NULL, \n\tgrant_ceiling JSONB NOT NULL, \n\tgrant_revision BIGINT NOT NULL, \n\tnext_ticket BIGINT NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\thorizon TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_agent_resource_account_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_agent_resource_account_root UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id), \n\tCONSTRAINT uq_agent_resource_account_fence UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT ck_agent_resource_account_version CHECK (protocol='resource-journal/1' AND application_generation>0 AND subject_generation>0 AND policy_generation>0 AND policy_revision>0 AND grant_revision>=0 AND next_ticket>0 AND horizon>created_at), \n\tCONSTRAINT ck_agent_resource_account_policy CHECK (COALESCE(policy=jsonb_build_object('schema','agent-resources/1','limits',policy->'limits','costCurrency',policy->'costCurrency','requestTimeoutMs',policy->'requestTimeoutMs','allowResourceGrants',policy->'allowResourceGrants','exhaustion',policy->'exhaustion') AND jsonb_typeof(policy->'costCurrency')='string' AND policy->>'costCurrency' ~ '^[A-Z]{3}$' AND jsonb_typeof(policy->'requestTimeoutMs')='number' AND policy->>'requestTimeoutMs' ~ '^[1-9][0-9]*$' AND (policy->>'requestTimeoutMs')::numeric BETWEEN 1 AND 900000 AND jsonb_typeof(policy->'allowResourceGrants')='boolean' AND policy->>'exhaustion' IN ('wait','fail') AND (jsonb_typeof((policy->'limits'))='object' AND (policy->'limits') ?& ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] AND (policy->'limits') - ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']='{}'::jsonb AND jsonb_typeof((policy->'limits')->'tokens')='number' AND ((policy->'limits')->>'tokens') ~ '^(0|[1-9][0-9]*)$' AND ((policy->'limits')->>'tokens')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof((policy->'limits')->'costMicros')='number' AND ((policy->'limits')->>'costMicros') ~ '^(0|[1-9][0-9]*)$' AND ((policy->'limits')->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof((policy->'limits')->'workMs')='number' AND ((policy->'limits')->>'workMs') ~ '^(0|[1-9][0-9]*)$' AND ((policy->'limits')->>'workMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof((policy->'limits')->'computeMs')='number' AND ((policy->'limits')->>'computeMs') ~ '^(0|[1-9][0-9]*)$' AND ((policy->'limits')->>'computeMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof((policy->'limits')->'storageBytes')='number' AND ((policy->'limits')->>'storageBytes') ~ '^(0|[1-9][0-9]*)$' AND ((policy->'limits')->>'storageBytes')::numeric BETWEEN 0 AND 9007199254740991),false)), \n\tCONSTRAINT ck_agent_resource_account_ceiling CHECK (jsonb_typeof(grant_ceiling)='object' AND grant_ceiling ?& ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] AND grant_ceiling - ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']='{}'::jsonb AND jsonb_typeof(grant_ceiling->'tokens')='number' AND (grant_ceiling->>'tokens') ~ '^(0|[1-9][0-9]*)$' AND (grant_ceiling->>'tokens')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(grant_ceiling->'costMicros')='number' AND (grant_ceiling->>'costMicros') ~ '^(0|[1-9][0-9]*)$' AND (grant_ceiling->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(grant_ceiling->'workMs')='number' AND (grant_ceiling->>'workMs') ~ '^(0|[1-9][0-9]*)$' AND (grant_ceiling->>'workMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(grant_ceiling->'computeMs')='number' AND (grant_ceiling->>'computeMs') ~ '^(0|[1-9][0-9]*)$' AND (grant_ceiling->>'computeMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(grant_ceiling->'storageBytes')='number' AND (grant_ceiling->>'storageBytes') ~ '^(0|[1-9][0-9]*)$' AND (grant_ceiling->>'storageBytes')::numeric BETWEEN 0 AND 9007199254740991), \n\tCONSTRAINT ck_agent_resource_policy_digest CHECK (policy_digest ~ '^[a-f0-9]{64}$')\n);\nCREATE UNIQUE INDEX ix_agent_resource_root ON os_agent_resource_accounts (root_id);\nCREATE TABLE os_agent_resource_grants (\n\tid UUID NOT NULL, \n\taccount_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\trevision BIGINT NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\tresources JSONB NOT NULL, \n\treceipt JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_agent_resource_grant_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_agent_grant_account FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, account_id, root_id) REFERENCES os_agent_resource_accounts (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT uq_agent_resource_grant_fence UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT uq_agent_resource_grant_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id, revision), \n\tCONSTRAINT uq_agent_resource_grant_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT ck_agent_resource_grant_version CHECK (control_epoch>0 AND revision>0), \n\tCONSTRAINT ck_agent_resource_grant_resources CHECK (jsonb_typeof(resources)='object' AND resources ?& ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] AND resources - ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']='{}'::jsonb AND jsonb_typeof(resources->'tokens')='number' AND (resources->>'tokens') ~ '^(0|[1-9][0-9]*)$' AND (resources->>'tokens')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(resources->'costMicros')='number' AND (resources->>'costMicros') ~ '^(0|[1-9][0-9]*)$' AND (resources->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(resources->'workMs')='number' AND (resources->>'workMs') ~ '^(0|[1-9][0-9]*)$' AND (resources->>'workMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(resources->'computeMs')='number' AND (resources->>'computeMs') ~ '^(0|[1-9][0-9]*)$' AND (resources->>'computeMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(resources->'storageBytes')='number' AND (resources->>'storageBytes') ~ '^(0|[1-9][0-9]*)$' AND (resources->>'storageBytes')::numeric BETWEEN 0 AND 9007199254740991), \n\tCONSTRAINT ck_agent_resource_grant_receipt CHECK (jsonb_typeof(receipt)='object'), \n\tCONSTRAINT ck_agent_resource_grant_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n);\nCREATE UNIQUE INDEX ix_agent_grant_root_revision ON os_agent_resource_grants (root_id, revision);\nCREATE TABLE os_agent_accounting_moves (\n\tid UUID NOT NULL, \n\taccount_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tattempt_id UUID, \n\tattempt_version BIGINT, \n\tgrant_id UUID, \n\troot_version BIGINT NOT NULL, \n\tkind VARCHAR(16) NOT NULL, \n\treserved JSONB NOT NULL, \n\treleased JSONB NOT NULL, \n\tmeasured JSONB NOT NULL, \n\tadded JSONB NOT NULL, \n\tapplied BOOLEAN DEFAULT false NOT NULL, \n\tobserved BOOLEAN DEFAULT false NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_agent_accounting_move_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_agent_move_account FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, account_id, root_id) REFERENCES os_agent_resource_accounts (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT fk_agent_move_attempt FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id) DEFERRABLE INITIALLY DEFERRED, \n\tCONSTRAINT fk_agent_move_grant FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, grant_id, root_id) REFERENCES os_agent_resource_grants (installation_id, application_id, tenant_id, subject_id, id, root_id) DEFERRABLE INITIALLY DEFERRED, \n\tCONSTRAINT uq_agent_move_root_version UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id, root_version), \n\tCONSTRAINT uq_agent_move_attempt_version UNIQUE (installation_id, application_id, tenant_id, subject_id, attempt_id, attempt_version), \n\tCONSTRAINT uq_agent_move_grant UNIQUE (installation_id, application_id, tenant_id, subject_id, grant_id), \n\tCONSTRAINT ck_agent_move_binding CHECK (root_version>1 AND ((kind IN ('reserve','settle','unknown','release') AND attempt_id IS NOT NULL AND attempt_version IS NOT NULL AND attempt_version>0 AND grant_id IS NULL) OR (kind='grant' AND grant_id IS NOT NULL AND attempt_id IS NULL AND attempt_version IS NULL))), \n\tCONSTRAINT ck_agent_move_reserved CHECK (jsonb_typeof(reserved)='object' AND reserved ?& ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] AND reserved - ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']='{}'::jsonb AND jsonb_typeof(reserved->'tokens')='number' AND (reserved->>'tokens') ~ '^(0|[1-9][0-9]*)$' AND (reserved->>'tokens')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(reserved->'costMicros')='number' AND (reserved->>'costMicros') ~ '^(0|[1-9][0-9]*)$' AND (reserved->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(reserved->'workMs')='number' AND (reserved->>'workMs') ~ '^(0|[1-9][0-9]*)$' AND (reserved->>'workMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(reserved->'computeMs')='number' AND (reserved->>'computeMs') ~ '^(0|[1-9][0-9]*)$' AND (reserved->>'computeMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(reserved->'storageBytes')='number' AND (reserved->>'storageBytes') ~ '^(0|[1-9][0-9]*)$' AND (reserved->>'storageBytes')::numeric BETWEEN 0 AND 9007199254740991), \n\tCONSTRAINT ck_agent_move_released CHECK (jsonb_typeof(released)='object' AND released ?& ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] AND released - ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']='{}'::jsonb AND jsonb_typeof(released->'tokens')='number' AND (released->>'tokens') ~ '^(0|[1-9][0-9]*)$' AND (released->>'tokens')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(released->'costMicros')='number' AND (released->>'costMicros') ~ '^(0|[1-9][0-9]*)$' AND (released->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(released->'workMs')='number' AND (released->>'workMs') ~ '^(0|[1-9][0-9]*)$' AND (released->>'workMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(released->'computeMs')='number' AND (released->>'computeMs') ~ '^(0|[1-9][0-9]*)$' AND (released->>'computeMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(released->'storageBytes')='number' AND (released->>'storageBytes') ~ '^(0|[1-9][0-9]*)$' AND (released->>'storageBytes')::numeric BETWEEN 0 AND 9007199254740991), \n\tCONSTRAINT ck_agent_move_measured CHECK (jsonb_typeof(measured)='object' AND measured ?& ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] AND measured - ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']='{}'::jsonb AND jsonb_typeof(measured->'tokens')='number' AND (measured->>'tokens') ~ '^(0|[1-9][0-9]*)$' AND (measured->>'tokens')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(measured->'costMicros')='number' AND (measured->>'costMicros') ~ '^(0|[1-9][0-9]*)$' AND (measured->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(measured->'workMs')='number' AND (measured->>'workMs') ~ '^(0|[1-9][0-9]*)$' AND (measured->>'workMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(measured->'computeMs')='number' AND (measured->>'computeMs') ~ '^(0|[1-9][0-9]*)$' AND (measured->>'computeMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(measured->'storageBytes')='number' AND (measured->>'storageBytes') ~ '^(0|[1-9][0-9]*)$' AND (measured->>'storageBytes')::numeric BETWEEN 0 AND 9007199254740991), \n\tCONSTRAINT ck_agent_move_added CHECK (jsonb_typeof(added)='object' AND added ?& ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] AND added - ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']='{}'::jsonb AND jsonb_typeof(added->'tokens')='number' AND (added->>'tokens') ~ '^(0|[1-9][0-9]*)$' AND (added->>'tokens')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(added->'costMicros')='number' AND (added->>'costMicros') ~ '^(0|[1-9][0-9]*)$' AND (added->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(added->'workMs')='number' AND (added->>'workMs') ~ '^(0|[1-9][0-9]*)$' AND (added->>'workMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(added->'computeMs')='number' AND (added->>'computeMs') ~ '^(0|[1-9][0-9]*)$' AND (added->>'computeMs')::numeric BETWEEN 0 AND 9007199254740991 AND jsonb_typeof(added->'storageBytes')='number' AND (added->>'storageBytes') ~ '^(0|[1-9][0-9]*)$' AND (added->>'storageBytes')::numeric BETWEEN 0 AND 9007199254740991)\n);\nCREATE UNIQUE INDEX ix_agent_move_attempt_version ON os_agent_accounting_moves (attempt_id, attempt_version);\nCREATE UNIQUE INDEX ix_agent_move_grant ON os_agent_accounting_moves (grant_id);\nCREATE UNIQUE INDEX ix_agent_move_root_version ON os_agent_accounting_moves (root_id, root_version);\nCREATE TABLE os_agent_resource_waits (\n\tid UUID NOT NULL, \n\taccount_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\tticket BIGINT NOT NULL, \n\tinvocation_id UUID NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\trequest JSONB NOT NULL, \n\tstate VARCHAR(16) NOT NULL, \n\tattempt_id UUID, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_agent_resource_wait_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_agent_wait_account FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, account_id, root_id) REFERENCES os_agent_resource_accounts (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT fk_agent_wait_task FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id, root_id) REFERENCES os_workload_bindings (installation_id, application_id, tenant_id, subject_id, task_id, root_id), \n\tCONSTRAINT fk_agent_wait_segment FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, segment_id, task_id) REFERENCES os_segments (installation_id, application_id, tenant_id, subject_id, id, task_id), \n\tCONSTRAINT fk_agent_wait_attempt FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id, task_id, segment_id, root_id, control_epoch, invocation_id, request_digest) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, root_id, control_epoch, invocation_id, request_digest) DEFERRABLE INITIALLY DEFERRED, \n\tCONSTRAINT uq_agent_wait_ticket UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id, ticket), \n\tCONSTRAINT uq_agent_wait_invocation UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id, invocation_id), \n\tCONSTRAINT ck_agent_wait_state CHECK (ticket>0 AND control_epoch>0 AND state IN ('WAITING','ADMITTED','CANCELLED','EXPIRED') AND (state='ADMITTED')=(attempt_id IS NOT NULL)), \n\tCONSTRAINT ck_agent_wait_request CHECK (jsonb_typeof(request)='object'), \n\tCONSTRAINT ck_agent_resource_wait_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n);\nCREATE INDEX ix_agent_wait_pending ON os_agent_resource_waits (root_id, ticket) WHERE state='WAITING';\nCREATE UNIQUE INDEX ix_agent_wait_root_ticket ON os_agent_resource_waits (root_id, ticket);\nCREATE INDEX ix_attempt_root ON os_work_attempts (root_id);"

GUARDS = r"""
CREATE FUNCTION os_agent_resource_canonical(v jsonb) RETURNS text LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE result text;
BEGIN
 IF jsonb_typeof(v)='object' THEN
  SELECT '{'||COALESCE(string_agg(to_jsonb(key)::text||':'||os_agent_resource_canonical(value),',' ORDER BY key COLLATE "C"),'')||'}'
   INTO result FROM jsonb_each(v);
  RETURN result;
 END IF;
 IF jsonb_typeof(v)='array' THEN RAISE EXCEPTION 'agent_resource_canonical_array'; END IF;
 IF jsonb_typeof(v)='number' AND (v::text !~ '^(0|[1-9][0-9]*)$' OR v::numeric>9007199254740991)
  THEN RAISE EXCEPTION 'agent_resource_canonical_number'; END IF;
 RETURN v::text;
END $$;

CREATE FUNCTION os_agent_resource_digest(purpose text,v jsonb) RETURNS text LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
 IF purpose NOT IN ('command','policy') THEN RAISE EXCEPTION 'agent_resource_hash_purpose'; END IF;
 RETURN encode(sha256(convert_to('agentic-os.hash/1','UTF8')||decode('00','hex')||convert_to(purpose,'UTF8')||decode('00','hex')||convert_to(os_agent_resource_canonical(v),'UTF8')),'hex');
END $$;

CREATE FUNCTION os_agent_resource_owner(a os_agent_resource_accounts) RETURNS void LANGUAGE plpgsql AS $$
DECLARE app os_applications%ROWTYPE; owner_row os_subjects%ROWTYPE; s os_interactive_sessions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO app FROM os_applications WHERE installation_id=a.installation_id AND id=a.application_id FOR SHARE;
 SELECT * INTO owner_row FROM os_subjects WHERE installation_id=a.installation_id AND application_id=a.application_id
  AND tenant_id=a.tenant_id AND subject_id=a.subject_id FOR SHARE;
 SELECT * INTO s FROM os_interactive_sessions WHERE id=a.session_id FOR SHARE;
 IF app.id IS NULL OR NOT app.active OR app.generation<>a.application_generation
  OR owner_row.id IS NULL OR NOT owner_row.active OR owner_row.generation<>a.subject_generation
  OR owner_row.host_policy_generation<>a.policy_generation OR s.id IS NULL OR s.revoked
  OR s.expires_at<=clock_timestamp() OR s.application_generation<>a.application_generation
  OR s.subject_generation<>a.subject_generation
  OR a.horizon>s.expires_at
  OR ROW(s.installation_id,s.application_id,s.tenant_id,s.subject_id)
   IS DISTINCT FROM ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  THEN RAISE EXCEPTION 'agent_resource_owner_not_current'; END IF;
END $$;

CREATE FUNCTION os_guard_agent_resource_account() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; d os_admissions%ROWTYPE; k text;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_resource_account_immutable'; END IF;
 IF TG_OP='UPDATE' THEN
  IF (to_jsonb(NEW)-ARRAY['grant_revision','next_ticket']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['grant_revision','next_ticket'])
   OR NOT ((NEW.grant_revision=OLD.grant_revision+1 AND NEW.next_ticket=OLD.next_ticket)
     OR (NEW.grant_revision=OLD.grant_revision AND NEW.next_ticket=OLD.next_ticket+1))
   THEN RAISE EXCEPTION 'agent_resource_account_immutable'; END IF;
  RETURN NEW;
 END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 IF r.id IS NULL OR r.accounting_format<>'agent-resources/1' OR r.version<>1 OR r.state<>'ACTIVE'
  OR r.deadline<=clock_timestamp() OR NEW.horizon<>r.deadline OR NEW.created_at>clock_timestamp()
  OR NEW.grant_revision<>0 OR NEW.next_ticket<>1 OR NEW.policy->'limits'<>r.ceiling
  OR NEW.policy_digest<>os_agent_resource_digest('policy',NEW.policy)
  OR (d.authority->>'sessionId') IS DISTINCT FROM NEW.session_id::text
  OR (d.authority->>'applicationGeneration') IS DISTINCT FROM NEW.application_generation::text
  OR (d.authority->>'subjectGeneration') IS DISTINCT FROM NEW.subject_generation::text
  OR (d.authority->>'policyGeneration') IS DISTINCT FROM NEW.policy_generation::text
  OR EXISTS(SELECT 1 FROM os_work_attempts WHERE root_id=r.id)
  THEN RAISE EXCEPTION 'agent_resource_new_root_binding'; END IF;
 PERFORM os_agent_resource_owner(NEW);
 FOREACH k IN ARRAY ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] LOOP
  IF (r.spent->>k)::numeric<>0 OR (r.outstanding->>k)::numeric<>0 OR COALESCE((r.granted->>k)::numeric,0)<>0
   OR (NEW.grant_ceiling->>k)::numeric<(r.ceiling->>k)::numeric
   OR (NEW.policy->>'allowResourceGrants'='false' AND (NEW.grant_ceiling->>k)::numeric<>(r.ceiling->>k)::numeric)
   THEN RAISE EXCEPTION 'agent_resource_initial_resources'; END IF;
 END LOOP;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_resource_account BEFORE INSERT OR UPDATE OR DELETE ON os_agent_resource_accounts
FOR EACH ROW EXECUTE FUNCTION os_guard_agent_resource_account();

CREATE FUNCTION os_guard_agent_resource_cursors() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_resource_accounts%ROWTYPE;
BEGIN
 SELECT * INTO a FROM os_agent_resource_accounts WHERE id=NEW.id;
 IF (a.grant_revision>0 AND NOT EXISTS(SELECT 1 FROM os_agent_resource_grants g WHERE g.root_id=a.root_id AND g.account_id=a.id AND g.revision=a.grant_revision))
  OR (a.next_ticket>1 AND NOT EXISTS(SELECT 1 FROM os_agent_resource_waits w WHERE w.root_id=a.root_id AND w.ticket=a.next_ticket-1))
  THEN RAISE EXCEPTION 'agent_resource_cursor_without_event'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_agent_resource_cursors AFTER INSERT OR UPDATE ON os_agent_resource_accounts
DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_agent_resource_cursors();

CREATE FUNCTION os_guard_agent_move() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_move_immutable'; END IF;
 IF TG_OP='INSERT' THEN
  PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
  SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
  IF r.id IS NULL OR NEW.root_version<>r.version+1 OR NEW.applied OR NEW.observed
   THEN RAISE EXCEPTION 'agent_move_initial'; END IF;
 ELSE
  IF pg_trigger_depth()<>2
   OR (to_jsonb(NEW)-ARRAY['applied','observed']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['applied','observed'])
   OR NOT ((NOT OLD.applied AND NEW.applied AND NEW.observed=OLD.observed)
       OR (NOT OLD.observed AND NEW.observed AND NEW.applied=OLD.applied))
   THEN RAISE EXCEPTION 'agent_move_immutable'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_move BEFORE INSERT OR UPDATE OR DELETE ON os_agent_accounting_moves
FOR EACH ROW EXECUTE FUNCTION os_guard_agent_move();

CREATE FUNCTION os_guard_agent_move_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE m os_agent_accounting_moves%ROWTYPE;
BEGIN
 SELECT * INTO m FROM os_agent_accounting_moves WHERE id=NEW.id;
 IF NOT m.applied OR NOT m.observed THEN RAISE EXCEPTION 'agent_move_unpaired'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_agent_move AFTER INSERT OR UPDATE ON os_agent_accounting_moves
DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_agent_move_commit();

CREATE FUNCTION os_guard_agent_root_movement() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_resource_accounts%ROWTYPE; m os_agent_accounting_moves%ROWTYPE; k text;
BEGIN
 IF NEW.accounting_format<>'agent-resources/1' THEN RETURN NEW; END IF;
 SELECT * INTO a FROM os_agent_resource_accounts WHERE root_id=NEW.id;
 IF TG_OP='INSERT' THEN
  IF NEW.granted IS NOT NULL THEN
   FOREACH k IN ARRAY ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] LOOP
    IF (NEW.granted->>k)::numeric<>0 THEN RAISE EXCEPTION 'agent_root_initial_grant'; END IF;
   END LOOP;
  END IF;
  RETURN NEW;
 END IF;
 IF a.id IS NULL THEN
  IF NEW.granted IS DISTINCT FROM OLD.granted THEN RAISE EXCEPTION 'agent_old_root_grant'; END IF;
  RETURN NEW;
 END IF;
 SELECT * INTO m FROM os_agent_accounting_moves WHERE root_id=NEW.id AND root_version=NEW.version;
 IF m.id IS NULL THEN
  IF NEW.spent IS DISTINCT FROM OLD.spent OR NEW.outstanding IS DISTINCT FROM OLD.outstanding OR NEW.granted IS DISTINCT FROM OLD.granted
   THEN RAISE EXCEPTION 'agent_root_movement_missing'; END IF;
  RETURN NEW;
 END IF;
 IF m.account_id<>a.id OR m.applied THEN RAISE EXCEPTION 'agent_root_movement_binding'; END IF;
 FOREACH k IN ARRAY ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] LOOP
  IF (NEW.spent->>k)::numeric<>(OLD.spent->>k)::numeric+(m.measured->>k)::numeric
   OR (NEW.outstanding->>k)::numeric<>(OLD.outstanding->>k)::numeric+(m.reserved->>k)::numeric-(m.released->>k)::numeric
   OR COALESCE((NEW.granted->>k)::numeric,0)<>COALESCE((OLD.granted->>k)::numeric,0)+(m.added->>k)::numeric
   THEN RAISE EXCEPTION 'agent_root_movement_delta'; END IF;
 END LOOP;
 UPDATE os_agent_accounting_moves SET applied=true WHERE id=m.id;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_root_movement BEFORE INSERT OR UPDATE ON os_budget_roots
FOR EACH ROW EXECUTE FUNCTION os_guard_agent_root_movement();

CREATE FUNCTION os_observe_agent_attempt_movement() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_resource_accounts%ROWTYPE; m os_agent_accounting_moves%ROWTYPE; h os_agent_resource_waits%ROWTYPE; k text; wanted text;
BEGIN
 IF NEW.accounting_format<>'agent-resources/1' THEN RETURN NEW; END IF;
 SELECT * INTO a FROM os_agent_resource_accounts WHERE root_id=NEW.root_id;
 IF a.id IS NULL THEN RETURN NEW; END IF;
 IF TG_OP='INSERT' OR NEW.state='RUNNING' THEN
  PERFORM os_agent_resource_owner(a);
  IF (NEW.reserved->>'workMs')::numeric<1 OR NEW.lease_until>NEW.created_at+((a.policy->>'requestTimeoutMs')::bigint*interval '1 millisecond')
   THEN RAISE EXCEPTION 'agent_operation_policy'; END IF;
 END IF;
 IF NEW.state='RUNNING' THEN RETURN NEW; END IF;
 wanted=CASE NEW.state WHEN 'RESERVED' THEN 'reserve' WHEN 'SETTLED' THEN 'settle' WHEN 'UNKNOWN' THEN 'unknown' WHEN 'RELEASED' THEN 'release' END;
 SELECT * INTO m FROM os_agent_accounting_moves WHERE attempt_id=NEW.id AND attempt_version=NEW.version;
 IF m.id IS NULL OR m.root_id<>NEW.root_id OR m.account_id<>a.id OR m.kind<>wanted OR m.observed
  THEN RAISE EXCEPTION 'agent_attempt_movement_binding'; END IF;
 FOREACH k IN ARRAY ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] LOOP
  IF (m.reserved->>k)::numeric<>(CASE WHEN wanted='reserve' THEN (NEW.reserved->>k)::numeric ELSE 0 END)
   OR (m.released->>k)::numeric<>(CASE WHEN wanted IN ('settle','release') THEN (NEW.reserved->>k)::numeric ELSE 0 END)
   OR (m.measured->>k)::numeric<>(CASE WHEN wanted='settle' THEN (NEW.actual->>k)::numeric ELSE 0 END)
   OR (m.added->>k)::numeric<>0 THEN RAISE EXCEPTION 'agent_attempt_movement_delta'; END IF;
 END LOOP;
 IF TG_OP='INSERT' THEN
  SELECT * INTO h FROM os_agent_resource_waits WHERE root_id=NEW.root_id AND state='WAITING' ORDER BY ticket LIMIT 1;
  IF h.id IS NOT NULL AND (h.task_id<>NEW.task_id OR h.invocation_id<>NEW.invocation_id OR h.request_digest<>NEW.request_digest)
   THEN RAISE EXCEPTION 'agent_wait_fifo'; END IF;
 END IF;
 UPDATE os_agent_accounting_moves SET observed=true WHERE id=m.id;
 RETURN NEW;
END $$;
CREATE TRIGGER observe_agent_attempt_movement AFTER INSERT OR UPDATE ON os_work_attempts
FOR EACH ROW EXECUTE FUNCTION os_observe_agent_attempt_movement();

CREATE FUNCTION os_guard_agent_resource_grant() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE; c os_task_controls%ROWTYPE; m os_agent_accounting_moves%ROWTYPE; k text; total numeric;
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_resource_grant_immutable'; END IF;
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_agent_resource_accounts WHERE id=NEW.account_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id;
 SELECT * INTO c FROM os_task_controls WHERE task_id=r.root_task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 PERFORM os_agent_resource_owner(a);
 IF a.id IS NULL OR a.root_id<>r.id OR a.policy->>'allowResourceGrants'<>'true'
  OR a.session_id<>NEW.session_id OR r.state<>'ACTIVE' OR r.deadline<=clock_timestamp()
  OR c.id IS NULL OR c.state<>'ACTIVE' OR c.epoch<>NEW.control_epoch
  OR NEW.created_at>=r.deadline
  OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=r.root_task_id AND deadline>clock_timestamp()
                AND state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
  THEN RAISE EXCEPTION 'agent_resource_grant_not_current'; END IF;
 IF a.grant_revision<>NEW.revision THEN RAISE EXCEPTION 'agent_resource_grant_revision'; END IF;
 IF NEW.created_at>clock_timestamp() THEN RAISE EXCEPTION 'agent_resource_grant_clock'; END IF;
 IF NEW.request_digest<>os_agent_resource_digest('command',jsonb_build_object('schema','agent-resource-grant/1',
     'commandId',NEW.command_id::text,'rootId',r.id::text,'controlEpoch',NEW.control_epoch,'expectedGrantRevision',NEW.revision-1,'resources',NEW.resources))
  THEN RAISE EXCEPTION 'agent_resource_grant_digest'; END IF;
 SELECT * INTO m FROM os_agent_accounting_moves WHERE grant_id=NEW.id;
 IF m.id IS NULL OR m.account_id<>a.id OR m.root_id<>r.id OR m.kind<>'grant' OR m.observed
  OR NEW.receipt IS DISTINCT FROM jsonb_build_object('commandId',NEW.command_id::text,'grantId',NEW.id::text,
   'rootId',r.id::text,'grantRevision',NEW.revision,'resources',NEW.resources,'granted',r.granted,
   'authorizedTotal',NEW.receipt->'authorizedTotal','costCurrency',a.policy->>'costCurrency','authorizationHorizon',NEW.receipt->'authorizationHorizon')
  OR (NEW.receipt->>'authorizationHorizon')::timestamptz IS DISTINCT FROM r.deadline
  THEN RAISE EXCEPTION 'agent_resource_grant_receipt'; END IF;
 total=0;
 FOREACH k IN ARRAY ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] LOOP
  IF (m.added->>k)::numeric<>(NEW.resources->>k)::numeric OR (m.reserved->>k)::numeric<>0
   OR (m.released->>k)::numeric<>0 OR (m.measured->>k)::numeric<>0
   OR (r.ceiling->>k)::numeric+COALESCE((r.granted->>k)::numeric,0)>(a.grant_ceiling->>k)::numeric
   OR (NEW.receipt->'authorizedTotal'->>k)::numeric IS DISTINCT FROM (r.ceiling->>k)::numeric+COALESCE((r.granted->>k)::numeric,0)
   THEN RAISE EXCEPTION 'agent_resource_grant_ceiling'; END IF;
  total=total+(NEW.resources->>k)::numeric;
 END LOOP;
 IF total=0 THEN RAISE EXCEPTION 'agent_resource_empty_grant'; END IF;
 IF (NEW.receipt->'authorizedTotal')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
  THEN RAISE EXCEPTION 'agent_resource_grant_receipt'; END IF;
 UPDATE os_agent_accounting_moves SET observed=true WHERE id=m.id;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_resource_grant BEFORE INSERT OR UPDATE OR DELETE ON os_agent_resource_grants
FOR EACH ROW EXECUTE FUNCTION os_guard_agent_resource_grant();

CREATE FUNCTION os_guard_agent_resource_wait() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_resource_accounts%ROWTYPE; w os_work_attempts%ROWTYPE; r os_budget_roots%ROWTYPE; k text; expected jsonb;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_resource_wait_immutable'; END IF;
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-ARRAY['state','attempt_id']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','attempt_id'])
   THEN RAISE EXCEPTION 'agent_resource_wait_transition'; END IF;
  IF NEW.state='ADMITTED' AND EXISTS(SELECT 1 FROM os_agent_resource_waits WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
   THEN RAISE EXCEPTION 'agent_wait_fifo'; END IF;
  RETURN NEW;
 END IF;
 SELECT * INTO a FROM os_agent_resource_accounts WHERE id=NEW.account_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 PERFORM os_agent_resource_owner(a);
 expected=jsonb_build_object('invocationId',NEW.invocation_id::text,'taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,
  'controlEpoch',NEW.control_epoch,'kind',NEW.request->'kind','inputDigest',NEW.request->'inputDigest','units',NEW.request->'units','timeoutMs',NEW.request->'timeoutMs');
 IF a.id IS NULL OR a.root_id<>NEW.root_id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR a.policy->>'exhaustion'<>'wait' OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline
  OR NEW.request IS DISTINCT FROM expected OR (NEW.request->>'inputDigest') !~ '^[a-f0-9]{64}$'
  OR jsonb_typeof(NEW.request->'inputDigest') IS DISTINCT FROM 'string'
  OR jsonb_typeof(NEW.request->'kind') IS DISTINCT FROM 'string'
  OR jsonb_typeof(NEW.request->'timeoutMs') IS DISTINCT FROM 'number'
  OR jsonb_typeof(NEW.request->'units') IS DISTINCT FROM 'object'
  OR NEW.request->>'kind' NOT IN ('agent.model','agent.tool','agent.compute','agent.child','agent.prepare','agent.review','agent.effect','agent.memory','agent.native','agent.schedule','agent.storage','agent.repair')
  OR (NEW.request->>'timeoutMs') !~ '^[1-9][0-9]*$'
  OR (NEW.request->>'timeoutMs')::numeric>(a.policy->>'requestTimeoutMs')::numeric
  OR NEW.request_digest<>os_agent_resource_digest('command',(NEW.request-'controlEpoch')||jsonb_build_object('schema','agent-resource-reservation/1','epoch',NEW.control_epoch))
  THEN RAISE EXCEPTION 'agent_resource_wait_request'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
 PERFORM os_assert_agent_work_current(w);
 FOREACH k IN ARRAY ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] LOOP
  IF jsonb_typeof(NEW.request->'units'->k) IS DISTINCT FROM 'number' OR (NEW.request->'units'->>k) !~ '^(0|[1-9][0-9]*)$'
   OR (NEW.request->'units'->>k)::numeric+(r.spent->>k)::numeric>(a.grant_ceiling->>k)::numeric
   THEN RAISE EXCEPTION 'agent_resource_wait_impossible'; END IF;
 END LOOP;
 IF (NEW.request->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb OR (NEW.request->'units'->>'workMs')::numeric<1
  THEN RAISE EXCEPTION 'agent_resource_wait_units'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_resource_wait BEFORE INSERT OR UPDATE OR DELETE ON os_agent_resource_waits
FOR EACH ROW EXECUTE FUNCTION os_guard_agent_resource_wait();

CREATE OR REPLACE FUNCTION os_assert_agent_accounting(rid uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; a os_agent_resource_accounts%ROWTYPE; k text; measured numeric; pending numeric;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO r FROM os_budget_roots WHERE id=rid FOR UPDATE;
 IF r.id IS NULL OR r.accounting_format<>'agent-resources/1' THEN RETURN; END IF;
 IF NOT EXISTS(SELECT 1 FROM os_workload_bindings WHERE task_id=r.root_task_id AND root_id=r.id AND parent_task_id IS NULL)
  THEN RAISE EXCEPTION 'agent_root_binding'; END IF;
 SELECT * INTO a FROM os_agent_resource_accounts WHERE root_id=r.id;
 IF a.id IS NOT NULL THEN
  IF a.horizon<>r.deadline OR a.policy->'limits'<>r.ceiling THEN RAISE EXCEPTION 'agent_root_policy_drift'; END IF;
  IF r.state='CLOSED' THEN
   FOREACH k IN ARRAY ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] LOOP
    IF (r.outstanding->>k)::numeric<>0 THEN RAISE EXCEPTION 'agent_root_unresolved'; END IF;
   END LOOP;
  END IF;
  RETURN;
 END IF;
 FOREACH k IN ARRAY ARRAY['tokens','costMicros','workMs','computeMs','storageBytes'] LOOP
  SELECT COALESCE(sum((actual->>k)::numeric) FILTER (WHERE state='SETTLED'),0),
    COALESCE(sum((reserved->>k)::numeric) FILTER (WHERE state IN ('RESERVED','RUNNING','UNKNOWN')),0)
   INTO measured,pending FROM os_work_attempts WHERE root_id=r.id;
  IF (r.spent->>k)::numeric<>measured OR (r.outstanding->>k)::numeric<>pending
   THEN RAISE EXCEPTION 'agent_root_conservation'; END IF;
  IF r.state='CLOSED' AND pending<>0 THEN RAISE EXCEPTION 'agent_root_unresolved'; END IF;
 END LOOP;
END $$;
"""


def upgrade():
    op.execute(TABLES)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Resource journal changes require protected forward recovery')
