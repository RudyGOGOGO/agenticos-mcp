"""Draft native analysis on original production resources and private inputs.

Unapplied. Protected runtime, negative guards, catalog/metadata, populated
rollback/forward and independent0082 recovery are required before freezing.
"""
from alembic import op

revision='os_pg_0083'
down_revision='os_pg_0082'
branch_labels=None
depends_on=None

HELPERS=r"""
CREATE FUNCTION os_native_analysis_limits(p jsonb) RETURNS boolean LANGUAGE sql IMMUTABLE AS $$
 SELECT COALESCE(p=jsonb_build_object('cpus',1,'memoryMiB',1024,'rootDiskMiB',512,'temporaryMiB',8,
  'maxInputBytes',p->'maxInputBytes','maxOutputBytes',p->'maxOutputBytes','timeoutMs',p->'timeoutMs',
  'network','none','modelAccess',false,'hostAccess',false)
  AND jsonb_typeof(p->'maxInputBytes')='number' AND p->>'maxInputBytes' ~ '^[1-9][0-9]*$'
  AND (p->>'maxInputBytes')::numeric<=4194304
  AND jsonb_typeof(p->'maxOutputBytes')='number' AND p->>'maxOutputBytes' ~ '^[1-9][0-9]*$'
  AND (p->>'maxOutputBytes')::numeric<=8388608
  AND jsonb_typeof(p->'timeoutMs')='number' AND p->>'timeoutMs' ~ '^[1-9][0-9]*$'
  AND (p->>'timeoutMs')::numeric<=30000,false)
$$;


CREATE FUNCTION os_native_analysis_cost(m jsonb,compute_ms bigint,allocated boolean) RETURNS bigint LANGUAGE sql IMMUTABLE AS $$
 SELECT (CASE WHEN allocated THEN (m->>'baseMicros')::numeric ELSE 0 END
  +ceil((m->>'microsPerMillionComputeMs')::numeric*compute_ms/1000000))::bigint
$$;

CREATE FUNCTION os_native_analysis_meter(m jsonb,timeout_ms bigint) RETURNS boolean LANGUAGE sql IMMUTABLE AS $$
 SELECT COALESCE(m=jsonb_build_object('id',m->'id','revision',m->'revision','currency','USD',
  'baseMicros',m->'baseMicros','microsPerMillionComputeMs',m->'microsPerMillionComputeMs')
  AND m->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND jsonb_typeof(m->'revision')='number' AND m->>'revision' ~ '^[1-9][0-9]*$' AND (m->>'revision')::numeric<=9007199254740991
  AND jsonb_typeof(m->'baseMicros')='number' AND m->>'baseMicros' ~ '^(0|[1-9][0-9]*)$' AND (m->>'baseMicros')::numeric<=9007199254740991
  AND jsonb_typeof(m->'microsPerMillionComputeMs')='number' AND m->>'microsPerMillionComputeMs' ~ '^(0|[1-9][0-9]*)$'
  AND (m->>'microsPerMillionComputeMs')::numeric<=9007199254740991
  AND os_native_analysis_cost(m,timeout_ms,true) BETWEEN 0 AND 9007199254740991,false)
$$;

CREATE FUNCTION os_native_analysis_payload(fid uuid,expected text,c jsonb,reference jsonb,before_at timestamptz)
RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT COALESCE(EXISTS(SELECT 1 FROM os_agent_private_payloads f
  JOIN os_agent_payload_writes p ON p.id=f.write_id
  WHERE f.id=fid AND os_query_source_payload(p.id,expected,c,before_at)
   AND reference=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,
    'bytes',p.plain_bytes,'schemaRef',expected,'schemaVersion',1)),false)
$$;
"""

NATIVE_GUARDS=r"""
CREATE FUNCTION os_assert_agent_native_current(o os_agent_native_operations) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; a os_admissions%ROWTYPE; q os_agent_resource_accounts%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; app os_applications%ROWTYPE; cap os_agent_capabilities%ROWTYPE;
 parent os_agent_operations%ROWTYPE;
 c jsonb; b jsonb; i jsonb; limits jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=o.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN(o.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=o.root_id))
  ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=o.root_id FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=o.installation_id AND id=o.application_id;
 SELECT * INTO parent FROM os_agent_operations WHERE id=o.parent_operation_id;
 b:=o.payload;c:=b->'context';i:=b->'identity';limits:=b->'limits';
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND policy_digest=b->'profile'->>'digest';
 SELECT * INTO cap FROM os_agent_capabilities WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND application_generation=app.generation AND capability_ref=b->'capability'->>'ref' ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(r.state='ACTIVE' AND r.accounting_format='agent-resources/1' AND r.deadline>clock_timestamp()
  AND ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
  AND c=a.context AND o.task_id=r.root_task_id AND o.digest=os_agent_profile_digest('command',o.payload)
  AND b=jsonb_build_object('context',c,'identity',i,'binding',b->'binding','modelOperationId',o.parent_operation_id,
   'modelResult',b->'modelResult','capability',b->'capability','profile',b->'profile','inputs',b->'inputs',
   'programDigest',b->'programDigest','inputDigest',b->'inputDigest','runtime',b->'runtime','limits',limits,'meter',b->'meter')
  AND i=jsonb_build_object('operationId',o.id,'taskId',o.task_id,'rootId',o.root_id,'segmentId',a.segment_id,
   'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch',
   'planRevision',parent.payload->'identity'->'planRevision','parentOperationId',o.parent_operation_id,
   'iteration',parent.payload->'identity'->'iteration','kind','tool','inputDigest',i->'inputDigest')
  AND i->>'inputDigest' ~ '^[a-f0-9]{64}$' AND b->>'programDigest' ~ '^[a-f0-9]{64}$'
  AND b->>'inputDigest' ~ '^[a-f0-9]{64}$' AND parent.root_id=o.root_id AND parent.payload->'context'=c
  AND EXISTS(SELECT 1 FROM os_agent_operation_models link JOIN os_agent_model_acceptances accepted ON accepted.call_id=link.id
    WHERE link.operation_id=parent.id AND accepted.id=o.source_acceptance_id)
  AND b->'modelResult'->>'resultId'=o.source_acceptance_id::text
  AND p.application_generation=app.generation AND p.registration_revision=app.revision
  AND p.digest=os_agent_profile_digest('policy',p.payload)
  AND b->'profile'=jsonb_build_object('ref',p.payload->'execution'->'id','revision',p.payload->'execution'->'revision','digest',p.policy_digest)
  AND p.payload->'native'->'capability'=b->'capability' AND p.payload->'native'->'runtime'=b->'runtime'
  AND p.payload->'native'->'harness'=c->'harness'
  AND p.payload->'native'->'limits'=limits AND os_native_analysis_limits(limits)
  AND p.payload->'native'->'meter'=b->'meter' AND os_native_analysis_meter(b->'meter',(limits->>'timeoutMs')::bigint)
  AND cap.payload->>'kind'='native' AND cap.payload->>'adapterRef'='native.offline-analysis/1'
  AND cap.payload->'mcp'='null'::jsonb AND cap.payload->>'lifecycle'='qualified' AND cap.payload->>'purpose'=c->>'purpose'
  AND b->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
  AND os_native_analysis_payload(o.binding_id,'AgentSDKToolBinding',c,b->'binding',o.created_at)
  AND os_native_analysis_payload(o.inputs_id,'AgentNativeAnalysisInputs',c,b->'inputs',o.created_at)
  AND o.created_at>=(c->>'admittedAt')::timestamptz AND o.created_at<=clock_timestamp()
  AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=o.task_id
    AND k.state='ACTIVE' AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp()
    AND t.state NOT IN('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
  AND EXISTS(SELECT 1 FROM os_segments segment WHERE segment.id=a.segment_id AND segment.task_id=o.task_id AND segment.state='OPEN'),false)
 THEN RAISE EXCEPTION 'agent_native_operation_binding'; END IF;
 PERFORM os_assert_agent_input_dependency(b->'modelResult',c,r.id,o.created_at);
END $$;

CREATE FUNCTION os_guard_agent_native_operation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_native_operation_immutable'; END IF;
 PERFORM os_assert_agent_native_current(NEW);
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_native_operation BEFORE INSERT OR UPDATE OR DELETE ON os_agent_native_operations
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_native_operation();


CREATE FUNCTION os_guard_agent_native_call() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE o os_agent_native_operations%ROWTYPE; w os_work_attempts%ROWTYPE; a os_admissions%ROWTYPE;
 r os_budget_roots%ROWTYPE; b jsonb; c jsonb; s jsonb; limits jsonb; units jsonb; fingerprint text;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_native_call_immutable'; END IF;
 SELECT * INTO o FROM os_agent_native_operations WHERE id=NEW.operation_id;
 PERFORM os_assert_agent_native_current(o);
 SELECT * INTO r FROM os_budget_roots WHERE id=o.root_id;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;
 b:=o.payload;c:=b->'context';s:=NEW.request->'sandbox';limits:=b->'limits';
 units:=jsonb_build_object('tokens',0,'costMicros',os_native_analysis_cost(b->'meter',(limits->>'timeoutMs')::bigint,true),'workMs',limits->'timeoutMs',
  'computeMs',limits->'timeoutMs','storageBytes',536870912);
 fingerprint:=os_agent_profile_digest('command',jsonb_build_object('profile','python-offline-analysis/1',
  'context',c,'operationId',o.id,'programDigest',b->'programDigest','inputDigest',b->'inputDigest',
  'runtime',b->'runtime','limits',limits,'meter',b->'meter'));

 IF NOT COALESCE(NEW.id=os_query_source_uuid5(o.id,'tool-attempt/1') AND NEW.root_id=o.root_id
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND NEW.request=jsonb_build_object('record',b,'sandbox',s) AND NEW.digest=os_agent_profile_digest('command',NEW.request)
  AND NEW.created_at>=w.created_at AND NEW.created_at>=o.created_at AND NEW.created_at<=clock_timestamp()
  AND w.state='RESERVED'
  AND ROW(w.installation_id,w.application_id,w.tenant_id,w.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND w.kind='agent.native' AND w.accounting_format='agent-resources/1' AND w.root_id=r.id AND w.task_id=o.task_id
  AND w.segment_id=a.segment_id AND w.control_epoch=(c->>'controlEpoch')::bigint
  AND w.invocation_id=os_query_source_uuid5(o.id,'tool-attempt/1') AND w.reserved=units
  AND w.request_digest=os_agent_profile_digest('command',jsonb_build_object('schema','agent-resource-reservation/1',
   'taskId',o.task_id,'segmentId',a.segment_id,'epoch',w.control_epoch,'invocationId',w.invocation_id,
   'kind','agent.native','inputDigest',fingerprint,'units',units,'timeoutMs',limits->'timeoutMs'))
  AND s=jsonb_build_object('context',c,'attempt',jsonb_build_object('subject',c->'subject','id',w.id,'taskId',w.task_id,
   'segmentId',w.segment_id,'rootId',w.root_id,'controlEpoch',w.control_epoch,'leaseToken',w.lease_token,
   'leaseUntil',s->'attempt'->'leaseUntil','state','RESERVED'),'operationId',o.id,'requestDigest',w.request_digest,
   'programDigest',b->'programDigest','inputDigest',b->'inputDigest','runtime',b->'runtime','limits',limits,'meter',b->'meter')
  AND (s->'attempt'->>'leaseUntil')::timestamptz=w.lease_until AND w.lease_until>clock_timestamp()
  AND w.lease_until<=LEAST(r.deadline,w.created_at+make_interval(secs=>(limits->>'timeoutMs')::numeric/1000))

 ,false) THEN RAISE EXCEPTION 'agent_native_call_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_native_call BEFORE INSERT OR UPDATE OR DELETE ON os_agent_native_calls
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_native_call();

CREATE FUNCTION os_guard_agent_native_begin() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE o os_agent_native_operations%ROWTYPE;
BEGIN
 IF NEW.kind='agent.native' AND NEW.accounting_format='agent-resources/1' AND OLD.state='RESERVED' AND NEW.state='RUNNING' THEN
  SELECT native.* INTO o FROM os_agent_native_operations native JOIN os_agent_native_calls call ON call.operation_id=native.id WHERE call.attempt_id=NEW.id;
  IF o.id IS NULL THEN RAISE EXCEPTION 'agent_native_begin_binding'; END IF;
  PERFORM os_assert_agent_native_current(o);
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_native_begin BEFORE UPDATE ON os_work_attempts
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_native_begin();

CREATE FUNCTION os_guard_agent_native_finish() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE o os_agent_native_operations%ROWTYPE; call os_agent_native_calls%ROWTYPE; w os_work_attempts%ROWTYPE; p os_agent_tool_profiles%ROWTYPE;
 s jsonb; t jsonb; v jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_native_finish_immutable'; END IF;
 SELECT * INTO call FROM os_agent_native_calls WHERE id=NEW.id;
 SELECT * INTO o FROM os_agent_native_operations WHERE id=call.operation_id;
 SELECT * INTO w FROM os_work_attempts WHERE id=call.attempt_id;
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND policy_digest=o.payload->'profile'->>'digest';
 s:=NEW.observation;t:=s->'teardown';v:=s->'usage';
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
   ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND NEW.digest=os_agent_profile_digest('command',s) AND w.state='SETTLED' AND w.actual=v
  AND s=jsonb_build_object('kind','settled','attemptId',w.id,'requestDigest',w.request_digest,
   'programDigest',o.payload->'programDigest','inputDigest',o.payload->'inputDigest',
   'usage',v,'teardown',t,'outputDigest',s->'outputDigest','failure',s->'failure')
  AND v->>'tokens'='0' AND (v->>'costMicros')::bigint=os_native_analysis_cost(o.payload->'meter',(v->>'computeMs')::bigint,t->'placementId'<>'null'::jsonb)
  AND t=jsonb_build_object('attemptId',w.id,'placementName','aos-n-'||replace(w.id::text,'-',''),
   'placementId',t->'placementId','providerDigest',p.payload->'native'->'placement'->'providerDigest',
   'runtimeDigest',p.payload->'native'->'placement'->'runtimeDigest','observedAt',t->'observedAt',
   'metadataAbsent',true,'directoryAbsent',true,'processAbsent',true)
  AND ((t->>'placementId' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$' AND (v->>'storageBytes')::bigint=536870912)
    OR (t->'placementId'='null'::jsonb AND v->>'storageBytes'='0' AND v->>'computeMs'='0'
      AND s->>'failure'='placement-failed' AND s->'outputDigest'='null'::jsonb))
  AND (t->>'observedAt')::timestamptz>=o.created_at AND (t->>'observedAt')::timestamptz<=NEW.created_at
  AND NEW.created_at<=clock_timestamp()
  AND ((s->'failure'='null'::jsonb AND s->>'outputDigest' ~ '^[a-f0-9]{64}$')
    OR (s->>'failure' IN('placement-failed','program-failed','invalid-output','output-limit','execution-expired','cancelled')
      AND s->'outputDigest'='null'::jsonb)),false)
 THEN RAISE EXCEPTION 'agent_native_finish_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_native_finish BEFORE INSERT OR UPDATE OR DELETE ON os_agent_native_finishes
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_native_finish();

CREATE FUNCTION os_check_agent_native_accounting() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE call os_agent_native_calls%ROWTYPE; w os_work_attempts%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF NEW.kind='agent.native' AND NEW.accounting_format='agent-resources/1' AND NEW.state='SETTLED' THEN
  SELECT * INTO w FROM os_work_attempts WHERE id=NEW.id;
  SELECT * INTO call FROM os_agent_native_calls WHERE attempt_id=w.id;
  IF call.id IS NULL OR NOT EXISTS(SELECT 1 FROM os_agent_native_finishes f WHERE f.id=call.id AND f.observation->'usage'=w.actual)
   THEN RAISE EXCEPTION 'agent_native_accounting_receipt'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_native_accounting AFTER UPDATE ON os_work_attempts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_native_accounting();
"""

# Exact current profile body plus a closed native-only branch, generated from
# frozen0076 during drafting. Existing read/preparation semantics stay intact.
PROFILE=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_tool_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_applications%ROWTYPE; p jsonb; r jsonb; e jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_profile_immutable'; END IF;
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 p:=NEW.payload;r:=p->'read';e:=p->'execution';

 IF p ? 'native' THEN
  r:=p->'native';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('native',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'harness',r->'harness','runtime',r->'runtime','verifier',r->'verifier','placement',r->'placement','limits',r->'limits','meter',r->'meter','adapterRef','native.offline-analysis/1')
   AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(r->'revision')='number' AND r->>'revision' ~ '^[1-9][0-9]*$'
   AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND EXISTS(SELECT 1 FROM os_agent_profiles registered WHERE registered.installation_id=NEW.installation_id
    AND registered.application_id=NEW.application_id AND registered.application_generation=NEW.application_generation
    AND registered.registration_revision=NEW.registration_revision AND registered.payload->'harness'->'harness'=r->'harness'
    AND registered.payload->'harness'->'features' @> '["native-execution"]'::jsonb)
   AND jsonb_typeof(r->'capability'->'revision')='number' AND r->'capability'->>'revision' ~ '^[1-9][0-9]*$'
   AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->'runtime'=jsonb_build_object('ref',r->'runtime'->'ref','revision',r->'runtime'->'revision','digest',r->'runtime'->'digest')
   AND r->'runtime'->>'ref'='python-offline-analysis/1' AND r->'runtime'->'revision'='1'::jsonb
   AND r->'runtime'->>'digest' ~ '^[a-f0-9]{64}$'
   AND r->'verifier'=jsonb_build_object('ref','native-source-values/1','revision',1,'digest',r->'verifier'->'digest')
   AND r->'verifier'->>'digest' ~ '^[a-f0-9]{64}$'
   AND r->'placement'=jsonb_build_object('providerDigest',r->'placement'->'providerDigest','runtimeDigest',r->'placement'->'runtimeDigest')
   AND r->'placement'->>'providerDigest' ~ '^[a-f0-9]{64}$' AND r->'placement'->>'runtimeDigest' ~ '^[a-f0-9]{64}$'
   AND os_native_analysis_limits(r->'limits') AND os_native_analysis_meter(r->'meter',(r->'limits'->>'timeoutMs')::bigint)
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'nativeProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','native-one-vcpu-allocation/1','externalInference',false)
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND jsonb_typeof(e->'revision')='number' AND e->>'revision' ~ '^[1-9][0-9]*$'
   AND (e->>'revision')::numeric<=9007199254740991 AND NEW.created_at<=clock_timestamp(),false)
   THEN RAISE EXCEPTION 'agent_native_profile_binding'; END IF;
  RETURN NEW;
 END IF;
 IF p ? 'preparation' THEN
  r:=p->'preparation';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('preparation',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'hostDefinitionRef',r->'hostDefinitionRef',
    'providerRef',r->'providerRef','outputContract','AgentPreparedChange/1','adapterRef','typed.prepare/1')
   AND jsonb_typeof(r->'id')='string' AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (r->>'revision') ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND (r->'capability'->>'revision') ~ '^[1-9][0-9]*$' AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->>'hostDefinitionRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'preparationProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','host-preparation-elapsed/1','externalInference',false,
    'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (e->>'revision') ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND (e->>'requestTimeoutMs') ~ '^[1-9][0-9]*$' AND (e->>'requestTimeoutMs')::numeric BETWEEN 25000 AND 900000
   AND (e->>'maxResultBytes') ~ '^[1-9][0-9]*$' AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576
   AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_preparation_profile_binding'; END IF;
  RETURN NEW;
 END IF;

 IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
 AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
 AND p-ARRAY['read','execution']='{}'::jsonb AND p ?& ARRAY['read','execution']
 AND e=jsonb_build_object('id',e->'id','revision',e->'revision','readProfile',jsonb_build_object('ref',r->'id','revision',r->'revision',
   'digest',os_agent_profile_digest('manifest',r)),'usageProfile','host-read-elapsed/1','externalInference',false,
   'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
 AND (e->>'requestTimeoutMs')::bigint BETWEEN 1 AND 900000 AND (e->>'maxResultBytes')::bigint BETWEEN 1024 AND 1048576
 AND (e->>'revision')::bigint BETWEEN 1 AND 9007199254740991 AND (r->>'outputContract'='EvidencePage/1' OR (
 r->>'outputContract'='AgentQueryPage/1'
 AND r-ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']='{}'::jsonb
 AND r ?& ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']
 AND jsonb_typeof(r->'cursorField')='string' AND r->>'cursorField' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
 AND jsonb_typeof(r->'grain')='array' AND jsonb_array_length(r->'grain') BETWEEN 1 AND 64
 AND jsonb_typeof(r->'pageGroupFields')='array' AND jsonb_array_length(r->'pageGroupFields') BETWEEN 0 AND 64
 AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements((r->'grain')||(r->'pageGroupFields')) v
  WHERE jsonb_typeof(v)<>'string' OR (v#>>'{}') !~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$')
 AND jsonb_array_length(r->'grain')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'grain') v)
 AND jsonb_array_length(r->'pageGroupFields')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'pageGroupFields') v)
 ))
 AND r->'host'->>'installationId'=NEW.installation_id::text AND r->'host'->>'applicationId'=NEW.application_id::text
 AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_tool_profile_binding'; END IF;
 RETURN NEW;
END $$;
"""
TABLES=r"""
CREATE TABLE os_agent_native_operations (
	id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	task_id UUID NOT NULL, 
	parent_operation_id UUID NOT NULL, 
	source_acceptance_id UUID NOT NULL, 
	binding_id UUID NOT NULL, 
	inputs_id UUID NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	payload JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_native_operation_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_native_operation_parent FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, parent_operation_id, root_id) REFERENCES os_agent_operations (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT fk_os_agent_model_acceptances_source_acceptance_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_acceptance_id) REFERENCES os_agent_model_acceptances (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_private_payloads_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES os_agent_private_payloads (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_private_payloads_inputs_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, inputs_id) REFERENCES os_agent_private_payloads (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_agent_native_operation_root UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT ck_agent_native_operation_payload CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536), 
	CONSTRAINT ck_agent_native_operation_digest CHECK (digest ~ '^[a-f0-9]{64}$')
)

;

CREATE TABLE os_agent_native_calls (
	id UUID NOT NULL, 
	operation_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	attempt_id UUID NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	request JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_native_call_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_native_call_operation FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, operation_id, root_id) REFERENCES os_agent_native_operations (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT fk_os_work_attempts_attempt_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_agent_native_call_operation UNIQUE (installation_id, application_id, tenant_id, subject_id, operation_id), 
	CONSTRAINT uq_agent_native_call_attempt UNIQUE (installation_id, application_id, tenant_id, subject_id, attempt_id), 
	CONSTRAINT ck_agent_native_call_request CHECK (jsonb_typeof(request)='object' AND octet_length(request::text)<=65536), 
	CONSTRAINT ck_agent_native_call_digest CHECK (digest ~ '^[a-f0-9]{64}$')
)

;

CREATE TABLE os_agent_native_finishes (
	id UUID NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	observation JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_native_finish_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_native_calls_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, id) REFERENCES os_agent_native_calls (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT ck_agent_native_finish_bounds CHECK (jsonb_typeof(observation)='object' AND octet_length(observation::text)<=16384), 
	CONSTRAINT ck_agent_native_finish_digest CHECK (digest ~ '^[a-f0-9]{64}$')
)

;

CREATE TABLE os_agent_native_acceptances (
	id UUID NOT NULL, 
	call_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	source_binding_id UUID NOT NULL, 
	write_id UUID NOT NULL, 
	reference JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_native_acceptance_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_native_calls_call_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, call_id) REFERENCES os_agent_native_calls (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_payload_writes_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_native_acceptance_source FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_binding_id, root_id) REFERENCES os_agent_query_source_bindings (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT uq_agent_native_acceptance_call UNIQUE (installation_id, application_id, tenant_id, subject_id, call_id), 
	CONSTRAINT uq_agent_native_acceptance_write UNIQUE (installation_id, application_id, tenant_id, subject_id, write_id), 
	CONSTRAINT ck_agent_native_acceptance_reference CHECK (jsonb_typeof(reference)='object' AND octet_length(reference::text)<=16384)
)

;"""


GROUPS=r"""ALTER TABLE os_agent_resource_groups DROP CONSTRAINT ck_agent_group_bounds;
ALTER TABLE os_agent_resource_groups ADD CONSTRAINT ck_agent_group_bounds CHECK (control_epoch>0 AND ticket BETWEEN 1 AND 9007199254740991 AND state IN ('WAITING','ADMITTED','CANCELLED','EXPIRED') AND profile_ref IN ('model-reservation/1','tool-reservation/1','storage-reservation/1','compute-reservation/1','effect-reservation/1','native-reservation/1') AND jsonb_typeof(request)='object' AND octet_length(request::text)<=65536);
CREATE OR REPLACE FUNCTION os_guard_agent_resource_group() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_group_accounts%ROWTYPE; original os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE;
 d os_admissions%ROWTYPE; c jsonb; member jsonb; required jsonb; w os_work_attempts%ROWTYPE; expected_kind text; expected_count integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_group_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_agent_group_accounts WHERE id=NEW.group_account_id;
 SELECT * INTO original FROM os_agent_resource_accounts WHERE id=a.account_id;
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state') THEN RAISE EXCEPTION 'agent_group_transition'; END IF;
  IF NEW.state='ADMITTED' THEN
   PERFORM os_agent_resource_owner(original);
   w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
   w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
   PERFORM os_assert_agent_work_current(w);
   IF EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
    THEN RAISE EXCEPTION 'agent_group_fifo'; END IF;
  END IF;
  RETURN NEW;
 END IF;
 PERFORM os_agent_resource_owner(original);
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 c=NEW.request->'context';required=os_agent_group_required(NEW.request->'members');
 expected_kind=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 'agent.model' WHEN 'tool-reservation/1' THEN 'agent.tool' WHEN 'compute-reservation/1' THEN 'agent.compute' WHEN 'effect-reservation/1' THEN 'agent.effect' WHEN 'native-reservation/1' THEN 'agent.native' ELSE 'agent.storage' END;
 expected_count=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 3 WHEN 'tool-reservation/1' THEN 2 ELSE 1 END;
 IF a.id IS NULL OR a.root_id<>r.id OR NEW.group_account_id<>a.id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline OR c IS DISTINCT FROM d.context
  OR NEW.request IS DISTINCT FROM jsonb_build_object('context',c,'groupId',NEW.id::text,'profile',NEW.profile_ref,'sourceId',NEW.source_id::text,'members',NEW.request->'members')
  OR c->>'rootId'<>NEW.root_id::text OR c->>'taskId'<>NEW.task_id::text OR c->>'segmentId'<>NEW.segment_id::text
  OR (c->>'controlEpoch')::bigint<>NEW.control_epoch
  OR NEW.request_digest<>os_agent_profile_digest('command',NEW.request||jsonb_build_object('schema','agent-resource-group/1'))
  OR jsonb_array_length(NEW.request->'members')<>expected_count
  OR NEW.request->'members'->0->>'kind'<>expected_kind OR NEW.request->'members'->0->>'invocationId'<>NEW.source_id::text
  OR (SELECT count(DISTINCT value->>'invocationId') FROM jsonb_array_elements(NEW.request->'members'))<>expected_count
  THEN RAISE EXCEPTION 'agent_group_binding'; END IF;
 FOR member IN SELECT value FROM jsonb_array_elements(NEW.request->'members') LOOP
  IF member IS DISTINCT FROM jsonb_build_object('taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,'controlEpoch',NEW.control_epoch,
    'invocationId',member->'invocationId','kind',member->'kind','inputDigest',member->'inputDigest','units',member->'units','timeoutMs',member->'timeoutMs')
   OR jsonb_typeof(member->'invocationId') IS DISTINCT FROM 'string' OR (member->>'invocationId') !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   OR jsonb_typeof(member->'inputDigest') IS DISTINCT FROM 'string' OR (member->>'inputDigest') !~ '^[a-f0-9]{64}$'
   OR member->>'kind' NOT IN ('agent.model','agent.tool','agent.storage','agent.compute','agent.effect','agent.native')
   OR jsonb_typeof(member->'kind') IS DISTINCT FROM 'string'
   OR jsonb_typeof(member->'timeoutMs') IS DISTINCT FROM 'number' OR (member->>'timeoutMs') !~ '^[1-9][0-9]*$'
   OR (member->>'timeoutMs')::numeric>(original.policy->>'requestTimeoutMs')::numeric
   OR (member->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
   OR (member->'units'->>'workMs')::numeric<1 THEN RAISE EXCEPTION 'agent_group_member_request'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.request->'members') WITH ORDINALITY AS m(value,ordinal) WHERE ordinal>1 AND value->>'kind'<>'agent.storage')
  THEN RAISE EXCEPTION 'agent_group_member_kind'; END IF;
 IF NEW.profile_ref='native-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_native_operations native WHERE native.root_id=NEW.root_id AND native.task_id=NEW.task_id
   AND native.payload->'context'=c AND os_query_source_uuid5(native.id,'tool-attempt/1')=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_native_group_source'; END IF;
 IF NEW.profile_ref='effect-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
   JOIN os_tasks task ON task.id=review.task_id
  WHERE decision.id=NEW.source_id AND review.root_id=NEW.root_id AND review.task_id=NEW.task_id
   AND review.payload->'context'=c AND decision.payload->'command'->>'decision'='approve'
   AND decision.expires_at>clock_timestamp() AND task.state='RUNNING'
   AND (NEW.request->'members'->0->>'inputDigest')=(os_agent_reviewed_grant(decision.id)->>'grantDigest'))
 THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));PERFORM os_assert_agent_work_current(w);
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_check_agent_group_complete() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE gid uuid; g os_agent_resource_groups%ROWTYPE; expected_count integer; actual uuid[]; claimed uuid[];
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_agent_resource_groups' THEN gid=NEW.id;
 ELSIF TG_TABLE_NAME='os_agent_group_members' THEN gid=NEW.group_id;
 ELSE SELECT group_id INTO gid FROM os_agent_group_members WHERE id=NEW.member_id; END IF;
 SELECT * INTO g FROM os_agent_resource_groups WHERE id=gid;
 IF g.id IS NULL THEN RAISE EXCEPTION 'agent_group_missing'; END IF;
 expected_count=jsonb_array_length(g.request->'members');
 SELECT array_agg(c.attempt_id ORDER BY c.attempt_id) INTO claimed FROM os_agent_group_claims c JOIN os_agent_group_members m ON m.id=c.member_id WHERE m.group_id=gid;
 IF g.state<>'ADMITTED' THEN
  IF EXISTS(SELECT 1 FROM os_agent_group_members WHERE group_id=gid) THEN RAISE EXCEPTION 'agent_group_unadmitted_work'; END IF;
  RETURN NEW;
 END IF;
 IF (SELECT count(*) FROM os_agent_group_members WHERE group_id=gid)<>expected_count OR cardinality(claimed) IS DISTINCT FROM expected_count
  THEN RAISE EXCEPTION 'agent_group_incomplete'; END IF;
 IF g.profile_ref='model-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_model_calls WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND request->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_model_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_model_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_model_slots WHERE call_id=g.source_id) s;
 ELSIF g.profile_ref='tool-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
    WHERE c.id=g.source_id AND c.root_id=g.root_id AND o.task_id=g.task_id AND o.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_tool_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_tool_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_tool_slots WHERE id=g.source_id) s;
 ELSIF g.profile_ref='effect-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
    WHERE decision.id=g.source_id AND review.root_id=g.root_id AND review.task_id=g.task_id
     AND review.payload->'context'=g.request->'context' AND decision.payload->'command'->>'decision'='approve')
   THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.effect';
 ELSIF g.profile_ref='native-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_native_calls call JOIN os_agent_native_operations native ON native.id=call.operation_id
   WHERE call.id=g.source_id AND call.root_id=g.root_id AND native.task_id=g.task_id AND native.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_native_source'; END IF;
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_native_calls WHERE id=g.source_id;
 ELSIF g.profile_ref='compute-reservation/1' THEN
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.compute';
 ELSE
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_payload_writes
   WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND segment_id=g.segment_id AND control_epoch=g.control_epoch;
 END IF;
 IF actual IS DISTINCT FROM claimed THEN RAISE EXCEPTION 'agent_group_source_members'; END IF;
 RETURN NEW;
END $$;"""


ACCEPTANCE=r"""
CREATE FUNCTION os_assert_agent_native_dependency(dep jsonb,c jsonb,root uuid,before_at timestamptz)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE accepted os_agent_native_acceptances%ROWTYPE; call os_agent_native_calls%ROWTYPE;
 o os_agent_native_operations%ROWTYPE; f os_agent_native_finishes%ROWTYPE; source uuid;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO accepted FROM os_agent_native_acceptances WHERE id=(dep->>'resultId')::uuid;
 SELECT * INTO call FROM os_agent_native_calls WHERE id=accepted.call_id;
 SELECT * INTO o FROM os_agent_native_operations WHERE id=call.operation_id;
 SELECT * INTO f FROM os_agent_native_finishes WHERE id=call.id;
 SELECT id INTO source FROM os_agent_query_source_bindings WHERE root_id=root ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(accepted.root_id=root AND o.payload->'context'=c AND accepted.reference=dep
  AND accepted.created_at<=before_at AND accepted.source_binding_id=source
  AND ROW(accepted.installation_id,accepted.application_id,accepted.tenant_id,accepted.subject_id)=
      ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND f.observation->>'kind'='settled' AND f.observation->'failure'='null'::jsonb
  AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=call.attempt_id AND state='SETTLED' AND actual=f.observation->'usage')
  AND os_query_source_payload(accepted.write_id,'AgentNativeAnalysisResult',c,before_at),false)
 THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
END $$;

CREATE FUNCTION os_guard_agent_native_acceptance() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE call os_agent_native_calls%ROWTYPE; o os_agent_native_operations%ROWTYPE;
 f os_agent_native_finishes%ROWTYPE; source os_agent_query_source_bindings%ROWTYPE;
 p os_agent_payload_writes%ROWTYPE; ready os_agent_private_payloads%ROWTYPE; c jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_native_acceptance_immutable'; END IF;
 SELECT * INTO call FROM os_agent_native_calls WHERE id=NEW.call_id;
 SELECT * INTO o FROM os_agent_native_operations WHERE id=call.operation_id;
 PERFORM os_assert_agent_native_current(o);
 SELECT * INTO f FROM os_agent_native_finishes WHERE id=call.id;
 SELECT * INTO source FROM os_agent_query_source_bindings WHERE root_id=o.root_id ORDER BY revision DESC LIMIT 1;
 SELECT * INTO p FROM os_agent_payload_writes WHERE id=NEW.write_id;
 SELECT * INTO ready FROM os_agent_private_payloads WHERE write_id=p.id;
 c:=o.payload->'context';
 IF NOT COALESCE(NEW.id=os_query_source_uuid5(call.id,'accepted-result') AND NEW.root_id=o.root_id
  AND NEW.source_binding_id=source.id AND source.payload->'context'=c
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
      ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND f.observation->>'kind'='settled' AND f.observation->'failure'='null'::jsonb
  AND f.observation->>'outputDigest' ~ '^[a-f0-9]{64}$'
  AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=call.attempt_id AND state='SETTLED' AND actual=f.observation->'usage')
  AND NEW.write_id=os_query_source_uuid5(call.id,'native-verified-result/1')
  AND os_query_source_payload(p.id,'AgentNativeAnalysisResult',c,NEW.created_at)
  AND NEW.reference=jsonb_build_object('subject',c->'subject','taskId',o.task_id,'rootId',o.root_id,
   'resultId',NEW.id,'producerStepId',call.id,'acceptedAttemptId',call.attempt_id,
   'payload',jsonb_build_object('artifactRef','artifact/'||ready.id,'ciphertextDigest',ready.ciphertext_digest,
    'bytes',p.plain_bytes,'schemaRef','AgentNativeAnalysisResult','schemaVersion',1),
   'lineageRef','native-output/'||(f.observation->>'outputDigest'),'scopeRef',c->'scopeRef','acceptedAt',NEW.reference->'acceptedAt')
  AND (NEW.reference->>'acceptedAt')::timestamptz=NEW.created_at AND NEW.created_at<=clock_timestamp(),false)
 THEN RAISE EXCEPTION 'agent_native_acceptance_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_native_acceptance BEFORE INSERT OR UPDATE OR DELETE ON os_agent_native_acceptances
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_native_acceptance();

CREATE FUNCTION os_check_agent_native_completion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; source os_agent_query_source_bindings%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF NEW.state<>'COMPLETED' THEN RETURN NULL; END IF;
 SELECT admitted.* INTO a FROM os_admissions admitted JOIN os_budget_roots root ON root.admission_id=admitted.id
  WHERE root.root_task_id=NEW.id;
 IF a.id IS NULL OR NOT EXISTS(SELECT 1 FROM os_agent_tool_profiles profile WHERE profile.installation_id=a.installation_id
  AND profile.application_id=a.application_id AND profile.payload->'native'->'harness'=a.context->'harness') THEN RETURN NULL; END IF;
 SELECT * INTO source FROM os_agent_query_source_bindings WHERE root_id=(a.context->>'rootId')::uuid ORDER BY revision DESC LIMIT 1;
 IF source.id IS NULL OR NOT EXISTS(SELECT 1 FROM os_agent_native_acceptances accepted
  JOIN os_agent_native_calls call ON call.id=accepted.call_id JOIN os_agent_native_operations native ON native.id=call.operation_id
  WHERE accepted.root_id=source.root_id AND accepted.source_binding_id=source.id AND native.payload->'context'=a.context)
 THEN RAISE EXCEPTION 'agent_native_goal_incomplete'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_native_completion AFTER UPDATE ON os_tasks
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_native_completion();
"""


DEPENDENCY=r"""CREATE OR REPLACE FUNCTION os_assert_agent_input_dependency(dep jsonb,c jsonb,root uuid,before_at timestamptz) RETURNS void LANGUAGE plpgsql AS $$
DECLARE accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 tool_accepted os_agent_tool_acceptances%ROWTYPE; tool os_agent_tool_calls%ROWTYPE; tool_archive os_agent_tool_archives%ROWTYPE;
 page os_agent_input_result_sets%ROWTYPE; artifact os_artifacts%ROWTYPE; expected_schema text;
BEGIN

 IF dep->'payload'->>'schemaRef'='AgentNativeAnalysisResult' THEN
  PERFORM os_assert_agent_native_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 IF dep->'payload'->>'schemaRef'='AgentQueryFactSet' THEN
  PERFORM os_assert_agent_query_fact_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 IF dep->'payload'->>'schemaRef'='AgentOwnerReply' THEN
  PERFORM os_assert_agent_owner_reply_dependency(dep,c,root,before_at);
  RETURN;
 END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF dep->'payload'->>'schemaRef'='AgentProviderResponse' THEN
  SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=(dep->>'resultId')::uuid;
  SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
  SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
  IF NOT COALESCE(producer.root_id=root AND producer.request->'context'->'subject'=c->'subject'
   AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
    'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
     'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
    'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
   AND (dep->>'acceptedAt')::timestamptz=accepted.created_at AND accepted.created_at<=before_at AND producer.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSIF dep->'payload'->>'schemaRef' IN ('EvidencePage','AgentQueryPage') THEN
  SELECT * INTO tool_accepted FROM os_agent_tool_acceptances WHERE id=(dep->>'resultId')::uuid;
  SELECT * INTO tool FROM os_agent_tool_calls WHERE id=tool_accepted.call_id;
  SELECT * INTO tool_archive FROM os_agent_tool_archives WHERE id=tool_accepted.artifact_id;
  SELECT CASE p.payload->'read'->>'outputContract' WHEN 'EvidencePage/1' THEN 'EvidencePage' WHEN 'AgentQueryPage/1' THEN 'AgentQueryPage' END INTO expected_schema
   FROM os_agent_tool_profiles p WHERE p.installation_id=tool.installation_id AND p.application_id=tool.application_id
    AND p.policy_digest=tool.request->'record'->'profile'->>'digest';
  IF NOT COALESCE(expected_schema=dep->'payload'->>'schemaRef' AND tool.root_id=root AND tool.request->'record'->'context'->'subject'=c->'subject'
   AND dep=jsonb_build_object('subject',c->'subject','taskId',tool.request->'record'->'context'->'taskId','rootId',tool.root_id,
    'resultId',tool_accepted.id,'producerStepId',tool.id,'acceptedAttemptId',tool.attempt_id,
    'payload',jsonb_build_object('artifactRef','artifact/'||tool_archive.id,'ciphertextDigest',tool_archive.ciphertext_digest,
     'bytes',tool_archive.plain_bytes,'schemaRef',expected_schema,'schemaVersion',1),
    'lineageRef',null,'scopeRef',tool.request->'record'->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
   AND (dep->>'acceptedAt')::timestamptz=tool_accepted.created_at AND tool_accepted.created_at<=before_at AND tool.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSIF dep->'payload'->>'schemaRef'='AgentInputResultSet' THEN
  SELECT * INTO page FROM os_agent_input_result_sets WHERE id=(dep->>'producerStepId')::uuid;
  SELECT * INTO artifact FROM os_artifacts WHERE id=page.artifact_id;
  IF NOT COALESCE(page.root_id=root AND page.record->'context'=c AND page.reference=dep
   AND page.created_at<=before_at AND artifact.expires_at>clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;
 ELSE RAISE EXCEPTION 'agent_operation_dependency';
 END IF;
END $$;"""


def upgrade():
    op.execute(HELPERS)
    op.execute(PROFILE)
    op.execute(TABLES)
    op.execute(NATIVE_GUARDS)
    op.execute(GROUPS)
    op.execute(ACCEPTANCE)
    op.execute(DEPENDENCY)


def downgrade():
    raise RuntimeError('Native analysis facts require protected forward recovery')
