"""Resolve the selected-outcome alias without changing publication authority."""
from alembic import op

revision="os_pg_0038"
down_revision="os_pg_0037"
branch_labels=None
depends_on=None


def upgrade():
    op.execute(GUARD)


# Exact0037 guard snapshot, changing only the colliding inner table alias.
GUARD = r"""
CREATE OR REPLACE FUNCTION os_assert_candidate_decision(did uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE d personal_candidate_decisions%ROWTYPE; c personal_knowledge_candidates%ROWTYPE;
 r personal_knowledge_candidate_revisions%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 s personal_learning_settings%ROWTYPE; p personal_knowledge_publications%ROWTYPE;
 op personal_knowledge_operations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; expected jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO d FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=d.candidate_id;
 SELECT * INTO r FROM personal_knowledge_candidate_revisions WHERE id=d.candidate_revision_id;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO p FROM personal_knowledge_publications WHERE decision_id=d.id;
 IF d.id IS NULL OR c.id IS NULL OR r.id IS NULL OR j.state IS DISTINCT FROM 'SUCCEEDED' OR s.id IS NULL
  OR r.candidate_id<>c.id OR r.ordinal<>d.accepted_version OR c.version<>d.accepted_version
  OR c.state<>(CASE WHEN d.decision='reject' THEN 'REJECTED' ELSE 'ACCEPTED' END)
  OR c.updated_at<>d.created_at OR d.context_revision>s.context_revision
  OR (r.envelope IS NULL AND NOT os_candidate_erasure_allowed(c.id))
  THEN RAISE EXCEPTION 'candidate_decision_binding'; END IF;
 IF d.decision='reject' THEN
  IF p.id IS NOT NULL THEN RAISE EXCEPTION 'candidate_rejection_publication'; END IF;
  expected='null'::jsonb;
 ELSE
  SELECT * INTO op FROM personal_knowledge_operations WHERE id=p.operation_id;
  IF p.id IS NULL OR p.candidate_id<>c.id OR p.candidate_revision_id<>r.id OR p.created_at<>d.created_at
   OR op.id IS NULL OR op.kind<>'SAVE' OR op.entry_id<>p.entry_id OR op.command_id<>d.command_id
   OR op.session_id<>d.session_id OR op.context_revision<>d.context_revision OR op.created_at<>d.created_at
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions kr WHERE kr.id=p.revision_id AND kr.entry_id=p.entry_id AND kr.operation_id=op.id)
   OR (SELECT count(*) FROM personal_knowledge_supersessions WHERE publication_id=p.id)<>p.target_count
   THEN RAISE EXCEPTION 'candidate_atomic_publication'; END IF;
  IF p.epistemic IS DISTINCT FROM (CASE WHEN d.decision='edit-and-accept' THEN 'user-stated'
    WHEN EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources source_row ON source_row.id=e.source_id
     WHERE e.job_id=j.id AND source_row.kind='accepted-outcome/1') THEN 'derived-outcome' ELSE 'user-stated' END)
   THEN RAISE EXCEPTION 'candidate_epistemic_origin'; END IF;
  expected=op.receipt;
 END IF;
 IF d.receipt IS DISTINCT FROM jsonb_build_object('commandId',d.command_id,'decisionId',d.id,'candidateId',c.id,
  'candidateRevision',c.version,'state',c.state,'contextRevision',d.context_revision,'knowledge',expected)
  THEN RAISE EXCEPTION 'candidate_atomic_receipt'; END IF;
 IF live THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE id=d.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=d.installation_id AND application_id=d.application_id
   AND tenant_id=d.tenant_id AND subject_id=d.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp() OR d.request_mac IS NULL
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation OR owner.id IS NULL
   OR NOT owner.active OR owner.generation<>session.subject_generation OR c.expires_at<=clock_timestamp()
   OR os_learning_candidate_invalid(c.id) THEN RAISE EXCEPTION 'candidate_current_review'; END IF;
  IF d.decision<>'reject' THEN
   IF s.context_revision<>d.context_revision OR s.updated_at<>d.created_at OR s.learning_epoch<>j.learning_epoch
    OR s.choice->'learnConversation' IS DISTINCT FROM 'true'::jsonb OR s.choice->>'extractorProfile'<>j.profile_ref
    OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
     IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
    THEN RAISE EXCEPTION 'candidate_current_learning'; END IF;
   PERFORM os_assert_knowledge_entry(p.entry_id,true);
  END IF;
 END IF;
END $$;
"""


def downgrade():
    raise RuntimeError("Protected correction restore requires the owned recovery procedure")
