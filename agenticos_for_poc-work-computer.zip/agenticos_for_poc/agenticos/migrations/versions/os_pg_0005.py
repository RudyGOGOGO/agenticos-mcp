"""Enforce the finite dispatch repair boundary omitted by autogeneration."""
from alembic import op

revision = "os_pg_0005"
down_revision = "os_pg_0004"
branch_labels = None
depends_on = None


def upgrade():
    # PostgreSQL validates existing rows transactionally. Invalid rows fail the
    # upgrade; this migration must never rewrite them to manufacture a pass.
    op.create_check_constraint("ck_dispatch_repairs", "os_dispatches",
                               "repair_count>=0 AND repair_count<=3")


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use tested fresh recovery")
