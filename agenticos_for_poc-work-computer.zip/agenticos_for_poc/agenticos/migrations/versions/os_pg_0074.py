"""Bind pre-goal owner replies to original metered storage and human commands.

Draft until protected populated runtime/negative rehearsal and recovery pass.
Existing dependency branches retain their frozen semantics.
"""
from alembic import op

revision='os_pg_0074'
down_revision='os_pg_0073'
branch_labels=None
depends_on=None

DEPENDENCY="CREATE OR REPLACE FUNCTION os_assert_agent_input_dependency(dep jsonb,c jsonb,root uuid,before_at timestamptz) RETURNS void LANGUAGE plpgsql AS $$\nDECLARE accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;\n tool_accepted os_agent_tool_acceptances%ROWTYPE; tool os_agent_tool_calls%ROWTYPE; tool_archive os_agent_tool_archives%ROWTYPE;\n page os_agent_input_result_sets%ROWTYPE; artifact os_artifacts%ROWTYPE; expected_schema text;\nBEGIN\n\n IF dep->'payload'->>'schemaRef'='AgentOwnerReply' THEN\n  PERFORM os_assert_agent_owner_reply_dependency(dep,c,root,before_at);\n  RETURN;\n END IF;\n PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);\n IF dep->'payload'->>'schemaRef'='AgentProviderResponse' THEN\n  SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=(dep->>'resultId')::uuid;\n  SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;\n  SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;\n  IF NOT COALESCE(producer.root_id=root AND producer.request->'context'->'subject'=c->'subject'\n   AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,\n    'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,\n     'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),\n    'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')\n   AND (dep->>'acceptedAt')::timestamptz=accepted.created_at AND accepted.created_at<=before_at AND producer.expires_at>clock_timestamp(),false)\n  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;\n ELSIF dep->'payload'->>'schemaRef' IN ('EvidencePage','AgentQueryPage') THEN\n  SELECT * INTO tool_accepted FROM os_agent_tool_acceptances WHERE id=(dep->>'resultId')::uuid;\n  SELECT * INTO tool FROM os_agent_tool_calls WHERE id=tool_accepted.call_id;\n  SELECT * INTO tool_archive FROM os_agent_tool_archives WHERE id=tool_accepted.artifact_id;\n  SELECT CASE p.payload->'read'->>'outputContract' WHEN 'EvidencePage/1' THEN 'EvidencePage' WHEN 'AgentQueryPage/1' THEN 'AgentQueryPage' END INTO expected_schema\n   FROM os_agent_tool_profiles p WHERE p.installation_id=tool.installation_id AND p.application_id=tool.application_id\n    AND p.policy_digest=tool.request->'record'->'profile'->>'digest';\n  IF NOT COALESCE(expected_schema=dep->'payload'->>'schemaRef' AND tool.root_id=root AND tool.request->'record'->'context'->'subject'=c->'subject'\n   AND dep=jsonb_build_object('subject',c->'subject','taskId',tool.request->'record'->'context'->'taskId','rootId',tool.root_id,\n    'resultId',tool_accepted.id,'producerStepId',tool.id,'acceptedAttemptId',tool.attempt_id,\n    'payload',jsonb_build_object('artifactRef','artifact/'||tool_archive.id,'ciphertextDigest',tool_archive.ciphertext_digest,\n     'bytes',tool_archive.plain_bytes,'schemaRef',expected_schema,'schemaVersion',1),\n    'lineageRef',null,'scopeRef',tool.request->'record'->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')\n   AND (dep->>'acceptedAt')::timestamptz=tool_accepted.created_at AND tool_accepted.created_at<=before_at AND tool.expires_at>clock_timestamp(),false)\n  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;\n ELSIF dep->'payload'->>'schemaRef'='AgentInputResultSet' THEN\n  SELECT * INTO page FROM os_agent_input_result_sets WHERE id=(dep->>'producerStepId')::uuid;\n  SELECT * INTO artifact FROM os_artifacts WHERE id=page.artifact_id;\n  IF NOT COALESCE(page.root_id=root AND page.record->'context'=c AND page.reference=dep\n   AND page.created_at<=before_at AND artifact.expires_at>clock_timestamp(),false)\n  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;\n ELSE RAISE EXCEPTION 'agent_operation_dependency';\n END IF;\nEND $$;"


OWNER_REPLY=r"""
CREATE FUNCTION os_assert_agent_owner_reply_dependency(dep jsonb,c jsonb,root uuid,before_at timestamptz)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; r os_budget_roots%ROWTYPE; accepted os_commands%ROWTYPE; prepared os_commands%ROWTYPE;
 p os_agent_payload_writes%ROWTYPE; f os_agent_private_payloads%ROWTYPE; w os_work_attempts%ROWTYPE;
 artifact os_artifacts%ROWTYPE; payload jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO r FROM os_budget_roots WHERE id=root;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO accepted FROM os_commands WHERE id=(dep->>'resultId')::uuid;
 SELECT * INTO prepared FROM os_commands WHERE kind='agent-owner-reply-prepare/1' AND accepted_task_id=a.task_id;
 SELECT * INTO p FROM os_agent_payload_writes WHERE id=(dep->>'producerStepId')::uuid;
 SELECT * INTO f FROM os_agent_private_payloads WHERE write_id=p.id;
 SELECT * INTO artifact FROM os_artifacts WHERE id=f.id;
 SELECT * INTO w FROM os_work_attempts WHERE id=p.attempt_id;
 payload:=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,
  'bytes',p.plain_bytes,'schemaRef','AgentOwnerReply','schemaVersion',1);
 IF NOT COALESCE(a.context=c AND c->'harness'->>'ref'='agent-sdk-owner-input/1'
  AND accepted.kind='agent-owner-reply/1' AND accepted.accepted_task_id=a.task_id
  AND ROW(accepted.installation_id,accepted.application_id,accepted.tenant_id,accepted.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND ROW(prepared.installation_id,prepared.application_id,prepared.tenant_id,prepared.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND accepted.command_id=prepared.command_id AND accepted.request_digest=os_agent_profile_digest('command',
      jsonb_build_object('preparedDigest',prepared.request_digest,'reply',payload))
  AND p.root_id=root AND p.task_id=a.task_id AND p.segment_id=a.segment_id
  AND p.control_epoch=(c->>'controlEpoch')::bigint AND p.schema_ref='AgentOwnerReply' AND p.schema_version=1
  AND ROW(p.installation_id,p.application_id,p.tenant_id,p.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND w.state='SETTLED' AND w.kind='agent.storage' AND w.root_id=root
  AND p.expires_at>clock_timestamp() AND artifact.expires_at=p.expires_at
  AND accepted.created_at>=f.created_at AND prepared.created_at<=p.created_at
  AND accepted.created_at<=before_at
  AND dep=jsonb_build_object('subject',c->'subject','taskId',a.task_id,'rootId',root,'resultId',accepted.id,
      'producerStepId',p.id,'acceptedAttemptId',p.attempt_id,'payload',payload,'lineageRef',null,
      'scopeRef',c->'scopeRef','acceptedAt',dep->'acceptedAt')
  AND (dep->>'acceptedAt')::timestamptz=accepted.created_at,false)
 THEN RAISE EXCEPTION 'agent_owner_reply_dependency'; END IF;
END $$;

CREATE FUNCTION os_guard_agent_owner_reply_command() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE t os_tasks%ROWTYPE; r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE;
 a os_admissions%ROWTYPE; prepared os_commands%ROWTYPE; p os_agent_payload_writes%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; payload jsonb; matched integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_owner_reply_command_immutable'; END IF;
 SELECT * INTO t FROM os_tasks WHERE id=NEW.accepted_task_id;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=t.budget_root_id;
 PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (t.id,(SELECT root_task_id FROM os_budget_roots WHERE id=t.budget_root_id))
  ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=t.budget_root_id FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND t.deadline>clock_timestamp()
  AND r.accounting_format='agent-resources/1' AND t.state='WAITING_INPUT'
  AND a.context->'harness'->>'ref'='agent-sdk-owner-input/1'
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.state='OPEN')
  AND NOT EXISTS(SELECT 1 FROM os_task_controls k WHERE k.task_id IN (t.id,r.root_task_id)
      AND (k.state<>'ACTIVE' OR k.epoch<>(a.context->>'controlEpoch')::bigint))
  AND NOT EXISTS(SELECT 1 FROM jsonb_each_text(r.outstanding) x WHERE x.value::bigint<>0)
  AND NEW.created_at<=clock_timestamp()
  AND NOT EXISTS(SELECT 1 FROM os_commands prior_command WHERE prior_command.accepted_task_id=t.id AND prior_command.kind=NEW.kind),false)
 THEN RAISE EXCEPTION 'agent_owner_reply_command_binding'; END IF;
 IF NEW.kind='agent-owner-reply/1' THEN
  SELECT * INTO prepared FROM os_commands WHERE accepted_task_id=t.id AND kind='agent-owner-reply-prepare/1';
  SELECT count(*) INTO matched FROM os_agent_payload_writes WHERE root_id=r.id AND schema_ref='AgentOwnerReply' AND schema_version=1;
  SELECT * INTO p FROM os_agent_payload_writes WHERE root_id=r.id AND schema_ref='AgentOwnerReply' AND schema_version=1;
  SELECT * INTO f FROM os_agent_private_payloads WHERE write_id=p.id;
  payload:=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,
   'bytes',p.plain_bytes,'schemaRef','AgentOwnerReply','schemaVersion',1);
  IF NOT COALESCE(matched=1 AND NEW.command_id=prepared.command_id AND NEW.created_at>=f.created_at
    AND prepared.created_at<=p.created_at AND NEW.request_digest=os_agent_profile_digest('command',
     jsonb_build_object('preparedDigest',prepared.request_digest,'reply',payload))
    AND p.task_id=t.id AND p.segment_id=a.segment_id AND p.control_epoch=(a.context->>'controlEpoch')::bigint
    AND EXISTS(SELECT 1 FROM os_work_attempts w WHERE w.id=p.attempt_id AND w.state='SETTLED' AND w.kind='agent.storage'),false)
  THEN RAISE EXCEPTION 'agent_owner_reply_command_payload'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_owner_reply_insert BEFORE INSERT ON os_commands FOR EACH ROW
 WHEN (NEW.kind IN ('agent-owner-reply/1','agent-owner-reply-prepare/1')) EXECUTE FUNCTION os_guard_agent_owner_reply_command();
CREATE TRIGGER guard_agent_owner_reply_update BEFORE UPDATE ON os_commands FOR EACH ROW
 WHEN (OLD.kind IN ('agent-owner-reply/1','agent-owner-reply-prepare/1') OR
       NEW.kind IN ('agent-owner-reply/1','agent-owner-reply-prepare/1')) EXECUTE FUNCTION os_guard_agent_owner_reply_command();
CREATE TRIGGER guard_agent_owner_reply_delete BEFORE DELETE ON os_commands FOR EACH ROW
 WHEN (OLD.kind IN ('agent-owner-reply/1','agent-owner-reply-prepare/1')) EXECUTE FUNCTION os_guard_agent_owner_reply_command();
"""

WAIT_GUARDS=r"""
CREATE FUNCTION os_guard_agent_input_wait() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_work_attempts' THEN
  IF NEW.kind='agent.storage' THEN RETURN NEW; END IF;
 END IF;
 IF EXISTS(SELECT 1 FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id
  WHERE t.id=NEW.task_id AND t.state='WAITING_INPUT' AND r.profile_ref='agent-production/1')
 THEN RAISE EXCEPTION 'agent_input_wait_admission'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_work_input_wait BEFORE INSERT ON os_work_attempts FOR EACH ROW EXECUTE FUNCTION os_guard_agent_input_wait();
CREATE TRIGGER guard_agent_operation_input_wait BEFORE INSERT ON os_agent_operations FOR EACH ROW EXECUTE FUNCTION os_guard_agent_input_wait();
"""


def upgrade():
    op.execute(OWNER_REPLY)
    op.execute(DEPENDENCY)
    op.execute(WAIT_GUARDS)


def downgrade():
    raise RuntimeError('Accepted owner replies require protected forward recovery')
