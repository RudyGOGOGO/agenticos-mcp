"""Scoped inference consent and honest standing-consent publication.

Draft: protected populated rehearsal and runtime acceptance remain pending.
"""
from alembic import op

revision='os_pg_0104'
down_revision='os_pg_0103'
branch_labels=None
depends_on=None

CONSENT_SQL=r"""
CREATE FUNCTION os_inference_consent_valid(v jsonb) RETURNS boolean LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE happened timestamptz;
BEGIN
 IF v IS NULL OR jsonb_typeof(v)<>'object' OR v IS DISTINCT FROM jsonb_build_object(
  'commandId',v->'commandId','generation',v->'generation','enabled',v->'enabled',
  'categories',v->'categories','purposes',v->'purposes','grantedAt',v->'grantedAt','revokedAt',v->'revokedAt')
  OR jsonb_typeof(v->'commandId')<>'string' OR v->>'commandId' !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'
  OR jsonb_typeof(v->'generation')<>'number' OR (v->>'generation') !~ '^[1-9][0-9]*$'
  OR (v->>'generation')::numeric>9007199254740991 OR jsonb_typeof(v->'enabled')<>'boolean'
  OR jsonb_typeof(v->'categories')<>'array' OR jsonb_typeof(v->'purposes')<>'array'
  THEN RETURN false;END IF;
 IF jsonb_array_length(v->'categories')>2 OR jsonb_array_length(v->'purposes')>2
  OR EXISTS(SELECT 1 FROM jsonb_array_elements(v->'categories') x WHERE x NOT IN ('"personal-context"'::jsonb,'"preference"'::jsonb))
  OR EXISTS(SELECT 1 FROM jsonb_array_elements(v->'purposes') x WHERE x NOT IN ('"assistant.personalize/1"'::jsonb,'"assistant.reflect/1"'::jsonb))
  OR v->'categories' IS DISTINCT FROM (SELECT COALESCE(jsonb_agg(x ORDER BY x),'[]'::jsonb) FROM (SELECT DISTINCT x FROM jsonb_array_elements(v->'categories') x) q)
  OR v->'purposes' IS DISTINCT FROM (SELECT COALESCE(jsonb_agg(x ORDER BY x),'[]'::jsonb) FROM (SELECT DISTINCT x FROM jsonb_array_elements(v->'purposes') x) q)
  THEN RETURN false;END IF;
 IF v->'enabled'='true'::jsonb THEN
  IF jsonb_array_length(v->'categories')=0 OR jsonb_array_length(v->'purposes')=0
   OR jsonb_typeof(v->'grantedAt')<>'string' OR v->'revokedAt'<>'null'::jsonb THEN RETURN false;END IF;
  happened=(v->>'grantedAt')::timestamptz;
 ELSE
  IF jsonb_typeof(v->'revokedAt')<>'string' OR jsonb_typeof(v->'grantedAt') NOT IN ('string','null') THEN RETURN false;END IF;
  happened=(v->>'revokedAt')::timestamptz;
  IF v->'grantedAt'<>'null'::jsonb AND (v->>'grantedAt')::timestamptz>happened THEN RETURN false;END IF;
 END IF;
 RETURN isfinite(happened);
EXCEPTION WHEN OTHERS THEN RETURN false;
END $$;
"""

INFERENCE_SQL=r"""
CREATE FUNCTION os_assert_inference_source(sid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE source_row personal_learning_sources%ROWTYPE; settings_row personal_learning_settings%ROWTYPE;
 command_row personal_learning_commands%ROWTYPE; origin_row personal_learning_source_origins%ROWTYPE;
 input_row os_source_inputs%ROWTYPE; permission jsonb;
BEGIN
 SELECT * INTO source_row FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO settings_row FROM personal_learning_settings WHERE id=source_row.settings_id;
 SELECT * INTO command_row FROM personal_learning_commands WHERE id=source_row.inference_consent_command_id;
 SELECT * INTO origin_row FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO input_row FROM os_source_inputs WHERE id=origin_row.input_id;
 permission=command_row.receipt->'settings'->'choice'->'inferenceConsent';
 IF source_row.id IS NULL OR source_row.authorization_basis IS DISTINCT FROM 'scoped-inference-turn/1'
  OR source_row.kind IS DISTINCT FROM 'accepted-user-turn/1' OR command_row.contract_ref IS DISTINCT FROM 'scoped-inference-consent/1'
  OR NOT COALESCE(os_inference_consent_valid(permission),false) OR permission->'enabled' IS DISTINCT FROM 'true'::jsonb
  OR permission->'revokedAt' IS DISTINCT FROM 'null'::jsonb OR permission->>'commandId' IS DISTINCT FROM command_row.command_id::text
  OR (command_row.receipt->'settings'->>'learningEpoch')::bigint>source_row.learning_epoch
  OR NOT COALESCE(permission->'purposes' ? source_row.inference_purpose,false)
  OR source_row.expires_at<>source_row.created_at+interval '14 days'
  OR input_row.id IS NULL OR input_row.created_at<(permission->>'grantedAt')::timestamptz
  OR source_row.created_at<(permission->>'grantedAt')::timestamptz
  OR NOT EXISTS(SELECT 1 FROM os_admissions a WHERE a.task_id=origin_row.task_id AND a.source_input_id=input_row.id
   AND a.authority->>'sessionId'=source_row.session_id::text AND a.context->>'accountingFormat'='agent-resources/1')
  THEN RAISE EXCEPTION 'inference_source_exact_grant';END IF;
 IF live THEN
  IF settings_row.inference_consent_command_id IS DISTINCT FROM command_row.id
   OR settings_row.choice->'inferenceConsent' IS DISTINCT FROM permission
   OR settings_row.choice->'learnConversation' IS DISTINCT FROM 'true'::jsonb
   OR settings_row.choice->>'extractorProfile' IS DISTINCT FROM 'keyword-inference/1'
   OR settings_row.learning_epoch<>source_row.learning_epoch OR source_row.state<>'AVAILABLE'
   OR source_row.expires_at<=clock_timestamp() THEN RAISE EXCEPTION 'inference_source_current_grant';END IF;
  PERFORM os_assert_learning_source_owner(sid,source_row.session_id);
 END IF;
END $$;

CREATE FUNCTION os_assert_inference_job(jid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE job_row personal_learning_jobs%ROWTYPE; snapshot_row classified_learning_job_snapshots%ROWTYPE;
 source_row personal_learning_sources%ROWTYPE; command_row personal_learning_commands%ROWTYPE; permission jsonb;
BEGIN
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=jid;
 SELECT * INTO snapshot_row FROM classified_learning_job_snapshots WHERE job_id=jid;
 SELECT s.* INTO source_row FROM personal_learning_sources s JOIN personal_learning_job_sources e ON e.source_id=s.id
  WHERE e.job_id=jid AND e.ordinal=1;
 IF job_row.profile_ref IS DISTINCT FROM 'keyword-inference/1' OR job_row.prompt_ref IS DISTINCT FROM 'owner-turn-inference/1'
  OR (SELECT count(*) FROM personal_learning_job_sources WHERE job_id=jid)<>1
  OR source_row.kind IS DISTINCT FROM 'accepted-user-turn/1' OR job_row.result_count>1
  THEN RAISE EXCEPTION 'inference_job_one_source';END IF;
 IF source_row.authorization_basis IS NULL THEN
  IF snapshot_row.inference_consent_command_id IS NOT NULL OR snapshot_row.inference_generation IS NOT NULL
   OR snapshot_row.inference_purpose IS NOT NULL THEN RAISE EXCEPTION 'inference_job_explicit_review_only';END IF;
 ELSIF source_row.authorization_basis='scoped-inference-turn/1' THEN
  PERFORM os_assert_inference_source(source_row.id,live);
  SELECT * INTO command_row FROM personal_learning_commands WHERE id=source_row.inference_consent_command_id;
  permission=command_row.receipt->'settings'->'choice'->'inferenceConsent';
  IF snapshot_row.inference_consent_command_id IS DISTINCT FROM source_row.inference_consent_command_id
   OR snapshot_row.inference_generation IS DISTINCT FROM (permission->>'generation')::bigint
   OR snapshot_row.inference_purpose IS DISTINCT FROM source_row.inference_purpose
   THEN RAISE EXCEPTION 'inference_job_grant_snapshot';END IF;
 ELSE RAISE EXCEPTION 'inference_job_separate_source_basis';END IF;
 IF live THEN PERFORM os_assert_learning_source_owner(source_row.id,source_row.session_id);END IF;
END $$;

CREATE FUNCTION os_assert_inference_publication(pid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE publication_row personal_knowledge_publications%ROWTYPE; candidate_row personal_knowledge_candidates%ROWTYPE;
 job_row personal_learning_jobs%ROWTYPE; snapshot_row classified_learning_job_snapshots%ROWTYPE;
 binding_row classified_knowledge_candidate_bindings%ROWTYPE; canonical_binding classified_knowledge_bindings%ROWTYPE;
 operation_row personal_knowledge_operations%ROWTYPE; source_row personal_learning_sources%ROWTYPE;
 command_row personal_learning_commands%ROWTYPE; permission jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO publication_row FROM personal_knowledge_publications WHERE id=pid;
 SELECT * INTO candidate_row FROM personal_knowledge_candidates WHERE id=publication_row.candidate_id;
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=candidate_row.job_id;
 SELECT * INTO snapshot_row FROM classified_learning_job_snapshots WHERE job_id=job_row.id;
 SELECT * INTO binding_row FROM classified_knowledge_candidate_bindings WHERE candidate_revision_id=publication_row.candidate_revision_id;
 SELECT * INTO canonical_binding FROM classified_knowledge_bindings WHERE revision_id=publication_row.revision_id;
 SELECT * INTO operation_row FROM personal_knowledge_operations WHERE id=publication_row.operation_id;
 SELECT * INTO command_row FROM personal_learning_commands WHERE id=publication_row.inference_consent_command_id;
 SELECT s.* INTO source_row FROM personal_learning_sources s JOIN personal_knowledge_candidate_sources e ON e.source_id=s.id
  WHERE e.candidate_id=candidate_row.id;
 permission=command_row.receipt->'settings'->'choice'->'inferenceConsent';
 IF publication_row.id IS NULL OR publication_row.authority_basis IS DISTINCT FROM 'standing-inference/1'
  OR publication_row.decision_id IS NOT NULL OR publication_row.epistemic IS DISTINCT FROM 'behavior-inferred'
  OR publication_row.operation IS DISTINCT FROM 'add' OR publication_row.target_count<>0
  OR EXISTS(SELECT 1 FROM personal_candidate_decisions WHERE candidate_id=candidate_row.id)
  OR candidate_row.state IS DISTINCT FROM 'ACCEPTED' OR candidate_row.version<>1 OR candidate_row.ordinal<>1
  OR job_row.state IS DISTINCT FROM 'SUCCEEDED' OR NOT job_row.provider_started OR job_row.usage IS NULL OR job_row.result_count<>1
  OR command_row.id IS NULL OR snapshot_row.inference_consent_command_id IS DISTINCT FROM command_row.id
  OR source_row.inference_consent_command_id IS DISTINCT FROM command_row.id
  OR operation_row.inference_consent_command_id IS DISTINCT FROM command_row.id
  OR operation_row.authority_basis IS DISTINCT FROM 'standing-inference/1' OR operation_row.kind IS DISTINCT FROM 'SAVE'
  OR operation_row.session_id IS DISTINCT FROM source_row.session_id OR operation_row.entry_id IS DISTINCT FROM publication_row.entry_id
  OR operation_row.expected_version<>0 OR operation_row.accepted_version<>1
  OR operation_row.context_revision<>snapshot_row.context_revision+1 OR operation_row.created_at<>publication_row.created_at
  OR publication_row.created_at>job_row.expires_at
  OR (SELECT count(*) FROM personal_knowledge_candidate_sources WHERE candidate_id=candidate_row.id)<>1
  OR NOT EXISTS(SELECT 1 FROM personal_learning_job_sources e WHERE e.job_id=job_row.id AND e.source_id=source_row.id AND e.source_revision=1)
  OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions r WHERE r.id=publication_row.revision_id
   AND r.operation_id=operation_row.id AND r.entry_id=publication_row.entry_id AND r.ordinal=1)
  OR canonical_binding.revision_id IS NULL OR binding_row.operation IS DISTINCT FROM 'add'
  OR binding_row.candidate_id IS DISTINCT FROM candidate_row.id OR canonical_binding.directed_source_id IS NOT NULL
  OR ROW(canonical_binding.content_kind,canonical_binding.context_id,canonical_binding.claim_key_id,canonical_binding.workflow_ref,canonical_binding.tool_refs)
   IS DISTINCT FROM ROW(binding_row.content_kind,binding_row.context_id,binding_row.claim_key_id,binding_row.workflow_ref,binding_row.tool_refs)
  OR NOT COALESCE(permission->'categories' ? binding_row.content_kind,false)
  OR binding_row.content_kind NOT IN ('personal-context','preference')
  OR EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets WHERE candidate_revision_id=binding_row.candidate_revision_id)
  THEN RAISE EXCEPTION 'inference_publication_exact_basis';END IF;
 PERFORM os_assert_inference_job(job_row.id,live);
 PERFORM os_assert_classified_candidate(publication_row.candidate_revision_id,live);
 IF live THEN
  IF candidate_row.expires_at<=clock_timestamp() OR job_row.expires_at<=clock_timestamp()
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE id=publication_row.candidate_revision_id AND envelope IS NOT NULL)
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions WHERE id=publication_row.revision_id AND envelope IS NOT NULL)
   THEN RAISE EXCEPTION 'inference_publication_current_payload';END IF;
 END IF;
END $$;

CREATE FUNCTION os_commit_inference_operation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE pid uuid;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NULL;END IF;
 IF NEW.authority_basis='standing-inference/1' THEN
  SELECT id INTO pid FROM personal_knowledge_publications WHERE operation_id=NEW.id AND authority_basis='standing-inference/1';
  IF pid IS NULL THEN RAISE EXCEPTION 'inference_operation_publication_required';END IF;
  PERFORM os_assert_inference_publication(pid,TG_OP='INSERT');
 END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_retained_entry_source(eid uuid,sid uuid) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_learning_sources s WHERE s.id=sid AND (
  s.authorization_basis='owner-directed-turn/1' AND EXISTS(SELECT 1 FROM classified_knowledge_bindings k WHERE k.entry_id=eid AND k.directed_source_id=sid)
  OR s.authorization_basis='scoped-inference-turn/1' AND EXISTS(SELECT 1 FROM personal_knowledge_publications p
   JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
   WHERE p.entry_id=eid AND e.source_id=sid)))
$$;
"""

# Populated during coherent draft preparation from frozen103 catalog definitions.
SCHEMA_SQL=r"""ALTER TABLE personal_learning_settings ADD COLUMN inference_consent_command_id UUID;
ALTER TABLE personal_learning_settings ADD CONSTRAINT fk_personal_learning_commands_inference_consent_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, inference_consent_command_id) REFERENCES personal_learning_commands (installation_id, application_id, tenant_id, subject_id, id) DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE personal_learning_commands ADD COLUMN contract_ref VARCHAR(64);
ALTER TABLE personal_learning_sources ADD COLUMN inference_consent_command_id UUID;
ALTER TABLE personal_learning_sources ADD COLUMN inference_purpose VARCHAR(64);
ALTER TABLE personal_learning_sources ADD CONSTRAINT fk_personal_learning_commands_inference_consent_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, inference_consent_command_id) REFERENCES personal_learning_commands (installation_id, application_id, tenant_id, subject_id, id);
ALTER TABLE classified_learning_job_snapshots ADD COLUMN inference_consent_command_id UUID;
ALTER TABLE classified_learning_job_snapshots ADD COLUMN inference_generation BIGINT;
ALTER TABLE classified_learning_job_snapshots ADD COLUMN inference_purpose VARCHAR(64);
ALTER TABLE classified_learning_job_snapshots ADD CONSTRAINT fk_personal_learning_commands_inference_consent_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, inference_consent_command_id) REFERENCES personal_learning_commands (installation_id, application_id, tenant_id, subject_id, id);
ALTER TABLE personal_knowledge_operations ADD COLUMN authority_basis VARCHAR(32);
ALTER TABLE personal_knowledge_operations ADD COLUMN inference_consent_command_id UUID;
ALTER TABLE personal_knowledge_operations ADD CONSTRAINT fk_personal_learning_commands_inference_consent_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, inference_consent_command_id) REFERENCES personal_learning_commands (installation_id, application_id, tenant_id, subject_id, id);
ALTER TABLE personal_knowledge_publications ADD COLUMN authority_basis VARCHAR(32);
ALTER TABLE personal_knowledge_publications ADD COLUMN inference_consent_command_id UUID;
ALTER TABLE personal_knowledge_publications ADD CONSTRAINT fk_personal_learning_commands_inference_consent_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, inference_consent_command_id) REFERENCES personal_learning_commands (installation_id, application_id, tenant_id, subject_id, id);
ALTER TABLE personal_learning_settings DROP CONSTRAINT ck_learning_settings_choice;
ALTER TABLE personal_learning_settings ADD CONSTRAINT ck_learning_settings_choice CHECK (COALESCE(jsonb_typeof(choice->'learnConversation')='boolean' AND jsonb_typeof(choice->'learnUsage')='boolean' AND jsonb_typeof(choice->'useMemory')='boolean' AND choice-'inferenceConsent'=jsonb_build_object('learnConversation',choice->'learnConversation','learnUsage',choice->'learnUsage','useMemory',choice->'useMemory','retentionProfile','private-local/1','extractorProfile',choice->'extractorProfile','embeddingProfile',choice->'embeddingProfile') AND choice->>'extractorProfile' IN ('synthetic-staging/1','classified-staging/2','keyword-inference/1') AND choice->>'embeddingProfile' IN ('synthetic-embedding/1','minilm-english-onnx/1','keyword-fts/1') AND (choice?'inferenceConsent')=(inference_consent_command_id IS NOT NULL) AND (NOT (choice?'inferenceConsent') OR os_inference_consent_valid(choice->'inferenceConsent')),false));
ALTER TABLE personal_learning_commands ADD CONSTRAINT ck_learning_command_contract CHECK (contract_ref IS NULL OR contract_ref='scoped-inference-consent/1');
ALTER TABLE personal_learning_sources DROP CONSTRAINT ck_learning_source_authorization_basis;
ALTER TABLE personal_learning_sources ADD CONSTRAINT ck_learning_source_authorization_basis CHECK (authorization_basis IS NULL OR (authorization_basis IN ('owner-directed-turn/1','scoped-inference-turn/1') AND kind='accepted-user-turn/1'));
ALTER TABLE personal_learning_sources ADD CONSTRAINT ck_learning_source_inference_grant CHECK ((authorization_basis IS NOT DISTINCT FROM 'scoped-inference-turn/1' AND inference_consent_command_id IS NOT NULL AND inference_purpose IS NOT NULL AND inference_purpose IN ('assistant.personalize/1','assistant.reflect/1')) OR (authorization_basis IS DISTINCT FROM 'scoped-inference-turn/1' AND inference_consent_command_id IS NULL AND inference_purpose IS NULL));
ALTER TABLE personal_learning_source_origins DROP CONSTRAINT ck_learning_source_origin_authorization;
ALTER TABLE personal_learning_source_origins ADD CONSTRAINT ck_learning_source_origin_authorization CHECK (authorization_basis IS NULL OR (authorization_basis IN ('owner-directed-turn/1','scoped-inference-turn/1') AND input_id IS NOT NULL AND result_id IS NULL));
ALTER TABLE personal_learning_source_intents DROP CONSTRAINT ck_learning_source_intent_profile;
ALTER TABLE personal_learning_source_intents ADD CONSTRAINT ck_learning_source_intent_profile CHECK (learning_epoch>0 AND extractor_ref IN ('synthetic-staging/1','classified-staging/2','keyword-inference/1') AND state IN ('PENDING_DISPATCH','CANCELLED') AND max_source_chars=8000 AND max_candidates=8);
ALTER TABLE personal_learning_jobs DROP CONSTRAINT ck_learning_job_profile;
ALTER TABLE personal_learning_jobs ADD CONSTRAINT ck_learning_job_profile CHECK (((profile_ref='synthetic-staging/1' AND prompt_ref IN ('mem0-2.2.1-owner-source/1','mem0-2.2.1-accepted-source/2','mem0-2.2.1-usage-source/3')) OR (profile_ref='classified-staging/2' AND prompt_ref='mem0-2.2.1-classified-source/4') OR (profile_ref='keyword-inference/1' AND prompt_ref='owner-turn-inference/1')) AND (restoration_id IS NULL AND source_mac IS NOT NULL AND mac_key_id IS NOT NULL AND source_mac ~ '^[a-f0-9]{64}$' OR restoration_id IS NOT NULL AND source_mac IS NULL AND mac_key_id IS NULL));
ALTER TABLE classified_learning_job_snapshots ADD CONSTRAINT ck_classified_job_inference CHECK ((inference_consent_command_id IS NULL AND inference_generation IS NULL AND inference_purpose IS NULL) OR (inference_consent_command_id IS NOT NULL AND inference_generation IS NOT NULL AND inference_generation>0 AND inference_purpose IS NOT NULL AND inference_purpose IN ('assistant.personalize/1','assistant.reflect/1')));
ALTER TABLE personal_knowledge_operations ADD CONSTRAINT ck_knowledge_operation_authority CHECK ((authority_basis IS NULL AND inference_consent_command_id IS NULL) OR (authority_basis IS NOT DISTINCT FROM 'standing-inference/1' AND inference_consent_command_id IS NOT NULL AND kind='SAVE'));
ALTER TABLE personal_knowledge_publications ADD CONSTRAINT ck_knowledge_publication_authority CHECK ((authority_basis IS NULL AND inference_consent_command_id IS NULL AND decision_id IS NOT NULL) OR (authority_basis IS NOT DISTINCT FROM 'standing-inference/1' AND inference_consent_command_id IS NOT NULL AND decision_id IS NULL AND operation='add' AND target_count=0 AND epistemic='behavior-inferred'));
ALTER TABLE personal_knowledge_publications ALTER COLUMN decision_id DROP NOT NULL;
"""
GUARDS_SQL=r"""CREATE OR REPLACE FUNCTION public.os_guard_learning_settings()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_settings_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.learning_epoch<>1 OR NEW.recall_epoch<>1 OR NEW.context_revision<>1
   OR NEW.index_generation<>1 OR NEW.created_at<>NEW.updated_at
   OR NEW.choice->'learnConversation'<>'false'::jsonb OR NEW.choice->'learnUsage'<>'false'::jsonb
   OR NEW.inference_consent_command_id IS NOT NULL OR NEW.choice?'inferenceConsent'
   OR NEW.choice->'useMemory'<>'false'::jsonb OR NEW.choice->>'embeddingProfile'<>'synthetic-embedding/1' THEN RAISE EXCEPTION 'learning_default_consent'; END IF;
 ELSIF EXISTS(SELECT 1 FROM memory_forget_batches b WHERE b.settings_id=OLD.id AND b.kind='all'
  AND ROW(b.expected_version,b.prior_learning_epoch,b.prior_recall_epoch,b.prior_context_revision,b.index_generation)
   =ROW(OLD.version,OLD.learning_epoch,OLD.recall_epoch,OLD.context_revision,OLD.index_generation)
  AND ROW(b.accepted_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.created_at)
   =ROW(NEW.version,NEW.learning_epoch,NEW.recall_epoch,NEW.context_revision,NEW.updated_at)) THEN
  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','context_revision','updated_at']) IS DISTINCT FROM
    (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','context_revision','updated_at'])
   THEN RAISE EXCEPTION 'memory_forget_all_settings_transition';END IF;
 ELSIF NEW.version=OLD.version AND NEW.index_generation<>OLD.index_generation THEN
  IF (to_jsonb(NEW)-ARRAY['index_generation','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['index_generation','updated_at'])
   OR NEW.index_generation<=OLD.index_generation OR NEW.updated_at<OLD.updated_at
   THEN RAISE EXCEPTION 'personal_index_activation_transition'; END IF;
 ELSIF NEW.version=OLD.version THEN
  IF (to_jsonb(NEW)-ARRAY['context_revision','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['context_revision','updated_at'])
   OR NEW.context_revision<>OLD.context_revision+1 OR NEW.updated_at<OLD.updated_at
   THEN RAISE EXCEPTION 'knowledge_context_transition'; END IF;
 ELSE
  IF (NEW.choice->'inferenceConsent') IS DISTINCT FROM (OLD.choice->'inferenceConsent') THEN
   IF NEW.inference_consent_command_id IS NULL OR NEW.inference_consent_command_id IS NOT DISTINCT FROM OLD.inference_consent_command_id
    OR (NEW.choice->'inferenceConsent'->>'generation')::bigint<>COALESCE((OLD.choice->'inferenceConsent'->>'generation')::bigint,0)+1
    OR (CASE WHEN NEW.choice->'inferenceConsent'->'enabled'='true'::jsonb THEN
      (NEW.choice->'inferenceConsent'->>'grantedAt')::timestamptz ELSE (NEW.choice->'inferenceConsent'->>'revokedAt')::timestamptz END)<OLD.updated_at
    OR (CASE WHEN NEW.choice->'inferenceConsent'->'enabled'='true'::jsonb THEN
      (NEW.choice->'inferenceConsent'->>'grantedAt')::timestamptz ELSE (NEW.choice->'inferenceConsent'->>'revokedAt')::timestamptz END)>NEW.updated_at+interval '1 second'
    OR (NEW.choice->'inferenceConsent'->'enabled'='true'::jsonb AND (NEW.choice->>'extractorProfile'<>'keyword-inference/1'
      OR NEW.choice->>'embeddingProfile'<>'keyword-fts/1' OR NEW.choice->'learnConversation'<>'true'::jsonb))
    OR (NEW.choice-ARRAY['inferenceConsent','learnConversation','extractorProfile']) IS DISTINCT FROM (OLD.choice-ARRAY['inferenceConsent','learnConversation','extractorProfile'])
    OR (NEW.choice->'inferenceConsent'->'enabled'='false'::jsonb AND ROW(NEW.choice->'learnConversation',NEW.choice->'extractorProfile') IS DISTINCT FROM ROW(OLD.choice->'learnConversation',OLD.choice->'extractorProfile'))
    OR (NEW.choice->'inferenceConsent'->'enabled'='false'::jsonb AND NEW.choice->'inferenceConsent'->'grantedAt'
       IS DISTINCT FROM COALESCE(OLD.choice->'inferenceConsent'->'grantedAt','null'::jsonb))
    THEN RAISE EXCEPTION 'inference_consent_transition';END IF;
  ELSIF NEW.inference_consent_command_id IS DISTINCT FROM OLD.inference_consent_command_id THEN
   RAISE EXCEPTION 'inference_consent_receipt_unchanged';
  END IF;
  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at','inference_consent_command_id'])
   IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at','inference_consent_command_id'])
   OR NEW.version<>OLD.version+1
   OR NEW.learning_epoch<>OLD.learning_epoch+(CASE WHEN (NEW.choice-'useMemory') IS DISTINCT FROM (OLD.choice-'useMemory') THEN 1 ELSE 0 END)
   OR NEW.recall_epoch<>OLD.recall_epoch+(CASE WHEN (NEW.choice-ARRAY['learnConversation','learnUsage'])
    IS DISTINCT FROM (OLD.choice-ARRAY['learnConversation','learnUsage']) THEN 1 ELSE 0 END)
   OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'learning_settings_transition'; END IF;
 END IF;
 RETURN NEW;
END $function$;
CREATE OR REPLACE FUNCTION public.os_guard_learning_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE s personal_learning_settings%ROWTYPE; c personal_learning_commands%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  s=NEW;
  IF EXISTS(SELECT 1 FROM memory_forget_batches b WHERE b.settings_id=s.id AND b.kind='all' AND b.accepted_version=s.version
   AND b.created_at=s.updated_at) THEN
   PERFORM os_assert_memory_forget_batch((SELECT id FROM memory_forget_batches WHERE settings_id=s.id
    AND kind='all' AND accepted_version=s.version AND created_at=s.updated_at),true);RETURN NULL;
  END IF;
  SELECT * INTO c FROM personal_learning_commands WHERE settings_id=s.id AND accepted_version=s.version;
 ELSE
  c=NEW;
  SELECT * INTO s FROM personal_learning_settings WHERE id=c.settings_id;
 END IF;
 IF c.id IS NULL OR s.id IS NULL OR c.accepted_version<>s.version OR c.created_at<>s.updated_at
  OR c.receipt IS DISTINCT FROM jsonb_build_object('commandId',c.command_id,'settings',os_learning_settings_payload(s))
 THEN RAISE EXCEPTION 'learning_atomic_receipt'; END IF;
 IF c.contract_ref='scoped-inference-consent/1' THEN
  IF s.inference_consent_command_id IS DISTINCT FROM c.id OR s.choice->'inferenceConsent'->>'commandId' IS DISTINCT FROM c.command_id::text
   THEN RAISE EXCEPTION 'inference_consent_exact_command';END IF;
 ELSIF c.id=s.inference_consent_command_id THEN RAISE EXCEPTION 'inference_consent_command_family';END IF;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=c.session_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=s.installation_id AND id=s.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
 THEN RAISE EXCEPTION 'learning_current_owner'; END IF;
 RETURN NULL;
END $function$;
CREATE OR REPLACE FUNCTION public.os_conversation_learning_source_current(sid uuid)
 RETURNS boolean
 LANGUAGE plpgsql
AS $function$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
 t os_tasks%ROWTYPE; segment os_segments%ROWTYPE; a os_artifacts%ROWTYPE; owner os_subjects%ROWTYPE;
 input os_source_inputs%ROWTYPE; result os_accepted_results%ROWTYPE; directed boolean;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF s.id IS NULL THEN RETURN false; END IF;
 directed=COALESCE(s.authorization_basis IN ('owner-directed-turn/1','scoped-inference-turn/1'),false);
 IF s.kind='owner-statement/1' THEN RETURN NOT EXISTS(SELECT 1 FROM personal_learning_source_origins WHERE source_id=sid); END IF;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO t FROM os_tasks WHERE id=o.task_id;
 SELECT * INTO segment FROM os_segments WHERE id=o.segment_id;
 SELECT * INTO a FROM os_artifacts WHERE id=o.artifact_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF o.id IS NULL OR o.authorization_basis IS DISTINCT FROM s.authorization_basis
  OR t.state IS DISTINCT FROM 'COMPLETED' OR t.version<>o.task_version
  OR segment.task_id<>t.id OR segment.state IS DISTINCT FROM 'FINISHED'
  OR NOT EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=t.id AND state='ACTIVE')
  OR owner.id IS NULL OR NOT owner.active OR (NOT directed AND owner.host_policy_generation<>o.policy_generation)
  OR a.id IS NULL OR (NOT directed AND a.expires_at<=clock_timestamp()) OR a.ciphertext_digest<>o.ciphertext_digest
  OR (NOT directed AND s.expires_at>a.expires_at) OR o.created_at<>s.created_at
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'name'='os.grounded/1')
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'type'='RUN_FINISHED') THEN RETURN false; END IF;
 IF o.input_id IS NOT NULL THEN
  SELECT * INTO input FROM os_source_inputs WHERE id=o.input_id;
  RETURN s.kind='accepted-user-turn/1' AND input.admitted_task_id=t.id AND input.artifact_id=a.id
   AND (directed OR (input.expires_at>clock_timestamp() AND s.expires_at<=input.expires_at))
   AND a.purpose='intent' AND a.classification='owner-private' AND o.occurred_at=input.created_at
   AND EXISTS(SELECT 1 FROM os_admissions WHERE task_id=t.id AND source_input_id=input.id AND segment_id=segment.id);
 ELSE
  SELECT * INTO result FROM os_accepted_results WHERE id=o.result_id;
  RETURN s.kind='accepted-outcome/1' AND result.task_id=t.id AND result.segment_id=segment.id
   AND result.artifact_id=a.id AND result.ciphertext_digest=a.ciphertext_digest AND result.contract_ref='ReadStageResult'
   AND a.purpose='artifact' AND a.classification='protected' AND o.occurred_at=result.created_at
   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=result.attempt_id AND state='SETTLED');
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_learning_source(sid uuid)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE s personal_learning_sources%ROWTYPE; j personal_learning_source_intents%ROWTYPE;
 f personal_learning_source_forgets%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF os_restoration_erased('personal_learning_sources',to_jsonb(s)) THEN
  RETURN;
 END IF;

 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
 SELECT * INTO j FROM personal_learning_source_intents WHERE source_id=sid;
 SELECT * INTO f FROM personal_learning_source_forgets WHERE source_id=sid;
 IF s.id IS NULL OR settings.id IS NULL OR j.id IS NULL OR j.learning_epoch<>s.learning_epoch
  OR j.created_at<>s.created_at OR j.extractor_ref NOT IN ('synthetic-staging/1','classified-staging/2','keyword-inference/1')
  OR s.receipt IS DISTINCT FROM jsonb_build_object('commandId',s.command_id,'sourceId',s.id,
   'revision',1,'learningEpoch',s.learning_epoch,'extractionState',CASE WHEN s.authorization_basis='owner-directed-turn/1' THEN 'DIRECTED_ONLY' ELSE 'PENDING_DISPATCH' END)
  THEN RAISE EXCEPTION 'learning_source_atomic_intent'; END IF;
 IF s.authorization_basis='owner-directed-turn/1' THEN PERFORM os_assert_directed_memory_source(sid); END IF;
 IF s.authorization_basis='scoped-inference-turn/1' THEN PERFORM os_assert_inference_source(sid,false);END IF;
 IF s.state='AVAILABLE' THEN
  IF f.id IS NOT NULL OR s.envelope IS NULL THEN RAISE EXCEPTION 'learning_source_live'; END IF;
 ELSE
  IF f.id IS NULL OR j.state<>'CANCELLED' OR f.learning_epoch<>s.learning_epoch OR f.created_at<>s.updated_at
   OR f.receipt IS DISTINCT FROM jsonb_build_object('commandId',f.command_id,'operationId',f.id,
    'sourceId',s.id,'revision',2,'state','FORGOTTEN')
   OR (f.completed_at IS NULL AND s.envelope IS NULL)
   OR (f.completed_at IS NOT NULL AND (s.envelope IS NOT NULL OR s.request_mac IS NOT NULL OR s.mac_key_id IS NOT NULL))
   THEN RAISE EXCEPTION 'learning_source_forget_atomic'; END IF;
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_guard_learning_source_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE sid uuid; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_TABLE_NAME='personal_learning_sources' THEN
  sid=NEW.id;
  IF TG_OP='INSERT' THEN
   SELECT * INTO settings FROM personal_learning_settings WHERE id=NEW.settings_id;
   IF (NEW.authorization_basis IS DISTINCT FROM 'owner-directed-turn/1' AND settings.choice->(CASE WHEN NEW.kind='usage-event/2' THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb)
    OR settings.learning_epoch<>NEW.learning_epoch OR NEW.expires_at<=clock_timestamp()
    OR (SELECT count(*) FROM personal_learning_sources WHERE settings_id=NEW.settings_id AND state='AVAILABLE')>64
    THEN RAISE EXCEPTION 'learning_source_consent_capacity'; END IF;
   IF NEW.kind<>'usage-event/2' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id); END IF;
   IF NEW.authorization_basis='scoped-inference-turn/1' THEN PERFORM os_assert_inference_source(sid,true);END IF;
   IF NEW.authorization_basis IN ('owner-directed-turn/1','scoped-inference-turn/1') AND NOT EXISTS(SELECT 1 FROM personal_learning_source_origins o
    JOIN os_source_inputs i ON i.id=o.input_id JOIN os_artifacts a ON a.id=o.artifact_id
    WHERE o.source_id=sid AND i.expires_at>clock_timestamp() AND a.expires_at>clock_timestamp())
    THEN RAISE EXCEPTION 'directed_memory_source_expired_before_save'; END IF;
  END IF;
 ELSE
  sid=NEW.source_id;
  IF TG_TABLE_NAME='personal_learning_source_forgets' THEN
   IF TG_OP='INSERT' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
   ELSE PERFORM os_assert_learning_source_owner(sid,NEW.cleanup_session_id); END IF;
  END IF;
 END IF;
 PERFORM os_assert_learning_source(sid);
 IF TG_TABLE_NAME='personal_learning_sources' AND TG_OP='INSERT' AND NOT COALESCE(os_selected_learning_source_current(sid),false)
  THEN RAISE EXCEPTION 'selected_learning_source_binding'; END IF;
 RETURN NULL;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_classified_job(jid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE job_row personal_learning_jobs%ROWTYPE; snapshot_row classified_learning_job_snapshots%ROWTYPE;
 settings_row personal_learning_settings%ROWTYPE; app_row os_applications%ROWTYPE;
 contexts jsonb; claim_keys jsonb; tools jsonb;
BEGIN
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=jid;
 SELECT * INTO snapshot_row FROM classified_learning_job_snapshots WHERE job_id=jid;
 SELECT * INTO settings_row FROM personal_learning_settings WHERE id=job_row.settings_id;
 IF NOT ((job_row.profile_ref='classified-staging/2' AND job_row.prompt_ref='mem0-2.2.1-classified-source/4')
   OR (job_row.profile_ref='keyword-inference/1' AND job_row.prompt_ref='owner-turn-inference/1'))
  OR snapshot_row.job_id IS NULL OR snapshot_row.settings_id<>job_row.settings_id OR snapshot_row.created_at<>job_row.created_at
  OR ROW(snapshot_row.installation_id,snapshot_row.application_id,snapshot_row.tenant_id,snapshot_row.subject_id)
   IS DISTINCT FROM ROW(job_row.installation_id,job_row.application_id,job_row.tenant_id,job_row.subject_id)
  OR (SELECT count(*) FROM classified_learning_job_memory_refs WHERE job_id=jid)>64
  OR EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row JOIN personal_knowledge_revisions revision_row
   ON revision_row.id=ref_row.revision_id WHERE ref_row.job_id=jid AND revision_row.entry_id<>ref_row.entry_id)
  THEN RAISE EXCEPTION 'classified_job_snapshot_binding'; END IF;
 IF job_row.profile_ref='keyword-inference/1' THEN PERFORM os_assert_inference_job(jid,live);
 ELSIF snapshot_row.inference_consent_command_id IS NOT NULL OR snapshot_row.inference_generation IS NOT NULL
   OR snapshot_row.inference_purpose IS NOT NULL THEN RAISE EXCEPTION 'classified_job_unexpected_grant';END IF;
 IF live THEN
  SELECT * INTO app_row FROM os_applications WHERE installation_id=job_row.installation_id AND id=job_row.application_id;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',id,'revision',version) ORDER BY id),'[]'::jsonb) INTO contexts
   FROM owner_memory_contexts WHERE installation_id=job_row.installation_id AND application_id=job_row.application_id
    AND tenant_id=job_row.tenant_id AND subject_id=job_row.subject_id AND state='ACTIVE' AND kind='context';
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',id,'revision',version) ORDER BY id),'[]'::jsonb) INTO claim_keys
   FROM owner_memory_contexts WHERE installation_id=job_row.installation_id AND application_id=job_row.application_id
    AND tenant_id=job_row.tenant_id AND subject_id=job_row.subject_id AND state='ACTIVE' AND kind='claim-key';
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',capability->'descriptor'->'id','revision',capability->'descriptor'->'revision')
   ORDER BY (capability->'descriptor'->>'id') COLLATE "C",(capability->'descriptor'->>'revision')::bigint),'[]'::jsonb) INTO tools
   FROM os_registrations registration_row CROSS JOIN LATERAL jsonb_array_elements(registration_row.payload->'capabilities') capability
   WHERE registration_row.installation_id=job_row.installation_id AND registration_row.application_id=job_row.application_id
    AND registration_row.revision=app_row.revision AND capability->'descriptor'->>'kind'='read';
  IF NOT (snapshot_row.context_revision=settings_row.context_revision OR job_row.profile_ref='keyword-inference/1'
    AND snapshot_row.context_revision+1=settings_row.context_revision AND EXISTS(SELECT 1 FROM personal_knowledge_publications p
     JOIN personal_knowledge_candidates c ON c.id=p.candidate_id JOIN personal_knowledge_operations o ON o.id=p.operation_id
     WHERE c.job_id=jid AND p.authority_basis='standing-inference/1' AND o.context_revision=settings_row.context_revision)) OR snapshot_row.context_refs IS DISTINCT FROM contexts
   OR snapshot_row.claim_key_refs IS DISTINCT FROM claim_keys OR snapshot_row.tool_refs IS DISTINCT FROM tools
   OR EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row JOIN personal_knowledge_entries entry_row
    ON entry_row.id=ref_row.entry_id WHERE ref_row.job_id=jid
     AND (entry_row.version<>ref_row.entry_version OR entry_row.active_revision_id<>ref_row.revision_id
      OR NOT os_classified_memory_current(entry_row.id)))
   OR EXISTS(SELECT 1 FROM personal_knowledge_entries entry_row WHERE entry_row.installation_id=job_row.installation_id
    AND entry_row.application_id=job_row.application_id AND entry_row.tenant_id=job_row.tenant_id AND entry_row.subject_id=job_row.subject_id
    AND os_classified_memory_current(entry_row.id)
    AND NOT EXISTS(SELECT 1 FROM personal_knowledge_publications p JOIN personal_knowledge_candidates c ON c.id=p.candidate_id
     WHERE c.job_id=jid AND p.entry_id=entry_row.id AND p.authority_basis='standing-inference/1') AND NOT EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row
     WHERE ref_row.job_id=jid AND ref_row.entry_id=entry_row.id))
   THEN RAISE EXCEPTION 'classified_job_current_snapshot'; END IF;
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_learning_job_live(j personal_learning_jobs)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE s personal_learning_settings%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=j.installation_id AND id=j.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=j.installation_id AND application_id=j.application_id
  AND tenant_id=j.tenant_id AND subject_id=j.subject_id;
 IF s.id IS NULL OR s.learning_epoch<>j.learning_epoch OR s.choice->(CASE WHEN os_learning_job_usage(j.id) THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb
  OR s.choice->>'extractorProfile'<>j.profile_ref OR app.id IS NULL OR NOT app.active OR owner.id IS NULL OR NOT owner.active
  OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
  OR j.expires_at<=clock_timestamp() OR j.account_valid_until<=clock_timestamp()
  OR j.account_checked_at<clock_timestamp()-interval '5 seconds'
  OR j.account_checked_at>clock_timestamp()+interval '5 seconds'
  OR NOT EXISTS(SELECT 1 FROM personal_learning_job_sources WHERE job_id=j.id)
  OR EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id
   JOIN personal_learning_source_intents i ON i.id=e.intent_id WHERE e.job_id=j.id
    AND (r.settings_id<>j.settings_id OR r.state<>'AVAILABLE' OR r.revision<>e.source_revision
     OR r.learning_epoch<>j.learning_epoch OR r.expires_at<=clock_timestamp() OR r.envelope IS NULL
     OR i.source_id<>r.id OR i.learning_epoch<>j.learning_epoch OR i.state<>'PENDING_DISPATCH'
     OR i.extractor_ref<>j.profile_ref OR i.due_at>j.created_at
     OR NOT COALESCE(os_selected_learning_source_current(r.id),false)
     OR (j.prompt_ref='mem0-2.2.1-owner-source/1' AND r.kind<>'owner-statement/1')
     OR (j.prompt_ref='mem0-2.2.1-accepted-source/2' AND r.kind NOT IN ('accepted-user-turn/1','accepted-outcome/1'))
     OR (os_learning_job_usage(j.id) AND r.kind<>'usage-event/2')))
  OR (SELECT count(DISTINCT r.kind) FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id WHERE e.job_id=j.id)<>1
 OR (os_learning_job_usage(j.id) AND NOT COALESCE(os_usage_batch_current(j.id),false))
 THEN RAISE EXCEPTION 'learning_job_current_authority'; END IF;
 IF j.profile_ref IN ('classified-staging/2','keyword-inference/1') THEN PERFORM os_assert_classified_job(j.id,true); END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_classified_candidate(rid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE binding_row classified_knowledge_candidate_bindings%ROWTYPE; revision_row personal_knowledge_candidate_revisions%ROWTYPE;
 candidate_row personal_knowledge_candidates%ROWTYPE; job_row personal_learning_jobs%ROWTYPE;
 snapshot_row classified_learning_job_snapshots%ROWTYPE; decision_row personal_candidate_decisions%ROWTYPE;
 target_count bigint; registration_row os_registrations%ROWTYPE; app_row os_applications%ROWTYPE;
BEGIN
 SELECT * INTO binding_row FROM classified_knowledge_candidate_bindings WHERE candidate_revision_id=rid;
 SELECT * INTO revision_row FROM personal_knowledge_candidate_revisions WHERE id=rid;
 SELECT * INTO candidate_row FROM personal_knowledge_candidates WHERE id=revision_row.candidate_id;
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=candidate_row.job_id;
 SELECT * INTO snapshot_row FROM classified_learning_job_snapshots WHERE job_id=job_row.id;
 SELECT * INTO decision_row FROM personal_candidate_decisions WHERE candidate_revision_id=rid;
 SELECT count(*) INTO target_count FROM classified_knowledge_candidate_targets WHERE candidate_revision_id=rid;
 IF binding_row.candidate_revision_id IS NULL OR binding_row.candidate_id<>candidate_row.id OR binding_row.job_id<>job_row.id
  OR job_row.profile_ref NOT IN ('classified-staging/2','keyword-inference/1') OR job_row.state IS DISTINCT FROM 'SUCCEEDED'
  OR binding_row.created_at<>revision_row.created_at OR snapshot_row.job_id IS NULL
  OR (revision_row.ordinal=1 AND binding_row.expected_context_revision<>snapshot_row.context_revision)
  OR NOT ((binding_row.operation='add' AND target_count=0) OR (binding_row.operation IN ('supersede','forget') AND target_count=1)
   OR (binding_row.operation='merge' AND target_count BETWEEN 2 AND 8))
  OR EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row JOIN personal_knowledge_revisions knowledge_revision
   ON knowledge_revision.id=target_row.revision_id WHERE target_row.candidate_revision_id=rid AND knowledge_revision.entry_id<>target_row.entry_id)
  OR (revision_row.ordinal=1 AND EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row
   WHERE target_row.candidate_revision_id=rid AND NOT EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row
    WHERE ref_row.job_id=job_row.id AND ROW(ref_row.entry_id,ref_row.revision_id,ref_row.entry_version)
     =ROW(target_row.entry_id,target_row.revision_id,target_row.expected_entry_version))))
  THEN RAISE EXCEPTION 'classified_candidate_binding'; END IF;
 IF live THEN
  IF (binding_row.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts context_row
    WHERE context_row.id=binding_row.context_id AND context_row.state='ACTIVE' AND context_row.kind='context'
     AND context_row.version=binding_row.context_version))
   OR (binding_row.claim_key_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts context_row
    WHERE context_row.id=binding_row.claim_key_id AND context_row.state='ACTIVE' AND context_row.kind='claim-key'
     AND context_row.version=binding_row.claim_key_version))
   OR EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row JOIN personal_knowledge_entries entry_row
    ON entry_row.id=target_row.entry_id WHERE target_row.candidate_revision_id=rid AND NOT (
     (entry_row.version=target_row.expected_entry_version AND entry_row.active_revision_id=target_row.revision_id
      AND os_classified_memory_current(entry_row.id))
     OR (decision_row.id IS NOT NULL AND decision_row.decision<>'reject' AND EXISTS(SELECT 1 FROM personal_knowledge_supersessions supersession_row
      JOIN personal_knowledge_publications publication_row ON publication_row.id=supersession_row.publication_id
      WHERE publication_row.decision_id=decision_row.id AND supersession_row.entry_id=entry_row.id
       AND supersession_row.revision_id=target_row.revision_id AND supersession_row.expected_version=target_row.expected_entry_version
       AND supersession_row.accepted_version=entry_row.version AND entry_row.state='SUPERSEDED'))
     OR (decision_row.id IS NOT NULL AND decision_row.decision<>'reject' AND EXISTS(SELECT 1 FROM personal_knowledge_retractions retraction_row
      WHERE retraction_row.decision_id=decision_row.id AND retraction_row.entry_id=entry_row.id
       AND retraction_row.expected_entry_version=target_row.expected_entry_version
       AND retraction_row.accepted_entry_version=entry_row.version AND entry_row.state='FORGOTTEN'))))
   THEN RAISE EXCEPTION 'classified_candidate_current_references'; END IF;
  SELECT * INTO app_row FROM os_applications WHERE installation_id=candidate_row.installation_id AND id=candidate_row.application_id;
  SELECT * INTO registration_row FROM os_registrations WHERE installation_id=app_row.installation_id
   AND application_id=app_row.id AND revision=app_row.revision;
  IF EXISTS(SELECT 1 FROM jsonb_array_elements(binding_row.tool_refs) tool WHERE NOT EXISTS(
   SELECT 1 FROM jsonb_array_elements(registration_row.payload->'capabilities') capability
    WHERE capability->'descriptor'->>'kind'='read' AND capability->'descriptor'->>'id'=tool->>'id'
     AND capability->'descriptor'->'revision'=tool->'revision'))
   THEN RAISE EXCEPTION 'classified_candidate_current_tools'; END IF;
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_candidate_decision(did uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE profile text;
BEGIN
 SELECT job_row.profile_ref INTO profile FROM personal_candidate_decisions decision_row
  JOIN personal_knowledge_candidates candidate_row ON candidate_row.id=decision_row.candidate_id
  JOIN personal_learning_jobs job_row ON job_row.id=candidate_row.job_id WHERE decision_row.id=did;
 IF profile IN ('classified-staging/2','keyword-inference/1') THEN PERFORM os_assert_classified_candidate_decision(did,live);
 ELSE PERFORM os_assert_legacy_candidate_decision(did,live); END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_classified_candidate_decision(did uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE d personal_candidate_decisions%ROWTYPE; c personal_knowledge_candidates%ROWTYPE;
 r personal_knowledge_candidate_revisions%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 s personal_learning_settings%ROWTYPE; p personal_knowledge_publications%ROWTYPE;
 op personal_knowledge_operations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; expected jsonb; retraction_row personal_knowledge_retractions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO d FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=d.candidate_id;
 SELECT * INTO r FROM personal_knowledge_candidate_revisions WHERE id=d.candidate_revision_id;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO p FROM personal_knowledge_publications WHERE decision_id=d.id;
 SELECT * INTO retraction_row FROM personal_knowledge_retractions WHERE decision_id=d.id;
 IF d.id IS NULL OR c.id IS NULL OR r.id IS NULL OR j.state IS DISTINCT FROM 'SUCCEEDED' OR s.id IS NULL
  OR r.candidate_id<>c.id OR r.ordinal<>d.accepted_version OR c.version<>d.accepted_version
  OR c.state<>(CASE WHEN d.decision='reject' THEN 'REJECTED' ELSE 'ACCEPTED' END)
  OR c.updated_at<>d.created_at OR d.context_revision>s.context_revision
  OR (r.envelope IS NULL AND NOT os_candidate_erasure_allowed(c.id))
  THEN RAISE EXCEPTION 'candidate_decision_binding'; END IF;
 PERFORM os_assert_classified_candidate(r.id,live AND d.decision<>'reject');
 PERFORM os_assert_classified_publication(d.id);
 IF d.decision='reject' THEN
  IF p.id IS NOT NULL OR retraction_row.id IS NOT NULL THEN RAISE EXCEPTION 'candidate_rejection_publication'; END IF;
  expected='null'::jsonb;
 ELSE
  IF retraction_row.id IS NOT NULL THEN
   SELECT * INTO op FROM personal_knowledge_operations WHERE id=retraction_row.operation_id;
  ELSE
  SELECT * INTO op FROM personal_knowledge_operations WHERE id=p.operation_id;
  IF p.id IS NULL OR p.candidate_id<>c.id OR p.candidate_revision_id<>r.id OR p.created_at<>d.created_at
   OR op.id IS NULL OR op.kind<>'SAVE' OR op.entry_id<>p.entry_id OR op.command_id<>d.command_id
   OR op.session_id<>d.session_id OR op.context_revision<>d.context_revision OR op.created_at<>d.created_at
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions kr WHERE kr.id=p.revision_id AND kr.entry_id=p.entry_id AND kr.operation_id=op.id)
   OR (SELECT count(*) FROM personal_knowledge_supersessions WHERE publication_id=p.id)<>p.target_count
   THEN RAISE EXCEPTION 'candidate_atomic_publication'; END IF;
  IF p.epistemic IS DISTINCT FROM (CASE WHEN d.decision='edit-and-accept' THEN 'user-stated'
    WHEN os_learning_job_usage(j.id) OR j.profile_ref='keyword-inference/1' THEN 'behavior-inferred'
    WHEN EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources source_row ON source_row.id=e.source_id
     WHERE e.job_id=j.id AND source_row.kind='accepted-outcome/1') THEN 'derived-outcome' ELSE 'user-stated' END)
   THEN RAISE EXCEPTION 'candidate_epistemic_origin'; END IF;
  END IF;
  expected=op.receipt;
 END IF;
 IF d.receipt IS DISTINCT FROM jsonb_build_object('commandId',d.command_id,'decisionId',d.id,'candidateId',c.id,
  'candidateRevision',c.version,'state',c.state,'contextRevision',d.context_revision,'knowledge',expected)
  THEN RAISE EXCEPTION 'candidate_atomic_receipt'; END IF;
 IF live THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE id=d.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=d.installation_id AND application_id=d.application_id
   AND tenant_id=d.tenant_id AND subject_id=d.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp() OR d.request_mac IS NULL
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation OR owner.id IS NULL
   OR NOT owner.active OR owner.generation<>session.subject_generation OR c.expires_at<=clock_timestamp()
   OR os_learning_candidate_invalid(c.id) THEN RAISE EXCEPTION 'candidate_current_review'; END IF;
  IF d.decision<>'reject' THEN
   IF s.context_revision<>d.context_revision OR s.updated_at<>d.created_at OR s.learning_epoch<>j.learning_epoch
    OR s.choice->(CASE WHEN os_learning_job_usage(j.id) THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb OR s.choice->>'extractorProfile'<>j.profile_ref
    OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
     IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
    THEN RAISE EXCEPTION 'candidate_current_learning'; END IF;
   PERFORM os_assert_knowledge_entry(COALESCE(p.entry_id,retraction_row.entry_id),true);
  END IF;
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_guard_learning_candidate_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE cid uuid; c personal_knowledge_candidates%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 n bigint; d personal_candidate_decisions%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_knowledge_candidates' THEN cid=NEW.id;ELSE cid=NEW.candidate_id;END IF;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=cid;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT count(*) INTO n FROM personal_knowledge_candidate_sources WHERE candidate_id=cid;
 IF c.id IS NULL OR j.state<>'SUCCEEDED' OR c.ordinal>j.result_count OR n NOT BETWEEN 1 AND 20
  OR NOT EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND ordinal=c.version)
  OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e WHERE e.candidate_id=cid AND NOT EXISTS(
   SELECT 1 FROM personal_learning_job_sources r WHERE r.job_id=j.id AND r.source_id=e.source_id AND r.source_revision=e.source_revision))
  THEN RAISE EXCEPTION 'learning_candidate_atomic_provenance'; END IF;

 IF j.profile_ref IN ('classified-staging/2','keyword-inference/1') THEN
  IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions revision_row WHERE revision_row.candidate_id=cid
   AND NOT EXISTS(SELECT 1 FROM classified_knowledge_candidate_bindings binding_row WHERE binding_row.candidate_revision_id=revision_row.id))
   THEN RAISE EXCEPTION 'classified_candidate_revision_binding_missing'; END IF;
 END IF;
 IF c.state='ACCEPTED' AND EXISTS(SELECT 1 FROM personal_knowledge_publications p
  WHERE p.candidate_id=c.id AND p.authority_basis='standing-inference/1') THEN
  IF EXISTS(SELECT 1 FROM personal_candidate_decisions WHERE candidate_id=c.id) THEN RAISE EXCEPTION 'inference_no_owner_decision';END IF;
  IF os_candidate_erasure_allowed(cid) AND EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL) THEN
   IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
    THEN RAISE EXCEPTION 'inference_candidate_cleanup_incomplete';END IF;
   PERFORM os_assert_inference_publication((SELECT id FROM personal_knowledge_publications WHERE candidate_id=cid),false);
  ELSE PERFORM os_assert_inference_publication((SELECT id FROM personal_knowledge_publications WHERE candidate_id=cid),true);END IF;
 ELSIF c.state IN ('ACCEPTED','REJECTED') THEN
  SELECT * INTO d FROM personal_candidate_decisions WHERE candidate_id=c.id;
  IF d.id IS NULL THEN RAISE EXCEPTION 'candidate_decision_missing'; END IF;
  IF os_candidate_erasure_allowed(cid) AND EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL) THEN
   IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
    OR d.request_mac IS NOT NULL THEN RAISE EXCEPTION 'candidate_cleanup_incomplete'; END IF;
   PERFORM os_assert_candidate_decision(d.id,false);
  ELSE PERFORM os_assert_candidate_decision(d.id,true);END IF;
 ELSIF TG_OP='INSERT' THEN
  IF c.state<>'PENDING_REVIEW' OR c.version<>1 OR c.created_at<>j.updated_at
   OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL)
   THEN RAISE EXCEPTION 'learning_candidate_result_binding'; END IF;
  PERFORM os_assert_learning_job_live(j);
 ELSE
  IF c.state<>'INVALIDATED' OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
   THEN RAISE EXCEPTION 'learning_candidate_cleanup_incomplete'; END IF;
 END IF;
 RETURN NULL;
END $function$;
CREATE OR REPLACE FUNCTION public.os_guard_publication_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE did uuid; p personal_knowledge_publications%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_TABLE_NAME='personal_candidate_decisions' THEN did=NEW.id;
 ELSIF TG_TABLE_NAME='personal_knowledge_publications' THEN
  IF NEW.authority_basis='standing-inference/1' THEN PERFORM os_assert_inference_publication(NEW.id,TG_OP='INSERT');RETURN NULL;END IF;
  did=NEW.decision_id;
 ELSE
  SELECT * INTO p FROM personal_knowledge_publications WHERE id=NEW.publication_id;did=p.decision_id;
  PERFORM os_assert_knowledge_supersession(NEW.entry_id,true);
 END IF;
 PERFORM os_assert_candidate_decision(did,TG_OP='INSERT');RETURN NULL;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_memory_forget_batch(bid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE b memory_forget_batches%ROWTYPE; s personal_learning_settings%ROWTYPE; watermark memory_recovery_owners%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
 entry_refs jsonb; source_refs jsonb; context_refs jsonb; ne bigint; ns bigint; nc bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM memory_forget_batches WHERE id=bid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO watermark FROM memory_recovery_owners WHERE settings_id=b.settings_id;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',entry_id,'revision',expected_version) ORDER BY entry_id),'[]'::jsonb),count(*)
  INTO entry_refs,ne FROM memory_forget_entries WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',source_id,'revision',expected_version) ORDER BY source_id),'[]'::jsonb),count(*)
  INTO source_refs,ns FROM memory_forget_sources WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',context_id,'revision',expected_version) ORDER BY context_id),'[]'::jsonb),count(*)
  INTO context_refs,nc FROM memory_forget_contexts WHERE batch_id=bid;
 IF b.id IS NULL OR s.id IS NULL OR watermark.settings_id IS NULL OR watermark.journal_id<>b.journal_id
  OR watermark.sequence<b.journal_sequence OR watermark.owner_epoch<b.owner_epoch OR ne>64 OR ns>64 OR nc>64
  OR (b.kind='entry' AND (ne<>1 OR ns>1 OR nc<>0
   OR EXISTS(SELECT 1 FROM memory_forget_sources m WHERE m.batch_id=bid
    AND NOT EXISTS(SELECT 1 FROM memory_forget_entries e WHERE e.batch_id=bid AND os_retained_entry_source(e.entry_id,m.source_id)))
   OR EXISTS(SELECT 1 FROM memory_forget_entries e JOIN personal_learning_sources d ON os_retained_entry_source(e.entry_id,d.id)
    WHERE e.batch_id=bid AND d.state='AVAILABLE'))) OR (b.kind='source' AND (ne<>0 OR ns<>1 OR nc<>0))
  OR b.request IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'kind',b.kind,'settingsId',s.id,
   'expectedRevision',b.expected_version,'learningEpoch',b.prior_learning_epoch,'recallEpoch',b.prior_recall_epoch,
   'contextRevision',b.prior_context_revision,'entryRefs',entry_refs,'sourceRefs',source_refs,'contextRefs',context_refs)
  OR b.receipt IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'operationId',b.id,'kind',b.kind,
   'settings',jsonb_build_object('revision',b.accepted_version,'learningEpoch',b.learning_epoch,'recallEpoch',b.recall_epoch,
    'contextRevision',b.context_revision,'indexGeneration',b.index_generation,'choice',b.receipt->'settings'->'choice'),
   'forgotten',jsonb_build_object('entries',ne,'sources',ns,'contexts',nc))
  THEN RAISE EXCEPTION 'memory_forget_exact_receipt';END IF;
 IF EXISTS(SELECT 1 FROM memory_forget_entries m JOIN personal_knowledge_entries e ON e.id=m.entry_id
  JOIN personal_knowledge_operations operation ON operation.id=m.operation_id WHERE m.batch_id=bid
   AND (e.settings_id<>b.settings_id OR e.state<>'FORGOTTEN' OR e.version<>m.accepted_version
    OR operation.forget_batch_id IS DISTINCT FROM bid OR operation.kind<>'FORGET' OR operation.entry_id<>m.entry_id
    OR operation.expected_version<>m.expected_version OR operation.accepted_version<>m.accepted_version
    OR operation.context_revision<>b.context_revision OR operation.created_at<>b.created_at
    OR operation.session_id<>b.session_id))
  OR EXISTS(SELECT 1 FROM personal_knowledge_operations operation WHERE operation.forget_batch_id=bid AND NOT EXISTS(
   SELECT 1 FROM memory_forget_entries m WHERE m.batch_id=bid AND m.operation_id=operation.id AND m.entry_id=operation.entry_id))
  OR EXISTS(SELECT 1 FROM memory_forget_sources m JOIN personal_learning_sources source ON source.id=m.source_id
   JOIN personal_learning_source_forgets f ON f.id=m.forget_id WHERE m.batch_id=bid
    AND (source.settings_id<>b.settings_id OR source.state<>'FORGOTTEN' OR source.revision<>m.accepted_version
     OR f.source_id<>m.source_id OR f.session_id<>b.session_id OR f.created_at<>b.created_at))
  OR EXISTS(SELECT 1 FROM memory_forget_contexts m JOIN owner_memory_contexts c ON c.id=m.context_id WHERE m.batch_id=bid
   AND (c.settings_id<>b.settings_id OR c.state<>'FORGOTTEN' OR c.version<>m.accepted_version
    OR c.context_revision<>b.context_revision OR c.updated_at<>b.created_at OR c.envelope IS NOT NULL))
  THEN RAISE EXCEPTION 'memory_forget_exact_members';END IF;
 IF live THEN
  IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation,s.updated_at)
   IS DISTINCT FROM ROW(b.accepted_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation,b.created_at)
   AND b.kind<>'source' THEN RAISE EXCEPTION 'memory_forget_current_settings';END IF;
  IF b.receipt->'settings' IS DISTINCT FROM os_learning_settings_payload(s)
   OR watermark.sequence<>b.journal_sequence OR watermark.owner_epoch<>b.owner_epoch OR watermark.updated_at<>b.created_at
   THEN RAISE EXCEPTION 'memory_forget_current_watermark';END IF;
  IF b.kind='all' AND (EXISTS(SELECT 1 FROM personal_knowledge_entries WHERE settings_id=b.settings_id AND state<>'FORGOTTEN')
   OR EXISTS(SELECT 1 FROM personal_learning_sources WHERE settings_id=b.settings_id AND state='AVAILABLE')
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state<>'FORGOTTEN'))
   THEN RAISE EXCEPTION 'memory_forget_all_members';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_current_owner';END IF;
 END IF;
 IF b.completed_at IS NOT NULL THEN
  IF EXISTS(SELECT 1 FROM personal_forget_journal WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_source_forgets WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state='FORGOTTEN' AND envelope IS NOT NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_context_commands command JOIN owner_memory_contexts context ON context.id=command.context_id
    WHERE context.settings_id=b.settings_id AND context.state='FORGOTTEN' AND command.request_mac IS NOT NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_jobs WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND state IN ('QUEUED','RUNNING'))
   THEN RAISE EXCEPTION 'memory_forget_cleanup_incomplete';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.cleanup_session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR NOT app.active OR app.generation<>session.application_generation
   OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_cleanup_owner';END IF;
 END IF;
END $function$;
"""


def upgrade():
    op.execute(CONSENT_SQL)
    op.execute(SCHEMA_SQL)
    op.execute(INFERENCE_SQL)
    op.execute(GUARDS_SQL)
    op.execute('CREATE CONSTRAINT TRIGGER commit_inference_operation AFTER INSERT OR UPDATE ON personal_knowledge_operations '
        'DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_inference_operation()')


def downgrade():
    op.execute('DROP TRIGGER commit_inference_operation ON personal_knowledge_operations')
    op.execute(r"""CREATE OR REPLACE FUNCTION public.os_guard_learning_settings()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_settings_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.learning_epoch<>1 OR NEW.recall_epoch<>1 OR NEW.context_revision<>1
   OR NEW.index_generation<>1 OR NEW.created_at<>NEW.updated_at
   OR NEW.choice->'learnConversation'<>'false'::jsonb OR NEW.choice->'learnUsage'<>'false'::jsonb
   OR NEW.choice->'useMemory'<>'false'::jsonb OR NEW.choice->>'embeddingProfile'<>'synthetic-embedding/1' THEN RAISE EXCEPTION 'learning_default_consent'; END IF;
 ELSIF EXISTS(SELECT 1 FROM memory_forget_batches b WHERE b.settings_id=OLD.id AND b.kind='all'
  AND ROW(b.expected_version,b.prior_learning_epoch,b.prior_recall_epoch,b.prior_context_revision,b.index_generation)
   =ROW(OLD.version,OLD.learning_epoch,OLD.recall_epoch,OLD.context_revision,OLD.index_generation)
  AND ROW(b.accepted_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.created_at)
   =ROW(NEW.version,NEW.learning_epoch,NEW.recall_epoch,NEW.context_revision,NEW.updated_at)) THEN
  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','context_revision','updated_at']) IS DISTINCT FROM
    (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','context_revision','updated_at'])
   THEN RAISE EXCEPTION 'memory_forget_all_settings_transition';END IF;
 ELSIF NEW.version=OLD.version AND NEW.index_generation<>OLD.index_generation THEN
  IF (to_jsonb(NEW)-ARRAY['index_generation','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['index_generation','updated_at'])
   OR NEW.index_generation<=OLD.index_generation OR NEW.updated_at<OLD.updated_at
   THEN RAISE EXCEPTION 'personal_index_activation_transition'; END IF;
 ELSIF NEW.version=OLD.version THEN
  IF (to_jsonb(NEW)-ARRAY['context_revision','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['context_revision','updated_at'])
   OR NEW.context_revision<>OLD.context_revision+1 OR NEW.updated_at<OLD.updated_at
   THEN RAISE EXCEPTION 'knowledge_context_transition'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])
   IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])
   OR NEW.version<>OLD.version+1
   OR NEW.learning_epoch<>OLD.learning_epoch+(CASE WHEN (NEW.choice-'useMemory') IS DISTINCT FROM (OLD.choice-'useMemory') THEN 1 ELSE 0 END)
   OR NEW.recall_epoch<>OLD.recall_epoch+(CASE WHEN (NEW.choice-ARRAY['learnConversation','learnUsage'])
    IS DISTINCT FROM (OLD.choice-ARRAY['learnConversation','learnUsage']) THEN 1 ELSE 0 END)
   OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'learning_settings_transition'; END IF;
 END IF;
 RETURN NEW;
END $function$;
CREATE OR REPLACE FUNCTION public.os_guard_learning_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE s personal_learning_settings%ROWTYPE; c personal_learning_commands%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  s=NEW;
  IF EXISTS(SELECT 1 FROM memory_forget_batches b WHERE b.settings_id=s.id AND b.kind='all' AND b.accepted_version=s.version
   AND b.created_at=s.updated_at) THEN
   PERFORM os_assert_memory_forget_batch((SELECT id FROM memory_forget_batches WHERE settings_id=s.id
    AND kind='all' AND accepted_version=s.version AND created_at=s.updated_at),true);RETURN NULL;
  END IF;
  SELECT * INTO c FROM personal_learning_commands WHERE settings_id=s.id AND accepted_version=s.version;
 ELSE
  c=NEW;
  SELECT * INTO s FROM personal_learning_settings WHERE id=c.settings_id;
 END IF;
 IF c.id IS NULL OR s.id IS NULL OR c.accepted_version<>s.version OR c.created_at<>s.updated_at
  OR c.receipt IS DISTINCT FROM jsonb_build_object('commandId',c.command_id,'settings',os_learning_settings_payload(s))
 THEN RAISE EXCEPTION 'learning_atomic_receipt'; END IF;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=c.session_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=s.installation_id AND id=s.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
 THEN RAISE EXCEPTION 'learning_current_owner'; END IF;
 RETURN NULL;
END $function$;
CREATE OR REPLACE FUNCTION public.os_conversation_learning_source_current(sid uuid)
 RETURNS boolean
 LANGUAGE plpgsql
AS $function$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
 t os_tasks%ROWTYPE; segment os_segments%ROWTYPE; a os_artifacts%ROWTYPE; owner os_subjects%ROWTYPE;
 input os_source_inputs%ROWTYPE; result os_accepted_results%ROWTYPE; directed boolean;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF s.id IS NULL THEN RETURN false; END IF;
 directed=COALESCE(s.authorization_basis='owner-directed-turn/1',false);
 IF s.kind='owner-statement/1' THEN RETURN NOT EXISTS(SELECT 1 FROM personal_learning_source_origins WHERE source_id=sid); END IF;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO t FROM os_tasks WHERE id=o.task_id;
 SELECT * INTO segment FROM os_segments WHERE id=o.segment_id;
 SELECT * INTO a FROM os_artifacts WHERE id=o.artifact_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF o.id IS NULL OR o.authorization_basis IS DISTINCT FROM s.authorization_basis
  OR t.state IS DISTINCT FROM 'COMPLETED' OR t.version<>o.task_version
  OR segment.task_id<>t.id OR segment.state IS DISTINCT FROM 'FINISHED'
  OR NOT EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=t.id AND state='ACTIVE')
  OR owner.id IS NULL OR NOT owner.active OR (NOT directed AND owner.host_policy_generation<>o.policy_generation)
  OR a.id IS NULL OR (NOT directed AND a.expires_at<=clock_timestamp()) OR a.ciphertext_digest<>o.ciphertext_digest
  OR (NOT directed AND s.expires_at>a.expires_at) OR o.created_at<>s.created_at
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'name'='os.grounded/1')
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'type'='RUN_FINISHED') THEN RETURN false; END IF;
 IF o.input_id IS NOT NULL THEN
  SELECT * INTO input FROM os_source_inputs WHERE id=o.input_id;
  RETURN s.kind='accepted-user-turn/1' AND input.admitted_task_id=t.id AND input.artifact_id=a.id
   AND (directed OR (input.expires_at>clock_timestamp() AND s.expires_at<=input.expires_at))
   AND a.purpose='intent' AND a.classification='owner-private' AND o.occurred_at=input.created_at
   AND EXISTS(SELECT 1 FROM os_admissions WHERE task_id=t.id AND source_input_id=input.id AND segment_id=segment.id);
 ELSE
  SELECT * INTO result FROM os_accepted_results WHERE id=o.result_id;
  RETURN s.kind='accepted-outcome/1' AND result.task_id=t.id AND result.segment_id=segment.id
   AND result.artifact_id=a.id AND result.ciphertext_digest=a.ciphertext_digest AND result.contract_ref='ReadStageResult'
   AND a.purpose='artifact' AND a.classification='protected' AND o.occurred_at=result.created_at
   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=result.attempt_id AND state='SETTLED');
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_learning_source(sid uuid)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE s personal_learning_sources%ROWTYPE; j personal_learning_source_intents%ROWTYPE;
 f personal_learning_source_forgets%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF os_restoration_erased('personal_learning_sources',to_jsonb(s)) THEN
  RETURN;
 END IF;

 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
 SELECT * INTO j FROM personal_learning_source_intents WHERE source_id=sid;
 SELECT * INTO f FROM personal_learning_source_forgets WHERE source_id=sid;
 IF s.id IS NULL OR settings.id IS NULL OR j.id IS NULL OR j.learning_epoch<>s.learning_epoch
  OR j.created_at<>s.created_at OR j.extractor_ref NOT IN ('synthetic-staging/1','classified-staging/2')
  OR s.receipt IS DISTINCT FROM jsonb_build_object('commandId',s.command_id,'sourceId',s.id,
   'revision',1,'learningEpoch',s.learning_epoch,'extractionState',CASE WHEN s.authorization_basis='owner-directed-turn/1' THEN 'DIRECTED_ONLY' ELSE 'PENDING_DISPATCH' END)
  THEN RAISE EXCEPTION 'learning_source_atomic_intent'; END IF;
 IF s.authorization_basis='owner-directed-turn/1' THEN PERFORM os_assert_directed_memory_source(sid); END IF;
 IF s.state='AVAILABLE' THEN
  IF f.id IS NOT NULL OR s.envelope IS NULL THEN RAISE EXCEPTION 'learning_source_live'; END IF;
 ELSE
  IF f.id IS NULL OR j.state<>'CANCELLED' OR f.learning_epoch<>s.learning_epoch OR f.created_at<>s.updated_at
   OR f.receipt IS DISTINCT FROM jsonb_build_object('commandId',f.command_id,'operationId',f.id,
    'sourceId',s.id,'revision',2,'state','FORGOTTEN')
   OR (f.completed_at IS NULL AND s.envelope IS NULL)
   OR (f.completed_at IS NOT NULL AND (s.envelope IS NOT NULL OR s.request_mac IS NOT NULL OR s.mac_key_id IS NOT NULL))
   THEN RAISE EXCEPTION 'learning_source_forget_atomic'; END IF;
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_guard_learning_source_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE sid uuid; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_TABLE_NAME='personal_learning_sources' THEN
  sid=NEW.id;
  IF TG_OP='INSERT' THEN
   SELECT * INTO settings FROM personal_learning_settings WHERE id=NEW.settings_id;
   IF (NEW.authorization_basis IS DISTINCT FROM 'owner-directed-turn/1' AND settings.choice->(CASE WHEN NEW.kind='usage-event/2' THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb)
    OR settings.learning_epoch<>NEW.learning_epoch OR NEW.expires_at<=clock_timestamp()
    OR (SELECT count(*) FROM personal_learning_sources WHERE settings_id=NEW.settings_id AND state='AVAILABLE')>64
    THEN RAISE EXCEPTION 'learning_source_consent_capacity'; END IF;
   IF NEW.kind<>'usage-event/2' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id); END IF;
   IF NEW.authorization_basis='owner-directed-turn/1' AND NOT EXISTS(SELECT 1 FROM personal_learning_source_origins o
    JOIN os_source_inputs i ON i.id=o.input_id JOIN os_artifacts a ON a.id=o.artifact_id
    WHERE o.source_id=sid AND i.expires_at>clock_timestamp() AND a.expires_at>clock_timestamp())
    THEN RAISE EXCEPTION 'directed_memory_source_expired_before_save'; END IF;
  END IF;
 ELSE
  sid=NEW.source_id;
  IF TG_TABLE_NAME='personal_learning_source_forgets' THEN
   IF TG_OP='INSERT' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
   ELSE PERFORM os_assert_learning_source_owner(sid,NEW.cleanup_session_id); END IF;
  END IF;
 END IF;
 PERFORM os_assert_learning_source(sid);
 IF TG_TABLE_NAME='personal_learning_sources' AND TG_OP='INSERT' AND NOT COALESCE(os_selected_learning_source_current(sid),false)
  THEN RAISE EXCEPTION 'selected_learning_source_binding'; END IF;
 RETURN NULL;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_classified_job(jid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE job_row personal_learning_jobs%ROWTYPE; snapshot_row classified_learning_job_snapshots%ROWTYPE;
 settings_row personal_learning_settings%ROWTYPE; app_row os_applications%ROWTYPE;
 contexts jsonb; claim_keys jsonb; tools jsonb;
BEGIN
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=jid;
 SELECT * INTO snapshot_row FROM classified_learning_job_snapshots WHERE job_id=jid;
 SELECT * INTO settings_row FROM personal_learning_settings WHERE id=job_row.settings_id;
 IF job_row.profile_ref IS DISTINCT FROM 'classified-staging/2' OR job_row.prompt_ref IS DISTINCT FROM 'mem0-2.2.1-classified-source/4'
  OR snapshot_row.job_id IS NULL OR snapshot_row.settings_id<>job_row.settings_id OR snapshot_row.created_at<>job_row.created_at
  OR ROW(snapshot_row.installation_id,snapshot_row.application_id,snapshot_row.tenant_id,snapshot_row.subject_id)
   IS DISTINCT FROM ROW(job_row.installation_id,job_row.application_id,job_row.tenant_id,job_row.subject_id)
  OR (SELECT count(*) FROM classified_learning_job_memory_refs WHERE job_id=jid)>64
  OR EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row JOIN personal_knowledge_revisions revision_row
   ON revision_row.id=ref_row.revision_id WHERE ref_row.job_id=jid AND revision_row.entry_id<>ref_row.entry_id)
  THEN RAISE EXCEPTION 'classified_job_snapshot_binding'; END IF;
 IF live THEN
  SELECT * INTO app_row FROM os_applications WHERE installation_id=job_row.installation_id AND id=job_row.application_id;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',id,'revision',version) ORDER BY id),'[]'::jsonb) INTO contexts
   FROM owner_memory_contexts WHERE installation_id=job_row.installation_id AND application_id=job_row.application_id
    AND tenant_id=job_row.tenant_id AND subject_id=job_row.subject_id AND state='ACTIVE' AND kind='context';
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',id,'revision',version) ORDER BY id),'[]'::jsonb) INTO claim_keys
   FROM owner_memory_contexts WHERE installation_id=job_row.installation_id AND application_id=job_row.application_id
    AND tenant_id=job_row.tenant_id AND subject_id=job_row.subject_id AND state='ACTIVE' AND kind='claim-key';
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',capability->'descriptor'->'id','revision',capability->'descriptor'->'revision')
   ORDER BY (capability->'descriptor'->>'id') COLLATE "C",(capability->'descriptor'->>'revision')::bigint),'[]'::jsonb) INTO tools
   FROM os_registrations registration_row CROSS JOIN LATERAL jsonb_array_elements(registration_row.payload->'capabilities') capability
   WHERE registration_row.installation_id=job_row.installation_id AND registration_row.application_id=job_row.application_id
    AND registration_row.revision=app_row.revision AND capability->'descriptor'->>'kind'='read';
  IF snapshot_row.context_revision<>settings_row.context_revision OR snapshot_row.context_refs IS DISTINCT FROM contexts
   OR snapshot_row.claim_key_refs IS DISTINCT FROM claim_keys OR snapshot_row.tool_refs IS DISTINCT FROM tools
   OR EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row JOIN personal_knowledge_entries entry_row
    ON entry_row.id=ref_row.entry_id WHERE ref_row.job_id=jid
     AND (entry_row.version<>ref_row.entry_version OR entry_row.active_revision_id<>ref_row.revision_id
      OR NOT os_classified_memory_current(entry_row.id)))
   OR EXISTS(SELECT 1 FROM personal_knowledge_entries entry_row WHERE entry_row.installation_id=job_row.installation_id
    AND entry_row.application_id=job_row.application_id AND entry_row.tenant_id=job_row.tenant_id AND entry_row.subject_id=job_row.subject_id
    AND os_classified_memory_current(entry_row.id) AND NOT EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row
     WHERE ref_row.job_id=jid AND ref_row.entry_id=entry_row.id))
   THEN RAISE EXCEPTION 'classified_job_current_snapshot'; END IF;
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_learning_job_live(j personal_learning_jobs)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE s personal_learning_settings%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=j.installation_id AND id=j.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=j.installation_id AND application_id=j.application_id
  AND tenant_id=j.tenant_id AND subject_id=j.subject_id;
 IF s.id IS NULL OR s.learning_epoch<>j.learning_epoch OR s.choice->(CASE WHEN os_learning_job_usage(j.id) THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb
  OR s.choice->>'extractorProfile'<>j.profile_ref OR app.id IS NULL OR NOT app.active OR owner.id IS NULL OR NOT owner.active
  OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
  OR j.expires_at<=clock_timestamp() OR j.account_valid_until<=clock_timestamp()
  OR j.account_checked_at<clock_timestamp()-interval '5 seconds'
  OR j.account_checked_at>clock_timestamp()+interval '5 seconds'
  OR NOT EXISTS(SELECT 1 FROM personal_learning_job_sources WHERE job_id=j.id)
  OR EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id
   JOIN personal_learning_source_intents i ON i.id=e.intent_id WHERE e.job_id=j.id
    AND (r.settings_id<>j.settings_id OR r.state<>'AVAILABLE' OR r.revision<>e.source_revision
     OR r.learning_epoch<>j.learning_epoch OR r.expires_at<=clock_timestamp() OR r.envelope IS NULL
     OR i.source_id<>r.id OR i.learning_epoch<>j.learning_epoch OR i.state<>'PENDING_DISPATCH'
     OR i.extractor_ref<>j.profile_ref OR i.due_at>j.created_at
     OR NOT COALESCE(os_selected_learning_source_current(r.id),false)
     OR (j.prompt_ref='mem0-2.2.1-owner-source/1' AND r.kind<>'owner-statement/1')
     OR (j.prompt_ref='mem0-2.2.1-accepted-source/2' AND r.kind NOT IN ('accepted-user-turn/1','accepted-outcome/1'))
     OR (os_learning_job_usage(j.id) AND r.kind<>'usage-event/2')))
  OR (SELECT count(DISTINCT r.kind) FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id WHERE e.job_id=j.id)<>1
 OR (os_learning_job_usage(j.id) AND NOT COALESCE(os_usage_batch_current(j.id),false))
 THEN RAISE EXCEPTION 'learning_job_current_authority'; END IF;
 IF j.profile_ref='classified-staging/2' THEN PERFORM os_assert_classified_job(j.id,true); END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_classified_candidate(rid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE binding_row classified_knowledge_candidate_bindings%ROWTYPE; revision_row personal_knowledge_candidate_revisions%ROWTYPE;
 candidate_row personal_knowledge_candidates%ROWTYPE; job_row personal_learning_jobs%ROWTYPE;
 snapshot_row classified_learning_job_snapshots%ROWTYPE; decision_row personal_candidate_decisions%ROWTYPE;
 target_count bigint; registration_row os_registrations%ROWTYPE; app_row os_applications%ROWTYPE;
BEGIN
 SELECT * INTO binding_row FROM classified_knowledge_candidate_bindings WHERE candidate_revision_id=rid;
 SELECT * INTO revision_row FROM personal_knowledge_candidate_revisions WHERE id=rid;
 SELECT * INTO candidate_row FROM personal_knowledge_candidates WHERE id=revision_row.candidate_id;
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=candidate_row.job_id;
 SELECT * INTO snapshot_row FROM classified_learning_job_snapshots WHERE job_id=job_row.id;
 SELECT * INTO decision_row FROM personal_candidate_decisions WHERE candidate_revision_id=rid;
 SELECT count(*) INTO target_count FROM classified_knowledge_candidate_targets WHERE candidate_revision_id=rid;
 IF binding_row.candidate_revision_id IS NULL OR binding_row.candidate_id<>candidate_row.id OR binding_row.job_id<>job_row.id
  OR job_row.profile_ref IS DISTINCT FROM 'classified-staging/2' OR job_row.state IS DISTINCT FROM 'SUCCEEDED'
  OR binding_row.created_at<>revision_row.created_at OR snapshot_row.job_id IS NULL
  OR (revision_row.ordinal=1 AND binding_row.expected_context_revision<>snapshot_row.context_revision)
  OR NOT ((binding_row.operation='add' AND target_count=0) OR (binding_row.operation IN ('supersede','forget') AND target_count=1)
   OR (binding_row.operation='merge' AND target_count BETWEEN 2 AND 8))
  OR EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row JOIN personal_knowledge_revisions knowledge_revision
   ON knowledge_revision.id=target_row.revision_id WHERE target_row.candidate_revision_id=rid AND knowledge_revision.entry_id<>target_row.entry_id)
  OR (revision_row.ordinal=1 AND EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row
   WHERE target_row.candidate_revision_id=rid AND NOT EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row
    WHERE ref_row.job_id=job_row.id AND ROW(ref_row.entry_id,ref_row.revision_id,ref_row.entry_version)
     =ROW(target_row.entry_id,target_row.revision_id,target_row.expected_entry_version))))
  THEN RAISE EXCEPTION 'classified_candidate_binding'; END IF;
 IF live THEN
  IF (binding_row.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts context_row
    WHERE context_row.id=binding_row.context_id AND context_row.state='ACTIVE' AND context_row.kind='context'
     AND context_row.version=binding_row.context_version))
   OR (binding_row.claim_key_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts context_row
    WHERE context_row.id=binding_row.claim_key_id AND context_row.state='ACTIVE' AND context_row.kind='claim-key'
     AND context_row.version=binding_row.claim_key_version))
   OR EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row JOIN personal_knowledge_entries entry_row
    ON entry_row.id=target_row.entry_id WHERE target_row.candidate_revision_id=rid AND NOT (
     (entry_row.version=target_row.expected_entry_version AND entry_row.active_revision_id=target_row.revision_id
      AND os_classified_memory_current(entry_row.id))
     OR (decision_row.id IS NOT NULL AND decision_row.decision<>'reject' AND EXISTS(SELECT 1 FROM personal_knowledge_supersessions supersession_row
      JOIN personal_knowledge_publications publication_row ON publication_row.id=supersession_row.publication_id
      WHERE publication_row.decision_id=decision_row.id AND supersession_row.entry_id=entry_row.id
       AND supersession_row.revision_id=target_row.revision_id AND supersession_row.expected_version=target_row.expected_entry_version
       AND supersession_row.accepted_version=entry_row.version AND entry_row.state='SUPERSEDED'))
     OR (decision_row.id IS NOT NULL AND decision_row.decision<>'reject' AND EXISTS(SELECT 1 FROM personal_knowledge_retractions retraction_row
      WHERE retraction_row.decision_id=decision_row.id AND retraction_row.entry_id=entry_row.id
       AND retraction_row.expected_entry_version=target_row.expected_entry_version
       AND retraction_row.accepted_entry_version=entry_row.version AND entry_row.state='FORGOTTEN'))))
   THEN RAISE EXCEPTION 'classified_candidate_current_references'; END IF;
  SELECT * INTO app_row FROM os_applications WHERE installation_id=candidate_row.installation_id AND id=candidate_row.application_id;
  SELECT * INTO registration_row FROM os_registrations WHERE installation_id=app_row.installation_id
   AND application_id=app_row.id AND revision=app_row.revision;
  IF EXISTS(SELECT 1 FROM jsonb_array_elements(binding_row.tool_refs) tool WHERE NOT EXISTS(
   SELECT 1 FROM jsonb_array_elements(registration_row.payload->'capabilities') capability
    WHERE capability->'descriptor'->>'kind'='read' AND capability->'descriptor'->>'id'=tool->>'id'
     AND capability->'descriptor'->'revision'=tool->'revision'))
   THEN RAISE EXCEPTION 'classified_candidate_current_tools'; END IF;
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_candidate_decision(did uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE profile text;
BEGIN
 SELECT job_row.profile_ref INTO profile FROM personal_candidate_decisions decision_row
  JOIN personal_knowledge_candidates candidate_row ON candidate_row.id=decision_row.candidate_id
  JOIN personal_learning_jobs job_row ON job_row.id=candidate_row.job_id WHERE decision_row.id=did;
 IF profile='classified-staging/2' THEN PERFORM os_assert_classified_candidate_decision(did,live);
 ELSE PERFORM os_assert_legacy_candidate_decision(did,live); END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_classified_candidate_decision(did uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE d personal_candidate_decisions%ROWTYPE; c personal_knowledge_candidates%ROWTYPE;
 r personal_knowledge_candidate_revisions%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 s personal_learning_settings%ROWTYPE; p personal_knowledge_publications%ROWTYPE;
 op personal_knowledge_operations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; expected jsonb; retraction_row personal_knowledge_retractions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO d FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=d.candidate_id;
 SELECT * INTO r FROM personal_knowledge_candidate_revisions WHERE id=d.candidate_revision_id;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO p FROM personal_knowledge_publications WHERE decision_id=d.id;
 SELECT * INTO retraction_row FROM personal_knowledge_retractions WHERE decision_id=d.id;
 IF d.id IS NULL OR c.id IS NULL OR r.id IS NULL OR j.state IS DISTINCT FROM 'SUCCEEDED' OR s.id IS NULL
  OR r.candidate_id<>c.id OR r.ordinal<>d.accepted_version OR c.version<>d.accepted_version
  OR c.state<>(CASE WHEN d.decision='reject' THEN 'REJECTED' ELSE 'ACCEPTED' END)
  OR c.updated_at<>d.created_at OR d.context_revision>s.context_revision
  OR (r.envelope IS NULL AND NOT os_candidate_erasure_allowed(c.id))
  THEN RAISE EXCEPTION 'candidate_decision_binding'; END IF;
 PERFORM os_assert_classified_candidate(r.id,live AND d.decision<>'reject');
 PERFORM os_assert_classified_publication(d.id);
 IF d.decision='reject' THEN
  IF p.id IS NOT NULL OR retraction_row.id IS NOT NULL THEN RAISE EXCEPTION 'candidate_rejection_publication'; END IF;
  expected='null'::jsonb;
 ELSE
  IF retraction_row.id IS NOT NULL THEN
   SELECT * INTO op FROM personal_knowledge_operations WHERE id=retraction_row.operation_id;
  ELSE
  SELECT * INTO op FROM personal_knowledge_operations WHERE id=p.operation_id;
  IF p.id IS NULL OR p.candidate_id<>c.id OR p.candidate_revision_id<>r.id OR p.created_at<>d.created_at
   OR op.id IS NULL OR op.kind<>'SAVE' OR op.entry_id<>p.entry_id OR op.command_id<>d.command_id
   OR op.session_id<>d.session_id OR op.context_revision<>d.context_revision OR op.created_at<>d.created_at
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions kr WHERE kr.id=p.revision_id AND kr.entry_id=p.entry_id AND kr.operation_id=op.id)
   OR (SELECT count(*) FROM personal_knowledge_supersessions WHERE publication_id=p.id)<>p.target_count
   THEN RAISE EXCEPTION 'candidate_atomic_publication'; END IF;
  IF p.epistemic IS DISTINCT FROM (CASE WHEN d.decision='edit-and-accept' THEN 'user-stated'
    WHEN os_learning_job_usage(j.id) THEN 'behavior-inferred'
    WHEN EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources source_row ON source_row.id=e.source_id
     WHERE e.job_id=j.id AND source_row.kind='accepted-outcome/1') THEN 'derived-outcome' ELSE 'user-stated' END)
   THEN RAISE EXCEPTION 'candidate_epistemic_origin'; END IF;
  END IF;
  expected=op.receipt;
 END IF;
 IF d.receipt IS DISTINCT FROM jsonb_build_object('commandId',d.command_id,'decisionId',d.id,'candidateId',c.id,
  'candidateRevision',c.version,'state',c.state,'contextRevision',d.context_revision,'knowledge',expected)
  THEN RAISE EXCEPTION 'candidate_atomic_receipt'; END IF;
 IF live THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE id=d.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=d.installation_id AND application_id=d.application_id
   AND tenant_id=d.tenant_id AND subject_id=d.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp() OR d.request_mac IS NULL
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation OR owner.id IS NULL
   OR NOT owner.active OR owner.generation<>session.subject_generation OR c.expires_at<=clock_timestamp()
   OR os_learning_candidate_invalid(c.id) THEN RAISE EXCEPTION 'candidate_current_review'; END IF;
  IF d.decision<>'reject' THEN
   IF s.context_revision<>d.context_revision OR s.updated_at<>d.created_at OR s.learning_epoch<>j.learning_epoch
    OR s.choice->(CASE WHEN os_learning_job_usage(j.id) THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb OR s.choice->>'extractorProfile'<>j.profile_ref
    OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
     IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
    THEN RAISE EXCEPTION 'candidate_current_learning'; END IF;
   PERFORM os_assert_knowledge_entry(COALESCE(p.entry_id,retraction_row.entry_id),true);
  END IF;
 END IF;
END $function$;
CREATE OR REPLACE FUNCTION public.os_guard_learning_candidate_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE cid uuid; c personal_knowledge_candidates%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 n bigint; d personal_candidate_decisions%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_knowledge_candidates' THEN cid=NEW.id;ELSE cid=NEW.candidate_id;END IF;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=cid;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT count(*) INTO n FROM personal_knowledge_candidate_sources WHERE candidate_id=cid;
 IF c.id IS NULL OR j.state<>'SUCCEEDED' OR c.ordinal>j.result_count OR n NOT BETWEEN 1 AND 20
  OR NOT EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND ordinal=c.version)
  OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e WHERE e.candidate_id=cid AND NOT EXISTS(
   SELECT 1 FROM personal_learning_job_sources r WHERE r.job_id=j.id AND r.source_id=e.source_id AND r.source_revision=e.source_revision))
  THEN RAISE EXCEPTION 'learning_candidate_atomic_provenance'; END IF;

 IF j.profile_ref='classified-staging/2' THEN
  IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions revision_row WHERE revision_row.candidate_id=cid
   AND NOT EXISTS(SELECT 1 FROM classified_knowledge_candidate_bindings binding_row WHERE binding_row.candidate_revision_id=revision_row.id))
   THEN RAISE EXCEPTION 'classified_candidate_revision_binding_missing'; END IF;
 END IF;
 IF c.state IN ('ACCEPTED','REJECTED') THEN
  SELECT * INTO d FROM personal_candidate_decisions WHERE candidate_id=c.id;
  IF d.id IS NULL THEN RAISE EXCEPTION 'candidate_decision_missing'; END IF;
  IF os_candidate_erasure_allowed(cid) AND EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL) THEN
   IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
    OR d.request_mac IS NOT NULL THEN RAISE EXCEPTION 'candidate_cleanup_incomplete'; END IF;
   PERFORM os_assert_candidate_decision(d.id,false);
  ELSE PERFORM os_assert_candidate_decision(d.id,true);END IF;
 ELSIF TG_OP='INSERT' THEN
  IF c.state<>'PENDING_REVIEW' OR c.version<>1 OR c.created_at<>j.updated_at
   OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL)
   THEN RAISE EXCEPTION 'learning_candidate_result_binding'; END IF;
  PERFORM os_assert_learning_job_live(j);
 ELSE
  IF c.state<>'INVALIDATED' OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
   THEN RAISE EXCEPTION 'learning_candidate_cleanup_incomplete'; END IF;
 END IF;
 RETURN NULL;
END $function$;
CREATE OR REPLACE FUNCTION public.os_guard_publication_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE did uuid; p personal_knowledge_publications%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_TABLE_NAME='personal_candidate_decisions' THEN did=NEW.id;
 ELSIF TG_TABLE_NAME='personal_knowledge_publications' THEN did=NEW.decision_id;
 ELSE
  SELECT * INTO p FROM personal_knowledge_publications WHERE id=NEW.publication_id;did=p.decision_id;
  PERFORM os_assert_knowledge_supersession(NEW.entry_id,true);
 END IF;
 PERFORM os_assert_candidate_decision(did,TG_OP='INSERT');RETURN NULL;
END $function$;
CREATE OR REPLACE FUNCTION public.os_assert_memory_forget_batch(bid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE b memory_forget_batches%ROWTYPE; s personal_learning_settings%ROWTYPE; watermark memory_recovery_owners%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
 entry_refs jsonb; source_refs jsonb; context_refs jsonb; ne bigint; ns bigint; nc bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM memory_forget_batches WHERE id=bid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO watermark FROM memory_recovery_owners WHERE settings_id=b.settings_id;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',entry_id,'revision',expected_version) ORDER BY entry_id),'[]'::jsonb),count(*)
  INTO entry_refs,ne FROM memory_forget_entries WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',source_id,'revision',expected_version) ORDER BY source_id),'[]'::jsonb),count(*)
  INTO source_refs,ns FROM memory_forget_sources WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',context_id,'revision',expected_version) ORDER BY context_id),'[]'::jsonb),count(*)
  INTO context_refs,nc FROM memory_forget_contexts WHERE batch_id=bid;
 IF b.id IS NULL OR s.id IS NULL OR watermark.settings_id IS NULL OR watermark.journal_id<>b.journal_id
  OR watermark.sequence<b.journal_sequence OR watermark.owner_epoch<b.owner_epoch OR ne>64 OR ns>64 OR nc>64
  OR (b.kind='entry' AND (ne<>1 OR ns>1 OR nc<>0
   OR EXISTS(SELECT 1 FROM memory_forget_sources m JOIN personal_learning_sources d ON d.id=m.source_id
    WHERE m.batch_id=bid AND (d.authorization_basis IS DISTINCT FROM 'owner-directed-turn/1'
     OR NOT EXISTS(SELECT 1 FROM classified_knowledge_bindings k JOIN memory_forget_entries e ON e.entry_id=k.entry_id
      WHERE e.batch_id=bid AND k.directed_source_id=d.id)))
   OR EXISTS(SELECT 1 FROM classified_knowledge_bindings k JOIN personal_learning_sources d ON d.id=k.directed_source_id
    JOIN memory_forget_entries e ON e.entry_id=k.entry_id WHERE e.batch_id=bid
     AND d.authorization_basis='owner-directed-turn/1' AND d.state='AVAILABLE'))) OR (b.kind='source' AND (ne<>0 OR ns<>1 OR nc<>0))
  OR b.request IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'kind',b.kind,'settingsId',s.id,
   'expectedRevision',b.expected_version,'learningEpoch',b.prior_learning_epoch,'recallEpoch',b.prior_recall_epoch,
   'contextRevision',b.prior_context_revision,'entryRefs',entry_refs,'sourceRefs',source_refs,'contextRefs',context_refs)
  OR b.receipt IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'operationId',b.id,'kind',b.kind,
   'settings',jsonb_build_object('revision',b.accepted_version,'learningEpoch',b.learning_epoch,'recallEpoch',b.recall_epoch,
    'contextRevision',b.context_revision,'indexGeneration',b.index_generation,'choice',b.receipt->'settings'->'choice'),
   'forgotten',jsonb_build_object('entries',ne,'sources',ns,'contexts',nc))
  THEN RAISE EXCEPTION 'memory_forget_exact_receipt';END IF;
 IF EXISTS(SELECT 1 FROM memory_forget_entries m JOIN personal_knowledge_entries e ON e.id=m.entry_id
  JOIN personal_knowledge_operations operation ON operation.id=m.operation_id WHERE m.batch_id=bid
   AND (e.settings_id<>b.settings_id OR e.state<>'FORGOTTEN' OR e.version<>m.accepted_version
    OR operation.forget_batch_id IS DISTINCT FROM bid OR operation.kind<>'FORGET' OR operation.entry_id<>m.entry_id
    OR operation.expected_version<>m.expected_version OR operation.accepted_version<>m.accepted_version
    OR operation.context_revision<>b.context_revision OR operation.created_at<>b.created_at
    OR operation.session_id<>b.session_id))
  OR EXISTS(SELECT 1 FROM personal_knowledge_operations operation WHERE operation.forget_batch_id=bid AND NOT EXISTS(
   SELECT 1 FROM memory_forget_entries m WHERE m.batch_id=bid AND m.operation_id=operation.id AND m.entry_id=operation.entry_id))
  OR EXISTS(SELECT 1 FROM memory_forget_sources m JOIN personal_learning_sources source ON source.id=m.source_id
   JOIN personal_learning_source_forgets f ON f.id=m.forget_id WHERE m.batch_id=bid
    AND (source.settings_id<>b.settings_id OR source.state<>'FORGOTTEN' OR source.revision<>m.accepted_version
     OR f.source_id<>m.source_id OR f.session_id<>b.session_id OR f.created_at<>b.created_at))
  OR EXISTS(SELECT 1 FROM memory_forget_contexts m JOIN owner_memory_contexts c ON c.id=m.context_id WHERE m.batch_id=bid
   AND (c.settings_id<>b.settings_id OR c.state<>'FORGOTTEN' OR c.version<>m.accepted_version
    OR c.context_revision<>b.context_revision OR c.updated_at<>b.created_at OR c.envelope IS NOT NULL))
  THEN RAISE EXCEPTION 'memory_forget_exact_members';END IF;
 IF live THEN
  IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation,s.updated_at)
   IS DISTINCT FROM ROW(b.accepted_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation,b.created_at)
   AND b.kind<>'source' THEN RAISE EXCEPTION 'memory_forget_current_settings';END IF;
  IF b.receipt->'settings' IS DISTINCT FROM os_learning_settings_payload(s)
   OR watermark.sequence<>b.journal_sequence OR watermark.owner_epoch<>b.owner_epoch OR watermark.updated_at<>b.created_at
   THEN RAISE EXCEPTION 'memory_forget_current_watermark';END IF;
  IF b.kind='all' AND (EXISTS(SELECT 1 FROM personal_knowledge_entries WHERE settings_id=b.settings_id AND state<>'FORGOTTEN')
   OR EXISTS(SELECT 1 FROM personal_learning_sources WHERE settings_id=b.settings_id AND state='AVAILABLE')
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state<>'FORGOTTEN'))
   THEN RAISE EXCEPTION 'memory_forget_all_members';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_current_owner';END IF;
 END IF;
 IF b.completed_at IS NOT NULL THEN
  IF EXISTS(SELECT 1 FROM personal_forget_journal WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_source_forgets WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state='FORGOTTEN' AND envelope IS NOT NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_context_commands command JOIN owner_memory_contexts context ON context.id=command.context_id
    WHERE context.settings_id=b.settings_id AND context.state='FORGOTTEN' AND command.request_mac IS NOT NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_jobs WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND state IN ('QUEUED','RUNNING'))
   THEN RAISE EXCEPTION 'memory_forget_cleanup_incomplete';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.cleanup_session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR NOT app.active OR app.generation<>session.application_generation
   OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_cleanup_owner';END IF;
 END IF;
END $function$;
ALTER TABLE personal_knowledge_publications DROP CONSTRAINT ck_knowledge_publication_authority;
ALTER TABLE personal_knowledge_operations DROP CONSTRAINT ck_knowledge_operation_authority;
ALTER TABLE classified_learning_job_snapshots DROP CONSTRAINT ck_classified_job_inference;
ALTER TABLE personal_learning_jobs DROP CONSTRAINT ck_learning_job_profile;
ALTER TABLE personal_learning_source_intents DROP CONSTRAINT ck_learning_source_intent_profile;
ALTER TABLE personal_learning_source_origins DROP CONSTRAINT ck_learning_source_origin_authorization;
ALTER TABLE personal_learning_sources DROP CONSTRAINT ck_learning_source_inference_grant;
ALTER TABLE personal_learning_sources DROP CONSTRAINT ck_learning_source_authorization_basis;
ALTER TABLE personal_learning_commands DROP CONSTRAINT ck_learning_command_contract;
ALTER TABLE personal_learning_settings DROP CONSTRAINT ck_learning_settings_choice;
ALTER TABLE personal_knowledge_publications DROP CONSTRAINT fk_personal_learning_commands_inference_consent_command_id;
ALTER TABLE personal_knowledge_operations DROP CONSTRAINT fk_personal_learning_commands_inference_consent_command_id;
ALTER TABLE classified_learning_job_snapshots DROP CONSTRAINT fk_personal_learning_commands_inference_consent_command_id;
ALTER TABLE personal_learning_sources DROP CONSTRAINT fk_personal_learning_commands_inference_consent_command_id;
ALTER TABLE personal_learning_settings DROP CONSTRAINT fk_personal_learning_commands_inference_consent_command_id;
ALTER TABLE personal_knowledge_publications ALTER COLUMN decision_id SET NOT NULL;
ALTER TABLE personal_knowledge_publications DROP COLUMN inference_consent_command_id;
ALTER TABLE personal_knowledge_publications DROP COLUMN authority_basis;
ALTER TABLE personal_knowledge_operations DROP COLUMN inference_consent_command_id;
ALTER TABLE personal_knowledge_operations DROP COLUMN authority_basis;
ALTER TABLE classified_learning_job_snapshots DROP COLUMN inference_purpose;
ALTER TABLE classified_learning_job_snapshots DROP COLUMN inference_generation;
ALTER TABLE classified_learning_job_snapshots DROP COLUMN inference_consent_command_id;
ALTER TABLE personal_learning_sources DROP COLUMN inference_purpose;
ALTER TABLE personal_learning_sources DROP COLUMN inference_consent_command_id;
ALTER TABLE personal_learning_commands DROP COLUMN contract_ref;
ALTER TABLE personal_learning_settings DROP COLUMN inference_consent_command_id;
ALTER TABLE personal_learning_jobs ADD CONSTRAINT ck_learning_job_profile CHECK ((((((profile_ref)::text = 'synthetic-staging/1'::text) AND ((prompt_ref)::text = ANY ((ARRAY['mem0-2.2.1-owner-source/1'::character varying, 'mem0-2.2.1-accepted-source/2'::character varying, 'mem0-2.2.1-usage-source/3'::character varying])::text[]))) OR (((profile_ref)::text = 'classified-staging/2'::text) AND ((prompt_ref)::text = 'mem0-2.2.1-classified-source/4'::text))) AND (((restoration_id IS NULL) AND (source_mac IS NOT NULL) AND (mac_key_id IS NOT NULL) AND ((source_mac)::text ~ '^[a-f0-9]{64}$'::text)) OR ((restoration_id IS NOT NULL) AND (source_mac IS NULL) AND (mac_key_id IS NULL)))));
ALTER TABLE personal_learning_settings ADD CONSTRAINT ck_learning_settings_choice CHECK (COALESCE(((jsonb_typeof((choice -> 'learnConversation'::text)) = 'boolean'::text) AND (jsonb_typeof((choice -> 'learnUsage'::text)) = 'boolean'::text) AND (jsonb_typeof((choice -> 'useMemory'::text)) = 'boolean'::text) AND (choice = jsonb_build_object('learnConversation', (choice -> 'learnConversation'::text), 'learnUsage', (choice -> 'learnUsage'::text), 'useMemory', (choice -> 'useMemory'::text), 'retentionProfile', 'private-local/1', 'extractorProfile', (choice -> 'extractorProfile'::text), 'embeddingProfile', (choice -> 'embeddingProfile'::text))) AND ((choice ->> 'extractorProfile'::text) = ANY (ARRAY['synthetic-staging/1'::text, 'classified-staging/2'::text])) AND ((choice ->> 'embeddingProfile'::text) = ANY (ARRAY['synthetic-embedding/1'::text, 'minilm-english-onnx/1'::text, 'keyword-fts/1'::text]))), false));
ALTER TABLE personal_learning_source_intents ADD CONSTRAINT ck_learning_source_intent_profile CHECK (((learning_epoch > 0) AND ((extractor_ref)::text = ANY ((ARRAY['synthetic-staging/1'::character varying, 'classified-staging/2'::character varying])::text[])) AND ((state)::text = ANY ((ARRAY['PENDING_DISPATCH'::character varying, 'CANCELLED'::character varying])::text[])) AND (max_source_chars = 8000) AND (max_candidates = 8)));
ALTER TABLE personal_learning_source_origins ADD CONSTRAINT ck_learning_source_origin_authorization CHECK (((authorization_basis IS NULL) OR (((authorization_basis)::text = 'owner-directed-turn/1'::text) AND (input_id IS NOT NULL) AND (result_id IS NULL))));
ALTER TABLE personal_learning_sources ADD CONSTRAINT ck_learning_source_authorization_basis CHECK (((authorization_basis IS NULL) OR (((authorization_basis)::text = 'owner-directed-turn/1'::text) AND ((kind)::text = 'accepted-user-turn/1'::text))));
DROP FUNCTION os_retained_entry_source(uuid,uuid);
DROP FUNCTION os_commit_inference_operation();
DROP FUNCTION os_assert_inference_publication(uuid,boolean);
DROP FUNCTION os_assert_inference_job(uuid,boolean);
DROP FUNCTION os_assert_inference_source(uuid,boolean);
DROP FUNCTION os_inference_consent_valid(jsonb);
""")
