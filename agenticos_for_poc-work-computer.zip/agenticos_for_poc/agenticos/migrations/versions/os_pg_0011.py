"""Typed capture and durable source pin; preserve frozen prior profiles."""

from alembic import op

revision = "os_pg_0011"
down_revision = "os_pg_0010"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        "\nCREATE TABLE os_typed_source_captures (\n\tid UUID NOT NULL, \n\tsource_input_id UUID NOT NULL, \n\tregistration_revision BIGINT NOT NULL, \n\tcapability_ref VARCHAR(256) NOT NULL, \n\tdefinition_ref VARCHAR(256) NOT NULL, \n\tdefinition_revision BIGINT NOT NULL, \n\tcapture_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_typed_source_capture_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_source_inputs_source_input_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_input_id) REFERENCES os_source_inputs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_typed_capture_input UNIQUE (installation_id, application_id, tenant_id, subject_id, source_input_id), \n\tCONSTRAINT fk_capture_schema FOREIGN KEY(installation_id, application_id, registration_revision, capability_ref) REFERENCES os_resource_schemas (installation_id, application_id, registration_revision, capability_ref), \n\tCONSTRAINT ck_typed_capture_versions CHECK (registration_revision>0 AND definition_revision>0), \n\tCONSTRAINT ck_typed_capture_digest CHECK (capture_digest ~ '^[a-f0-9]{64}$')\n)\n\n"
    )
    op.execute(
        "\nCREATE TABLE os_task_source_pins (\n\tid UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tcapture_id UUID NOT NULL, \n\tartifact_id UUID NOT NULL, \n\tprofile_ref VARCHAR(64) NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\tpin_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_task_source_pin_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_typed_source_captures_capture_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, capture_id) REFERENCES os_typed_source_captures (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_artifacts_artifact_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, artifact_id) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_task_source_pin UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id), \n\tCONSTRAINT uq_capture_task_pin UNIQUE (installation_id, application_id, tenant_id, subject_id, capture_id), \n\tCONSTRAINT ck_task_source_profile CHECK (profile_ref='typed-trusted-task/1'), \n\tCONSTRAINT ck_task_source_lifetime CHECK (expires_at>created_at AND expires_at<=created_at+interval '7 days'), \n\tCONSTRAINT ck_task_source_ciphertext_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_task_source_pin_digest CHECK (pin_digest ~ '^[a-f0-9]{64}$')\n)\n\n"
    )
    op.execute("ALTER TABLE os_dispatches DROP CONSTRAINT ck_dispatch_profile")
    op.execute(
        "ALTER TABLE os_dispatches ADD CONSTRAINT ck_dispatch_profile CHECK (workflow_profile IN ('OSAdmissionTransport/1','OSTaskDriver/1','OSTrustedTaskDriver/1')) NOT VALID"
    )
    op.execute("ALTER TABLE os_dispatches VALIDATE CONSTRAINT ck_dispatch_profile")
    op.execute(
        "CREATE TRIGGER immutable_os_typed_source_captures BEFORE UPDATE OR DELETE ON os_typed_source_captures FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','source_input_id','registration_revision','capability_ref','definition_ref','definition_revision','capture_digest','created_at','installation_id','application_id','tenant_id','subject_id')"
    )
    op.execute(
        "CREATE TRIGGER immutable_os_task_source_pins BEFORE UPDATE OR DELETE ON os_task_source_pins FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','task_id','capture_id','artifact_id','profile_ref','ciphertext_digest','pin_digest','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')"
    )


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use tested fresh recovery")
