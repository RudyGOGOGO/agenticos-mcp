"""Add immutable owned proposals and closed review disposition guards.

Protect/rehearse populated0013 first. No original source or root is rewritten.
"""

from alembic import op

revision = "os_pg_0014"
down_revision = "os_pg_0013"
branch_labels = None
depends_on = None


def upgrade():
    op.create_unique_constraint(
        "uq_result_proposal_fence",
        "os_accepted_results",
        [
            "installation_id",
            "application_id",
            "tenant_id",
            "subject_id",
            "id",
            "task_id",
            "segment_id",
            "control_epoch",
            "contract_ref",
        ],
    )
    op.execute("""
CREATE TABLE os_review_proposals (
	id UUID NOT NULL, 
	task_id UUID NOT NULL, 
	segment_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	control_epoch BIGINT NOT NULL, 
	accepted_id UUID NOT NULL, 
	accepted_contract_ref VARCHAR(64) NOT NULL, 
	revision BIGINT NOT NULL, 
	proposal_digest VARCHAR(64) NOT NULL, 
	source_pin_digest VARCHAR(64) NOT NULL, 
	request_digest VARCHAR(64) NOT NULL, 
	artifact_id UUID NOT NULL, 
	ciphertext_digest VARCHAR(64) NOT NULL, 
	capability_ref VARCHAR(256) NOT NULL, 
	registration_revision BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_review_proposal_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_artifacts_artifact_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, artifact_id) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_review_task_root_fence FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, budget_root_id, id), 
	CONSTRAINT fk_review_proposal_segment FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, segment_id, task_id) REFERENCES os_segments (installation_id, application_id, tenant_id, subject_id, id, task_id), 
	CONSTRAINT fk_review_accepted_fence FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, accepted_id, task_id, segment_id, control_epoch, accepted_contract_ref) REFERENCES os_accepted_results (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, control_epoch, contract_ref), 
	CONSTRAINT uq_review_accepted_once UNIQUE (installation_id, application_id, tenant_id, subject_id, accepted_id), 
	CONSTRAINT ck_review_proposal_versions CHECK (revision>0 AND control_epoch>0 AND registration_revision>0), 
	CONSTRAINT ck_review_accepted_contract CHECK (accepted_contract_ref='PreparedChangeResult'), 
	CONSTRAINT ck_review_proposal_lifetime CHECK (expires_at>created_at AND expires_at<=created_at+interval '10 minutes'), 
	CONSTRAINT ck_review_proposal_digest CHECK (proposal_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_review_source_digest CHECK (source_pin_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_review_request_digest CHECK (request_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_review_ciphertext_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$')
)
""")
    op.execute("""
CREATE TABLE os_review_dispositions (
	id UUID NOT NULL, 
	proposal_id UUID NOT NULL, 
	version BIGINT NOT NULL, 
	state VARCHAR(32) NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_review_disposition_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_review_proposals_proposal_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, proposal_id) REFERENCES os_review_proposals (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_review_disposition UNIQUE (installation_id, application_id, tenant_id, subject_id, proposal_id), 
	CONSTRAINT ck_review_disposition_version CHECK (version>0), 
	CONSTRAINT ck_review_disposition_state CHECK (state IN ('PROPOSED','APPROVED','REJECTED','STALE','EXPIRED','SUPERSEDED'))
)
""")
    op.execute(
        "CREATE TRIGGER immutable_os_review_proposals BEFORE UPDATE OR DELETE ON os_review_proposals FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','task_id','segment_id','root_id','control_epoch','accepted_id','accepted_contract_ref','revision','proposal_digest','source_pin_digest','request_digest','artifact_id','ciphertext_digest','capability_ref','registration_revision','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')"
    )
    op.execute("""
CREATE FUNCTION os_guard_review_disposition() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.state<>'PROPOSED' THEN
   RAISE EXCEPTION 'Review disposition initialization refused';
  END IF;
  RETURN NEW;
 END IF;
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Review disposition deletion refused'; END IF;
 IF ROW(NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.proposal_id)
 IS DISTINCT FROM ROW(OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.proposal_id)
 OR NEW.version<>OLD.version+1 OR OLD.state<>'PROPOSED' OR NEW.state='PROPOSED'
 THEN RAISE EXCEPTION 'Review disposition transition refused'; END IF;
 RETURN NEW;
END;
$$
""")
    op.execute(
        "CREATE TRIGGER guard_os_review_disposition BEFORE INSERT OR UPDATE OR DELETE ON os_review_dispositions FOR EACH ROW EXECUTE FUNCTION os_guard_review_disposition()"
    )


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use tested fresh recovery")
