"""Align observed case guard with the closed arguments contract."""
from alembic import op

revision='os_pg_0051'
down_revision='os_pg_0050'
branch_labels=None
depends_on=None
GUARDS=r"""

CREATE OR REPLACE FUNCTION os_guard_native_verification() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE j os_native_jobs%ROWTYPE; a os_work_attempts%ROWTYPE; r os_budget_roots%ROWTYPE;
 c os_task_controls%ROWTYPE; t os_tasks%ROWTYPE; f os_artifacts%ROWTYPE; observed jsonb; argument jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO j FROM os_native_jobs WHERE id=NEW.job_id;
 SELECT * INTO a FROM os_work_attempts WHERE id=j.attempt_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=j.root_id;
 SELECT * INTO c FROM os_task_controls WHERE task_id=j.task_id FOR UPDATE;
 SELECT * INTO t FROM os_tasks WHERE id=j.task_id;
 SELECT * INTO f FROM os_artifacts WHERE id=NEW.artifact_id;
 IF j.id IS NULL OR a.state IS DISTINCT FROM 'SETTLED' OR a.kind IS DISTINCT FROM 'native'
  OR r.state IS DISTINCT FROM 'ACTIVE' OR r.deadline<=clock_timestamp()
  OR c.state IS DISTINCT FROM 'ACTIVE' OR c.epoch IS DISTINCT FROM j.control_epoch
  OR t.deadline<=clock_timestamp() OR t.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')
  OR f.id IS NULL OR f.purpose<>'artifact' OR f.classification<>'protected' OR f.expires_at<=clock_timestamp()
  OR f.ciphertext_digest<>NEW.ciphertext_digest
  OR NEW.receipt IS DISTINCT FROM jsonb_build_object(
   'subject',jsonb_build_object('installationId',NEW.installation_id,'applicationId',NEW.application_id,'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id),
   'jobId',NEW.job_id,'taskId',j.task_id,'attemptId',j.attempt_id,'inputDigest',j.binding->'inputDigest','policyDigest',j.binding->'policyDigest',
   'artifactRef','artifact/'||NEW.artifact_id::text,'ciphertextDigest',NEW.ciphertext_digest,'compiledDigest',NEW.compiled_digest,
   'teardownDigest',NEW.teardown_digest,'profileRef','wasmtime-i32-offline/1','cases',NEW.receipt->'cases','status','verified','verifiedAt',NEW.receipt->'verifiedAt')
  OR jsonb_typeof(NEW.receipt->'cases') IS DISTINCT FROM 'array'
  OR jsonb_array_length(NEW.receipt->'cases') NOT BETWEEN 1 AND 8
  OR jsonb_typeof(NEW.receipt->'verifiedAt') IS DISTINCT FROM 'string'
  OR (NEW.receipt->>'verifiedAt')::timestamptz>clock_timestamp()
 THEN RAISE EXCEPTION 'native_verification_exact_binding';END IF;
 FOR observed IN SELECT value FROM jsonb_array_elements(NEW.receipt->'cases') LOOP
  IF jsonb_typeof(observed) IS DISTINCT FROM 'object'
   OR (observed-ARRAY['arguments','result','fuelUsed'])<>'{}'::jsonb
   OR jsonb_typeof(observed->'arguments') IS DISTINCT FROM 'array'
   OR jsonb_array_length(observed->'arguments')>8
   OR jsonb_typeof(observed->'result') IS DISTINCT FROM 'number'
   OR observed->>'result' !~ '^-?[0-9]+$'
   OR (observed->>'result')::numeric NOT BETWEEN -2147483648 AND 2147483647
   OR jsonb_typeof(observed->'fuelUsed') IS DISTINCT FROM 'number'
   OR observed->>'fuelUsed' !~ '^[0-9]+$'
   OR (observed->>'fuelUsed')::numeric NOT BETWEEN 0 AND 1000000
   THEN RAISE EXCEPTION 'native_verification_observed_case';END IF;
  FOR argument IN SELECT value FROM jsonb_array_elements(observed->'arguments') LOOP
   IF jsonb_typeof(argument) IS DISTINCT FROM 'number' OR argument::text !~ '^-?[0-9]+$'
    OR argument::text::numeric NOT BETWEEN -2147483648 AND 2147483647
    THEN RAISE EXCEPTION 'native_verification_observed_case';END IF;
  END LOOP;
 END LOOP;
 RETURN NEW;
END $$;

"""

def upgrade():
    op.execute(GUARDS)

def downgrade():
    raise RuntimeError('Native case guards require reviewed forward recovery')
