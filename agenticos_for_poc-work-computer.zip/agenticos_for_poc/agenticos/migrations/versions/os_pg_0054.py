"""Reviewed finite proactive definitions, durable ingress and independent dispatch."""
from alembic import op

revision="os_pg_0054"
down_revision="os_pg_0053"
branch_labels=None
depends_on=None
TABLES=("CREATE TABLE os_proactive_definitions (\n\tid UUID NOT NULL, \n\tkind VARCHAR(16) NOT NULL, \n\tversion BIGINT NOT NULL, \n\tgeneration BIGINT NOT NULL, \n\tconfiguration_revision BIGINT NOT NULL, \n\tstate VARCHAR(24) NOT NULL, \n\tapplication_generation BIGINT NOT NULL, \n\tsubject_generation BIGINT NOT NULL, \n\tpolicy_generation BIGINT NOT NULL, \n\tregistration_revision BIGINT NOT NULL, \n\tcursor TIMESTAMP WITH TIME ZONE NOT NULL, \n\tlast_admitted_at TIMESTAMP WITH TIME ZONE, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_definition_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_proactive_definition_subject FOREIGN KEY(installation_id, application_id, tenant_id, subject_id) REFERENCES os_subjects (installation_id, application_id, tenant_id, subject_id), \n\tCONSTRAINT ck_proactive_definition_state CHECK (kind IN ('schedule','subscription') AND state IN ('awaiting-review','active','paused','removed','revoked','rejected')), \n\tCONSTRAINT ck_proactive_definition_versions CHECK (version>0 AND generation>0 AND configuration_revision>0 AND configuration_revision<=version AND application_generation>0 AND subject_generation>0 AND policy_generation>0 AND registration_revision>0)\n)", "CREATE TABLE os_proactive_revisions (\n\tid UUID NOT NULL, \n\tdefinition_id UUID NOT NULL, \n\trevision BIGINT NOT NULL, \n\tsession_id UUID NOT NULL, \n\tapplication_generation BIGINT NOT NULL, \n\tsubject_generation BIGINT NOT NULL, \n\tpolicy_generation BIGINT NOT NULL, \n\tregistration_revision BIGINT NOT NULL, \n\tconfiguration JSONB NOT NULL, \n\tconfiguration_digest VARCHAR(64) NOT NULL, \n\tverification_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_revision_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_definitions_definition_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, definition_id) REFERENCES os_proactive_definitions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_proactive_definition_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, definition_id, revision), \n\tCONSTRAINT ck_proactive_configuration CHECK (revision>0 AND jsonb_typeof(configuration)='object' AND octet_length(configuration::text)<=16384), \n\tCONSTRAINT ck_proactive_revision_generations CHECK (application_generation>0 AND subject_generation>0 AND policy_generation>0 AND registration_revision>0), \n\tCONSTRAINT ck_proactive_configuration_digest CHECK (configuration_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_proactive_verification_digest CHECK (verification_digest ~ '^[a-f0-9]{64}$')\n)", "CREATE TABLE os_proactive_commands (\n\tid UUID NOT NULL, \n\tdefinition_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tkind VARCHAR(16) NOT NULL, \n\texpected_version BIGINT NOT NULL, \n\taccepted_version BIGINT NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\treceipt JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_command_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_definitions_definition_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, definition_id) REFERENCES os_proactive_definitions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_proactive_command_key UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT uq_proactive_command_version UNIQUE (installation_id, application_id, tenant_id, subject_id, definition_id, accepted_version), \n\tCONSTRAINT ck_proactive_command_version CHECK (expected_version>=0 AND accepted_version=expected_version+1 AND kind IN ('draft','activate','reject','pause','resume','remove','revoke')), \n\tCONSTRAINT ck_proactive_command_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n)", "CREATE TABLE os_proactive_delegations (\n\tid UUID NOT NULL, \n\tdefinition_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\treview_command_id UUID NOT NULL, \n\tpayload JSONB NOT NULL, \n\tdigest VARCHAR(64) NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_delegation_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_definitions_definition_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, definition_id) REFERENCES os_proactive_definitions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES os_proactive_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_commands_review_command_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, review_command_id) REFERENCES os_proactive_commands (installation_id, application_id, tenant_id, subject_id, id) DEFERRABLE INITIALLY DEFERRED, \n\tCONSTRAINT uq_proactive_revision_delegation UNIQUE (installation_id, application_id, tenant_id, subject_id, revision_id), \n\tCONSTRAINT ck_proactive_delegation_scope CHECK (jsonb_typeof(payload)='object' AND payload->>'maxRisk'='low' AND octet_length(payload::text)<=16384), \n\tCONSTRAINT ck_proactive_delegation_digest CHECK (digest ~ '^[a-f0-9]{64}$')\n)", 'CREATE TABLE os_proactive_days (\n\tid UUID NOT NULL, \n\tday VARCHAR(10) NOT NULL, \n\ttasks BIGINT NOT NULL, \n\ttool_calls BIGINT NOT NULL, \n\treserved_work_ms BIGINT NOT NULL, \n\tspent_work_ms BIGINT NOT NULL, \n\ttask_limit BIGINT NOT NULL, \n\ttool_limit BIGINT NOT NULL, \n\twork_limit_ms BIGINT NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_day_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_proactive_day_subject FOREIGN KEY(installation_id, application_id, tenant_id, subject_id) REFERENCES os_subjects (installation_id, application_id, tenant_id, subject_id), \n\tCONSTRAINT uq_proactive_owner_day UNIQUE (installation_id, application_id, tenant_id, subject_id, day), \n\tCONSTRAINT ck_proactive_daily_budget CHECK (tasks>=0 AND tool_calls>=0 AND reserved_work_ms>=0 AND spent_work_ms>=0 AND task_limit BETWEEN 1 AND 1000 AND tool_limit BETWEEN 1 AND 1000 AND work_limit_ms BETWEEN 1000 AND 86400000 AND tasks<=task_limit AND tool_calls<=tool_limit AND reserved_work_ms+spent_work_ms<=work_limit_ms)\n)', 'CREATE TABLE os_proactive_roots (\n\tid UUID NOT NULL, \n\ttasks BIGINT NOT NULL, \n\ttool_calls BIGINT NOT NULL, \n\treserved_work_ms BIGINT NOT NULL, \n\tspent_work_ms BIGINT NOT NULL, \n\ttask_limit BIGINT NOT NULL, \n\ttool_limit BIGINT NOT NULL, \n\twork_limit_ms BIGINT NOT NULL, \n\tdepth_limit BIGINT NOT NULL, \n\tdeadline TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_root_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_proactive_root_subject FOREIGN KEY(installation_id, application_id, tenant_id, subject_id) REFERENCES os_subjects (installation_id, application_id, tenant_id, subject_id), \n\tCONSTRAINT ck_proactive_root_budget CHECK (tasks>=0 AND tool_calls>=0 AND reserved_work_ms>=0 AND spent_work_ms>=0 AND task_limit BETWEEN 1 AND 16 AND tool_limit BETWEEN 1 AND 64 AND work_limit_ms BETWEEN 1000 AND 600000 AND depth_limit BETWEEN 1 AND 8 AND tasks<=task_limit AND tool_calls<=tool_limit AND reserved_work_ms+spent_work_ms<=work_limit_ms)\n)', "CREATE TABLE os_proactive_runs (\n\tid UUID NOT NULL, \n\tdefinition_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\tdelegation_id UUID NOT NULL, \n\tdefinition_revision BIGINT NOT NULL, \n\tgeneration BIGINT NOT NULL, \n\ttrigger_key VARCHAR(256) NOT NULL, \n\ttask_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tday_id UUID NOT NULL, \n\tcausal_parent_id UUID, \n\tdepth BIGINT NOT NULL, \n\tstate VARCHAR(24) NOT NULL, \n\tversion BIGINT NOT NULL, \n\tadmission_digest VARCHAR(64) NOT NULL, \n\treserved_work_ms BIGINT NOT NULL, \n\ttool_calls BIGINT NOT NULL, \n\tactual_work_ms BIGINT, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tdeadline TIMESTAMP WITH TIME ZONE NOT NULL, \n\tresult_digest VARCHAR(64), \n\tresult_artifact_id UUID, \n\tresult_ciphertext_digest VARCHAR(64), \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_run_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_definitions_definition_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, definition_id) REFERENCES os_proactive_definitions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES os_proactive_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_delegations_delegation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, delegation_id) REFERENCES os_proactive_delegations (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_proactive_roots (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_days_day_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, day_id) REFERENCES os_proactive_days (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_runs_causal_parent_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, causal_parent_id) REFERENCES os_proactive_runs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_proactive_result_pin FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, result_artifact_id, result_ciphertext_digest) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id, ciphertext_digest), \n\tCONSTRAINT uq_proactive_trigger_admission UNIQUE (installation_id, application_id, tenant_id, subject_id, definition_id, definition_revision, trigger_key), \n\tCONSTRAINT uq_proactive_task UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id), \n\tCONSTRAINT ck_proactive_run_limits CHECK (definition_revision>0 AND generation>0 AND version>0 AND depth BETWEEN 0 AND 8 AND reserved_work_ms>0 AND tool_calls BETWEEN 1 AND 2 AND (actual_work_ms IS NULL OR actual_work_ms>=0) AND deadline>created_at), \n\tCONSTRAINT ck_proactive_run_state CHECK (state IN ('DUE','RUNNING','COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')), \n\tCONSTRAINT ck_proactive_result CHECK ((result_artifact_id IS NULL)=(result_ciphertext_digest IS NULL) AND (result_digest IS NULL)=(result_artifact_id IS NULL)), \n\tCONSTRAINT ck_proactive_result_digest CHECK (result_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_proactive_result_ciphertext_digest CHECK (result_ciphertext_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_proactive_admission_digest CHECK (admission_digest ~ '^[a-f0-9]{64}$')\n)", "CREATE TABLE os_proactive_dispatches (\n\tid UUID NOT NULL, \n\trun_id UUID NOT NULL, \n\tstate VARCHAR(16) NOT NULL, \n\tattempts BIGINT NOT NULL, \n\tnext_attempt_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_dispatch_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_runs_run_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, run_id) REFERENCES os_proactive_runs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_proactive_run_dispatch UNIQUE (installation_id, application_id, tenant_id, subject_id, run_id), \n\tCONSTRAINT ck_proactive_dispatch_state CHECK (state IN ('DUE','STARTED','POISON') AND attempts BETWEEN 0 AND 8)\n)", "CREATE TABLE os_proactive_sources (\n\tid UUID NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\tsource_ref VARCHAR(256) NOT NULL, \n\tregistration JSONB NOT NULL, \n\tdigest VARCHAR(64) NOT NULL, \n\tactive BOOLEAN NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_source UNIQUE (installation_id, application_id, source_ref), \n\tCONSTRAINT fk_proactive_source_application FOREIGN KEY(installation_id, application_id) REFERENCES os_applications (installation_id, id), \n\tCONSTRAINT ck_proactive_source_digest CHECK (digest ~ '^[a-f0-9]{64}$')\n)", "CREATE TABLE os_proactive_inbox (\n\tid UUID NOT NULL, \n\tsource_ref VARCHAR(256) NOT NULL, \n\tevent_id UUID NOT NULL, \n\tdigest VARCHAR(64) NOT NULL, \n\tevent JSONB NOT NULL, \n\tcausal_parent_id UUID, \n\tstate VARCHAR(24) NOT NULL, \n\tattempts BIGINT NOT NULL, \n\treceived_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_inbox_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_proactive_inbox_subject FOREIGN KEY(installation_id, application_id, tenant_id, subject_id) REFERENCES os_subjects (installation_id, application_id, tenant_id, subject_id), \n\tCONSTRAINT fk_os_proactive_runs_causal_parent_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, causal_parent_id) REFERENCES os_proactive_runs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_proactive_inbox_source FOREIGN KEY(installation_id, application_id, source_ref) REFERENCES os_proactive_sources (installation_id, application_id, source_ref), \n\tCONSTRAINT uq_proactive_event UNIQUE (installation_id, application_id, tenant_id, subject_id, source_ref, event_id), \n\tCONSTRAINT ck_proactive_inbox_state CHECK (state IN ('STORED','QUARANTINED','POISON') AND attempts BETWEEN 0 AND 8 AND jsonb_typeof(event)='object' AND octet_length(event::text)<=65536), \n\tCONSTRAINT ck_proactive_inbox_digest CHECK (digest ~ '^[a-f0-9]{64}$')\n)", "CREATE TABLE os_proactive_event_consumptions (\n\tid UUID NOT NULL, \n\tdefinition_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\tinbox_id UUID NOT NULL, \n\toutcome VARCHAR(24) NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_event_consumption_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_definitions_definition_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, definition_id) REFERENCES os_proactive_definitions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES os_proactive_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_inbox_inbox_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, inbox_id) REFERENCES os_proactive_inbox (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_proactive_event_consumed UNIQUE (installation_id, application_id, tenant_id, subject_id, revision_id, inbox_id), \n\tCONSTRAINT ck_proactive_event_outcome CHECK (outcome IN ('ADMITTED','PREDICATE','COOLDOWN','OVERLAP','BUDGET','REVOKED'))\n)", "CREATE TABLE os_proactive_notifications (\n\tid UUID NOT NULL, \n\trun_id UUID NOT NULL, \n\tpayload JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_notification_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_runs_run_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, run_id) REFERENCES os_proactive_runs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_proactive_result_notification UNIQUE (installation_id, application_id, tenant_id, subject_id, run_id), \n\tCONSTRAINT ck_proactive_notification_payload CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=2048)\n)", 'CREATE TABLE os_proactive_acknowledgements (\n\tid UUID NOT NULL, \n\tnotification_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_acknowledgement_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_proactive_notifications_notification_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, notification_id) REFERENCES os_proactive_notifications (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_proactive_ack_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT uq_proactive_ack_notification UNIQUE (installation_id, application_id, tenant_id, subject_id, notification_id)\n)', "CREATE TABLE os_proactive_task_commands (\n\tid UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\treceipt JSONB NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_proactive_task_command_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_proactive_stop_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT ck_proactive_stop_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n)")
INDEXES=('CREATE INDEX ix_proactive_definition_due ON os_proactive_definitions (installation_id, application_id, state, id)', 'CREATE INDEX ix_proactive_run_owner ON os_proactive_runs (installation_id, application_id, tenant_id, subject_id, definition_id, created_at, id)', 'CREATE INDEX ix_proactive_dispatch_due ON os_proactive_dispatches (installation_id, application_id, state, next_attempt_at)', 'CREATE INDEX ix_proactive_inbox_source ON os_proactive_inbox (installation_id, application_id, source_ref, received_at, id)')
GUARDS=r"""
CREATE FUNCTION os_proactive_owner(i uuid,a uuid,t text,s text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM 1 FROM os_applications WHERE installation_id=i AND id=a AND active FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'proactive_current_application';END IF;
 PERFORM 1 FROM os_subjects WHERE installation_id=i AND application_id=a AND tenant_id=t AND subject_id=s AND active FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'proactive_current_owner';END IF;
END $$;

CREATE FUNCTION os_proactive_session(i uuid,a uuid,t text,s text,session_uuid uuid) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
 PERFORM os_proactive_owner(i,a,t,s);
 IF NOT EXISTS(SELECT 1 FROM os_interactive_sessions x JOIN os_applications p ON p.installation_id=x.installation_id AND p.id=x.application_id
  JOIN os_subjects o ON (o.installation_id,o.application_id,o.tenant_id,o.subject_id)=(x.installation_id,x.application_id,x.tenant_id,x.subject_id)
  WHERE (x.installation_id,x.application_id,x.tenant_id,x.subject_id,x.id)=(i,a,t,s,session_uuid)
  AND NOT x.revoked AND x.expires_at>clock_timestamp() AND x.application_generation=p.generation AND x.subject_generation=o.generation
  )
 THEN RAISE EXCEPTION 'proactive_current_session';END IF;
END $$;

CREATE FUNCTION os_proactive_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 RAISE EXCEPTION 'proactive_immutable_record';
END $$;

CREATE FUNCTION os_proactive_definition_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.generation<>1 OR NEW.configuration_revision<>1 OR NEW.state<>'awaiting-review' OR NEW.last_admitted_at IS NOT NULL
  THEN RAISE EXCEPTION 'proactive_initial_definition';END IF;
 ELSIF NEW.version=OLD.version THEN
  IF (to_jsonb(NEW)-ARRAY['cursor','last_admitted_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['cursor','last_admitted_at'])
   OR NEW.cursor<OLD.cursor OR (OLD.last_admitted_at IS NOT NULL AND (NEW.last_admitted_at IS NULL OR NEW.last_admitted_at<OLD.last_admitted_at))
  THEN RAISE EXCEPTION 'proactive_definition_bookkeeping';END IF;
 ELSE
  IF NEW.version<>OLD.version+1 OR NEW.generation<>OLD.generation+1 OR OLD.state IN ('removed','revoked')
   OR (NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.kind)
    IS DISTINCT FROM (OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.kind)
   OR NOT ((NEW.state='awaiting-review' AND NEW.configuration_revision=NEW.version)
    OR (NEW.configuration_revision=OLD.configuration_revision AND ((OLD.state='awaiting-review' AND NEW.state IN ('active','rejected','removed','revoked'))
     OR (OLD.state='active' AND NEW.state IN ('paused','removed','revoked')) OR (OLD.state='paused' AND NEW.state IN ('active','removed','revoked')))))
  THEN RAISE EXCEPTION 'proactive_definition_transition';END IF;
 END IF;
 IF NOT EXISTS(SELECT 1 FROM os_applications p JOIN os_subjects o ON o.installation_id=p.installation_id AND o.application_id=p.id
  WHERE (o.installation_id,o.application_id,o.tenant_id,o.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
  AND p.generation=NEW.application_generation AND p.revision=NEW.registration_revision AND o.generation=NEW.subject_generation
  AND o.host_policy_generation=NEW.policy_generation) THEN RAISE EXCEPTION 'proactive_definition_generation';END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_proactive_definition_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' OR NEW.version<>OLD.version THEN
  IF NOT EXISTS(SELECT 1 FROM os_proactive_commands c JOIN os_proactive_revisions r ON r.definition_id=c.definition_id
   WHERE c.definition_id=NEW.id AND c.accepted_version=NEW.version AND r.revision=NEW.configuration_revision
   AND c.receipt->'definition'->>'id'=NEW.id::text AND (c.receipt->'definition'->>'revision')::bigint=NEW.version
   AND (c.receipt->'definition'->>'generation')::bigint=NEW.generation AND c.receipt->'definition'->>'state'=NEW.state
   AND c.receipt->'definition'->'configuration'=r.configuration AND c.receipt->'definition'->>'configurationDigest'=r.configuration_digest
   AND c.kind=(CASE WHEN NEW.state='awaiting-review' THEN 'draft' WHEN NEW.state='active' AND TG_OP='UPDATE' AND OLD.state='paused' THEN 'resume'
    WHEN NEW.state='active' THEN 'activate' WHEN NEW.state='rejected' THEN 'reject' WHEN NEW.state='paused' THEN 'pause'
    WHEN NEW.state='removed' THEN 'remove' ELSE 'revoke' END))
  THEN RAISE EXCEPTION 'proactive_atomic_command';END IF;
 END IF;
 IF (SELECT count(*) FROM os_proactive_definitions d WHERE
  (d.installation_id,d.application_id,d.tenant_id,d.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
  AND d.state NOT IN ('removed','revoked','rejected'))>32 THEN RAISE EXCEPTION 'proactive_definition_capacity';END IF;
 IF NEW.state='active' AND NOT EXISTS(SELECT 1 FROM os_proactive_delegations g JOIN os_proactive_revisions r ON r.id=g.revision_id
  WHERE r.definition_id=NEW.id AND r.revision=NEW.configuration_revision AND g.expires_at>clock_timestamp())
 THEN RAISE EXCEPTION 'proactive_review_required';END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_proactive_revision_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_proactive_definitions%ROWTYPE;c jsonb;l jsonb;
BEGIN
 PERFORM os_proactive_session(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id FOR UPDATE;c=NEW.configuration;l=c->'limits';
 IF (NEW.application_generation,NEW.subject_generation,NEW.policy_generation,NEW.registration_revision)
  IS DISTINCT FROM (d.application_generation,d.subject_generation,d.policy_generation,d.registration_revision)
 THEN RAISE EXCEPTION 'proactive_original_revision_generations';END IF;
 IF COALESCE((d.state<>'awaiting-review' OR d.configuration_revision<>NEW.revision OR NEW.created_at>clock_timestamp()+interval '5 seconds'
  OR (c->>'validUntil')::timestamptz<=clock_timestamp() OR (c->>'validUntil')::timestamptz>NEW.created_at+interval '7 days'
  OR (c->>'workflowRevision')::bigint<>1 OR c->>'workflowRef' NOT IN ('registered-read/1','registered-staging/1','verified-wasm/1')
  OR (d.kind='schedule') IS DISTINCT FROM (c->'calendar'<>'null'::jsonb) OR (c->'calendar'='null'::jsonb)=(c->'event'='null'::jsonb)
  OR jsonb_array_length(c->'arguments'->'externalIds')<1 OR jsonb_array_length(c->'arguments'->'fieldNames')<1
  OR (l->>'taskDeadlineMs')::bigint>LEAST((l->>'rootWorkMs')::bigint,(l->>'dailyWorkMs')::bigint)
  OR (l->>'rootTaskLimit')::bigint>(l->>'dailyTaskLimit')::bigint OR (l->>'rootToolCallLimit')::bigint>(l->>'dailyToolCallLimit')::bigint
  OR (c->'calendar'<>'null'::jsonb AND (c->'calendar'->>'tzdataRef'<>'tzdata/2026.5' OR c->'calendar'->>'overlap'<>'SKIP'
   OR (c->'calendar'->'intervalSeconds'<>'null'::jsonb AND (c->'calendar'->>'intervalSeconds')::bigint<60)
   OR (c->'calendar'->>'catchUp'='COALESCE_READ' AND c->>'workflowRef'<>'registered-read/1')))),true)
 THEN RAISE EXCEPTION 'proactive_reviewed_configuration';END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_proactive_command_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_proactive_definitions%ROWTYPE;
BEGIN
 PERFORM os_proactive_session(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id FOR UPDATE;
 IF d.version<>NEW.accepted_version OR NEW.receipt->>'commandId'<>NEW.command_id::text
  OR NEW.receipt->'definition'->'subject'<>jsonb_build_object('installationId',NEW.installation_id::text,'applicationId',NEW.application_id::text,
   'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id) THEN RAISE EXCEPTION 'proactive_command_binding';END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_proactive_delegation_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_proactive_revisions%ROWTYPE;c os_proactive_commands%ROWTYPE;d os_proactive_definitions%ROWTYPE;b jsonb;
BEGIN
 SELECT * INTO r FROM os_proactive_revisions WHERE id=NEW.revision_id;
 SELECT * INTO c FROM os_proactive_commands WHERE id=NEW.review_command_id;
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id;
 b=jsonb_build_array(jsonb_build_object('resourceType',r.configuration->'arguments'->>'resourceType',
  'externalIds',r.configuration->'arguments'->'externalIds','fieldNames',r.configuration->'arguments'->'fieldNames'));
 IF COALESCE((r.definition_id<>d.id OR c.definition_id<>d.id OR c.kind<>'activate' OR c.expected_version<>r.revision OR c.accepted_version<>r.revision+1
  OR NEW.expires_at<>(r.configuration->>'validUntil')::timestamptz OR NEW.expires_at<=clock_timestamp()
  OR NEW.payload->>'id'<>NEW.id::text OR (NEW.payload->>'revision')::bigint<>r.revision OR NEW.payload->'active'<>'true'::jsonb
  OR NEW.payload->>'purpose'<>'assistant.read' OR NEW.payload->>'maxRisk'<>'low'
  OR NEW.payload->'subject'<>c.receipt->'definition'->'subject' OR NEW.payload->'resourceBounds'<>b
  OR NEW.payload->'capabilityRefs'<>jsonb_build_array(r.configuration->>'capabilityRef')
  OR (NEW.payload->>'validUntil')::timestamptz<>NEW.expires_at),true)
 THEN RAISE EXCEPTION 'proactive_exact_finite_delegation';END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_proactive_run_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_proactive_definitions%ROWTYPE;r os_proactive_revisions%ROWTYPE;g os_proactive_delegations%ROWTYPE;
 c os_task_controls%ROWTYPE;t os_tasks%ROWTYPE;p os_proactive_runs%ROWTYPE;b os_proactive_roots%ROWTYPE;l jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='UPDATE' THEN
  IF OLD.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED') OR NEW.version<>OLD.version+1
   OR (to_jsonb(NEW)-ARRAY['state','version','actual_work_ms','result_digest','result_artifact_id','result_ciphertext_digest'])
    IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','version','actual_work_ms','result_digest','result_artifact_id','result_ciphertext_digest'])
   OR NOT ((OLD.state='DUE' AND NEW.state IN ('RUNNING','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
    OR (OLD.state='RUNNING' AND NEW.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')))
   OR (NEW.state='QUARANTINED' AND (NEW.actual_work_ms IS NOT NULL OR NEW.result_digest IS NOT NULL))
   OR (NEW.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED') AND (NEW.actual_work_ms IS NULL OR NEW.actual_work_ms>NEW.reserved_work_ms))
   OR (NEW.state<>'COMPLETED' AND NEW.result_digest IS NOT NULL)
  THEN RAISE EXCEPTION 'proactive_run_transition';END IF;
 END IF;
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id;
 SELECT * INTO r FROM os_proactive_revisions WHERE id=NEW.revision_id;
 SELECT * INTO g FROM os_proactive_delegations WHERE id=NEW.delegation_id;
 SELECT * INTO t FROM os_tasks WHERE id=NEW.task_id;
 SELECT * INTO c FROM os_task_controls WHERE task_id=NEW.task_id;
 SELECT * INTO b FROM os_proactive_roots WHERE id=NEW.root_id;l=r.configuration->'limits';
 IF TG_OP='INSERT' THEN
  PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
  IF d.state<>'active' OR NEW.generation<>d.generation OR NEW.definition_revision<>d.configuration_revision
   OR r.definition_id<>d.id OR r.revision<>NEW.definition_revision OR g.definition_id<>d.id OR g.revision_id<>r.id
   OR g.expires_at<=clock_timestamp() OR NEW.deadline>g.expires_at OR NEW.deadline>b.deadline
   OR NEW.state<>'DUE' OR NEW.version<>1 OR NEW.actual_work_ms IS NOT NULL OR NEW.result_digest IS NOT NULL
   OR NEW.created_at>clock_timestamp()+interval '5 seconds' OR NEW.deadline<=clock_timestamp()
   OR NEW.reserved_work_ms<>(l->>'taskDeadlineMs')::bigint
   OR NEW.tool_calls<>(CASE WHEN r.configuration->>'workflowRef'='verified-wasm/1' THEN 2 ELSE 1 END)
   OR NEW.deadline>NEW.created_at+NEW.reserved_work_ms*interval '1 millisecond'
   OR t.budget_root_id<>b.id OR t.deadline<>NEW.deadline OR t.definition_ref<>r.configuration->>'definitionRef'
   OR t.definition_revision<>(r.configuration->>'definitionRevision')::bigint OR t.state<>'ACCEPTED' OR c.id IS NULL OR c.state<>'ACTIVE'
   OR NOT EXISTS(SELECT 1 FROM os_applications a JOIN os_subjects o ON o.installation_id=a.installation_id AND o.application_id=a.id
    WHERE (o.installation_id,o.application_id,o.tenant_id,o.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
    AND a.generation=d.application_generation AND a.revision=d.registration_revision AND o.generation=d.subject_generation AND o.host_policy_generation=d.policy_generation)
  THEN RAISE EXCEPTION 'proactive_current_admission';END IF;
  IF EXISTS(SELECT 1 FROM os_proactive_runs x WHERE x.definition_id=d.id AND x.state IN ('DUE','RUNNING'))
  THEN RAISE EXCEPTION 'proactive_skip_overlap';END IF;
  IF NEW.causal_parent_id IS NULL THEN
   IF NEW.depth<>0 OR b.task_limit<>(l->>'rootTaskLimit')::bigint OR b.tool_limit<>(l->>'rootToolCallLimit')::bigint
    OR b.work_limit_ms<>(l->>'rootWorkMs')::bigint OR b.depth_limit<>(l->>'maxCausalityDepth')::bigint
    OR b.deadline>NEW.created_at+b.work_limit_ms*interval '1 millisecond' THEN RAISE EXCEPTION 'proactive_original_root';END IF;
  ELSE
   SELECT * INTO p FROM os_proactive_runs WHERE id=NEW.causal_parent_id;
   IF p.root_id<>NEW.root_id OR NEW.depth<>p.depth+1 OR NEW.depth>LEAST(b.depth_limit,(l->>'maxCausalityDepth')::bigint)
    OR b.deadline<=clock_timestamp() THEN RAISE EXCEPTION 'proactive_causal_limit';END IF;
  END IF;
 END IF;
 IF NEW.state='COMPLETED' THEN
  PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
  IF d.state='revoked' OR NEW.deadline<=clock_timestamp() OR g.expires_at<=clock_timestamp() OR c.state<>'ACTIVE'
   OR NEW.result_digest IS NULL OR NOT EXISTS(SELECT 1 FROM os_artifacts a WHERE a.id=NEW.result_artifact_id
    AND a.ciphertext_digest=NEW.result_ciphertext_digest AND a.classification='owner-private' AND a.purpose='artifact')
  THEN RAISE EXCEPTION 'proactive_current_result';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_proactive_budget_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='INSERT' THEN
  IF NEW.tasks<>0 OR NEW.tool_calls<>0 OR NEW.reserved_work_ms<>0 OR NEW.spent_work_ms<>0 THEN RAISE EXCEPTION 'proactive_initial_budget';END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['tasks','tool_calls','reserved_work_ms','spent_work_ms'])
   IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['tasks','tool_calls','reserved_work_ms','spent_work_ms'])
   OR NEW.tasks<OLD.tasks OR NEW.tool_calls<OLD.tool_calls OR NEW.spent_work_ms<OLD.spent_work_ms
  THEN RAISE EXCEPTION 'proactive_original_budget';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_proactive_balance_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE day_uuid uuid;root_uuid uuid;b record;x record;t os_tasks%ROWTYPE;c os_task_controls%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='os_proactive_runs' THEN
  day_uuid=NEW.day_id;root_uuid=NEW.root_id;
  SELECT * INTO t FROM os_tasks WHERE id=NEW.task_id;SELECT * INTO c FROM os_task_controls WHERE task_id=NEW.task_id;
  IF t.deadline<>NEW.deadline OR t.budget_root_id<>NEW.root_id OR t.state<>(CASE WHEN NEW.state='DUE' THEN 'ACCEPTED' ELSE NEW.state END)
   OR (NEW.state='CANCELLED' AND c.state NOT IN ('STOP_ACKNOWLEDGED','ACTIVE'))
   OR NOT EXISTS(SELECT 1 FROM os_proactive_dispatches WHERE run_id=NEW.id)
  THEN RAISE EXCEPTION 'proactive_task_projection';END IF;
 ELSIF TG_TABLE_NAME='os_proactive_days' THEN day_uuid=NEW.id;ELSE root_uuid=NEW.id;END IF;
 IF day_uuid IS NOT NULL THEN
  SELECT * INTO b FROM os_proactive_days WHERE id=day_uuid;
  SELECT count(*) AS tasks,COALESCE(sum(tool_calls),0) AS calls,COALESCE(sum(reserved_work_ms) FILTER(WHERE actual_work_ms IS NULL),0) AS reserved,
   COALESCE(sum(actual_work_ms),0) AS spent INTO x FROM os_proactive_runs WHERE day_id=day_uuid;
  IF (b.tasks,b.tool_calls,b.reserved_work_ms,b.spent_work_ms) IS DISTINCT FROM (x.tasks,x.calls,x.reserved,x.spent)
   OR EXISTS(SELECT 1 FROM os_proactive_runs r JOIN os_proactive_revisions v ON v.id=r.revision_id WHERE r.day_id=b.id
    AND (b.day<>to_char(r.created_at AT TIME ZONE 'UTC','YYYY-MM-DD') OR b.tasks>(v.configuration->'limits'->>'dailyTaskLimit')::bigint
     OR b.tool_calls>(v.configuration->'limits'->>'dailyToolCallLimit')::bigint
     OR b.reserved_work_ms+b.spent_work_ms>(v.configuration->'limits'->>'dailyWorkMs')::bigint))
  THEN RAISE EXCEPTION 'proactive_daily_balance';END IF;
 END IF;
 IF root_uuid IS NOT NULL THEN
  SELECT * INTO b FROM os_proactive_roots WHERE id=root_uuid;
  SELECT count(*) AS tasks,COALESCE(sum(tool_calls),0) AS calls,COALESCE(sum(reserved_work_ms) FILTER(WHERE actual_work_ms IS NULL),0) AS reserved,
   COALESCE(sum(actual_work_ms),0) AS spent INTO x FROM os_proactive_runs WHERE root_id=root_uuid;
  IF (b.tasks,b.tool_calls,b.reserved_work_ms,b.spent_work_ms) IS DISTINCT FROM (x.tasks,x.calls,x.reserved,x.spent)
  THEN RAISE EXCEPTION 'proactive_root_balance';END IF;
 END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_proactive_inbox_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='INSERT' THEN
  PERFORM 1 FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id AND active FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'proactive_event_application';END IF;
  PERFORM 1 FROM os_subjects WHERE (installation_id,application_id,tenant_id,subject_id)=
   (NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id) FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'proactive_event_owner';END IF;
  IF NEW.state<>'STORED' OR NEW.attempts<>0 OR NEW.event->>'eventId'<>NEW.event_id::text OR NEW.event->>'sourceRef'<>NEW.source_ref
   OR NEW.event->'subject'<>jsonb_build_object('installationId',NEW.installation_id::text,'applicationId',NEW.application_id::text,
    'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id)
   OR NOT EXISTS(SELECT 1 FROM os_proactive_sources s WHERE s.installation_id=NEW.installation_id AND s.application_id=NEW.application_id AND s.source_ref=NEW.source_ref AND s.active
    AND s.registration->'subjectRefs' @> jsonb_build_array(NEW.event->'subject'))
  THEN RAISE EXCEPTION 'proactive_registered_event';END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['state','attempts']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','attempts'])
   OR OLD.state<>'STORED' OR NEW.attempts<OLD.attempts OR NEW.attempts>OLD.attempts+1 OR (NEW.state='POISON' AND NEW.attempts<>8)
  THEN RAISE EXCEPTION 'proactive_inbox_transition';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_proactive_source_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='UPDATE' AND ((to_jsonb(NEW)-'active') IS DISTINCT FROM (to_jsonb(OLD)-'active') OR NOT OLD.active OR NEW.active)
 THEN RAISE EXCEPTION 'proactive_registered_source_immutable';END IF;
 IF NEW.registration->>'applicationId'<>NEW.application_id::text OR NEW.registration->>'sourceRef'<>NEW.source_ref
  OR NEW.registration->>'schemaRef'<>'HostEvent/1' OR NEW.registration->>'authentication' NOT IN ('signed-webhook/1','registered-bridge/1')
 THEN RAISE EXCEPTION 'proactive_source_binding';END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_proactive_consumption_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_proactive_revisions%ROWTYPE;e os_proactive_inbox%ROWTYPE;
BEGIN
 SELECT * INTO r FROM os_proactive_revisions WHERE id=NEW.revision_id;SELECT * INTO e FROM os_proactive_inbox WHERE id=NEW.inbox_id;
 IF r.definition_id<>NEW.definition_id OR r.configuration->'event'->>'sourceRef'<>e.source_ref
  OR (NEW.outcome='ADMITTED' AND NOT EXISTS(SELECT 1 FROM os_proactive_runs x WHERE x.definition_id=NEW.definition_id
   AND x.revision_id=r.id AND x.trigger_key='event/'||e.event_id::text))
 THEN RAISE EXCEPTION 'proactive_event_consumption_binding';END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_proactive_dispatch_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'DUE' OR NEW.attempts<>0 THEN RAISE EXCEPTION 'proactive_initial_dispatch';END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['state','attempts','next_attempt_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','attempts','next_attempt_at'])
   OR OLD.state<>'DUE' OR NEW.attempts<>OLD.attempts+1 OR (NEW.state='POISON' AND NEW.attempts<>8)
   OR NEW.next_attempt_at<OLD.next_attempt_at OR NEW.next_attempt_at>clock_timestamp()+interval '31 seconds'
  THEN RAISE EXCEPTION 'proactive_dispatch_transition';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_proactive_notification_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_proactive_runs%ROWTYPE;c os_task_controls%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='os_proactive_notifications' THEN
  SELECT * INTO r FROM os_proactive_runs WHERE id=NEW.run_id;
  IF r.state<>'COMPLETED' OR r.result_digest IS NULL OR NEW.payload->>'id'<>NEW.id::text
   OR NEW.payload->>'taskId'<>r.task_id::text OR NEW.payload->>'kind'<>'result' OR NEW.payload->'acknowledged'<>'false'::jsonb
  THEN RAISE EXCEPTION 'proactive_committed_notification';END IF;
 ELSE
  PERFORM os_proactive_session(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
  IF TG_TABLE_NAME='os_proactive_task_commands' THEN
   SELECT * INTO c FROM os_task_controls WHERE task_id=NEW.task_id;
   IF c.state<>'STOP_REQUESTED' OR NEW.receipt->>'state'<>'STOP_REQUESTED' OR NEW.receipt->>'commandId'<>NEW.command_id::text
    OR NEW.receipt->>'taskId'<>NEW.task_id::text OR (NEW.receipt->>'controlVersion')::bigint<>c.version
   THEN RAISE EXCEPTION 'proactive_persisted_stop';END IF;
  END IF;
 END IF;
 RETURN NULL;
END $$;

CREATE TRIGGER proactive_definitions_immutable_delete BEFORE DELETE ON os_proactive_definitions
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_revisions_immutable_delete BEFORE DELETE ON os_proactive_revisions
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_commands_immutable_delete BEFORE DELETE ON os_proactive_commands
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_delegations_immutable_delete BEFORE DELETE ON os_proactive_delegations
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_days_immutable_delete BEFORE DELETE ON os_proactive_days
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_roots_immutable_delete BEFORE DELETE ON os_proactive_roots
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_runs_immutable_delete BEFORE DELETE ON os_proactive_runs
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_dispatches_immutable_delete BEFORE DELETE ON os_proactive_dispatches
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_sources_immutable_delete BEFORE DELETE ON os_proactive_sources
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_inbox_immutable_delete BEFORE DELETE ON os_proactive_inbox
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_event_consumptions_immutable_delete BEFORE DELETE ON os_proactive_event_consumptions
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_notifications_immutable_delete BEFORE DELETE ON os_proactive_notifications
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_acknowledgements_immutable_delete BEFORE DELETE ON os_proactive_acknowledgements
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_task_commands_immutable_delete BEFORE DELETE ON os_proactive_task_commands
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_revisions_immutable_update BEFORE UPDATE ON os_proactive_revisions
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_commands_immutable_update BEFORE UPDATE ON os_proactive_commands
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_delegations_immutable_update BEFORE UPDATE ON os_proactive_delegations
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_event_consumptions_immutable_update BEFORE UPDATE ON os_proactive_event_consumptions
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_notifications_immutable_update BEFORE UPDATE ON os_proactive_notifications
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_acknowledgements_immutable_update BEFORE UPDATE ON os_proactive_acknowledgements
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_task_commands_immutable_update BEFORE UPDATE ON os_proactive_task_commands
 FOR EACH ROW EXECUTE FUNCTION os_proactive_immutable();

CREATE TRIGGER proactive_definitions_definition_guard_insert_or_update BEFORE INSERT OR UPDATE ON os_proactive_definitions
 FOR EACH ROW EXECUTE FUNCTION os_proactive_definition_guard();

CREATE TRIGGER proactive_runs_run_guard_insert_or_update BEFORE INSERT OR UPDATE ON os_proactive_runs
 FOR EACH ROW EXECUTE FUNCTION os_proactive_run_guard();

CREATE TRIGGER proactive_days_budget_guard_insert_or_update BEFORE INSERT OR UPDATE ON os_proactive_days
 FOR EACH ROW EXECUTE FUNCTION os_proactive_budget_guard();

CREATE TRIGGER proactive_roots_budget_guard_insert_or_update BEFORE INSERT OR UPDATE ON os_proactive_roots
 FOR EACH ROW EXECUTE FUNCTION os_proactive_budget_guard();

CREATE TRIGGER proactive_inbox_inbox_guard_insert_or_update BEFORE INSERT OR UPDATE ON os_proactive_inbox
 FOR EACH ROW EXECUTE FUNCTION os_proactive_inbox_guard();

CREATE TRIGGER proactive_dispatches_dispatch_guard_insert_or_update BEFORE INSERT OR UPDATE ON os_proactive_dispatches
 FOR EACH ROW EXECUTE FUNCTION os_proactive_dispatch_guard();

CREATE TRIGGER proactive_sources_source_guard_insert_or_update BEFORE INSERT OR UPDATE ON os_proactive_sources
 FOR EACH ROW EXECUTE FUNCTION os_proactive_source_guard();

CREATE TRIGGER proactive_revisions_revision_guard_insert BEFORE INSERT ON os_proactive_revisions
 FOR EACH ROW EXECUTE FUNCTION os_proactive_revision_guard();

CREATE TRIGGER proactive_commands_command_guard_insert BEFORE INSERT ON os_proactive_commands
 FOR EACH ROW EXECUTE FUNCTION os_proactive_command_guard();

CREATE CONSTRAINT TRIGGER proactive_definitions_definition_commit_insert_or_update AFTER INSERT OR UPDATE ON os_proactive_definitions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_definition_commit();

CREATE CONSTRAINT TRIGGER proactive_delegations_delegation_commit_insert AFTER INSERT ON os_proactive_delegations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_delegation_commit();

CREATE CONSTRAINT TRIGGER proactive_runs_balance_commit_insert_or_update AFTER INSERT OR UPDATE ON os_proactive_runs
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_balance_commit();

CREATE CONSTRAINT TRIGGER proactive_days_balance_commit_insert_or_update AFTER INSERT OR UPDATE ON os_proactive_days
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_balance_commit();

CREATE CONSTRAINT TRIGGER proactive_roots_balance_commit_insert_or_update AFTER INSERT OR UPDATE ON os_proactive_roots
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_balance_commit();

CREATE CONSTRAINT TRIGGER proactive_event_consumptions_consumption_guard_insert AFTER INSERT ON os_proactive_event_consumptions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_consumption_guard();

CREATE CONSTRAINT TRIGGER proactive_notifications_notification_guard_insert AFTER INSERT ON os_proactive_notifications
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_notification_guard();

CREATE CONSTRAINT TRIGGER proactive_acknowledgements_notification_guard_insert AFTER INSERT ON os_proactive_acknowledgements
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_notification_guard();

CREATE CONSTRAINT TRIGGER proactive_task_commands_notification_guard_insert AFTER INSERT ON os_proactive_task_commands
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_proactive_notification_guard();
"""

def upgrade():
    for statement in TABLES:op.execute(statement)
    for statement in INDEXES:op.execute(statement)
    op.execute(GUARDS)

def downgrade():
    raise RuntimeError("Proactive records require reviewed forward recovery")
