"""Installation-owned recovery watermarks, separate from private deletion journal."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision = 'os_pg_0002'
down_revision = 'os_pg_0001'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('os_recovery_watermarks',
        sa.Column('installation_id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('component', sa.String(32), primary_key=True),
        sa.Column('revision', sa.BigInteger, nullable=False),
        sa.Column('generation', sa.BigInteger, nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint('revision>=0 AND generation>0', name='ck_watermark_versions'))


def downgrade():
    raise RuntimeError('Destructive downgrade disabled')
