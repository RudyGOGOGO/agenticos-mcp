"""Authoritative planned-analysis metadata and original-operation fences.

Draft: no qualification or application is implied by this source file.
Existing admitted profiles retain their original guards and semantics.
"""
from alembic import op

revision='os_pg_0072'
down_revision='os_pg_0071'
branch_labels=None
depends_on=None

TABLES=r"""
CREATE TABLE os_agent_plan_heads (
	id UUID NOT NULL, 
	task_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	segment_id UUID NOT NULL, 
	intent_revision BIGINT NOT NULL, 
	control_epoch BIGINT NOT NULL, 
	revision BIGINT NOT NULL, 
	next_ordinal BIGINT NOT NULL, 
	discovery_pins JSONB NOT NULL, 
	goal_write_id UUID, 
	goal_digest VARCHAR(64), 
	final_node_id UUID, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_plan_head_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_segments_segment_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, segment_id) REFERENCES os_segments (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_payload_writes_goal_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, goal_write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_agent_plan_task UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id), 
	CONSTRAINT uq_agent_plan_head_root UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT ck_agent_plan_head_versions CHECK (intent_revision>0 AND control_epoch>0 AND revision BETWEEN 0 AND 9007199254740991 AND next_ordinal BETWEEN 1 AND 9007199254740991), 
	CONSTRAINT ck_agent_plan_head_goal CHECK ((revision=0 AND goal_write_id IS NULL AND goal_digest IS NULL AND final_node_id IS NULL) OR (revision>0 AND goal_write_id IS NOT NULL AND goal_digest IS NOT NULL AND goal_digest ~ '^[a-f0-9]{64}$' AND final_node_id IS NOT NULL)), 
	CONSTRAINT ck_agent_plan_discovery CHECK (jsonb_typeof(discovery_pins)='array' AND jsonb_array_length(discovery_pins) BETWEEN 1 AND 128 AND octet_length(discovery_pins::text)<=65536)
)

;

CREATE TABLE os_agent_plan_revisions (
	id UUID NOT NULL, 
	head_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	task_id UUID NOT NULL, 
	command_id UUID NOT NULL, 
	revision BIGINT NOT NULL, 
	source_acceptance_id UUID NOT NULL, 
	patch_write_id UUID NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	payload JSONB NOT NULL, 
	transaction_ref VARCHAR(32) DEFAULT pg_current_xact_id()::text NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_plan_revision_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_model_acceptances_source_acceptance_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_acceptance_id) REFERENCES os_agent_model_acceptances (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_payload_writes_patch_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, patch_write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_plan_revision_head FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, head_id, root_id) REFERENCES os_agent_plan_heads (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT uq_agent_plan_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, head_id, revision), 
	CONSTRAINT uq_agent_plan_command UNIQUE (installation_id, application_id, tenant_id, subject_id, head_id, command_id), 
	CONSTRAINT uq_agent_plan_source_once UNIQUE (installation_id, application_id, tenant_id, subject_id, head_id, source_acceptance_id), 
	CONSTRAINT uq_agent_plan_revision_root UNIQUE (installation_id, application_id, tenant_id, subject_id, id, head_id, root_id), 
	CONSTRAINT ck_agent_plan_revision_number CHECK (revision BETWEEN 1 AND 9007199254740991), 
	CONSTRAINT ck_agent_plan_patch_bounds CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=1048576), 
	CONSTRAINT ck_agent_plan_revision_digest CHECK (digest ~ '^[a-f0-9]{64}$')
)

;

CREATE TABLE os_agent_plan_nodes (
	id UUID NOT NULL, 
	head_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	revision_id UUID NOT NULL, 
	ordinal BIGINT NOT NULL, 
	version BIGINT NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	payload JSONB NOT NULL, 
	outcome_write_id UUID, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_plan_node_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_payload_writes_outcome_write_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, outcome_write_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_plan_node_head FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, head_id, root_id) REFERENCES os_agent_plan_heads (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT fk_agent_plan_node_revision FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id, head_id, root_id) REFERENCES os_agent_plan_revisions (installation_id, application_id, tenant_id, subject_id, id, head_id, root_id), 
	CONSTRAINT uq_agent_plan_node_root UNIQUE (installation_id, application_id, tenant_id, subject_id, id, head_id, root_id), 
	CONSTRAINT uq_agent_plan_node_ordinal UNIQUE (installation_id, application_id, tenant_id, subject_id, head_id, ordinal), 
	CONSTRAINT ck_agent_plan_node_versions CHECK (ordinal BETWEEN 1 AND 9007199254740991 AND version BETWEEN 1 AND 9007199254740991), 
	CONSTRAINT ck_agent_plan_node_state CHECK (state IN ('UNSTARTED','STARTED','ACCEPTED','CANCELLED') AND (state='ACCEPTED')=(outcome_write_id IS NOT NULL)), 
	CONSTRAINT ck_agent_plan_node_bounds CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=16384), 
	CONSTRAINT ck_agent_plan_node_digest CHECK (digest ~ '^[a-f0-9]{64}$')
)

;

CREATE TABLE os_agent_plan_edges (
	id UUID NOT NULL, 
	head_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	child_id UUID NOT NULL, 
	child_version BIGINT NOT NULL, 
	parent_id UUID NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_plan_edge_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_plan_edge_child FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, child_id, head_id, root_id) REFERENCES os_agent_plan_nodes (installation_id, application_id, tenant_id, subject_id, id, head_id, root_id), 
	CONSTRAINT fk_agent_plan_edge_parent FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, parent_id, head_id, root_id) REFERENCES os_agent_plan_nodes (installation_id, application_id, tenant_id, subject_id, id, head_id, root_id), 
	CONSTRAINT uq_agent_plan_edge UNIQUE (installation_id, application_id, tenant_id, subject_id, child_id, child_version, parent_id), 
	CONSTRAINT ck_agent_plan_edge_versions CHECK (child_id<>parent_id AND child_version BETWEEN 1 AND 9007199254740991)
)

;

CREATE TABLE os_agent_plan_step_bindings (
	id UUID NOT NULL, 
	head_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	node_id UUID NOT NULL, 
	node_version BIGINT NOT NULL, 
	plan_revision BIGINT NOT NULL, 
	family VARCHAR(16) NOT NULL, 
	logical_operation_id UUID NOT NULL, 
	tool_operation_id UUID, 
	attempt_id UUID, 
	query_digest VARCHAR(64), 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_plan_step_binding_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_work_attempts_attempt_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_plan_step_tool FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, tool_operation_id, root_id) REFERENCES os_agent_tool_operations (installation_id, application_id, tenant_id, subject_id, id, root_id) DEFERRABLE INITIALLY DEFERRED, 
	CONSTRAINT fk_agent_plan_step_node FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, node_id, head_id, root_id) REFERENCES os_agent_plan_nodes (installation_id, application_id, tenant_id, subject_id, id, head_id, root_id), 
	CONSTRAINT uq_agent_plan_step_operation UNIQUE (installation_id, application_id, tenant_id, subject_id, family, logical_operation_id), 
	CONSTRAINT ck_agent_plan_step_versions CHECK (node_version BETWEEN 1 AND 9007199254740991 AND plan_revision BETWEEN 1 AND 9007199254740991), 
	CONSTRAINT ck_agent_plan_step_family CHECK ((family='tool' AND tool_operation_id=logical_operation_id AND tool_operation_id IS NOT NULL AND attempt_id IS NULL AND query_digest IS NOT NULL AND query_digest ~ '^[a-f0-9]{64}$') OR (family='compute' AND tool_operation_id IS NULL AND attempt_id IS NOT NULL AND query_digest IS NULL))
)

;
ALTER TABLE os_agent_plan_heads ADD CONSTRAINT fk_agent_plan_final_node FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, final_node_id, id, root_id) REFERENCES os_agent_plan_nodes (installation_id, application_id, tenant_id, subject_id, id, head_id, root_id) DEFERRABLE INITIALLY DEFERRED;
CREATE UNIQUE INDEX uq_agent_plan_compute_once ON os_agent_plan_step_bindings (installation_id, application_id, tenant_id, subject_id, node_id, node_version) WHERE family='compute';"""

CURRENT=r"""
CREATE FUNCTION os_agent_plan_current(root_uuid uuid) RETURNS os_admissions LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 t os_tasks%ROWTYPE; c os_task_controls%ROWTYPE; s os_segments%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=root_uuid;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id=(SELECT root_task_id FROM os_budget_roots WHERE id=root_uuid) FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=root_uuid FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO t FROM os_tasks WHERE id=r.root_task_id;SELECT * INTO c FROM os_task_controls WHERE task_id=t.id;
 SELECT * INTO s FROM os_segments WHERE id=a.segment_id;
 IF NOT COALESCE(r.state='ACTIVE' AND r.profile_ref='agent-production/1' AND r.accounting_format='agent-resources/1'
  AND r.deadline>clock_timestamp() AND t.deadline=r.deadline AND t.budget_root_id=r.id AND t.id=a.task_id
  AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')
  AND c.state='ACTIVE' AND c.epoch=(a.context->>'controlEpoch')::bigint
  AND s.state='OPEN' AND s.task_id=t.id AND a.context->>'rootId'=r.id::text
  AND a.context->>'taskId'=t.id::text AND a.context->>'segmentId'=s.id::text
  AND a.context->'harness'->>'ref' LIKE 'adaptive-analysis-planned/%',false)
  THEN RAISE EXCEPTION 'agent_plan_current'; END IF;
 RETURN a;
END $$;

CREATE FUNCTION os_agent_plan_payload(p jsonb,root_uuid uuid,task_uuid uuid,schema_name text)
RETURNS boolean LANGUAGE sql AS $$
 SELECT EXISTS(SELECT 1 FROM os_agent_private_payloads f JOIN os_agent_payload_writes w ON w.id=f.write_id
  JOIN os_work_attempts work ON work.id=w.attempt_id JOIN os_artifacts artifact ON artifact.id=f.id
  WHERE w.root_id=root_uuid AND w.task_id=task_uuid AND w.schema_ref=schema_name AND w.schema_version=1
   AND w.expires_at>clock_timestamp() AND artifact.expires_at>clock_timestamp() AND work.state='SETTLED'
   AND p=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,
    'bytes',w.plain_bytes,'schemaRef',schema_name,'schemaVersion',1));
$$;

CREATE FUNCTION os_agent_plan_ready(node_uuid uuid) RETURNS boolean LANGUAGE sql AS $$
 SELECT EXISTS(SELECT 1 FROM os_agent_plan_nodes n WHERE n.id=node_uuid AND n.state IN ('UNSTARTED','STARTED')
  AND NOT EXISTS(SELECT 1 FROM os_agent_plan_edges e JOIN os_agent_plan_nodes p ON p.id=e.parent_id
    WHERE e.child_id=n.id AND e.child_version=n.version AND p.state<>'ACCEPTED'));
$$;
"""

HEAD=r"""
CREATE FUNCTION os_guard_agent_plan_head() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; pins jsonb; item jsonb; goal os_agent_payload_writes%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_plan_head_immutable'; END IF;
 a=os_agent_plan_current(NEW.root_id);
 IF ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id) IS DISTINCT FROM
    ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  OR NEW.task_id<>a.task_id OR NEW.segment_id<>a.segment_id
  OR NEW.intent_revision<>(a.context->>'intentRevision')::bigint OR NEW.control_epoch<>(a.context->>'controlEpoch')::bigint
  THEN RAISE EXCEPTION 'agent_plan_head_binding'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.revision<>0 OR NEW.next_ordinal<>1 OR NEW.created_at>clock_timestamp()
   OR jsonb_typeof(NEW.discovery_pins) IS DISTINCT FROM 'array' THEN RAISE EXCEPTION 'agent_plan_initial_head'; END IF;
  FOR item IN SELECT value FROM jsonb_array_elements(NEW.discovery_pins) LOOP
   IF item IS DISTINCT FROM jsonb_build_object('ref',item->'ref','revision',item->'revision','digest',item->'digest')
    OR jsonb_typeof(item->'ref') IS DISTINCT FROM 'string' OR item->>'ref' !~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
    OR jsonb_typeof(item->'digest') IS DISTINCT FROM 'string' OR item->>'digest' !~ '^[a-f0-9]{64}$'
    OR jsonb_typeof(item->'revision') IS DISTINCT FROM 'number' OR item->>'revision' !~ '^[1-9][0-9]*$'
    OR (item->>'revision')::numeric>9007199254740991 THEN RAISE EXCEPTION 'agent_plan_discovery_pin'; END IF;
  END LOOP;
  SELECT jsonb_agg(value ORDER BY value->>'ref',(value->>'revision')::bigint,value->>'digest') INTO pins
   FROM jsonb_array_elements(NEW.discovery_pins);
  IF NEW.discovery_pins IS DISTINCT FROM pins
   OR jsonb_array_length(pins)<>(SELECT count(DISTINCT value->>'ref') FROM jsonb_array_elements(pins))
   OR a.context->'harness'->>'ref'<>'adaptive-analysis-planned/'||os_agent_profile_digest('manifest',pins)
   THEN RAISE EXCEPTION 'agent_plan_discovery_binding'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['revision','next_ordinal','goal_write_id','goal_digest','final_node_id']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['revision','next_ordinal','goal_write_id','goal_digest','final_node_id'])
   OR NEW.revision<>OLD.revision+1 OR NEW.next_ordinal<OLD.next_ordinal
   OR OLD.revision>0 AND (NEW.goal_write_id IS DISTINCT FROM OLD.goal_write_id OR NEW.goal_digest IS DISTINCT FROM OLD.goal_digest)
   OR NEW.final_node_id IS DISTINCT FROM OLD.final_node_id AND OLD.final_node_id IS NOT NULL AND
     NOT EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE id=OLD.final_node_id AND state='UNSTARTED')
   THEN RAISE EXCEPTION 'agent_plan_head_transition'; END IF;
  SELECT * INTO goal FROM os_agent_payload_writes WHERE id=NEW.goal_write_id;
  IF NOT COALESCE(goal.root_id=NEW.root_id AND goal.task_id=NEW.task_id AND goal.control_epoch=NEW.control_epoch
   AND goal.schema_ref='AgentPlannedAnalysisGoalRecord' AND goal.schema_version=1 AND goal.expires_at>clock_timestamp()
   AND EXISTS(SELECT 1 FROM os_agent_private_payloads f JOIN os_work_attempts w ON w.id=goal.attempt_id
    WHERE f.write_id=goal.id AND w.state='SETTLED'),false) THEN RAISE EXCEPTION 'agent_plan_goal_binding'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_plan_head BEFORE INSERT OR UPDATE OR DELETE ON os_agent_plan_heads
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_plan_head();

CREATE FUNCTION os_check_agent_plan_root() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE;
BEGIN
 SELECT * INTO a FROM os_admissions WHERE id=NEW.admission_id;
 IF a.context->'harness'->>'ref' LIKE 'adaptive-analysis-planned/%' AND NOT EXISTS(
  SELECT 1 FROM os_agent_plan_heads h WHERE h.root_id=NEW.id AND h.task_id=NEW.root_task_id)
  THEN RAISE EXCEPTION 'agent_plan_missing_admission_head'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_agent_plan_root AFTER INSERT ON os_budget_roots
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_plan_root();
"""

REVISION=r"""
CREATE FUNCTION os_guard_agent_plan_revision() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; h os_agent_plan_heads%ROWTYPE; w os_agent_payload_writes%ROWTYPE;
 accepted os_agent_model_acceptances%ROWTYPE; call os_agent_model_calls%ROWTYPE; model_op os_agent_operations%ROWTYPE;
 p jsonb; item jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_plan_revision_immutable'; END IF;
 a=os_agent_plan_current(NEW.root_id);
 SELECT * INTO h FROM os_agent_plan_heads WHERE id=NEW.head_id FOR UPDATE;
 SELECT * INTO w FROM os_agent_payload_writes WHERE id=NEW.patch_write_id;
 SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=NEW.source_acceptance_id;
 SELECT * INTO call FROM os_agent_model_calls WHERE id=accepted.call_id;
 SELECT o.* INTO model_op FROM os_agent_operations o JOIN os_agent_operation_models m ON m.operation_id=o.id WHERE m.id=call.id;
 p=NEW.payload;
 IF NOT COALESCE(h.root_id=NEW.root_id AND h.task_id=NEW.task_id AND NEW.task_id=a.task_id
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(h.installation_id,h.application_id,h.tenant_id,h.subject_id)
  AND h.revision IN (NEW.revision-1,NEW.revision) AND NEW.transaction_ref=pg_current_xact_id()::text
  AND NEW.digest=os_agent_profile_digest('command',p) AND NEW.created_at<=clock_timestamp()
  AND p=jsonb_build_object('taskId',NEW.task_id,'rootId',NEW.root_id,'intentRevision',h.intent_revision,'controlEpoch',h.control_epoch,
   'commandId',NEW.command_id,'baseRevision',NEW.revision-1,'revision',NEW.revision,'operations',p->'operations',
   'reasonRef','accepted-planner/'||NEW.source_acceptance_id)
  AND jsonb_typeof(p->'operations')='array' AND jsonb_array_length(p->'operations') BETWEEN 1 AND 64
  AND w.root_id=NEW.root_id AND w.task_id=NEW.task_id AND w.control_epoch=h.control_epoch
  AND w.schema_ref='AgentPlanPatch' AND w.schema_version=1 AND w.expires_at>clock_timestamp()
  AND EXISTS(SELECT 1 FROM os_agent_private_payloads f JOIN os_work_attempts work ON work.id=w.attempt_id
   WHERE f.write_id=w.id AND work.state='SETTLED')
  AND call.root_id=NEW.root_id AND call.request->'context'=a.context AND accepted.created_at<=NEW.created_at
  AND model_op.payload->'context'=a.context
  AND (model_op.payload->'identity'->>'planRevision')::bigint=greatest(1,NEW.revision-1),false)
  THEN RAISE EXCEPTION 'agent_plan_revision_binding'; END IF;
 FOR item IN SELECT value FROM jsonb_array_elements(p->'operations') LOOP
  IF (item->>'kind' IN ('add','replace-unstarted') AND item IS DISTINCT FROM jsonb_build_object('kind',item->'kind','node',item->'node'))
   OR (item->>'kind'='cancel-unstarted' AND item IS DISTINCT FROM jsonb_build_object('kind','cancel-unstarted','nodeId',item->'nodeId'))
   OR item->>'kind' NOT IN ('add','replace-unstarted','cancel-unstarted') OR item->>'kind' IS NULL
   THEN RAISE EXCEPTION 'agent_plan_patch_operation'; END IF;
 END LOOP;
 IF jsonb_array_length(p->'operations')<>(SELECT count(DISTINCT coalesce(value->>'nodeId',value->'node'->>'nodeId'))
  FROM jsonb_array_elements(p->'operations')) THEN RAISE EXCEPTION 'agent_plan_duplicate_node'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_plan_revision BEFORE INSERT OR UPDATE OR DELETE ON os_agent_plan_revisions
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_plan_revision();
"""

NODES=r"""
CREATE FUNCTION os_guard_agent_plan_node() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; h os_agent_plan_heads%ROWTYPE; revision_row os_agent_plan_revisions%ROWTYPE;
 old_revision os_agent_plan_revisions%ROWTYPE; operation jsonb; n jsonb; expected_schema text;
 dependency_write os_agent_payload_writes%ROWTYPE; outcome os_agent_payload_writes%ROWTYPE; bound boolean;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_plan_node_immutable'; END IF;
 a=os_agent_plan_current(NEW.root_id);SELECT * INTO h FROM os_agent_plan_heads WHERE id=NEW.head_id FOR UPDATE;
 SELECT * INTO revision_row FROM os_agent_plan_revisions WHERE id=NEW.revision_id;
 n=NEW.payload;
 IF NOT COALESCE(h.root_id=NEW.root_id AND h.task_id=a.task_id AND revision_row.head_id=h.id AND revision_row.root_id=h.root_id
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(h.installation_id,h.application_id,h.tenant_id,h.subject_id)
  AND NEW.digest=os_agent_profile_digest('command',n) AND n->>'nodeId'=NEW.id::text
  AND n=jsonb_build_object('nodeId',NEW.id,'kind',n->'kind','operationRef',n->'operationRef','input',n->'input',
   'bindingSetRef',null,'dependencySetRef',n->'dependencySetRef','join','all-required','requiredScopeRef',a.context->'scopeRef')
  AND n->>'kind' IN ('tool','compute','join')
  AND ((n->>'kind'='tool' AND n->>'operationRef' ~ '^analysis.query/[a-f0-9]{64}$')
   OR (n->>'kind'='compute' AND n->>'operationRef'='paged-exact-decimal-summary/1')
   OR (n->>'kind'='join' AND n->>'operationRef'='analysis.exhaustive-join/1'))
  AND n->>'dependencySetRef' ~ '^private/[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}/[a-f0-9]{64}/(0|[1-9][0-9]*)$'
  AND split_part(n->>'dependencySetRef','/',4)::numeric BETWEEN 0 AND 9007199254740991
  AND (n->>'kind'<>'join' OR split_part(n->>'dependencySetRef','/',4)::numeric>0),false)
  THEN RAISE EXCEPTION 'agent_plan_node_binding'; END IF;
 expected_schema=CASE n->>'kind' WHEN 'tool' THEN 'AgentPlannedReadInput' WHEN 'compute' THEN 'AgentPlannedComputeInput' ELSE 'AgentPlannedJoinInput' END;
 IF NOT os_agent_plan_payload(n->'input',h.root_id,h.task_id,expected_schema) THEN RAISE EXCEPTION 'agent_plan_node_input'; END IF;
 SELECT * INTO dependency_write FROM os_agent_payload_writes WHERE id=split_part(n->>'dependencySetRef','/',2)::uuid;
 IF NOT COALESCE(dependency_write.root_id=h.root_id AND dependency_write.task_id=h.task_id
  AND dependency_write.schema_ref='AgentPlanDependencySet' AND dependency_write.expires_at>clock_timestamp()
  AND EXISTS(SELECT 1 FROM os_agent_private_payloads p JOIN os_work_attempts w ON w.id=dependency_write.attempt_id
   WHERE p.write_id=dependency_write.id AND w.state='SETTLED'),false) THEN RAISE EXCEPTION 'agent_plan_node_dependencies'; END IF;
 IF TG_OP='INSERT' THEN
  SELECT value INTO operation FROM jsonb_array_elements(revision_row.payload->'operations') WHERE value->'node'->>'nodeId'=NEW.id::text;
  IF revision_row.revision<>h.revision OR revision_row.transaction_ref<>pg_current_xact_id()::text
   OR operation->>'kind' IS DISTINCT FROM 'add' OR operation->'node' IS DISTINCT FROM n
   OR NEW.version<>1 OR NEW.state<>'UNSTARTED' OR NEW.outcome_write_id IS NOT NULL
   OR NEW.ordinal>=h.next_ordinal OR NEW.created_at>clock_timestamp() THEN RAISE EXCEPTION 'agent_plan_node_initial'; END IF;
  RETURN NEW;
 END IF;
 IF ROW(NEW.id,NEW.head_id,NEW.root_id,NEW.ordinal,NEW.created_at,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
  IS DISTINCT FROM ROW(OLD.id,OLD.head_id,OLD.root_id,OLD.ordinal,OLD.created_at,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id)
  THEN RAISE EXCEPTION 'agent_plan_node_identity'; END IF;
 SELECT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings WHERE node_id=OLD.id) INTO bound;
 IF NEW.version<>OLD.version OR NEW.revision_id<>OLD.revision_id OR NEW.payload<>OLD.payload OR NEW.digest<>OLD.digest THEN
  SELECT * INTO old_revision FROM os_agent_plan_revisions WHERE id=OLD.revision_id;
  SELECT value INTO operation FROM jsonb_array_elements(revision_row.payload->'operations')
   WHERE coalesce(value->>'nodeId',value->'node'->>'nodeId')=NEW.id::text;
  IF OLD.state<>'UNSTARTED' OR bound OR NEW.version<>OLD.version+1 OR revision_row.revision<=old_revision.revision
   OR revision_row.revision<>h.revision OR revision_row.transaction_ref<>pg_current_xact_id()::text
   OR NEW.outcome_write_id IS NOT NULL THEN RAISE EXCEPTION 'agent_plan_started_replacement'; END IF;
  IF operation->>'kind'='replace-unstarted' THEN
   IF NEW.state<>'UNSTARTED' OR operation->'node' IS DISTINCT FROM n THEN RAISE EXCEPTION 'agent_plan_node_replacement'; END IF;
  ELSIF operation->>'kind'='cancel-unstarted' THEN
   IF NEW.state<>'CANCELLED' OR n<>OLD.payload THEN RAISE EXCEPTION 'agent_plan_node_cancellation'; END IF;
  ELSE RAISE EXCEPTION 'agent_plan_node_replacement'; END IF;
  RETURN NEW;
 END IF;
 IF NEW.state=OLD.state AND NEW.outcome_write_id IS NOT DISTINCT FROM OLD.outcome_write_id THEN RETURN NEW; END IF;
 IF NEW.state='STARTED' AND OLD.state='UNSTARTED' THEN
  IF n->>'kind'='tool' THEN
   IF NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_agent_tool_calls c ON c.operation_id=b.tool_operation_id
    JOIN os_agent_tool_starts s ON s.id=c.id WHERE b.node_id=NEW.id AND b.node_version=NEW.version)
    THEN RAISE EXCEPTION 'agent_plan_tool_not_begun'; END IF;
  ELSIF n->>'kind'='compute' THEN
   IF NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_work_attempts w ON w.id=b.attempt_id
    WHERE b.node_id=NEW.id AND b.node_version=NEW.version AND w.state IN ('RUNNING','SETTLED') AND w.kind='agent.compute')
    THEN RAISE EXCEPTION 'agent_plan_compute_not_begun'; END IF;
  ELSE RAISE EXCEPTION 'agent_plan_join_has_no_external_start'; END IF;
  IF NOT os_agent_plan_ready(NEW.id) THEN RAISE EXCEPTION 'agent_plan_dependencies_pending'; END IF;
 ELSIF NEW.state='ACCEPTED' AND (OLD.state='STARTED' OR OLD.state='UNSTARTED' AND n->>'kind'='join') THEN
  IF NOT os_agent_plan_ready(NEW.id) THEN RAISE EXCEPTION 'agent_plan_dependencies_pending'; END IF;
  SELECT * INTO outcome FROM os_agent_payload_writes WHERE id=NEW.outcome_write_id;
  IF NOT COALESCE(outcome.root_id=h.root_id AND outcome.task_id=h.task_id AND outcome.control_epoch=h.control_epoch
   AND outcome.schema_ref='AgentPlanNodeOutcome' AND outcome.schema_version=1 AND outcome.expires_at>clock_timestamp()
   AND EXISTS(SELECT 1 FROM os_agent_private_payloads p JOIN os_work_attempts w ON w.id=outcome.attempt_id
    WHERE p.write_id=outcome.id AND w.state='SETTLED'),false) THEN RAISE EXCEPTION 'agent_plan_outcome_binding'; END IF;
  IF n->>'kind'='tool' AND (NOT bound OR EXISTS(
   SELECT 1 FROM os_agent_plan_step_bindings b LEFT JOIN os_agent_tool_calls c ON c.operation_id=b.tool_operation_id
   LEFT JOIN os_agent_tool_acceptances accepted ON accepted.call_id=c.id
   WHERE b.node_id=NEW.id AND (c.id IS NULL OR accepted.id IS NULL))) THEN RAISE EXCEPTION 'agent_plan_read_unsettled'; END IF;
  IF n->>'kind'='compute' AND NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_work_attempts w ON w.id=b.attempt_id
   WHERE b.node_id=NEW.id AND b.node_version=NEW.version AND b.family='compute' AND w.state='SETTLED')
   THEN RAISE EXCEPTION 'agent_plan_compute_unsettled'; END IF;
 ELSE RAISE EXCEPTION 'agent_plan_node_transition'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_plan_node BEFORE INSERT OR UPDATE OR DELETE ON os_agent_plan_nodes
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_plan_node();

CREATE FUNCTION os_guard_agent_plan_edge() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE node_row os_agent_plan_nodes%ROWTYPE; parent_row os_agent_plan_nodes%ROWTYPE; revision_row os_agent_plan_revisions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_plan_edge_immutable'; END IF;
 PERFORM os_agent_plan_current(NEW.root_id);
 SELECT * INTO node_row FROM os_agent_plan_nodes WHERE id=NEW.child_id;
 SELECT * INTO parent_row FROM os_agent_plan_nodes WHERE id=NEW.parent_id;
 SELECT * INTO revision_row FROM os_agent_plan_revisions WHERE id=node_row.revision_id;
 IF NOT COALESCE(node_row.head_id=NEW.head_id AND node_row.root_id=NEW.root_id AND node_row.version=NEW.child_version
  AND node_row.state='UNSTARTED' AND parent_row.head_id=NEW.head_id AND parent_row.root_id=NEW.root_id AND parent_row.state<>'CANCELLED'
  AND revision_row.transaction_ref=pg_current_xact_id()::text,false) THEN RAISE EXCEPTION 'agent_plan_edge_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_plan_edge BEFORE INSERT OR UPDATE OR DELETE ON os_agent_plan_edges
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_plan_edge();
"""

GRAPH=r"""
CREATE FUNCTION os_check_agent_plan_revision() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE h os_agent_plan_heads%ROWTYPE; indexed_node os_agent_plan_nodes%ROWTYPE; dependencies jsonb; actual_count bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO h FROM os_agent_plan_heads WHERE id=NEW.head_id;
 IF h.revision<>(SELECT max(revision) FROM os_agent_plan_revisions WHERE head_id=h.id)
  THEN RAISE EXCEPTION 'agent_plan_revision_head'; END IF;
 IF TG_TABLE_NAME='os_agent_plan_revisions' THEN
  IF h.revision<NEW.revision THEN RAISE EXCEPTION 'agent_plan_revision_head'; END IF;
  IF h.revision<>NEW.revision THEN RETURN NULL; END IF;
 END IF;
 IF h.next_ordinal<>1+(SELECT count(*) FROM os_agent_plan_nodes WHERE head_id=h.id)
  OR EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE head_id=h.id AND ordinal>=h.next_ordinal)
  THEN RAISE EXCEPTION 'agent_plan_node_index_incomplete'; END IF;
 IF EXISTS(WITH changes AS (
   SELECT coalesce(op.value->>'nodeId',op.value->'node'->>'nodeId')::uuid id,count(*) version,max(r.revision) revision
   FROM os_agent_plan_revisions r CROSS JOIN LATERAL jsonb_array_elements(r.payload->'operations') op
   WHERE r.head_id=h.id GROUP BY 1)
  SELECT 1 FROM changes expected FULL JOIN (SELECT * FROM os_agent_plan_nodes WHERE head_id=h.id) actual ON actual.id=expected.id
   LEFT JOIN os_agent_plan_revisions latest ON latest.head_id=h.id AND latest.revision=expected.revision
  WHERE expected.id IS NULL OR actual.id IS NULL OR actual.version<>expected.version OR actual.revision_id<>latest.id)
  THEN RAISE EXCEPTION 'agent_plan_patch_index_incomplete'; END IF;
 FOR indexed_node IN SELECT * FROM os_agent_plan_nodes WHERE head_id=h.id AND state<>'CANCELLED' LOOP
  SELECT coalesce(jsonb_agg(parent_id::text ORDER BY parent_id::text),'[]'::jsonb),count(*) INTO dependencies,actual_count
   FROM os_agent_plan_edges WHERE child_id=indexed_node.id AND child_version=indexed_node.version;
  IF actual_count<>split_part(indexed_node.payload->>'dependencySetRef','/',4)::bigint
   OR os_agent_profile_digest('command',dependencies)<>split_part(indexed_node.payload->>'dependencySetRef','/',3)
   OR EXISTS(SELECT 1 FROM os_agent_plan_edges e JOIN os_agent_plan_nodes p ON p.id=e.parent_id
    WHERE e.child_id=indexed_node.id AND e.child_version=indexed_node.version AND p.state='CANCELLED')
   THEN RAISE EXCEPTION 'agent_plan_dependency_index_incomplete'; END IF;
 END LOOP;
 IF EXISTS(WITH RECURSIVE walk(child,ancestor) AS (
  SELECT e.child_id,e.parent_id FROM os_agent_plan_edges e JOIN os_agent_plan_nodes n ON n.id=e.child_id
   WHERE n.head_id=h.id AND n.version=e.child_version AND n.state<>'CANCELLED'
  UNION SELECT w.child,e.parent_id FROM walk w JOIN os_agent_plan_nodes n ON n.id=w.ancestor
   JOIN os_agent_plan_edges e ON e.child_id=n.id AND e.child_version=n.version WHERE n.state<>'CANCELLED')
  SELECT 1 FROM walk WHERE child=ancestor) THEN RAISE EXCEPTION 'agent_plan_cycle'; END IF;
 IF NOT EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE id=h.final_node_id AND head_id=h.id AND state<>'CANCELLED'
  AND payload->>'kind'='join' AND payload->>'join'='all-required') THEN RAISE EXCEPTION 'agent_plan_final_join'; END IF;
 IF (SELECT count(*) FROM os_agent_plan_nodes WHERE head_id=h.id AND state<>'CANCELLED' AND payload->>'kind'='compute')<>1
  OR NOT EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE head_id=h.id AND state<>'CANCELLED' AND payload->>'kind'='tool')
  THEN RAISE EXCEPTION 'agent_plan_analysis_shape'; END IF;
 IF EXISTS(WITH RECURSIVE required(id) AS (
  SELECT e.parent_id FROM os_agent_plan_edges e JOIN os_agent_plan_nodes n ON n.id=e.child_id
   WHERE n.id=h.final_node_id AND e.child_version=n.version
  UNION SELECT e.parent_id FROM required r JOIN os_agent_plan_nodes n ON n.id=r.id
   JOIN os_agent_plan_edges e ON e.child_id=n.id AND e.child_version=n.version)
  SELECT 1 FROM os_agent_plan_nodes n WHERE n.head_id=h.id AND n.state<>'CANCELLED' AND n.id<>h.final_node_id
   AND NOT EXISTS(SELECT 1 FROM required WHERE id=n.id)) THEN RAISE EXCEPTION 'agent_plan_unjoined_work'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_agent_plan_revision AFTER INSERT ON os_agent_plan_revisions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_plan_revision();
CREATE CONSTRAINT TRIGGER commit_agent_plan_node_index AFTER INSERT OR UPDATE ON os_agent_plan_nodes
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (NEW.state IN ('UNSTARTED','CANCELLED'))
 EXECUTE FUNCTION os_check_agent_plan_revision();
CREATE CONSTRAINT TRIGGER commit_agent_plan_edge_index AFTER INSERT ON os_agent_plan_edges
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_plan_revision();
"""


BINDINGS=r"""
CREATE FUNCTION os_guard_agent_plan_step() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; h os_agent_plan_heads%ROWTYPE; n os_agent_plan_nodes%ROWTYPE; w os_work_attempts%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_plan_step_immutable'; END IF;
 a=os_agent_plan_current(NEW.root_id);SELECT * INTO h FROM os_agent_plan_heads WHERE id=NEW.head_id FOR UPDATE;
 SELECT * INTO n FROM os_agent_plan_nodes WHERE id=NEW.node_id;
 IF NOT COALESCE(h.root_id=NEW.root_id AND n.head_id=h.id AND n.root_id=h.root_id AND n.version=NEW.node_version
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(h.installation_id,h.application_id,h.tenant_id,h.subject_id)
  AND NEW.plan_revision=h.revision AND h.revision>0 AND os_agent_plan_ready(n.id),false)
  THEN RAISE EXCEPTION 'agent_plan_step_binding'; END IF;
 IF NEW.family='tool' THEN
  IF n.payload->>'kind'<>'tool' OR n.payload->>'operationRef'<>'analysis.query/'||NEW.query_digest
   THEN RAISE EXCEPTION 'agent_plan_query_binding'; END IF;
 ELSIF NEW.family='compute' THEN
  SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;
  IF NOT COALESCE(n.payload->>'kind'='compute' AND w.root_id=h.root_id AND w.task_id=h.task_id
   AND w.segment_id=h.segment_id AND w.control_epoch=h.control_epoch AND w.state='RESERVED'
   AND w.kind='agent.compute' AND w.invocation_id=NEW.logical_operation_id,false)
   THEN RAISE EXCEPTION 'agent_plan_compute_binding'; END IF;
 ELSE RAISE EXCEPTION 'agent_plan_step_family'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_plan_step BEFORE INSERT OR UPDATE OR DELETE ON os_agent_plan_step_bindings
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_plan_step();

CREATE FUNCTION os_guard_agent_plan_operation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; h os_agent_plan_heads%ROWTYPE;
BEGIN
 IF NEW.payload->'context'->'harness'->>'ref' NOT LIKE 'adaptive-analysis-planned/%' THEN RETURN NEW; END IF;
 a=os_agent_plan_current(NEW.root_id);SELECT * INTO h FROM os_agent_plan_heads WHERE root_id=NEW.root_id FOR UPDATE;
 IF NOT COALESCE(NEW.payload->'context'=a.context AND h.id IS NOT NULL
  AND (NEW.payload->'identity'->>'planRevision')::bigint=greatest(1,h.revision),false)
  THEN RAISE EXCEPTION 'agent_plan_operation_revision'; END IF;
 IF TG_TABLE_NAME='os_agent_tool_operations' THEN
  IF h.revision=0 THEN
   IF NOT h.discovery_pins @> jsonb_build_array(NEW.payload->'capability') THEN RAISE EXCEPTION 'agent_plan_discovery_only'; END IF;
  ELSIF NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_agent_plan_nodes n ON n.id=b.node_id
   WHERE b.head_id=h.id AND b.tool_operation_id=NEW.id AND b.family='tool' AND b.node_version=n.version
    AND b.plan_revision=h.revision AND os_agent_plan_ready(n.id)) THEN RAISE EXCEPTION 'agent_plan_tool_unbound'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_plan_model_operation BEFORE INSERT ON os_agent_operations
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_plan_operation();
CREATE TRIGGER guard_agent_plan_tool_operation BEFORE INSERT ON os_agent_tool_operations
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_plan_operation();

CREATE FUNCTION os_guard_agent_plan_work_begin() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; h os_agent_plan_heads%ROWTYPE; op_payload jsonb;
BEGIN
 IF NEW.state<>'RUNNING' OR OLD.state='RUNNING' OR NEW.kind NOT IN ('agent.model','agent.tool','agent.compute') THEN RETURN NEW; END IF;
 SELECT admission.* INTO a FROM os_admissions admission JOIN os_budget_roots r ON r.admission_id=admission.id WHERE r.id=NEW.root_id;
 IF a.context->'harness'->>'ref' NOT LIKE 'adaptive-analysis-planned/%' THEN RETURN NEW; END IF;
 a=os_agent_plan_current(NEW.root_id);SELECT * INTO h FROM os_agent_plan_heads WHERE root_id=NEW.root_id FOR UPDATE;
 IF NEW.kind='agent.compute' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_agent_plan_nodes n ON n.id=b.node_id
   WHERE b.head_id=h.id AND b.attempt_id=NEW.id AND b.family='compute' AND b.node_version=n.version
    AND b.plan_revision=h.revision AND os_agent_plan_ready(n.id)) THEN RAISE EXCEPTION 'agent_plan_compute_unbound'; END IF;
 ELSIF NEW.kind='agent.model' THEN
  SELECT o.payload INTO op_payload FROM os_agent_operations o JOIN os_agent_operation_models m ON m.operation_id=o.id
   JOIN os_agent_model_calls c ON c.id=m.id WHERE c.attempt_id=NEW.id;
  IF NOT COALESCE((op_payload->'identity'->>'planRevision')::bigint=greatest(1,h.revision),false)
   THEN RAISE EXCEPTION 'agent_plan_model_stale'; END IF;
 ELSE
  SELECT o.payload INTO op_payload FROM os_agent_tool_operations o JOIN os_agent_tool_calls c ON c.operation_id=o.id WHERE c.attempt_id=NEW.id;
  IF h.revision=0 THEN
   IF NOT COALESCE(h.discovery_pins @> jsonb_build_array(op_payload->'capability'),false) THEN RAISE EXCEPTION 'agent_plan_discovery_only'; END IF;
  ELSIF NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_agent_plan_nodes n ON n.id=b.node_id
   JOIN os_agent_tool_calls c ON c.operation_id=b.tool_operation_id
   WHERE c.attempt_id=NEW.id AND b.head_id=h.id AND b.node_version=n.version AND b.plan_revision=h.revision
    AND os_agent_plan_ready(n.id)) THEN RAISE EXCEPTION 'agent_plan_tool_stale'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_plan_work_begin BEFORE UPDATE ON os_work_attempts
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_plan_work_begin();

CREATE FUNCTION os_check_agent_plan_head_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE h os_agent_plan_heads%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO h FROM os_agent_plan_heads WHERE id=NEW.id;
 IF h.revision<>coalesce((SELECT max(revision) FROM os_agent_plan_revisions WHERE head_id=h.id),0)
  THEN RAISE EXCEPTION 'agent_plan_head_unpublished_revision'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_agent_plan_head AFTER INSERT OR UPDATE ON os_agent_plan_heads
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_plan_head_commit();

CREATE FUNCTION os_check_agent_plan_completion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; h os_agent_plan_heads%ROWTYPE;
BEGIN
 IF NEW.state<>'COMPLETED' OR OLD.state='COMPLETED' THEN RETURN NULL; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_admissions WHERE task_id=NEW.id;
 IF a.context->'harness'->>'ref' NOT LIKE 'adaptive-analysis-planned/%' THEN RETURN NULL; END IF;
 SELECT * INTO h FROM os_agent_plan_heads WHERE task_id=NEW.id;
 IF h.revision IS NULL OR h.revision=0 OR EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE head_id=h.id AND state NOT IN ('ACCEPTED','CANCELLED'))
  OR NOT EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE id=h.final_node_id AND state='ACCEPTED')
  OR NOT EXISTS(SELECT 1 FROM os_agent_payload_writes w JOIN os_agent_private_payloads p ON p.write_id=w.id
   JOIN os_work_attempts work ON work.id=w.attempt_id WHERE w.task_id=NEW.id AND w.root_id=h.root_id
    AND w.schema_ref='AgentPlannedAnalysisVerification' AND work.state='SETTLED' AND w.expires_at>clock_timestamp())
  THEN RAISE EXCEPTION 'agent_plan_completion_incomplete'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_agent_plan_completion AFTER UPDATE ON os_tasks
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_plan_completion();
"""


def upgrade():
    for statement in (TABLES,CURRENT,HEAD,REVISION,NODES,GRAPH,BINDINGS):op.execute(statement)


def downgrade():
    raise RuntimeError('Planned accepted work requires protected forward recovery')
