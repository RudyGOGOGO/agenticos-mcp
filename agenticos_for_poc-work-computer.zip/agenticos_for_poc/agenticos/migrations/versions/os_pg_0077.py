"""Retain late receipt anomalies after a production root has closed."""
from alembic import op

revision='os_pg_0077'
down_revision='os_pg_0076'
branch_labels=None
depends_on=None

GUARDS=r"""
CREATE FUNCTION os_agent_receipt_regresses(previous jsonb,incoming jsonb) RETURNS boolean
LANGUAGE sql IMMUTABLE AS $$
 SELECT COALESCE(previous->'receiptId'<>'null'::jsonb AND (
  incoming->'receiptId' IS DISTINCT FROM previous->'receiptId' OR incoming->'version'='null'::jsonb
  OR (incoming->>'version')::bigint<(previous->>'version')::bigint
  OR (incoming->'version'=previous->'version' AND incoming->'status'<>previous->'status')
  OR (previous->>'status' IN ('COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED')
   AND (incoming->'status'<>previous->'status' OR incoming->'version'<>previous->'version'))),false)
$$;

CREATE OR REPLACE FUNCTION os_guard_agent_root() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF NEW.accounting_format<>'agent-resources/1' THEN RETURN NEW; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'ACTIVE' OR NEW.version<>1 OR NEW.deadline<=clock_timestamp()
   THEN RAISE EXCEPTION 'agent_root_initial'; END IF;
 ELSE
  IF OLD.state='CLOSED' AND NEW.state='QUARANTINED' THEN
   -- Only state/version can change. A deferred check below also requires an
   -- appended contradictory receipt and the matching task quarantine.
   IF NOT COALESCE(NEW.profile_ref='agent-production/1' AND NEW.version=OLD.version+1
    AND (to_jsonb(NEW)-ARRAY['state','version'])=(to_jsonb(OLD)-ARRAY['state','version'])
    AND EXISTS(SELECT 1 FROM os_work_attempts w JOIN os_agent_effect_receipts p ON p.binding_id=w.id
     WHERE w.root_id=NEW.id AND w.task_id=NEW.root_task_id AND w.kind='agent.effect' AND w.state='SETTLED'
      AND p.payload->>'status' IN ('COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED')),false)
    THEN RAISE EXCEPTION 'agent_root_transition'; END IF;
  ELSIF NEW.version<>OLD.version+1 OR OLD.state='CLOSED'
   OR (OLD.state='QUARANTINED' AND NEW.state='ACTIVE')
   THEN RAISE EXCEPTION 'agent_root_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_check_agent_closed_quarantine() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.id;
 IF NOT COALESCE(r.state='QUARANTINED'
  AND EXISTS(SELECT 1 FROM os_tasks t WHERE t.id=r.root_task_id AND t.budget_root_id=r.id AND t.state='QUARANTINED')
  AND EXISTS(SELECT 1 FROM os_work_attempts w
   JOIN os_agent_effect_receipts p ON p.binding_id=w.id
   JOIN os_agent_effect_receipts n ON n.binding_id=w.id AND n.ordinal=p.ordinal+1
   WHERE w.root_id=r.id AND w.task_id=r.root_task_id AND w.kind='agent.effect' AND w.state='SETTLED'
    AND os_agent_receipt_regresses(p.payload,n.payload)),false)
  THEN RAISE EXCEPTION 'agent_closed_quarantine_evidence'; END IF;
 RETURN NEW;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_closed_quarantine AFTER UPDATE ON os_budget_roots
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW
 WHEN (OLD.accounting_format='agent-resources/1' AND OLD.state='CLOSED' AND NEW.state='QUARANTINED')
 EXECUTE FUNCTION os_check_agent_closed_quarantine();
"""


def upgrade():
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Receipt quarantine requires protected forward recovery')
