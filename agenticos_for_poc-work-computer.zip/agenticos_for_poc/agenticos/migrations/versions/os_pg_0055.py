"""Operator-pinned independent surviving consent journal.

Protected populated rehearsal is required before application.
It grants no restored runtime, owner identity, memory or effect authority.
"""
from alembic import op

revision = 'os_pg_0055'
down_revision = 'os_pg_0054'
branch_labels = None
depends_on = None

TABLES = '''
CREATE TABLE memory_controls_recovery_profiles (
 installation_id uuid NOT NULL,
 application_id uuid NOT NULL,
 deletion_journal_id uuid NOT NULL,
 journal_id uuid NOT NULL,
 key_digest varchar(64) NOT NULL,
 created_at timestamptz NOT NULL,
 PRIMARY KEY (installation_id,application_id),
 CONSTRAINT fk_controls_recovery_deletion_profile FOREIGN KEY (installation_id,application_id,deletion_journal_id)
  REFERENCES memory_recovery_profiles (installation_id,application_id,journal_id),
 CONSTRAINT uq_controls_recovery_profile UNIQUE (installation_id,application_id,journal_id),
 CONSTRAINT uq_controls_recovery_journal UNIQUE (installation_id,journal_id),
 CONSTRAINT ck_controls_recovery_key_digest CHECK (key_digest ~ '^[a-f0-9]{64}$'),
 CONSTRAINT ck_controls_recovery_independent_journal CHECK (journal_id<>deletion_journal_id)
);
'''

GUARDS = '''
CREATE FUNCTION os_guard_controls_recovery_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE owner_role text; deletion_key text;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'controls_recovery_profile_retained';END IF;
 SELECT tableowner INTO owner_role FROM pg_tables WHERE schemaname='public' AND tablename=TG_TABLE_NAME;
 IF current_user<>owner_role THEN RAISE EXCEPTION 'controls_recovery_operator_required';END IF;
 SELECT key_digest INTO deletion_key FROM memory_recovery_profiles
  WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
   AND journal_id=NEW.deletion_journal_id;
 IF deletion_key IS NULL OR deletion_key=NEW.key_digest OR NEW.created_at>clock_timestamp()
  OR NOT EXISTS(SELECT 1 FROM os_applications WHERE installation_id=NEW.installation_id
   AND id=NEW.application_id AND active)
  THEN RAISE EXCEPTION 'controls_recovery_exact_profile';END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_controls_recovery_profile BEFORE INSERT OR UPDATE OR DELETE ON memory_controls_recovery_profiles
 FOR EACH ROW EXECUTE FUNCTION os_guard_controls_recovery_profile();
'''


def upgrade():
    op.execute(TABLES)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Retained privacy controls require protected forward recovery')
