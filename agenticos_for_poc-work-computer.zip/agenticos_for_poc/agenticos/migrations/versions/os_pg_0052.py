"""Encrypted owner persona and immutable current assistant surfaces."""
from alembic import op

revision="os_pg_0052"
down_revision="os_pg_0051"
branch_labels=None
depends_on=None
TABLES=("CREATE TABLE os_assistant_personas (\n\tid UUID NOT NULL, \n\tversion BIGINT NOT NULL, \n\tartifact_id UUID NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\tupdated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_assistant_persona_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_assistant_persona_subject FOREIGN KEY(installation_id, application_id, tenant_id, subject_id) REFERENCES os_subjects (installation_id, application_id, tenant_id, subject_id), \n\tCONSTRAINT uq_assistant_persona_owner UNIQUE (installation_id, application_id, tenant_id, subject_id), \n\tCONSTRAINT ck_assistant_persona_version CHECK (version>0), \n\tCONSTRAINT ck_assistant_persona_ciphertext_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$')\n)", "CREATE TABLE os_assistant_persona_commands (\n\tid UUID NOT NULL, \n\tpersona_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\texpected_version BIGINT NOT NULL, \n\taccepted_version BIGINT NOT NULL, \n\tartifact_id UUID NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\trequest_mac VARCHAR(64) NOT NULL, \n\tmac_key_id UUID NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_assistant_persona_command_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_assistant_personas_persona_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, persona_id) REFERENCES os_assistant_personas (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_assistant_persona_command_key UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT uq_assistant_persona_command_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, persona_id, accepted_version), \n\tCONSTRAINT ck_assistant_persona_command_version CHECK (expected_version>0 AND accepted_version=expected_version+1), \n\tCONSTRAINT ck_assistant_persona_command_mac_digest CHECK (request_mac ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_assistant_persona_command_ciphertext_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$')\n)", 'CREATE TABLE os_assistant_surfaces (\n\tid UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tconversation_id UUID NOT NULL, \n\tversion BIGINT NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_assistant_surface_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_conversations_conversation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, conversation_id) REFERENCES os_conversations (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_assistant_surface_task UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id), \n\tCONSTRAINT ck_assistant_surface_version CHECK (version>0)\n)', "CREATE TABLE os_assistant_surface_revisions (\n\tid UUID NOT NULL, \n\tsurface_id UUID NOT NULL, \n\tversion BIGINT NOT NULL, \n\tprojection_generation BIGINT NOT NULL, \n\tvisibility_generation BIGINT NOT NULL, \n\tartifact_id UUID NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\tsnapshot_hash VARCHAR(64) NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_assistant_surface_revision_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_assistant_surfaces_surface_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, surface_id) REFERENCES os_assistant_surfaces (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_assistant_surface_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, surface_id, version), \n\tCONSTRAINT ck_assistant_surface_revision_version CHECK (version>0 AND projection_generation>0 AND visibility_generation>0), \n\tCONSTRAINT ck_assistant_surface_revision_ciphertext_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_assistant_surface_revision_snapshot_digest CHECK (snapshot_hash ~ '^[a-f0-9]{64}$')\n)", "CREATE TABLE os_assistant_actions (\n\tid UUID NOT NULL, \n\taction_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\treceipt JSONB NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_assistant_action_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_assistant_surface_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES os_assistant_surface_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_assistant_action_key UNIQUE (installation_id, application_id, tenant_id, subject_id, action_id), \n\tCONSTRAINT ck_assistant_action_receipt CHECK (jsonb_typeof(receipt)='object' AND octet_length(receipt::text)<=2048), \n\tCONSTRAINT ck_assistant_action_request_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n)")
GUARDS=r"""
CREATE FUNCTION os_assistant_owner(i uuid,a uuid,t text,s text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM 1 FROM os_applications WHERE installation_id=i AND application_id=a AND active FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'assistant_current_application';END IF;
 PERFORM 1 FROM os_subjects WHERE installation_id=i AND application_id=a AND tenant_id=t AND subject_id=s AND active FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'assistant_current_owner';END IF;
END $$;
CREATE FUNCTION os_assistant_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' OR to_jsonb(OLD) IS DISTINCT FROM to_jsonb(NEW) THEN RAISE EXCEPTION 'assistant_immutable';END IF;
 RETURN NEW;
END $$;
CREATE FUNCTION os_assistant_persona_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'assistant_persona_retained';END IF;
 PERFORM os_assistant_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 THEN RAISE EXCEPTION 'assistant_persona_initial_revision';END IF;
 ELSE
  IF NEW.version<>OLD.version+1 OR (to_jsonb(NEW)-ARRAY['version','artifact_id','ciphertext_digest','updated_at'])
   IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','artifact_id','ciphertext_digest','updated_at'])
   OR NOT EXISTS(SELECT 1 FROM os_assistant_persona_commands WHERE persona_id=NEW.id AND expected_version=OLD.version
    AND accepted_version=NEW.version AND artifact_id=NEW.artifact_id AND ciphertext_digest=NEW.ciphertext_digest)
   THEN RAISE EXCEPTION 'assistant_persona_receipt_required';END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER assistant_persona_guard BEFORE INSERT OR UPDATE OR DELETE ON os_assistant_personas FOR EACH ROW EXECUTE FUNCTION os_assistant_persona_guard();
CREATE FUNCTION os_assistant_persona_command_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE p os_assistant_personas%ROWTYPE; sess os_interactive_sessions%ROWTYPE;
BEGIN
 PERFORM os_assistant_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 SELECT * INTO p FROM os_assistant_personas WHERE id=NEW.persona_id FOR UPDATE;
 SELECT * INTO sess FROM os_interactive_sessions WHERE id=NEW.session_id FOR UPDATE;
 IF p.version IS DISTINCT FROM NEW.expected_version OR sess.id IS NULL OR sess.revoked OR sess.expires_at<=clock_timestamp()
  OR sess.application_generation IS DISTINCT FROM (SELECT generation FROM os_applications WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id)
  OR sess.subject_generation IS DISTINCT FROM (SELECT generation FROM os_subjects WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id AND tenant_id=NEW.tenant_id AND subject_id=NEW.subject_id)
 THEN RAISE EXCEPTION 'assistant_persona_current_command';END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER assistant_persona_command_guard BEFORE INSERT ON os_assistant_persona_commands FOR EACH ROW EXECUTE FUNCTION os_assistant_persona_command_guard();
CREATE FUNCTION os_assistant_persona_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE p os_assistant_personas%ROWTYPE; sess os_interactive_sessions%ROWTYPE;
BEGIN
 PERFORM os_assistant_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 SELECT * INTO p FROM os_assistant_personas WHERE id=NEW.persona_id;
 SELECT * INTO sess FROM os_interactive_sessions WHERE id=NEW.session_id;
 IF p.version IS DISTINCT FROM NEW.accepted_version OR p.artifact_id IS DISTINCT FROM NEW.artifact_id
  OR p.ciphertext_digest IS DISTINCT FROM NEW.ciphertext_digest OR sess.revoked OR sess.expires_at<=clock_timestamp()
 THEN RAISE EXCEPTION 'assistant_persona_atomic_commit';END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER assistant_persona_commit AFTER INSERT ON os_assistant_persona_commands DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_assistant_persona_commit();
CREATE TRIGGER assistant_persona_command_immutable BEFORE UPDATE OR DELETE ON os_assistant_persona_commands FOR EACH ROW EXECUTE FUNCTION os_assistant_immutable();
CREATE FUNCTION os_assistant_surface_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'assistant_surface_retained';END IF;
 PERFORM os_assistant_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 IF NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND conversation_id=NEW.conversation_id)
 THEN RAISE EXCEPTION 'assistant_surface_task_conversation';END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 THEN RAISE EXCEPTION 'assistant_surface_initial_revision';END IF;
 ELSIF NEW.version<>OLD.version+1 OR (to_jsonb(NEW)-'version') IS DISTINCT FROM (to_jsonb(OLD)-'version')
 THEN RAISE EXCEPTION 'assistant_surface_revision_step';END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER assistant_surface_guard BEFORE INSERT OR UPDATE OR DELETE ON os_assistant_surfaces FOR EACH ROW EXECUTE FUNCTION os_assistant_surface_guard();
CREATE FUNCTION os_assistant_revision_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE h os_assistant_surfaces%ROWTYPE;
BEGIN
 PERFORM os_assistant_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 SELECT * INTO h FROM os_assistant_surfaces WHERE id=NEW.surface_id FOR UPDATE;
 IF h.id IS NULL OR NEW.version NOT IN (h.version,h.version+1)
  OR NEW.version=h.version AND EXISTS(SELECT 1 FROM os_assistant_surface_revisions WHERE surface_id=h.id)
  OR NEW.projection_generation IS DISTINCT FROM (SELECT version FROM os_conversations WHERE id=h.conversation_id)
  OR NEW.visibility_generation IS DISTINCT FROM (SELECT host_policy_generation FROM os_subjects WHERE installation_id=h.installation_id AND application_id=h.application_id AND tenant_id=h.tenant_id AND subject_id=h.subject_id)
 THEN RAISE EXCEPTION 'assistant_revision_exact_next';END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER assistant_revision_guard BEFORE INSERT ON os_assistant_surface_revisions FOR EACH ROW EXECUTE FUNCTION os_assistant_revision_guard();
CREATE FUNCTION os_assistant_surface_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE h os_assistant_surfaces%ROWTYPE; r os_assistant_surface_revisions%ROWTYPE;
BEGIN
 PERFORM os_assistant_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 IF TG_TABLE_NAME='os_assistant_surfaces' THEN SELECT * INTO h FROM os_assistant_surfaces WHERE id=NEW.id;
 ELSE SELECT * INTO h FROM os_assistant_surfaces WHERE id=NEW.surface_id;END IF;
 SELECT * INTO r FROM os_assistant_surface_revisions WHERE surface_id=h.id AND version=h.version;
 IF r.id IS NULL OR r.projection_generation IS DISTINCT FROM (SELECT version FROM os_conversations WHERE id=h.conversation_id)
  OR r.visibility_generation IS DISTINCT FROM (SELECT host_policy_generation FROM os_subjects WHERE installation_id=h.installation_id AND application_id=h.application_id AND tenant_id=h.tenant_id AND subject_id=h.subject_id)
 THEN RAISE EXCEPTION 'assistant_surface_current_revision';END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER assistant_surface_commit AFTER INSERT OR UPDATE ON os_assistant_surfaces DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_assistant_surface_commit();
CREATE CONSTRAINT TRIGGER assistant_revision_commit AFTER INSERT ON os_assistant_surface_revisions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_assistant_surface_commit();
CREATE TRIGGER assistant_revision_immutable BEFORE UPDATE OR DELETE ON os_assistant_surface_revisions FOR EACH ROW EXECUTE FUNCTION os_assistant_immutable();
CREATE FUNCTION os_assistant_action_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE h os_assistant_surfaces%ROWTYPE; r os_assistant_surface_revisions%ROWTYPE;
BEGIN
 PERFORM os_assistant_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 SELECT * INTO r FROM os_assistant_surface_revisions WHERE id=NEW.revision_id;
 SELECT * INTO h FROM os_assistant_surfaces WHERE id=r.surface_id FOR UPDATE;
 IF h.version IS DISTINCT FROM r.version OR r.projection_generation IS DISTINCT FROM (SELECT version FROM os_conversations WHERE id=h.conversation_id)
  OR r.visibility_generation IS DISTINCT FROM (SELECT host_policy_generation FROM os_subjects WHERE installation_id=h.installation_id AND application_id=h.application_id AND tenant_id=h.tenant_id AND subject_id=h.subject_id)
  OR NEW.receipt IS DISTINCT FROM jsonb_build_object('actionId',NEW.action_id,'surfaceId',h.id,'revision',r.version,'kind',NEW.receipt->'kind','handle',NEW.receipt->'handle')
  OR NEW.receipt->>'kind' NOT IN ('source','review','stage') OR jsonb_typeof(NEW.receipt->'handle') IS DISTINCT FROM 'string'
 THEN RAISE EXCEPTION 'assistant_action_exact_current_revision';END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER assistant_action_guard BEFORE INSERT ON os_assistant_actions FOR EACH ROW EXECUTE FUNCTION os_assistant_action_guard();
CREATE CONSTRAINT TRIGGER assistant_action_commit AFTER INSERT ON os_assistant_actions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_assistant_action_guard();
CREATE TRIGGER assistant_action_immutable BEFORE UPDATE OR DELETE ON os_assistant_actions FOR EACH ROW EXECUTE FUNCTION os_assistant_immutable();
"""

def upgrade():
    for statement in TABLES:op.execute(statement)
    op.execute(GUARDS)

def downgrade():
    raise RuntimeError("Assistant records require reviewed forward recovery")
