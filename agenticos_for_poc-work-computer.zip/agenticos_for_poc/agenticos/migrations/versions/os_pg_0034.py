"""Encrypted selected statements and atomic extraction/erasure intents."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "os_pg_0034"
down_revision = "os_pg_0033"
branch_labels = None
depends_on = None
OWNER = ["installation_id","application_id","tenant_id","subject_id"]


def scope():
    return [sa.Column("installation_id",pg.UUID(as_uuid=True),nullable=False),
        sa.Column("application_id",pg.UUID(as_uuid=True),nullable=False),
        sa.Column("tenant_id",sa.String(256),nullable=False),
        sa.Column("subject_id",sa.String(256),nullable=False)]


def uuid(name, nullable=False):
    return sa.Column(name,pg.UUID(as_uuid=True),nullable=nullable)


def integer(name):
    return sa.Column(name,sa.BigInteger,nullable=False)


def date(name, nullable=False):
    return sa.Column(name,sa.DateTime(timezone=True),nullable=nullable)


def owned(name):
    return sa.UniqueConstraint(*OWNER,"id",name="uq_"+name+"_owner_id")


def parent(table, field):
    return sa.ForeignKeyConstraint([*OWNER,field],[table+"."+k for k in [*OWNER,"id"]],
                                  name="fk_"+table+"_"+field)


def upgrade():
    op.create_table("personal_learning_sources",*scope(),
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),
        uuid("settings_id"),uuid("session_id"),uuid("command_id"),
        sa.Column("kind",sa.String(32),nullable=False),integer("revision"),
        sa.Column("state",sa.String(16),nullable=False),integer("learning_epoch"),
        sa.Column("envelope",pg.JSONB(none_as_null=True)),sa.Column("request_mac",sa.String(64)),
        uuid("mac_key_id",True),sa.Column("receipt",pg.JSONB,nullable=False),
        date("created_at"),date("updated_at"),date("expires_at"),owned("learning_source"),
        parent("personal_learning_settings","settings_id"),parent("os_interactive_sessions","session_id"),
        sa.UniqueConstraint(*OWNER,"command_id",name="uq_learning_source_command"),
        sa.CheckConstraint("kind='owner-statement/1' AND learning_epoch>0 AND "
            "((state='AVAILABLE' AND revision=1) OR (state='FORGOTTEN' AND revision=2))",name="ck_learning_source_state"),
        sa.CheckConstraint("updated_at>=created_at AND expires_at=created_at+interval '14 days'",name="ck_learning_source_time"),
        sa.CheckConstraint("(envelope IS NULL AND request_mac IS NULL AND mac_key_id IS NULL AND state='FORGOTTEN') OR "
            "(envelope IS NOT NULL AND request_mac IS NOT NULL AND request_mac ~ '^[a-f0-9]{64}$' AND mac_key_id IS NOT NULL)",
            name="ck_learning_source_private"),
        sa.CheckConstraint("envelope IS NULL OR COALESCE(envelope=jsonb_build_object('version',1,'keyId',envelope->'keyId',"
            "'nonce',envelope->'nonce','ciphertext',envelope->'ciphertext') AND jsonb_typeof(envelope->'keyId')='string' "
            "AND envelope->>'keyId' ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' "
            "AND jsonb_typeof(envelope->'nonce')='string' AND length(envelope->>'nonce')=16 "
            "AND jsonb_typeof(envelope->'ciphertext')='string' AND length(envelope->>'ciphertext') BETWEEN 24 AND 24000,false)",
            name="ck_learning_source_envelope"))
    op.create_table("personal_learning_source_intents",*scope(),
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),uuid("source_id"),integer("learning_epoch"),
        sa.Column("extractor_ref",sa.String(64),nullable=False),sa.Column("state",sa.String(32),nullable=False),
        integer("max_source_chars"),integer("max_candidates"),date("created_at"),date("due_at"),
        owned("learning_source_intent"),parent("personal_learning_sources","source_id"),
        sa.UniqueConstraint(*OWNER,"source_id",name="uq_learning_source_intent_once"),
        sa.CheckConstraint("learning_epoch>0 AND extractor_ref='synthetic-staging/1' AND "
            "state IN ('PENDING_DISPATCH','CANCELLED') AND max_source_chars=8000 AND max_candidates=8",
            name="ck_learning_source_intent_profile"),
        sa.CheckConstraint("due_at=created_at+interval '30 seconds'",name="ck_learning_source_intent_due"))
    op.create_table("personal_learning_source_forgets",*scope(),
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),uuid("source_id"),uuid("session_id"),uuid("command_id"),
        integer("learning_epoch"),sa.Column("receipt",pg.JSONB,nullable=False),date("created_at"),
        date("completed_at",True),uuid("cleanup_session_id",True),owned("learning_source_forget"),
        parent("personal_learning_sources","source_id"),parent("os_interactive_sessions","session_id"),
        parent("os_interactive_sessions","cleanup_session_id"),
        sa.UniqueConstraint(*OWNER,"source_id",name="uq_learning_source_forget_once"),
        sa.UniqueConstraint(*OWNER,"command_id",name="uq_learning_source_forget_command"),
        sa.CheckConstraint("learning_epoch>0 AND ((completed_at IS NULL AND cleanup_session_id IS NULL) OR "
            "(completed_at IS NOT NULL AND cleanup_session_id IS NOT NULL AND completed_at>=created_at))",
            name="ck_learning_source_forget_cleanup"))
    op.execute(GUARDS)


GUARDS = r"""
CREATE FUNCTION os_assert_learning_source_owner(sid uuid, session_id uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE s personal_learning_sources%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=session_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=s.installation_id AND id=s.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF s.id IS NULL OR session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
     IS DISTINCT FROM ROW(s.installation_id,s.application_id,s.tenant_id,s.subject_id)
  OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
  THEN RAISE EXCEPTION 'learning_source_current_owner'; END IF;
END $$;

CREATE FUNCTION os_assert_learning_source(sid uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE s personal_learning_sources%ROWTYPE; j personal_learning_source_intents%ROWTYPE;
 f personal_learning_source_forgets%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
 SELECT * INTO j FROM personal_learning_source_intents WHERE source_id=sid;
 SELECT * INTO f FROM personal_learning_source_forgets WHERE source_id=sid;
 IF s.id IS NULL OR settings.id IS NULL OR j.id IS NULL OR j.learning_epoch<>s.learning_epoch
  OR j.created_at<>s.created_at OR j.extractor_ref<>'synthetic-staging/1'
  OR s.receipt IS DISTINCT FROM jsonb_build_object('commandId',s.command_id,'sourceId',s.id,
   'revision',1,'learningEpoch',s.learning_epoch,'extractionState','PENDING_DISPATCH')
  THEN RAISE EXCEPTION 'learning_source_atomic_intent'; END IF;
 IF s.state='AVAILABLE' THEN
  IF f.id IS NOT NULL OR s.envelope IS NULL THEN RAISE EXCEPTION 'learning_source_live'; END IF;
 ELSE
  IF f.id IS NULL OR j.state<>'CANCELLED' OR f.learning_epoch<>s.learning_epoch OR f.created_at<>s.updated_at
   OR f.receipt IS DISTINCT FROM jsonb_build_object('commandId',f.command_id,'operationId',f.id,
    'sourceId',s.id,'revision',2,'state','FORGOTTEN')
   OR (f.completed_at IS NULL AND s.envelope IS NULL)
   OR (f.completed_at IS NOT NULL AND (s.envelope IS NOT NULL OR s.request_mac IS NOT NULL OR s.mac_key_id IS NOT NULL))
   THEN RAISE EXCEPTION 'learning_source_forget_atomic'; END IF;
 END IF;
END $$;

CREATE FUNCTION os_guard_learning_source() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_source_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'AVAILABLE' OR NEW.revision<>1 OR NEW.envelope IS NULL OR NEW.created_at<>NEW.updated_at
   THEN RAISE EXCEPTION 'learning_source_initial'; END IF;
 ELSIF OLD.state='AVAILABLE' THEN
  IF NEW.state<>'FORGOTTEN' OR NEW.revision<>2 OR NEW.updated_at<OLD.updated_at
   OR (to_jsonb(NEW)-ARRAY['state','revision','updated_at']) IS DISTINCT FROM
      (to_jsonb(OLD)-ARRAY['state','revision','updated_at'])
   THEN RAISE EXCEPTION 'learning_source_barrier_transition'; END IF;
 ELSE
  IF OLD.envelope IS NULL OR NEW.envelope IS NOT NULL OR NEW.request_mac IS NOT NULL OR NEW.mac_key_id IS NOT NULL
   OR (to_jsonb(NEW)-ARRAY['envelope','request_mac','mac_key_id']) IS DISTINCT FROM
      (to_jsonb(OLD)-ARRAY['envelope','request_mac','mac_key_id'])
   THEN RAISE EXCEPTION 'learning_source_erase_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_learning_source BEFORE INSERT OR UPDATE OR DELETE ON personal_learning_sources
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_source();

CREATE FUNCTION os_guard_learning_source_intent() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_sources%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_source_intent_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'PENDING_DISPATCH' THEN RAISE EXCEPTION 'learning_source_intent_initial'; END IF;
 ELSE
  SELECT * INTO s FROM personal_learning_sources WHERE id=OLD.source_id;
  SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
  IF OLD.state<>'PENDING_DISPATCH' OR NEW.state<>'CANCELLED'
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state')
   OR (s.state='AVAILABLE' AND settings.choice->'learnConversation'='true'::jsonb
       AND settings.learning_epoch=s.learning_epoch AND s.expires_at>clock_timestamp())
   THEN RAISE EXCEPTION 'learning_source_intent_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_learning_source_intent BEFORE INSERT OR UPDATE OR DELETE ON personal_learning_source_intents
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_source_intent();

CREATE FUNCTION os_guard_learning_source_forget() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_source_forget_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.completed_at IS NOT NULL OR NEW.cleanup_session_id IS NOT NULL THEN RAISE EXCEPTION 'learning_source_forget_initial'; END IF;
 ELSE
  IF OLD.completed_at IS NOT NULL OR NEW.completed_at IS NULL OR NEW.cleanup_session_id IS NULL
   OR (to_jsonb(NEW)-ARRAY['completed_at','cleanup_session_id']) IS DISTINCT FROM
      (to_jsonb(OLD)-ARRAY['completed_at','cleanup_session_id'])
   THEN RAISE EXCEPTION 'learning_source_forget_immutable'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_learning_source_forget BEFORE INSERT OR UPDATE OR DELETE ON personal_learning_source_forgets
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_source_forget();

CREATE FUNCTION os_guard_learning_source_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE sid uuid; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_learning_sources' THEN
  sid=NEW.id;
  IF TG_OP='INSERT' THEN
   SELECT * INTO settings FROM personal_learning_settings WHERE id=NEW.settings_id;
   IF settings.choice->'learnConversation' IS DISTINCT FROM 'true'::jsonb
    OR settings.learning_epoch<>NEW.learning_epoch OR NEW.expires_at<=clock_timestamp()
    OR (SELECT count(*) FROM personal_learning_sources WHERE settings_id=NEW.settings_id AND state='AVAILABLE')>64
    THEN RAISE EXCEPTION 'learning_source_consent_capacity'; END IF;
   PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
  END IF;
 ELSE
  sid=NEW.source_id;
  IF TG_TABLE_NAME='personal_learning_source_forgets' THEN
   IF TG_OP='INSERT' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
   ELSE PERFORM os_assert_learning_source_owner(sid,NEW.cleanup_session_id); END IF;
  END IF;
 END IF;
 PERFORM os_assert_learning_source(sid);
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_learning_source AFTER INSERT OR UPDATE ON personal_learning_sources
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_source_commit();
CREATE CONSTRAINT TRIGGER commit_learning_source_intent AFTER INSERT OR UPDATE ON personal_learning_source_intents
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_source_commit();
CREATE CONSTRAINT TRIGGER commit_learning_source_forget AFTER INSERT OR UPDATE ON personal_learning_source_forgets
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_source_commit();
"""


def downgrade():
    raise RuntimeError("Owned populated data requires protected forward recovery")
