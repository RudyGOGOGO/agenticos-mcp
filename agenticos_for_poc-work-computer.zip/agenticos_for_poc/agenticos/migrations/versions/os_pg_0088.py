"""Draft: authenticated analysis-basis replies on the original finite Root.

The registered harness pin binds the policy and discovery set. All original
owner, command, metered payload, expiry, control and UNKNOWN predicates remain.
Protected populated runtime/negative/rollback/forward/recovery is required
before this additive revision can be frozen.
"""
from alembic import op

revision='os_pg_0088'
down_revision='os_pg_0087'
branch_labels=None
depends_on=None

OWNER_REPLY=r"""
CREATE OR REPLACE FUNCTION os_assert_agent_owner_reply_dependency(dep jsonb,c jsonb,root uuid,before_at timestamptz)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; r os_budget_roots%ROWTYPE; accepted os_commands%ROWTYPE; prepared os_commands%ROWTYPE;
 p os_agent_payload_writes%ROWTYPE; f os_agent_private_payloads%ROWTYPE; w os_work_attempts%ROWTYPE;
 artifact os_artifacts%ROWTYPE; payload jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO r FROM os_budget_roots WHERE id=root;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO accepted FROM os_commands WHERE id=(dep->>'resultId')::uuid;
 SELECT * INTO prepared FROM os_commands WHERE kind='agent-owner-reply-prepare/1' AND accepted_task_id=a.task_id;
 SELECT * INTO p FROM os_agent_payload_writes WHERE id=(dep->>'producerStepId')::uuid;
 SELECT * INTO f FROM os_agent_private_payloads WHERE write_id=p.id;
 SELECT * INTO artifact FROM os_artifacts WHERE id=f.id;
 SELECT * INTO w FROM os_work_attempts WHERE id=p.attempt_id;
 payload:=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,
  'bytes',p.plain_bytes,'schemaRef','AgentOwnerReply','schemaVersion',1);
 IF NOT COALESCE(a.context=c AND (c->'harness'->>'ref'='agent-sdk-owner-input/1' OR c->'harness'->>'ref' ~ '^clarified-paged-analysis/[0-9a-f]{64}$')
  AND accepted.kind='agent-owner-reply/1' AND accepted.accepted_task_id=a.task_id
  AND ROW(accepted.installation_id,accepted.application_id,accepted.tenant_id,accepted.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND ROW(prepared.installation_id,prepared.application_id,prepared.tenant_id,prepared.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND accepted.command_id=prepared.command_id AND accepted.request_digest=os_agent_profile_digest('command',
      jsonb_build_object('preparedDigest',prepared.request_digest,'reply',payload))
  AND p.root_id=root AND p.task_id=a.task_id AND p.segment_id=a.segment_id
  AND p.control_epoch=(c->>'controlEpoch')::bigint AND p.schema_ref='AgentOwnerReply' AND p.schema_version=1
  AND ROW(p.installation_id,p.application_id,p.tenant_id,p.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND w.state='SETTLED' AND w.kind='agent.storage' AND w.root_id=root
  AND p.expires_at>clock_timestamp() AND artifact.expires_at=p.expires_at
  AND accepted.created_at>=f.created_at AND prepared.created_at<=p.created_at
  AND accepted.created_at<=before_at
  AND dep=jsonb_build_object('subject',c->'subject','taskId',a.task_id,'rootId',root,'resultId',accepted.id,
      'producerStepId',p.id,'acceptedAttemptId',p.attempt_id,'payload',payload,'lineageRef',null,
      'scopeRef',c->'scopeRef','acceptedAt',dep->'acceptedAt')
  AND (dep->>'acceptedAt')::timestamptz=accepted.created_at,false)
 THEN RAISE EXCEPTION 'agent_owner_reply_dependency'; END IF;
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_owner_reply_command() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE t os_tasks%ROWTYPE; r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE;
 a os_admissions%ROWTYPE; prepared os_commands%ROWTYPE; p os_agent_payload_writes%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; payload jsonb; matched integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_owner_reply_command_immutable'; END IF;
 SELECT * INTO t FROM os_tasks WHERE id=NEW.accepted_task_id;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=t.budget_root_id;
 PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (t.id,(SELECT root_task_id FROM os_budget_roots WHERE id=t.budget_root_id))
  ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=t.budget_root_id FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND t.deadline>clock_timestamp()
  AND r.accounting_format='agent-resources/1' AND t.state='WAITING_INPUT'
  AND (a.context->'harness'->>'ref'='agent-sdk-owner-input/1' OR a.context->'harness'->>'ref' ~ '^clarified-paged-analysis/[0-9a-f]{64}$')
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.state='OPEN')
  AND NOT EXISTS(SELECT 1 FROM os_task_controls k WHERE k.task_id IN (t.id,r.root_task_id)
      AND (k.state<>'ACTIVE' OR k.epoch<>(a.context->>'controlEpoch')::bigint))
  AND NOT EXISTS(SELECT 1 FROM jsonb_each_text(r.outstanding) x WHERE x.value::bigint<>0)
  AND NEW.created_at<=clock_timestamp()
  AND NOT EXISTS(SELECT 1 FROM os_commands prior_command WHERE prior_command.accepted_task_id=t.id AND prior_command.kind=NEW.kind),false)
 THEN RAISE EXCEPTION 'agent_owner_reply_command_binding'; END IF;
 IF NEW.kind='agent-owner-reply/1' THEN
  SELECT * INTO prepared FROM os_commands WHERE accepted_task_id=t.id AND kind='agent-owner-reply-prepare/1';
  SELECT count(*) INTO matched FROM os_agent_payload_writes WHERE root_id=r.id AND schema_ref='AgentOwnerReply' AND schema_version=1;
  SELECT * INTO p FROM os_agent_payload_writes WHERE root_id=r.id AND schema_ref='AgentOwnerReply' AND schema_version=1;
  SELECT * INTO f FROM os_agent_private_payloads WHERE write_id=p.id;
  payload:=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,
   'bytes',p.plain_bytes,'schemaRef','AgentOwnerReply','schemaVersion',1);
  IF NOT COALESCE(matched=1 AND NEW.command_id=prepared.command_id AND NEW.created_at>=f.created_at
    AND prepared.created_at<=p.created_at AND NEW.request_digest=os_agent_profile_digest('command',
     jsonb_build_object('preparedDigest',prepared.request_digest,'reply',payload))
    AND p.task_id=t.id AND p.segment_id=a.segment_id AND p.control_epoch=(a.context->>'controlEpoch')::bigint
    AND EXISTS(SELECT 1 FROM os_work_attempts w WHERE w.id=p.attempt_id AND w.state='SETTLED' AND w.kind='agent.storage'),false)
  THEN RAISE EXCEPTION 'agent_owner_reply_command_payload'; END IF;
 END IF;
 RETURN NEW;
END $$;
"""


def upgrade():
    op.execute(OWNER_REPLY)


def downgrade():
    raise RuntimeError('Analysis clarification requires protected forward recovery')
