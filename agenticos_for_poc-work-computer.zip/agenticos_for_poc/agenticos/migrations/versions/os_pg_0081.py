"""Draft exact original-root storage dependencies for current query fact pages.

Not applied or frozen. Protected populated positive/negative runtime, rollback,
forward/catalog and independent0080 recovery remain required. Existing input
branches preserve the exact frozen0074 function body.
"""
from alembic import op

revision='os_pg_0081'
down_revision='os_pg_0080'
branch_labels=None
depends_on=None

QUERY_FACTS=r"""
CREATE FUNCTION os_assert_agent_query_fact_dependency(dep jsonb,c jsonb,root uuid,before_at timestamptz)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; r os_budget_roots%ROWTYPE;
 p os_agent_payload_writes%ROWTYPE; f os_agent_private_payloads%ROWTYPE;
 w os_work_attempts%ROWTYPE; artifact os_artifacts%ROWTYPE; payload jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO r FROM os_budget_roots WHERE id=root;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO p FROM os_agent_payload_writes WHERE id=(dep->>'producerStepId')::uuid;
 SELECT * INTO f FROM os_agent_private_payloads WHERE write_id=p.id;
 SELECT * INTO artifact FROM os_artifacts WHERE id=f.id;
 SELECT * INTO w FROM os_work_attempts WHERE id=p.attempt_id;
 payload:=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,
  'bytes',p.plain_bytes,'schemaRef','AgentQueryFactSet','schemaVersion',1);
 IF NOT COALESCE(a.context=c AND c->'harness'->>'ref'='focused-child-reads/1'
  AND p.root_id=root AND p.task_id=a.task_id AND p.segment_id=a.segment_id
  AND p.control_epoch=(c->>'controlEpoch')::bigint AND p.schema_ref='AgentQueryFactSet' AND p.schema_version=1
  AND ROW(p.installation_id,p.application_id,p.tenant_id,p.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=
      ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  AND w.state='SETTLED' AND w.kind='agent.storage' AND w.root_id=root
  AND p.expires_at>clock_timestamp() AND artifact.expires_at=p.expires_at
  AND artifact.ciphertext_digest=f.ciphertext_digest
  AND p.created_at<=f.created_at AND f.created_at<=before_at AND before_at<=clock_timestamp()
  AND EXISTS(SELECT 1 FROM os_agent_payload_writes intent JOIN os_work_attempts iw ON iw.id=intent.attempt_id
      WHERE intent.root_id=root AND intent.task_id=a.task_id AND intent.segment_id=a.segment_id
       AND intent.schema_ref='AgentQuerySourceIntentRecord' AND intent.schema_version=1
       AND iw.state='SETTLED' AND iw.kind='agent.storage' AND intent.created_at<=p.created_at
       AND intent.expires_at>clock_timestamp())
  AND dep=jsonb_build_object('subject',c->'subject','taskId',a.task_id,'rootId',root,'resultId',p.id,
      'producerStepId',p.id,'acceptedAttemptId',p.attempt_id,'payload',payload,'lineageRef',null,
      'scopeRef',c->'scopeRef','acceptedAt',dep->'acceptedAt')
  AND (dep->>'acceptedAt')::timestamptz=f.created_at,false)
 THEN RAISE EXCEPTION 'agent_query_fact_dependency'; END IF;
END $$;
"""

DEPENDENCY="CREATE OR REPLACE FUNCTION os_assert_agent_input_dependency(dep jsonb,c jsonb,root uuid,before_at timestamptz) RETURNS void LANGUAGE plpgsql AS $$\nDECLARE accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;\n tool_accepted os_agent_tool_acceptances%ROWTYPE; tool os_agent_tool_calls%ROWTYPE; tool_archive os_agent_tool_archives%ROWTYPE;\n page os_agent_input_result_sets%ROWTYPE; artifact os_artifacts%ROWTYPE; expected_schema text;\nBEGIN\n\n IF dep->'payload'->>'schemaRef'='AgentQueryFactSet' THEN\n  PERFORM os_assert_agent_query_fact_dependency(dep,c,root,before_at);\n  RETURN;\n END IF;\n IF dep->'payload'->>'schemaRef'='AgentOwnerReply' THEN\n  PERFORM os_assert_agent_owner_reply_dependency(dep,c,root,before_at);\n  RETURN;\n END IF;\n PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);\n IF dep->'payload'->>'schemaRef'='AgentProviderResponse' THEN\n  SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=(dep->>'resultId')::uuid;\n  SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;\n  SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;\n  IF NOT COALESCE(producer.root_id=root AND producer.request->'context'->'subject'=c->'subject'\n   AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,\n    'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,\n     'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),\n    'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')\n   AND (dep->>'acceptedAt')::timestamptz=accepted.created_at AND accepted.created_at<=before_at AND producer.expires_at>clock_timestamp(),false)\n  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;\n ELSIF dep->'payload'->>'schemaRef' IN ('EvidencePage','AgentQueryPage') THEN\n  SELECT * INTO tool_accepted FROM os_agent_tool_acceptances WHERE id=(dep->>'resultId')::uuid;\n  SELECT * INTO tool FROM os_agent_tool_calls WHERE id=tool_accepted.call_id;\n  SELECT * INTO tool_archive FROM os_agent_tool_archives WHERE id=tool_accepted.artifact_id;\n  SELECT CASE p.payload->'read'->>'outputContract' WHEN 'EvidencePage/1' THEN 'EvidencePage' WHEN 'AgentQueryPage/1' THEN 'AgentQueryPage' END INTO expected_schema\n   FROM os_agent_tool_profiles p WHERE p.installation_id=tool.installation_id AND p.application_id=tool.application_id\n    AND p.policy_digest=tool.request->'record'->'profile'->>'digest';\n  IF NOT COALESCE(expected_schema=dep->'payload'->>'schemaRef' AND tool.root_id=root AND tool.request->'record'->'context'->'subject'=c->'subject'\n   AND dep=jsonb_build_object('subject',c->'subject','taskId',tool.request->'record'->'context'->'taskId','rootId',tool.root_id,\n    'resultId',tool_accepted.id,'producerStepId',tool.id,'acceptedAttemptId',tool.attempt_id,\n    'payload',jsonb_build_object('artifactRef','artifact/'||tool_archive.id,'ciphertextDigest',tool_archive.ciphertext_digest,\n     'bytes',tool_archive.plain_bytes,'schemaRef',expected_schema,'schemaVersion',1),\n    'lineageRef',null,'scopeRef',tool.request->'record'->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')\n   AND (dep->>'acceptedAt')::timestamptz=tool_accepted.created_at AND tool_accepted.created_at<=before_at AND tool.expires_at>clock_timestamp(),false)\n  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;\n ELSIF dep->'payload'->>'schemaRef'='AgentInputResultSet' THEN\n  SELECT * INTO page FROM os_agent_input_result_sets WHERE id=(dep->>'producerStepId')::uuid;\n  SELECT * INTO artifact FROM os_artifacts WHERE id=page.artifact_id;\n  IF NOT COALESCE(page.root_id=root AND page.record->'context'=c AND page.reference=dep\n   AND page.created_at<=before_at AND artifact.expires_at>clock_timestamp(),false)\n  THEN RAISE EXCEPTION 'agent_operation_dependency'; END IF;\n ELSE RAISE EXCEPTION 'agent_operation_dependency';\n END IF;\nEND $$;"


def upgrade():
    op.execute(QUERY_FACTS)
    op.execute(DEPENDENCY)


def downgrade():
    raise RuntimeError('Accepted current query facts require protected forward recovery')
