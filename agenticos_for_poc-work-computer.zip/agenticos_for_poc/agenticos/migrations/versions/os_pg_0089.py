"""Draft: exact extrema/ratio goals on the original planned-analysis guards.

Revision3 selects only the additive goal record and compute operator. All
original current-owner, immutable node/dependency, accounting and UNKNOWN
predicates remain. Protected runtime/negative/rollback/forward/recovery is
required before this revision is applied or frozen.
"""
from alembic import op

revision='os_pg_0089'
down_revision='os_pg_0088'
branch_labels=None
depends_on=None

HEAD=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_plan_head() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; pins jsonb; item jsonb; goal os_agent_payload_writes%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_plan_head_immutable'; END IF;
 a=os_agent_plan_current(NEW.root_id);
 IF (a.context->'harness'->>'revision')::bigint NOT IN (1,2,3) THEN RAISE EXCEPTION 'agent_plan_profile_version'; END IF;
 IF ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id) IS DISTINCT FROM
    ROW(a.installation_id,a.application_id,a.tenant_id,a.subject_id)
  OR NEW.task_id<>a.task_id OR NEW.segment_id<>a.segment_id
  OR NEW.intent_revision<>(a.context->>'intentRevision')::bigint OR NEW.control_epoch<>(a.context->>'controlEpoch')::bigint
  THEN RAISE EXCEPTION 'agent_plan_head_binding'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.revision<>0 OR NEW.next_ordinal<>1 OR NEW.created_at>clock_timestamp()
   OR jsonb_typeof(NEW.discovery_pins) IS DISTINCT FROM 'array' THEN RAISE EXCEPTION 'agent_plan_initial_head'; END IF;
  FOR item IN SELECT value FROM jsonb_array_elements(NEW.discovery_pins) LOOP
   IF item IS DISTINCT FROM jsonb_build_object('ref',item->'ref','revision',item->'revision','digest',item->'digest')
    OR jsonb_typeof(item->'ref') IS DISTINCT FROM 'string' OR item->>'ref' !~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
    OR jsonb_typeof(item->'digest') IS DISTINCT FROM 'string' OR item->>'digest' !~ '^[a-f0-9]{64}$'
    OR jsonb_typeof(item->'revision') IS DISTINCT FROM 'number' OR item->>'revision' !~ '^[1-9][0-9]*$'
    OR (item->>'revision')::numeric>9007199254740991 THEN RAISE EXCEPTION 'agent_plan_discovery_pin'; END IF;
  END LOOP;
  SELECT jsonb_agg(value ORDER BY value->>'ref',(value->>'revision')::bigint,value->>'digest') INTO pins
   FROM jsonb_array_elements(NEW.discovery_pins);
  IF NEW.discovery_pins IS DISTINCT FROM pins
   OR jsonb_array_length(pins)<>(SELECT count(DISTINCT value->>'ref') FROM jsonb_array_elements(pins))
   OR a.context->'harness'->>'ref'<>'adaptive-analysis-planned/'||os_agent_profile_digest('manifest',pins)
   THEN RAISE EXCEPTION 'agent_plan_discovery_binding'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['revision','next_ordinal','goal_write_id','goal_digest','final_node_id']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['revision','next_ordinal','goal_write_id','goal_digest','final_node_id'])
   OR NEW.revision<>OLD.revision+1 OR NEW.next_ordinal<OLD.next_ordinal
   OR OLD.revision>0 AND (NEW.goal_write_id IS DISTINCT FROM OLD.goal_write_id OR NEW.goal_digest IS DISTINCT FROM OLD.goal_digest)
   OR NEW.final_node_id IS DISTINCT FROM OLD.final_node_id AND OLD.final_node_id IS NOT NULL AND
     NOT EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE id=OLD.final_node_id AND state='UNSTARTED')
   THEN RAISE EXCEPTION 'agent_plan_head_transition'; END IF;
  SELECT * INTO goal FROM os_agent_payload_writes WHERE id=NEW.goal_write_id;
  IF NOT COALESCE(goal.root_id=NEW.root_id AND goal.task_id=NEW.task_id AND goal.control_epoch=NEW.control_epoch
   AND goal.schema_ref=CASE (a.context->'harness'->>'revision')::bigint WHEN 3 THEN 'AgentExtremaComparisonGoalRecord'
    WHEN 2 THEN 'AgentComparisonGoalRecord' ELSE 'AgentPlannedAnalysisGoalRecord' END AND goal.schema_version=1 AND goal.expires_at>clock_timestamp()
   AND EXISTS(SELECT 1 FROM os_agent_private_payloads f JOIN os_work_attempts w ON w.id=goal.attempt_id
    WHERE f.write_id=goal.id AND w.state='SETTLED'),false) THEN RAISE EXCEPTION 'agent_plan_goal_binding'; END IF;
 END IF;
 RETURN NEW;
END $$;
"""

NODE=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_plan_node() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; h os_agent_plan_heads%ROWTYPE; revision_row os_agent_plan_revisions%ROWTYPE;
 old_revision os_agent_plan_revisions%ROWTYPE; operation jsonb; n jsonb; expected_schema text;
 dependency_write os_agent_payload_writes%ROWTYPE; outcome os_agent_payload_writes%ROWTYPE; bound boolean;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_plan_node_immutable'; END IF;
 a=os_agent_plan_current(NEW.root_id);SELECT * INTO h FROM os_agent_plan_heads WHERE id=NEW.head_id FOR UPDATE;
 SELECT * INTO revision_row FROM os_agent_plan_revisions WHERE id=NEW.revision_id;
 n=NEW.payload;
 IF NOT COALESCE(h.root_id=NEW.root_id AND h.task_id=a.task_id AND revision_row.head_id=h.id AND revision_row.root_id=h.root_id
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=ROW(h.installation_id,h.application_id,h.tenant_id,h.subject_id)
  AND NEW.digest=os_agent_profile_digest('command',n) AND n->>'nodeId'=NEW.id::text
  AND n=jsonb_build_object('nodeId',NEW.id,'kind',n->'kind','operationRef',n->'operationRef','input',n->'input',
   'bindingSetRef',null,'dependencySetRef',n->'dependencySetRef','join','all-required','requiredScopeRef',a.context->'scopeRef')
  AND n->>'kind' IN ('tool','compute','join')
  AND ((n->>'kind'='tool' AND n->>'operationRef' ~ '^analysis.query/[a-f0-9]{64}$')
   OR (n->>'kind'='compute' AND n->>'operationRef'=CASE (a.context->'harness'->>'revision')::bigint WHEN 3 THEN 'exact-extrema-ratio-comparison/1'
    WHEN 2 THEN 'exact-period-comparison/1' ELSE 'paged-exact-decimal-summary/1' END)
   OR (n->>'kind'='join' AND n->>'operationRef'='analysis.exhaustive-join/1'))
  AND n->>'dependencySetRef' ~ '^private/[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}/[a-f0-9]{64}/(0|[1-9][0-9]*)$'
  AND split_part(n->>'dependencySetRef','/',4)::numeric BETWEEN 0 AND 9007199254740991
  AND (n->>'kind'<>'join' OR split_part(n->>'dependencySetRef','/',4)::numeric>0),false)
  THEN RAISE EXCEPTION 'agent_plan_node_binding'; END IF;
 expected_schema=CASE n->>'kind' WHEN 'tool' THEN 'AgentPlannedReadInput' WHEN 'compute' THEN 'AgentPlannedComputeInput' ELSE 'AgentPlannedJoinInput' END;
 IF NOT os_agent_plan_payload(n->'input',h.root_id,h.task_id,expected_schema) THEN RAISE EXCEPTION 'agent_plan_node_input'; END IF;
 SELECT * INTO dependency_write FROM os_agent_payload_writes WHERE id=split_part(n->>'dependencySetRef','/',2)::uuid;
 IF NOT COALESCE(dependency_write.root_id=h.root_id AND dependency_write.task_id=h.task_id
  AND dependency_write.schema_ref='AgentPlanDependencySet' AND dependency_write.expires_at>clock_timestamp()
  AND EXISTS(SELECT 1 FROM os_agent_private_payloads p JOIN os_work_attempts w ON w.id=dependency_write.attempt_id
   WHERE p.write_id=dependency_write.id AND w.state='SETTLED'),false) THEN RAISE EXCEPTION 'agent_plan_node_dependencies'; END IF;
 IF TG_OP='INSERT' THEN
  SELECT value INTO operation FROM jsonb_array_elements(revision_row.payload->'operations') WHERE value->'node'->>'nodeId'=NEW.id::text;
  IF revision_row.revision<>h.revision OR revision_row.transaction_ref<>pg_current_xact_id()::text
   OR operation->>'kind' IS DISTINCT FROM 'add' OR operation->'node' IS DISTINCT FROM n
   OR NEW.version<>1 OR NEW.state<>'UNSTARTED' OR NEW.outcome_write_id IS NOT NULL
   OR NEW.ordinal>=h.next_ordinal OR NEW.created_at>clock_timestamp() THEN RAISE EXCEPTION 'agent_plan_node_initial'; END IF;
  RETURN NEW;
 END IF;
 IF ROW(NEW.id,NEW.head_id,NEW.root_id,NEW.ordinal,NEW.created_at,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
  IS DISTINCT FROM ROW(OLD.id,OLD.head_id,OLD.root_id,OLD.ordinal,OLD.created_at,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id)
  THEN RAISE EXCEPTION 'agent_plan_node_identity'; END IF;
 SELECT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings WHERE node_id=OLD.id) INTO bound;
 IF NEW.version<>OLD.version OR NEW.revision_id<>OLD.revision_id OR NEW.payload<>OLD.payload OR NEW.digest<>OLD.digest THEN
  SELECT * INTO old_revision FROM os_agent_plan_revisions WHERE id=OLD.revision_id;
  SELECT value INTO operation FROM jsonb_array_elements(revision_row.payload->'operations')
   WHERE coalesce(value->>'nodeId',value->'node'->>'nodeId')=NEW.id::text;
  IF OLD.state<>'UNSTARTED' OR bound OR NEW.version<>OLD.version+1 OR revision_row.revision<=old_revision.revision
   OR revision_row.revision<>h.revision OR revision_row.transaction_ref<>pg_current_xact_id()::text
   OR NEW.outcome_write_id IS NOT NULL THEN RAISE EXCEPTION 'agent_plan_started_replacement'; END IF;
  IF operation->>'kind'='replace-unstarted' THEN
   IF NEW.state<>'UNSTARTED' OR operation->'node' IS DISTINCT FROM n THEN RAISE EXCEPTION 'agent_plan_node_replacement'; END IF;
  ELSIF operation->>'kind'='cancel-unstarted' THEN
   IF NEW.state<>'CANCELLED' OR n<>OLD.payload THEN RAISE EXCEPTION 'agent_plan_node_cancellation'; END IF;
  ELSE RAISE EXCEPTION 'agent_plan_node_replacement'; END IF;
  RETURN NEW;
 END IF;
 IF NEW.state=OLD.state AND NEW.outcome_write_id IS NOT DISTINCT FROM OLD.outcome_write_id THEN RETURN NEW; END IF;
 IF NEW.state='STARTED' AND OLD.state='UNSTARTED' THEN
  IF n->>'kind'='tool' THEN
   IF NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_agent_tool_calls c ON c.operation_id=b.tool_operation_id
    JOIN os_agent_tool_starts s ON s.id=c.id WHERE b.node_id=NEW.id AND b.node_version=NEW.version)
    THEN RAISE EXCEPTION 'agent_plan_tool_not_begun'; END IF;
  ELSIF n->>'kind'='compute' THEN
   IF NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_work_attempts w ON w.id=b.attempt_id
    WHERE b.node_id=NEW.id AND b.node_version=NEW.version AND w.state IN ('RUNNING','SETTLED') AND w.kind='agent.compute')
    THEN RAISE EXCEPTION 'agent_plan_compute_not_begun'; END IF;
  ELSE RAISE EXCEPTION 'agent_plan_join_has_no_external_start'; END IF;
  IF NOT os_agent_plan_ready(NEW.id) THEN RAISE EXCEPTION 'agent_plan_dependencies_pending'; END IF;
 ELSIF NEW.state='ACCEPTED' AND (OLD.state='STARTED' OR OLD.state='UNSTARTED' AND n->>'kind'='join') THEN
  IF NOT os_agent_plan_ready(NEW.id) THEN RAISE EXCEPTION 'agent_plan_dependencies_pending'; END IF;
  SELECT * INTO outcome FROM os_agent_payload_writes WHERE id=NEW.outcome_write_id;
  IF NOT COALESCE(outcome.root_id=h.root_id AND outcome.task_id=h.task_id AND outcome.control_epoch=h.control_epoch
   AND outcome.schema_ref='AgentPlanNodeOutcome' AND outcome.schema_version=1 AND outcome.expires_at>clock_timestamp()
   AND EXISTS(SELECT 1 FROM os_agent_private_payloads p JOIN os_work_attempts w ON w.id=outcome.attempt_id
    WHERE p.write_id=outcome.id AND w.state='SETTLED'),false) THEN RAISE EXCEPTION 'agent_plan_outcome_binding'; END IF;
  IF n->>'kind'='tool' AND (NOT bound OR EXISTS(
   SELECT 1 FROM os_agent_plan_step_bindings b LEFT JOIN os_agent_tool_calls c ON c.operation_id=b.tool_operation_id
   LEFT JOIN os_agent_tool_acceptances accepted ON accepted.call_id=c.id
   WHERE b.node_id=NEW.id AND (c.id IS NULL OR accepted.id IS NULL))) THEN RAISE EXCEPTION 'agent_plan_read_unsettled'; END IF;
  IF n->>'kind'='compute' AND NOT EXISTS(SELECT 1 FROM os_agent_plan_step_bindings b JOIN os_work_attempts w ON w.id=b.attempt_id
   WHERE b.node_id=NEW.id AND b.node_version=NEW.version AND b.family='compute' AND w.state='SETTLED')
   THEN RAISE EXCEPTION 'agent_plan_compute_unsettled'; END IF;
 ELSE RAISE EXCEPTION 'agent_plan_node_transition'; END IF;
 RETURN NEW;
END $$;
"""


def upgrade():
    op.execute(HEAD)
    op.execute(NODE)


def downgrade():
    raise RuntimeError('Extrema/ratio comparison requires protected forward recovery')
