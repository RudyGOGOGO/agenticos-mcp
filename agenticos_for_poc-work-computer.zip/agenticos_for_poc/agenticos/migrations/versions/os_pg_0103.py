"""Draft exact owner-turn remember through canonical source/revision bindings.

No inference/embedding job or broad learning grant. Existing source, currentness,
forgetting and original task/accounting checks remain. Runtime acceptance pending.
"""
from alembic import op

revision='os_pg_0103'
down_revision='os_pg_0102'
branch_labels=None
depends_on=None

SQL=r"""ALTER TABLE personal_learning_sources ADD COLUMN authorization_basis varchar(32);
ALTER TABLE personal_learning_sources ADD CONSTRAINT ck_learning_source_authorization_basis CHECK (
 authorization_basis IS NULL OR (authorization_basis='owner-directed-turn/1' AND kind='accepted-user-turn/1'));
ALTER TABLE personal_learning_source_origins ADD COLUMN authorization_basis varchar(32);
ALTER TABLE personal_learning_source_origins DROP CONSTRAINT uq_learning_source_selected_input;
CREATE UNIQUE INDEX uq_learning_source_selected_input ON personal_learning_source_origins
 (installation_id,application_id,tenant_id,subject_id,input_id,authorization_basis)
 NULLS NOT DISTINCT WHERE input_id IS NOT NULL;
ALTER TABLE personal_learning_source_origins ADD CONSTRAINT ck_learning_source_origin_authorization CHECK (
 authorization_basis IS NULL OR (authorization_basis='owner-directed-turn/1' AND input_id IS NOT NULL AND result_id IS NULL));
ALTER TABLE classified_knowledge_bindings ADD COLUMN directed_source_id uuid;
ALTER TABLE classified_knowledge_bindings ADD CONSTRAINT fk_personal_learning_sources_directed_source_id
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,directed_source_id)
 REFERENCES personal_learning_sources(installation_id,application_id,tenant_id,subject_id,id);

CREATE OR REPLACE FUNCTION os_assert_directed_memory_source(sid uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE s personal_learning_sources%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF s.id IS NULL OR s.authorization_basis IS DISTINCT FROM 'owner-directed-turn/1'
  OR s.kind<>'accepted-user-turn/1'
  OR NOT EXISTS(SELECT 1 FROM personal_learning_source_intents i WHERE i.source_id=s.id AND i.state='CANCELLED')
  OR NOT EXISTS(SELECT 1 FROM classified_knowledge_bindings b
   JOIN personal_knowledge_operations o ON o.id=b.operation_id
   JOIN personal_knowledge_revisions r ON r.id=b.revision_id
   WHERE b.directed_source_id=s.id AND o.kind='SAVE' AND r.operation_id=o.id
    AND o.command_id=s.command_id AND o.session_id=s.session_id AND o.created_at>=s.created_at
    AND ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
     IS NOT DISTINCT FROM ROW(s.installation_id,s.application_id,s.tenant_id,s.subject_id)
    AND (s.state='FORGOTTEN' OR (r.envelope IS NOT NULL AND o.request_mac IS NOT NULL)))
  THEN RAISE EXCEPTION 'directed_memory_exact_owner_entry'; END IF;
END $$;
CREATE OR REPLACE FUNCTION os_guard_directed_memory_binding() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_sources%ROWTYPE; o personal_knowledge_operations%ROWTYPE;
 r personal_knowledge_revisions%ROWTYPE;
BEGIN
 IF NEW.directed_source_id IS NULL THEN RETURN NULL; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO s FROM personal_learning_sources WHERE id=NEW.directed_source_id;
 SELECT * INTO o FROM personal_knowledge_operations WHERE id=NEW.operation_id;
 SELECT * INTO r FROM personal_knowledge_revisions WHERE id=NEW.revision_id;
 IF s.id IS NULL OR o.id IS NULL OR r.id IS NULL OR s.kind<>'accepted-user-turn/1'
  OR s.authorization_basis IS DISTINCT FROM 'owner-directed-turn/1'
  OR o.command_id<>s.command_id OR o.session_id<>s.session_id
  OR s.state<>'AVAILABLE' OR s.envelope IS NULL OR s.expires_at<=clock_timestamp()
  OR r.entry_id<>NEW.entry_id OR r.operation_id<>o.id OR o.entry_id<>NEW.entry_id
  OR o.kind<>'SAVE' OR o.request_mac IS NULL OR r.envelope IS NULL OR o.created_at<>NEW.created_at
  OR ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
   IS DISTINCT FROM ROW(s.installation_id,s.application_id,s.tenant_id,s.subject_id)
  OR NOT COALESCE(os_selected_learning_source_current(s.id),false)
  OR EXISTS(SELECT 1 FROM personal_knowledge_publications WHERE revision_id=r.id)
  THEN RAISE EXCEPTION 'directed_memory_binding'; END IF;
 PERFORM os_assert_learning_source_owner(s.id,o.session_id);
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER directed_memory_binding_commit AFTER INSERT ON classified_knowledge_bindings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_directed_memory_binding();

CREATE OR REPLACE FUNCTION os_assert_learning_source(sid uuid)
 RETURNS void
 LANGUAGE plpgsql
AS $$
DECLARE s personal_learning_sources%ROWTYPE; j personal_learning_source_intents%ROWTYPE;
 f personal_learning_source_forgets%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF os_restoration_erased('personal_learning_sources',to_jsonb(s)) THEN
  RETURN;
 END IF;

 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
 SELECT * INTO j FROM personal_learning_source_intents WHERE source_id=sid;
 SELECT * INTO f FROM personal_learning_source_forgets WHERE source_id=sid;
 IF s.id IS NULL OR settings.id IS NULL OR j.id IS NULL OR j.learning_epoch<>s.learning_epoch
  OR j.created_at<>s.created_at OR j.extractor_ref NOT IN ('synthetic-staging/1','classified-staging/2')
  OR s.receipt IS DISTINCT FROM jsonb_build_object('commandId',s.command_id,'sourceId',s.id,
   'revision',1,'learningEpoch',s.learning_epoch,'extractionState',CASE WHEN s.authorization_basis='owner-directed-turn/1' THEN 'DIRECTED_ONLY' ELSE 'PENDING_DISPATCH' END)
  THEN RAISE EXCEPTION 'learning_source_atomic_intent'; END IF;
 IF s.authorization_basis='owner-directed-turn/1' THEN PERFORM os_assert_directed_memory_source(sid); END IF;
 IF s.state='AVAILABLE' THEN
  IF f.id IS NOT NULL OR s.envelope IS NULL THEN RAISE EXCEPTION 'learning_source_live'; END IF;
 ELSE
  IF f.id IS NULL OR j.state<>'CANCELLED' OR f.learning_epoch<>s.learning_epoch OR f.created_at<>s.updated_at
   OR f.receipt IS DISTINCT FROM jsonb_build_object('commandId',f.command_id,'operationId',f.id,
    'sourceId',s.id,'revision',2,'state','FORGOTTEN')
   OR (f.completed_at IS NULL AND s.envelope IS NULL)
   OR (f.completed_at IS NOT NULL AND (s.envelope IS NOT NULL OR s.request_mac IS NOT NULL OR s.mac_key_id IS NOT NULL))
   THEN RAISE EXCEPTION 'learning_source_forget_atomic'; END IF;
 END IF;
END $$;

CREATE OR REPLACE FUNCTION os_guard_learning_source_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $$
DECLARE sid uuid; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_TABLE_NAME='personal_learning_sources' THEN
  sid=NEW.id;
  IF TG_OP='INSERT' THEN
   SELECT * INTO settings FROM personal_learning_settings WHERE id=NEW.settings_id;
   IF (NEW.authorization_basis IS DISTINCT FROM 'owner-directed-turn/1' AND settings.choice->(CASE WHEN NEW.kind='usage-event/2' THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb)
    OR settings.learning_epoch<>NEW.learning_epoch OR NEW.expires_at<=clock_timestamp()
    OR (SELECT count(*) FROM personal_learning_sources WHERE settings_id=NEW.settings_id AND state='AVAILABLE')>64
    THEN RAISE EXCEPTION 'learning_source_consent_capacity'; END IF;
   IF NEW.kind<>'usage-event/2' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id); END IF;
   IF NEW.authorization_basis='owner-directed-turn/1' AND NOT EXISTS(SELECT 1 FROM personal_learning_source_origins o
    JOIN os_source_inputs i ON i.id=o.input_id JOIN os_artifacts a ON a.id=o.artifact_id
    WHERE o.source_id=sid AND i.expires_at>clock_timestamp() AND a.expires_at>clock_timestamp())
    THEN RAISE EXCEPTION 'directed_memory_source_expired_before_save'; END IF;
  END IF;
 ELSE
  sid=NEW.source_id;
  IF TG_TABLE_NAME='personal_learning_source_forgets' THEN
   IF TG_OP='INSERT' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
   ELSE PERFORM os_assert_learning_source_owner(sid,NEW.cleanup_session_id); END IF;
  END IF;
 END IF;
 PERFORM os_assert_learning_source(sid);
 IF TG_TABLE_NAME='personal_learning_sources' AND TG_OP='INSERT' AND NOT COALESCE(os_selected_learning_source_current(sid),false)
  THEN RAISE EXCEPTION 'selected_learning_source_binding'; END IF;
 RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION os_guard_learning_source_intent()
 RETURNS trigger
 LANGUAGE plpgsql
AS $$
DECLARE s personal_learning_sources%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_source_intent_retained'; END IF;
 IF TG_OP='INSERT' THEN
  SELECT * INTO s FROM personal_learning_sources WHERE id=NEW.source_id;
  IF NEW.state IS DISTINCT FROM (CASE WHEN s.authorization_basis='owner-directed-turn/1' THEN 'CANCELLED' ELSE 'PENDING_DISPATCH' END)
   THEN RAISE EXCEPTION 'learning_source_intent_initial'; END IF;
 ELSE
  SELECT * INTO s FROM personal_learning_sources WHERE id=OLD.source_id;
  SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
  IF OLD.state<>'PENDING_DISPATCH' OR NEW.state<>'CANCELLED'
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state')
   OR (s.state='AVAILABLE' AND settings.choice->(CASE WHEN s.kind='usage-event/2' THEN 'learnUsage' ELSE 'learnConversation' END)='true'::jsonb
       AND settings.learning_epoch=s.learning_epoch AND s.expires_at>clock_timestamp())
   THEN RAISE EXCEPTION 'learning_source_intent_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_conversation_learning_source_current(sid uuid)
 RETURNS boolean
 LANGUAGE plpgsql
AS $$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
 t os_tasks%ROWTYPE; segment os_segments%ROWTYPE; a os_artifacts%ROWTYPE; owner os_subjects%ROWTYPE;
 input os_source_inputs%ROWTYPE; result os_accepted_results%ROWTYPE; directed boolean;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF s.id IS NULL THEN RETURN false; END IF;
 directed=COALESCE(s.authorization_basis='owner-directed-turn/1',false);
 IF s.kind='owner-statement/1' THEN RETURN NOT EXISTS(SELECT 1 FROM personal_learning_source_origins WHERE source_id=sid); END IF;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO t FROM os_tasks WHERE id=o.task_id;
 SELECT * INTO segment FROM os_segments WHERE id=o.segment_id;
 SELECT * INTO a FROM os_artifacts WHERE id=o.artifact_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF o.id IS NULL OR o.authorization_basis IS DISTINCT FROM s.authorization_basis
  OR t.state IS DISTINCT FROM 'COMPLETED' OR t.version<>o.task_version
  OR segment.task_id<>t.id OR segment.state IS DISTINCT FROM 'FINISHED'
  OR NOT EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=t.id AND state='ACTIVE')
  OR owner.id IS NULL OR NOT owner.active OR (NOT directed AND owner.host_policy_generation<>o.policy_generation)
  OR a.id IS NULL OR (NOT directed AND a.expires_at<=clock_timestamp()) OR a.ciphertext_digest<>o.ciphertext_digest
  OR (NOT directed AND s.expires_at>a.expires_at) OR o.created_at<>s.created_at
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'name'='os.grounded/1')
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'type'='RUN_FINISHED') THEN RETURN false; END IF;
 IF o.input_id IS NOT NULL THEN
  SELECT * INTO input FROM os_source_inputs WHERE id=o.input_id;
  RETURN s.kind='accepted-user-turn/1' AND input.admitted_task_id=t.id AND input.artifact_id=a.id
   AND (directed OR (input.expires_at>clock_timestamp() AND s.expires_at<=input.expires_at))
   AND a.purpose='intent' AND a.classification='owner-private' AND o.occurred_at=input.created_at
   AND EXISTS(SELECT 1 FROM os_admissions WHERE task_id=t.id AND source_input_id=input.id AND segment_id=segment.id);
 ELSE
  SELECT * INTO result FROM os_accepted_results WHERE id=o.result_id;
  RETURN s.kind='accepted-outcome/1' AND result.task_id=t.id AND result.segment_id=segment.id
   AND result.artifact_id=a.id AND result.ciphertext_digest=a.ciphertext_digest AND result.contract_ref='ReadStageResult'
   AND a.purpose='artifact' AND a.classification='protected' AND o.occurred_at=result.created_at
   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=result.attempt_id AND state='SETTLED');
 END IF;
END $$;

CREATE OR REPLACE FUNCTION os_revision_sources_current(rid uuid)
 RETURNS boolean
 LANGUAGE sql
AS $$
 SELECT NOT EXISTS(SELECT 1 FROM personal_knowledge_publications p JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
 JOIN personal_learning_sources s ON s.id=e.source_id WHERE p.revision_id=rid AND
 (s.state<>'AVAILABLE' OR s.revision<>e.source_revision OR s.expires_at<=clock_timestamp()
  OR NOT COALESCE(os_selected_learning_source_current(s.id),false)))
 AND NOT EXISTS(SELECT 1 FROM classified_knowledge_bindings b JOIN personal_learning_sources s ON s.id=b.directed_source_id
  WHERE b.revision_id=rid AND (s.state<>'AVAILABLE' OR s.envelope IS NULL OR s.expires_at<=clock_timestamp()
   OR NOT COALESCE(os_selected_learning_source_current(s.id),false)))
$$;

CREATE OR REPLACE FUNCTION os_revision_source_forgotten(rid uuid)
 RETURNS boolean
 LANGUAGE sql
AS $$
 SELECT EXISTS(SELECT 1 FROM personal_knowledge_publications p JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
 JOIN personal_learning_sources s ON s.id=e.source_id WHERE p.revision_id=rid AND s.state='FORGOTTEN')
 OR EXISTS(SELECT 1 FROM classified_knowledge_bindings b JOIN personal_learning_sources s ON s.id=b.directed_source_id
  WHERE b.revision_id=rid AND s.state='FORGOTTEN')
$$;

CREATE OR REPLACE FUNCTION os_assert_memory_forget_batch(bid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $$
DECLARE b memory_forget_batches%ROWTYPE; s personal_learning_settings%ROWTYPE; watermark memory_recovery_owners%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
 entry_refs jsonb; source_refs jsonb; context_refs jsonb; ne bigint; ns bigint; nc bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM memory_forget_batches WHERE id=bid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO watermark FROM memory_recovery_owners WHERE settings_id=b.settings_id;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',entry_id,'revision',expected_version) ORDER BY entry_id),'[]'::jsonb),count(*)
  INTO entry_refs,ne FROM memory_forget_entries WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',source_id,'revision',expected_version) ORDER BY source_id),'[]'::jsonb),count(*)
  INTO source_refs,ns FROM memory_forget_sources WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',context_id,'revision',expected_version) ORDER BY context_id),'[]'::jsonb),count(*)
  INTO context_refs,nc FROM memory_forget_contexts WHERE batch_id=bid;
 IF b.id IS NULL OR s.id IS NULL OR watermark.settings_id IS NULL OR watermark.journal_id<>b.journal_id
  OR watermark.sequence<b.journal_sequence OR watermark.owner_epoch<b.owner_epoch OR ne>64 OR ns>64 OR nc>64
  OR (b.kind='entry' AND (ne<>1 OR ns>1 OR nc<>0
   OR EXISTS(SELECT 1 FROM memory_forget_sources m JOIN personal_learning_sources d ON d.id=m.source_id
    WHERE m.batch_id=bid AND (d.authorization_basis IS DISTINCT FROM 'owner-directed-turn/1'
     OR NOT EXISTS(SELECT 1 FROM classified_knowledge_bindings k JOIN memory_forget_entries e ON e.entry_id=k.entry_id
      WHERE e.batch_id=bid AND k.directed_source_id=d.id)))
   OR EXISTS(SELECT 1 FROM classified_knowledge_bindings k JOIN personal_learning_sources d ON d.id=k.directed_source_id
    JOIN memory_forget_entries e ON e.entry_id=k.entry_id WHERE e.batch_id=bid
     AND d.authorization_basis='owner-directed-turn/1' AND d.state='AVAILABLE'))) OR (b.kind='source' AND (ne<>0 OR ns<>1 OR nc<>0))
  OR b.request IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'kind',b.kind,'settingsId',s.id,
   'expectedRevision',b.expected_version,'learningEpoch',b.prior_learning_epoch,'recallEpoch',b.prior_recall_epoch,
   'contextRevision',b.prior_context_revision,'entryRefs',entry_refs,'sourceRefs',source_refs,'contextRefs',context_refs)
  OR b.receipt IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'operationId',b.id,'kind',b.kind,
   'settings',jsonb_build_object('revision',b.accepted_version,'learningEpoch',b.learning_epoch,'recallEpoch',b.recall_epoch,
    'contextRevision',b.context_revision,'indexGeneration',b.index_generation,'choice',b.receipt->'settings'->'choice'),
   'forgotten',jsonb_build_object('entries',ne,'sources',ns,'contexts',nc))
  THEN RAISE EXCEPTION 'memory_forget_exact_receipt';END IF;
 IF EXISTS(SELECT 1 FROM memory_forget_entries m JOIN personal_knowledge_entries e ON e.id=m.entry_id
  JOIN personal_knowledge_operations operation ON operation.id=m.operation_id WHERE m.batch_id=bid
   AND (e.settings_id<>b.settings_id OR e.state<>'FORGOTTEN' OR e.version<>m.accepted_version
    OR operation.forget_batch_id IS DISTINCT FROM bid OR operation.kind<>'FORGET' OR operation.entry_id<>m.entry_id
    OR operation.expected_version<>m.expected_version OR operation.accepted_version<>m.accepted_version
    OR operation.context_revision<>b.context_revision OR operation.created_at<>b.created_at
    OR operation.session_id<>b.session_id))
  OR EXISTS(SELECT 1 FROM personal_knowledge_operations operation WHERE operation.forget_batch_id=bid AND NOT EXISTS(
   SELECT 1 FROM memory_forget_entries m WHERE m.batch_id=bid AND m.operation_id=operation.id AND m.entry_id=operation.entry_id))
  OR EXISTS(SELECT 1 FROM memory_forget_sources m JOIN personal_learning_sources source ON source.id=m.source_id
   JOIN personal_learning_source_forgets f ON f.id=m.forget_id WHERE m.batch_id=bid
    AND (source.settings_id<>b.settings_id OR source.state<>'FORGOTTEN' OR source.revision<>m.accepted_version
     OR f.source_id<>m.source_id OR f.session_id<>b.session_id OR f.created_at<>b.created_at))
  OR EXISTS(SELECT 1 FROM memory_forget_contexts m JOIN owner_memory_contexts c ON c.id=m.context_id WHERE m.batch_id=bid
   AND (c.settings_id<>b.settings_id OR c.state<>'FORGOTTEN' OR c.version<>m.accepted_version
    OR c.context_revision<>b.context_revision OR c.updated_at<>b.created_at OR c.envelope IS NOT NULL))
  THEN RAISE EXCEPTION 'memory_forget_exact_members';END IF;
 IF live THEN
  IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation,s.updated_at)
   IS DISTINCT FROM ROW(b.accepted_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation,b.created_at)
   AND b.kind<>'source' THEN RAISE EXCEPTION 'memory_forget_current_settings';END IF;
  IF b.receipt->'settings' IS DISTINCT FROM os_learning_settings_payload(s)
   OR watermark.sequence<>b.journal_sequence OR watermark.owner_epoch<>b.owner_epoch OR watermark.updated_at<>b.created_at
   THEN RAISE EXCEPTION 'memory_forget_current_watermark';END IF;
  IF b.kind='all' AND (EXISTS(SELECT 1 FROM personal_knowledge_entries WHERE settings_id=b.settings_id AND state<>'FORGOTTEN')
   OR EXISTS(SELECT 1 FROM personal_learning_sources WHERE settings_id=b.settings_id AND state='AVAILABLE')
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state<>'FORGOTTEN'))
   THEN RAISE EXCEPTION 'memory_forget_all_members';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_current_owner';END IF;
 END IF;
 IF b.completed_at IS NOT NULL THEN
  IF EXISTS(SELECT 1 FROM personal_forget_journal WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_source_forgets WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state='FORGOTTEN' AND envelope IS NOT NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_context_commands command JOIN owner_memory_contexts context ON context.id=command.context_id
    WHERE context.settings_id=b.settings_id AND context.state='FORGOTTEN' AND command.request_mac IS NOT NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_jobs WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND state IN ('QUEUED','RUNNING'))
   THEN RAISE EXCEPTION 'memory_forget_cleanup_incomplete';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.cleanup_session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR NOT app.active OR app.generation<>session.application_generation
   OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_cleanup_owner';END IF;
 END IF;
END $$;
"""

def upgrade():
    op.execute(SQL)

def downgrade():
    op.execute(r"""DO $$ BEGIN IF EXISTS(SELECT 1 FROM personal_learning_sources WHERE authorization_basis IS NOT NULL)
 OR EXISTS(SELECT 1 FROM classified_knowledge_bindings WHERE directed_source_id IS NOT NULL)
 THEN RAISE EXCEPTION 'directed_memory_downgrade_refused'; END IF; END $$;
DROP TRIGGER directed_memory_binding_commit ON classified_knowledge_bindings;
DROP FUNCTION os_guard_directed_memory_binding();

CREATE OR REPLACE FUNCTION os_assert_learning_source(sid uuid)
 RETURNS void
 LANGUAGE plpgsql
AS $$
DECLARE s personal_learning_sources%ROWTYPE; j personal_learning_source_intents%ROWTYPE;
 f personal_learning_source_forgets%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF os_restoration_erased('personal_learning_sources',to_jsonb(s)) THEN
  RETURN;
 END IF;

 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
 SELECT * INTO j FROM personal_learning_source_intents WHERE source_id=sid;
 SELECT * INTO f FROM personal_learning_source_forgets WHERE source_id=sid;
 IF s.id IS NULL OR settings.id IS NULL OR j.id IS NULL OR j.learning_epoch<>s.learning_epoch
  OR j.created_at<>s.created_at OR j.extractor_ref NOT IN ('synthetic-staging/1','classified-staging/2')
  OR s.receipt IS DISTINCT FROM jsonb_build_object('commandId',s.command_id,'sourceId',s.id,
   'revision',1,'learningEpoch',s.learning_epoch,'extractionState','PENDING_DISPATCH')
  THEN RAISE EXCEPTION 'learning_source_atomic_intent'; END IF;
 IF s.state='AVAILABLE' THEN
  IF f.id IS NOT NULL OR s.envelope IS NULL THEN RAISE EXCEPTION 'learning_source_live'; END IF;
 ELSE
  IF f.id IS NULL OR j.state<>'CANCELLED' OR f.learning_epoch<>s.learning_epoch OR f.created_at<>s.updated_at
   OR f.receipt IS DISTINCT FROM jsonb_build_object('commandId',f.command_id,'operationId',f.id,
    'sourceId',s.id,'revision',2,'state','FORGOTTEN')
   OR (f.completed_at IS NULL AND s.envelope IS NULL)
   OR (f.completed_at IS NOT NULL AND (s.envelope IS NOT NULL OR s.request_mac IS NOT NULL OR s.mac_key_id IS NOT NULL))
   THEN RAISE EXCEPTION 'learning_source_forget_atomic'; END IF;
 END IF;
END $$;

CREATE OR REPLACE FUNCTION os_guard_learning_source_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $$
DECLARE sid uuid; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' AND os_restoration_change(TG_TABLE_NAME,to_jsonb(OLD),to_jsonb(NEW)) THEN RETURN NEW;END IF;

 IF TG_TABLE_NAME='personal_learning_sources' THEN
  sid=NEW.id;
  IF TG_OP='INSERT' THEN
   SELECT * INTO settings FROM personal_learning_settings WHERE id=NEW.settings_id;
   IF settings.choice->(CASE WHEN NEW.kind='usage-event/2' THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb
    OR settings.learning_epoch<>NEW.learning_epoch OR NEW.expires_at<=clock_timestamp()
    OR (SELECT count(*) FROM personal_learning_sources WHERE settings_id=NEW.settings_id AND state='AVAILABLE')>64
    THEN RAISE EXCEPTION 'learning_source_consent_capacity'; END IF;
   IF NEW.kind<>'usage-event/2' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id); END IF;
  END IF;
 ELSE
  sid=NEW.source_id;
  IF TG_TABLE_NAME='personal_learning_source_forgets' THEN
   IF TG_OP='INSERT' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
   ELSE PERFORM os_assert_learning_source_owner(sid,NEW.cleanup_session_id); END IF;
  END IF;
 END IF;
 PERFORM os_assert_learning_source(sid);
 IF TG_TABLE_NAME='personal_learning_sources' AND TG_OP='INSERT' AND NOT COALESCE(os_selected_learning_source_current(sid),false)
  THEN RAISE EXCEPTION 'selected_learning_source_binding'; END IF;
 RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION os_guard_learning_source_intent()
 RETURNS trigger
 LANGUAGE plpgsql
AS $$
DECLARE s personal_learning_sources%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_source_intent_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'PENDING_DISPATCH' THEN RAISE EXCEPTION 'learning_source_intent_initial'; END IF;
 ELSE
  SELECT * INTO s FROM personal_learning_sources WHERE id=OLD.source_id;
  SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
  IF OLD.state<>'PENDING_DISPATCH' OR NEW.state<>'CANCELLED'
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state')
   OR (s.state='AVAILABLE' AND settings.choice->(CASE WHEN s.kind='usage-event/2' THEN 'learnUsage' ELSE 'learnConversation' END)='true'::jsonb
       AND settings.learning_epoch=s.learning_epoch AND s.expires_at>clock_timestamp())
   THEN RAISE EXCEPTION 'learning_source_intent_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_revision_sources_current(rid uuid)
 RETURNS boolean
 LANGUAGE sql
AS $$
 SELECT NOT EXISTS(SELECT 1 FROM personal_knowledge_publications p JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
 JOIN personal_learning_sources s ON s.id=e.source_id WHERE p.revision_id=rid AND
 (s.state<>'AVAILABLE' OR s.revision<>e.source_revision OR s.expires_at<=clock_timestamp()
  OR NOT COALESCE(os_selected_learning_source_current(s.id),false)))
$$;

CREATE OR REPLACE FUNCTION os_revision_source_forgotten(rid uuid)
 RETURNS boolean
 LANGUAGE sql
AS $$
 SELECT EXISTS(SELECT 1 FROM personal_knowledge_publications p JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
 JOIN personal_learning_sources s ON s.id=e.source_id WHERE p.revision_id=rid AND s.state='FORGOTTEN')
$$;

CREATE OR REPLACE FUNCTION os_conversation_learning_source_current(sid uuid)
 RETURNS boolean
 LANGUAGE plpgsql
AS $$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
 t os_tasks%ROWTYPE; segment os_segments%ROWTYPE; a os_artifacts%ROWTYPE; owner os_subjects%ROWTYPE;
 input os_source_inputs%ROWTYPE; result os_accepted_results%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF s.id IS NULL THEN RETURN false; END IF;
 IF s.kind='owner-statement/1' THEN RETURN NOT EXISTS(SELECT 1 FROM personal_learning_source_origins WHERE source_id=sid); END IF;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO t FROM os_tasks WHERE id=o.task_id;
 SELECT * INTO segment FROM os_segments WHERE id=o.segment_id;
 SELECT * INTO a FROM os_artifacts WHERE id=o.artifact_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF o.id IS NULL OR t.state IS DISTINCT FROM 'COMPLETED' OR t.version<>o.task_version
  OR segment.task_id<>t.id OR segment.state IS DISTINCT FROM 'FINISHED'
  OR NOT EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=t.id AND state='ACTIVE')
  OR owner.id IS NULL OR NOT owner.active OR owner.host_policy_generation<>o.policy_generation
  OR a.id IS NULL OR a.expires_at<=clock_timestamp() OR a.ciphertext_digest<>o.ciphertext_digest
  OR s.expires_at>a.expires_at OR o.created_at<>s.created_at
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'name'='os.grounded/1')
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'type'='RUN_FINISHED') THEN RETURN false; END IF;
 IF o.input_id IS NOT NULL THEN
  SELECT * INTO input FROM os_source_inputs WHERE id=o.input_id;
  RETURN s.kind='accepted-user-turn/1' AND input.admitted_task_id=t.id AND input.artifact_id=a.id
   AND input.expires_at>clock_timestamp() AND s.expires_at<=input.expires_at
   AND a.purpose='intent' AND a.classification='owner-private' AND o.occurred_at=input.created_at
   AND EXISTS(SELECT 1 FROM os_admissions WHERE task_id=t.id AND source_input_id=input.id AND segment_id=segment.id);
 ELSE
  SELECT * INTO result FROM os_accepted_results WHERE id=o.result_id;
  RETURN s.kind='accepted-outcome/1' AND result.task_id=t.id AND result.segment_id=segment.id
   AND result.artifact_id=a.id AND result.ciphertext_digest=a.ciphertext_digest AND result.contract_ref='ReadStageResult'
   AND a.purpose='artifact' AND a.classification='protected' AND o.occurred_at=result.created_at
   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=result.attempt_id AND state='SETTLED');
 END IF;
END $$;

CREATE OR REPLACE FUNCTION os_assert_memory_forget_batch(bid uuid, live boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $$
DECLARE b memory_forget_batches%ROWTYPE; s personal_learning_settings%ROWTYPE; watermark memory_recovery_owners%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
 entry_refs jsonb; source_refs jsonb; context_refs jsonb; ne bigint; ns bigint; nc bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM memory_forget_batches WHERE id=bid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO watermark FROM memory_recovery_owners WHERE settings_id=b.settings_id;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',entry_id,'revision',expected_version) ORDER BY entry_id),'[]'::jsonb),count(*)
  INTO entry_refs,ne FROM memory_forget_entries WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',source_id,'revision',expected_version) ORDER BY source_id),'[]'::jsonb),count(*)
  INTO source_refs,ns FROM memory_forget_sources WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',context_id,'revision',expected_version) ORDER BY context_id),'[]'::jsonb),count(*)
  INTO context_refs,nc FROM memory_forget_contexts WHERE batch_id=bid;
 IF b.id IS NULL OR s.id IS NULL OR watermark.settings_id IS NULL OR watermark.journal_id<>b.journal_id
  OR watermark.sequence<b.journal_sequence OR watermark.owner_epoch<b.owner_epoch OR ne>64 OR ns>64 OR nc>64
  OR (b.kind='entry' AND (ne<>1 OR ns<>0 OR nc<>0)) OR (b.kind='source' AND (ne<>0 OR ns<>1 OR nc<>0))
  OR b.request IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'kind',b.kind,'settingsId',s.id,
   'expectedRevision',b.expected_version,'learningEpoch',b.prior_learning_epoch,'recallEpoch',b.prior_recall_epoch,
   'contextRevision',b.prior_context_revision,'entryRefs',entry_refs,'sourceRefs',source_refs,'contextRefs',context_refs)
  OR b.receipt IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'operationId',b.id,'kind',b.kind,
   'settings',jsonb_build_object('revision',b.accepted_version,'learningEpoch',b.learning_epoch,'recallEpoch',b.recall_epoch,
    'contextRevision',b.context_revision,'indexGeneration',b.index_generation,'choice',b.receipt->'settings'->'choice'),
   'forgotten',jsonb_build_object('entries',ne,'sources',ns,'contexts',nc))
  THEN RAISE EXCEPTION 'memory_forget_exact_receipt';END IF;
 IF EXISTS(SELECT 1 FROM memory_forget_entries m JOIN personal_knowledge_entries e ON e.id=m.entry_id
  JOIN personal_knowledge_operations operation ON operation.id=m.operation_id WHERE m.batch_id=bid
   AND (e.settings_id<>b.settings_id OR e.state<>'FORGOTTEN' OR e.version<>m.accepted_version
    OR operation.forget_batch_id IS DISTINCT FROM bid OR operation.kind<>'FORGET' OR operation.entry_id<>m.entry_id
    OR operation.expected_version<>m.expected_version OR operation.accepted_version<>m.accepted_version
    OR operation.context_revision<>b.context_revision OR operation.created_at<>b.created_at
    OR operation.session_id<>b.session_id))
  OR EXISTS(SELECT 1 FROM personal_knowledge_operations operation WHERE operation.forget_batch_id=bid AND NOT EXISTS(
   SELECT 1 FROM memory_forget_entries m WHERE m.batch_id=bid AND m.operation_id=operation.id AND m.entry_id=operation.entry_id))
  OR EXISTS(SELECT 1 FROM memory_forget_sources m JOIN personal_learning_sources source ON source.id=m.source_id
   JOIN personal_learning_source_forgets f ON f.id=m.forget_id WHERE m.batch_id=bid
    AND (source.settings_id<>b.settings_id OR source.state<>'FORGOTTEN' OR source.revision<>m.accepted_version
     OR f.source_id<>m.source_id OR f.session_id<>b.session_id OR f.created_at<>b.created_at))
  OR EXISTS(SELECT 1 FROM memory_forget_contexts m JOIN owner_memory_contexts c ON c.id=m.context_id WHERE m.batch_id=bid
   AND (c.settings_id<>b.settings_id OR c.state<>'FORGOTTEN' OR c.version<>m.accepted_version
    OR c.context_revision<>b.context_revision OR c.updated_at<>b.created_at OR c.envelope IS NOT NULL))
  THEN RAISE EXCEPTION 'memory_forget_exact_members';END IF;
 IF live THEN
  IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation,s.updated_at)
   IS DISTINCT FROM ROW(b.accepted_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation,b.created_at)
   AND b.kind<>'source' THEN RAISE EXCEPTION 'memory_forget_current_settings';END IF;
  IF b.receipt->'settings' IS DISTINCT FROM os_learning_settings_payload(s)
   OR watermark.sequence<>b.journal_sequence OR watermark.owner_epoch<>b.owner_epoch OR watermark.updated_at<>b.created_at
   THEN RAISE EXCEPTION 'memory_forget_current_watermark';END IF;
  IF b.kind='all' AND (EXISTS(SELECT 1 FROM personal_knowledge_entries WHERE settings_id=b.settings_id AND state<>'FORGOTTEN')
   OR EXISTS(SELECT 1 FROM personal_learning_sources WHERE settings_id=b.settings_id AND state='AVAILABLE')
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state<>'FORGOTTEN'))
   THEN RAISE EXCEPTION 'memory_forget_all_members';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_current_owner';END IF;
 END IF;
 IF b.completed_at IS NOT NULL THEN
  IF EXISTS(SELECT 1 FROM personal_forget_journal WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_source_forgets WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state='FORGOTTEN' AND envelope IS NOT NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_context_commands command JOIN owner_memory_contexts context ON context.id=command.context_id
    WHERE context.settings_id=b.settings_id AND context.state='FORGOTTEN' AND command.request_mac IS NOT NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_jobs WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND state IN ('QUEUED','RUNNING'))
   THEN RAISE EXCEPTION 'memory_forget_cleanup_incomplete';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.cleanup_session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR NOT app.active OR app.generation<>session.application_generation
   OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_cleanup_owner';END IF;
 END IF;
END $$;

DROP FUNCTION os_assert_directed_memory_source(uuid);
DROP INDEX uq_learning_source_selected_input;
ALTER TABLE personal_learning_source_origins ADD CONSTRAINT uq_learning_source_selected_input
 UNIQUE(installation_id,application_id,tenant_id,subject_id,input_id);
ALTER TABLE personal_learning_source_origins DROP CONSTRAINT ck_learning_source_origin_authorization;
ALTER TABLE personal_learning_source_origins DROP COLUMN authorization_basis;
ALTER TABLE classified_knowledge_bindings DROP CONSTRAINT fk_personal_learning_sources_directed_source_id;
ALTER TABLE classified_knowledge_bindings DROP COLUMN directed_source_id;
ALTER TABLE personal_learning_sources DROP CONSTRAINT ck_learning_source_authorization_basis;
ALTER TABLE personal_learning_sources DROP COLUMN authorization_basis;
""")
