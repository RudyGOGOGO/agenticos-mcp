"""Bind OIDC serialized review to its immutable original conflict policy.

All original owner, exact command, current identity and finite phase checks are
preserved. The additional harness requires the actual original-root policy;
it cannot use an interactive ceremony to grant future background authority.
"""
from alembic import op

revision='os_pg_0094'
down_revision='os_pg_0093'
branch_labels=None
depends_on=None

OWNER=r"""
CREATE OR REPLACE FUNCTION os_oidc_assert_owner(v os_agent_reviews,s os_interactive_sessions,b jsonb,target_run text,phase text DEFAULT 'review')
 RETURNS void LANGUAGE plpgsql AS $$
DECLARE p os_oidc_assurance_profiles%ROWTYPE; m os_oidc_subject_mappings%ROWTYPE; a os_applications%ROWTYPE;
 registration os_registrations%ROWTYPE; e os_embed_registrations%ROWTYPE; u os_subjects%ROWTYPE; client_profile jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_applications WHERE installation_id=v.installation_id AND id=v.application_id;
 SELECT * INTO registration FROM os_registrations WHERE installation_id=v.installation_id AND application_id=v.application_id AND revision=a.revision;
 SELECT * INTO e FROM os_embed_registrations WHERE installation_id=v.installation_id AND application_id=v.application_id AND id=s.embed_ref;
 SELECT * INTO u FROM os_subjects WHERE installation_id=v.installation_id AND application_id=v.application_id AND tenant_id=v.tenant_id AND subject_id=v.subject_id;
 SELECT x INTO client_profile FROM jsonb_array_elements(registration.payload->'clientProfiles') x WHERE x->>'id'=e.payload->>'clientProfile';
 SELECT * INTO p FROM os_oidc_assurance_profiles WHERE installation_id=v.installation_id AND application_id=v.application_id
  AND profile_ref=b->'provider'->>'ref' ORDER BY revision DESC LIMIT 1;
 SELECT * INTO m FROM os_oidc_subject_mappings WHERE installation_id=v.installation_id AND application_id=v.application_id
  AND tenant_id=v.tenant_id AND subject_id=v.subject_id AND provider_ref=p.profile_ref ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE((v.payload->'context'->'harness'->>'ref'='agent-sdk-reviewed-change/1'
  OR (v.payload->'context'->'harness'->>'ref'='agent-sdk-serialized-reviewed-change/1'
   AND EXISTS(SELECT 1 FROM os_agent_write_conflict_roots selected
    JOIN os_agent_write_conflict_policies policy ON policy.installation_id=selected.installation_id
     AND policy.application_id=selected.application_id AND policy.policy_digest=selected.policy_digest
    JOIN os_budget_roots root ON root.id=selected.root_id
    JOIN os_admissions admission ON admission.id=root.admission_id
    WHERE selected.root_id=v.root_id AND selected.installation_id=v.installation_id AND selected.application_id=v.application_id
     AND selected.tenant_id=v.tenant_id AND selected.subject_id=v.subject_id
     AND root.root_task_id=v.task_id AND admission.context=v.payload->'context'
     AND policy.payload->'harness'=admission.context->'harness'
     AND policy.registration_revision=admission.registration_revision
     AND policy.digest=os_agent_profile_digest('policy',policy.payload))))
  AND (b->>'expiresAt')::timestamptz>clock_timestamp()
  AND (b->>'expiresAt')::timestamptz<=v.expires_at AND (b->>'expiresAt')::timestamptz<=s.expires_at
  AND b->>'assuranceProfile'='oidc-step-up-assurance/1' AND b->>'requiredAssurance'='oidc-step-up/1'
  AND b->>'assuranceProviderRef'=p.profile_ref AND b->'provider'=jsonb_build_object('ref',p.profile_ref,'revision',p.revision,'digest',p.digest)
  AND b->'ownerMapping'=jsonb_build_object('ref',m.id,'revision',m.revision,'digest',m.digest)
  AND p.run_id=target_run AND m.run_id=target_run AND p.payload->'active'='true'::jsonb AND m.payload->'active'='true'::jsonb
  AND p.digest=os_agent_profile_digest('manifest',p.payload) AND m.digest=os_agent_profile_digest('manifest',m.payload)
  AND m.payload->>'issuer'=p.payload->'client'->>'issuer' AND client_profile=p.payload->'clientProfile'
  AND registration.digest=os_agent_profile_digest('manifest',registration.payload) AND registration.generation=a.generation
  AND e.application_generation=a.generation AND e.payload->'active'='true'::jsonb
  AND b->'subject'=jsonb_build_object('installationId',v.installation_id,'applicationId',v.application_id,'tenantId',v.tenant_id,'subjectId',v.subject_id)
  AND b->>'sessionId'=s.id::text AND (b->>'sessionGeneration')::bigint=s.session_generation
  AND b->>'hostSessionRef'=s.host_session_ref AND (b->>'policyGeneration')::bigint=u.host_policy_generation
  AND EXISTS(SELECT 1 FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=v.task_id
   AND ((phase='review' AND t.state='WAITING_APPROVAL') OR (phase='effect' AND t.state='RUNNING'))
   AND r.state='ACTIVE' AND r.deadline>clock_timestamp() AND (b->>'expiresAt')::timestamptz<=r.deadline),false)
 THEN RAISE EXCEPTION 'oidc_current_owner_binding'; END IF;
END $$;
"""


def upgrade():
    op.execute(OWNER)


def downgrade():
    raise RuntimeError('Serialized OIDC authority requires protected forward recovery')
