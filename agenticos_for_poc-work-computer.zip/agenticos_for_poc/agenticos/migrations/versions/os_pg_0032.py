"""Encrypted owner-authored knowledge and durable deletion barriers."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "os_pg_0032"
down_revision = "os_pg_0031"
branch_labels = None
depends_on = None
OWNER = ["installation_id", "application_id", "tenant_id", "subject_id"]


def scope():
    return [sa.Column("installation_id",pg.UUID(as_uuid=True),nullable=False),
            sa.Column("application_id",pg.UUID(as_uuid=True),nullable=False),
            sa.Column("tenant_id",sa.String(256),nullable=False),
            sa.Column("subject_id",sa.String(256),nullable=False)]


def uuid(name, nullable=False):
    return sa.Column(name,pg.UUID(as_uuid=True),nullable=nullable)


def integer(name):
    return sa.Column(name,sa.BigInteger,nullable=False)


def date(name, nullable=False):
    return sa.Column(name,sa.DateTime(timezone=True),nullable=nullable)


def owned(name):
    return sa.UniqueConstraint(*OWNER,"id",name="uq_"+name+"_owner_id")


def parent(table, field):
    return sa.ForeignKeyConstraint([*OWNER,field],[table+"."+k for k in [*OWNER,"id"]],
                                   name="fk_"+table+"_"+field)


def upgrade():
    op.create_table("personal_knowledge_entries",*scope(),
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),uuid("settings_id"),uuid("active_revision_id"),
        integer("version"),integer("content_revision"),
        sa.Column("state",sa.String(16),nullable=False),sa.Column("projection_state",sa.String(16),nullable=False),
        date("valid_until",True),date("created_at"),date("updated_at"),owned("knowledge_entry"),
        parent("personal_learning_settings","settings_id"),
        sa.CheckConstraint("version>0 AND content_revision>0 AND content_revision<=version",name="ck_knowledge_entry_versions"),
        sa.CheckConstraint("state IN ('ACTIVE','PAUSED','FORGOTTEN') AND projection_state IN ('PENDING','PURGING','PURGED')",
                           name="ck_knowledge_entry_states"),
        sa.CheckConstraint("updated_at>=created_at",name="ck_knowledge_entry_time"))
    op.create_table("personal_knowledge_operations",*scope(),
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),
        *[uuid(k) for k in ["settings_id","entry_id","session_id","command_id"]],
        sa.Column("kind",sa.String(16),nullable=False),
        *[integer(k) for k in ["expected_version","accepted_version","context_revision"]],
        sa.Column("request_mac",sa.String(64)),uuid("mac_key_id",True),
        sa.Column("receipt",pg.JSONB,nullable=False),date("created_at"),owned("knowledge_operation"),
        parent("personal_learning_settings","settings_id"),parent("personal_knowledge_entries","entry_id"),
        parent("os_interactive_sessions","session_id"),
        sa.UniqueConstraint(*OWNER,"command_id",name="uq_knowledge_operation_key"),
        sa.UniqueConstraint(*OWNER,"context_revision",name="uq_knowledge_operation_context"),
        sa.UniqueConstraint(*OWNER,"entry_id","accepted_version",name="uq_knowledge_operation_version"),
        sa.CheckConstraint("kind IN ('SAVE','REVISE','PAUSE','RESUME','FORGET')",name="ck_knowledge_operation_kind"),
        sa.CheckConstraint("expected_version>=0 AND accepted_version=expected_version+1 AND context_revision>1",
                           name="ck_knowledge_operation_versions"),
        sa.CheckConstraint("(request_mac IS NULL AND mac_key_id IS NULL) OR (request_mac IS NOT NULL AND request_mac ~ '^[a-f0-9]{64}$' AND mac_key_id IS NOT NULL)",
                           name="ck_knowledge_operation_mac"))
    op.create_table("personal_knowledge_revisions",*scope(),
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),uuid("entry_id"),uuid("operation_id"),
        integer("ordinal"),sa.Column("envelope",pg.JSONB(none_as_null=True)),date("created_at"),owned("knowledge_revision"),
        parent("personal_knowledge_entries","entry_id"),parent("personal_knowledge_operations","operation_id"),
        sa.UniqueConstraint(*OWNER,"entry_id","id",name="uq_knowledge_revision_entry_id"),
        sa.UniqueConstraint(*OWNER,"entry_id","ordinal",name="uq_knowledge_revision_ordinal"),
        sa.CheckConstraint("ordinal>0",name="ck_knowledge_revision_ordinal"),
        sa.CheckConstraint("envelope IS NULL OR COALESCE(envelope=jsonb_build_object('version',1,'keyId',envelope->'keyId',"
            "'nonce',envelope->'nonce','ciphertext',envelope->'ciphertext') AND jsonb_typeof(envelope->'keyId')='string' "
            "AND envelope->>'keyId' ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' "
            "AND jsonb_typeof(envelope->'nonce')='string' AND length(envelope->>'nonce')=16 "
            "AND jsonb_typeof(envelope->'ciphertext')='string' AND length(envelope->>'ciphertext') BETWEEN 24 AND 12000,false)",
            name="ck_knowledge_revision_envelope"))
    op.create_foreign_key("fk_knowledge_active_revision","personal_knowledge_entries","personal_knowledge_revisions",
        [*OWNER,"id","active_revision_id"],[*OWNER,"entry_id","id"],deferrable=True,initially="DEFERRED")
    op.create_table("personal_knowledge_projection_jobs",*scope(),
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),uuid("entry_id"),uuid("revision_id"),uuid("operation_id"),
        *[integer(k) for k in ["entry_version","recall_epoch","index_generation"]],
        sa.Column("profile_ref",sa.String(64),nullable=False),
        *[sa.Column(k,sa.String(16),nullable=False) for k in ["operation","state"]],date("created_at"),owned("knowledge_job"),
        parent("personal_knowledge_entries","entry_id"),parent("personal_knowledge_revisions","revision_id"),
        parent("personal_knowledge_operations","operation_id"),
        sa.UniqueConstraint(*OWNER,"entry_id","entry_version",name="uq_knowledge_job_version"),
        sa.CheckConstraint("entry_version>0 AND recall_epoch>0 AND index_generation>0",name="ck_knowledge_job_versions"),
        sa.CheckConstraint("profile_ref='synthetic-embedding/1' AND operation IN ('INDEX','PURGE') AND state IN ('PENDING','CANCELLED','COMPLETE')",
                           name="ck_knowledge_job_states"))
    op.create_table("personal_forget_journal",*scope(),
        sa.Column("id",pg.UUID(as_uuid=True),primary_key=True),uuid("entry_id"),uuid("operation_id"),
        integer("context_revision"),date("forgotten_at"),date("completed_at",True),owned("forget_journal"),
        parent("personal_knowledge_entries","entry_id"),parent("personal_knowledge_operations","operation_id"),
        sa.UniqueConstraint(*OWNER,"entry_id",name="uq_forget_journal_entry"),
        sa.CheckConstraint("context_revision>1 AND (completed_at IS NULL OR completed_at>=forgotten_at)",name="ck_forget_journal_time"))
    op.execute(GUARDS)


GUARDS = r"""
-- Preserve0031 consent transitions, adding only a separately receipted context branch.
CREATE OR REPLACE FUNCTION os_guard_learning_settings() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_settings_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.learning_epoch<>1 OR NEW.recall_epoch<>1 OR NEW.context_revision<>1
   OR NEW.index_generation<>1 OR NEW.created_at<>NEW.updated_at
   OR NEW.choice->'learnConversation'<>'false'::jsonb OR NEW.choice->'learnUsage'<>'false'::jsonb
   OR NEW.choice->'useMemory'<>'false'::jsonb THEN RAISE EXCEPTION 'learning_default_consent'; END IF;
 ELSIF NEW.version=OLD.version THEN
  IF (to_jsonb(NEW)-ARRAY['context_revision','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['context_revision','updated_at'])
   OR NEW.context_revision<>OLD.context_revision+1 OR NEW.updated_at<OLD.updated_at
   THEN RAISE EXCEPTION 'knowledge_context_transition'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])
   IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])
   OR NEW.version<>OLD.version+1
   OR NEW.learning_epoch<>OLD.learning_epoch+(CASE WHEN (NEW.choice-'useMemory') IS DISTINCT FROM (OLD.choice-'useMemory') THEN 1 ELSE 0 END)
   OR NEW.recall_epoch<>OLD.recall_epoch+(CASE WHEN (NEW.choice-ARRAY['learnConversation','learnUsage'])
    IS DISTINCT FROM (OLD.choice-ARRAY['learnConversation','learnUsage']) THEN 1 ELSE 0 END)
   OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'learning_settings_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER commit_learning_settings ON personal_learning_settings;
CREATE CONSTRAINT TRIGGER commit_learning_settings AFTER UPDATE ON personal_learning_settings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (NEW.version IS DISTINCT FROM OLD.version)
 EXECUTE FUNCTION os_guard_learning_commit();

CREATE FUNCTION os_assert_knowledge_entry(eid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE e personal_knowledge_entries%ROWTYPE; r personal_knowledge_revisions%ROWTYPE;
 s personal_learning_settings%ROWTYPE; c personal_knowledge_operations%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
 j personal_forget_journal%ROWTYPE; p personal_knowledge_projection_jobs%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=e.settings_id;
 SELECT * INTO r FROM personal_knowledge_revisions WHERE id=e.active_revision_id;
 SELECT * INTO c FROM personal_knowledge_operations WHERE entry_id=e.id AND accepted_version=e.version;
 IF e.id IS NULL OR s.id IS NULL OR r.id IS NULL OR c.id IS NULL
  OR r.entry_id<>e.id OR r.ordinal<>e.content_revision OR c.settings_id<>s.id
  OR c.created_at<>e.updated_at OR c.context_revision>s.context_revision
  OR c.receipt IS DISTINCT FROM jsonb_build_object('commandId',c.command_id,'operationId',c.id,'entryId',e.id,
    'revision',e.version,'contextRevision',c.context_revision,'state',e.state,
    'projectionState',CASE WHEN e.state='FORGOTTEN' THEN 'PURGING' ELSE 'PENDING' END)
 THEN RAISE EXCEPTION 'knowledge_atomic_receipt'; END IF;
 IF live THEN
  IF c.context_revision<>s.context_revision OR s.updated_at<>c.created_at OR c.request_mac IS NULL
   THEN RAISE EXCEPTION 'knowledge_atomic_context'; END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=c.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=e.installation_id AND id=e.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=e.installation_id AND application_id=e.application_id
   AND tenant_id=e.tenant_id AND subject_id=e.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'knowledge_current_owner'; END IF;
 END IF;
 IF e.state='FORGOTTEN' THEN
  SELECT * INTO j FROM personal_forget_journal WHERE entry_id=e.id;
  SELECT * INTO p FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND entry_version=e.version;
  IF c.kind<>'FORGET' OR j.id IS NULL OR j.operation_id<>c.id OR j.context_revision<>c.context_revision
   OR j.forgotten_at<>c.created_at OR p.id IS NULL OR p.operation<>'PURGE' OR p.operation_id<>c.id
   OR p.created_at<>c.created_at OR p.revision_id<>r.id
   OR (e.projection_state='PURGING' AND (j.completed_at IS NOT NULL OR p.state<>'PENDING'))
   OR (e.projection_state='PURGED' AND (j.completed_at IS NULL OR p.state<>'COMPLETE'
    OR EXISTS(SELECT 1 FROM personal_knowledge_revisions WHERE entry_id=e.id AND envelope IS NOT NULL)
    OR EXISTS(SELECT 1 FROM personal_knowledge_operations WHERE entry_id=e.id AND kind<>'FORGET' AND request_mac IS NOT NULL)))
   OR e.projection_state NOT IN ('PURGING','PURGED')
   OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND operation='INDEX' AND state='PENDING')
   THEN RAISE EXCEPTION 'knowledge_forget_barrier'; END IF;
 ELSE
  IF r.envelope IS NULL OR e.projection_state<>'PENDING' OR EXISTS(SELECT 1 FROM personal_forget_journal WHERE entry_id=e.id)
   THEN RAISE EXCEPTION 'knowledge_live_revision'; END IF;
  IF c.kind IN ('SAVE','REVISE') AND (r.operation_id<>c.id OR r.created_at<>c.created_at)
   THEN RAISE EXCEPTION 'knowledge_revision_operation'; END IF;
  IF live AND c.kind IN ('SAVE','REVISE','RESUME') AND e.valid_until IS NOT NULL AND e.valid_until<=clock_timestamp()
   THEN RAISE EXCEPTION 'knowledge_expired_publication'; END IF;
  IF e.state='ACTIVE' THEN
   SELECT * INTO p FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND entry_version=e.version;
   IF c.kind NOT IN ('SAVE','REVISE','RESUME') OR p.id IS NULL OR p.operation<>'INDEX' OR p.state<>'PENDING'
    OR p.revision_id<>r.id OR p.operation_id<>c.id OR p.created_at<>c.created_at
    OR p.index_generation<>s.index_generation OR (live AND p.recall_epoch<>s.recall_epoch)
    THEN RAISE EXCEPTION 'knowledge_projection_intent'; END IF;
  ELSIF c.kind<>'PAUSE' OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND state='PENDING')
   THEN RAISE EXCEPTION 'knowledge_pause_barrier'; END IF;
 END IF;
END $$;

CREATE FUNCTION os_guard_knowledge_entry() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'knowledge_entry_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.content_revision<>1 OR NEW.state<>'ACTIVE' OR NEW.projection_state<>'PENDING'
   OR NEW.created_at<>NEW.updated_at THEN RAISE EXCEPTION 'knowledge_initial_entry'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['version','content_revision','active_revision_id','state','projection_state','valid_until','updated_at'])
    IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','content_revision','active_revision_id','state','projection_state','valid_until','updated_at'])
    OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'knowledge_entry_identity'; END IF;
  IF NEW.version=OLD.version THEN
   IF OLD.state<>'FORGOTTEN' OR OLD.projection_state<>'PURGING' OR NEW.projection_state<>'PURGED'
    OR (to_jsonb(NEW)-'projection_state') IS DISTINCT FROM (to_jsonb(OLD)-'projection_state')
    THEN RAISE EXCEPTION 'knowledge_cleanup_transition'; END IF;
  ELSIF NEW.version<>OLD.version+1 OR OLD.state='FORGOTTEN' THEN RAISE EXCEPTION 'knowledge_entry_version';
  ELSIF NEW.active_revision_id IS DISTINCT FROM OLD.active_revision_id THEN
   IF NEW.content_revision<>OLD.content_revision+1 OR NEW.state<>'ACTIVE' OR NEW.projection_state<>'PENDING'
    THEN RAISE EXCEPTION 'knowledge_revision_transition'; END IF;
  ELSE
   IF NEW.content_revision<>OLD.content_revision OR NEW.valid_until IS DISTINCT FROM OLD.valid_until
    OR NOT ((OLD.state='ACTIVE' AND NEW.state='PAUSED') OR (OLD.state='PAUSED' AND NEW.state='ACTIVE') OR NEW.state='FORGOTTEN')
    OR NEW.projection_state<>(CASE WHEN NEW.state='FORGOTTEN' THEN 'PURGING' ELSE 'PENDING' END)
    THEN RAISE EXCEPTION 'knowledge_state_transition'; END IF;
  END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_knowledge_entry BEFORE INSERT OR UPDATE OR DELETE ON personal_knowledge_entries
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_entry();

CREATE FUNCTION os_guard_knowledge_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE e personal_knowledge_entries%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'knowledge_record_retained'; END IF;
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=OLD.entry_id;
 IF TG_TABLE_NAME='personal_knowledge_revisions' THEN
  IF OLD.envelope IS NULL OR NEW.envelope IS NOT NULL OR e.state<>'FORGOTTEN'
   OR (to_jsonb(NEW)-'envelope') IS DISTINCT FROM (to_jsonb(OLD)-'envelope')
   THEN RAISE EXCEPTION 'knowledge_revision_immutable'; END IF;
 ELSIF TG_TABLE_NAME='personal_knowledge_operations' THEN
  IF OLD.kind='FORGET' OR OLD.request_mac IS NULL OR NEW.request_mac IS NOT NULL OR NEW.mac_key_id IS NOT NULL
   OR e.state<>'FORGOTTEN' OR (to_jsonb(NEW)-ARRAY['request_mac','mac_key_id']) IS DISTINCT FROM
    (to_jsonb(OLD)-ARRAY['request_mac','mac_key_id']) THEN RAISE EXCEPTION 'knowledge_operation_immutable'; END IF;
 ELSE
  IF OLD.completed_at IS NOT NULL OR NEW.completed_at IS NULL OR e.state<>'FORGOTTEN'
   OR (to_jsonb(NEW)-'completed_at') IS DISTINCT FROM (to_jsonb(OLD)-'completed_at')
   THEN RAISE EXCEPTION 'knowledge_journal_immutable'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER immutable_knowledge_revision BEFORE UPDATE OR DELETE ON personal_knowledge_revisions
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_immutable();
CREATE TRIGGER immutable_knowledge_operation BEFORE UPDATE OR DELETE ON personal_knowledge_operations
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_immutable();
CREATE TRIGGER immutable_forget_journal BEFORE UPDATE OR DELETE ON personal_forget_journal
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_immutable();

CREATE FUNCTION os_guard_knowledge_job() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE e personal_knowledge_entries%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'knowledge_job_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'PENDING' THEN RAISE EXCEPTION 'knowledge_job_initial'; END IF;
 ELSE
  SELECT * INTO e FROM personal_knowledge_entries WHERE id=OLD.entry_id;
  IF OLD.state<>'PENDING' OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state')
   OR NOT ((OLD.operation='INDEX' AND NEW.state='CANCELLED' AND (e.version>OLD.entry_version OR e.state<>'ACTIVE'))
    OR (OLD.operation='PURGE' AND NEW.state='COMPLETE' AND e.state='FORGOTTEN'))
   THEN RAISE EXCEPTION 'knowledge_job_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_knowledge_job BEFORE INSERT OR UPDATE OR DELETE ON personal_knowledge_projection_jobs
 FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_job();

CREATE FUNCTION os_guard_knowledge_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE eid uuid; live boolean; e personal_knowledge_entries%ROWTYPE; c personal_knowledge_operations%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE settings_id=NEW.id AND context_revision=NEW.context_revision;
  IF c.id IS NULL THEN RAISE EXCEPTION 'knowledge_context_receipt'; END IF;
  eid=c.entry_id; live=true;
 ELSIF TG_TABLE_NAME='personal_knowledge_entries' THEN
  eid=NEW.id; live=(TG_OP='INSERT');
  IF TG_OP='UPDATE' THEN live=NEW.version<>OLD.version; END IF;
  IF live THEN
   SELECT * INTO c FROM personal_knowledge_operations WHERE entry_id=eid AND accepted_version=NEW.version;
   IF TG_OP='INSERT' THEN
    IF c.kind IS DISTINCT FROM 'SAVE' THEN RAISE EXCEPTION 'knowledge_save_operation'; END IF;
   ELSE
    IF c.kind IS DISTINCT FROM (CASE WHEN NEW.active_revision_id<>OLD.active_revision_id THEN 'REVISE'
     WHEN NEW.state='FORGOTTEN' THEN 'FORGET' WHEN NEW.state='PAUSED' THEN 'PAUSE' ELSE 'RESUME' END)
     THEN RAISE EXCEPTION 'knowledge_transition_operation'; END IF;
   END IF;
  END IF;
 ELSE
  eid=NEW.entry_id; live=(TG_OP='INSERT');
  IF TG_TABLE_NAME='personal_knowledge_projection_jobs' AND TG_OP='UPDATE' AND NEW.state='CANCELLED' THEN
   RETURN NULL;
  END IF;
 END IF;
 PERFORM os_assert_knowledge_entry(eid,live);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;
 IF NOT live AND TG_TABLE_NAME IN ('personal_knowledge_revisions','personal_knowledge_operations','personal_forget_journal')
  AND e.projection_state<>'PURGED' THEN RAISE EXCEPTION 'knowledge_cleanup_incomplete'; END IF;
 IF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_revisions' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE id=NEW.operation_id;
  IF NEW.id<>e.active_revision_id OR NEW.envelope IS NULL OR c.kind NOT IN ('SAVE','REVISE')
   OR c.accepted_version<>e.version OR NEW.created_at<>c.created_at
   THEN RAISE EXCEPTION 'knowledge_revision_binding'; END IF;
 ELSIF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
  IF NEW.entry_version<>e.version OR NEW.revision_id<>e.active_revision_id THEN RAISE EXCEPTION 'knowledge_job_binding'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_knowledge_context AFTER UPDATE ON personal_learning_settings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (NEW.version=OLD.version)
 EXECUTE FUNCTION os_guard_knowledge_commit();
CREATE CONSTRAINT TRIGGER commit_knowledge_entry AFTER INSERT OR UPDATE ON personal_knowledge_entries
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_commit();
CREATE CONSTRAINT TRIGGER commit_knowledge_operation AFTER INSERT OR UPDATE ON personal_knowledge_operations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_commit();
CREATE CONSTRAINT TRIGGER commit_knowledge_revision AFTER INSERT OR UPDATE ON personal_knowledge_revisions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_commit();
CREATE CONSTRAINT TRIGGER commit_knowledge_job AFTER INSERT OR UPDATE ON personal_knowledge_projection_jobs
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_commit();
CREATE CONSTRAINT TRIGGER commit_forget_journal AFTER INSERT OR UPDATE ON personal_forget_journal
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_knowledge_commit();
"""


def downgrade():
    raise RuntimeError("Owned populated data requires protected forward recovery")
