"""Independent authenticated semantic usage sources and daily learning batches."""
from alembic import op
revision="os_pg_0039"
down_revision="os_pg_0038"
branch_labels=None
depends_on=None

def upgrade():
    for statement in TABLES:op.get_bind().exec_driver_sql(statement)
    op.execute(GUARDS)

TABLES = (
    """
CREATE TABLE os_usage_semantic_profiles (
	id UUID NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	application_revision BIGINT NOT NULL, 
	application_generation BIGINT NOT NULL, 
	schema_ref VARCHAR(256) NOT NULL, 
	definition JSONB NOT NULL, 
	definition_digest VARCHAR(64) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_usage_profile_application FOREIGN KEY(installation_id, application_id) REFERENCES os_applications (installation_id, id), 
	CONSTRAINT uq_usage_profile_app_id UNIQUE (installation_id, application_id, id), 
	CONSTRAINT uq_usage_profile_revision UNIQUE (installation_id, application_id, application_revision, schema_ref), 
	CONSTRAINT ck_usage_profile_versions CHECK (application_revision>0 AND application_generation>0), 
	CONSTRAINT ck_usage_profile_digest CHECK (definition_digest ~ '^[a-f0-9]{64}$')
)
""",
    """
CREATE TABLE personal_usage_origins (
	id UUID NOT NULL, 
	source_id UUID NOT NULL, 
	profile_id UUID NOT NULL, 
	event_id UUID NOT NULL, 
	stream_ref VARCHAR(256) NOT NULL, 
	source_sequence BIGINT NOT NULL, 
	subject_generation BIGINT NOT NULL, 
	policy_generation BIGINT NOT NULL, 
	signal_mac VARCHAR(64), 
	mac_key_id UUID, 
	account_checked_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	account_valid_until TIMESTAMP WITH TIME ZONE NOT NULL, 
	occurred_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_usage_origin_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_personal_learning_sources_source_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_id) REFERENCES personal_learning_sources (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_usage_origin_profile FOREIGN KEY(installation_id, application_id, profile_id) REFERENCES os_usage_semantic_profiles (installation_id, application_id, id), 
	CONSTRAINT uq_usage_origin_source UNIQUE (installation_id, application_id, tenant_id, subject_id, source_id), 
	CONSTRAINT uq_usage_origin_event UNIQUE (installation_id, application_id, tenant_id, subject_id, event_id), 
	CONSTRAINT uq_usage_origin_sequence UNIQUE (installation_id, application_id, tenant_id, subject_id, stream_ref, source_sequence), 
	CONSTRAINT ck_usage_origin_versions CHECK (source_sequence>0 AND subject_generation>0 AND policy_generation>0), 
	CONSTRAINT ck_usage_origin_time CHECK (created_at>=occurred_at-interval '5 seconds' AND created_at<occurred_at+interval '14 days' AND account_valid_until>account_checked_at AND account_valid_until<=account_checked_at+interval '15 seconds'), 
	CONSTRAINT ck_usage_origin_private CHECK ((signal_mac IS NULL AND mac_key_id IS NULL) OR (signal_mac ~ '^[a-f0-9]{64}$' AND mac_key_id IS NOT NULL))
)
""",
    """
CREATE TABLE personal_usage_batches (
	id UUID NOT NULL, 
	job_id UUID NOT NULL, 
	utc_day VARCHAR(10) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_usage_batch_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_personal_learning_jobs_job_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, job_id) REFERENCES personal_learning_jobs (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_usage_batch_day UNIQUE (installation_id, application_id, tenant_id, subject_id, utc_day), 
	CONSTRAINT uq_usage_batch_job UNIQUE (installation_id, application_id, tenant_id, subject_id, job_id), 
	CONSTRAINT ck_usage_batch_day CHECK (utc_day=to_char(created_at AT TIME ZONE 'UTC','YYYY-MM-DD'))
)
""",
    """
ALTER TABLE personal_learning_sources ALTER COLUMN session_id DROP NOT NULL
""",
    """
ALTER TABLE personal_learning_sources DROP CONSTRAINT ck_learning_source_state
""",
    """
ALTER TABLE personal_learning_sources ADD CONSTRAINT ck_learning_source_state CHECK (kind IN ('owner-statement/1','accepted-user-turn/1','accepted-outcome/1','usage-event/2') AND learning_epoch>0 AND ((state='AVAILABLE' AND revision=1) OR (state='FORGOTTEN' AND revision=2)))
""",
    """
ALTER TABLE personal_learning_sources ADD CONSTRAINT ck_learning_source_session_lane CHECK ((kind='usage-event/2')=(session_id IS NULL))
""",
    """
ALTER TABLE personal_learning_jobs DROP CONSTRAINT ck_learning_job_profile
""",
    """
ALTER TABLE personal_learning_jobs ADD CONSTRAINT ck_learning_job_profile CHECK (profile_ref='synthetic-staging/1' AND prompt_ref IN ('mem0-2.2.1-owner-source/1','mem0-2.2.1-accepted-source/2','mem0-2.2.1-usage-source/3') AND source_mac ~ '^[a-f0-9]{64}$')
""",
    """
ALTER TABLE personal_knowledge_publications DROP CONSTRAINT ck_knowledge_publication_operation
""",
    """
ALTER TABLE personal_knowledge_publications ADD CONSTRAINT ck_knowledge_publication_operation CHECK (epistemic IN ('user-stated','derived-outcome','behavior-inferred') AND ((operation='add' AND target_count=0) OR (operation='supersede' AND target_count=1) OR (operation='merge' AND target_count BETWEEN 2 AND 8)))
""",
)

GUARDS = r"""

CREATE FUNCTION os_usage_source_current(sid uuid) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
DECLARE source_row personal_learning_sources%ROWTYPE; o personal_usage_origins%ROWTYPE;
 p os_usage_semantic_profiles%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 SELECT * INTO source_row FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO o FROM personal_usage_origins WHERE source_id=sid;
 SELECT * INTO p FROM os_usage_semantic_profiles WHERE id=o.profile_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=source_row.installation_id AND id=source_row.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=source_row.installation_id AND application_id=source_row.application_id
  AND tenant_id=source_row.tenant_id AND subject_id=source_row.subject_id;
 RETURN COALESCE(source_row.kind='usage-event/2' AND source_row.session_id IS NULL AND o.id IS NOT NULL AND p.id IS NOT NULL
  AND app.active AND owner.active AND o.signal_mac IS NOT NULL AND o.mac_key_id=source_row.mac_key_id
  AND source_row.command_id=o.event_id AND source_row.created_at=o.created_at
  AND source_row.expires_at<=o.occurred_at+interval '14 days'
  AND ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   =ROW(p.application_revision,p.application_generation,o.subject_generation,o.policy_generation)
  AND NOT EXISTS(SELECT 1 FROM personal_learning_source_origins WHERE source_id=sid),false);
END $$;
CREATE FUNCTION os_guard_usage_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE app os_applications%ROWTYPE;
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'usage_profile_immutable'; END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id;
 IF app.id IS NULL OR NOT app.active OR app.revision<>NEW.application_revision OR app.generation<>NEW.application_generation
  OR NEW.definition IS DISTINCT FROM jsonb_build_object('applicationId',NEW.application_id,
   'expectedApplicationRevision',NEW.application_revision,'schemaRef',NEW.schema_ref,
   'settingKey',NEW.definition->'settingKey','allowedValues',NEW.definition->'allowedValues','contextRef','general/1')
  OR COALESCE(NEW.definition->>'settingKey' NOT IN ('presentation.density','presentation.order','notification.format'),true)
  OR jsonb_typeof(NEW.definition->'allowedValues') IS DISTINCT FROM 'array'
 THEN RAISE EXCEPTION 'usage_profile_binding'; END IF;
 IF jsonb_array_length(NEW.definition->'allowedValues') NOT BETWEEN 1 AND 16
  OR EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.definition->'allowedValues') value
   WHERE jsonb_typeof(value)<>'string' OR value#>>'{}' !~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$')
  OR (SELECT count(DISTINCT value) FROM jsonb_array_elements(NEW.definition->'allowedValues') value)
   <>jsonb_array_length(NEW.definition->'allowedValues')
 THEN RAISE EXCEPTION 'usage_profile_values'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_usage_profile BEFORE INSERT OR UPDATE OR DELETE ON os_usage_semantic_profiles
 FOR EACH ROW EXECUTE FUNCTION os_guard_usage_profile();
CREATE FUNCTION os_guard_usage_origin() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'usage_origin_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.signal_mac IS NULL OR NEW.mac_key_id IS NULL THEN RAISE EXCEPTION 'usage_origin_initial'; END IF;
 ELSE
  IF OLD.signal_mac IS NULL OR NEW.signal_mac IS NOT NULL OR NEW.mac_key_id IS NOT NULL
   OR (to_jsonb(NEW)-ARRAY['signal_mac','mac_key_id']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['signal_mac','mac_key_id'])
   OR NOT EXISTS(SELECT 1 FROM personal_learning_sources WHERE id=NEW.source_id AND state='FORGOTTEN' AND envelope IS NULL)
   THEN RAISE EXCEPTION 'usage_origin_immutable'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_usage_origin BEFORE INSERT OR UPDATE OR DELETE ON personal_usage_origins
 FOR EACH ROW EXECUTE FUNCTION os_guard_usage_origin();
CREATE FUNCTION os_commit_usage_origin() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT os_usage_source_current(NEW.source_id) OR NEW.account_valid_until<=clock_timestamp()
  OR NEW.account_checked_at<clock_timestamp()-interval '5 seconds'
  OR NEW.account_checked_at>clock_timestamp()+interval '5 seconds'
 THEN RAISE EXCEPTION 'usage_current_actor'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_usage_origin AFTER INSERT ON personal_usage_origins
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_usage_origin();
CREATE FUNCTION os_usage_batch_current(jid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_usage_batches b JOIN personal_learning_jobs j ON j.id=b.job_id
  WHERE j.id=jid AND j.prompt_ref='mem0-2.2.1-usage-source/3' AND j.created_at=b.created_at)
 AND (SELECT count(*)>=3
  FROM personal_learning_job_sources e JOIN personal_usage_origins o ON o.source_id=e.source_id WHERE e.job_id=jid)
 AND (SELECT count(DISTINCT (o.occurred_at AT TIME ZONE 'UTC')::date)>=2
  AND count(DISTINCT o.signal_mac)=1 AND count(DISTINCT o.profile_id)=1
  FROM personal_learning_job_sources e JOIN personal_usage_origins o ON o.source_id=e.source_id WHERE e.job_id=jid)
 AND NOT EXISTS(SELECT 1 FROM personal_learning_job_sources e WHERE e.job_id=jid AND NOT os_usage_source_current(e.source_id))
$$;
CREATE FUNCTION os_guard_usage_batch() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'usage_batch_immutable'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_usage_batch BEFORE INSERT OR UPDATE OR DELETE ON personal_usage_batches
 FOR EACH ROW EXECUTE FUNCTION os_guard_usage_batch();
CREATE FUNCTION os_commit_usage_batch() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT COALESCE(os_usage_batch_current(NEW.job_id),false) THEN RAISE EXCEPTION 'usage_batch_binding'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_usage_batch AFTER INSERT ON personal_usage_batches
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_usage_batch();
CREATE FUNCTION os_conversation_learning_source_current(sid uuid) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
 t os_tasks%ROWTYPE; segment os_segments%ROWTYPE; a os_artifacts%ROWTYPE; owner os_subjects%ROWTYPE;
 input os_source_inputs%ROWTYPE; result os_accepted_results%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF s.id IS NULL THEN RETURN false; END IF;
 IF s.kind='owner-statement/1' THEN RETURN NOT EXISTS(SELECT 1 FROM personal_learning_source_origins WHERE source_id=sid); END IF;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO t FROM os_tasks WHERE id=o.task_id;
 SELECT * INTO segment FROM os_segments WHERE id=o.segment_id;
 SELECT * INTO a FROM os_artifacts WHERE id=o.artifact_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF o.id IS NULL OR t.state IS DISTINCT FROM 'COMPLETED' OR t.version<>o.task_version
  OR segment.task_id<>t.id OR segment.state IS DISTINCT FROM 'FINISHED'
  OR NOT EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=t.id AND state='ACTIVE')
  OR owner.id IS NULL OR NOT owner.active OR owner.host_policy_generation<>o.policy_generation
  OR a.id IS NULL OR a.expires_at<=clock_timestamp() OR a.ciphertext_digest<>o.ciphertext_digest
  OR s.expires_at>a.expires_at OR o.created_at<>s.created_at
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'name'='os.grounded/1')
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'type'='RUN_FINISHED') THEN RETURN false; END IF;
 IF o.input_id IS NOT NULL THEN
  SELECT * INTO input FROM os_source_inputs WHERE id=o.input_id;
  RETURN s.kind='accepted-user-turn/1' AND input.admitted_task_id=t.id AND input.artifact_id=a.id
   AND input.expires_at>clock_timestamp() AND s.expires_at<=input.expires_at
   AND a.purpose='intent' AND a.classification='owner-private' AND o.occurred_at=input.created_at
   AND EXISTS(SELECT 1 FROM os_admissions WHERE task_id=t.id AND source_input_id=input.id AND segment_id=segment.id);
 ELSE
  SELECT * INTO result FROM os_accepted_results WHERE id=o.result_id;
  RETURN s.kind='accepted-outcome/1' AND result.task_id=t.id AND result.segment_id=segment.id
   AND result.artifact_id=a.id AND result.ciphertext_digest=a.ciphertext_digest AND result.contract_ref='ReadStageResult'
   AND a.purpose='artifact' AND a.classification='protected' AND o.occurred_at=result.created_at
   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=result.attempt_id AND state='SETTLED');
 END IF;
END $$;
CREATE OR REPLACE FUNCTION os_selected_learning_source_current(sid uuid) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM personal_learning_sources WHERE id=sid AND kind='usage-event/2')
 THEN RETURN os_usage_source_current(sid); END IF;
 RETURN os_conversation_learning_source_current(sid);
END $$;
CREATE OR REPLACE FUNCTION os_guard_learning_source_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE sid uuid; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_learning_sources' THEN
  sid=NEW.id;
  IF TG_OP='INSERT' THEN
   SELECT * INTO settings FROM personal_learning_settings WHERE id=NEW.settings_id;
   IF settings.choice->(CASE WHEN NEW.kind='usage-event/2' THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb
    OR settings.learning_epoch<>NEW.learning_epoch OR NEW.expires_at<=clock_timestamp()
    OR (SELECT count(*) FROM personal_learning_sources WHERE settings_id=NEW.settings_id AND state='AVAILABLE')>64
    THEN RAISE EXCEPTION 'learning_source_consent_capacity'; END IF;
   IF NEW.kind<>'usage-event/2' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id); END IF;
  END IF;
 ELSE
  sid=NEW.source_id;
  IF TG_TABLE_NAME='personal_learning_source_forgets' THEN
   IF TG_OP='INSERT' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
   ELSE PERFORM os_assert_learning_source_owner(sid,NEW.cleanup_session_id); END IF;
  END IF;
 END IF;
 PERFORM os_assert_learning_source(sid);
 IF TG_TABLE_NAME='personal_learning_sources' AND TG_OP='INSERT' AND NOT COALESCE(os_selected_learning_source_current(sid),false)
  THEN RAISE EXCEPTION 'selected_learning_source_binding'; END IF;
 RETURN NULL;
END $$;CREATE OR REPLACE FUNCTION os_guard_learning_source_intent() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_sources%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_source_intent_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'PENDING_DISPATCH' THEN RAISE EXCEPTION 'learning_source_intent_initial'; END IF;
 ELSE
  SELECT * INTO s FROM personal_learning_sources WHERE id=OLD.source_id;
  SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
  IF OLD.state<>'PENDING_DISPATCH' OR NEW.state<>'CANCELLED'
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state')
   OR (s.state='AVAILABLE' AND settings.choice->(CASE WHEN s.kind='usage-event/2' THEN 'learnUsage' ELSE 'learnConversation' END)='true'::jsonb
       AND settings.learning_epoch=s.learning_epoch AND s.expires_at>clock_timestamp())
   THEN RAISE EXCEPTION 'learning_source_intent_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;CREATE OR REPLACE FUNCTION os_assert_learning_job_live(j personal_learning_jobs) RETURNS void LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=j.installation_id AND id=j.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=j.installation_id AND application_id=j.application_id
  AND tenant_id=j.tenant_id AND subject_id=j.subject_id;
 IF s.id IS NULL OR s.learning_epoch<>j.learning_epoch OR s.choice->(CASE WHEN j.prompt_ref='mem0-2.2.1-usage-source/3' THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb
  OR s.choice->>'extractorProfile'<>j.profile_ref OR app.id IS NULL OR NOT app.active OR owner.id IS NULL OR NOT owner.active
  OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
  OR j.expires_at<=clock_timestamp() OR j.account_valid_until<=clock_timestamp()
  OR j.account_checked_at<clock_timestamp()-interval '5 seconds'
  OR j.account_checked_at>clock_timestamp()+interval '5 seconds'
  OR NOT EXISTS(SELECT 1 FROM personal_learning_job_sources WHERE job_id=j.id)
  OR EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id
   JOIN personal_learning_source_intents i ON i.id=e.intent_id WHERE e.job_id=j.id
    AND (r.settings_id<>j.settings_id OR r.state<>'AVAILABLE' OR r.revision<>e.source_revision
     OR r.learning_epoch<>j.learning_epoch OR r.expires_at<=clock_timestamp() OR r.envelope IS NULL
     OR i.source_id<>r.id OR i.learning_epoch<>j.learning_epoch OR i.state<>'PENDING_DISPATCH'
     OR i.extractor_ref<>j.profile_ref OR i.due_at>j.created_at
     OR NOT COALESCE(os_selected_learning_source_current(r.id),false)
     OR (j.prompt_ref='mem0-2.2.1-owner-source/1' AND r.kind<>'owner-statement/1')
     OR (j.prompt_ref='mem0-2.2.1-accepted-source/2' AND r.kind NOT IN ('accepted-user-turn/1','accepted-outcome/1'))
     OR (j.prompt_ref='mem0-2.2.1-usage-source/3' AND r.kind<>'usage-event/2')))
  OR (SELECT count(DISTINCT r.kind) FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id WHERE e.job_id=j.id)<>1
 OR (j.prompt_ref='mem0-2.2.1-usage-source/3' AND NOT COALESCE(os_usage_batch_current(j.id),false))
 THEN RAISE EXCEPTION 'learning_job_current_authority'; END IF;
END $$;CREATE OR REPLACE FUNCTION os_assert_candidate_decision(did uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE d personal_candidate_decisions%ROWTYPE; c personal_knowledge_candidates%ROWTYPE;
 r personal_knowledge_candidate_revisions%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 s personal_learning_settings%ROWTYPE; p personal_knowledge_publications%ROWTYPE;
 op personal_knowledge_operations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; expected jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO d FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=d.candidate_id;
 SELECT * INTO r FROM personal_knowledge_candidate_revisions WHERE id=d.candidate_revision_id;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO p FROM personal_knowledge_publications WHERE decision_id=d.id;
 IF d.id IS NULL OR c.id IS NULL OR r.id IS NULL OR j.state IS DISTINCT FROM 'SUCCEEDED' OR s.id IS NULL
  OR r.candidate_id<>c.id OR r.ordinal<>d.accepted_version OR c.version<>d.accepted_version
  OR c.state<>(CASE WHEN d.decision='reject' THEN 'REJECTED' ELSE 'ACCEPTED' END)
  OR c.updated_at<>d.created_at OR d.context_revision>s.context_revision
  OR (r.envelope IS NULL AND NOT os_candidate_erasure_allowed(c.id))
  THEN RAISE EXCEPTION 'candidate_decision_binding'; END IF;
 IF d.decision='reject' THEN
  IF p.id IS NOT NULL THEN RAISE EXCEPTION 'candidate_rejection_publication'; END IF;
  expected='null'::jsonb;
 ELSE
  SELECT * INTO op FROM personal_knowledge_operations WHERE id=p.operation_id;
  IF p.id IS NULL OR p.candidate_id<>c.id OR p.candidate_revision_id<>r.id OR p.created_at<>d.created_at
   OR op.id IS NULL OR op.kind<>'SAVE' OR op.entry_id<>p.entry_id OR op.command_id<>d.command_id
   OR op.session_id<>d.session_id OR op.context_revision<>d.context_revision OR op.created_at<>d.created_at
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions kr WHERE kr.id=p.revision_id AND kr.entry_id=p.entry_id AND kr.operation_id=op.id)
   OR (SELECT count(*) FROM personal_knowledge_supersessions WHERE publication_id=p.id)<>p.target_count
   THEN RAISE EXCEPTION 'candidate_atomic_publication'; END IF;
  IF p.epistemic IS DISTINCT FROM (CASE WHEN d.decision='edit-and-accept' THEN 'user-stated'
    WHEN j.prompt_ref='mem0-2.2.1-usage-source/3' THEN 'behavior-inferred'
    WHEN EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources source_row ON source_row.id=e.source_id
     WHERE e.job_id=j.id AND source_row.kind='accepted-outcome/1') THEN 'derived-outcome' ELSE 'user-stated' END)
   THEN RAISE EXCEPTION 'candidate_epistemic_origin'; END IF;
  expected=op.receipt;
 END IF;
 IF d.receipt IS DISTINCT FROM jsonb_build_object('commandId',d.command_id,'decisionId',d.id,'candidateId',c.id,
  'candidateRevision',c.version,'state',c.state,'contextRevision',d.context_revision,'knowledge',expected)
  THEN RAISE EXCEPTION 'candidate_atomic_receipt'; END IF;
 IF live THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE id=d.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=d.installation_id AND application_id=d.application_id
   AND tenant_id=d.tenant_id AND subject_id=d.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp() OR d.request_mac IS NULL
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation OR owner.id IS NULL
   OR NOT owner.active OR owner.generation<>session.subject_generation OR c.expires_at<=clock_timestamp()
   OR os_learning_candidate_invalid(c.id) THEN RAISE EXCEPTION 'candidate_current_review'; END IF;
  IF d.decision<>'reject' THEN
   IF s.context_revision<>d.context_revision OR s.updated_at<>d.created_at OR s.learning_epoch<>j.learning_epoch
    OR s.choice->(CASE WHEN j.prompt_ref='mem0-2.2.1-usage-source/3' THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb OR s.choice->>'extractorProfile'<>j.profile_ref
    OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
     IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
    THEN RAISE EXCEPTION 'candidate_current_learning'; END IF;
   PERFORM os_assert_knowledge_entry(p.entry_id,true);
  END IF;
 END IF;
END $$;
"""

def downgrade():
    raise RuntimeError("Owned populated data requires protected forward recovery")
