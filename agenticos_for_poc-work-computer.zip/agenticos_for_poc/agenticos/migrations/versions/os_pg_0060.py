"""Pair private input files with started original-root storage attempts."""
from alembic import op

revision='os_pg_0060'
down_revision='os_pg_0059'
branch_labels=None
depends_on=None

TABLES = "\nCREATE TABLE os_agent_payload_writes (\n\tid UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\ttask_id UUID NOT NULL, \n\tsegment_id UUID NOT NULL, \n\tcontrol_epoch BIGINT NOT NULL, \n\tattempt_id UUID NOT NULL, \n\tartifact_id UUID NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\tschema_ref VARCHAR(256) NOT NULL, \n\tschema_version BIGINT NOT NULL, \n\tplain_bytes BIGINT NOT NULL, \n\ttimeout_ms BIGINT NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\texpires_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_agent_payload_write_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_agent_payload_write_attempt FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id, task_id, segment_id, root_id, control_epoch) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id, task_id, segment_id, root_id, control_epoch), \n\tCONSTRAINT uq_agent_payload_write_root UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT uq_agent_payload_write_attempt UNIQUE (installation_id, application_id, tenant_id, subject_id, attempt_id), \n\tCONSTRAINT uq_agent_payload_write_artifact UNIQUE (artifact_id), \n\tCONSTRAINT ck_agent_payload_write_bounds CHECK (control_epoch>0 AND schema_version>0 AND plain_bytes>=0 AND plain_bytes<=9007199254740991 AND timeout_ms>=1 AND timeout_ms<=900000 AND expires_at>created_at), \n\tCONSTRAINT ck_agent_payload_write_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n)\n\n;\n\nCREATE TABLE os_agent_private_payloads (\n\tid UUID NOT NULL, \n\twrite_id UUID NOT NULL, \n\troot_id UUID NOT NULL, \n\tciphertext_digest VARCHAR(64) NOT NULL, \n\tstored_bytes BIGINT NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_agent_private_payload_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_agent_private_payload_write FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, write_id, root_id) REFERENCES os_agent_payload_writes (installation_id, application_id, tenant_id, subject_id, id, root_id), \n\tCONSTRAINT fk_agent_private_payload_artifact FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, id, ciphertext_digest) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id, ciphertext_digest), \n\tCONSTRAINT uq_agent_private_payload_write UNIQUE (installation_id, application_id, tenant_id, subject_id, write_id), \n\tCONSTRAINT ck_agent_private_payload_bytes CHECK (stored_bytes>0 AND stored_bytes<=9007199254740991), \n\tCONSTRAINT ck_agent_private_payload_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$')\n)\n\n;"

GUARDS = r"""
CREATE FUNCTION os_guard_agent_payload_write() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE w os_work_attempts%ROWTYPE; r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE;
 a os_admissions%ROWTYPE; reg os_registrations%ROWTYPE; expected text; units jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_payload_write_immutable'; END IF;
 SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=NEW.root_id;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO reg FROM os_registrations WHERE installation_id=NEW.installation_id
  AND application_id=NEW.application_id AND revision=a.registration_revision;
 expected:=os_agent_resource_digest('command',jsonb_build_object('schema','agent-private-input-write/1',
  'writeId',NEW.id,'taskId',NEW.task_id,'segmentId',NEW.segment_id,'controlEpoch',NEW.control_epoch,
  'schemaRef',NEW.schema_ref,'schemaVersion',NEW.schema_version,'plainBytes',NEW.plain_bytes));
 units:=jsonb_build_object('tokens',0,'costMicros',0,'workMs',NEW.timeout_ms,'computeMs',NEW.timeout_ms,'storageBytes',2*NEW.plain_bytes+4096);
 IF NOT COALESCE(w.id IS NOT NULL AND w.kind='agent.storage' AND w.accounting_format='agent-resources/1'
  AND w.state='RUNNING' AND w.invocation_id=NEW.id AND q.id IS NOT NULL
  AND a.context->>'accountingFormat'='agent-resources/1' AND reg.revision IS NOT NULL
  AND NEW.request_digest=expected AND w.reserved=units
  AND NEW.timeout_ms<=(q.policy->>'requestTimeoutMs')::bigint
  AND NEW.created_at<=clock_timestamp() AND NEW.expires_at=NEW.created_at+((reg.payload->'application'->>'retentionDays')::bigint*interval '1 day')
  AND NOT EXISTS(SELECT 1 FROM os_artifacts WHERE id=NEW.artifact_id)
  AND w.request_digest=os_agent_resource_digest('command',jsonb_build_object('schema','agent-resource-reservation/1',
   'taskId',NEW.task_id,'segmentId',NEW.segment_id,'epoch',NEW.control_epoch,'invocationId',NEW.id,
   'kind','agent.storage','inputDigest',expected,'units',units,'timeoutMs',NEW.timeout_ms)),false)
  THEN RAISE EXCEPTION 'agent_payload_write_binding'; END IF;
 PERFORM os_assert_agent_work_current(w);
 PERFORM os_agent_resource_owner(q);
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_payload_write BEFORE INSERT OR UPDATE OR DELETE ON os_agent_payload_writes
FOR EACH ROW EXECUTE FUNCTION os_guard_agent_payload_write();

CREATE FUNCTION os_guard_agent_private_payload() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE p os_agent_payload_writes%ROWTYPE; w os_work_attempts%ROWTYPE; a os_artifacts%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_private_payload_immutable'; END IF;
 SELECT * INTO p FROM os_agent_payload_writes WHERE id=NEW.write_id;
 SELECT * INTO w FROM os_work_attempts WHERE id=p.attempt_id;
 SELECT * INTO a FROM os_artifacts WHERE id=NEW.id;
 IF NOT COALESCE(p.id IS NOT NULL AND p.artifact_id=NEW.id AND p.root_id=NEW.root_id
  AND w.state='SETTLED' AND w.kind='agent.storage' AND w.accounting_format='agent-resources/1'
  AND (w.actual->>'storageBytes')::bigint=NEW.stored_bytes
  AND (w.actual->>'workMs')::bigint>=1 AND (w.actual->>'computeMs')::bigint>=1
  AND a.id IS NOT NULL AND a.purpose='artifact' AND a.classification='protected'
  AND a.ciphertext_digest=NEW.ciphertext_digest AND a.expires_at=p.expires_at
  AND NEW.created_at>=p.created_at AND NEW.created_at<=clock_timestamp(),false)
  THEN RAISE EXCEPTION 'agent_private_payload_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_private_payload BEFORE INSERT OR UPDATE OR DELETE ON os_agent_private_payloads
FOR EACH ROW EXECUTE FUNCTION os_guard_agent_private_payload();
"""


def upgrade():
    op.execute(TABLES)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Private payload storage requires protected forward recovery')
