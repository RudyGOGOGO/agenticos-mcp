"""Version immutable dispatch intent; never reinterpret old transport histories."""
from alembic import op
import sqlalchemy as sa
revision='os_pg_0008'
down_revision='os_pg_0007'
branch_labels=None
depends_on=None


def upgrade():
    op.add_column('os_dispatches',sa.Column('workflow_profile',sa.String(64),nullable=False,
        server_default='OSAdmissionTransport/1'))
    op.create_check_constraint('ck_dispatch_profile','os_dispatches',
        "workflow_profile IN ('OSAdmissionTransport/1','OSTaskDriver/1')")
    fields=['installation_id','application_id','tenant_id','subject_id','id','command_id',
        'task_id','workflow_id','workflow_profile']
    args=','.join("'"+field+"'" for field in fields)
    op.execute('CREATE TRIGGER immutable_os_dispatches BEFORE UPDATE OR DELETE '
        'ON os_dispatches FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('+args+')')


def downgrade():
    raise RuntimeError('Destructive downgrade refused; use tested fresh recovery')
