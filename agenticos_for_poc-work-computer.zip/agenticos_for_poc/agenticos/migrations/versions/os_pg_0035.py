"""Finite source-bound jobs and private governed extraction candidates."""
from alembic import op

revision = "os_pg_0035"
down_revision = "os_pg_0034"
branch_labels = None
depends_on = None


def upgrade():
    for statement in TABLES:
        op.get_bind().exec_driver_sql(statement)
    op.execute(GUARDS)


TABLES = (
    """
CREATE TABLE personal_learning_jobs (
    id UUID NOT NULL,
    settings_id UUID NOT NULL,
    learning_epoch BIGINT NOT NULL,
    application_revision BIGINT NOT NULL,
    application_generation BIGINT NOT NULL,
    subject_generation BIGINT NOT NULL,
    policy_generation BIGINT NOT NULL,
    profile_ref VARCHAR(64) NOT NULL,
    prompt_ref VARCHAR(64) NOT NULL,
    budget JSONB NOT NULL,
    source_mac VARCHAR(64) NOT NULL,
    mac_key_id UUID NOT NULL,
    state VARCHAR(32) NOT NULL,
    version BIGINT NOT NULL,
    run_id UUID,
    lease_id UUID,
    lease_until TIMESTAMP WITH TIME ZONE,
    account_checked_at TIMESTAMP WITH TIME ZONE NOT NULL,
    account_valid_until TIMESTAMP WITH TIME ZONE NOT NULL,
    provider_started BOOLEAN NOT NULL,
    usage JSONB,
    result_count BIGINT NOT NULL,
    error_code VARCHAR(32),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    installation_id UUID NOT NULL,
    application_id UUID NOT NULL,
    tenant_id VARCHAR(256) NOT NULL,
    subject_id VARCHAR(256) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_learning_job_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_learning_settings_settings_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, settings_id) REFERENCES personal_learning_settings (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT uq_learning_job_range UNIQUE (installation_id, application_id, tenant_id, subject_id, source_mac, learning_epoch, profile_ref),
    CONSTRAINT ck_learning_job_versions CHECK (learning_epoch>0 AND application_revision>0 AND application_generation>0 AND subject_generation>0 AND policy_generation>0 AND version>0 AND result_count BETWEEN 0 AND 8),
    CONSTRAINT ck_learning_job_profile CHECK (profile_ref='synthetic-staging/1' AND prompt_ref='mem0-2.2.1-owner-source/1' AND source_mac ~ '^[a-f0-9]{64}$'),
    CONSTRAINT ck_learning_job_budget CHECK (budget=jsonb_build_object('providerCalls',1,'inputTokens',16384,'outputTokens',2048,'costMicros',100000,'sourceChars',8000,'candidates',8,'cpuSeconds',10,'wallSeconds',30,'rssBytes',536870912)),
    CONSTRAINT ck_learning_job_state CHECK (state IN ('QUEUED','RUNNING','SUCCEEDED','FAILED','CANCELLED','OUTCOME_UNKNOWN') AND ((lease_id IS NULL AND lease_until IS NULL) OR (lease_id IS NOT NULL AND lease_until IS NOT NULL)) AND (usage IS NULL OR provider_started)),
    CONSTRAINT ck_learning_job_time CHECK (updated_at>=created_at AND expires_at>created_at AND expires_at<=created_at+interval '5 minutes' AND account_valid_until>account_checked_at AND account_valid_until<=account_checked_at+interval '15 seconds'),
    CONSTRAINT ck_learning_job_usage CHECK (usage IS NULL OR COALESCE(usage=jsonb_build_object('inputTokens',usage->'inputTokens','outputTokens',usage->'outputTokens','costMicros',usage->'costMicros') AND jsonb_typeof(usage->'inputTokens')='number' AND jsonb_typeof(usage->'outputTokens')='number' AND jsonb_typeof(usage->'costMicros')='number' AND usage->>'inputTokens' ~ '^[0-9]+$' AND usage->>'outputTokens' ~ '^[0-9]+$' AND usage->>'costMicros' ~ '^[0-9]+$' AND (usage->>'inputTokens')::numeric BETWEEN 0 AND 9007199254740991 AND (usage->>'outputTokens')::numeric BETWEEN 0 AND 9007199254740991 AND (usage->>'costMicros')::numeric BETWEEN 0 AND 9007199254740991,false))
)
    """,
    """
CREATE INDEX ix_learning_job_due ON personal_learning_jobs (state, expires_at)
    """,
    """
CREATE UNIQUE INDEX uq_learning_job_inflight ON personal_learning_jobs (installation_id, application_id, tenant_id, subject_id) WHERE state IN ('QUEUED','RUNNING','OUTCOME_UNKNOWN')
    """,
    """
CREATE TABLE personal_learning_job_sources (
    id UUID NOT NULL,
    job_id UUID NOT NULL,
    source_id UUID NOT NULL,
    intent_id UUID NOT NULL,
    source_revision BIGINT NOT NULL,
    ordinal BIGINT NOT NULL,
    installation_id UUID NOT NULL,
    application_id UUID NOT NULL,
    tenant_id VARCHAR(256) NOT NULL,
    subject_id VARCHAR(256) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_learning_job_source_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_learning_jobs_job_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, job_id) REFERENCES personal_learning_jobs (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_learning_sources_source_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_id) REFERENCES personal_learning_sources (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_learning_source_intents_intent_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, intent_id) REFERENCES personal_learning_source_intents (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT uq_learning_job_source_once UNIQUE (installation_id, application_id, tenant_id, subject_id, source_id),
    CONSTRAINT uq_learning_job_source_order UNIQUE (installation_id, application_id, tenant_id, subject_id, job_id, ordinal),
    CONSTRAINT ck_learning_job_source_versions CHECK (source_revision=1 AND ordinal BETWEEN 1 AND 20)
)
    """,
    """
CREATE TABLE personal_knowledge_candidates (
    id UUID NOT NULL,
    job_id UUID NOT NULL,
    ordinal BIGINT NOT NULL,
    version BIGINT NOT NULL,
    state VARCHAR(16) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    installation_id UUID NOT NULL,
    application_id UUID NOT NULL,
    tenant_id VARCHAR(256) NOT NULL,
    subject_id VARCHAR(256) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_knowledge_candidate_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_learning_jobs_job_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, job_id) REFERENCES personal_learning_jobs (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT uq_knowledge_candidate_result UNIQUE (installation_id, application_id, tenant_id, subject_id, job_id, ordinal),
    CONSTRAINT ck_knowledge_candidate_versions CHECK (ordinal BETWEEN 1 AND 8 AND version BETWEEN 1 AND 64),
    CONSTRAINT ck_knowledge_candidate_state CHECK (state IN ('PENDING_REVIEW','ACCEPTED','REJECTED','EXPIRED','INVALIDATED')),
    CONSTRAINT ck_knowledge_candidate_time CHECK (updated_at>=created_at AND expires_at>created_at AND expires_at<=created_at+interval '1 day')
)
    """,
    """
CREATE TABLE personal_knowledge_candidate_revisions (
    id UUID NOT NULL,
    candidate_id UUID NOT NULL,
    ordinal BIGINT NOT NULL,
    envelope JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    installation_id UUID NOT NULL,
    application_id UUID NOT NULL,
    tenant_id VARCHAR(256) NOT NULL,
    subject_id VARCHAR(256) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_knowledge_candidate_revision_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_candidates_candidate_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_id) REFERENCES personal_knowledge_candidates (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT uq_knowledge_candidate_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, candidate_id, ordinal),
    CONSTRAINT ck_knowledge_candidate_revision_version CHECK (ordinal BETWEEN 1 AND 64),
    CONSTRAINT ck_knowledge_candidate_envelope CHECK (envelope IS NULL OR COALESCE(envelope=jsonb_build_object('version',1,'keyId',envelope->'keyId','nonce',envelope->'nonce','ciphertext',envelope->'ciphertext') AND jsonb_typeof(envelope->'keyId')='string' AND envelope->>'keyId' ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' AND jsonb_typeof(envelope->'nonce')='string' AND length(envelope->>'nonce')=16 AND jsonb_typeof(envelope->'ciphertext')='string' AND length(envelope->>'ciphertext') BETWEEN 24 AND 64000,false))
)
    """,
    """
CREATE TABLE personal_knowledge_candidate_sources (
    id UUID NOT NULL,
    candidate_id UUID NOT NULL,
    source_id UUID NOT NULL,
    source_revision BIGINT NOT NULL,
    installation_id UUID NOT NULL,
    application_id UUID NOT NULL,
    tenant_id VARCHAR(256) NOT NULL,
    subject_id VARCHAR(256) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_knowledge_candidate_source_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_candidates_candidate_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_id) REFERENCES personal_knowledge_candidates (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_learning_sources_source_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_id) REFERENCES personal_learning_sources (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT uq_knowledge_candidate_source UNIQUE (installation_id, application_id, tenant_id, subject_id, candidate_id, source_id),
    CONSTRAINT ck_knowledge_candidate_source_version CHECK (source_revision=1)
)
    """,
)

GUARDS = r"""
CREATE FUNCTION os_assert_learning_job_live(j personal_learning_jobs) RETURNS void LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=j.installation_id AND id=j.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=j.installation_id AND application_id=j.application_id
  AND tenant_id=j.tenant_id AND subject_id=j.subject_id;
 IF s.id IS NULL OR s.learning_epoch<>j.learning_epoch OR s.choice->'learnConversation' IS DISTINCT FROM 'true'::jsonb
  OR s.choice->>'extractorProfile'<>j.profile_ref OR app.id IS NULL OR NOT app.active OR owner.id IS NULL OR NOT owner.active
  OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
  OR j.expires_at<=clock_timestamp() OR j.account_valid_until<=clock_timestamp()
  OR j.account_checked_at<clock_timestamp()-interval '5 seconds'
  OR j.account_checked_at>clock_timestamp()+interval '5 seconds'
  OR NOT EXISTS(SELECT 1 FROM personal_learning_job_sources WHERE job_id=j.id)
  OR EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id
   JOIN personal_learning_source_intents i ON i.id=e.intent_id WHERE e.job_id=j.id
    AND (r.settings_id<>j.settings_id OR r.state<>'AVAILABLE' OR r.revision<>e.source_revision
     OR r.learning_epoch<>j.learning_epoch OR r.expires_at<=clock_timestamp() OR r.envelope IS NULL
     OR i.source_id<>r.id OR i.learning_epoch<>j.learning_epoch OR i.state<>'PENDING_DISPATCH'
     OR i.extractor_ref<>j.profile_ref OR i.due_at>j.created_at))
 THEN RAISE EXCEPTION 'learning_job_current_authority'; END IF;
END $$;

CREATE FUNCTION os_guard_learning_job() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_job_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'QUEUED' OR NEW.version<>1 OR NEW.run_id IS NOT NULL OR NEW.lease_id IS NOT NULL
   OR NEW.provider_started OR NEW.usage IS NOT NULL OR NEW.result_count<>0 OR NEW.error_code IS NOT NULL
   OR NEW.created_at<>NEW.updated_at THEN RAISE EXCEPTION 'learning_job_initial'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['state','version','run_id','lease_id','lease_until','account_checked_at','account_valid_until',
       'provider_started','usage','result_count','error_code','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['state','version','run_id','lease_id','lease_until','account_checked_at','account_valid_until',
       'provider_started','usage','result_count','error_code','updated_at'])
   OR NEW.version<>OLD.version+1 OR NEW.updated_at<OLD.updated_at
   OR (OLD.run_id IS NOT NULL AND NEW.run_id IS DISTINCT FROM OLD.run_id)
   OR (OLD.provider_started AND NOT NEW.provider_started)
   OR (OLD.usage IS NOT NULL AND NEW.usage IS DISTINCT FROM OLD.usage)
   OR (NOT NEW.provider_started AND NEW.usage IS NOT NULL)
  THEN RAISE EXCEPTION 'learning_job_immutable_input_accounting'; END IF;
  IF OLD.state='QUEUED' THEN
   IF NEW.state NOT IN ('QUEUED','RUNNING','CANCELLED') OR NEW.provider_started OR NEW.usage IS NOT NULL
    OR NEW.result_count<>0 THEN RAISE EXCEPTION 'learning_job_queue_transition'; END IF;
   IF NEW.state='RUNNING' THEN
    IF NEW.lease_id IS NULL OR NEW.lease_until<=clock_timestamp()
     OR NEW.lease_until>clock_timestamp()+interval '45 seconds' OR NEW.lease_until>NEW.expires_at
    THEN RAISE EXCEPTION 'learning_job_finite_lease'; END IF;
   ELSIF NEW.lease_id IS NOT NULL THEN RAISE EXCEPTION 'learning_job_queue_lease'; END IF;
  ELSIF OLD.state='RUNNING' THEN
   IF NEW.state NOT IN ('RUNNING','SUCCEEDED','FAILED','CANCELLED','OUTCOME_UNKNOWN')
    OR ROW(NEW.lease_id,NEW.lease_until) IS DISTINCT FROM ROW(OLD.lease_id,OLD.lease_until)
    OR (NEW.state='SUCCEEDED' AND (NOT NEW.provider_started OR NEW.usage IS NULL OR NEW.error_code IS NOT NULL))
    OR (NEW.state='OUTCOME_UNKNOWN' AND (NOT NEW.provider_started OR NEW.usage IS NOT NULL))
    OR (NEW.state IN ('FAILED','CANCELLED') AND NEW.provider_started AND NEW.usage IS NULL)
    OR (NEW.state<>'SUCCEEDED' AND NEW.result_count<>0)
   THEN RAISE EXCEPTION 'learning_job_running_transition'; END IF;
  ELSE
   -- A late, matching Temporal acknowledgement may bind the same completed
   -- launch. It cannot restart work, change usage or renew any authority.
   IF OLD.run_id IS NOT NULL OR NEW.run_id IS NULL
    OR (to_jsonb(NEW)-ARRAY['run_id','version','updated_at']) IS DISTINCT FROM
       (to_jsonb(OLD)-ARRAY['run_id','version','updated_at'])
   THEN RAISE EXCEPTION 'learning_job_terminal'; END IF;
  END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_learning_job BEFORE INSERT OR UPDATE OR DELETE ON personal_learning_jobs
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_job();

CREATE FUNCTION os_guard_learning_edge_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'learning_edge_immutable'; END $$;
CREATE TRIGGER immutable_learning_job_source BEFORE UPDATE OR DELETE ON personal_learning_job_sources
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_edge_immutable();
CREATE TRIGGER immutable_learning_candidate_source BEFORE UPDATE OR DELETE ON personal_knowledge_candidate_sources
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_edge_immutable();

CREATE FUNCTION os_guard_learning_job_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE j personal_learning_jobs%ROWTYPE; n bigint; sources bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_learning_jobs' THEN j=NEW;
 ELSE SELECT * INTO j FROM personal_learning_jobs WHERE id=NEW.job_id; END IF;
 SELECT count(*),max(ordinal) INTO n,sources FROM personal_learning_job_sources WHERE job_id=j.id;
 IF j.id IS NULL OR n NOT BETWEEN 1 AND 20 OR sources<>n
  OR EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_source_intents i ON i.id=e.intent_id
   WHERE e.job_id=j.id AND i.source_id<>e.source_id)
 THEN RAISE EXCEPTION 'learning_job_atomic_range'; END IF;
 IF TG_TABLE_NAME='personal_learning_job_sources' THEN
  IF j.state<>'QUEUED' OR j.version<>1 THEN RAISE EXCEPTION 'learning_job_late_range'; END IF;
  PERFORM os_assert_learning_job_live(j);
 ELSIF TG_OP='INSERT' THEN PERFORM os_assert_learning_job_live(j);
 ELSE
  IF NEW.state='RUNNING' AND (OLD.state='QUEUED' OR NOT OLD.provider_started AND NEW.provider_started)
   OR OLD.state='RUNNING' AND NEW.state='SUCCEEDED'
  THEN
   PERFORM os_assert_learning_job_live(j);
   IF j.lease_until<=clock_timestamp() THEN RAISE EXCEPTION 'learning_job_expired_lease'; END IF;
  END IF;
 END IF;
 SELECT count(*) INTO n FROM personal_knowledge_candidates WHERE job_id=j.id;
 IF (j.state='SUCCEEDED' AND n<>j.result_count) OR (j.state<>'SUCCEEDED' AND n<>0)
 THEN RAISE EXCEPTION 'learning_job_atomic_result'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_learning_job AFTER INSERT OR UPDATE ON personal_learning_jobs
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_job_commit();
CREATE CONSTRAINT TRIGGER commit_learning_job_source AFTER INSERT ON personal_learning_job_sources
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_job_commit();

CREATE FUNCTION os_learning_candidate_invalid(cid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e JOIN personal_learning_sources s ON s.id=e.source_id
  WHERE e.candidate_id=cid AND (s.state<>'AVAILABLE' OR s.revision<>e.source_revision OR s.expires_at<=clock_timestamp()))
$$;

CREATE FUNCTION os_guard_learning_candidate() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_candidate_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'PENDING_REVIEW' OR NEW.version<>1 OR NEW.created_at<>NEW.updated_at
  THEN RAISE EXCEPTION 'learning_candidate_initial'; END IF;
 ELSE
  IF OLD.state<>'PENDING_REVIEW' OR NEW.state<>'INVALIDATED' OR NEW.version<>OLD.version
   OR NOT os_learning_candidate_invalid(OLD.id)
   OR (to_jsonb(NEW)-ARRAY['state','updated_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','updated_at'])
   OR NEW.updated_at<OLD.updated_at
  THEN RAISE EXCEPTION 'learning_candidate_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_learning_candidate BEFORE INSERT OR UPDATE OR DELETE ON personal_knowledge_candidates
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_candidate();

CREATE FUNCTION os_guard_learning_candidate_revision() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_candidate_revision_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.ordinal<>1 OR NEW.envelope IS NULL THEN RAISE EXCEPTION 'learning_candidate_revision_initial'; END IF;
 ELSE
  IF OLD.envelope IS NULL OR NEW.envelope IS NOT NULL OR NOT os_learning_candidate_invalid(OLD.candidate_id)
   OR (to_jsonb(NEW)-'envelope') IS DISTINCT FROM (to_jsonb(OLD)-'envelope')
  THEN RAISE EXCEPTION 'learning_candidate_revision_immutable'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_learning_candidate_revision BEFORE INSERT OR UPDATE OR DELETE ON personal_knowledge_candidate_revisions
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_candidate_revision();

CREATE FUNCTION os_guard_learning_candidate_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid; c personal_knowledge_candidates%ROWTYPE; j personal_learning_jobs%ROWTYPE; n bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_knowledge_candidates' THEN cid=NEW.id; ELSE cid=NEW.candidate_id; END IF;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=cid;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT count(*) INTO n FROM personal_knowledge_candidate_sources WHERE candidate_id=cid;
 IF c.id IS NULL OR j.state<>'SUCCEEDED' OR c.ordinal>j.result_count OR n NOT BETWEEN 1 AND 20
  OR NOT EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND ordinal=c.version)
  OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e WHERE e.candidate_id=cid AND NOT EXISTS(
    SELECT 1 FROM personal_learning_job_sources r WHERE r.job_id=j.id AND r.source_id=e.source_id
     AND r.source_revision=e.source_revision))
 THEN RAISE EXCEPTION 'learning_candidate_atomic_provenance'; END IF;
 IF TG_OP='INSERT' THEN
  IF c.state<>'PENDING_REVIEW' OR c.version<>1 OR c.created_at<>j.updated_at
   OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL)
  THEN RAISE EXCEPTION 'learning_candidate_result_binding'; END IF;
  PERFORM os_assert_learning_job_live(j);
 ELSE
  IF c.state<>'INVALIDATED' OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
  THEN RAISE EXCEPTION 'learning_candidate_cleanup_incomplete'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_learning_candidate AFTER INSERT OR UPDATE ON personal_knowledge_candidates
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_candidate_commit();
CREATE CONSTRAINT TRIGGER commit_learning_candidate_revision AFTER INSERT OR UPDATE ON personal_knowledge_candidate_revisions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_candidate_commit();
CREATE CONSTRAINT TRIGGER commit_learning_candidate_source AFTER INSERT ON personal_knowledge_candidate_sources
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_candidate_commit();
"""

def downgrade():
    raise RuntimeError("Owned populated data requires protected forward recovery")
