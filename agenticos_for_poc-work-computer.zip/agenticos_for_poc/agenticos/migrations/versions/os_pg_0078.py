"""Apply planned-analysis completion checks only to their admitted profile."""
from alembic import op

revision='os_pg_0078'
down_revision='os_pg_0077'
branch_labels=None
depends_on=None

GUARDS=r"""
CREATE OR REPLACE FUNCTION os_check_agent_plan_completion() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; h os_agent_plan_heads%ROWTYPE;
BEGIN
 IF NEW.state<>'COMPLETED' OR OLD.state='COMPLETED' THEN RETURN NULL; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_admissions WHERE task_id=NEW.id;
 IF NOT COALESCE(a.context->'harness'->>'ref' LIKE 'adaptive-analysis-planned/%',false) THEN RETURN NULL; END IF;
 SELECT * INTO h FROM os_agent_plan_heads WHERE task_id=NEW.id;
 IF h.revision IS NULL OR h.revision=0 OR EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE head_id=h.id AND state NOT IN ('ACCEPTED','CANCELLED'))
  OR NOT EXISTS(SELECT 1 FROM os_agent_plan_nodes WHERE id=h.final_node_id AND state='ACCEPTED')
  OR NOT EXISTS(SELECT 1 FROM os_agent_payload_writes w JOIN os_agent_private_payloads p ON p.write_id=w.id
   JOIN os_work_attempts work ON work.id=w.attempt_id WHERE w.task_id=NEW.id AND w.root_id=h.root_id
    AND w.schema_ref='AgentPlannedAnalysisVerification' AND work.state='SETTLED' AND w.expires_at>clock_timestamp())
  THEN RAISE EXCEPTION 'agent_plan_completion_incomplete'; END IF;
 RETURN NULL;
END $$;
"""


def upgrade():
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Completion dispatch requires protected forward recovery')
