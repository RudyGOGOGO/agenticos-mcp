"""Immutable scoped per-segment read authority; no write lane activation."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision='os_pg_0009'
down_revision='os_pg_0008'
branch_labels=None
depends_on=None

def upgrade():
    # Frozen additive DDL, independent of future ORM definitions.
    op.create_table('os_execution_grants',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('task_id', sa.UUID(), nullable=False),
    sa.Column('segment_id', sa.UUID(), nullable=False),
    sa.Column('root_id', sa.UUID(), nullable=False),
    sa.Column('admission_id', sa.UUID(), nullable=False),
    sa.Column('control_epoch', sa.BigInteger(), nullable=False),
    sa.Column('contract_ref', sa.String(length=64), nullable=False),
    sa.Column('request_digest', sa.String(length=64), nullable=False),
    sa.Column('digest', sa.String(length=64), nullable=False),
    sa.Column('payload', postgresql.JSONB(astext_type=sa.Text()), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('installation_id', sa.UUID(), nullable=False),
    sa.Column('application_id', sa.UUID(), nullable=False),
    sa.Column('tenant_id', sa.String(length=256), nullable=False),
    sa.Column('subject_id', sa.String(length=256), nullable=False),
    sa.CheckConstraint("contract_ref='InteractiveExecutionGrant'", name='ck_grant_contract'),
    sa.CheckConstraint("control_epoch>0 AND expires_at>created_at AND expires_at<=created_at+interval '5 minutes'", name='ck_grant_expiry'),
    sa.CheckConstraint("digest ~ '^[a-f0-9]{64}$'", name='ck_grant_digest'),
    sa.CheckConstraint("jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536", name='ck_grant_payload'),
    sa.CheckConstraint("request_digest ~ '^[a-f0-9]{64}$'", name='ck_grant_request_digest'),
    sa.ForeignKeyConstraint(['installation_id', 'application_id', 'tenant_id', 'subject_id', 'admission_id', 'task_id'], ['os_admissions.installation_id', 'os_admissions.application_id', 'os_admissions.tenant_id', 'os_admissions.subject_id', 'os_admissions.id', 'os_admissions.task_id'], name='fk_grant_admission'),
    sa.ForeignKeyConstraint(['installation_id', 'application_id', 'tenant_id', 'subject_id', 'root_id'], ['os_budget_roots.installation_id', 'os_budget_roots.application_id', 'os_budget_roots.tenant_id', 'os_budget_roots.subject_id', 'os_budget_roots.id'], name='fk_os_budget_roots_root_id'),
    sa.ForeignKeyConstraint(['installation_id', 'application_id', 'tenant_id', 'subject_id', 'segment_id', 'task_id'], ['os_segments.installation_id', 'os_segments.application_id', 'os_segments.tenant_id', 'os_segments.subject_id', 'os_segments.id', 'os_segments.task_id'], name='fk_grant_segment'),
    sa.ForeignKeyConstraint(['installation_id', 'application_id', 'tenant_id', 'subject_id', 'task_id', 'root_id'], ['os_workload_bindings.installation_id', 'os_workload_bindings.application_id', 'os_workload_bindings.tenant_id', 'os_workload_bindings.subject_id', 'os_workload_bindings.task_id', 'os_workload_bindings.root_id'], name='fk_grant_binding'),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('installation_id', 'application_id', 'tenant_id', 'subject_id', 'id', name='uq_execution_grant_owner_id')
    )
    op.create_index('ix_grant_owner_expiry', 'os_execution_grants', ['installation_id', 'application_id', 'tenant_id', 'subject_id', 'expires_at'], unique=False)
    op.create_table('os_execution_grant_revocations',
    sa.Column('id', sa.UUID(), nullable=False),
    sa.Column('grant_id', sa.UUID(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reason_code', sa.String(length=64), nullable=False),
    sa.Column('installation_id', sa.UUID(), nullable=False),
    sa.Column('application_id', sa.UUID(), nullable=False),
    sa.Column('tenant_id', sa.String(length=256), nullable=False),
    sa.Column('subject_id', sa.String(length=256), nullable=False),
    sa.CheckConstraint("reason_code='OWNER_REVOKED'", name='ck_grant_revocation_reason'),
    sa.ForeignKeyConstraint(['installation_id', 'application_id', 'tenant_id', 'subject_id', 'grant_id'], ['os_execution_grants.installation_id', 'os_execution_grants.application_id', 'os_execution_grants.tenant_id', 'os_execution_grants.subject_id', 'os_execution_grants.id'], name='fk_os_execution_grants_grant_id'),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('installation_id', 'application_id', 'tenant_id', 'subject_id', 'grant_id', name='uq_grant_revocation'),
    sa.UniqueConstraint('installation_id', 'application_id', 'tenant_id', 'subject_id', 'id', name='uq_execution_grant_revocation_owner_id')
    )
    # ### end Alembic commands ###
    immutable_guards()


def immutable_guards():
    op.execute("CREATE TRIGGER immutable_os_execution_grants BEFORE UPDATE OR DELETE ON os_execution_grants FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','task_id','segment_id','root_id','admission_id','control_epoch','contract_ref','request_digest','digest','payload','created_at','expires_at','installation_id','application_id','tenant_id','subject_id')")
    op.execute("CREATE TRIGGER immutable_os_execution_grant_revocations BEFORE UPDATE OR DELETE ON os_execution_grant_revocations FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('id','grant_id','created_at','reason_code','installation_id','application_id','tenant_id','subject_id')")


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use tested fresh recovery")
