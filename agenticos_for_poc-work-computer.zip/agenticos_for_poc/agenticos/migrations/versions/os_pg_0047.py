"""Atomic owner forgetting and application-pinned surviving recovery watermarks."""
from alembic import op

revision = 'os_pg_0047'
down_revision = 'os_pg_0046'
branch_labels = None
depends_on = None

TABLES = ("\nCREATE TABLE memory_recovery_profiles (\n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\tjournal_id UUID NOT NULL, \n\tkey_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tPRIMARY KEY (installation_id, application_id), \n\tCONSTRAINT fk_memory_recovery_application FOREIGN KEY(installation_id, application_id) REFERENCES os_applications (installation_id, id), \n\tCONSTRAINT uq_memory_recovery_profile UNIQUE (installation_id, application_id, journal_id), \n\tCONSTRAINT uq_memory_recovery_journal UNIQUE (installation_id, journal_id), \n\tCONSTRAINT ck_memory_recovery_key_digest CHECK (key_digest ~ '^[a-f0-9]{64}$')\n)\n\n", '\nCREATE TABLE memory_recovery_owners (\n\tsettings_id UUID NOT NULL, \n\tjournal_id UUID NOT NULL, \n\tsequence BIGINT NOT NULL, \n\towner_epoch BIGINT NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tupdated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (settings_id), \n\tCONSTRAINT fk_personal_learning_settings_settings_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, settings_id) REFERENCES personal_learning_settings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_memory_recovery_owner UNIQUE (installation_id, application_id, tenant_id, subject_id, settings_id), \n\tCONSTRAINT fk_memory_recovery_owner_profile FOREIGN KEY(installation_id, application_id, journal_id) REFERENCES memory_recovery_profiles (installation_id, application_id, journal_id), \n\tCONSTRAINT ck_memory_recovery_owner_bounds CHECK (sequence>=0 AND owner_epoch>0 AND updated_at>=created_at)\n)\n\n', "\nCREATE TABLE memory_forget_batches (\n\tid UUID NOT NULL, \n\tsettings_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tkind VARCHAR(16) NOT NULL, \n\texpected_version BIGINT NOT NULL, \n\taccepted_version BIGINT NOT NULL, \n\tprior_learning_epoch BIGINT NOT NULL, \n\tlearning_epoch BIGINT NOT NULL, \n\tprior_recall_epoch BIGINT NOT NULL, \n\trecall_epoch BIGINT NOT NULL, \n\tprior_context_revision BIGINT NOT NULL, \n\tcontext_revision BIGINT NOT NULL, \n\tindex_generation BIGINT NOT NULL, \n\tjournal_id UUID NOT NULL, \n\tprior_journal_sequence BIGINT NOT NULL, \n\tjournal_sequence BIGINT NOT NULL, \n\tprior_owner_epoch BIGINT NOT NULL, \n\towner_epoch BIGINT NOT NULL, \n\trequest_mac VARCHAR(64) NOT NULL, \n\trequest JSONB NOT NULL, \n\treceipt JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tcompleted_at TIMESTAMP WITH TIME ZONE, \n\tcleanup_session_id UUID, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_memory_forget_batch_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_learning_settings_settings_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, settings_id) REFERENCES personal_learning_settings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_cleanup_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, cleanup_session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_memory_forget_batch_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT uq_memory_forget_batch_sequence UNIQUE (installation_id, application_id, tenant_id, subject_id, journal_sequence), \n\tCONSTRAINT fk_memory_forget_batch_profile FOREIGN KEY(installation_id, application_id, journal_id) REFERENCES memory_recovery_profiles (installation_id, application_id, journal_id), \n\tCONSTRAINT ck_memory_forget_batch_epochs CHECK (kind IN ('all','entry','source') AND expected_version>0 AND prior_learning_epoch>0 AND prior_recall_epoch>0 AND prior_context_revision>0 AND index_generation>0 AND prior_journal_sequence>=0 AND journal_sequence>prior_journal_sequence AND prior_owner_epoch>0 AND ((kind='all' AND accepted_version=expected_version+1 AND learning_epoch=prior_learning_epoch+1 AND recall_epoch=prior_recall_epoch+1 AND context_revision=prior_context_revision+1 AND owner_epoch=prior_owner_epoch+1) OR (kind<>'all' AND accepted_version=expected_version AND learning_epoch=prior_learning_epoch AND recall_epoch=prior_recall_epoch AND context_revision=prior_context_revision+(CASE WHEN kind='entry' THEN 1 ELSE 0 END) AND owner_epoch=prior_owner_epoch))), \n\tCONSTRAINT ck_memory_forget_batch_digest CHECK (request_mac ~ '^[a-f0-9]{64}$'), \n\tCONSTRAINT ck_memory_forget_batch_metadata CHECK (jsonb_typeof(request)='object' AND jsonb_typeof(receipt)='object' AND octet_length(request::text)<=32768 AND octet_length(receipt::text)<=8192), \n\tCONSTRAINT ck_memory_forget_batch_cleanup CHECK ((completed_at IS NULL AND cleanup_session_id IS NULL) OR (completed_at IS NOT NULL AND cleanup_session_id IS NOT NULL AND completed_at>=created_at))\n)\n\n", '\nCREATE TABLE memory_forget_entries (\n\tbatch_id UUID NOT NULL, \n\tentry_id UUID NOT NULL, \n\toperation_id UUID NOT NULL, \n\texpected_version BIGINT NOT NULL, \n\taccepted_version BIGINT NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (batch_id, entry_id), \n\tCONSTRAINT fk_memory_forget_batches_batch_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, batch_id) REFERENCES memory_forget_batches (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_operations_operation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, operation_id) REFERENCES personal_knowledge_operations (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_memory_forget_entry_operation UNIQUE (installation_id, application_id, tenant_id, subject_id, operation_id), \n\tCONSTRAINT ck_memory_forget_entry_version CHECK (expected_version>0 AND accepted_version=expected_version+1)\n)\n\n', '\nCREATE TABLE memory_forget_sources (\n\tbatch_id UUID NOT NULL, \n\tsource_id UUID NOT NULL, \n\tforget_id UUID NOT NULL, \n\texpected_version BIGINT NOT NULL, \n\taccepted_version BIGINT NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (batch_id, source_id), \n\tCONSTRAINT fk_memory_forget_batches_batch_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, batch_id) REFERENCES memory_forget_batches (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_learning_sources_source_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_id) REFERENCES personal_learning_sources (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_learning_source_forgets_forget_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, forget_id) REFERENCES personal_learning_source_forgets (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_memory_forget_source_receipt UNIQUE (installation_id, application_id, tenant_id, subject_id, forget_id), \n\tCONSTRAINT ck_memory_forget_source_version CHECK (expected_version=1 AND accepted_version=2)\n)\n\n', '\nCREATE TABLE memory_forget_contexts (\n\tbatch_id UUID NOT NULL, \n\tcontext_id UUID NOT NULL, \n\texpected_version BIGINT NOT NULL, \n\taccepted_version BIGINT NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (batch_id, context_id), \n\tCONSTRAINT fk_memory_forget_batches_batch_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, batch_id) REFERENCES memory_forget_batches (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_owner_memory_contexts_context_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, context_id) REFERENCES owner_memory_contexts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_memory_forget_context_once UNIQUE (installation_id, application_id, tenant_id, subject_id, context_id), \n\tCONSTRAINT ck_memory_forget_context_version CHECK (expected_version BETWEEN 1 AND 32 AND accepted_version=expected_version+1)\n)\n\n', 'ALTER TABLE personal_knowledge_operations ADD COLUMN forget_batch_id UUID', "ALTER TABLE personal_knowledge_operations ADD CONSTRAINT ck_knowledge_operation_forget_batch CHECK (forget_batch_id IS NULL OR kind='FORGET')", 'ALTER TABLE personal_knowledge_operations ADD CONSTRAINT fk_memory_forget_batches_forget_batch_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, forget_batch_id) REFERENCES memory_forget_batches (installation_id, application_id, tenant_id, subject_id, id)', 'ALTER TABLE personal_knowledge_operations DROP CONSTRAINT uq_knowledge_operation_context', 'CREATE UNIQUE INDEX uq_knowledge_operation_context ON personal_knowledge_operations (installation_id, application_id, tenant_id, subject_id, context_revision) WHERE forget_batch_id IS NULL', 'ALTER TABLE owner_memory_contexts DROP CONSTRAINT ck_owner_memory_context_version_time', "ALTER TABLE owner_memory_contexts ADD CONSTRAINT ck_owner_memory_context_version_time CHECK ((version BETWEEN 1 AND 32 OR (version=33 AND state='FORGOTTEN')) AND context_revision>1 AND updated_at>=created_at)")

GUARDS = r"""
CREATE FUNCTION os_assert_memory_forget_batch(bid uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE b memory_forget_batches%ROWTYPE; s personal_learning_settings%ROWTYPE; watermark memory_recovery_owners%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
 entry_refs jsonb; source_refs jsonb; context_refs jsonb; ne bigint; ns bigint; nc bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO b FROM memory_forget_batches WHERE id=bid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=b.settings_id;
 SELECT * INTO watermark FROM memory_recovery_owners WHERE settings_id=b.settings_id;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',entry_id,'revision',expected_version) ORDER BY entry_id),'[]'::jsonb),count(*)
  INTO entry_refs,ne FROM memory_forget_entries WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',source_id,'revision',expected_version) ORDER BY source_id),'[]'::jsonb),count(*)
  INTO source_refs,ns FROM memory_forget_sources WHERE batch_id=bid;
 SELECT COALESCE(jsonb_agg(jsonb_build_object('id',context_id,'revision',expected_version) ORDER BY context_id),'[]'::jsonb),count(*)
  INTO context_refs,nc FROM memory_forget_contexts WHERE batch_id=bid;
 IF b.id IS NULL OR s.id IS NULL OR watermark.settings_id IS NULL OR watermark.journal_id<>b.journal_id
  OR watermark.sequence<b.journal_sequence OR watermark.owner_epoch<b.owner_epoch OR ne>64 OR ns>64 OR nc>64
  OR (b.kind='entry' AND (ne<>1 OR ns<>0 OR nc<>0)) OR (b.kind='source' AND (ne<>0 OR ns<>1 OR nc<>0))
  OR b.request IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'kind',b.kind,'settingsId',s.id,
   'expectedRevision',b.expected_version,'learningEpoch',b.prior_learning_epoch,'recallEpoch',b.prior_recall_epoch,
   'contextRevision',b.prior_context_revision,'entryRefs',entry_refs,'sourceRefs',source_refs,'contextRefs',context_refs)
  OR b.receipt IS DISTINCT FROM jsonb_build_object('commandId',b.command_id,'operationId',b.id,'kind',b.kind,
   'settings',jsonb_build_object('revision',b.accepted_version,'learningEpoch',b.learning_epoch,'recallEpoch',b.recall_epoch,
    'contextRevision',b.context_revision,'indexGeneration',b.index_generation,'choice',b.receipt->'settings'->'choice'),
   'forgotten',jsonb_build_object('entries',ne,'sources',ns,'contexts',nc))
  THEN RAISE EXCEPTION 'memory_forget_exact_receipt';END IF;
 IF EXISTS(SELECT 1 FROM memory_forget_entries m JOIN personal_knowledge_entries e ON e.id=m.entry_id
  JOIN personal_knowledge_operations operation ON operation.id=m.operation_id WHERE m.batch_id=bid
   AND (e.settings_id<>b.settings_id OR e.state<>'FORGOTTEN' OR e.version<>m.accepted_version
    OR operation.forget_batch_id IS DISTINCT FROM bid OR operation.kind<>'FORGET' OR operation.entry_id<>m.entry_id
    OR operation.expected_version<>m.expected_version OR operation.accepted_version<>m.accepted_version
    OR operation.context_revision<>b.context_revision OR operation.created_at<>b.created_at
    OR operation.session_id<>b.session_id))
  OR EXISTS(SELECT 1 FROM personal_knowledge_operations operation WHERE operation.forget_batch_id=bid AND NOT EXISTS(
   SELECT 1 FROM memory_forget_entries m WHERE m.batch_id=bid AND m.operation_id=operation.id AND m.entry_id=operation.entry_id))
  OR EXISTS(SELECT 1 FROM memory_forget_sources m JOIN personal_learning_sources source ON source.id=m.source_id
   JOIN personal_learning_source_forgets f ON f.id=m.forget_id WHERE m.batch_id=bid
    AND (source.settings_id<>b.settings_id OR source.state<>'FORGOTTEN' OR source.revision<>m.accepted_version
     OR f.source_id<>m.source_id OR f.session_id<>b.session_id OR f.created_at<>b.created_at))
  OR EXISTS(SELECT 1 FROM memory_forget_contexts m JOIN owner_memory_contexts c ON c.id=m.context_id WHERE m.batch_id=bid
   AND (c.settings_id<>b.settings_id OR c.state<>'FORGOTTEN' OR c.version<>m.accepted_version
    OR c.context_revision<>b.context_revision OR c.updated_at<>b.created_at OR c.envelope IS NOT NULL))
  THEN RAISE EXCEPTION 'memory_forget_exact_members';END IF;
 IF live THEN
  IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation,s.updated_at)
   IS DISTINCT FROM ROW(b.accepted_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.index_generation,b.created_at)
   AND b.kind<>'source' THEN RAISE EXCEPTION 'memory_forget_current_settings';END IF;
  IF b.receipt->'settings' IS DISTINCT FROM os_learning_settings_payload(s)
   OR watermark.sequence<>b.journal_sequence OR watermark.owner_epoch<>b.owner_epoch OR watermark.updated_at<>b.created_at
   THEN RAISE EXCEPTION 'memory_forget_current_watermark';END IF;
  IF b.kind='all' AND (EXISTS(SELECT 1 FROM personal_knowledge_entries WHERE settings_id=b.settings_id AND state<>'FORGOTTEN')
   OR EXISTS(SELECT 1 FROM personal_learning_sources WHERE settings_id=b.settings_id AND state='AVAILABLE')
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state<>'FORGOTTEN'))
   THEN RAISE EXCEPTION 'memory_forget_all_members';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_current_owner';END IF;
 END IF;
 IF b.completed_at IS NOT NULL THEN
  IF EXISTS(SELECT 1 FROM personal_forget_journal WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_source_forgets WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND completed_at IS NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_contexts WHERE settings_id=b.settings_id AND state='FORGOTTEN' AND envelope IS NOT NULL)
   OR EXISTS(SELECT 1 FROM owner_memory_context_commands command JOIN owner_memory_contexts context ON context.id=command.context_id
    WHERE context.settings_id=b.settings_id AND context.state='FORGOTTEN' AND command.request_mac IS NOT NULL)
   OR EXISTS(SELECT 1 FROM personal_learning_jobs WHERE installation_id=b.installation_id AND application_id=b.application_id
    AND tenant_id=b.tenant_id AND subject_id=b.subject_id AND state IN ('QUEUED','RUNNING'))
   THEN RAISE EXCEPTION 'memory_forget_cleanup_incomplete';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=b.cleanup_session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=b.installation_id AND id=b.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=b.installation_id AND application_id=b.application_id
   AND tenant_id=b.tenant_id AND subject_id=b.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(b.installation_id,b.application_id,b.tenant_id,b.subject_id)
   OR NOT app.active OR app.generation<>session.application_generation
   OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_forget_cleanup_owner';END IF;
 END IF;
END $$;

CREATE FUNCTION os_guard_memory_recovery_owner() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE b memory_forget_batches%ROWTYPE; s personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'memory_recovery_owner_retained';END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.sequence<>0 OR NEW.owner_epoch<>1 OR NEW.updated_at<>NEW.created_at
   THEN RAISE EXCEPTION 'memory_recovery_initial_watermark';END IF;
 ELSE
  SELECT * INTO b FROM memory_forget_batches WHERE settings_id=NEW.settings_id AND journal_sequence=NEW.sequence;
  SELECT * INTO s FROM personal_learning_settings WHERE id=NEW.settings_id;
  IF ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.index_generation) IS DISTINCT FROM
    ROW(b.expected_version,b.prior_learning_epoch,b.prior_recall_epoch,b.prior_context_revision,b.index_generation)
   THEN RAISE EXCEPTION 'memory_recovery_prior_settings';END IF;
  IF b.id IS NULL OR b.prior_journal_sequence<>OLD.sequence OR b.prior_owner_epoch<>OLD.owner_epoch
   OR b.owner_epoch<>NEW.owner_epoch OR NEW.updated_at<>b.created_at
   OR (to_jsonb(NEW)-ARRAY['sequence','owner_epoch','updated_at']) IS DISTINCT FROM
    (to_jsonb(OLD)-ARRAY['sequence','owner_epoch','updated_at'])
   THEN RAISE EXCEPTION 'memory_recovery_exact_watermark';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_guard_memory_forget_batch() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'memory_forget_receipt_retained';END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.completed_at IS NOT NULL OR NEW.cleanup_session_id IS NOT NULL
   THEN RAISE EXCEPTION 'memory_forget_initial_cleanup';END IF;
 ELSE
  IF OLD.completed_at IS NOT NULL OR NEW.completed_at IS NULL OR NEW.cleanup_session_id IS NULL
   OR (to_jsonb(NEW)-ARRAY['completed_at','cleanup_session_id']) IS DISTINCT FROM
      (to_jsonb(OLD)-ARRAY['completed_at','cleanup_session_id'])
   THEN RAISE EXCEPTION 'memory_forget_receipt_immutable';END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE FUNCTION os_commit_memory_forget_batch() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE bid uuid;
BEGIN
 IF TG_TABLE_NAME='memory_forget_batches' THEN
  bid=NEW.id;
 ELSIF TG_TABLE_NAME='memory_recovery_owners' THEN
  IF NEW.sequence=0 THEN RETURN NULL;END IF;
  SELECT id INTO bid FROM memory_forget_batches WHERE settings_id=NEW.settings_id AND journal_sequence=NEW.sequence;
 ELSIF TG_TABLE_NAME='personal_knowledge_operations' THEN
  IF NEW.forget_batch_id IS NULL THEN RETURN NULL;END IF;
  bid=NEW.forget_batch_id;
 ELSE
  bid=NEW.batch_id;
 END IF;
 PERFORM os_assert_memory_forget_batch(bid,TG_OP='INSERT' AND TG_TABLE_NAME='memory_forget_batches');
 RETURN NULL;
END $$;

CREATE FUNCTION os_guard_forgotten_context_command() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'memory_context_receipt_retained';END IF;
 IF OLD.request_mac IS NULL OR NEW.request_mac IS NOT NULL OR NEW.mac_key_id IS NOT NULL
  OR (to_jsonb(NEW)-ARRAY['request_mac','mac_key_id']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['request_mac','mac_key_id'])
  OR NOT EXISTS(SELECT 1 FROM owner_memory_contexts c JOIN memory_forget_contexts member ON member.context_id=c.id
   WHERE c.id=NEW.context_id AND c.state='FORGOTTEN' AND c.version=member.accepted_version AND c.envelope IS NULL)
  THEN RAISE EXCEPTION 'memory_context_exact_erasure';END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_learning_settings() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_settings_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.learning_epoch<>1 OR NEW.recall_epoch<>1 OR NEW.context_revision<>1
   OR NEW.index_generation<>1 OR NEW.created_at<>NEW.updated_at
   OR NEW.choice->'learnConversation'<>'false'::jsonb OR NEW.choice->'learnUsage'<>'false'::jsonb
   OR NEW.choice->'useMemory'<>'false'::jsonb OR NEW.choice->>'embeddingProfile'<>'synthetic-embedding/1' THEN RAISE EXCEPTION 'learning_default_consent'; END IF;
 ELSIF EXISTS(SELECT 1 FROM memory_forget_batches b WHERE b.settings_id=OLD.id AND b.kind='all'
  AND ROW(b.expected_version,b.prior_learning_epoch,b.prior_recall_epoch,b.prior_context_revision,b.index_generation)
   =ROW(OLD.version,OLD.learning_epoch,OLD.recall_epoch,OLD.context_revision,OLD.index_generation)
  AND ROW(b.accepted_version,b.learning_epoch,b.recall_epoch,b.context_revision,b.created_at)
   =ROW(NEW.version,NEW.learning_epoch,NEW.recall_epoch,NEW.context_revision,NEW.updated_at)) THEN
  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','context_revision','updated_at']) IS DISTINCT FROM
    (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','context_revision','updated_at'])
   THEN RAISE EXCEPTION 'memory_forget_all_settings_transition';END IF;
 ELSIF NEW.version=OLD.version AND NEW.index_generation<>OLD.index_generation THEN
  IF (to_jsonb(NEW)-ARRAY['index_generation','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['index_generation','updated_at'])
   OR NEW.index_generation<=OLD.index_generation OR NEW.updated_at<OLD.updated_at
   THEN RAISE EXCEPTION 'personal_index_activation_transition'; END IF;
 ELSIF NEW.version=OLD.version THEN
  IF (to_jsonb(NEW)-ARRAY['context_revision','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['context_revision','updated_at'])
   OR NEW.context_revision<>OLD.context_revision+1 OR NEW.updated_at<OLD.updated_at
   THEN RAISE EXCEPTION 'knowledge_context_transition'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])
   IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])
   OR NEW.version<>OLD.version+1
   OR NEW.learning_epoch<>OLD.learning_epoch+(CASE WHEN (NEW.choice-'useMemory') IS DISTINCT FROM (OLD.choice-'useMemory') THEN 1 ELSE 0 END)
   OR NEW.recall_epoch<>OLD.recall_epoch+(CASE WHEN (NEW.choice-ARRAY['learnConversation','learnUsage'])
    IS DISTINCT FROM (OLD.choice-ARRAY['learnConversation','learnUsage']) THEN 1 ELSE 0 END)
   OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'learning_settings_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_guard_learning_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; c personal_learning_commands%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  s=NEW;
  IF EXISTS(SELECT 1 FROM memory_forget_batches b WHERE b.settings_id=s.id AND b.kind='all' AND b.accepted_version=s.version
   AND b.created_at=s.updated_at) THEN
   PERFORM os_assert_memory_forget_batch((SELECT id FROM memory_forget_batches WHERE settings_id=s.id
    AND kind='all' AND accepted_version=s.version AND created_at=s.updated_at),true);RETURN NULL;
  END IF;
  SELECT * INTO c FROM personal_learning_commands WHERE settings_id=s.id AND accepted_version=s.version;
 ELSE
  c=NEW;
  SELECT * INTO s FROM personal_learning_settings WHERE id=c.settings_id;
 END IF;
 IF c.id IS NULL OR s.id IS NULL OR c.accepted_version<>s.version OR c.created_at<>s.updated_at
  OR c.receipt IS DISTINCT FROM jsonb_build_object('commandId',c.command_id,'settings',os_learning_settings_payload(s))
 THEN RAISE EXCEPTION 'learning_atomic_receipt'; END IF;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=c.session_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=s.installation_id AND id=s.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
 THEN RAISE EXCEPTION 'learning_current_owner'; END IF;
 RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION os_guard_knowledge_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE eid uuid; live boolean; e personal_knowledge_entries%ROWTYPE; c personal_knowledge_operations%ROWTYPE; context_command owner_memory_context_commands%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  IF EXISTS(SELECT 1 FROM memory_forget_batches b WHERE b.settings_id=NEW.id AND b.kind IN ('all','entry')
    AND b.context_revision=NEW.context_revision AND b.created_at=NEW.updated_at) THEN
   PERFORM os_assert_memory_forget_batch((SELECT id FROM memory_forget_batches WHERE settings_id=NEW.id
    AND kind IN ('all','entry') AND context_revision=NEW.context_revision AND created_at=NEW.updated_at),true);RETURN NULL;
  END IF;
  SELECT * INTO c FROM personal_knowledge_operations WHERE settings_id=NEW.id AND context_revision=NEW.context_revision;
  SELECT * INTO context_command FROM owner_memory_context_commands WHERE settings_id=NEW.id AND context_revision=NEW.context_revision;
  IF (c.id IS NULL)=(context_command.id IS NULL) THEN RAISE EXCEPTION 'memory_context_exact_receipt';END IF;
  IF context_command.id IS NOT NULL THEN PERFORM os_assert_owner_memory_context(context_command.context_id,true);RETURN NULL;END IF;
  IF c.id IS NULL THEN RAISE EXCEPTION 'knowledge_context_receipt'; END IF;
  eid=c.entry_id; live=true;
 ELSIF TG_TABLE_NAME='personal_knowledge_entries' THEN
  eid=NEW.id; live=(TG_OP='INSERT');
  IF TG_OP='UPDATE' THEN live=NEW.version<>OLD.version; END IF;
  IF NEW.state='SUPERSEDED' THEN
   IF TG_OP='UPDATE' AND live THEN
    IF NOT EXISTS(SELECT 1 FROM personal_knowledge_supersessions m WHERE m.entry_id=NEW.id
     AND m.expected_version=OLD.version AND m.accepted_version=NEW.version AND m.prior_state=OLD.state)
     THEN RAISE EXCEPTION 'knowledge_reviewed_target_transition';END IF;
   END IF;
   PERFORM os_assert_knowledge_supersession(eid,live);RETURN NULL;
  END IF;
  IF live THEN
   SELECT * INTO c FROM personal_knowledge_operations WHERE entry_id=eid AND accepted_version=NEW.version;
   IF TG_OP='INSERT' THEN
    IF c.kind IS DISTINCT FROM 'SAVE' THEN RAISE EXCEPTION 'knowledge_save_operation'; END IF;
   ELSE
    IF c.kind IS DISTINCT FROM (CASE WHEN NEW.active_revision_id<>OLD.active_revision_id THEN 'REVISE'
     WHEN NEW.state='FORGOTTEN' THEN 'FORGET' WHEN NEW.state='PAUSED' THEN 'PAUSE' ELSE 'RESUME' END)
     THEN RAISE EXCEPTION 'knowledge_transition_operation'; END IF;
   END IF;
  END IF;
 ELSE
  eid=NEW.entry_id; live=(TG_OP='INSERT');
  -- PL/pgSQL resolves record fields when preparing an expression, even if
  -- another operand in that expression would make an AND condition false.
  IF TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
   IF TG_OP='UPDATE' AND NEW.state='CANCELLED' THEN RETURN NULL; END IF;
  END IF;
 END IF;
 PERFORM os_assert_knowledge_entry(eid,live);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;
 IF TG_OP='UPDATE' AND TG_TABLE_NAME='personal_knowledge_revisions' THEN
  IF os_revision_source_forgotten(NEW.id) THEN RETURN NULL;END IF;
 ELSIF TG_OP='UPDATE' AND TG_TABLE_NAME='personal_knowledge_operations' THEN
  IF EXISTS(SELECT 1 FROM personal_knowledge_publications p WHERE p.operation_id=NEW.id AND os_revision_source_forgotten(p.revision_id))
   THEN RETURN NULL;END IF;
 END IF;
 IF NOT live AND TG_TABLE_NAME IN ('personal_knowledge_revisions','personal_knowledge_operations','personal_forget_journal')
  AND e.projection_state<>'PURGED' THEN RAISE EXCEPTION 'knowledge_cleanup_incomplete'; END IF;
 IF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_revisions' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE id=NEW.operation_id;
  IF NEW.id<>e.active_revision_id OR NEW.envelope IS NULL OR c.kind NOT IN ('SAVE','REVISE')
   OR c.accepted_version<>e.version OR NEW.created_at<>c.created_at
   THEN RAISE EXCEPTION 'knowledge_revision_binding'; END IF;
 ELSIF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
  IF NEW.entry_version<>e.version OR NEW.revision_id<>e.active_revision_id THEN RAISE EXCEPTION 'knowledge_job_binding'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION os_guard_owner_memory_context() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; total bigint; active bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'memory_context_retained';END IF;
 SELECT * INTO s FROM personal_learning_settings WHERE id=NEW.settings_id FOR UPDATE;
 IF s.id IS NULL THEN RAISE EXCEPTION 'memory_context_settings';END IF;
 IF TG_OP='UPDATE' THEN
  IF NEW.state='FORGOTTEN' THEN
   IF OLD.state='FORGOTTEN' OR NEW.version<>OLD.version+1 OR NEW.envelope IS NOT NULL
    OR (to_jsonb(NEW)-ARRAY['state','version','context_revision','envelope','updated_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['state','version','context_revision','envelope','updated_at'])
    OR NOT EXISTS(SELECT 1 FROM memory_forget_contexts member JOIN memory_forget_batches b ON b.id=member.batch_id
     WHERE member.context_id=NEW.id AND member.expected_version=OLD.version AND member.accepted_version=NEW.version
      AND b.kind='all' AND b.settings_id=s.id AND b.prior_context_revision=s.context_revision
      AND b.context_revision=NEW.context_revision AND b.created_at=NEW.updated_at)
    THEN RAISE EXCEPTION 'memory_context_exact_forget';END IF;
   RETURN NEW;
  END IF;
 END IF;
 IF NEW.context_revision<>s.context_revision+1 THEN RAISE EXCEPTION 'memory_context_next_revision';END IF;
 IF TG_OP='INSERT' THEN
  SELECT count(*),count(*) FILTER(WHERE kind=NEW.kind AND state='ACTIVE') INTO total,active
   FROM owner_memory_contexts WHERE settings_id=s.id;
  IF total>=64 OR active>=(CASE WHEN NEW.kind='context' THEN 16 ELSE 32 END)
   OR NEW.state<>'ACTIVE' OR NEW.version<>1 OR NEW.created_at<>NEW.updated_at
   THEN RAISE EXCEPTION 'memory_context_initial_bound';END IF;
 ELSE
  IF OLD.state<>'ACTIVE' OR NEW.version<>OLD.version+1 OR NEW.updated_at<OLD.updated_at
   OR NEW.context_revision<>s.context_revision+1 OR NEW.state NOT IN ('ACTIVE','RETIRED')
   OR (to_jsonb(NEW)-ARRAY['state','version','context_revision','envelope','updated_at']) IS DISTINCT FROM
      (to_jsonb(OLD)-ARRAY['state','version','context_revision','envelope','updated_at'])
   OR (NEW.state='RETIRED' AND NEW.envelope IS DISTINCT FROM OLD.envelope)
   THEN RAISE EXCEPTION 'memory_context_transition';END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_assert_owner_memory_context(cid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE c owner_memory_contexts%ROWTYPE; m owner_memory_context_commands%ROWTYPE;
 s personal_learning_settings%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO c FROM owner_memory_contexts WHERE id=cid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=c.settings_id;
 IF c.state='FORGOTTEN' THEN
  PERFORM os_assert_memory_forget_batch((SELECT batch_id FROM memory_forget_contexts WHERE context_id=c.id),live);RETURN;
 END IF;
 SELECT * INTO m FROM owner_memory_context_commands WHERE context_id=c.id AND accepted_version=c.version;
 IF c.id IS NULL OR s.id IS NULL OR m.id IS NULL OR m.settings_id<>s.id
  OR m.context_revision<>c.context_revision OR m.created_at<>c.updated_at OR c.context_revision>s.context_revision
  OR m.receipt IS DISTINCT FROM jsonb_build_object('commandId',m.command_id,'contextRevision',m.context_revision,
    'contextId',c.id,'revision',c.version,'kind',c.kind,'state',c.state)
  OR (c.version=1 AND m.kind<>'CREATE') OR (c.version>1 AND m.kind='CREATE')
  OR (c.state='RETIRED')<>(m.kind='RETIRE') OR c.state='FORGOTTEN'
 THEN RAISE EXCEPTION 'memory_context_atomic_receipt';END IF;
 IF live THEN
  IF s.context_revision<>c.context_revision OR s.updated_at<>c.updated_at OR m.request_mac IS NULL
   THEN RAISE EXCEPTION 'memory_context_atomic_revision';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=m.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=c.installation_id AND id=c.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=c.installation_id AND application_id=c.application_id
   AND tenant_id=c.tenant_id AND subject_id=c.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(c.installation_id,c.application_id,c.tenant_id,c.subject_id)
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_context_current_owner';END IF;
 END IF;
END $$;
CREATE OR REPLACE FUNCTION os_commit_owner_memory_context() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid; m owner_memory_context_commands%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='owner_memory_contexts' THEN
  cid=NEW.id;
  IF NEW.state='FORGOTTEN' THEN PERFORM os_assert_owner_memory_context(cid,true);RETURN NULL;END IF;
  SELECT * INTO m FROM owner_memory_context_commands WHERE context_id=cid AND accepted_version=NEW.version;
  IF TG_OP='UPDATE' AND m.kind IS DISTINCT FROM (CASE WHEN NEW.state='RETIRED' THEN 'RETIRE' ELSE 'RENAME' END)
   THEN RAISE EXCEPTION 'memory_context_transition_receipt';END IF;
 ELSE
  cid=NEW.context_id;
  IF NEW.accepted_version<>(SELECT version FROM owner_memory_contexts WHERE id=cid)
   THEN RAISE EXCEPTION 'memory_context_command_version';END IF;
 END IF;
 PERFORM os_assert_owner_memory_context(cid,true);RETURN NULL;
END $$;

DROP TRIGGER guard_owner_memory_context_command ON owner_memory_context_commands;
CREATE TRIGGER guard_owner_memory_context_command BEFORE UPDATE OR DELETE ON owner_memory_context_commands
 FOR EACH ROW EXECUTE FUNCTION os_guard_forgotten_context_command();
CREATE TRIGGER guard_memory_recovery_profile BEFORE UPDATE OR DELETE ON memory_recovery_profiles
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE TRIGGER guard_memory_recovery_owner BEFORE INSERT OR UPDATE OR DELETE ON memory_recovery_owners
 FOR EACH ROW EXECUTE FUNCTION os_guard_memory_recovery_owner();
CREATE CONSTRAINT TRIGGER commit_memory_recovery_owner AFTER INSERT OR UPDATE ON memory_recovery_owners
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_memory_forget_batch();
CREATE TRIGGER guard_memory_forget_batch BEFORE INSERT OR UPDATE OR DELETE ON memory_forget_batches
 FOR EACH ROW EXECUTE FUNCTION os_guard_memory_forget_batch();
CREATE CONSTRAINT TRIGGER commit_memory_forget_batch AFTER INSERT OR UPDATE ON memory_forget_batches
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_memory_forget_batch();
CREATE CONSTRAINT TRIGGER commit_knowledge_forget_batch AFTER INSERT ON personal_knowledge_operations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_memory_forget_batch();
CREATE TRIGGER guard_memory_forget_entries BEFORE UPDATE OR DELETE ON memory_forget_entries
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_memory_forget_entries AFTER INSERT ON memory_forget_entries
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_memory_forget_batch();
CREATE TRIGGER guard_memory_forget_sources BEFORE UPDATE OR DELETE ON memory_forget_sources
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_memory_forget_sources AFTER INSERT ON memory_forget_sources
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_memory_forget_batch();
CREATE TRIGGER guard_memory_forget_contexts BEFORE UPDATE OR DELETE ON memory_forget_contexts
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_memory_forget_contexts AFTER INSERT ON memory_forget_contexts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_memory_forget_batch();
"""

def upgrade():
    for statement in TABLES:
        op.get_bind().exec_driver_sql(statement)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Use the protected additive recovery plan; deletion barriers are retained')
