"""Explicit typed preparation grant family; frozen read grants stay disjoint."""

from alembic import op

revision = "os_pg_0012"
down_revision = "os_pg_0011"
branch_labels = None
depends_on = None


def upgrade():
    op.execute("ALTER TABLE os_execution_grants DROP CONSTRAINT ck_grant_contract")
    op.execute(
        "ALTER TABLE os_execution_grants ADD CONSTRAINT ck_grant_contract "
        "CHECK (contract_ref IN ('InteractiveExecutionGrant','TypedPreparationGrant')) NOT VALID"
    )
    op.execute("ALTER TABLE os_execution_grants VALIDATE CONSTRAINT ck_grant_contract")


def downgrade():
    raise RuntimeError("Destructive downgrade refused; use tested fresh recovery")
