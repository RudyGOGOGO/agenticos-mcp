"""Draft typed preparation on the original production tool journal.

Not frozen or applied: representative runtime/negative rehearsal and recovery
remain required. Existing read/query profile branches retain their guards.
"""
from alembic import op
revision='os_pg_0076'
down_revision='os_pg_0075'
branch_labels=None
depends_on=None

REVIEW_DIGEST=r"""
CREATE OR REPLACE FUNCTION os_agent_profile_digest(purpose text,v jsonb) RETURNS text LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
 IF purpose NOT IN ('manifest','definition','policy','command','verification','receipt') THEN RAISE EXCEPTION 'agent_profile_hash_purpose'; END IF;
 RETURN encode(sha256(convert_to('agentic-os.hash/1','UTF8')||decode('00','hex')||convert_to(purpose,'UTF8')||decode('00','hex')||convert_to(os_agent_profile_canonical(v,0),'UTF8')),'hex');
END $$;
"""

PREPARATION_PROFILE=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_tool_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_applications%ROWTYPE; p jsonb; r jsonb; e jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_tool_profile_immutable'; END IF;
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 p:=NEW.payload;r:=p->'read';e:=p->'execution';
 IF p ? 'preparation' THEN
  r:=p->'preparation';
  IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
   AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
   AND p=jsonb_build_object('preparation',r,'execution',e)
   AND r=jsonb_build_object('id',r->'id','revision',r->'revision','capability',r->'capability',
    'installationId',NEW.installation_id,'applicationId',NEW.application_id,'hostDefinitionRef',r->'hostDefinitionRef',
    'providerRef',r->'providerRef','outputContract','AgentPreparedChange/1','adapterRef','typed.prepare/1')
   AND jsonb_typeof(r->'id')='string' AND r->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (r->>'revision') ~ '^[1-9][0-9]*$' AND (r->>'revision')::numeric<=9007199254740991
   AND r->'capability'=jsonb_build_object('ref',r->'capability'->'ref','revision',r->'capability'->'revision','digest',r->'capability'->'digest')
   AND r->'capability'->>'ref' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->'capability'->>'digest' ~ '^[a-f0-9]{64}$'
   AND (r->'capability'->>'revision') ~ '^[1-9][0-9]*$' AND (r->'capability'->>'revision')::numeric<=9007199254740991
   AND r->>'hostDefinitionRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND r->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND e=jsonb_build_object('id',e->'id','revision',e->'revision',
    'preparationProfile',jsonb_build_object('ref',r->'id','revision',r->'revision','digest',os_agent_profile_digest('manifest',r)),
    'usageProfile','host-preparation-elapsed/1','externalInference',false,
    'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
   AND e->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
   AND (e->>'revision') ~ '^[1-9][0-9]*$' AND (e->>'revision')::numeric<=9007199254740991
   AND (e->>'requestTimeoutMs') ~ '^[1-9][0-9]*$' AND (e->>'requestTimeoutMs')::numeric BETWEEN 25000 AND 900000
   AND (e->>'maxResultBytes') ~ '^[1-9][0-9]*$' AND (e->>'maxResultBytes')::numeric BETWEEN 1024 AND 1048576
   AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_preparation_profile_binding'; END IF;
  RETURN NEW;
 END IF;

 IF NOT COALESCE(a.active AND a.generation=NEW.application_generation AND a.revision=NEW.registration_revision
 AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',e)
 AND p-ARRAY['read','execution']='{}'::jsonb AND p ?& ARRAY['read','execution']
 AND e=jsonb_build_object('id',e->'id','revision',e->'revision','readProfile',jsonb_build_object('ref',r->'id','revision',r->'revision',
   'digest',os_agent_profile_digest('manifest',r)),'usageProfile','host-read-elapsed/1','externalInference',false,
   'requestTimeoutMs',e->'requestTimeoutMs','maxResultBytes',e->'maxResultBytes')
 AND (e->>'requestTimeoutMs')::bigint BETWEEN 1 AND 900000 AND (e->>'maxResultBytes')::bigint BETWEEN 1024 AND 1048576
 AND (e->>'revision')::bigint BETWEEN 1 AND 9007199254740991 AND (r->>'outputContract'='EvidencePage/1' OR (
 r->>'outputContract'='AgentQueryPage/1'
 AND r-ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']='{}'::jsonb
 AND r ?& ARRAY['id','revision','capability','providerRef','outputContract','host','policy','cursorField','grain','pageGroupFields']
 AND jsonb_typeof(r->'cursorField')='string' AND r->>'cursorField' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
 AND jsonb_typeof(r->'grain')='array' AND jsonb_array_length(r->'grain') BETWEEN 1 AND 64
 AND jsonb_typeof(r->'pageGroupFields')='array' AND jsonb_array_length(r->'pageGroupFields') BETWEEN 0 AND 64
 AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements((r->'grain')||(r->'pageGroupFields')) v
  WHERE jsonb_typeof(v)<>'string' OR (v#>>'{}') !~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$')
 AND jsonb_array_length(r->'grain')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'grain') v)
 AND jsonb_array_length(r->'pageGroupFields')=(SELECT count(DISTINCT v) FROM jsonb_array_elements(r->'pageGroupFields') v)
 ))
 AND r->'host'->>'installationId'=NEW.installation_id::text AND r->'host'->>'applicationId'=NEW.application_id::text
 AND NEW.created_at<=clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_tool_profile_binding'; END IF;
 RETURN NEW;
END $$;
"""

PREPARATION_BINDING=r"""
CREATE OR REPLACE FUNCTION os_assert_agent_tool_current(o os_agent_tool_operations) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; app os_applications%ROWTYPE; parent os_agent_operations%ROWTYPE;
 accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; w os_agent_payload_writes%ROWTYPE; cap os_agent_capabilities%ROWTYPE;
 c jsonb; i jsonb; dep jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=o.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (o.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=o.root_id)) ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=o.root_id FOR UPDATE;SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=o.installation_id AND id=o.application_id;
 c:=o.payload->'context';i:=o.payload->'identity';dep:=o.payload->'modelResult';
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO parent FROM os_agent_operations WHERE id=o.parent_operation_id;
 SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=o.source_acceptance_id;
 SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
 SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=o.binding_id;
 SELECT * INTO w FROM os_agent_payload_writes WHERE id=f.write_id;
 SELECT * INTO cap FROM os_agent_capabilities WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND application_generation=app.generation AND capability_ref=o.payload->'capability'->>'ref' ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND r.accounting_format='agent-resources/1'
 AND ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
 AND c=a.context AND o.task_id=r.root_task_id AND o.digest=os_agent_profile_digest('command',o.payload)
 AND o.payload=jsonb_build_object('context',c,'identity',i,'binding',o.payload->'binding','modelOperationId',o.parent_operation_id,
  'modelResult',dep,'capability',o.payload->'capability','profile',o.payload->'profile')
 AND i=jsonb_build_object('operationId',o.id,'taskId',o.task_id,'rootId',o.root_id,'segmentId',a.segment_id,
  'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','planRevision',parent.payload->'identity'->'planRevision',
  'parentOperationId',o.parent_operation_id,'iteration',parent.payload->'identity'->'iteration','kind','tool','inputDigest',i->'inputDigest')
 AND i->>'inputDigest' ~ '^[a-f0-9]{64}$' AND parent.root_id=o.root_id AND parent.payload->'context'=c
 AND producer.root_id=o.root_id AND producer.request->'context'=c AND producer.expires_at>clock_timestamp()
 AND EXISTS(SELECT 1 FROM os_agent_operation_models link WHERE link.operation_id=parent.id AND link.id=producer.id)
 AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
   'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
   'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
   'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
 AND (dep->>'acceptedAt')::timestamptz=accepted.created_at
 AND ROW(producer.installation_id,producer.application_id,producer.tenant_id,producer.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND w.task_id=o.task_id AND w.root_id=o.root_id AND w.schema_ref='AgentSDKToolBinding' AND w.schema_version=1 AND w.expires_at>clock_timestamp()
 AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND o.payload->'binding'=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',w.plain_bytes,'schemaRef',w.schema_ref,'schemaVersion',w.schema_version)
 AND p.application_generation=app.generation AND p.registration_revision=app.revision AND p.digest=os_agent_profile_digest('policy',p.payload)
 AND o.payload->'profile'=jsonb_build_object('ref',p.payload->'execution'->'id','revision',p.payload->'execution'->'revision','digest',p.policy_digest)
 AND ((p.payload->'read'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='mcp.read/1')
 OR (p.payload->'preparation'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='propose'
  AND cap.payload->>'adapterRef'='typed.prepare/1' AND cap.payload->'mcp'='null'::jsonb))
 AND cap.payload->>'lifecycle'='qualified' AND cap.payload->>'purpose'=c->>'purpose'
 AND o.payload->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
 AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=o.task_id
  AND k.state='ACTIVE' AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp()
  AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
 AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.task_id=o.task_id AND s.state='OPEN'),false)
 THEN RAISE EXCEPTION 'agent_tool_operation_binding'; END IF;
END $$;
"""

REVIEW_TABLES=r"""

CREATE TABLE os_agent_reviews (
	id UUID NOT NULL, 
	task_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	preparation_id UUID NOT NULL, 
	payload JSONB NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_review_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_tool_acceptances_preparation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, preparation_id) REFERENCES os_agent_tool_acceptances (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_agent_review_preparation UNIQUE (installation_id, application_id, tenant_id, subject_id, preparation_id), 
	CONSTRAINT uq_agent_review_task UNIQUE (installation_id, application_id, tenant_id, subject_id, task_id), 
	CONSTRAINT ck_agent_review_digest CHECK (digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_review_payload CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=16384 AND expires_at>created_at)
)

;

CREATE TABLE os_agent_review_challenges (
	id UUID NOT NULL, 
	review_id UUID NOT NULL, 
	session_id UUID NOT NULL, 
	command_id UUID NOT NULL, 
	command_digest VARCHAR(64) NOT NULL, 
	binding JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_review_challenge_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_reviews_review_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, review_id) REFERENCES os_agent_reviews (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_agent_review_challenge_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), 
	CONSTRAINT ck_agent_review_challenge_command_digest CHECK (command_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_review_challenge_binding CHECK (jsonb_typeof(binding)='object' AND octet_length(binding::text)<=8192 AND expires_at>created_at AND expires_at<=created_at+interval '60 seconds')
)

;

CREATE TABLE os_agent_review_decisions (
	id UUID NOT NULL, 
	review_id UUID NOT NULL, 
	challenge_id UUID NOT NULL, 
	session_id UUID NOT NULL, 
	command_id UUID NOT NULL, 
	command_digest VARCHAR(64) NOT NULL, 
	payload JSONB NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_review_decision_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_reviews_review_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, review_id) REFERENCES os_agent_reviews (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_review_challenges_challenge_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, challenge_id) REFERENCES os_agent_review_challenges (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_agent_review_decision_review UNIQUE (installation_id, application_id, tenant_id, subject_id, review_id), 
	CONSTRAINT uq_agent_review_decision_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), 
	CONSTRAINT ck_agent_review_decision_command_digest CHECK (command_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_review_decision_digest CHECK (digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_review_decision_payload CHECK (jsonb_typeof(payload)='object' AND octet_length(payload::text)<=32768 AND expires_at>created_at)
)

;
"""

EFFECT_TABLE=r"""

CREATE TABLE os_agent_effect_receipts (
	id UUID NOT NULL, 
	binding_id UUID NOT NULL, 
	invocation_id UUID NOT NULL, 
	effect_request_digest VARCHAR(64) NOT NULL, 
	provider_binding_digest VARCHAR(64) NOT NULL, 
	ordinal BIGINT NOT NULL, 
	observation_digest VARCHAR(64) NOT NULL, 
	payload JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_effect_receipt_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_work_attempts_binding_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_review_decisions_invocation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, invocation_id) REFERENCES os_agent_review_decisions (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_agent_effect_receipt_ordinal UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id, ordinal), 
	CONSTRAINT ck_agent_effect_receipt_request_digest CHECK (effect_request_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_effect_receipt_provider_digest CHECK (provider_binding_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_effect_receipt_observation_digest CHECK (observation_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_effect_receipt_payload CHECK (ordinal BETWEEN 1 AND 32 AND jsonb_typeof(payload)='object' AND octet_length(payload::text)<=8192)
)

;
"""

REVIEW_GUARDS=r"""
CREATE FUNCTION os_agent_review_current(review uuid) RETURNS os_agent_reviews LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; o os_agent_tool_operations%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO v FROM os_agent_reviews WHERE id=review;
 SELECT o0.* INTO o FROM os_agent_tool_operations o0 JOIN os_agent_tool_calls c ON c.operation_id=o0.id
  JOIN os_agent_tool_acceptances a ON a.call_id=c.id WHERE a.id=v.preparation_id;
 IF v.id IS NULL OR o.id IS NULL THEN RAISE EXCEPTION 'agent_review_missing'; END IF;
 PERFORM os_assert_agent_tool_current(o);
 IF v.expires_at<=clock_timestamp() THEN RAISE EXCEPTION 'agent_review_expired'; END IF;
 RETURN v;
END $$;

CREATE FUNCTION os_guard_agent_review() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_tool_acceptances%ROWTYPE; c os_agent_tool_calls%ROWTYPE; o os_agent_tool_operations%ROWTYPE;
 f os_agent_tool_archives%ROWTYPE; p os_agent_tool_profiles%ROWTYPE; r os_budget_roots%ROWTYPE;
 v jsonb; context jsonb; reference jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_review_immutable'; END IF;
 SELECT * INTO a FROM os_agent_tool_acceptances WHERE id=NEW.preparation_id;
 SELECT * INTO c FROM os_agent_tool_calls WHERE id=a.call_id;
 SELECT * INTO o FROM os_agent_tool_operations WHERE id=c.operation_id;
 PERFORM os_assert_agent_tool_current(o);
 SELECT * INTO f FROM os_agent_tool_archives WHERE id=a.artifact_id;
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id;
 v:=NEW.payload;context:=o.payload->'context';reference:=v->'preparation';
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND p.payload->'preparation'->>'outputContract'='AgentPreparedChange/1'
  AND o.task_id=NEW.task_id AND o.root_id=NEW.root_id
  AND context->'harness'->>'ref'='agent-sdk-reviewed-change/1'
  AND NEW.digest=os_agent_profile_digest('command',v)
  AND v=jsonb_build_object('context',context,'preparation',reference,'proposalId',NEW.id,'proposalDigest',v->'proposalDigest','stageId',v->'stageId','expiresAt',v->'expiresAt')
  AND v->>'stageId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
  AND v->>'proposalDigest' ~ '^[a-f0-9]{64}$'
  AND reference=jsonb_build_object('subject',context->'subject','taskId',NEW.task_id,'rootId',NEW.root_id,
   'resultId',a.id,'producerStepId',c.id,'acceptedAttemptId',c.attempt_id,
   'payload',jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',f.plain_bytes,
    'schemaRef','AgentPreparedChange','schemaVersion',1),'lineageRef',null,'scopeRef',context->'scopeRef','acceptedAt',reference->'acceptedAt')
  AND (reference->>'acceptedAt')::timestamptz=a.created_at AND a.created_at<=NEW.created_at
  AND (v->>'expiresAt')::timestamptz=NEW.expires_at AND NEW.expires_at<=r.deadline AND NEW.expires_at<=c.expires_at
  AND NEW.expires_at>clock_timestamp() AND NEW.created_at<=clock_timestamp()
  AND NOT EXISTS(SELECT 1 FROM jsonb_each(r.outstanding) x WHERE x.value<>'0'::jsonb),false)
 THEN RAISE EXCEPTION 'agent_review_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_review BEFORE INSERT OR UPDATE OR DELETE ON os_agent_reviews
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_review();

CREATE FUNCTION os_agent_review_session(v os_agent_reviews,sid uuid) RETURNS os_interactive_sessions LANGUAGE plpgsql AS $$
DECLARE s os_interactive_sessions%ROWTYPE; a os_applications%ROWTYPE; u os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_applications WHERE installation_id=v.installation_id AND id=v.application_id FOR SHARE;
 SELECT * INTO u FROM os_subjects WHERE installation_id=v.installation_id AND application_id=v.application_id
  AND tenant_id=v.tenant_id AND subject_id=v.subject_id FOR SHARE;
 SELECT * INTO s FROM os_interactive_sessions WHERE id=sid FOR SHARE;
 IF NOT COALESCE(ROW(s.installation_id,s.application_id,s.tenant_id,s.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND a.active AND u.active AND NOT s.revoked AND s.expires_at>clock_timestamp()
  AND s.application_generation=a.generation AND s.subject_generation=u.generation,false)
 THEN RAISE EXCEPTION 'agent_review_owner_not_current'; END IF;
 RETURN s;
END $$;

CREATE FUNCTION os_guard_agent_review_challenge() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; s os_interactive_sessions%ROWTYPE; b jsonb; t os_tasks%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_review_challenge_immutable'; END IF;
 v:=os_agent_review_current(NEW.review_id);s:=os_agent_review_session(v,NEW.session_id);
 SELECT * INTO t FROM os_tasks WHERE id=v.task_id;
 b:=NEW.binding;
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND t.state='WAITING_APPROVAL'
  AND b=jsonb_build_object('subject',v.payload->'context'->'subject','sessionId',s.id,'sessionGeneration',s.session_generation,
   'hostSessionRef',s.host_session_ref,'policyGeneration',(SELECT host_policy_generation FROM os_subjects
    WHERE installation_id=v.installation_id AND application_id=v.application_id AND tenant_id=v.tenant_id AND subject_id=v.subject_id),
   'challengeId',NEW.id,'nonce',b->'nonce','proposalId',v.id,'proposalRevision',1,'proposalDigest',v.payload->'proposalDigest',
   'assuranceProfile','local-synthetic-assurance/1','assuranceProviderRef',b->'assuranceProviderRef',
   'requiredAssurance','local-synthetic','createdAt',b->'createdAt','expiresAt',b->'expiresAt')
  AND b->>'nonce' ~ '^[A-Za-z0-9_-]{43,128}$' AND b->>'assuranceProviderRef' ~ '^assurance/[a-f0-9]{64}$'
  AND (b->>'createdAt')::timestamptz=NEW.created_at AND (b->>'expiresAt')::timestamptz=NEW.expires_at
  AND NEW.created_at<=clock_timestamp() AND NEW.expires_at>clock_timestamp()
  AND NEW.expires_at<=v.expires_at AND NEW.expires_at<=s.expires_at,false)
 THEN RAISE EXCEPTION 'agent_review_challenge_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_review_challenge BEFORE INSERT OR UPDATE OR DELETE ON os_agent_review_challenges
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_review_challenge();

CREATE FUNCTION os_guard_agent_review_decision() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; s os_interactive_sessions%ROWTYPE; h os_agent_review_challenges%ROWTYPE;
 t os_tasks%ROWTYPE; p jsonb; c jsonb; claim jsonb; proof jsonb; authority jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_review_decision_immutable'; END IF;
 v:=os_agent_review_current(NEW.review_id);s:=os_agent_review_session(v,NEW.session_id);
 SELECT * INTO h FROM os_agent_review_challenges WHERE id=NEW.challenge_id;
 SELECT * INTO t FROM os_tasks WHERE id=v.task_id;
 p:=NEW.payload;c:=p->'command';claim:=p->'claim';proof:=p->'attestation';authority:=p->'authority';
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND t.state='WAITING_APPROVAL' AND t.version=(c->>'expectedTaskVersion')::bigint
  AND h.review_id=v.id AND h.session_id=s.id AND h.expires_at>clock_timestamp()
  AND NEW.digest=os_agent_profile_digest('verification',p) AND NEW.command_digest=os_agent_profile_digest('command',c)
  AND c=jsonb_build_object('commandId',NEW.command_id,'taskId',t.id,'reviewId',v.id,'proposalDigest',v.payload->'proposalDigest',
   'expectedTaskVersion',t.version,'challengeId',h.id,'assertionRef',c->'assertionRef','decision',c->'decision')
  AND c->>'decision' IN ('approve','reject') AND c->>'assertionRef' ~ '^assertion/[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
  AND p=jsonb_build_object('review',v.payload,'command',c,'authority',authority,'claim',claim,'attestation',proof,
   'createdAt',p->'createdAt','expiresAt',p->'expiresAt')
  AND authority=jsonb_build_object('subject',h.binding->'subject','sessionId',s.id,'sessionGeneration',s.session_generation,
   'applicationGeneration',s.application_generation,'subjectGeneration',s.subject_generation,'hostSessionRef',s.host_session_ref,
   'profileRef',authority->'profileRef','policyGeneration',h.binding->'policyGeneration')
  AND claim=jsonb_build_object('binding',h.binding,'assertionRef',c->'assertionRef','commandId',NEW.command_id,
   'commandDigest',NEW.command_digest,'decision',c->'decision')
  AND proof=jsonb_build_object('subject',h.binding->'subject','sessionId',s.id,'challengeId',h.id,
   'bindingDigest',os_agent_profile_digest('verification',h.binding),'assertionRef',c->'assertionRef','commandId',NEW.command_id,
   'commandDigest',NEW.command_digest,'decision',c->'decision','assuranceRef','local-synthetic',
   'observedAt',proof->'observedAt','expiresAt',proof->'expiresAt')
  AND (proof->>'observedAt')::timestamptz BETWEEN clock_timestamp()-interval '5 seconds' AND clock_timestamp()+interval '1 second'
  AND (proof->>'expiresAt')::timestamptz>clock_timestamp() AND (proof->>'expiresAt')::timestamptz<=h.expires_at
  AND EXISTS(SELECT 1 FROM os_commands k WHERE k.accepted_task_id=t.id AND k.kind='agent.review.register'
   AND k.request_digest=os_agent_profile_digest('verification',jsonb_build_object('challengeId',h.id,
    'bindingDigest',os_agent_profile_digest('verification',h.binding),'expiresAt',h.binding->'expiresAt')))
  AND (p->>'createdAt')::timestamptz=NEW.created_at AND (p->>'expiresAt')::timestamptz=NEW.expires_at
  AND NEW.created_at<=clock_timestamp() AND NEW.expires_at>clock_timestamp() AND NEW.expires_at<=h.expires_at
  AND NOT EXISTS(SELECT 1 FROM os_work_attempts w WHERE w.root_id=v.root_id AND w.state IN ('RESERVED','RUNNING','UNKNOWN')),false)
 THEN RAISE EXCEPTION 'agent_review_decision_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_review_decision BEFORE INSERT OR UPDATE OR DELETE ON os_agent_review_decisions
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_review_decision();

CREATE FUNCTION os_guard_agent_approval_wait() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF NEW.accounting_format='agent-resources/1' AND NEW.state IN ('RESERVED','RUNNING')
  AND (TG_OP='INSERT' OR OLD.state IS DISTINCT FROM NEW.state)
  AND NEW.kind NOT IN ('agent.storage','agent.review')
  AND EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state='WAITING_APPROVAL')
 THEN RAISE EXCEPTION 'agent_work_waiting_approval'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_approval_wait BEFORE INSERT OR UPDATE ON os_work_attempts
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_approval_wait();
"""

EFFECT_GUARDS=r"""
CREATE FUNCTION os_agent_reviewed_grant(decision uuid) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE d os_agent_review_decisions%ROWTYPE; v os_agent_reviews%ROWTYPE; c os_agent_tool_calls%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; a os_admissions%ROWTYPE; context jsonb; subject jsonb; result jsonb;
BEGIN
 SELECT * INTO d FROM os_agent_review_decisions WHERE id=decision;
 SELECT * INTO v FROM os_agent_reviews WHERE id=d.review_id;
 SELECT c0.* INTO c FROM os_agent_tool_calls c0 JOIN os_agent_tool_acceptances x ON x.call_id=c0.id WHERE x.id=v.preparation_id;
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=c.installation_id AND application_id=c.application_id
  AND policy_digest=c.request->'record'->'profile'->>'digest';
 SELECT a0.* INTO a FROM os_admissions a0 JOIN os_budget_roots r ON r.admission_id=a0.id WHERE r.id=v.root_id;
 IF d.id IS NULL OR v.id IS NULL OR c.id IS NULL OR p.policy_digest IS NULL OR a.id IS NULL
  OR d.payload->'command'->>'decision'<>'approve' OR d.payload->'review' IS DISTINCT FROM v.payload
  OR d.digest<>os_agent_profile_digest('verification',d.payload) OR v.digest<>os_agent_profile_digest('command',v.payload)
  OR v.payload->'context' IS DISTINCT FROM a.context THEN RAISE EXCEPTION 'agent_effect_not_approved'; END IF;
 context:=a.context;subject:=context->'subject';
 result:=jsonb_build_object('profileRef','agent-reviewed-effect/1','id',d.id,'subject',subject,
  'taskId',context->'taskId','rootId',context->'rootId','segmentId',context->'segmentId','controlEpoch',context->'controlEpoch',
  'reviewId',v.id,'decision',jsonb_build_object('id',d.id,'proposalId',v.id,'proposalRevision',1,'digest',v.payload->'proposalDigest',
   'subject',subject,'expiresAt',d.payload->'expiresAt','assuranceRef','local-synthetic'),
  'decisionCoreDigest',d.digest,'proposalId',v.id,'proposalRevision',1,'proposalDigest',v.payload->'proposalDigest',
  'stageId',v.payload->'stageId','capabilityRef',c.request->'record'->'capability'->'ref',
  'providerRef',p.payload->'preparation'->'providerRef','registrationRevision',a.registration_revision,
  'invocationId',d.id,'effectRequestDigest',os_agent_profile_digest('command',jsonb_build_object('subject',subject,
   'invocationId',d.id,'proposalDigest',v.payload->'proposalDigest','capabilityRef',c.request->'record'->'capability'->'ref')),
  'expiresAt',d.payload->'expiresAt');
 RETURN result||jsonb_build_object('grantDigest',os_agent_profile_digest('verification',result));
END $$;

CREATE FUNCTION os_guard_agent_reviewed_effect() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE g jsonb; c jsonb; d os_agent_review_decisions%ROWTYPE; v os_agent_reviews%ROWTYPE; a os_admissions%ROWTYPE;
 units jsonb; request jsonb;
BEGIN
 IF NEW.accounting_format<>'agent-resources/1' OR NEW.kind<>'agent.effect' THEN RETURN NEW; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 g:=os_agent_reviewed_grant(NEW.invocation_id);
 SELECT * INTO d FROM os_agent_review_decisions WHERE id=NEW.invocation_id;
 SELECT * INTO v FROM os_agent_reviews WHERE id=d.review_id;
 c:=v.payload->'context';
 SELECT a0.* INTO a FROM os_admissions a0 JOIN os_budget_roots r ON r.admission_id=a0.id WHERE r.id=v.root_id;
 units:=jsonb_build_object('tokens',0,'costMicros',0,'workMs',NEW.reserved->'workMs','computeMs',0,'storageBytes',0);
 request:=jsonb_build_object('schema','agent-resource-reservation/1','taskId',NEW.task_id,'segmentId',NEW.segment_id,
  'epoch',NEW.control_epoch,'invocationId',NEW.invocation_id,'kind','agent.effect','inputDigest',g->'grantDigest',
  'units',units,'timeoutMs',units->'workMs');
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
  AND NEW.task_id=v.task_id AND NEW.root_id=v.root_id AND NEW.segment_id=(c->>'segmentId')::uuid
  AND NEW.control_epoch=(c->>'controlEpoch')::bigint AND NEW.reserved=units
  AND (units->>'workMs')::bigint BETWEEN 1 AND LEAST(45000,(a.bot->'resources'->>'requestTimeoutMs')::bigint)
  AND NEW.request_digest=os_agent_profile_digest('command',request)
  AND NEW.lease_until<=(g->>'expiresAt')::timestamptz,false)
 THEN RAISE EXCEPTION 'agent_reviewed_effect_binding'; END IF;
 IF NEW.state IN ('RESERVED','RUNNING') AND (TG_OP='INSERT' OR NEW.state IS DISTINCT FROM OLD.state) THEN
  PERFORM os_agent_review_session(v,d.session_id);PERFORM os_assert_agent_work_current(NEW);
  IF (g->>'expiresAt')::timestamptz<=clock_timestamp()
   OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state='RUNNING')
  THEN RAISE EXCEPTION 'agent_reviewed_effect_not_current'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_reviewed_effect BEFORE INSERT OR UPDATE ON os_work_attempts
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_reviewed_effect();

CREATE FUNCTION os_guard_agent_effect_receipt() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE w os_work_attempts%ROWTYPE; g jsonb; p jsonb; binding os_reviewed_effect_providers%ROWTYPE;
 previous os_agent_effect_receipts%ROWTYPE; count_previous bigint; regresses boolean;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_effect_receipt_immutable'; END IF;
 SELECT * INTO w FROM os_work_attempts WHERE id=NEW.binding_id FOR UPDATE;
 g:=os_agent_reviewed_grant(w.invocation_id);p:=NEW.payload;
 SELECT * INTO binding FROM os_reviewed_effect_providers WHERE installation_id=w.installation_id AND application_id=w.application_id
  AND registration_revision=(g->>'registrationRevision')::bigint AND capability_ref=g->>'capabilityRef';
 SELECT count(*) INTO count_previous FROM os_agent_effect_receipts WHERE binding_id=w.id;
 SELECT * INTO previous FROM os_agent_effect_receipts WHERE binding_id=w.id ORDER BY ordinal DESC LIMIT 1;
 regresses:=previous.id IS NOT NULL AND previous.payload->'receiptId'<>'null'::jsonb AND (
  p->'receiptId' IS DISTINCT FROM previous.payload->'receiptId' OR p->'version'='null'::jsonb
  OR (p->>'version')::bigint<(previous.payload->>'version')::bigint
  OR (p->'version'=previous.payload->'version' AND p->'status'<>previous.payload->'status')
  OR (previous.payload->>'status' IN ('COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED')
   AND (p->'status'<>previous.payload->'status' OR p->'version'<>previous.payload->'version')));
 IF NOT COALESCE(w.accounting_format='agent-resources/1' AND w.kind='agent.effect' AND w.state IN ('RUNNING','UNKNOWN','SETTLED')
  AND ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
   ROW(w.installation_id,w.application_id,w.tenant_id,w.subject_id)
  AND NEW.invocation_id=w.invocation_id AND NEW.effect_request_digest=g->>'effectRequestDigest'
  AND NEW.provider_binding_digest=binding.binding_digest AND binding.profile_ref='reviewed-host-effect/1'
  AND binding.provider_ref=g->>'providerRef' AND NEW.ordinal=count_previous+1 AND NEW.created_at<=clock_timestamp()
  AND NEW.observation_digest=os_agent_profile_digest('receipt',p)
  AND p=jsonb_build_object('subject',g->'subject','providerRef',g->'providerRef','invocationId',w.invocation_id,
   'requestDigest',g->'effectRequestDigest','receiptId',p->'receiptId','status',p->'status','version',p->'version',
   'observedAt',p->'observedAt','attestationProfile','atomic-host-receipt-observation/1')
  AND p->>'status' IN ('UNKNOWN','PENDING','COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED')
  AND ((p->>'status'='UNKNOWN' AND p->'receiptId'='null'::jsonb AND p->'version'='null'::jsonb)
   OR (p->>'status'<>'UNKNOWN' AND p->>'receiptId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
    AND p->>'version' ~ '^[1-9][0-9]*$' AND (p->>'version')::numeric<=9007199254740991))
  AND (p->>'observedAt')::timestamptz BETWEEN clock_timestamp()-interval '5 seconds' AND clock_timestamp()+interval '1 second'
  AND (NOT regresses OR (EXISTS(SELECT 1 FROM os_budget_roots WHERE id=w.root_id AND state='QUARANTINED')
   AND EXISTS(SELECT 1 FROM os_tasks WHERE id=w.task_id AND state='QUARANTINED'))),false)
 THEN RAISE EXCEPTION 'agent_effect_receipt_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_effect_receipt BEFORE INSERT OR UPDATE OR DELETE ON os_agent_effect_receipts
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_effect_receipt();
"""

EFFECT_GROUP_BOUNDS=r"""
ALTER TABLE os_agent_resource_groups DROP CONSTRAINT ck_agent_group_bounds;
ALTER TABLE os_agent_resource_groups ADD CONSTRAINT ck_agent_group_bounds CHECK (
 control_epoch>0 AND ticket BETWEEN 1 AND 9007199254740991
 AND state IN ('WAITING','ADMITTED','CANCELLED','EXPIRED')
 AND profile_ref IN ('model-reservation/1','tool-reservation/1','storage-reservation/1','compute-reservation/1','effect-reservation/1')
 AND jsonb_typeof(request)='object' AND octet_length(request::text)<=65536);
"""

EFFECT_GROUP=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_resource_group() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_group_accounts%ROWTYPE; original os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE;
 d os_admissions%ROWTYPE; c jsonb; member jsonb; required jsonb; w os_work_attempts%ROWTYPE; expected_kind text; expected_count integer;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_group_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_agent_group_accounts WHERE id=NEW.group_account_id;
 SELECT * INTO original FROM os_agent_resource_accounts WHERE id=a.account_id;
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state') THEN RAISE EXCEPTION 'agent_group_transition'; END IF;
  IF NEW.state='ADMITTED' THEN
   PERFORM os_agent_resource_owner(original);
   w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
   w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
   PERFORM os_assert_agent_work_current(w);
   IF EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
    THEN RAISE EXCEPTION 'agent_group_fifo'; END IF;
  END IF;
  RETURN NEW;
 END IF;
 PERFORM os_agent_resource_owner(original);
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 c=NEW.request->'context';required=os_agent_group_required(NEW.request->'members');
 expected_kind=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 'agent.model' WHEN 'tool-reservation/1' THEN 'agent.tool' WHEN 'compute-reservation/1' THEN 'agent.compute' WHEN 'effect-reservation/1' THEN 'agent.effect' ELSE 'agent.storage' END;
 expected_count=CASE NEW.profile_ref WHEN 'model-reservation/1' THEN 3 WHEN 'tool-reservation/1' THEN 2 ELSE 1 END;
 IF a.id IS NULL OR a.root_id<>r.id OR NEW.group_account_id<>a.id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline OR c IS DISTINCT FROM d.context
  OR NEW.request IS DISTINCT FROM jsonb_build_object('context',c,'groupId',NEW.id::text,'profile',NEW.profile_ref,'sourceId',NEW.source_id::text,'members',NEW.request->'members')
  OR c->>'rootId'<>NEW.root_id::text OR c->>'taskId'<>NEW.task_id::text OR c->>'segmentId'<>NEW.segment_id::text
  OR (c->>'controlEpoch')::bigint<>NEW.control_epoch
  OR NEW.request_digest<>os_agent_profile_digest('command',NEW.request||jsonb_build_object('schema','agent-resource-group/1'))
  OR jsonb_array_length(NEW.request->'members')<>expected_count
  OR NEW.request->'members'->0->>'kind'<>expected_kind OR NEW.request->'members'->0->>'invocationId'<>NEW.source_id::text
  OR (SELECT count(DISTINCT value->>'invocationId') FROM jsonb_array_elements(NEW.request->'members'))<>expected_count
  THEN RAISE EXCEPTION 'agent_group_binding'; END IF;
 FOR member IN SELECT value FROM jsonb_array_elements(NEW.request->'members') LOOP
  IF member IS DISTINCT FROM jsonb_build_object('taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,'controlEpoch',NEW.control_epoch,
    'invocationId',member->'invocationId','kind',member->'kind','inputDigest',member->'inputDigest','units',member->'units','timeoutMs',member->'timeoutMs')
   OR jsonb_typeof(member->'invocationId') IS DISTINCT FROM 'string' OR (member->>'invocationId') !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   OR jsonb_typeof(member->'inputDigest') IS DISTINCT FROM 'string' OR (member->>'inputDigest') !~ '^[a-f0-9]{64}$'
   OR member->>'kind' NOT IN ('agent.model','agent.tool','agent.storage','agent.compute','agent.effect')
   OR jsonb_typeof(member->'kind') IS DISTINCT FROM 'string'
   OR jsonb_typeof(member->'timeoutMs') IS DISTINCT FROM 'number' OR (member->>'timeoutMs') !~ '^[1-9][0-9]*$'
   OR (member->>'timeoutMs')::numeric>(original.policy->>'requestTimeoutMs')::numeric
   OR (member->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
   OR (member->'units'->>'workMs')::numeric<1 THEN RAISE EXCEPTION 'agent_group_member_request'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.request->'members') WITH ORDINALITY AS m(value,ordinal) WHERE ordinal>1 AND value->>'kind'<>'agent.storage')
  THEN RAISE EXCEPTION 'agent_group_member_kind'; END IF;
 IF NEW.profile_ref='effect-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
   JOIN os_tasks task ON task.id=review.task_id
  WHERE decision.id=NEW.source_id AND review.root_id=NEW.root_id AND review.task_id=NEW.task_id
   AND review.payload->'context'=c AND decision.payload->'command'->>'decision'='approve'
   AND decision.expires_at>clock_timestamp() AND task.state='RUNNING'
   AND (NEW.request->'members'->0->>'inputDigest')=(os_agent_reviewed_grant(decision.id)->>'grantDigest'))
 THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));PERFORM os_assert_agent_work_current(w);
 RETURN NEW;
END $$;
"""

EFFECT_GROUP_COMPLETION=r"""
CREATE OR REPLACE FUNCTION os_check_agent_group_complete() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE gid uuid; g os_agent_resource_groups%ROWTYPE; expected_count integer; actual uuid[]; claimed uuid[];
BEGIN
 IF TG_TABLE_NAME='os_agent_resource_groups' THEN gid=NEW.id;
 ELSIF TG_TABLE_NAME='os_agent_group_members' THEN gid=NEW.group_id;
 ELSE SELECT group_id INTO gid FROM os_agent_group_members WHERE id=NEW.member_id; END IF;
 SELECT * INTO g FROM os_agent_resource_groups WHERE id=gid;
 IF g.id IS NULL THEN RAISE EXCEPTION 'agent_group_missing'; END IF;
 expected_count=jsonb_array_length(g.request->'members');
 SELECT array_agg(c.attempt_id ORDER BY c.attempt_id) INTO claimed FROM os_agent_group_claims c JOIN os_agent_group_members m ON m.id=c.member_id WHERE m.group_id=gid;
 IF g.state<>'ADMITTED' THEN
  IF EXISTS(SELECT 1 FROM os_agent_group_members WHERE group_id=gid) THEN RAISE EXCEPTION 'agent_group_unadmitted_work'; END IF;
  RETURN NEW;
 END IF;
 IF (SELECT count(*) FROM os_agent_group_members WHERE group_id=gid)<>expected_count OR cardinality(claimed) IS DISTINCT FROM expected_count
  THEN RAISE EXCEPTION 'agent_group_incomplete'; END IF;
 IF g.profile_ref='model-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_model_calls WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND request->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_model_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_model_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_model_slots WHERE call_id=g.source_id) s;
 ELSIF g.profile_ref='tool-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
    WHERE c.id=g.source_id AND c.root_id=g.root_id AND o.task_id=g.task_id AND o.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_tool_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_tool_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_tool_slots WHERE id=g.source_id) s;
 ELSIF g.profile_ref='effect-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
    WHERE decision.id=g.source_id AND review.root_id=g.root_id AND review.task_id=g.task_id
     AND review.payload->'context'=g.request->'context' AND decision.payload->'command'->>'decision'='approve')
   THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.effect';
 ELSIF g.profile_ref='compute-reservation/1' THEN
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.compute';
 ELSE
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_payload_writes
   WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND segment_id=g.segment_id AND control_epoch=g.control_epoch;
 END IF;
 IF actual IS DISTINCT FROM claimed THEN RAISE EXCEPTION 'agent_group_source_members'; END IF;
 RETURN NEW;
END $$;
"""

def upgrade():
    for statement in (REVIEW_DIGEST,PREPARATION_PROFILE,PREPARATION_BINDING,REVIEW_TABLES,EFFECT_TABLE,REVIEW_GUARDS,EFFECT_GUARDS,EFFECT_GROUP_BOUNDS,EFFECT_GROUP,EFFECT_GROUP_COMPLETION):op.execute(statement)

def downgrade():raise RuntimeError("Use the protected recovery procedure")
