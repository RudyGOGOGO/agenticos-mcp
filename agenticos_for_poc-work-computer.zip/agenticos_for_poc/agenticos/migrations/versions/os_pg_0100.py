"""Draft authenticated owner amendments to immutable production reviews.

The existing review, decision, Root, preparation and permit guards remain.
An amendment retains its original model preparation and distinct private owner
input. No decided review can be amended. Protected runtime/recovery is pending.
"""
from alembic import op

revision='os_pg_0100'
down_revision='os_pg_0099'
branch_labels=None
depends_on=None


TABLE=r"""
ALTER TABLE os_agent_reviews DROP CONSTRAINT uq_agent_review_preparation;
ALTER TABLE os_agent_reviews DROP CONSTRAINT uq_agent_review_task;
ALTER TABLE os_agent_reviews ADD COLUMN predecessor_id uuid;
ALTER TABLE os_agent_reviews ADD COLUMN revision bigint NOT NULL DEFAULT 1;
ALTER TABLE os_agent_reviews ADD COLUMN amendment jsonb;
ALTER TABLE os_agent_reviews ADD CONSTRAINT fk_os_agent_reviews_predecessor_id
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,predecessor_id)
 REFERENCES os_agent_reviews(installation_id,application_id,tenant_id,subject_id,id);
ALTER TABLE os_agent_reviews ADD CONSTRAINT uq_agent_review_successor
 UNIQUE(installation_id,application_id,tenant_id,subject_id,predecessor_id);
ALTER TABLE os_agent_reviews ADD CONSTRAINT uq_agent_review_revision
 UNIQUE(installation_id,application_id,tenant_id,subject_id,task_id,revision);
CREATE UNIQUE INDEX uq_agent_review_original ON os_agent_reviews
 (installation_id,application_id,tenant_id,subject_id,task_id) WHERE predecessor_id IS NULL;
ALTER TABLE os_agent_reviews ADD CONSTRAINT ck_agent_review_revision CHECK (
 (predecessor_id IS NULL AND revision=1 AND amendment IS NULL) OR
 (predecessor_id IS NOT NULL AND revision BETWEEN 2 AND 8 AND amendment IS NOT NULL
  AND jsonb_typeof(amendment)='object' AND octet_length(amendment::text)<=16384));
"""

CURRENT=r"""
CREATE OR REPLACE FUNCTION os_agent_review_current(review uuid) RETURNS os_agent_reviews LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; o os_agent_tool_operations%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO v FROM os_agent_reviews WHERE id=review;
 SELECT o0.* INTO o FROM os_agent_tool_operations o0 JOIN os_agent_tool_calls c ON c.operation_id=o0.id
  JOIN os_agent_tool_acceptances a ON a.call_id=c.id WHERE a.id=v.preparation_id;
 IF v.id IS NULL OR o.id IS NULL THEN RAISE EXCEPTION 'agent_review_missing'; END IF;
 PERFORM os_assert_agent_tool_current(o);
 IF v.expires_at<=clock_timestamp() THEN RAISE EXCEPTION 'agent_review_expired'; END IF;
 IF EXISTS(SELECT 1 FROM os_agent_reviews newer WHERE newer.predecessor_id=v.id)
 THEN RAISE EXCEPTION 'agent_review_superseded'; END IF;
 RETURN v;
END $$;
"""

GUARD=r"""
CREATE FUNCTION os_guard_agent_review_revision() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE prior os_agent_reviews%ROWTYPE; root os_budget_roots%ROWTYPE; task os_tasks%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; owner os_subjects%ROWTYPE; registration os_registrations%ROWTYPE;
 embed os_embed_registrations%ROWTYPE; command os_commands%ROWTYPE; write os_agent_payload_writes%ROWTYPE;
 ready os_agent_private_payloads%ROWTYPE; work os_work_attempts%ROWTYPE; artifact os_artifacts%ROWTYPE;
 origin jsonb; c jsonb; authority jsonb; input jsonb; payload jsonb; client jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_review_immutable'; END IF;
 IF NEW.predecessor_id IS NULL THEN
  IF NEW.revision<>1 OR NEW.amendment IS NOT NULL THEN RAISE EXCEPTION 'agent_review_original'; END IF;
  RETURN NEW;
 END IF;
 -- The original guard has already checked current preparation, original Root,
 -- complete immutable record/digest/expiry and settled accounting. Locking the
 -- same Root serializes an amendment with owner decisions and other amendments.
 prior:=os_agent_review_current(NEW.predecessor_id);
 SELECT * INTO root FROM os_budget_roots WHERE id=prior.root_id FOR UPDATE;
 SELECT * INTO task FROM os_tasks WHERE id=prior.task_id FOR UPDATE;
 origin:=NEW.amendment;c:=origin->'command';authority:=origin->'authority';input:=origin->'input';payload:=input->'payload';
 session:=os_agent_review_session(prior,(authority->>'sessionId')::uuid);
 SELECT * INTO owner FROM os_subjects WHERE installation_id=prior.installation_id AND application_id=prior.application_id
  AND tenant_id=prior.tenant_id AND subject_id=prior.subject_id;
 SELECT * INTO registration FROM os_registrations WHERE installation_id=prior.installation_id
  AND application_id=prior.application_id AND revision=(SELECT revision FROM os_applications
   WHERE installation_id=prior.installation_id AND id=prior.application_id);
 SELECT * INTO embed FROM os_embed_registrations WHERE installation_id=prior.installation_id
  AND application_id=prior.application_id AND id=session.embed_ref;
 SELECT p INTO client FROM jsonb_array_elements(registration.payload->'clientProfiles') p
  WHERE p->>'id'=embed.payload->>'clientProfile';
 SELECT * INTO command FROM os_commands WHERE installation_id=prior.installation_id AND application_id=prior.application_id
  AND tenant_id=prior.tenant_id AND subject_id=prior.subject_id AND kind='agent.review.amend' AND command_id=(c->>'commandId')::uuid;
 SELECT * INTO write FROM os_agent_payload_writes WHERE id=(input->>'writeId')::uuid;
 SELECT * INTO ready FROM os_agent_private_payloads WHERE write_id=write.id;
 SELECT * INTO work FROM os_work_attempts WHERE id=write.attempt_id;
 SELECT * INTO artifact FROM os_artifacts WHERE id=ready.id;
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
   ROW(prior.installation_id,prior.application_id,prior.tenant_id,prior.subject_id)
  AND NEW.task_id=prior.task_id AND NEW.root_id=prior.root_id AND NEW.preparation_id=prior.preparation_id
  AND prior.payload->'context'->'harness'->>'ref'='agent-sdk-reviewed-change/1'
  AND NEW.payload->'context'=prior.payload->'context' AND NEW.payload->'preparation'=prior.payload->'preparation'
  AND NEW.revision=prior.revision+1 AND NEW.revision BETWEEN 2 AND 8 AND NEW.expires_at<=prior.expires_at
  AND NEW.id=os_query_source_uuid5(prior.id,'owner-amendment/'||(c->>'commandId'))
  AND NEW.created_at>=prior.created_at AND task.state='WAITING_APPROVAL' AND root.state='ACTIVE'
  AND origin=jsonb_build_object('command',c,'authority',authority,'input',input)
  AND c=jsonb_build_object('commandId',c->'commandId','taskId',task.id,'reviewId',prior.id,
   'proposalDigest',prior.payload->'proposalDigest','expectedTaskVersion',task.version,'fields',c->'fields')
  AND jsonb_typeof(c->'fields')='array' AND jsonb_array_length(c->'fields') BETWEEN 1 AND 64
  AND authority=jsonb_build_object('subject',prior.payload->'context'->'subject','sessionId',session.id,
   'sessionGeneration',session.session_generation,'applicationGeneration',session.application_generation,
   'subjectGeneration',session.subject_generation,'hostSessionRef',session.host_session_ref,
   'profileRef',client->>'id','policyGeneration',owner.host_policy_generation)
  AND (client->>'highRiskReview')::boolean AND client->>'assurance' IN ('local-synthetic','dpop-qualified')
  AND command.accepted_task_id=task.id AND command.request_digest=os_agent_profile_digest('command',c)
  AND write.id=os_query_source_uuid5(NEW.id,'owner-input/1')
  AND ROW(write.installation_id,write.application_id,write.tenant_id,write.subject_id)=
   ROW(prior.installation_id,prior.application_id,prior.tenant_id,prior.subject_id)
  AND write.task_id=task.id AND write.root_id=root.id AND write.segment_id=(prior.payload->'context'->>'segmentId')::uuid
  AND write.control_epoch=(prior.payload->'context'->>'controlEpoch')::bigint
  AND write.schema_ref='AgentReviewAmendmentInput' AND write.schema_version=1 AND write.expires_at>clock_timestamp()
  AND ready.root_id=root.id AND work.state='SETTLED' AND work.actual IS NOT NULL AND artifact.id=ready.id
  AND artifact.classification='protected' AND artifact.purpose='artifact' AND artifact.expires_at>clock_timestamp()
  AND artifact.ciphertext_digest=ready.ciphertext_digest
  AND input=jsonb_build_object('subject',prior.payload->'context'->'subject','rootId',root.id,'taskId',task.id,
   'writeId',write.id,'payload',payload,'createdAt',input->'createdAt','expiresAt',input->'expiresAt')
  AND (input->>'createdAt')::timestamptz=ready.created_at AND (input->>'expiresAt')::timestamptz=write.expires_at
  AND payload=jsonb_build_object('artifactRef','artifact/'||ready.id,'ciphertextDigest',ready.ciphertext_digest,
   'bytes',write.plain_bytes,'schemaRef',write.schema_ref,'schemaVersion',write.schema_version)
  AND NOT EXISTS(SELECT 1 FROM os_agent_review_decisions d JOIN os_agent_reviews reviewed ON reviewed.id=d.review_id
   WHERE reviewed.root_id=root.id),false)
 THEN RAISE EXCEPTION 'agent_review_amendment_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_review_revision BEFORE INSERT OR UPDATE OR DELETE ON os_agent_reviews
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_review_revision();
"""


# Retained original group predicates with one explicit owner-review source.
GROUP_GUARDS=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_resource_group() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_group_accounts%ROWTYPE; original os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE;
 d os_admissions%ROWTYPE; c jsonb; member jsonb; required jsonb; w os_work_attempts%ROWTYPE; expected_kind text; expected_count integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_group_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_agent_group_accounts WHERE id=NEW.group_account_id;
 SELECT * INTO original FROM os_agent_resource_accounts WHERE id=a.account_id;
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state') THEN RAISE EXCEPTION 'agent_group_transition'; END IF;
  IF NEW.state='ADMITTED' THEN
   PERFORM os_agent_resource_owner(original);
   w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
   w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
   PERFORM os_assert_agent_work_current(w);
   IF EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
    THEN RAISE EXCEPTION 'agent_group_fifo'; END IF;
  END IF;
  RETURN NEW;
 END IF;
 PERFORM os_agent_resource_owner(original);
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 c=NEW.request->'context';required=os_agent_group_required(NEW.request->'members');
 expected_kind=CASE NEW.profile_ref WHEN 'repair-reservation/1' THEN 'agent.repair' WHEN 'wasm-creation-reservation/1' THEN 'agent.native' WHEN 'model-reservation/1' THEN 'agent.model' WHEN 'tool-reservation/1' THEN CASE WHEN c->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END WHEN 'compute-reservation/1' THEN 'agent.compute' WHEN 'review-reservation/1' THEN 'agent.review' WHEN 'effect-reservation/1' THEN 'agent.effect' WHEN 'native-reservation/1' THEN 'agent.native' WHEN 'memory-reservation/1' THEN 'agent.memory' ELSE 'agent.storage' END;
 expected_count=CASE NEW.profile_ref WHEN 'wasm-creation-reservation/1' THEN 2 WHEN 'model-reservation/1' THEN 3 WHEN 'tool-reservation/1' THEN 2 WHEN 'memory-reservation/1' THEN 2 ELSE 1 END;
 IF a.id IS NULL OR a.root_id<>r.id OR NEW.group_account_id<>a.id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline OR NOT COALESCE(os_agent_context_matches(d,c) OR (NEW.profile_ref IN ('repair-reservation/1','storage-reservation/1') AND os_agent_repair_child_context(d,c)),false)
  OR NEW.request IS DISTINCT FROM jsonb_build_object('context',c,'groupId',NEW.id::text,'profile',NEW.profile_ref,'sourceId',NEW.source_id::text,'members',NEW.request->'members')
  OR c->>'rootId'<>NEW.root_id::text OR c->>'taskId'<>NEW.task_id::text OR c->>'segmentId'<>NEW.segment_id::text
  OR (c->>'controlEpoch')::bigint<>NEW.control_epoch
  OR NEW.request_digest<>os_agent_profile_digest('command',NEW.request||jsonb_build_object('schema','agent-resource-group/1'))
  OR jsonb_array_length(NEW.request->'members')<>expected_count
  OR NEW.request->'members'->0->>'kind'<>expected_kind OR NEW.request->'members'->0->>'invocationId'<>NEW.source_id::text
  OR (SELECT count(DISTINCT value->>'invocationId') FROM jsonb_array_elements(NEW.request->'members'))<>expected_count
  THEN RAISE EXCEPTION 'agent_group_binding'; END IF;
 IF NEW.profile_ref='review-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_commands command JOIN os_tasks task ON task.id=command.accepted_task_id
   JOIN os_agent_reviews review ON review.task_id=task.id
  WHERE command.id=NEW.source_id AND command.kind='agent.review.amend.prepare'
   AND ROW(command.installation_id,command.application_id,command.tenant_id,command.subject_id)=
    ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
   AND task.id=NEW.task_id AND task.budget_root_id=NEW.root_id AND task.state='WAITING_APPROVAL'
   AND command.request_digest=NEW.request->'members'->0->>'inputDigest'
   AND review.payload->'context'=c AND c->'harness'->>'ref'='agent-sdk-reviewed-change/1'
   AND NOT EXISTS(SELECT 1 FROM os_agent_reviews newer WHERE newer.predecessor_id=review.id)
   AND NOT EXISTS(SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews decided ON decided.id=decision.review_id
    WHERE decided.root_id=NEW.root_id)) THEN RAISE EXCEPTION 'agent_group_review_source'; END IF;
 FOR member IN SELECT value FROM jsonb_array_elements(NEW.request->'members') LOOP
  IF member IS DISTINCT FROM jsonb_build_object('taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,'controlEpoch',NEW.control_epoch,
    'invocationId',member->'invocationId','kind',member->'kind','inputDigest',member->'inputDigest','units',member->'units','timeoutMs',member->'timeoutMs')
   OR jsonb_typeof(member->'invocationId') IS DISTINCT FROM 'string' OR (member->>'invocationId') !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   OR jsonb_typeof(member->'inputDigest') IS DISTINCT FROM 'string' OR (member->>'inputDigest') !~ '^[a-f0-9]{64}$'
   OR member->>'kind' NOT IN ('agent.review','agent.model','agent.tool','agent.storage','agent.compute','agent.effect','agent.native','agent.memory','agent.schedule','agent.repair')
   OR jsonb_typeof(member->'kind') IS DISTINCT FROM 'string'
   OR jsonb_typeof(member->'timeoutMs') IS DISTINCT FROM 'number' OR (member->>'timeoutMs') !~ '^[1-9][0-9]*$'
   OR (member->>'timeoutMs')::numeric>(original.policy->>'requestTimeoutMs')::numeric
   OR (member->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
   OR (member->'units'->>'workMs')::numeric<1 THEN RAISE EXCEPTION 'agent_group_member_request'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.request->'members') WITH ORDINALITY AS m(value,ordinal) WHERE ordinal>1 AND value->>'kind'<>'agent.storage')
  THEN RAISE EXCEPTION 'agent_group_member_kind'; END IF;
 IF expected_kind='agent.schedule' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id
   AND tool.payload->'context'=c AND tool.payload->'capability'=os_agent_proactive_profile(d)->'capability'
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_proactive_group_source';END IF;
 IF NEW.profile_ref='memory-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND (p.payload ? 'memory' OR p.payload ? 'knowledge')
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_memory_group_source';END IF;
 IF NEW.profile_ref='wasm-creation-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND p.payload ? 'verification'
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_wasm_creation_group_source'; END IF;
 IF NEW.profile_ref='native-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_native_operations native WHERE native.root_id=NEW.root_id AND native.task_id=NEW.task_id
   AND native.payload->'context'=c AND os_query_source_uuid5(native.id,'tool-attempt/1')=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_native_group_source'; END IF;
 IF NEW.profile_ref='effect-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
   JOIN os_tasks task ON task.id=review.task_id
  WHERE decision.id=NEW.source_id AND review.root_id=NEW.root_id AND review.task_id=NEW.task_id
   AND review.payload->'context'=c AND decision.payload->'command'->>'decision'='approve'
   AND decision.expires_at>clock_timestamp() AND task.state='RUNNING'
   AND (NEW.request->'members'->0->>'inputDigest')=(os_agent_reviewed_grant(decision.id)->>'grantDigest'))
 THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
 IF NEW.profile_ref='repair-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_repair_admissions repair JOIN os_tasks child ON child.id=repair.task_id
   LEFT JOIN os_repair_grants grant_row ON grant_row.admission_id=repair.id
  WHERE repair.original_kind='agent-reviewed' AND repair.root_id=NEW.root_id AND repair.task_id=NEW.task_id
   AND os_agent_repair_child_context(d,c) AND (
    (NEW.source_id=os_query_source_uuid5(repair.id,'preparation/1') AND NEW.segment_id=repair.segment_id
     AND child.state='ACCEPTED' AND NEW.request->'members'->0->>'inputDigest'=os_agent_profile_digest('command',
      jsonb_build_object('profile','agent-repair-work/1','repairDigest',repair.repair_digest,'phase','prepare',
       'workMs',(NEW.request->'members'->0->'units'->>'workMs')::bigint,'grantId',null)))
    OR (NEW.source_id=(grant_row.payload->>'invocationId')::uuid AND child.state='VALIDATING'
     AND NEW.segment_id=(grant_row.payload->>'segmentId')::uuid AND grant_row.expires_at>clock_timestamp()
     AND NEW.request->'members'->0->>'inputDigest'=os_agent_profile_digest('command',
      jsonb_build_object('profile','agent-repair-work/1','repairDigest',repair.repair_digest,'phase','effect',
       'workMs',(NEW.request->'members'->0->'units'->>'workMs')::bigint,'grantId',grant_row.id)))))
 THEN RAISE EXCEPTION 'agent_group_repair_source'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));PERFORM os_assert_agent_work_current(w);
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_check_agent_group_complete() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE gid uuid; g os_agent_resource_groups%ROWTYPE; expected_count integer; actual uuid[]; claimed uuid[];
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_agent_resource_groups' THEN gid=NEW.id;
 ELSIF TG_TABLE_NAME='os_agent_group_members' THEN gid=NEW.group_id;
 ELSE SELECT group_id INTO gid FROM os_agent_group_members WHERE id=NEW.member_id; END IF;
 SELECT * INTO g FROM os_agent_resource_groups WHERE id=gid;
 IF g.id IS NULL THEN RAISE EXCEPTION 'agent_group_missing'; END IF;
 expected_count=jsonb_array_length(g.request->'members');
 SELECT array_agg(c.attempt_id ORDER BY c.attempt_id) INTO claimed FROM os_agent_group_claims c JOIN os_agent_group_members m ON m.id=c.member_id WHERE m.group_id=gid;
 IF g.state<>'ADMITTED' THEN
  IF EXISTS(SELECT 1 FROM os_agent_group_members WHERE group_id=gid) THEN RAISE EXCEPTION 'agent_group_unadmitted_work'; END IF;
  RETURN NEW;
 END IF;
 IF (SELECT count(*) FROM os_agent_group_members WHERE group_id=gid)<>expected_count OR cardinality(claimed) IS DISTINCT FROM expected_count
  THEN RAISE EXCEPTION 'agent_group_incomplete'; END IF;
 IF g.profile_ref='model-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_model_calls WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND request->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_model_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_model_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_model_slots WHERE call_id=g.source_id) s;
 ELSIF g.profile_ref IN ('tool-reservation/1','memory-reservation/1','wasm-creation-reservation/1') THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
    WHERE c.id=g.source_id AND c.root_id=g.root_id AND o.task_id=g.task_id AND o.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_tool_source'; END IF;
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_work_attempts w ON w.id=c.attempt_id
   WHERE c.id=g.source_id AND w.kind=CASE WHEN g.profile_ref='wasm-creation-reservation/1' THEN 'agent.native' WHEN g.profile_ref='memory-reservation/1' THEN 'agent.memory'
    WHEN g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END)
   OR (g.profile_ref='tool-reservation/1' AND g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%'
    AND NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
     JOIN os_budget_roots r ON r.id=o.root_id JOIN os_admissions a ON a.id=r.admission_id
     JOIN os_agent_tool_profiles p ON p.installation_id=o.installation_id AND p.application_id=o.application_id
      AND p.policy_digest=o.payload->'profile'->>'digest'
     WHERE c.id=g.source_id AND p.payload ? 'proactive'
      AND p.payload->'proactive'->'capability'=o.payload->'capability'
      AND o.payload->'capability'=os_agent_proactive_profile(a)->'capability'))
  THEN RAISE EXCEPTION 'agent_group_tool_lane';END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_tool_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_tool_slots WHERE id=g.source_id) s;
 ELSIF g.profile_ref='effect-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
    WHERE decision.id=g.source_id AND review.root_id=g.root_id AND review.task_id=g.task_id
     AND review.payload->'context'=g.request->'context' AND decision.payload->'command'->>'decision'='approve')
   THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.effect';
 ELSIF g.profile_ref='native-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_native_calls call JOIN os_agent_native_operations native ON native.id=call.operation_id
   WHERE call.id=g.source_id AND call.root_id=g.root_id AND native.task_id=g.task_id AND native.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_native_source'; END IF;
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_native_calls WHERE id=g.source_id;
 ELSIF g.profile_ref='repair-reservation/1' THEN
  SELECT array_agg(w.id ORDER BY w.id) INTO actual FROM os_work_attempts w
   JOIN os_repair_work b ON b.attempt_id=w.id JOIN os_repair_admissions repair ON repair.id=b.admission_id
   WHERE w.invocation_id=g.source_id AND w.root_id=g.root_id AND w.task_id=g.task_id
    AND w.segment_id=g.segment_id AND w.control_epoch=g.control_epoch AND w.kind='agent.repair'
    AND w.accounting_format='agent-resources/1' AND repair.original_kind='agent-reviewed'
    AND repair.root_id=g.root_id AND repair.task_id=g.task_id;
 ELSIF g.profile_ref IN ('compute-reservation/1','review-reservation/1') THEN
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind=CASE WHEN g.profile_ref='review-reservation/1' THEN 'agent.review' ELSE 'agent.compute' END;
 ELSE
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_payload_writes
   WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND segment_id=g.segment_id AND control_epoch=g.control_epoch;
 END IF;
 IF actual IS DISTINCT FROM claimed THEN RAISE EXCEPTION 'agent_group_source_members'; END IF;
 RETURN NEW;
END $$;
ALTER TABLE os_agent_resource_groups DROP CONSTRAINT ck_agent_group_bounds;
ALTER TABLE os_agent_resource_groups ADD CONSTRAINT ck_agent_group_bounds CHECK (control_epoch>0 AND ticket BETWEEN 1 AND 9007199254740991 AND state IN ('WAITING','ADMITTED','CANCELLED','EXPIRED') AND profile_ref IN ('model-reservation/1','tool-reservation/1','storage-reservation/1','compute-reservation/1','effect-reservation/1','native-reservation/1','memory-reservation/1','repair-reservation/1','wasm-creation-reservation/1','review-reservation/1') AND jsonb_typeof(request)='object' AND octet_length(request::text)<=65536);
"""

def upgrade():
    for sql in (TABLE,CURRENT,GUARD,GROUP_GUARDS):op.execute(sql)


def downgrade():
    # A predecessor binary cannot interpret an owner amendment. Preserve it
    # rather than discarding owner history to make a downgrade appear safe.
    op.execute("DO $$ BEGIN IF EXISTS(SELECT 1 FROM os_agent_reviews WHERE predecessor_id IS NOT NULL) OR EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE profile_ref='review-reservation/1') "
        "THEN RAISE EXCEPTION 'agent_review_amendment_retained'; END IF; END $$;")
    op.execute(r"""
CREATE OR REPLACE FUNCTION os_guard_agent_resource_group() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_group_accounts%ROWTYPE; original os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE;
 d os_admissions%ROWTYPE; c jsonb; member jsonb; required jsonb; w os_work_attempts%ROWTYPE; expected_kind text; expected_count integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_group_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_agent_group_accounts WHERE id=NEW.group_account_id;
 SELECT * INTO original FROM os_agent_resource_accounts WHERE id=a.account_id;
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state') THEN RAISE EXCEPTION 'agent_group_transition'; END IF;
  IF NEW.state='ADMITTED' THEN
   PERFORM os_agent_resource_owner(original);
   w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
   w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
   PERFORM os_assert_agent_work_current(w);
   IF EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
    THEN RAISE EXCEPTION 'agent_group_fifo'; END IF;
  END IF;
  RETURN NEW;
 END IF;
 PERFORM os_agent_resource_owner(original);
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 c=NEW.request->'context';required=os_agent_group_required(NEW.request->'members');
 expected_kind=CASE NEW.profile_ref WHEN 'repair-reservation/1' THEN 'agent.repair' WHEN 'wasm-creation-reservation/1' THEN 'agent.native' WHEN 'model-reservation/1' THEN 'agent.model' WHEN 'tool-reservation/1' THEN CASE WHEN c->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END WHEN 'compute-reservation/1' THEN 'agent.compute' WHEN 'effect-reservation/1' THEN 'agent.effect' WHEN 'native-reservation/1' THEN 'agent.native' WHEN 'memory-reservation/1' THEN 'agent.memory' ELSE 'agent.storage' END;
 expected_count=CASE NEW.profile_ref WHEN 'wasm-creation-reservation/1' THEN 2 WHEN 'model-reservation/1' THEN 3 WHEN 'tool-reservation/1' THEN 2 WHEN 'memory-reservation/1' THEN 2 ELSE 1 END;
 IF a.id IS NULL OR a.root_id<>r.id OR NEW.group_account_id<>a.id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline OR NOT COALESCE(os_agent_context_matches(d,c) OR (NEW.profile_ref IN ('repair-reservation/1','storage-reservation/1') AND os_agent_repair_child_context(d,c)),false)
  OR NEW.request IS DISTINCT FROM jsonb_build_object('context',c,'groupId',NEW.id::text,'profile',NEW.profile_ref,'sourceId',NEW.source_id::text,'members',NEW.request->'members')
  OR c->>'rootId'<>NEW.root_id::text OR c->>'taskId'<>NEW.task_id::text OR c->>'segmentId'<>NEW.segment_id::text
  OR (c->>'controlEpoch')::bigint<>NEW.control_epoch
  OR NEW.request_digest<>os_agent_profile_digest('command',NEW.request||jsonb_build_object('schema','agent-resource-group/1'))
  OR jsonb_array_length(NEW.request->'members')<>expected_count
  OR NEW.request->'members'->0->>'kind'<>expected_kind OR NEW.request->'members'->0->>'invocationId'<>NEW.source_id::text
  OR (SELECT count(DISTINCT value->>'invocationId') FROM jsonb_array_elements(NEW.request->'members'))<>expected_count
  THEN RAISE EXCEPTION 'agent_group_binding'; END IF;
 FOR member IN SELECT value FROM jsonb_array_elements(NEW.request->'members') LOOP
  IF member IS DISTINCT FROM jsonb_build_object('taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,'controlEpoch',NEW.control_epoch,
    'invocationId',member->'invocationId','kind',member->'kind','inputDigest',member->'inputDigest','units',member->'units','timeoutMs',member->'timeoutMs')
   OR jsonb_typeof(member->'invocationId') IS DISTINCT FROM 'string' OR (member->>'invocationId') !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   OR jsonb_typeof(member->'inputDigest') IS DISTINCT FROM 'string' OR (member->>'inputDigest') !~ '^[a-f0-9]{64}$'
   OR member->>'kind' NOT IN ('agent.model','agent.tool','agent.storage','agent.compute','agent.effect','agent.native','agent.memory','agent.schedule','agent.repair')
   OR jsonb_typeof(member->'kind') IS DISTINCT FROM 'string'
   OR jsonb_typeof(member->'timeoutMs') IS DISTINCT FROM 'number' OR (member->>'timeoutMs') !~ '^[1-9][0-9]*$'
   OR (member->>'timeoutMs')::numeric>(original.policy->>'requestTimeoutMs')::numeric
   OR (member->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
   OR (member->'units'->>'workMs')::numeric<1 THEN RAISE EXCEPTION 'agent_group_member_request'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.request->'members') WITH ORDINALITY AS m(value,ordinal) WHERE ordinal>1 AND value->>'kind'<>'agent.storage')
  THEN RAISE EXCEPTION 'agent_group_member_kind'; END IF;
 IF expected_kind='agent.schedule' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id
   AND tool.payload->'context'=c AND tool.payload->'capability'=os_agent_proactive_profile(d)->'capability'
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_proactive_group_source';END IF;
 IF NEW.profile_ref='memory-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND (p.payload ? 'memory' OR p.payload ? 'knowledge')
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_memory_group_source';END IF;
 IF NEW.profile_ref='wasm-creation-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND p.payload ? 'verification'
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_wasm_creation_group_source'; END IF;
 IF NEW.profile_ref='native-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_native_operations native WHERE native.root_id=NEW.root_id AND native.task_id=NEW.task_id
   AND native.payload->'context'=c AND os_query_source_uuid5(native.id,'tool-attempt/1')=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_native_group_source'; END IF;
 IF NEW.profile_ref='effect-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
   JOIN os_tasks task ON task.id=review.task_id
  WHERE decision.id=NEW.source_id AND review.root_id=NEW.root_id AND review.task_id=NEW.task_id
   AND review.payload->'context'=c AND decision.payload->'command'->>'decision'='approve'
   AND decision.expires_at>clock_timestamp() AND task.state='RUNNING'
   AND (NEW.request->'members'->0->>'inputDigest')=(os_agent_reviewed_grant(decision.id)->>'grantDigest'))
 THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
 IF NEW.profile_ref='repair-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_repair_admissions repair JOIN os_tasks child ON child.id=repair.task_id
   LEFT JOIN os_repair_grants grant_row ON grant_row.admission_id=repair.id
  WHERE repair.original_kind='agent-reviewed' AND repair.root_id=NEW.root_id AND repair.task_id=NEW.task_id
   AND os_agent_repair_child_context(d,c) AND (
    (NEW.source_id=os_query_source_uuid5(repair.id,'preparation/1') AND NEW.segment_id=repair.segment_id
     AND child.state='ACCEPTED' AND NEW.request->'members'->0->>'inputDigest'=os_agent_profile_digest('command',
      jsonb_build_object('profile','agent-repair-work/1','repairDigest',repair.repair_digest,'phase','prepare',
       'workMs',(NEW.request->'members'->0->'units'->>'workMs')::bigint,'grantId',null)))
    OR (NEW.source_id=(grant_row.payload->>'invocationId')::uuid AND child.state='VALIDATING'
     AND NEW.segment_id=(grant_row.payload->>'segmentId')::uuid AND grant_row.expires_at>clock_timestamp()
     AND NEW.request->'members'->0->>'inputDigest'=os_agent_profile_digest('command',
      jsonb_build_object('profile','agent-repair-work/1','repairDigest',repair.repair_digest,'phase','effect',
       'workMs',(NEW.request->'members'->0->'units'->>'workMs')::bigint,'grantId',grant_row.id)))))
 THEN RAISE EXCEPTION 'agent_group_repair_source'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));PERFORM os_assert_agent_work_current(w);
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_check_agent_group_complete() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE gid uuid; g os_agent_resource_groups%ROWTYPE; expected_count integer; actual uuid[]; claimed uuid[];
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_agent_resource_groups' THEN gid=NEW.id;
 ELSIF TG_TABLE_NAME='os_agent_group_members' THEN gid=NEW.group_id;
 ELSE SELECT group_id INTO gid FROM os_agent_group_members WHERE id=NEW.member_id; END IF;
 SELECT * INTO g FROM os_agent_resource_groups WHERE id=gid;
 IF g.id IS NULL THEN RAISE EXCEPTION 'agent_group_missing'; END IF;
 expected_count=jsonb_array_length(g.request->'members');
 SELECT array_agg(c.attempt_id ORDER BY c.attempt_id) INTO claimed FROM os_agent_group_claims c JOIN os_agent_group_members m ON m.id=c.member_id WHERE m.group_id=gid;
 IF g.state<>'ADMITTED' THEN
  IF EXISTS(SELECT 1 FROM os_agent_group_members WHERE group_id=gid) THEN RAISE EXCEPTION 'agent_group_unadmitted_work'; END IF;
  RETURN NEW;
 END IF;
 IF (SELECT count(*) FROM os_agent_group_members WHERE group_id=gid)<>expected_count OR cardinality(claimed) IS DISTINCT FROM expected_count
  THEN RAISE EXCEPTION 'agent_group_incomplete'; END IF;
 IF g.profile_ref='model-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_model_calls WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND request->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_model_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_model_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_model_slots WHERE call_id=g.source_id) s;
 ELSIF g.profile_ref IN ('tool-reservation/1','memory-reservation/1','wasm-creation-reservation/1') THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
    WHERE c.id=g.source_id AND c.root_id=g.root_id AND o.task_id=g.task_id AND o.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_tool_source'; END IF;
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_work_attempts w ON w.id=c.attempt_id
   WHERE c.id=g.source_id AND w.kind=CASE WHEN g.profile_ref='wasm-creation-reservation/1' THEN 'agent.native' WHEN g.profile_ref='memory-reservation/1' THEN 'agent.memory'
    WHEN g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END)
   OR (g.profile_ref='tool-reservation/1' AND g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%'
    AND NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
     JOIN os_budget_roots r ON r.id=o.root_id JOIN os_admissions a ON a.id=r.admission_id
     JOIN os_agent_tool_profiles p ON p.installation_id=o.installation_id AND p.application_id=o.application_id
      AND p.policy_digest=o.payload->'profile'->>'digest'
     WHERE c.id=g.source_id AND p.payload ? 'proactive'
      AND p.payload->'proactive'->'capability'=o.payload->'capability'
      AND o.payload->'capability'=os_agent_proactive_profile(a)->'capability'))
  THEN RAISE EXCEPTION 'agent_group_tool_lane';END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_tool_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_tool_slots WHERE id=g.source_id) s;
 ELSIF g.profile_ref='effect-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
    WHERE decision.id=g.source_id AND review.root_id=g.root_id AND review.task_id=g.task_id
     AND review.payload->'context'=g.request->'context' AND decision.payload->'command'->>'decision'='approve')
   THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.effect';
 ELSIF g.profile_ref='native-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_native_calls call JOIN os_agent_native_operations native ON native.id=call.operation_id
   WHERE call.id=g.source_id AND call.root_id=g.root_id AND native.task_id=g.task_id AND native.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_native_source'; END IF;
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_native_calls WHERE id=g.source_id;
 ELSIF g.profile_ref='repair-reservation/1' THEN
  SELECT array_agg(w.id ORDER BY w.id) INTO actual FROM os_work_attempts w
   JOIN os_repair_work b ON b.attempt_id=w.id JOIN os_repair_admissions repair ON repair.id=b.admission_id
   WHERE w.invocation_id=g.source_id AND w.root_id=g.root_id AND w.task_id=g.task_id
    AND w.segment_id=g.segment_id AND w.control_epoch=g.control_epoch AND w.kind='agent.repair'
    AND w.accounting_format='agent-resources/1' AND repair.original_kind='agent-reviewed'
    AND repair.root_id=g.root_id AND repair.task_id=g.task_id;
 ELSIF g.profile_ref='compute-reservation/1' THEN
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.compute';
 ELSE
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_payload_writes
   WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND segment_id=g.segment_id AND control_epoch=g.control_epoch;
 END IF;
 IF actual IS DISTINCT FROM claimed THEN RAISE EXCEPTION 'agent_group_source_members'; END IF;
 RETURN NEW;
END $$;
ALTER TABLE os_agent_resource_groups DROP CONSTRAINT ck_agent_group_bounds;
ALTER TABLE os_agent_resource_groups ADD CONSTRAINT ck_agent_group_bounds CHECK (control_epoch>0 AND ticket BETWEEN 1 AND 9007199254740991 AND state IN ('WAITING','ADMITTED','CANCELLED','EXPIRED') AND profile_ref IN ('model-reservation/1','tool-reservation/1','storage-reservation/1','compute-reservation/1','effect-reservation/1','native-reservation/1','memory-reservation/1','repair-reservation/1','wasm-creation-reservation/1') AND jsonb_typeof(request)='object' AND octet_length(request::text)<=65536);
""")
    op.execute('DROP TRIGGER guard_agent_review_revision ON os_agent_reviews; DROP FUNCTION os_guard_agent_review_revision();')
    op.execute(r"""
CREATE OR REPLACE FUNCTION os_agent_review_current(review uuid) RETURNS os_agent_reviews LANGUAGE plpgsql AS $$
DECLARE v os_agent_reviews%ROWTYPE; o os_agent_tool_operations%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO v FROM os_agent_reviews WHERE id=review;
 SELECT o0.* INTO o FROM os_agent_tool_operations o0 JOIN os_agent_tool_calls c ON c.operation_id=o0.id
  JOIN os_agent_tool_acceptances a ON a.call_id=c.id WHERE a.id=v.preparation_id;
 IF v.id IS NULL OR o.id IS NULL THEN RAISE EXCEPTION 'agent_review_missing'; END IF;
 PERFORM os_assert_agent_tool_current(o);
 IF v.expires_at<=clock_timestamp() THEN RAISE EXCEPTION 'agent_review_expired'; END IF;
 RETURN v;
END $$;
""")
    op.execute('DROP INDEX uq_agent_review_original; ALTER TABLE os_agent_reviews '
        'DROP CONSTRAINT fk_os_agent_reviews_predecessor_id, DROP CONSTRAINT uq_agent_review_successor, '
        'DROP CONSTRAINT uq_agent_review_revision, DROP CONSTRAINT ck_agent_review_revision, '
        'DROP COLUMN amendment, DROP COLUMN revision, DROP COLUMN predecessor_id; '
        'ALTER TABLE os_agent_reviews ADD CONSTRAINT uq_agent_review_preparation '
        'UNIQUE(installation_id,application_id,tenant_id,subject_id,preparation_id), '
        'ADD CONSTRAINT uq_agent_review_task UNIQUE(installation_id,application_id,tenant_id,subject_id,task_id);')
