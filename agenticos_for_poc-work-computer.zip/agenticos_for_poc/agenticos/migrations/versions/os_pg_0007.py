"""Preserve typed accepted-result contracts without reinterpreting old history."""
from alembic import op
import sqlalchemy as sa

revision='os_pg_0007'
down_revision='os_pg_0006'
branch_labels=None
depends_on=None


def upgrade():
    # The additive default labels existing StageResult/2 bytes exactly as they
    # were accepted. No ciphertext or historical result is rewritten.
    op.add_column('os_accepted_results',sa.Column('contract_ref',sa.String(64),
        nullable=False,server_default='StageResult'))
    op.create_check_constraint('ck_result_contract','os_accepted_results',
        "contract_ref IN ('StageResult','CognitiveStageResult','ReadStageResult')")
    op.execute('DROP TRIGGER immutable_os_accepted_results ON os_accepted_results')
    fields=['installation_id','application_id','tenant_id','subject_id','id','task_id',
        'segment_id','attempt_id','control_epoch','artifact_id','ciphertext_digest','created_at','contract_ref']
    arguments=','.join("'"+field+"'" for field in fields)
    op.execute('CREATE TRIGGER immutable_os_accepted_results BEFORE UPDATE OR DELETE '
        'ON os_accepted_results FOR EACH ROW EXECUTE FUNCTION os_guard_immutable('+arguments+')')


def downgrade():
    raise RuntimeError('Destructive downgrade refused; use tested fresh recovery')
