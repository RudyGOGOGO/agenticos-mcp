"""Owner-private synthetic learning consent; no extraction or recall activation."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "os_pg_0031"
down_revision = "os_pg_0030"
branch_labels = None
depends_on = None

OWNER = ["installation_id", "application_id", "tenant_id", "subject_id"]


def scope():
    return [sa.Column("installation_id", pg.UUID(as_uuid=True), nullable=False),
            sa.Column("application_id", pg.UUID(as_uuid=True), nullable=False),
            sa.Column("tenant_id", sa.String(256), nullable=False),
            sa.Column("subject_id", sa.String(256), nullable=False)]


def upgrade():
    op.create_table("personal_learning_settings", *scope(),
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        *[sa.Column(k, sa.BigInteger, nullable=False) for k in
          ["version", "learning_epoch", "recall_epoch", "context_revision", "index_generation"]],
        sa.Column("choice", pg.JSONB, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint(*OWNER, "id", name="uq_learning_settings_owner_id"),
        sa.UniqueConstraint(*OWNER, name="uq_learning_settings_owner"),
        sa.ForeignKeyConstraint(OWNER, ["os_subjects."+k for k in OWNER], name="fk_learning_settings_subject"),
        sa.CheckConstraint("version>0 AND learning_epoch>0 AND recall_epoch>0 AND context_revision>0 AND index_generation>0",
                           name="ck_learning_settings_versions"),
        sa.CheckConstraint("updated_at>=created_at", name="ck_learning_settings_time"),
        sa.CheckConstraint("COALESCE(jsonb_typeof(choice->'learnConversation')='boolean' AND "
            "jsonb_typeof(choice->'learnUsage')='boolean' AND jsonb_typeof(choice->'useMemory')='boolean' AND "
            "choice=jsonb_build_object('learnConversation',choice->'learnConversation','learnUsage',choice->'learnUsage',"
            "'useMemory',choice->'useMemory','retentionProfile','private-local/1','extractorProfile','synthetic-staging/1',"
            "'embeddingProfile','synthetic-embedding/1'),false)", name="ck_learning_settings_choice"))
    op.create_table("personal_learning_commands", *scope(),
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        *[sa.Column(k, pg.UUID(as_uuid=True), nullable=False) for k in ["settings_id", "command_id", "session_id"]],
        sa.Column("expected_version", sa.BigInteger, nullable=False),
        sa.Column("accepted_version", sa.BigInteger, nullable=False),
        sa.Column("request_digest", sa.String(64), nullable=False),
        sa.Column("receipt", pg.JSONB, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint(*OWNER, "id", name="uq_learning_command_owner_id"),
        sa.UniqueConstraint(*OWNER, "command_id", name="uq_learning_command_key"),
        sa.UniqueConstraint(*OWNER, "settings_id", "accepted_version", name="uq_learning_command_revision"),
        sa.ForeignKeyConstraint([*OWNER, "settings_id"], ["personal_learning_settings."+k for k in [*OWNER, "id"]],
                                name="fk_personal_learning_settings_settings_id"),
        sa.ForeignKeyConstraint([*OWNER, "session_id"], ["os_interactive_sessions."+k for k in [*OWNER, "id"]],
                                name="fk_os_interactive_sessions_session_id"),
        sa.CheckConstraint("expected_version>0 AND accepted_version=expected_version+1", name="ck_learning_command_versions"),
        sa.CheckConstraint("request_digest ~ '^[a-f0-9]{64}$'", name="ck_learning_command_digest"))
    op.execute(GUARDS)


GUARDS = r"""
CREATE FUNCTION os_guard_learning_settings() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_settings_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.learning_epoch<>1 OR NEW.recall_epoch<>1 OR NEW.context_revision<>1
   OR NEW.index_generation<>1 OR NEW.created_at<>NEW.updated_at
   OR NEW.choice->'learnConversation'<>'false'::jsonb OR NEW.choice->'learnUsage'<>'false'::jsonb
   OR NEW.choice->'useMemory'<>'false'::jsonb THEN RAISE EXCEPTION 'learning_default_consent'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])
   IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])
   OR NEW.version<>OLD.version+1
   OR NEW.learning_epoch<>OLD.learning_epoch+(CASE WHEN (NEW.choice-'useMemory') IS DISTINCT FROM (OLD.choice-'useMemory') THEN 1 ELSE 0 END)
   OR NEW.recall_epoch<>OLD.recall_epoch+(CASE WHEN (NEW.choice-ARRAY['learnConversation','learnUsage'])
    IS DISTINCT FROM (OLD.choice-ARRAY['learnConversation','learnUsage']) THEN 1 ELSE 0 END)
   OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'learning_settings_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_learning_settings BEFORE INSERT OR UPDATE OR DELETE ON personal_learning_settings
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_settings();

CREATE FUNCTION os_learning_settings_payload(s personal_learning_settings) RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
 SELECT jsonb_build_object('revision',s.version,'learningEpoch',s.learning_epoch,'recallEpoch',s.recall_epoch,
  'contextRevision',s.context_revision,'indexGeneration',s.index_generation,'choice',s.choice)
$$;

CREATE FUNCTION os_guard_learning_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; c personal_learning_commands%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  s=NEW;
  SELECT * INTO c FROM personal_learning_commands WHERE settings_id=s.id AND accepted_version=s.version;
 ELSE
  c=NEW;
  SELECT * INTO s FROM personal_learning_settings WHERE id=c.settings_id;
 END IF;
 IF c.id IS NULL OR s.id IS NULL OR c.accepted_version<>s.version OR c.created_at<>s.updated_at
  OR c.receipt IS DISTINCT FROM jsonb_build_object('commandId',c.command_id,'settings',os_learning_settings_payload(s))
 THEN RAISE EXCEPTION 'learning_atomic_receipt'; END IF;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=c.session_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=s.installation_id AND id=s.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
 THEN RAISE EXCEPTION 'learning_current_owner'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_learning_settings AFTER UPDATE ON personal_learning_settings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_commit();
CREATE CONSTRAINT TRIGGER commit_learning_command AFTER INSERT ON personal_learning_commands
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_learning_commit();
CREATE FUNCTION os_guard_learning_command_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'learning_command_immutable'; END $$;
CREATE TRIGGER immutable_learning_command BEFORE UPDATE OR DELETE ON personal_learning_commands
 FOR EACH ROW EXECUTE FUNCTION os_guard_learning_command_immutable();
"""


def downgrade():
    raise RuntimeError("Owned populated data requires protected forward recovery")
