"""Draft canonical direct schedule placement and terminal missed occurrences."""
from alembic import op

revision='os_pg_0101'
down_revision='os_pg_0100'
branch_labels=None
depends_on=None

UPGRADE=r'''ALTER TABLE os_proactive_definitions ADD COLUMN execution_profile varchar(64) NOT NULL DEFAULT 'ScheduleDriverWorkflow/1';
ALTER TABLE os_proactive_definitions ADD COLUMN poll_observation jsonb;
ALTER TABLE os_proactive_definitions ADD CONSTRAINT ck_proactive_execution_profile CHECK (execution_profile IN ('ScheduleDriverWorkflow/1','OSDuePoll/1'));
ALTER TABLE os_proactive_definitions ADD CONSTRAINT ck_proactive_poll_observation CHECK (poll_observation IS NULL OR (execution_profile='OSDuePoll/1' AND jsonb_typeof(poll_observation)='object' AND octet_length(poll_observation::text)<=2048));
ALTER TABLE os_proactive_runs ADD COLUMN execution_profile varchar(64) NOT NULL DEFAULT 'ScheduleDriverWorkflow/1';
ALTER TABLE os_proactive_runs ADD CONSTRAINT ck_proactive_run_execution_profile CHECK (execution_profile IN ('ScheduleDriverWorkflow/1','OSDuePoll/1'));
ALTER TABLE os_proactive_runs DROP CONSTRAINT ck_proactive_run_limits;
ALTER TABLE os_proactive_runs DROP CONSTRAINT ck_proactive_run_state;
ALTER TABLE os_proactive_runs ADD CONSTRAINT ck_proactive_run_limits CHECK (definition_revision>0 AND generation>0 AND version>0 AND depth BETWEEN 0 AND 8 AND ((state='MISSED' AND execution_profile='OSDuePoll/1' AND reserved_work_ms=0 AND tool_calls=0 AND actual_work_ms=0 AND deadline<=created_at AND depth=0 AND causal_parent_id IS NULL) OR (state<>'MISSED' AND reserved_work_ms>0 AND tool_calls BETWEEN 1 AND 2 AND (actual_work_ms IS NULL OR actual_work_ms>=0) AND deadline>created_at)));
ALTER TABLE os_proactive_runs ADD CONSTRAINT ck_proactive_run_state CHECK (state IN ('DUE','RUNNING','COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED','MISSED'));
CREATE OR REPLACE FUNCTION os_proactive_definition_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='UPDATE' AND NEW.execution_profile IS DISTINCT FROM OLD.execution_profile
 THEN RAISE EXCEPTION 'proactive_execution_profile_immutable';END IF;
 IF NEW.poll_observation IS NOT NULL AND (TG_OP='INSERT' OR NEW.poll_observation IS DISTINCT FROM OLD.poll_observation) THEN
  IF NEW.execution_profile<>'OSDuePoll/1'
   OR (SELECT array_agg(k ORDER BY k) FROM jsonb_object_keys(NEW.poll_observation) k)
    IS DISTINCT FROM ARRAY['cursor','demo','generation','graceSeconds','observedAt','outcome','pollSeconds']
   OR NEW.poll_observation->'generation' IS DISTINCT FROM to_jsonb(NEW.generation)
   OR jsonb_typeof(NEW.poll_observation->'cursor') IS DISTINCT FROM 'string'
   OR jsonb_typeof(NEW.poll_observation->'observedAt') IS DISTINCT FROM 'string'
   OR jsonb_typeof(NEW.poll_observation->'outcome') IS DISTINCT FROM 'string'
   OR NEW.poll_observation->>'outcome' NOT IN ('waiting','running','needs-auth','missed','interrupted')
   OR (NEW.poll_observation->>'cursor')::timestamptz IS DISTINCT FROM NEW.cursor
   OR abs(extract(epoch FROM ((NEW.poll_observation->>'observedAt')::timestamptz-clock_timestamp())))>5
   OR NOT ((NEW.poll_observation->'demo'='true'::jsonb AND NEW.poll_observation->'pollSeconds'='2'::jsonb AND NEW.poll_observation->'graceSeconds'='10'::jsonb)
       OR (NEW.poll_observation->'demo'='false'::jsonb AND NEW.poll_observation->'pollSeconds'='60'::jsonb AND NEW.poll_observation->'graceSeconds'='120'::jsonb))
  THEN RAISE EXCEPTION 'proactive_poll_observation_binding';END IF;
 END IF;
 PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.generation<>1 OR NEW.configuration_revision<>1 OR NEW.state<>'awaiting-review' OR NEW.last_admitted_at IS NOT NULL
  THEN RAISE EXCEPTION 'proactive_initial_definition';END IF;
 ELSIF NEW.version=OLD.version THEN
  IF (to_jsonb(NEW)-ARRAY['cursor','last_admitted_at','poll_observation']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['cursor','last_admitted_at','poll_observation'])
   OR NEW.cursor<OLD.cursor OR (OLD.last_admitted_at IS NOT NULL AND (NEW.last_admitted_at IS NULL OR NEW.last_admitted_at<OLD.last_admitted_at))
  THEN RAISE EXCEPTION 'proactive_definition_bookkeeping';END IF;
 ELSE
  IF NEW.version<>OLD.version+1 OR NEW.generation<>OLD.generation+1 OR OLD.state IN ('removed','revoked')
   OR (NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.kind)
    IS DISTINCT FROM (OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.kind)
   OR NOT ((NEW.state='awaiting-review' AND NEW.configuration_revision=NEW.version)
    OR (NEW.configuration_revision=OLD.configuration_revision AND ((OLD.state='awaiting-review' AND NEW.state IN ('active','rejected','removed','revoked'))
     OR (OLD.state='active' AND NEW.state IN ('paused','removed','revoked')) OR (OLD.state='paused' AND NEW.state IN ('active','removed','revoked')))))
  THEN RAISE EXCEPTION 'proactive_definition_transition';END IF;
 END IF;
 IF NOT EXISTS(SELECT 1 FROM os_applications p JOIN os_subjects o ON o.installation_id=p.installation_id AND o.application_id=p.id
  WHERE (o.installation_id,o.application_id,o.tenant_id,o.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
  AND p.generation=NEW.application_generation AND p.revision=NEW.registration_revision AND o.generation=NEW.subject_generation
  AND o.host_policy_generation=NEW.policy_generation) THEN RAISE EXCEPTION 'proactive_definition_generation';END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_proactive_run_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_proactive_definitions%ROWTYPE;r os_proactive_revisions%ROWTYPE;g os_proactive_delegations%ROWTYPE;
 c os_task_controls%ROWTYPE;t os_tasks%ROWTYPE;p os_proactive_runs%ROWTYPE;b os_proactive_roots%ROWTYPE;l jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='UPDATE' THEN
  IF OLD.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED','MISSED') OR NEW.version<>OLD.version+1
   OR (to_jsonb(NEW)-ARRAY['state','version','actual_work_ms','result_digest','result_artifact_id','result_ciphertext_digest'])
    IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','version','actual_work_ms','result_digest','result_artifact_id','result_ciphertext_digest'])
   OR NOT ((OLD.state='DUE' AND NEW.state IN ('RUNNING','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
    OR (OLD.state='RUNNING' AND NEW.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')))
   OR (NEW.state='QUARANTINED' AND (NEW.actual_work_ms IS NOT NULL OR NEW.result_digest IS NOT NULL))
   OR (NEW.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED') AND (NEW.actual_work_ms IS NULL OR NEW.actual_work_ms>NEW.reserved_work_ms))
   OR (NEW.state<>'COMPLETED' AND NEW.result_digest IS NOT NULL)
  THEN RAISE EXCEPTION 'proactive_run_transition';END IF;
 END IF;
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id;
 SELECT * INTO r FROM os_proactive_revisions WHERE id=NEW.revision_id;
 SELECT * INTO g FROM os_proactive_delegations WHERE id=NEW.delegation_id;
 SELECT * INTO t FROM os_tasks WHERE id=NEW.task_id;
 SELECT * INTO c FROM os_task_controls WHERE task_id=NEW.task_id;
 SELECT * INTO b FROM os_proactive_roots WHERE id=NEW.root_id;l=r.configuration->'limits';
 IF NEW.execution_profile IS DISTINCT FROM d.execution_profile THEN RAISE EXCEPTION 'proactive_run_execution_profile';END IF;
 IF TG_OP='INSERT' AND NEW.state='MISSED' THEN
  PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
  IF NEW.execution_profile<>'OSDuePoll/1' OR d.state<>'active' OR NEW.generation<>d.generation
   OR NEW.definition_revision<>d.configuration_revision OR r.definition_id<>d.id OR r.revision<>NEW.definition_revision
   OR g.definition_id<>d.id OR g.revision_id<>r.id OR g.expires_at<=clock_timestamp()
   OR NEW.trigger_key !~ '^slot/[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?Z$'
   OR substring(NEW.trigger_key FROM 6)::timestamptz<d.cursor
   OR extract(epoch FROM (NEW.deadline-substring(NEW.trigger_key FROM 6)::timestamptz)) NOT IN (10,120)
   OR NEW.deadline>=clock_timestamp() OR NEW.deadline>g.expires_at OR NEW.deadline<>b.deadline
   OR abs(extract(epoch FROM (NEW.created_at-clock_timestamp())))>5
   OR NEW.version<>1 OR NEW.reserved_work_ms<>0 OR NEW.tool_calls<>0 OR NEW.actual_work_ms IS DISTINCT FROM 0
   OR NEW.result_digest IS NOT NULL OR NEW.depth<>0 OR NEW.causal_parent_id IS NOT NULL
   OR t.budget_root_id<>b.id OR t.deadline<>NEW.deadline OR t.state<>'EXPIRED' OR t.version<>1
   OR t.definition_ref<>r.configuration->>'definitionRef' OR t.definition_revision<>(r.configuration->>'definitionRevision')::bigint
   OR c.id IS NULL OR c.state<>'ACTIVE' OR c.version<>1 OR c.epoch<>1
   OR b.tasks<>0 OR b.tool_calls<>0 OR b.reserved_work_ms<>0 OR b.spent_work_ms<>0
   OR b.task_limit<>(l->>'rootTaskLimit')::bigint OR b.tool_limit<>(l->>'rootToolCallLimit')::bigint
   OR b.work_limit_ms<>(l->>'rootWorkMs')::bigint OR b.depth_limit<>(l->>'maxCausalityDepth')::bigint
   OR r.configuration->>'workflowRef'<>'registered-read/1'
   OR EXISTS(SELECT 1 FROM os_proactive_runs x WHERE x.root_id=NEW.root_id)
   OR NOT EXISTS(SELECT 1 FROM os_applications a JOIN os_subjects o ON o.installation_id=a.installation_id AND o.application_id=a.id
    WHERE (o.installation_id,o.application_id,o.tenant_id,o.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
    AND a.generation=d.application_generation AND a.revision=d.registration_revision AND o.generation=d.subject_generation AND o.host_policy_generation=d.policy_generation)
  THEN RAISE EXCEPTION 'proactive_missed_occurrence_binding';END IF;
  RETURN NEW;
 END IF;
 IF TG_OP='INSERT' THEN
  PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
  IF d.state<>'active' OR NEW.generation<>d.generation OR NEW.definition_revision<>d.configuration_revision
   OR r.definition_id<>d.id OR r.revision<>NEW.definition_revision OR g.definition_id<>d.id OR g.revision_id<>r.id
   OR g.expires_at<=clock_timestamp() OR NEW.deadline>g.expires_at OR NEW.deadline>b.deadline
   OR NEW.state<>'DUE' OR NEW.version<>1 OR NEW.actual_work_ms IS NOT NULL OR NEW.result_digest IS NOT NULL
   OR NEW.created_at>clock_timestamp()+interval '5 seconds' OR NEW.deadline<=clock_timestamp()
   OR NEW.reserved_work_ms<>(l->>'taskDeadlineMs')::bigint
   OR NEW.tool_calls<>(CASE WHEN r.configuration->>'workflowRef'='verified-wasm/1' THEN 2 ELSE 1 END)
   OR NEW.deadline>NEW.created_at+NEW.reserved_work_ms*interval '1 millisecond'
   OR t.budget_root_id<>b.id OR t.deadline<>NEW.deadline OR t.definition_ref<>r.configuration->>'definitionRef'
   OR t.definition_revision<>(r.configuration->>'definitionRevision')::bigint OR t.state<>'ACCEPTED' OR c.id IS NULL OR c.state<>'ACTIVE'
   OR NOT EXISTS(SELECT 1 FROM os_applications a JOIN os_subjects o ON o.installation_id=a.installation_id AND o.application_id=a.id
    WHERE (o.installation_id,o.application_id,o.tenant_id,o.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
    AND a.generation=d.application_generation AND a.revision=d.registration_revision AND o.generation=d.subject_generation AND o.host_policy_generation=d.policy_generation)
  THEN RAISE EXCEPTION 'proactive_current_admission';END IF;
  IF EXISTS(SELECT 1 FROM os_proactive_runs x WHERE x.definition_id=d.id AND x.state IN ('DUE','RUNNING'))
  THEN RAISE EXCEPTION 'proactive_skip_overlap';END IF;
  IF NEW.causal_parent_id IS NULL THEN
   IF NEW.depth<>0 OR b.task_limit<>(l->>'rootTaskLimit')::bigint OR b.tool_limit<>(l->>'rootToolCallLimit')::bigint
    OR b.work_limit_ms<>(l->>'rootWorkMs')::bigint OR b.depth_limit<>(l->>'maxCausalityDepth')::bigint
    OR b.deadline>NEW.created_at+b.work_limit_ms*interval '1 millisecond' THEN RAISE EXCEPTION 'proactive_original_root';END IF;
  ELSE
   SELECT * INTO p FROM os_proactive_runs WHERE id=NEW.causal_parent_id;
   IF p.root_id<>NEW.root_id OR NEW.depth<>p.depth+1 OR NEW.depth>LEAST(b.depth_limit,(l->>'maxCausalityDepth')::bigint)
    OR b.deadline<=clock_timestamp() THEN RAISE EXCEPTION 'proactive_causal_limit';END IF;
  END IF;
 END IF;
 IF NEW.state='COMPLETED' THEN
  PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
  IF (NEW.execution_profile='OSDuePoll/1' AND (d.state<>'active' OR d.generation<>NEW.generation OR d.configuration_revision<>NEW.definition_revision))
   OR d.state='revoked' OR NEW.deadline<=clock_timestamp() OR g.expires_at<=clock_timestamp() OR c.state<>'ACTIVE'
   OR NEW.result_digest IS NULL OR NOT EXISTS(SELECT 1 FROM os_artifacts a WHERE a.id=NEW.result_artifact_id
    AND a.ciphertext_digest=NEW.result_ciphertext_digest AND a.classification='owner-private' AND a.purpose='artifact')
  THEN RAISE EXCEPTION 'proactive_current_result';END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_proactive_dispatch_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM os_proactive_runs r WHERE r.id=NEW.run_id AND r.state='MISSED')
 THEN RAISE EXCEPTION 'proactive_missed_has_no_dispatch';END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'DUE' OR NEW.attempts<>0 THEN RAISE EXCEPTION 'proactive_initial_dispatch';END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['state','attempts','next_attempt_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','attempts','next_attempt_at'])
   OR OLD.state<>'DUE' OR NEW.attempts<>OLD.attempts+1 OR (NEW.state='POISON' AND NEW.attempts<>8)
   OR NEW.next_attempt_at<OLD.next_attempt_at OR NEW.next_attempt_at>clock_timestamp()+interval '31 seconds'
  THEN RAISE EXCEPTION 'proactive_dispatch_transition';END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_proactive_balance_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE day_uuid uuid;root_uuid uuid;b record;x record;t os_tasks%ROWTYPE;c os_task_controls%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='os_proactive_runs' THEN
  day_uuid=NEW.day_id;root_uuid=NEW.root_id;
  SELECT * INTO t FROM os_tasks WHERE id=NEW.task_id;SELECT * INTO c FROM os_task_controls WHERE task_id=NEW.task_id;
  IF t.deadline<>NEW.deadline OR t.budget_root_id<>NEW.root_id OR t.state<>(CASE WHEN NEW.state='DUE' THEN 'ACCEPTED' WHEN NEW.state='MISSED' THEN 'EXPIRED' ELSE NEW.state END)
   OR (NEW.state='CANCELLED' AND c.state NOT IN ('STOP_ACKNOWLEDGED','ACTIVE'))
   OR (NEW.state<>'MISSED' AND NOT EXISTS(SELECT 1 FROM os_proactive_dispatches WHERE run_id=NEW.id))
   OR (NEW.state='MISSED' AND EXISTS(SELECT 1 FROM os_proactive_dispatches WHERE run_id=NEW.id))
  THEN RAISE EXCEPTION 'proactive_task_projection';END IF;
 ELSIF TG_TABLE_NAME='os_proactive_days' THEN day_uuid=NEW.id;ELSE root_uuid=NEW.id;END IF;
 IF day_uuid IS NOT NULL THEN
  SELECT * INTO b FROM os_proactive_days WHERE id=day_uuid;
  SELECT count(*) FILTER(WHERE state<>'MISSED') AS tasks,COALESCE(sum(tool_calls),0) AS calls,COALESCE(sum(reserved_work_ms) FILTER(WHERE actual_work_ms IS NULL),0) AS reserved,
   COALESCE(sum(actual_work_ms),0) AS spent INTO x FROM os_proactive_runs WHERE day_id=day_uuid;
  IF (b.tasks,b.tool_calls,b.reserved_work_ms,b.spent_work_ms) IS DISTINCT FROM (x.tasks,x.calls,x.reserved,x.spent)
   OR EXISTS(SELECT 1 FROM os_proactive_runs r JOIN os_proactive_revisions v ON v.id=r.revision_id WHERE r.day_id=b.id
    AND (b.day<>to_char(r.created_at AT TIME ZONE 'UTC','YYYY-MM-DD') OR b.tasks>(v.configuration->'limits'->>'dailyTaskLimit')::bigint
     OR b.tool_calls>(v.configuration->'limits'->>'dailyToolCallLimit')::bigint
     OR b.reserved_work_ms+b.spent_work_ms>(v.configuration->'limits'->>'dailyWorkMs')::bigint))
  THEN RAISE EXCEPTION 'proactive_daily_balance';END IF;
 END IF;
 IF root_uuid IS NOT NULL THEN
  SELECT * INTO b FROM os_proactive_roots WHERE id=root_uuid;
  SELECT count(*) FILTER(WHERE state<>'MISSED') AS tasks,COALESCE(sum(tool_calls),0) AS calls,COALESCE(sum(reserved_work_ms) FILTER(WHERE actual_work_ms IS NULL),0) AS reserved,
   COALESCE(sum(actual_work_ms),0) AS spent INTO x FROM os_proactive_runs WHERE root_id=root_uuid;
  IF (b.tasks,b.tool_calls,b.reserved_work_ms,b.spent_work_ms) IS DISTINCT FROM (x.tasks,x.calls,x.reserved,x.spent)
  THEN RAISE EXCEPTION 'proactive_root_balance';END IF;
 END IF;
 RETURN NULL;
END $$;'''

def upgrade():
    op.execute(UPGRADE)


def downgrade():
    op.execute(r'''CREATE OR REPLACE FUNCTION os_proactive_balance_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE day_uuid uuid;root_uuid uuid;b record;x record;t os_tasks%ROWTYPE;c os_task_controls%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='os_proactive_runs' THEN
  day_uuid=NEW.day_id;root_uuid=NEW.root_id;
  SELECT * INTO t FROM os_tasks WHERE id=NEW.task_id;SELECT * INTO c FROM os_task_controls WHERE task_id=NEW.task_id;
  IF t.deadline<>NEW.deadline OR t.budget_root_id<>NEW.root_id OR t.state<>(CASE WHEN NEW.state='DUE' THEN 'ACCEPTED' ELSE NEW.state END)
   OR (NEW.state='CANCELLED' AND c.state NOT IN ('STOP_ACKNOWLEDGED','ACTIVE'))
   OR NOT EXISTS(SELECT 1 FROM os_proactive_dispatches WHERE run_id=NEW.id)
  THEN RAISE EXCEPTION 'proactive_task_projection';END IF;
 ELSIF TG_TABLE_NAME='os_proactive_days' THEN day_uuid=NEW.id;ELSE root_uuid=NEW.id;END IF;
 IF day_uuid IS NOT NULL THEN
  SELECT * INTO b FROM os_proactive_days WHERE id=day_uuid;
  SELECT count(*) AS tasks,COALESCE(sum(tool_calls),0) AS calls,COALESCE(sum(reserved_work_ms) FILTER(WHERE actual_work_ms IS NULL),0) AS reserved,
   COALESCE(sum(actual_work_ms),0) AS spent INTO x FROM os_proactive_runs WHERE day_id=day_uuid;
  IF (b.tasks,b.tool_calls,b.reserved_work_ms,b.spent_work_ms) IS DISTINCT FROM (x.tasks,x.calls,x.reserved,x.spent)
   OR EXISTS(SELECT 1 FROM os_proactive_runs r JOIN os_proactive_revisions v ON v.id=r.revision_id WHERE r.day_id=b.id
    AND (b.day<>to_char(r.created_at AT TIME ZONE 'UTC','YYYY-MM-DD') OR b.tasks>(v.configuration->'limits'->>'dailyTaskLimit')::bigint
     OR b.tool_calls>(v.configuration->'limits'->>'dailyToolCallLimit')::bigint
     OR b.reserved_work_ms+b.spent_work_ms>(v.configuration->'limits'->>'dailyWorkMs')::bigint))
  THEN RAISE EXCEPTION 'proactive_daily_balance';END IF;
 END IF;
 IF root_uuid IS NOT NULL THEN
  SELECT * INTO b FROM os_proactive_roots WHERE id=root_uuid;
  SELECT count(*) AS tasks,COALESCE(sum(tool_calls),0) AS calls,COALESCE(sum(reserved_work_ms) FILTER(WHERE actual_work_ms IS NULL),0) AS reserved,
   COALESCE(sum(actual_work_ms),0) AS spent INTO x FROM os_proactive_runs WHERE root_id=root_uuid;
  IF (b.tasks,b.tool_calls,b.reserved_work_ms,b.spent_work_ms) IS DISTINCT FROM (x.tasks,x.calls,x.reserved,x.spent)
  THEN RAISE EXCEPTION 'proactive_root_balance';END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION os_proactive_dispatch_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'DUE' OR NEW.attempts<>0 THEN RAISE EXCEPTION 'proactive_initial_dispatch';END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['state','attempts','next_attempt_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','attempts','next_attempt_at'])
   OR OLD.state<>'DUE' OR NEW.attempts<>OLD.attempts+1 OR (NEW.state='POISON' AND NEW.attempts<>8)
   OR NEW.next_attempt_at<OLD.next_attempt_at OR NEW.next_attempt_at>clock_timestamp()+interval '31 seconds'
  THEN RAISE EXCEPTION 'proactive_dispatch_transition';END IF;
 END IF;
 RETURN NEW;
END $$;
DO $$ BEGIN IF EXISTS(SELECT 1 FROM os_proactive_definitions WHERE execution_profile<>'ScheduleDriverWorkflow/1' OR poll_observation IS NOT NULL)
 OR EXISTS(SELECT 1 FROM os_proactive_runs WHERE execution_profile<>'ScheduleDriverWorkflow/1' OR state='MISSED')
 THEN RAISE EXCEPTION 'preserve_direct_schedule_facts';END IF;END $$;
CREATE OR REPLACE FUNCTION os_proactive_definition_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.generation<>1 OR NEW.configuration_revision<>1 OR NEW.state<>'awaiting-review' OR NEW.last_admitted_at IS NOT NULL
  THEN RAISE EXCEPTION 'proactive_initial_definition';END IF;
 ELSIF NEW.version=OLD.version THEN
  IF (to_jsonb(NEW)-ARRAY['cursor','last_admitted_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['cursor','last_admitted_at'])
   OR NEW.cursor<OLD.cursor OR (OLD.last_admitted_at IS NOT NULL AND (NEW.last_admitted_at IS NULL OR NEW.last_admitted_at<OLD.last_admitted_at))
  THEN RAISE EXCEPTION 'proactive_definition_bookkeeping';END IF;
 ELSE
  IF NEW.version<>OLD.version+1 OR NEW.generation<>OLD.generation+1 OR OLD.state IN ('removed','revoked')
   OR (NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.kind)
    IS DISTINCT FROM (OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.kind)
   OR NOT ((NEW.state='awaiting-review' AND NEW.configuration_revision=NEW.version)
    OR (NEW.configuration_revision=OLD.configuration_revision AND ((OLD.state='awaiting-review' AND NEW.state IN ('active','rejected','removed','revoked'))
     OR (OLD.state='active' AND NEW.state IN ('paused','removed','revoked')) OR (OLD.state='paused' AND NEW.state IN ('active','removed','revoked')))))
  THEN RAISE EXCEPTION 'proactive_definition_transition';END IF;
 END IF;
 IF NOT EXISTS(SELECT 1 FROM os_applications p JOIN os_subjects o ON o.installation_id=p.installation_id AND o.application_id=p.id
  WHERE (o.installation_id,o.application_id,o.tenant_id,o.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
  AND p.generation=NEW.application_generation AND p.revision=NEW.registration_revision AND o.generation=NEW.subject_generation
  AND o.host_policy_generation=NEW.policy_generation) THEN RAISE EXCEPTION 'proactive_definition_generation';END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_proactive_run_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_proactive_definitions%ROWTYPE;r os_proactive_revisions%ROWTYPE;g os_proactive_delegations%ROWTYPE;
 c os_task_controls%ROWTYPE;t os_tasks%ROWTYPE;p os_proactive_runs%ROWTYPE;b os_proactive_roots%ROWTYPE;l jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='UPDATE' THEN
  IF OLD.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED') OR NEW.version<>OLD.version+1
   OR (to_jsonb(NEW)-ARRAY['state','version','actual_work_ms','result_digest','result_artifact_id','result_ciphertext_digest'])
    IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','version','actual_work_ms','result_digest','result_artifact_id','result_ciphertext_digest'])
   OR NOT ((OLD.state='DUE' AND NEW.state IN ('RUNNING','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
    OR (OLD.state='RUNNING' AND NEW.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')))
   OR (NEW.state='QUARANTINED' AND (NEW.actual_work_ms IS NOT NULL OR NEW.result_digest IS NOT NULL))
   OR (NEW.state IN ('COMPLETED','FAILED','CANCELLED','EXPIRED') AND (NEW.actual_work_ms IS NULL OR NEW.actual_work_ms>NEW.reserved_work_ms))
   OR (NEW.state<>'COMPLETED' AND NEW.result_digest IS NOT NULL)
  THEN RAISE EXCEPTION 'proactive_run_transition';END IF;
 END IF;
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id;
 SELECT * INTO r FROM os_proactive_revisions WHERE id=NEW.revision_id;
 SELECT * INTO g FROM os_proactive_delegations WHERE id=NEW.delegation_id;
 SELECT * INTO t FROM os_tasks WHERE id=NEW.task_id;
 SELECT * INTO c FROM os_task_controls WHERE task_id=NEW.task_id;
 SELECT * INTO b FROM os_proactive_roots WHERE id=NEW.root_id;l=r.configuration->'limits';
 IF TG_OP='INSERT' THEN
  PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
  IF d.state<>'active' OR NEW.generation<>d.generation OR NEW.definition_revision<>d.configuration_revision
   OR r.definition_id<>d.id OR r.revision<>NEW.definition_revision OR g.definition_id<>d.id OR g.revision_id<>r.id
   OR g.expires_at<=clock_timestamp() OR NEW.deadline>g.expires_at OR NEW.deadline>b.deadline
   OR NEW.state<>'DUE' OR NEW.version<>1 OR NEW.actual_work_ms IS NOT NULL OR NEW.result_digest IS NOT NULL
   OR NEW.created_at>clock_timestamp()+interval '5 seconds' OR NEW.deadline<=clock_timestamp()
   OR NEW.reserved_work_ms<>(l->>'taskDeadlineMs')::bigint
   OR NEW.tool_calls<>(CASE WHEN r.configuration->>'workflowRef'='verified-wasm/1' THEN 2 ELSE 1 END)
   OR NEW.deadline>NEW.created_at+NEW.reserved_work_ms*interval '1 millisecond'
   OR t.budget_root_id<>b.id OR t.deadline<>NEW.deadline OR t.definition_ref<>r.configuration->>'definitionRef'
   OR t.definition_revision<>(r.configuration->>'definitionRevision')::bigint OR t.state<>'ACCEPTED' OR c.id IS NULL OR c.state<>'ACTIVE'
   OR NOT EXISTS(SELECT 1 FROM os_applications a JOIN os_subjects o ON o.installation_id=a.installation_id AND o.application_id=a.id
    WHERE (o.installation_id,o.application_id,o.tenant_id,o.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
    AND a.generation=d.application_generation AND a.revision=d.registration_revision AND o.generation=d.subject_generation AND o.host_policy_generation=d.policy_generation)
  THEN RAISE EXCEPTION 'proactive_current_admission';END IF;
  IF EXISTS(SELECT 1 FROM os_proactive_runs x WHERE x.definition_id=d.id AND x.state IN ('DUE','RUNNING'))
  THEN RAISE EXCEPTION 'proactive_skip_overlap';END IF;
  IF NEW.causal_parent_id IS NULL THEN
   IF NEW.depth<>0 OR b.task_limit<>(l->>'rootTaskLimit')::bigint OR b.tool_limit<>(l->>'rootToolCallLimit')::bigint
    OR b.work_limit_ms<>(l->>'rootWorkMs')::bigint OR b.depth_limit<>(l->>'maxCausalityDepth')::bigint
    OR b.deadline>NEW.created_at+b.work_limit_ms*interval '1 millisecond' THEN RAISE EXCEPTION 'proactive_original_root';END IF;
  ELSE
   SELECT * INTO p FROM os_proactive_runs WHERE id=NEW.causal_parent_id;
   IF p.root_id<>NEW.root_id OR NEW.depth<>p.depth+1 OR NEW.depth>LEAST(b.depth_limit,(l->>'maxCausalityDepth')::bigint)
    OR b.deadline<=clock_timestamp() THEN RAISE EXCEPTION 'proactive_causal_limit';END IF;
  END IF;
 END IF;
 IF NEW.state='COMPLETED' THEN
  PERFORM os_proactive_owner(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id);
  IF d.state='revoked' OR NEW.deadline<=clock_timestamp() OR g.expires_at<=clock_timestamp() OR c.state<>'ACTIVE'
   OR NEW.result_digest IS NULL OR NOT EXISTS(SELECT 1 FROM os_artifacts a WHERE a.id=NEW.result_artifact_id
    AND a.ciphertext_digest=NEW.result_ciphertext_digest AND a.classification='owner-private' AND a.purpose='artifact')
  THEN RAISE EXCEPTION 'proactive_current_result';END IF;
 END IF;
 RETURN NEW;
END $$;
ALTER TABLE os_proactive_runs DROP CONSTRAINT ck_proactive_run_limits;
ALTER TABLE os_proactive_runs DROP CONSTRAINT ck_proactive_run_state;
ALTER TABLE os_proactive_runs ADD CONSTRAINT ck_proactive_run_limits CHECK (definition_revision>0 AND generation>0 AND version>0 AND depth BETWEEN 0 AND 8 AND reserved_work_ms>0 AND tool_calls BETWEEN 1 AND 2 AND (actual_work_ms IS NULL OR actual_work_ms>=0) AND deadline>created_at);
ALTER TABLE os_proactive_runs ADD CONSTRAINT ck_proactive_run_state CHECK (state IN ('DUE','RUNNING','COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'));
ALTER TABLE os_proactive_runs DROP CONSTRAINT ck_proactive_run_execution_profile;
ALTER TABLE os_proactive_runs DROP COLUMN execution_profile;
ALTER TABLE os_proactive_definitions DROP CONSTRAINT ck_proactive_poll_observation;
ALTER TABLE os_proactive_definitions DROP CONSTRAINT ck_proactive_execution_profile;
ALTER TABLE os_proactive_definitions DROP COLUMN poll_observation;
ALTER TABLE os_proactive_definitions DROP COLUMN execution_profile;
''')
