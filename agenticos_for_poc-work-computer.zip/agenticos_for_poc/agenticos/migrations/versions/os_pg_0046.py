"""Current-reference classified learning, typed owner review and retractions."""
from alembic import op

revision = "os_pg_0046"
down_revision = "os_pg_0045"
branch_labels = None
depends_on = None

TABLES = ("\nCREATE TABLE classified_learning_job_snapshots (\n\tjob_id UUID NOT NULL, \n\tsettings_id UUID NOT NULL, \n\tcontext_revision BIGINT NOT NULL, \n\tcontext_refs JSONB NOT NULL, \n\tclaim_key_refs JSONB NOT NULL, \n\ttool_refs JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (job_id), \n\tCONSTRAINT fk_personal_learning_jobs_job_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, job_id) REFERENCES personal_learning_jobs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_learning_settings_settings_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, settings_id) REFERENCES personal_learning_settings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT ck_classified_job_snapshot_bounds CHECK (context_revision>0 AND jsonb_typeof(context_refs)='array' AND jsonb_array_length(context_refs)<=16 AND jsonb_typeof(claim_key_refs)='array' AND jsonb_array_length(claim_key_refs)<=32 AND jsonb_typeof(tool_refs)='array' AND jsonb_array_length(tool_refs)<=128 AND octet_length(context_refs::text)+octet_length(claim_key_refs::text)+octet_length(tool_refs::text)<=65536)\n)\n\n", '\nCREATE TABLE classified_learning_job_memory_refs (\n\tjob_id UUID NOT NULL, \n\tentry_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\tentry_version BIGINT NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (job_id, entry_id), \n\tCONSTRAINT fk_personal_learning_jobs_job_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, job_id) REFERENCES personal_learning_jobs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT ck_classified_job_memory_version CHECK (entry_version>0)\n)\n\n', "\nCREATE TABLE classified_knowledge_candidate_bindings (\n\tcandidate_revision_id UUID NOT NULL, \n\tcandidate_id UUID NOT NULL, \n\tjob_id UUID NOT NULL, \n\texpected_context_revision BIGINT NOT NULL, \n\toperation VARCHAR(16) NOT NULL, \n\tcontent_kind VARCHAR(24), \n\tcontext_id UUID, \n\tcontext_version BIGINT, \n\tclaim_key_id UUID, \n\tclaim_key_version BIGINT, \n\tworkflow_ref VARCHAR(256), \n\ttool_refs JSONB NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (candidate_revision_id), \n\tCONSTRAINT fk_personal_knowledge_candidate_revisions_candidate_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_revision_id) REFERENCES personal_knowledge_candidate_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_candidates_candidate_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_id) REFERENCES personal_knowledge_candidates (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_learning_jobs_job_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, job_id) REFERENCES personal_learning_jobs (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_owner_memory_contexts_context_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, context_id) REFERENCES owner_memory_contexts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_owner_memory_contexts_claim_key_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, claim_key_id) REFERENCES owner_memory_contexts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT ck_classified_candidate_binding_kind CHECK (expected_context_revision>0 AND operation IN ('add','supersede','merge','forget') AND jsonb_typeof(tool_refs)='array' AND jsonb_array_length(tool_refs)<=8 AND octet_length(tool_refs::text)<=8192 AND ((context_id IS NULL AND context_version IS NULL) OR (context_id IS NOT NULL AND context_version IS NOT NULL AND context_version>0)) AND ((claim_key_id IS NULL AND claim_key_version IS NULL) OR (claim_key_id IS NOT NULL AND claim_key_version IS NOT NULL AND claim_key_version>0)) AND ((operation='forget' AND content_kind IS NULL AND context_id IS NULL AND claim_key_id IS NULL AND workflow_ref IS NULL AND tool_refs='[]'::jsonb) OR (operation<>'forget' AND content_kind IS NOT NULL AND content_kind IN ('preference','personal-context','relationship-context','episode','procedure') AND ((content_kind IN ('preference','procedure'))=(claim_key_id IS NOT NULL)) AND ((content_kind='procedure' AND workflow_ref IS NOT NULL AND workflow_ref='registered-tool-sequence/1' AND jsonb_array_length(tool_refs)>0) OR (content_kind<>'procedure' AND workflow_ref IS NULL AND tool_refs='[]'::jsonb)))))\n)\n\n", '\nCREATE TABLE classified_knowledge_candidate_targets (\n\tcandidate_revision_id UUID NOT NULL, \n\tentry_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\texpected_entry_version BIGINT NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (candidate_revision_id, entry_id), \n\tCONSTRAINT fk_personal_knowledge_candidate_revisions_candidate_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_revision_id) REFERENCES personal_knowledge_candidate_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT ck_classified_candidate_target_version CHECK (expected_entry_version>0)\n)\n\n', '\nCREATE TABLE personal_knowledge_retractions (\n\tid UUID NOT NULL, \n\tdecision_id UUID NOT NULL, \n\tcandidate_id UUID NOT NULL, \n\tcandidate_revision_id UUID NOT NULL, \n\tentry_id UUID NOT NULL, \n\toperation_id UUID NOT NULL, \n\texpected_entry_version BIGINT NOT NULL, \n\taccepted_entry_version BIGINT NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_knowledge_retraction_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_candidate_decisions_decision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, decision_id) REFERENCES personal_candidate_decisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_candidates_candidate_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_id) REFERENCES personal_knowledge_candidates (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_candidate_revisions_candidate_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_revision_id) REFERENCES personal_knowledge_candidate_revisions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_operations_operation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, operation_id) REFERENCES personal_knowledge_operations (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_knowledge_retraction_decision UNIQUE (installation_id, application_id, tenant_id, subject_id, decision_id), \n\tCONSTRAINT uq_knowledge_retraction_operation UNIQUE (installation_id, application_id, tenant_id, subject_id, operation_id), \n\tCONSTRAINT ck_knowledge_retraction_version CHECK (expected_entry_version>0 AND accepted_entry_version=expected_entry_version+1)\n)\n\n', 'ALTER TABLE personal_learning_settings DROP CONSTRAINT ck_learning_settings_choice', "ALTER TABLE personal_learning_settings ADD CONSTRAINT ck_learning_settings_choice CHECK (COALESCE(jsonb_typeof(choice->'learnConversation')='boolean' AND jsonb_typeof(choice->'learnUsage')='boolean' AND jsonb_typeof(choice->'useMemory')='boolean' AND choice=jsonb_build_object('learnConversation',choice->'learnConversation','learnUsage',choice->'learnUsage','useMemory',choice->'useMemory','retentionProfile','private-local/1','extractorProfile',choice->'extractorProfile','embeddingProfile',choice->'embeddingProfile') AND choice->>'extractorProfile' IN ('synthetic-staging/1','classified-staging/2') AND choice->>'embeddingProfile' IN ('synthetic-embedding/1','minilm-english-onnx/1'),false))", 'ALTER TABLE personal_learning_source_intents DROP CONSTRAINT ck_learning_source_intent_profile', "ALTER TABLE personal_learning_source_intents ADD CONSTRAINT ck_learning_source_intent_profile CHECK (learning_epoch>0 AND extractor_ref IN ('synthetic-staging/1','classified-staging/2') AND state IN ('PENDING_DISPATCH','CANCELLED') AND max_source_chars=8000 AND max_candidates=8)", 'ALTER TABLE personal_learning_jobs DROP CONSTRAINT ck_learning_job_profile', "ALTER TABLE personal_learning_jobs ADD CONSTRAINT ck_learning_job_profile CHECK (((profile_ref='synthetic-staging/1' AND prompt_ref IN ('mem0-2.2.1-owner-source/1','mem0-2.2.1-accepted-source/2','mem0-2.2.1-usage-source/3')) OR (profile_ref='classified-staging/2' AND prompt_ref='mem0-2.2.1-classified-source/4')) AND source_mac ~ '^[a-f0-9]{64}$')")

GUARDS = r"""
CREATE FUNCTION os_learning_job_usage(jid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_learning_job_sources edge_row JOIN personal_learning_sources source_row
  ON source_row.id=edge_row.source_id WHERE edge_row.job_id=jid AND source_row.kind='usage-event/2')
$$;

CREATE FUNCTION os_classified_memory_current(eid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_knowledge_entries entry_row JOIN classified_knowledge_bindings binding_row
  ON binding_row.revision_id=entry_row.active_revision_id AND binding_row.entry_id=entry_row.id
  WHERE entry_row.id=eid AND entry_row.state IN ('ACTIVE','PAUSED')
   AND (entry_row.valid_until IS NULL OR entry_row.valid_until>clock_timestamp())
   AND os_revision_sources_current(entry_row.active_revision_id) AND os_classified_tools_current(entry_row.active_revision_id)
   AND (binding_row.context_id IS NULL OR EXISTS(SELECT 1 FROM owner_memory_contexts context_row
    WHERE context_row.id=binding_row.context_id AND context_row.kind='context' AND context_row.state='ACTIVE'))
   AND (binding_row.claim_key_id IS NULL OR EXISTS(SELECT 1 FROM owner_memory_contexts context_row
    WHERE context_row.id=binding_row.claim_key_id AND context_row.kind='claim-key' AND context_row.state='ACTIVE')))
$$;

CREATE FUNCTION os_assert_classified_job(jid uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE job_row personal_learning_jobs%ROWTYPE; snapshot_row classified_learning_job_snapshots%ROWTYPE;
 settings_row personal_learning_settings%ROWTYPE; app_row os_applications%ROWTYPE;
 contexts jsonb; claim_keys jsonb; tools jsonb;
BEGIN
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=jid;
 SELECT * INTO snapshot_row FROM classified_learning_job_snapshots WHERE job_id=jid;
 SELECT * INTO settings_row FROM personal_learning_settings WHERE id=job_row.settings_id;
 IF job_row.profile_ref IS DISTINCT FROM 'classified-staging/2' OR job_row.prompt_ref IS DISTINCT FROM 'mem0-2.2.1-classified-source/4'
  OR snapshot_row.job_id IS NULL OR snapshot_row.settings_id<>job_row.settings_id OR snapshot_row.created_at<>job_row.created_at
  OR ROW(snapshot_row.installation_id,snapshot_row.application_id,snapshot_row.tenant_id,snapshot_row.subject_id)
   IS DISTINCT FROM ROW(job_row.installation_id,job_row.application_id,job_row.tenant_id,job_row.subject_id)
  OR (SELECT count(*) FROM classified_learning_job_memory_refs WHERE job_id=jid)>64
  OR EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row JOIN personal_knowledge_revisions revision_row
   ON revision_row.id=ref_row.revision_id WHERE ref_row.job_id=jid AND revision_row.entry_id<>ref_row.entry_id)
  THEN RAISE EXCEPTION 'classified_job_snapshot_binding'; END IF;
 IF live THEN
  SELECT * INTO app_row FROM os_applications WHERE installation_id=job_row.installation_id AND id=job_row.application_id;
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',id,'revision',version) ORDER BY id),'[]'::jsonb) INTO contexts
   FROM owner_memory_contexts WHERE installation_id=job_row.installation_id AND application_id=job_row.application_id
    AND tenant_id=job_row.tenant_id AND subject_id=job_row.subject_id AND state='ACTIVE' AND kind='context';
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',id,'revision',version) ORDER BY id),'[]'::jsonb) INTO claim_keys
   FROM owner_memory_contexts WHERE installation_id=job_row.installation_id AND application_id=job_row.application_id
    AND tenant_id=job_row.tenant_id AND subject_id=job_row.subject_id AND state='ACTIVE' AND kind='claim-key';
  SELECT COALESCE(jsonb_agg(jsonb_build_object('id',capability->'descriptor'->'id','revision',capability->'descriptor'->'revision')
   ORDER BY (capability->'descriptor'->>'id') COLLATE "C",(capability->'descriptor'->>'revision')::bigint),'[]'::jsonb) INTO tools
   FROM os_registrations registration_row CROSS JOIN LATERAL jsonb_array_elements(registration_row.payload->'capabilities') capability
   WHERE registration_row.installation_id=job_row.installation_id AND registration_row.application_id=job_row.application_id
    AND registration_row.revision=app_row.revision AND capability->'descriptor'->>'kind'='read';
  IF snapshot_row.context_revision<>settings_row.context_revision OR snapshot_row.context_refs IS DISTINCT FROM contexts
   OR snapshot_row.claim_key_refs IS DISTINCT FROM claim_keys OR snapshot_row.tool_refs IS DISTINCT FROM tools
   OR EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row JOIN personal_knowledge_entries entry_row
    ON entry_row.id=ref_row.entry_id WHERE ref_row.job_id=jid
     AND (entry_row.version<>ref_row.entry_version OR entry_row.active_revision_id<>ref_row.revision_id
      OR NOT os_classified_memory_current(entry_row.id)))
   OR EXISTS(SELECT 1 FROM personal_knowledge_entries entry_row WHERE entry_row.installation_id=job_row.installation_id
    AND entry_row.application_id=job_row.application_id AND entry_row.tenant_id=job_row.tenant_id AND entry_row.subject_id=job_row.subject_id
    AND os_classified_memory_current(entry_row.id) AND NOT EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row
     WHERE ref_row.job_id=jid AND ref_row.entry_id=entry_row.id))
   THEN RAISE EXCEPTION 'classified_job_current_snapshot'; END IF;
 END IF;
END $$;

CREATE FUNCTION os_commit_classified_job() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE job_row personal_learning_jobs%ROWTYPE;
BEGIN
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=NEW.job_id;
 IF job_row.state IS DISTINCT FROM 'QUEUED' THEN RAISE EXCEPTION 'classified_job_initial_snapshot'; END IF;
 PERFORM os_assert_classified_job(NEW.job_id,true);
 RETURN NULL;
END $$;

CREATE FUNCTION os_assert_classified_candidate(rid uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE binding_row classified_knowledge_candidate_bindings%ROWTYPE; revision_row personal_knowledge_candidate_revisions%ROWTYPE;
 candidate_row personal_knowledge_candidates%ROWTYPE; job_row personal_learning_jobs%ROWTYPE;
 snapshot_row classified_learning_job_snapshots%ROWTYPE; decision_row personal_candidate_decisions%ROWTYPE;
 target_count bigint; registration_row os_registrations%ROWTYPE; app_row os_applications%ROWTYPE;
BEGIN
 SELECT * INTO binding_row FROM classified_knowledge_candidate_bindings WHERE candidate_revision_id=rid;
 SELECT * INTO revision_row FROM personal_knowledge_candidate_revisions WHERE id=rid;
 SELECT * INTO candidate_row FROM personal_knowledge_candidates WHERE id=revision_row.candidate_id;
 SELECT * INTO job_row FROM personal_learning_jobs WHERE id=candidate_row.job_id;
 SELECT * INTO snapshot_row FROM classified_learning_job_snapshots WHERE job_id=job_row.id;
 SELECT * INTO decision_row FROM personal_candidate_decisions WHERE candidate_revision_id=rid;
 SELECT count(*) INTO target_count FROM classified_knowledge_candidate_targets WHERE candidate_revision_id=rid;
 IF binding_row.candidate_revision_id IS NULL OR binding_row.candidate_id<>candidate_row.id OR binding_row.job_id<>job_row.id
  OR job_row.profile_ref IS DISTINCT FROM 'classified-staging/2' OR job_row.state IS DISTINCT FROM 'SUCCEEDED'
  OR binding_row.created_at<>revision_row.created_at OR snapshot_row.job_id IS NULL
  OR (revision_row.ordinal=1 AND binding_row.expected_context_revision<>snapshot_row.context_revision)
  OR NOT ((binding_row.operation='add' AND target_count=0) OR (binding_row.operation IN ('supersede','forget') AND target_count=1)
   OR (binding_row.operation='merge' AND target_count BETWEEN 2 AND 8))
  OR EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row JOIN personal_knowledge_revisions knowledge_revision
   ON knowledge_revision.id=target_row.revision_id WHERE target_row.candidate_revision_id=rid AND knowledge_revision.entry_id<>target_row.entry_id)
  OR (revision_row.ordinal=1 AND EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row
   WHERE target_row.candidate_revision_id=rid AND NOT EXISTS(SELECT 1 FROM classified_learning_job_memory_refs ref_row
    WHERE ref_row.job_id=job_row.id AND ROW(ref_row.entry_id,ref_row.revision_id,ref_row.entry_version)
     =ROW(target_row.entry_id,target_row.revision_id,target_row.expected_entry_version))))
  THEN RAISE EXCEPTION 'classified_candidate_binding'; END IF;
 IF live THEN
  IF (binding_row.context_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts context_row
    WHERE context_row.id=binding_row.context_id AND context_row.state='ACTIVE' AND context_row.kind='context'
     AND context_row.version=binding_row.context_version))
   OR (binding_row.claim_key_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM owner_memory_contexts context_row
    WHERE context_row.id=binding_row.claim_key_id AND context_row.state='ACTIVE' AND context_row.kind='claim-key'
     AND context_row.version=binding_row.claim_key_version))
   OR EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row JOIN personal_knowledge_entries entry_row
    ON entry_row.id=target_row.entry_id WHERE target_row.candidate_revision_id=rid AND NOT (
     (entry_row.version=target_row.expected_entry_version AND entry_row.active_revision_id=target_row.revision_id
      AND os_classified_memory_current(entry_row.id))
     OR (decision_row.id IS NOT NULL AND decision_row.decision<>'reject' AND EXISTS(SELECT 1 FROM personal_knowledge_supersessions supersession_row
      JOIN personal_knowledge_publications publication_row ON publication_row.id=supersession_row.publication_id
      WHERE publication_row.decision_id=decision_row.id AND supersession_row.entry_id=entry_row.id
       AND supersession_row.revision_id=target_row.revision_id AND supersession_row.expected_version=target_row.expected_entry_version
       AND supersession_row.accepted_version=entry_row.version AND entry_row.state='SUPERSEDED'))
     OR (decision_row.id IS NOT NULL AND decision_row.decision<>'reject' AND EXISTS(SELECT 1 FROM personal_knowledge_retractions retraction_row
      WHERE retraction_row.decision_id=decision_row.id AND retraction_row.entry_id=entry_row.id
       AND retraction_row.expected_entry_version=target_row.expected_entry_version
       AND retraction_row.accepted_entry_version=entry_row.version AND entry_row.state='FORGOTTEN'))))
   THEN RAISE EXCEPTION 'classified_candidate_current_references'; END IF;
  SELECT * INTO app_row FROM os_applications WHERE installation_id=candidate_row.installation_id AND id=candidate_row.application_id;
  SELECT * INTO registration_row FROM os_registrations WHERE installation_id=app_row.installation_id
   AND application_id=app_row.id AND revision=app_row.revision;
  IF EXISTS(SELECT 1 FROM jsonb_array_elements(binding_row.tool_refs) tool WHERE NOT EXISTS(
   SELECT 1 FROM jsonb_array_elements(registration_row.payload->'capabilities') capability
    WHERE capability->'descriptor'->>'kind'='read' AND capability->'descriptor'->>'id'=tool->>'id'
     AND capability->'descriptor'->'revision'=tool->'revision'))
   THEN RAISE EXCEPTION 'classified_candidate_current_tools'; END IF;
 END IF;
END $$;

CREATE FUNCTION os_assert_classified_publication(did uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE decision_row personal_candidate_decisions%ROWTYPE; binding_row classified_knowledge_candidate_bindings%ROWTYPE;
 publication_row personal_knowledge_publications%ROWTYPE; canonical_binding classified_knowledge_bindings%ROWTYPE;
 retraction_row personal_knowledge_retractions%ROWTYPE; operation_row personal_knowledge_operations%ROWTYPE;
 retraction_target classified_knowledge_candidate_targets%ROWTYPE;
BEGIN
 SELECT * INTO decision_row FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO binding_row FROM classified_knowledge_candidate_bindings WHERE candidate_revision_id=decision_row.candidate_revision_id;
 SELECT * INTO publication_row FROM personal_knowledge_publications WHERE decision_id=did;
 SELECT * INTO retraction_row FROM personal_knowledge_retractions WHERE decision_id=did;
 IF binding_row.candidate_revision_id IS NULL THEN RAISE EXCEPTION 'classified_review_binding'; END IF;
 IF decision_row.decision='reject' THEN
  IF publication_row.id IS NOT NULL OR retraction_row.id IS NOT NULL THEN RAISE EXCEPTION 'classified_rejection_write'; END IF;
 ELSIF binding_row.operation='forget' THEN
  SELECT * INTO operation_row FROM personal_knowledge_operations WHERE id=retraction_row.operation_id;
  SELECT * INTO retraction_target FROM classified_knowledge_candidate_targets WHERE candidate_revision_id=binding_row.candidate_revision_id;
  IF publication_row.id IS NOT NULL OR retraction_row.id IS NULL OR retraction_row.candidate_id<>decision_row.candidate_id
   OR retraction_row.candidate_revision_id<>decision_row.candidate_revision_id OR retraction_row.created_at<>decision_row.created_at
   OR operation_row.kind IS DISTINCT FROM 'FORGET' OR operation_row.entry_id<>retraction_row.entry_id
   OR operation_row.command_id<>decision_row.command_id OR operation_row.session_id<>decision_row.session_id
   OR operation_row.context_revision<>decision_row.context_revision OR operation_row.created_at<>decision_row.created_at
   OR operation_row.expected_version<>retraction_row.expected_entry_version OR operation_row.accepted_version<>retraction_row.accepted_entry_version
   OR retraction_target.entry_id<>retraction_row.entry_id OR retraction_target.expected_entry_version<>retraction_row.expected_entry_version
   THEN RAISE EXCEPTION 'classified_atomic_retraction'; END IF;
 ELSE
  SELECT * INTO canonical_binding FROM classified_knowledge_bindings WHERE revision_id=publication_row.revision_id;
  IF retraction_row.id IS NOT NULL OR publication_row.id IS NULL OR publication_row.operation<>binding_row.operation
   OR canonical_binding.revision_id IS NULL OR canonical_binding.entry_id<>publication_row.entry_id
   OR ROW(canonical_binding.content_kind,canonical_binding.context_id,canonical_binding.claim_key_id,canonical_binding.workflow_ref,canonical_binding.tool_refs)
    IS DISTINCT FROM ROW(binding_row.content_kind,binding_row.context_id,binding_row.claim_key_id,binding_row.workflow_ref,binding_row.tool_refs)
   OR (SELECT count(*) FROM classified_knowledge_candidate_targets WHERE candidate_revision_id=binding_row.candidate_revision_id)<>publication_row.target_count
   OR EXISTS(SELECT 1 FROM classified_knowledge_candidate_targets target_row WHERE target_row.candidate_revision_id=binding_row.candidate_revision_id
    AND NOT EXISTS(SELECT 1 FROM personal_knowledge_supersessions supersession_row WHERE supersession_row.publication_id=publication_row.id
     AND ROW(supersession_row.entry_id,supersession_row.revision_id,supersession_row.expected_version)
      =ROW(target_row.entry_id,target_row.revision_id,target_row.expected_entry_version)))
   THEN RAISE EXCEPTION 'classified_atomic_publication'; END IF;
 END IF;
END $$;

CREATE FUNCTION os_commit_classified_candidate() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE rid uuid; decision_row personal_candidate_decisions%ROWTYPE;
BEGIN
 rid=NEW.candidate_revision_id;
 SELECT * INTO decision_row FROM personal_candidate_decisions WHERE candidate_revision_id=rid;
 PERFORM os_assert_classified_candidate(rid,decision_row.id IS NULL OR decision_row.decision<>'reject');
 IF TG_TABLE_NAME='personal_knowledge_retractions' THEN
  PERFORM os_assert_candidate_decision(NEW.decision_id,true);
 END IF;
 RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION os_assert_learning_job_live(j personal_learning_jobs) RETURNS void LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=j.installation_id AND id=j.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=j.installation_id AND application_id=j.application_id
  AND tenant_id=j.tenant_id AND subject_id=j.subject_id;
 IF s.id IS NULL OR s.learning_epoch<>j.learning_epoch OR s.choice->(CASE WHEN os_learning_job_usage(j.id) THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb
  OR s.choice->>'extractorProfile'<>j.profile_ref OR app.id IS NULL OR NOT app.active OR owner.id IS NULL OR NOT owner.active
  OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
  OR j.expires_at<=clock_timestamp() OR j.account_valid_until<=clock_timestamp()
  OR j.account_checked_at<clock_timestamp()-interval '5 seconds'
  OR j.account_checked_at>clock_timestamp()+interval '5 seconds'
  OR NOT EXISTS(SELECT 1 FROM personal_learning_job_sources WHERE job_id=j.id)
  OR EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id
   JOIN personal_learning_source_intents i ON i.id=e.intent_id WHERE e.job_id=j.id
    AND (r.settings_id<>j.settings_id OR r.state<>'AVAILABLE' OR r.revision<>e.source_revision
     OR r.learning_epoch<>j.learning_epoch OR r.expires_at<=clock_timestamp() OR r.envelope IS NULL
     OR i.source_id<>r.id OR i.learning_epoch<>j.learning_epoch OR i.state<>'PENDING_DISPATCH'
     OR i.extractor_ref<>j.profile_ref OR i.due_at>j.created_at
     OR NOT COALESCE(os_selected_learning_source_current(r.id),false)
     OR (j.prompt_ref='mem0-2.2.1-owner-source/1' AND r.kind<>'owner-statement/1')
     OR (j.prompt_ref='mem0-2.2.1-accepted-source/2' AND r.kind NOT IN ('accepted-user-turn/1','accepted-outcome/1'))
     OR (os_learning_job_usage(j.id) AND r.kind<>'usage-event/2')))
  OR (SELECT count(DISTINCT r.kind) FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id WHERE e.job_id=j.id)<>1
 OR (os_learning_job_usage(j.id) AND NOT COALESCE(os_usage_batch_current(j.id),false))
 THEN RAISE EXCEPTION 'learning_job_current_authority'; END IF;
 IF j.profile_ref='classified-staging/2' THEN PERFORM os_assert_classified_job(j.id,true); END IF;
END $$;
CREATE OR REPLACE FUNCTION os_assert_learning_source(sid uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE s personal_learning_sources%ROWTYPE; j personal_learning_source_intents%ROWTYPE;
 f personal_learning_source_forgets%ROWTYPE; settings personal_learning_settings%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO settings FROM personal_learning_settings WHERE id=s.settings_id;
 SELECT * INTO j FROM personal_learning_source_intents WHERE source_id=sid;
 SELECT * INTO f FROM personal_learning_source_forgets WHERE source_id=sid;
 IF s.id IS NULL OR settings.id IS NULL OR j.id IS NULL OR j.learning_epoch<>s.learning_epoch
  OR j.created_at<>s.created_at OR j.extractor_ref NOT IN ('synthetic-staging/1','classified-staging/2')
  OR s.receipt IS DISTINCT FROM jsonb_build_object('commandId',s.command_id,'sourceId',s.id,
   'revision',1,'learningEpoch',s.learning_epoch,'extractionState','PENDING_DISPATCH')
  THEN RAISE EXCEPTION 'learning_source_atomic_intent'; END IF;
 IF s.state='AVAILABLE' THEN
  IF f.id IS NOT NULL OR s.envelope IS NULL THEN RAISE EXCEPTION 'learning_source_live'; END IF;
 ELSE
  IF f.id IS NULL OR j.state<>'CANCELLED' OR f.learning_epoch<>s.learning_epoch OR f.created_at<>s.updated_at
   OR f.receipt IS DISTINCT FROM jsonb_build_object('commandId',f.command_id,'operationId',f.id,
    'sourceId',s.id,'revision',2,'state','FORGOTTEN')
   OR (f.completed_at IS NULL AND s.envelope IS NULL)
   OR (f.completed_at IS NOT NULL AND (s.envelope IS NOT NULL OR s.request_mac IS NOT NULL OR s.mac_key_id IS NOT NULL))
   THEN RAISE EXCEPTION 'learning_source_forget_atomic'; END IF;
 END IF;
END $$;
CREATE OR REPLACE FUNCTION os_usage_batch_current(jid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_usage_batches b JOIN personal_learning_jobs j ON j.id=b.job_id
  WHERE j.id=jid AND ((j.profile_ref='synthetic-staging/1' AND j.prompt_ref='mem0-2.2.1-usage-source/3') OR (j.profile_ref='classified-staging/2' AND j.prompt_ref='mem0-2.2.1-classified-source/4')) AND j.created_at=b.created_at)
 AND (SELECT count(*)>=3
  FROM personal_learning_job_sources e JOIN personal_usage_origins o ON o.source_id=e.source_id WHERE e.job_id=jid)
 AND (SELECT count(DISTINCT (o.occurred_at AT TIME ZONE 'UTC')::date)>=2
  AND count(DISTINCT o.signal_mac)=1 AND count(DISTINCT o.profile_id)=1
  FROM personal_learning_job_sources e JOIN personal_usage_origins o ON o.source_id=e.source_id WHERE e.job_id=jid)
 AND NOT EXISTS(SELECT 1 FROM personal_learning_job_sources e WHERE e.job_id=jid AND NOT os_usage_source_current(e.source_id))
$$;
CREATE FUNCTION os_assert_legacy_candidate_decision(did uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE d personal_candidate_decisions%ROWTYPE; c personal_knowledge_candidates%ROWTYPE;
 r personal_knowledge_candidate_revisions%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 s personal_learning_settings%ROWTYPE; p personal_knowledge_publications%ROWTYPE;
 op personal_knowledge_operations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; expected jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO d FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=d.candidate_id;
 SELECT * INTO r FROM personal_knowledge_candidate_revisions WHERE id=d.candidate_revision_id;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO p FROM personal_knowledge_publications WHERE decision_id=d.id;
 IF d.id IS NULL OR c.id IS NULL OR r.id IS NULL OR j.state IS DISTINCT FROM 'SUCCEEDED' OR s.id IS NULL
  OR r.candidate_id<>c.id OR r.ordinal<>d.accepted_version OR c.version<>d.accepted_version
  OR c.state<>(CASE WHEN d.decision='reject' THEN 'REJECTED' ELSE 'ACCEPTED' END)
  OR c.updated_at<>d.created_at OR d.context_revision>s.context_revision
  OR (r.envelope IS NULL AND NOT os_candidate_erasure_allowed(c.id))
  THEN RAISE EXCEPTION 'candidate_decision_binding'; END IF;
 IF d.decision='reject' THEN
  IF p.id IS NOT NULL THEN RAISE EXCEPTION 'candidate_rejection_publication'; END IF;
  expected='null'::jsonb;
 ELSE
  SELECT * INTO op FROM personal_knowledge_operations WHERE id=p.operation_id;
  IF p.id IS NULL OR p.candidate_id<>c.id OR p.candidate_revision_id<>r.id OR p.created_at<>d.created_at
   OR op.id IS NULL OR op.kind<>'SAVE' OR op.entry_id<>p.entry_id OR op.command_id<>d.command_id
   OR op.session_id<>d.session_id OR op.context_revision<>d.context_revision OR op.created_at<>d.created_at
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions kr WHERE kr.id=p.revision_id AND kr.entry_id=p.entry_id AND kr.operation_id=op.id)
   OR (SELECT count(*) FROM personal_knowledge_supersessions WHERE publication_id=p.id)<>p.target_count
   THEN RAISE EXCEPTION 'candidate_atomic_publication'; END IF;
  IF p.epistemic IS DISTINCT FROM (CASE WHEN d.decision='edit-and-accept' THEN 'user-stated'
    WHEN j.prompt_ref='mem0-2.2.1-usage-source/3' THEN 'behavior-inferred'
    WHEN EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources source_row ON source_row.id=e.source_id
     WHERE e.job_id=j.id AND source_row.kind='accepted-outcome/1') THEN 'derived-outcome' ELSE 'user-stated' END)
   THEN RAISE EXCEPTION 'candidate_epistemic_origin'; END IF;
  expected=op.receipt;
 END IF;
 IF d.receipt IS DISTINCT FROM jsonb_build_object('commandId',d.command_id,'decisionId',d.id,'candidateId',c.id,
  'candidateRevision',c.version,'state',c.state,'contextRevision',d.context_revision,'knowledge',expected)
  THEN RAISE EXCEPTION 'candidate_atomic_receipt'; END IF;
 IF live THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE id=d.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=d.installation_id AND application_id=d.application_id
   AND tenant_id=d.tenant_id AND subject_id=d.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp() OR d.request_mac IS NULL
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation OR owner.id IS NULL
   OR NOT owner.active OR owner.generation<>session.subject_generation OR c.expires_at<=clock_timestamp()
   OR os_learning_candidate_invalid(c.id) THEN RAISE EXCEPTION 'candidate_current_review'; END IF;
  IF d.decision<>'reject' THEN
   IF s.context_revision<>d.context_revision OR s.updated_at<>d.created_at OR s.learning_epoch<>j.learning_epoch
    OR s.choice->(CASE WHEN j.prompt_ref='mem0-2.2.1-usage-source/3' THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb OR s.choice->>'extractorProfile'<>j.profile_ref
    OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
     IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
    THEN RAISE EXCEPTION 'candidate_current_learning'; END IF;
   PERFORM os_assert_knowledge_entry(p.entry_id,true);
  END IF;
 END IF;
END $$;
CREATE FUNCTION os_assert_classified_candidate_decision(did uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE d personal_candidate_decisions%ROWTYPE; c personal_knowledge_candidates%ROWTYPE;
 r personal_knowledge_candidate_revisions%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 s personal_learning_settings%ROWTYPE; p personal_knowledge_publications%ROWTYPE;
 op personal_knowledge_operations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; expected jsonb; retraction_row personal_knowledge_retractions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO d FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=d.candidate_id;
 SELECT * INTO r FROM personal_knowledge_candidate_revisions WHERE id=d.candidate_revision_id;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO p FROM personal_knowledge_publications WHERE decision_id=d.id;
 SELECT * INTO retraction_row FROM personal_knowledge_retractions WHERE decision_id=d.id;
 IF d.id IS NULL OR c.id IS NULL OR r.id IS NULL OR j.state IS DISTINCT FROM 'SUCCEEDED' OR s.id IS NULL
  OR r.candidate_id<>c.id OR r.ordinal<>d.accepted_version OR c.version<>d.accepted_version
  OR c.state<>(CASE WHEN d.decision='reject' THEN 'REJECTED' ELSE 'ACCEPTED' END)
  OR c.updated_at<>d.created_at OR d.context_revision>s.context_revision
  OR (r.envelope IS NULL AND NOT os_candidate_erasure_allowed(c.id))
  THEN RAISE EXCEPTION 'candidate_decision_binding'; END IF;
 PERFORM os_assert_classified_candidate(r.id,live AND d.decision<>'reject');
 PERFORM os_assert_classified_publication(d.id);
 IF d.decision='reject' THEN
  IF p.id IS NOT NULL OR retraction_row.id IS NOT NULL THEN RAISE EXCEPTION 'candidate_rejection_publication'; END IF;
  expected='null'::jsonb;
 ELSE
  IF retraction_row.id IS NOT NULL THEN
   SELECT * INTO op FROM personal_knowledge_operations WHERE id=retraction_row.operation_id;
  ELSE
  SELECT * INTO op FROM personal_knowledge_operations WHERE id=p.operation_id;
  IF p.id IS NULL OR p.candidate_id<>c.id OR p.candidate_revision_id<>r.id OR p.created_at<>d.created_at
   OR op.id IS NULL OR op.kind<>'SAVE' OR op.entry_id<>p.entry_id OR op.command_id<>d.command_id
   OR op.session_id<>d.session_id OR op.context_revision<>d.context_revision OR op.created_at<>d.created_at
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions kr WHERE kr.id=p.revision_id AND kr.entry_id=p.entry_id AND kr.operation_id=op.id)
   OR (SELECT count(*) FROM personal_knowledge_supersessions WHERE publication_id=p.id)<>p.target_count
   THEN RAISE EXCEPTION 'candidate_atomic_publication'; END IF;
  IF p.epistemic IS DISTINCT FROM (CASE WHEN d.decision='edit-and-accept' THEN 'user-stated'
    WHEN os_learning_job_usage(j.id) THEN 'behavior-inferred'
    WHEN EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources source_row ON source_row.id=e.source_id
     WHERE e.job_id=j.id AND source_row.kind='accepted-outcome/1') THEN 'derived-outcome' ELSE 'user-stated' END)
   THEN RAISE EXCEPTION 'candidate_epistemic_origin'; END IF;
  END IF;
  expected=op.receipt;
 END IF;
 IF d.receipt IS DISTINCT FROM jsonb_build_object('commandId',d.command_id,'decisionId',d.id,'candidateId',c.id,
  'candidateRevision',c.version,'state',c.state,'contextRevision',d.context_revision,'knowledge',expected)
  THEN RAISE EXCEPTION 'candidate_atomic_receipt'; END IF;
 IF live THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE id=d.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=d.installation_id AND application_id=d.application_id
   AND tenant_id=d.tenant_id AND subject_id=d.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp() OR d.request_mac IS NULL
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation OR owner.id IS NULL
   OR NOT owner.active OR owner.generation<>session.subject_generation OR c.expires_at<=clock_timestamp()
   OR os_learning_candidate_invalid(c.id) THEN RAISE EXCEPTION 'candidate_current_review'; END IF;
  IF d.decision<>'reject' THEN
   IF s.context_revision<>d.context_revision OR s.updated_at<>d.created_at OR s.learning_epoch<>j.learning_epoch
    OR s.choice->(CASE WHEN os_learning_job_usage(j.id) THEN 'learnUsage' ELSE 'learnConversation' END) IS DISTINCT FROM 'true'::jsonb OR s.choice->>'extractorProfile'<>j.profile_ref
    OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
     IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
    THEN RAISE EXCEPTION 'candidate_current_learning'; END IF;
   PERFORM os_assert_knowledge_entry(COALESCE(p.entry_id,retraction_row.entry_id),true);
  END IF;
 END IF;
END $$;
CREATE OR REPLACE FUNCTION os_assert_candidate_decision(did uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE profile text;
BEGIN
 SELECT job_row.profile_ref INTO profile FROM personal_candidate_decisions decision_row
  JOIN personal_knowledge_candidates candidate_row ON candidate_row.id=decision_row.candidate_id
  JOIN personal_learning_jobs job_row ON job_row.id=candidate_row.job_id WHERE decision_row.id=did;
 IF profile='classified-staging/2' THEN PERFORM os_assert_classified_candidate_decision(did,live);
 ELSE PERFORM os_assert_legacy_candidate_decision(did,live); END IF;
END $$;

CREATE OR REPLACE FUNCTION os_learning_candidate_invalid(cid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e JOIN personal_learning_sources s ON s.id=e.source_id
  WHERE e.candidate_id=cid AND (s.state<>'AVAILABLE' OR s.revision<>e.source_revision OR s.expires_at<=clock_timestamp() OR NOT COALESCE(os_selected_learning_source_current(s.id),false)))
 OR EXISTS(SELECT 1 FROM personal_knowledge_candidates candidate_row
  JOIN personal_knowledge_candidate_revisions revision_row ON revision_row.candidate_id=candidate_row.id
  JOIN classified_knowledge_candidate_targets target_row ON target_row.candidate_revision_id=revision_row.id
  JOIN personal_knowledge_entries entry_row ON entry_row.id=target_row.entry_id
  WHERE candidate_row.id=cid AND candidate_row.state IN ('PENDING_REVIEW','INVALIDATED') AND entry_row.state='FORGOTTEN')
$$;
CREATE OR REPLACE FUNCTION os_candidate_erasure_allowed(cid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT os_learning_candidate_invalid(cid) OR EXISTS(SELECT 1 FROM personal_knowledge_publications p
 JOIN personal_knowledge_entries e ON e.id=p.entry_id WHERE p.candidate_id=cid AND e.state='FORGOTTEN')
 OR EXISTS(SELECT 1 FROM personal_knowledge_retractions retraction_row JOIN personal_knowledge_entries entry_row
  ON entry_row.id=retraction_row.entry_id WHERE retraction_row.candidate_id=cid AND entry_row.state='FORGOTTEN')
$$;
CREATE OR REPLACE FUNCTION os_guard_learning_candidate_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid; c personal_knowledge_candidates%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 n bigint; d personal_candidate_decisions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_knowledge_candidates' THEN cid=NEW.id;ELSE cid=NEW.candidate_id;END IF;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=cid;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT count(*) INTO n FROM personal_knowledge_candidate_sources WHERE candidate_id=cid;
 IF c.id IS NULL OR j.state<>'SUCCEEDED' OR c.ordinal>j.result_count OR n NOT BETWEEN 1 AND 20
  OR NOT EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND ordinal=c.version)
  OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e WHERE e.candidate_id=cid AND NOT EXISTS(
   SELECT 1 FROM personal_learning_job_sources r WHERE r.job_id=j.id AND r.source_id=e.source_id AND r.source_revision=e.source_revision))
  THEN RAISE EXCEPTION 'learning_candidate_atomic_provenance'; END IF;

 IF j.profile_ref='classified-staging/2' THEN
  IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions revision_row WHERE revision_row.candidate_id=cid
   AND NOT EXISTS(SELECT 1 FROM classified_knowledge_candidate_bindings binding_row WHERE binding_row.candidate_revision_id=revision_row.id))
   THEN RAISE EXCEPTION 'classified_candidate_revision_binding_missing'; END IF;
 END IF;
 IF c.state IN ('ACCEPTED','REJECTED') THEN
  SELECT * INTO d FROM personal_candidate_decisions WHERE candidate_id=c.id;
  IF d.id IS NULL THEN RAISE EXCEPTION 'candidate_decision_missing'; END IF;
  IF os_candidate_erasure_allowed(cid) AND EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL) THEN
   IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
    OR d.request_mac IS NOT NULL THEN RAISE EXCEPTION 'candidate_cleanup_incomplete'; END IF;
   PERFORM os_assert_candidate_decision(d.id,false);
  ELSE PERFORM os_assert_candidate_decision(d.id,true);END IF;
 ELSIF TG_OP='INSERT' THEN
  IF c.state<>'PENDING_REVIEW' OR c.version<>1 OR c.created_at<>j.updated_at
   OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL)
   THEN RAISE EXCEPTION 'learning_candidate_result_binding'; END IF;
  PERFORM os_assert_learning_job_live(j);
 ELSE
  IF c.state<>'INVALIDATED' OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
   THEN RAISE EXCEPTION 'learning_candidate_cleanup_incomplete'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE TRIGGER guard_classified_job_snapshot BEFORE UPDATE OR DELETE ON classified_learning_job_snapshots
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_classified_job_snapshot AFTER INSERT ON classified_learning_job_snapshots
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_classified_job();

CREATE TRIGGER guard_classified_job_memory BEFORE UPDATE OR DELETE ON classified_learning_job_memory_refs
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_classified_job_memory AFTER INSERT ON classified_learning_job_memory_refs
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_classified_job();

CREATE TRIGGER guard_classified_candidate_binding BEFORE UPDATE OR DELETE ON classified_knowledge_candidate_bindings
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_classified_candidate_binding AFTER INSERT ON classified_knowledge_candidate_bindings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_classified_candidate();

CREATE TRIGGER guard_classified_candidate_target BEFORE UPDATE OR DELETE ON classified_knowledge_candidate_targets
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_classified_candidate_target AFTER INSERT ON classified_knowledge_candidate_targets
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_classified_candidate();

CREATE TRIGGER guard_knowledge_retraction BEFORE UPDATE OR DELETE ON personal_knowledge_retractions
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE CONSTRAINT TRIGGER commit_knowledge_retraction AFTER INSERT ON personal_knowledge_retractions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_classified_candidate();

"""

def upgrade():
    for statement in TABLES:
        op.get_bind().exec_driver_sql(statement)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError("Use the protected additive recovery plan; populated memory is retained")
