"""Draft registered business-key coordination for reviewed production effects.

Not applied or frozen. SQL/source, protected positive/negative runtime,
rollback/forward and independent0079 recovery gates remain required.
"""
from alembic import op

revision='os_pg_0080'
down_revision='os_pg_0079'
branch_labels=None
depends_on=None

TABLES=r"""
CREATE TABLE os_agent_write_conflict_policies (
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	policy_digest VARCHAR(64) NOT NULL, 
	application_generation BIGINT NOT NULL, 
	registration_revision BIGINT NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	payload JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (installation_id, application_id, policy_digest), 
	CONSTRAINT fk_agent_write_policy_app FOREIGN KEY(installation_id, application_id) REFERENCES os_applications (installation_id, id), 
	CONSTRAINT ck_agent_write_policy_bounds CHECK (application_generation>0 AND registration_revision>0 AND jsonb_typeof(payload)='object' AND octet_length(payload::text)<=65536), 
	CONSTRAINT ck_agent_write_policy_pin_digest CHECK (policy_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_write_policy_digest CHECK (digest ~ '^[a-f0-9]{64}$')
);

CREATE TABLE os_agent_write_conflict_roots (
	id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	policy_digest VARCHAR(64) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_write_root_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_budget_roots_root_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_id) REFERENCES os_budget_roots (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_write_root_policy FOREIGN KEY(installation_id, application_id, policy_digest) REFERENCES os_agent_write_conflict_policies (installation_id, application_id, policy_digest), 
	CONSTRAINT uq_agent_write_root UNIQUE (installation_id, application_id, tenant_id, subject_id, root_id), 
	CONSTRAINT uq_agent_write_root_fence UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id)
);

CREATE TABLE os_agent_write_conflict_bindings (
	id UUID NOT NULL, 
	root_binding_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	decision_id UUID NOT NULL, 
	attempt_id UUID, 
	grant_digest VARCHAR(64) NOT NULL, 
	keys_digest VARCHAR(64) NOT NULL, 
	keys JSONB NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	version BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	begun_at TIMESTAMP WITH TIME ZONE, 
	released_at TIMESTAMP WITH TIME ZONE, 
	receipt_id UUID, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_write_binding_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_review_decisions_decision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, decision_id) REFERENCES os_agent_review_decisions (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_work_attempts_attempt_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id) REFERENCES os_work_attempts (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_agent_effect_receipts_receipt_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, receipt_id) REFERENCES os_agent_effect_receipts (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_write_binding_root FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, root_binding_id, root_id) REFERENCES os_agent_write_conflict_roots (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT uq_agent_write_binding_decision UNIQUE (installation_id, application_id, tenant_id, subject_id, decision_id), 
	CONSTRAINT uq_agent_write_binding_attempt UNIQUE (installation_id, application_id, tenant_id, subject_id, attempt_id), 
	CONSTRAINT uq_agent_write_binding_fence UNIQUE (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT ck_agent_write_binding_grant_digest CHECK (grant_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_write_binding_keys_digest CHECK (keys_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_write_binding_state CHECK (state IN ('WAITING','RESERVED','RUNNING','RELEASED','CANCELLED') AND version>0 AND jsonb_typeof(keys)='object' AND octet_length(keys::text)<=16384 AND ((state='WAITING' AND attempt_id IS NULL AND begun_at IS NULL AND released_at IS NULL AND receipt_id IS NULL) OR (state='RESERVED' AND attempt_id IS NOT NULL AND begun_at IS NULL AND released_at IS NULL AND receipt_id IS NULL) OR (state='RUNNING' AND attempt_id IS NOT NULL AND begun_at IS NOT NULL AND released_at IS NULL AND receipt_id IS NULL) OR (state='RELEASED' AND attempt_id IS NOT NULL AND begun_at IS NOT NULL AND released_at IS NOT NULL AND receipt_id IS NOT NULL) OR (state='CANCELLED' AND begun_at IS NULL AND released_at IS NOT NULL AND receipt_id IS NULL)))
);

CREATE TABLE os_agent_write_conflict_claims (
	id UUID NOT NULL, 
	binding_id UUID NOT NULL, 
	root_id UUID NOT NULL, 
	namespace_digest VARCHAR(64) NOT NULL, 
	key_digest VARCHAR(64) NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_write_claim_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_agent_write_claim_binding FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, binding_id, root_id) REFERENCES os_agent_write_conflict_bindings (installation_id, application_id, tenant_id, subject_id, id, root_id), 
	CONSTRAINT uq_agent_write_claim_member UNIQUE (installation_id, application_id, tenant_id, subject_id, binding_id, namespace_digest, key_digest), 
	CONSTRAINT ck_agent_write_claim_namespace_digest CHECK (namespace_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_write_claim_key_digest CHECK (key_digest ~ '^[a-f0-9]{64}$'), 
	CONSTRAINT ck_agent_write_claim_state CHECK (state IN ('WAITING','HELD','RELEASED','CANCELLED'))
);

CREATE UNIQUE INDEX uq_agent_write_held_key ON os_agent_write_conflict_claims (installation_id, application_id, tenant_id, namespace_digest, key_digest) WHERE state='HELD';
"""

GUARDS=r"""
CREATE FUNCTION os_guard_agent_write_policy() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE app os_applications%ROWTYPE; p jsonb; count_types bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_write_policy_immutable'; END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR UPDATE;
 p:=NEW.payload;
 IF NOT COALESCE(app.active AND app.generation=NEW.application_generation AND app.revision=NEW.registration_revision
  AND NEW.digest=os_agent_profile_digest('policy',p) AND NEW.policy_digest=os_agent_profile_digest('manifest',p)
  AND NEW.created_at<=clock_timestamp()
  AND p=jsonb_build_object('id',p->'id','revision',p->'revision','harness',p->'harness',
   'capability',p->'capability','preparationProfile',p->'preparationProfile','providerRef',p->'providerRef',
   'keyNamespace',p->'keyNamespace','scopeProfile','prepared-resource-id-keys/1','resourceTypes',p->'resourceTypes')
  AND p->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND p->>'revision' ~ '^[1-9][0-9]*$' AND (p->>'revision')::numeric<=9007199254740991
  AND p->>'providerRef' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND p->>'keyNamespace' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$'
  AND p->'harness'=jsonb_build_object('ref','agent-sdk-serialized-reviewed-change/1',
   'revision',p->'harness'->'revision','digest',p->'harness'->'digest')
  AND p->'harness'->>'revision' ~ '^[1-9][0-9]*$'
  AND (p->'harness'->>'revision')::numeric<=9007199254740991
  AND p->'harness'->>'digest' ~ '^[a-f0-9]{64}$'
  AND jsonb_typeof(p->'resourceTypes')='array' AND jsonb_array_length(p->'resourceTypes') BETWEEN 1 AND 64
  AND EXISTS(SELECT 1 FROM os_agent_capabilities c WHERE c.installation_id=NEW.installation_id
   AND c.application_id=NEW.application_id AND c.application_generation=NEW.application_generation
   AND c.capability_ref=p->'capability'->>'ref' AND c.revision=(p->'capability'->>'revision')::bigint
   AND c.digest=p->'capability'->>'digest' AND c.payload->>'kind'='propose'
   AND c.payload->>'adapterRef'='typed.prepare/1' AND c.payload->>'lifecycle'='qualified'
   AND p->'capability'=jsonb_build_object('ref',c.capability_ref,'revision',c.revision,'digest',c.digest))
  AND EXISTS(SELECT 1 FROM os_agent_tool_profiles t WHERE t.installation_id=NEW.installation_id
   AND t.application_id=NEW.application_id AND t.application_generation=NEW.application_generation
   AND t.registration_revision=NEW.registration_revision AND t.payload->'preparation'->'capability'=p->'capability'
   AND t.payload->'preparation'->>'providerRef'=p->>'providerRef'
   AND t.payload->'preparation'->>'outputContract'='AgentPreparedChange/1'
   AND p->'preparationProfile'=jsonb_build_object('ref',t.payload->'preparation'->>'id',
    'revision',t.payload->'preparation'->'revision','digest',os_agent_profile_digest('manifest',t.payload->'preparation'))),false)
  THEN RAISE EXCEPTION 'agent_write_policy_binding'; END IF;
 SELECT count(DISTINCT value) INTO count_types FROM jsonb_array_elements(p->'resourceTypes');
 IF count_types<>jsonb_array_length(p->'resourceTypes') OR EXISTS(SELECT 1 FROM jsonb_array_elements(p->'resourceTypes') x
  WHERE jsonb_typeof(x)<>'string' OR NOT (x#>>'{}') ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$')
  THEN RAISE EXCEPTION 'agent_write_policy_types'; END IF;
 IF EXISTS(SELECT 1 FROM os_agent_write_conflict_policies previous_policy WHERE previous_policy.installation_id=NEW.installation_id
  AND previous_policy.application_id=NEW.application_id AND previous_policy.payload->>'providerRef'=p->>'providerRef'
  AND previous_policy.payload->>'keyNamespace'<>p->>'keyNamespace') THEN RAISE EXCEPTION 'agent_write_namespace_changed'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_write_policy BEFORE INSERT OR UPDATE OR DELETE ON os_agent_write_conflict_policies
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_write_policy();

CREATE FUNCTION os_guard_agent_write_root() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; a os_admissions%ROWTYPE; p os_agent_write_conflict_policies%ROWTYPE; app os_applications%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_write_root_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO p FROM os_agent_write_conflict_policies WHERE installation_id=NEW.installation_id
  AND application_id=NEW.application_id AND policy_digest=NEW.policy_digest;
 SELECT * INTO app FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id;
 IF NOT COALESCE(r.accounting_format='agent-resources/1' AND r.profile_ref='agent-production/1' AND r.state='ACTIVE'
  AND r.deadline>clock_timestamp() AND r.root_task_id=a.task_id AND a.context->'harness'=p.payload->'harness'
  AND a.context->'harness'->>'ref'='agent-sdk-serialized-reviewed-change/1'
  AND app.active AND app.generation=p.application_generation AND app.revision=p.registration_revision
  AND p.registration_revision=a.registration_revision AND NEW.created_at<=clock_timestamp()
  AND NEW.created_at>=(a.context->>'admittedAt')::timestamptz,false)
  THEN RAISE EXCEPTION 'agent_write_original_root'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_write_root BEFORE INSERT OR UPDATE OR DELETE ON os_agent_write_conflict_roots
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_write_root();
"""

REVIEW_GUARD=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_review() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_tool_acceptances%ROWTYPE; c os_agent_tool_calls%ROWTYPE; o os_agent_tool_operations%ROWTYPE;
 f os_agent_tool_archives%ROWTYPE; p os_agent_tool_profiles%ROWTYPE; r os_budget_roots%ROWTYPE;
 v jsonb; context jsonb; reference jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_review_immutable'; END IF;
 SELECT * INTO a FROM os_agent_tool_acceptances WHERE id=NEW.preparation_id;
 SELECT * INTO c FROM os_agent_tool_calls WHERE id=a.call_id;
 SELECT * INTO o FROM os_agent_tool_operations WHERE id=c.operation_id;
 PERFORM os_assert_agent_tool_current(o);
 SELECT * INTO f FROM os_agent_tool_archives WHERE id=a.artifact_id;
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id;
 v:=NEW.payload;context:=o.payload->'context';reference:=v->'preparation';
 IF NOT COALESCE(ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)=
  ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
  AND p.payload->'preparation'->>'outputContract'='AgentPreparedChange/1'
  AND o.task_id=NEW.task_id AND o.root_id=NEW.root_id
  AND context->'harness'->>'ref' IN ('agent-sdk-reviewed-change/1','agent-sdk-serialized-reviewed-change/1')
  AND (context->'harness'->>'ref'='agent-sdk-reviewed-change/1' OR EXISTS(SELECT 1 FROM os_agent_write_conflict_roots b
   JOIN os_agent_write_conflict_policies policy ON policy.installation_id=b.installation_id AND policy.application_id=b.application_id
    AND policy.policy_digest=b.policy_digest WHERE b.root_id=r.id AND policy.payload->'harness'=context->'harness'))
  AND NEW.digest=os_agent_profile_digest('command',v)
  AND v=jsonb_build_object('context',context,'preparation',reference,'proposalId',NEW.id,'proposalDigest',v->'proposalDigest','stageId',v->'stageId','expiresAt',v->'expiresAt')
  AND v->>'stageId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
  AND v->>'proposalDigest' ~ '^[a-f0-9]{64}$'
  AND reference=jsonb_build_object('subject',context->'subject','taskId',NEW.task_id,'rootId',NEW.root_id,
   'resultId',a.id,'producerStepId',c.id,'acceptedAttemptId',c.attempt_id,
   'payload',jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',f.plain_bytes,
    'schemaRef','AgentPreparedChange','schemaVersion',1),'lineageRef',null,'scopeRef',context->'scopeRef','acceptedAt',reference->'acceptedAt')
  AND (reference->>'acceptedAt')::timestamptz=a.created_at AND a.created_at<=NEW.created_at
  AND (v->>'expiresAt')::timestamptz=NEW.expires_at AND NEW.expires_at<=r.deadline AND NEW.expires_at<=c.expires_at
  AND NEW.expires_at>clock_timestamp() AND NEW.created_at<=clock_timestamp()
  AND NOT EXISTS(SELECT 1 FROM jsonb_each(r.outstanding) x WHERE x.value<>'0'::jsonb),false)
 THEN RAISE EXCEPTION 'agent_review_binding'; END IF;
 RETURN NEW;
END $$;
"""

BINDING_GUARDS=r"""
CREATE FUNCTION os_guard_agent_write_binding() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE original os_agent_write_conflict_roots%ROWTYPE; policy os_agent_write_conflict_policies%ROWTYPE;
 r os_budget_roots%ROWTYPE; d os_agent_review_decisions%ROWTYPE; review os_agent_reviews%ROWTYPE;
 w os_work_attempts%ROWTYPE; receipt os_agent_effect_receipts%ROWTYPE;
 prepared_call os_agent_tool_calls%ROWTYPE; tool os_agent_tool_profiles%ROWTYPE; g jsonb; ns text; item jsonb; count_keys bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_write_binding_retained'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO original FROM os_agent_write_conflict_roots WHERE id=NEW.root_binding_id;
 SELECT * INTO policy FROM os_agent_write_conflict_policies WHERE installation_id=original.installation_id
  AND application_id=original.application_id AND policy_digest=original.policy_digest;
 SELECT * INTO d FROM os_agent_review_decisions WHERE id=NEW.decision_id;
 SELECT * INTO review FROM os_agent_reviews WHERE id=d.review_id;
 SELECT c.* INTO prepared_call FROM os_agent_tool_calls c JOIN os_agent_tool_acceptances accepted ON accepted.call_id=c.id
  WHERE accepted.id=review.preparation_id;
 SELECT * INTO tool FROM os_agent_tool_profiles WHERE installation_id=prepared_call.installation_id
  AND application_id=prepared_call.application_id AND policy_digest=prepared_call.request->'record'->'profile'->>'digest';
 g:=os_agent_reviewed_grant(NEW.decision_id);
 ns:=os_agent_profile_digest('policy',jsonb_build_object('installationId',NEW.installation_id,
  'applicationId',NEW.application_id,'tenantId',NEW.tenant_id,'providerRef',policy.payload->>'providerRef',
  'keyNamespace',policy.payload->>'keyNamespace'));
 IF NOT COALESCE(original.root_id=r.id AND review.root_id=r.id AND review.task_id=r.root_task_id
  AND g->'subject'=jsonb_build_object('installationId',NEW.installation_id,'applicationId',NEW.application_id,
   'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id)
  AND NEW.grant_digest=g->>'grantDigest' AND g->>'providerRef'=policy.payload->>'providerRef'
  AND g->>'capabilityRef'=policy.payload->'capability'->>'ref'
  AND prepared_call.request->'record'->'capability'=policy.payload->'capability'
  AND policy.payload->'preparationProfile'=jsonb_build_object('ref',tool.payload->'preparation'->>'id',
   'revision',tool.payload->'preparation'->'revision','digest',os_agent_profile_digest('manifest',tool.payload->'preparation'))
  AND NEW.keys=jsonb_build_object('keys',NEW.keys->'keys') AND jsonb_typeof(NEW.keys->'keys')='array'
  AND jsonb_array_length(NEW.keys->'keys') BETWEEN 1 AND 64
  AND NEW.keys_digest=os_agent_profile_digest('policy',NEW.keys),false)
  THEN RAISE EXCEPTION 'agent_write_binding_identity'; END IF;
 SELECT count(DISTINCT value) INTO count_keys FROM jsonb_array_elements(NEW.keys->'keys');
 IF count_keys<>jsonb_array_length(NEW.keys->'keys') THEN RAISE EXCEPTION 'agent_write_key_duplicate'; END IF;
 FOR item IN SELECT value FROM jsonb_array_elements(NEW.keys->'keys') LOOP
  IF NOT COALESCE(item=jsonb_build_object('namespaceDigest',ns,'keyDigest',item->'keyDigest')
   AND item->>'keyDigest' ~ '^[a-f0-9]{64}$',false) THEN RAISE EXCEPTION 'agent_write_key_namespace'; END IF;
 END LOOP;
 IF TG_OP='INSERT' THEN
  IF NOT COALESCE(NEW.state='WAITING' AND NEW.version=1 AND NEW.attempt_id IS NULL
   AND r.state='ACTIVE' AND r.deadline>clock_timestamp() AND d.expires_at>clock_timestamp()
   AND NEW.created_at BETWEEN d.created_at AND clock_timestamp(),false)
   THEN RAISE EXCEPTION 'agent_write_binding_initial'; END IF;
 ELSE
  IF ROW(NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.root_binding_id,NEW.root_id,
    NEW.decision_id,NEW.grant_digest,NEW.keys_digest,NEW.keys,NEW.created_at)
   IS DISTINCT FROM ROW(OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.root_binding_id,OLD.root_id,
    OLD.decision_id,OLD.grant_digest,OLD.keys_digest,OLD.keys,OLD.created_at)
   OR NEW.version<>OLD.version+1 THEN RAISE EXCEPTION 'agent_write_binding_immutable'; END IF;
  IF OLD.state='WAITING' AND NEW.state='RESERVED' THEN
   SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;
   IF NOT COALESCE(OLD.attempt_id IS NULL AND w.state='RESERVED' AND w.kind='agent.effect'
    AND w.root_id=r.id AND w.invocation_id=d.id AND w.accounting_format='agent-resources/1'
    AND ROW(w.installation_id,w.application_id,w.tenant_id,w.subject_id)=
      ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
    AND r.state='ACTIVE' AND r.deadline>clock_timestamp() AND w.lease_until>clock_timestamp()
    AND d.expires_at>clock_timestamp(),false) THEN RAISE EXCEPTION 'agent_write_reservation_binding'; END IF;
  ELSIF OLD.state='RESERVED' AND NEW.state='RUNNING' THEN
   SELECT * INTO w FROM os_work_attempts WHERE id=NEW.attempt_id;
   IF NOT COALESCE(NEW.attempt_id=OLD.attempt_id AND w.state='RUNNING' AND r.state='ACTIVE'
    AND r.deadline>clock_timestamp() AND w.lease_until>clock_timestamp() AND d.expires_at>clock_timestamp()
    AND NEW.begun_at BETWEEN w.created_at AND clock_timestamp(),false)
    THEN RAISE EXCEPTION 'agent_write_begin_binding'; END IF;
  ELSIF OLD.state IN ('WAITING','RESERVED') AND NEW.state='CANCELLED' THEN
   SELECT * INTO w FROM os_work_attempts WHERE id=OLD.attempt_id;
   IF NEW.attempt_id IS DISTINCT FROM OLD.attempt_id OR OLD.begun_at IS NOT NULL
    OR (OLD.attempt_id IS NOT NULL AND w.state IS DISTINCT FROM 'RELEASED')
    OR NOT COALESCE(NEW.released_at BETWEEN OLD.created_at AND clock_timestamp(),false)
    THEN RAISE EXCEPTION 'agent_write_cancel_not_unstarted'; END IF;
  ELSIF OLD.state='RUNNING' AND NEW.state='RELEASED' THEN
   SELECT * INTO receipt FROM os_agent_effect_receipts WHERE id=NEW.receipt_id;
   IF NEW.attempt_id IS DISTINCT FROM OLD.attempt_id OR NEW.begun_at IS DISTINCT FROM OLD.begun_at
    OR NOT COALESCE(receipt.binding_id=NEW.attempt_id AND receipt.invocation_id=NEW.decision_id
     AND receipt.payload->>'status' IN ('COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED')
     AND NEW.released_at BETWEEN receipt.created_at AND clock_timestamp(),false)
    OR EXISTS(SELECT 1 FROM os_agent_effect_receipts later WHERE later.binding_id=NEW.attempt_id AND later.ordinal>receipt.ordinal)
    OR EXISTS(SELECT 1 FROM os_agent_effect_receipts a JOIN os_agent_effect_receipts b
     ON b.binding_id=a.binding_id AND b.ordinal=a.ordinal+1 WHERE a.binding_id=NEW.attempt_id
     AND a.payload->'receiptId'<>'null'::jsonb AND (b.payload->'receiptId' IS DISTINCT FROM a.payload->'receiptId'
      OR b.payload->'version'='null'::jsonb OR (b.payload->>'version')::numeric<(a.payload->>'version')::numeric
      OR (b.payload->'version'=a.payload->'version' AND b.payload->'status'<>a.payload->'status')
      OR (a.payload->>'status' IN ('COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED')
       AND (b.payload->'status'<>a.payload->'status' OR b.payload->'version'<>a.payload->'version'))))
    THEN RAISE EXCEPTION 'agent_write_release_not_receipted'; END IF;
  ELSE RAISE EXCEPTION 'agent_write_binding_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_write_binding BEFORE INSERT OR UPDATE OR DELETE ON os_agent_write_conflict_bindings
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_write_binding();

CREATE FUNCTION os_guard_agent_write_claim() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE binding os_agent_write_conflict_bindings%ROWTYPE; expected_state text;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_write_claim_retained'; END IF;
 SELECT * INTO binding FROM os_agent_write_conflict_bindings WHERE id=NEW.binding_id;
 expected_state:=CASE WHEN binding.state IN ('RESERVED','RUNNING') THEN 'HELD' ELSE binding.state END;
 IF NOT COALESCE(NEW.state=expected_state AND EXISTS(SELECT 1 FROM jsonb_array_elements(binding.keys->'keys') k
  WHERE k=jsonb_build_object('namespaceDigest',NEW.namespace_digest,'keyDigest',NEW.key_digest)),false)
  THEN RAISE EXCEPTION 'agent_write_claim_binding'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'WAITING' OR NEW.created_at<binding.created_at OR NEW.created_at>clock_timestamp()
   THEN RAISE EXCEPTION 'agent_write_claim_initial'; END IF;
 ELSE
  IF ROW(NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.binding_id,NEW.root_id,
    NEW.namespace_digest,NEW.key_digest,NEW.created_at)
   IS DISTINCT FROM ROW(OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.binding_id,OLD.root_id,
    OLD.namespace_digest,OLD.key_digest,OLD.created_at)
   OR NOT ((OLD.state='WAITING' AND NEW.state IN ('HELD','CANCELLED')) OR (OLD.state='HELD' AND NEW.state IN ('RELEASED','CANCELLED')))
   THEN RAISE EXCEPTION 'agent_write_claim_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_write_claim BEFORE INSERT OR UPDATE OR DELETE ON os_agent_write_conflict_claims
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_write_claim();
"""

WORK_GUARDS=r"""
CREATE FUNCTION os_check_agent_write_set() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE b os_agent_write_conflict_bindings%ROWTYPE; w os_work_attempts%ROWTYPE; a os_admissions%ROWTYPE;
 actual_keys jsonb; count_claims bigint; expected_state text;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_work_attempts' THEN
  SELECT * INTO w FROM os_work_attempts WHERE id=NEW.id;
  IF w.accounting_format<>'agent-resources/1' OR w.kind<>'agent.effect' THEN RETURN NULL; END IF;
  SELECT admission.* INTO a FROM os_admissions admission JOIN os_budget_roots root ON root.admission_id=admission.id WHERE root.id=w.root_id;
  IF a.context->'harness'->>'ref' IS DISTINCT FROM 'agent-sdk-serialized-reviewed-change/1' THEN RETURN NULL; END IF;
  SELECT * INTO b FROM os_agent_write_conflict_bindings WHERE attempt_id=w.id;
  IF b.id IS NULL THEN RAISE EXCEPTION 'agent_write_policy_required'; END IF;
 ELSIF TG_TABLE_NAME='os_agent_write_conflict_claims' THEN
  SELECT * INTO b FROM os_agent_write_conflict_bindings WHERE id=NEW.binding_id;
 ELSE SELECT * INTO b FROM os_agent_write_conflict_bindings WHERE id=NEW.id;
 END IF;
 IF b.id IS NULL THEN RAISE EXCEPTION 'agent_write_binding_missing'; END IF;
 SELECT count(*),jsonb_agg(jsonb_build_object('namespaceDigest',namespace_digest,'keyDigest',key_digest)
  ORDER BY namespace_digest,key_digest) INTO count_claims,actual_keys FROM os_agent_write_conflict_claims WHERE binding_id=b.id;
 expected_state:=CASE WHEN b.state IN ('RESERVED','RUNNING') THEN 'HELD' ELSE b.state END;
 IF count_claims<>jsonb_array_length(b.keys->'keys') OR actual_keys IS DISTINCT FROM b.keys->'keys'
  OR EXISTS(SELECT 1 FROM os_agent_write_conflict_claims WHERE binding_id=b.id AND state<>expected_state)
  THEN RAISE EXCEPTION 'agent_write_key_set_incomplete'; END IF;
 SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
 IF b.state='WAITING' THEN
  IF b.attempt_id IS NOT NULL THEN RAISE EXCEPTION 'agent_write_wait_reserved'; END IF;
 ELSIF b.state='RESERVED' THEN
  IF w.state IS DISTINCT FROM 'RESERVED' THEN RAISE EXCEPTION 'agent_write_reservation_state'; END IF;
 ELSIF b.state IN ('RUNNING','RELEASED') THEN
  IF w.state IS NULL OR w.state NOT IN ('RUNNING','UNKNOWN','SETTLED') THEN RAISE EXCEPTION 'agent_write_started_state'; END IF;
 ELSIF b.state='CANCELLED' AND b.attempt_id IS NOT NULL THEN
  IF w.state IS DISTINCT FROM 'RELEASED' THEN RAISE EXCEPTION 'agent_write_cancelled_started'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_write_binding_set AFTER INSERT OR UPDATE ON os_agent_write_conflict_bindings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_write_set();
CREATE CONSTRAINT TRIGGER check_agent_write_claim_set AFTER INSERT OR UPDATE ON os_agent_write_conflict_claims
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_write_set();
CREATE CONSTRAINT TRIGGER check_agent_write_work_set AFTER INSERT OR UPDATE ON os_work_attempts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_write_set();

CREATE FUNCTION os_agent_write_work_transition() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; b os_agent_write_conflict_bindings%ROWTYPE;
BEGIN
 IF NEW.accounting_format<>'agent-resources/1' OR NEW.kind<>'agent.effect' OR NEW.state=OLD.state THEN RETURN NULL; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT admission.* INTO a FROM os_admissions admission JOIN os_budget_roots root ON root.admission_id=admission.id WHERE root.id=NEW.root_id;
 IF a.context->'harness'->>'ref' IS DISTINCT FROM 'agent-sdk-serialized-reviewed-change/1' THEN RETURN NULL; END IF;
 SELECT * INTO b FROM os_agent_write_conflict_bindings WHERE attempt_id=NEW.id FOR UPDATE;
 IF b.id IS NULL THEN RAISE EXCEPTION 'agent_write_work_unbound'; END IF;
 IF OLD.state='RESERVED' AND NEW.state='RUNNING' THEN
  IF b.state<>'RESERVED' THEN RAISE EXCEPTION 'agent_write_begin_unclaimed'; END IF;
  UPDATE os_agent_write_conflict_bindings SET state='RUNNING',begun_at=clock_timestamp(),version=version+1 WHERE id=b.id;
 ELSIF OLD.state='RESERVED' AND NEW.state='RELEASED' THEN
  IF b.state<>'RESERVED' OR b.begun_at IS NOT NULL THEN RAISE EXCEPTION 'agent_write_release_started'; END IF;
  UPDATE os_agent_write_conflict_bindings SET state='CANCELLED',released_at=clock_timestamp(),version=version+1 WHERE id=b.id;
  UPDATE os_agent_write_conflict_claims SET state='CANCELLED' WHERE binding_id=b.id;
 END IF;
 RETURN NULL;
END $$;
CREATE TRIGGER agent_write_work_transition AFTER UPDATE ON os_work_attempts
 FOR EACH ROW EXECUTE FUNCTION os_agent_write_work_transition();

CREATE FUNCTION os_check_agent_write_admission() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE;
BEGIN
 IF NEW.context->'harness'->>'ref' IS DISTINCT FROM 'agent-sdk-serialized-reviewed-change/1' THEN RETURN NULL; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO r FROM os_budget_roots WHERE admission_id=NEW.id;
 IF NOT EXISTS(SELECT 1 FROM os_agent_write_conflict_roots binding JOIN os_agent_write_conflict_policies policy
  ON policy.installation_id=binding.installation_id AND policy.application_id=binding.application_id
   AND policy.policy_digest=binding.policy_digest WHERE binding.root_id=r.id AND policy.payload->'harness'=NEW.context->'harness')
  THEN RAISE EXCEPTION 'agent_write_admission_policy_required'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER check_agent_write_admission AFTER INSERT ON os_admissions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_check_agent_write_admission();
"""

def upgrade():
    op.execute(TABLES)
    op.execute(GUARDS)
    op.execute(REVIEW_GUARD)
    op.execute(BINDING_GUARDS)
    op.execute(WORK_GUARDS)


def downgrade():
    raise RuntimeError("Write coordination requires protected forward recovery")
