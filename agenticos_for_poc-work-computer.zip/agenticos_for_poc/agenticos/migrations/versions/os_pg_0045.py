"""Keep context-command records distinct from reviewed supersession aliases."""
from alembic import op

revision = "os_pg_0045"
down_revision = "os_pg_0044"
branch_labels = None
depends_on = None

GUARDS = r"""
CREATE OR REPLACE FUNCTION os_guard_knowledge_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE eid uuid; live boolean; e personal_knowledge_entries%ROWTYPE; c personal_knowledge_operations%ROWTYPE; context_command owner_memory_context_commands%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE settings_id=NEW.id AND context_revision=NEW.context_revision;
  SELECT * INTO context_command FROM owner_memory_context_commands WHERE settings_id=NEW.id AND context_revision=NEW.context_revision;
  IF (c.id IS NULL)=(context_command.id IS NULL) THEN RAISE EXCEPTION 'memory_context_exact_receipt';END IF;
  IF context_command.id IS NOT NULL THEN PERFORM os_assert_owner_memory_context(context_command.context_id,true);RETURN NULL;END IF;
  IF c.id IS NULL THEN RAISE EXCEPTION 'knowledge_context_receipt'; END IF;
  eid=c.entry_id; live=true;
 ELSIF TG_TABLE_NAME='personal_knowledge_entries' THEN
  eid=NEW.id; live=(TG_OP='INSERT');
  IF TG_OP='UPDATE' THEN live=NEW.version<>OLD.version; END IF;
  IF NEW.state='SUPERSEDED' THEN
   IF TG_OP='UPDATE' AND live THEN
    IF NOT EXISTS(SELECT 1 FROM personal_knowledge_supersessions m WHERE m.entry_id=NEW.id
     AND m.expected_version=OLD.version AND m.accepted_version=NEW.version AND m.prior_state=OLD.state)
     THEN RAISE EXCEPTION 'knowledge_reviewed_target_transition';END IF;
   END IF;
   PERFORM os_assert_knowledge_supersession(eid,live);RETURN NULL;
  END IF;
  IF live THEN
   SELECT * INTO c FROM personal_knowledge_operations WHERE entry_id=eid AND accepted_version=NEW.version;
   IF TG_OP='INSERT' THEN
    IF c.kind IS DISTINCT FROM 'SAVE' THEN RAISE EXCEPTION 'knowledge_save_operation'; END IF;
   ELSE
    IF c.kind IS DISTINCT FROM (CASE WHEN NEW.active_revision_id<>OLD.active_revision_id THEN 'REVISE'
     WHEN NEW.state='FORGOTTEN' THEN 'FORGET' WHEN NEW.state='PAUSED' THEN 'PAUSE' ELSE 'RESUME' END)
     THEN RAISE EXCEPTION 'knowledge_transition_operation'; END IF;
   END IF;
  END IF;
 ELSE
  eid=NEW.entry_id; live=(TG_OP='INSERT');
  -- PL/pgSQL resolves record fields when preparing an expression, even if
  -- another operand in that expression would make an AND condition false.
  IF TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
   IF TG_OP='UPDATE' AND NEW.state='CANCELLED' THEN RETURN NULL; END IF;
  END IF;
 END IF;
 PERFORM os_assert_knowledge_entry(eid,live);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;
 IF TG_OP='UPDATE' AND TG_TABLE_NAME='personal_knowledge_revisions' THEN
  IF os_revision_source_forgotten(NEW.id) THEN RETURN NULL;END IF;
 ELSIF TG_OP='UPDATE' AND TG_TABLE_NAME='personal_knowledge_operations' THEN
  IF EXISTS(SELECT 1 FROM personal_knowledge_publications p WHERE p.operation_id=NEW.id AND os_revision_source_forgotten(p.revision_id))
   THEN RETURN NULL;END IF;
 END IF;
 IF NOT live AND TG_TABLE_NAME IN ('personal_knowledge_revisions','personal_knowledge_operations','personal_forget_journal')
  AND e.projection_state<>'PURGED' THEN RAISE EXCEPTION 'knowledge_cleanup_incomplete'; END IF;
 IF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_revisions' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE id=NEW.operation_id;
  IF NEW.id<>e.active_revision_id OR NEW.envelope IS NULL OR c.kind NOT IN ('SAVE','REVISE')
   OR c.accepted_version<>e.version OR NEW.created_at<>c.created_at
   THEN RAISE EXCEPTION 'knowledge_revision_binding'; END IF;
 ELSIF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
  IF NEW.entry_version<>e.version OR NEW.revision_id<>e.active_revision_id THEN RAISE EXCEPTION 'knowledge_job_binding'; END IF;
 END IF;
 RETURN NULL;
END $$;
"""


def upgrade():
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError("Use the protected additive recovery plan; populated memory is retained")
