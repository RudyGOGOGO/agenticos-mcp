"""Controlled offline canonical index generations, attempts and activation."""
from alembic import op
revision='os_pg_0042'
down_revision='os_pg_0041'
branch_labels=None
depends_on=None

TABLES = "\nCREATE TABLE personal_index_generations (\n\tid UUID NOT NULL, \n\tsettings_id UUID NOT NULL, \n\tcommand_id UUID NOT NULL, \n\tsession_id UUID NOT NULL, \n\tgeneration BIGINT NOT NULL, \n\tsettings_version BIGINT NOT NULL, \n\tlearning_epoch BIGINT NOT NULL, \n\trecall_epoch BIGINT NOT NULL, \n\tcontext_revision BIGINT NOT NULL, \n\tprofile_ref VARCHAR(64) NOT NULL, \n\tstate VARCHAR(16) NOT NULL, \n\texpected_entries BIGINT NOT NULL, \n\trequest_digest VARCHAR(64) NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tcompleted_at TIMESTAMP WITH TIME ZONE, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_personal_index_generation_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_learning_settings_settings_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, settings_id) REFERENCES personal_learning_settings (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT uq_personal_index_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id), \n\tCONSTRAINT uq_personal_index_number UNIQUE (installation_id, application_id, tenant_id, subject_id, settings_id, generation), \n\tCONSTRAINT ck_personal_index_versions CHECK (generation>1 AND settings_version>0 AND learning_epoch>0 AND recall_epoch>0 AND context_revision>0), \n\tCONSTRAINT ck_personal_index_profile CHECK (profile_ref='minilm-english-onnx/1' AND expected_entries BETWEEN 0 AND 64), \n\tCONSTRAINT ck_personal_index_state CHECK ((state='BUILDING' AND completed_at IS NULL) OR (state IN ('READY','STALE','FAILED') AND completed_at IS NOT NULL AND completed_at>=created_at)), \n\tCONSTRAINT ck_personal_index_command_digest CHECK (request_digest ~ '^[a-f0-9]{64}$')\n)\n\n;\n\nCREATE TABLE personal_index_members (\n\tid UUID NOT NULL, \n\tgeneration_id UUID NOT NULL, \n\tentry_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\tentry_version BIGINT NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_personal_index_member_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_index_generations_generation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, generation_id) REFERENCES personal_index_generations (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_index_member_revision FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, entry_id, id), \n\tCONSTRAINT uq_personal_index_member_entry UNIQUE (installation_id, application_id, tenant_id, subject_id, generation_id, entry_id), \n\tCONSTRAINT ck_personal_index_member_version CHECK (entry_version>0)\n)\n\n;\n\nCREATE TABLE personal_index_attempts (\n\tid UUID NOT NULL, \n\tgeneration_id UUID NOT NULL, \n\tentry_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\tprojection_id UUID NOT NULL, \n\tentry_version BIGINT NOT NULL, \n\trecall_epoch BIGINT NOT NULL, \n\tcontext_revision BIGINT NOT NULL, \n\tlane VARCHAR(16) NOT NULL, \n\tcontext_ref VARCHAR(64) NOT NULL, \n\tstate VARCHAR(16) NOT NULL, \n\tlease_id UUID NOT NULL, \n\tlease_until TIMESTAMP WITH TIME ZONE NOT NULL, \n\tcreated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tcompleted_at TIMESTAMP WITH TIME ZONE, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_personal_index_attempt_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_index_generations_generation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, generation_id) REFERENCES personal_index_generations (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_index_attempt_revision FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, entry_id, id), \n\tCONSTRAINT uq_personal_index_attempt_entry UNIQUE (installation_id, application_id, tenant_id, subject_id, generation_id, entry_id, entry_version), \n\tCONSTRAINT uq_personal_index_attempt_projection UNIQUE (projection_id), \n\tCONSTRAINT ck_personal_index_attempt_versions CHECK (entry_version>0 AND recall_epoch>0 AND context_revision>0), \n\tCONSTRAINT ck_personal_index_attempt_lane CHECK (lane IN ('preference','episodic','semantic','procedural') AND (context_ref='general/1' OR context_ref ~ '^context/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/1$')), \n\tCONSTRAINT ck_personal_index_attempt_state CHECK (lease_until>created_at AND ((state='RUNNING' AND completed_at IS NULL) OR (state IN ('READY','STALE','FAILED','HELD') AND completed_at IS NOT NULL AND completed_at>=created_at)))\n)\n\n;\n\nCREATE TABLE personal_index_pointers (\n\tid UUID NOT NULL, \n\tentry_id UUID NOT NULL, \n\tgeneration_id UUID NOT NULL, \n\tattempt_id UUID NOT NULL, \n\trevision_id UUID NOT NULL, \n\tprojection_id UUID NOT NULL, \n\tentry_version BIGINT NOT NULL, \n\tupdated_at TIMESTAMP WITH TIME ZONE NOT NULL, \n\tinstallation_id UUID NOT NULL, \n\tapplication_id UUID NOT NULL, \n\ttenant_id VARCHAR(256) NOT NULL, \n\tsubject_id VARCHAR(256) NOT NULL, \n\tPRIMARY KEY (id), \n\tCONSTRAINT uq_personal_index_pointer_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_index_generations_generation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, generation_id) REFERENCES personal_index_generations (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_index_attempts_attempt_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, attempt_id) REFERENCES personal_index_attempts (installation_id, application_id, tenant_id, subject_id, id), \n\tCONSTRAINT fk_personal_index_pointer_revision FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, entry_id, id), \n\tCONSTRAINT uq_personal_index_pointer_entry UNIQUE (installation_id, application_id, tenant_id, subject_id, generation_id, entry_id), \n\tCONSTRAINT uq_personal_index_pointer_projection UNIQUE (projection_id), \n\tCONSTRAINT ck_personal_index_pointer_version CHECK (entry_version>0)\n)\n\n;\nCREATE UNIQUE INDEX uq_personal_index_building ON personal_index_generations (settings_id) WHERE state='BUILDING';"
SETTINGS = "ALTER TABLE personal_learning_settings DROP CONSTRAINT ck_learning_settings_choice;\nALTER TABLE personal_learning_settings ADD CONSTRAINT ck_learning_settings_choice CHECK (COALESCE(jsonb_typeof(choice->'learnConversation')='boolean' AND jsonb_typeof(choice->'learnUsage')='boolean' AND jsonb_typeof(choice->'useMemory')='boolean' AND choice=jsonb_build_object('learnConversation',choice->'learnConversation','learnUsage',choice->'learnUsage','useMemory',choice->'useMemory','retentionProfile','private-local/1','extractorProfile','synthetic-staging/1','embeddingProfile',choice->'embeddingProfile') AND choice->>'embeddingProfile' IN ('synthetic-embedding/1','minilm-english-onnx/1'),false));\nALTER TABLE personal_knowledge_projection_jobs DROP CONSTRAINT ck_knowledge_job_states;\nALTER TABLE personal_knowledge_projection_jobs ADD CONSTRAINT ck_knowledge_job_states CHECK (profile_ref IN ('synthetic-embedding/1','minilm-english-onnx/1') AND operation IN ('INDEX','PURGE') AND state IN ('PENDING','CANCELLED','COMPLETE'));\nCREATE OR REPLACE FUNCTION os_guard_learning_settings() RETURNS trigger LANGUAGE plpgsql AS $$\nBEGIN\n IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_settings_retained'; END IF;\n IF TG_OP='INSERT' THEN\n  IF NEW.version<>1 OR NEW.learning_epoch<>1 OR NEW.recall_epoch<>1 OR NEW.context_revision<>1\n   OR NEW.index_generation<>1 OR NEW.created_at<>NEW.updated_at\n   OR NEW.choice->'learnConversation'<>'false'::jsonb OR NEW.choice->'learnUsage'<>'false'::jsonb\n   OR NEW.choice->'useMemory'<>'false'::jsonb OR NEW.choice->>'embeddingProfile'<>'synthetic-embedding/1' THEN RAISE EXCEPTION 'learning_default_consent'; END IF;\n ELSIF NEW.version=OLD.version AND NEW.index_generation<>OLD.index_generation THEN\n  IF (to_jsonb(NEW)-ARRAY['index_generation','updated_at']) IS DISTINCT FROM\n     (to_jsonb(OLD)-ARRAY['index_generation','updated_at'])\n   OR NEW.index_generation<=OLD.index_generation OR NEW.updated_at<OLD.updated_at\n   THEN RAISE EXCEPTION 'personal_index_activation_transition'; END IF;\n ELSIF NEW.version=OLD.version THEN\n  IF (to_jsonb(NEW)-ARRAY['context_revision','updated_at']) IS DISTINCT FROM\n     (to_jsonb(OLD)-ARRAY['context_revision','updated_at'])\n   OR NEW.context_revision<>OLD.context_revision+1 OR NEW.updated_at<OLD.updated_at\n   THEN RAISE EXCEPTION 'knowledge_context_transition'; END IF;\n ELSE\n  IF (to_jsonb(NEW)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])\n   IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','learning_epoch','recall_epoch','choice','updated_at'])\n   OR NEW.version<>OLD.version+1\n   OR NEW.learning_epoch<>OLD.learning_epoch+(CASE WHEN (NEW.choice-'useMemory') IS DISTINCT FROM (OLD.choice-'useMemory') THEN 1 ELSE 0 END)\n   OR NEW.recall_epoch<>OLD.recall_epoch+(CASE WHEN (NEW.choice-ARRAY['learnConversation','learnUsage'])\n    IS DISTINCT FROM (OLD.choice-ARRAY['learnConversation','learnUsage']) THEN 1 ELSE 0 END)\n   OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'learning_settings_transition'; END IF;\n END IF;\n RETURN NEW;\nEND $$;\nCREATE OR REPLACE FUNCTION os_assert_knowledge_entry(eid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$\nDECLARE e personal_knowledge_entries%ROWTYPE; r personal_knowledge_revisions%ROWTYPE;\n s personal_learning_settings%ROWTYPE; c personal_knowledge_operations%ROWTYPE;\n session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;\n j personal_forget_journal%ROWTYPE; p personal_knowledge_projection_jobs%ROWTYPE;\nBEGIN\n PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);\n SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;\n SELECT * INTO s FROM personal_learning_settings WHERE id=e.settings_id;\n SELECT * INTO r FROM personal_knowledge_revisions WHERE id=e.active_revision_id;\n\n IF e.state='SUPERSEDED' THEN PERFORM os_assert_knowledge_supersession(e.id,live);RETURN;END IF;\n IF r.envelope IS NULL AND os_revision_source_forgotten(r.id) AND e.state<>'FORGOTTEN' THEN\n  IF live OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE revision_id=r.id AND operation='INDEX' AND state='PENDING')\n   OR EXISTS(SELECT 1 FROM personal_knowledge_operations WHERE id=r.operation_id AND request_mac IS NOT NULL)\n   THEN RAISE EXCEPTION 'knowledge_source_cleanup_incomplete';END IF;\n  RETURN;\n END IF;\n SELECT * INTO c FROM personal_knowledge_operations WHERE entry_id=e.id AND accepted_version=e.version;\n IF e.id IS NULL OR s.id IS NULL OR r.id IS NULL OR c.id IS NULL\n  OR r.entry_id<>e.id OR r.ordinal<>e.content_revision OR c.settings_id<>s.id\n  OR c.created_at<>e.updated_at OR c.context_revision>s.context_revision\n  OR c.receipt IS DISTINCT FROM jsonb_build_object('commandId',c.command_id,'operationId',c.id,'entryId',e.id,\n    'revision',e.version,'contextRevision',c.context_revision,'state',e.state,\n    'projectionState',CASE WHEN e.state='FORGOTTEN' THEN 'PURGING' ELSE 'PENDING' END)\n THEN RAISE EXCEPTION 'knowledge_atomic_receipt'; END IF;\n IF live THEN\n  IF c.context_revision<>s.context_revision OR s.updated_at<>c.created_at OR c.request_mac IS NULL\n   THEN RAISE EXCEPTION 'knowledge_atomic_context'; END IF;\n  SELECT * INTO session FROM os_interactive_sessions WHERE id=c.session_id;\n  SELECT * INTO app FROM os_applications WHERE installation_id=e.installation_id AND id=e.application_id;\n  SELECT * INTO owner FROM os_subjects WHERE installation_id=e.installation_id AND application_id=e.application_id\n   AND tenant_id=e.tenant_id AND subject_id=e.subject_id;\n  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()\n   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation\n   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation\n   THEN RAISE EXCEPTION 'knowledge_current_owner'; END IF;\n END IF;\n IF e.state='FORGOTTEN' THEN\n  SELECT * INTO j FROM personal_forget_journal WHERE entry_id=e.id;\n  SELECT * INTO p FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND entry_version=e.version;\n  IF c.kind<>'FORGET' OR j.id IS NULL OR j.operation_id<>c.id OR j.context_revision<>c.context_revision\n   OR j.forgotten_at<>c.created_at OR p.id IS NULL OR p.operation<>'PURGE' OR p.operation_id<>c.id\n   OR p.created_at<>c.created_at OR p.revision_id<>r.id\n   OR (e.projection_state='PURGING' AND (j.completed_at IS NOT NULL OR p.state<>'PENDING'))\n   OR (e.projection_state='PURGED' AND (j.completed_at IS NULL OR p.state<>'COMPLETE'\n    OR EXISTS(SELECT 1 FROM personal_knowledge_revisions WHERE entry_id=e.id AND envelope IS NOT NULL)\n    OR EXISTS(SELECT 1 FROM personal_knowledge_operations WHERE entry_id=e.id AND kind<>'FORGET' AND request_mac IS NOT NULL)))\n   OR e.projection_state NOT IN ('PURGING','PURGED')\n   OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND operation='INDEX' AND state='PENDING')\n   THEN RAISE EXCEPTION 'knowledge_forget_barrier'; END IF;\n ELSE\n  IF r.envelope IS NULL OR e.projection_state<>'PENDING' OR EXISTS(SELECT 1 FROM personal_forget_journal WHERE entry_id=e.id)\n   THEN RAISE EXCEPTION 'knowledge_live_revision'; END IF;\n  IF c.kind IN ('SAVE','REVISE') AND (r.operation_id<>c.id OR r.created_at<>c.created_at)\n   THEN RAISE EXCEPTION 'knowledge_revision_operation'; END IF;\n  IF live AND c.kind IN ('SAVE','REVISE','RESUME') AND e.valid_until IS NOT NULL AND e.valid_until<=clock_timestamp()\n   THEN RAISE EXCEPTION 'knowledge_expired_publication'; END IF;\n  IF e.state='ACTIVE' THEN\n   SELECT * INTO p FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND entry_version=e.version;\n   IF c.kind NOT IN ('SAVE','REVISE','RESUME') OR p.id IS NULL OR p.operation<>'INDEX' OR p.state<>'PENDING'\n    OR p.revision_id<>r.id OR p.operation_id<>c.id OR p.created_at<>c.created_at\n    OR (live AND p.index_generation<>s.index_generation) OR (live AND p.recall_epoch<>s.recall_epoch)\n    THEN RAISE EXCEPTION 'knowledge_projection_intent'; END IF;\n  ELSIF c.kind<>'PAUSE' OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND state='PENDING')\n   THEN RAISE EXCEPTION 'knowledge_pause_barrier'; END IF;\n END IF;\nEND $$;\n\n"


def upgrade():
    op.execute(TABLES)
    op.execute(SETTINGS)
    op.execute(GUARDS)


def downgrade():
    raise RuntimeError('Owned populated data requires protected forward recovery')


GUARDS = r"""
CREATE FUNCTION os_personal_index_eligible(eid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT COALESCE(e.state='ACTIVE' AND (e.valid_until IS NULL OR e.valid_until>clock_timestamp())
  AND r.envelope IS NOT NULL AND os_revision_sources_current(r.id),false)
 FROM personal_knowledge_entries e JOIN personal_knowledge_revisions r ON r.id=e.active_revision_id WHERE e.id=eid
$$;
CREATE FUNCTION os_personal_index_owner(gid uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE g personal_index_generations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO g FROM personal_index_generations WHERE id=gid;
 SELECT * INTO session FROM os_interactive_sessions WHERE id=g.session_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=g.installation_id AND id=g.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=g.installation_id AND application_id=g.application_id
  AND tenant_id=g.tenant_id AND subject_id=g.subject_id;
 IF g.id IS NULL OR session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
  OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
  OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
 THEN RAISE EXCEPTION 'personal_index_current_owner'; END IF;
END $$;
CREATE FUNCTION os_guard_personal_index_generation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; n bigint; next_generation bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'personal_index_generation_retained'; END IF;
 SELECT * INTO s FROM personal_learning_settings WHERE id=NEW.settings_id FOR UPDATE;
 IF TG_OP='INSERT' THEN
  SELECT count(*),COALESCE(max(generation),s.index_generation)+1 INTO n,next_generation
   FROM personal_index_generations WHERE settings_id=s.id;
  IF n>=32 OR NEW.generation<>next_generation OR NEW.state<>'BUILDING' OR NEW.completed_at IS NOT NULL
   OR ROW(NEW.settings_version,NEW.learning_epoch,NEW.recall_epoch,NEW.context_revision,NEW.profile_ref)
    IS DISTINCT FROM ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.choice->>'embeddingProfile')
   THEN RAISE EXCEPTION 'personal_index_build_binding'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['state','completed_at']) IS DISTINCT FROM
     (to_jsonb(OLD)-ARRAY['state','completed_at']) OR OLD.state<>'BUILDING' OR NEW.state='BUILDING'
   THEN RAISE EXCEPTION 'personal_index_generation_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_personal_index_generation BEFORE INSERT OR UPDATE OR DELETE ON personal_index_generations
 FOR EACH ROW EXECUTE FUNCTION os_guard_personal_index_generation();
CREATE FUNCTION os_guard_personal_index_member() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE g personal_index_generations%ROWTYPE; e personal_knowledge_entries%ROWTYPE;
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'personal_index_member_immutable'; END IF;
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO g FROM personal_index_generations WHERE id=NEW.generation_id;
 PERFORM 1 FROM personal_learning_settings WHERE id=g.settings_id FOR UPDATE;
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=NEW.entry_id;
 IF g.state<>'BUILDING' OR NOT COALESCE(os_personal_index_eligible(e.id),false)
  OR ROW(NEW.revision_id,NEW.entry_version) IS DISTINCT FROM ROW(e.active_revision_id,e.version)
  OR NEW.created_at<>g.created_at THEN RAISE EXCEPTION 'personal_index_member_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_personal_index_member BEFORE INSERT OR UPDATE OR DELETE ON personal_index_members
 FOR EACH ROW EXECUTE FUNCTION os_guard_personal_index_member();
CREATE FUNCTION os_guard_personal_index_attempt() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE g personal_index_generations%ROWTYPE; s personal_learning_settings%ROWTYPE; e personal_knowledge_entries%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'personal_index_attempt_retained'; END IF;
 SELECT * INTO g FROM personal_index_generations WHERE id=NEW.generation_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=g.settings_id FOR UPDATE;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'RUNNING' OR NEW.completed_at IS NOT NULL OR NEW.created_at<>g.created_at
   OR NEW.lease_until<>NEW.created_at+interval '120 seconds'
   OR ROW(NEW.recall_epoch,NEW.context_revision) IS DISTINCT FROM ROW(g.recall_epoch,g.context_revision)
   OR NOT EXISTS(SELECT 1 FROM personal_index_members m WHERE m.generation_id=g.id AND m.entry_id=NEW.entry_id
    AND m.revision_id=NEW.revision_id AND m.entry_version=NEW.entry_version)
   THEN RAISE EXCEPTION 'personal_index_attempt_binding'; END IF;
 ELSE
  IF OLD.state<>'RUNNING' OR NEW.state='RUNNING' OR (to_jsonb(NEW)-ARRAY['state','completed_at']) IS DISTINCT FROM
    (to_jsonb(OLD)-ARRAY['state','completed_at']) THEN RAISE EXCEPTION 'personal_index_attempt_transition'; END IF;
 END IF;
 IF TG_OP='INSERT' OR NEW.state='READY' THEN
  PERFORM os_personal_index_owner(g.id);
  SELECT * INTO e FROM personal_knowledge_entries WHERE id=NEW.entry_id;
  IF g.state<>'BUILDING' OR NEW.lease_until<=clock_timestamp()
   OR ROW(g.settings_version,g.learning_epoch,g.recall_epoch,g.context_revision,g.profile_ref)
    IS DISTINCT FROM ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.choice->>'embeddingProfile')
   OR NOT COALESCE(os_personal_index_eligible(e.id),false)
   OR ROW(NEW.revision_id,NEW.entry_version) IS DISTINCT FROM ROW(e.active_revision_id,e.version)
   THEN RAISE EXCEPTION 'personal_index_attempt_obsolete'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_personal_index_attempt BEFORE INSERT OR UPDATE OR DELETE ON personal_index_attempts
 FOR EACH ROW EXECUTE FUNCTION os_guard_personal_index_attempt();
CREATE FUNCTION os_guard_personal_index_pointer() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a personal_index_attempts%ROWTYPE; g personal_index_generations%ROWTYPE;
 e personal_knowledge_entries%ROWTYPE; s personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'personal_index_pointer_immutable'; END IF;
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM personal_index_attempts WHERE id=NEW.attempt_id;
 SELECT * INTO g FROM personal_index_generations WHERE id=a.generation_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=g.settings_id FOR UPDATE;
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=NEW.entry_id;
 PERFORM os_personal_index_owner(g.id);
 IF a.state<>'READY' OR a.lease_until<=clock_timestamp() OR g.state<>'BUILDING'
  OR ROW(g.settings_version,g.learning_epoch,g.recall_epoch,g.context_revision,g.profile_ref)
   IS DISTINCT FROM ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.choice->>'embeddingProfile')
  OR ROW(NEW.generation_id,NEW.entry_id,NEW.revision_id,NEW.entry_version,NEW.projection_id,NEW.updated_at)
   IS DISTINCT FROM ROW(a.generation_id,a.entry_id,a.revision_id,a.entry_version,a.projection_id,a.completed_at)
  OR ROW(NEW.revision_id,NEW.entry_version) IS DISTINCT FROM ROW(e.active_revision_id,e.version)
  OR NOT COALESCE(os_personal_index_eligible(e.id),false)
 THEN RAISE EXCEPTION 'personal_index_pointer_binding'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_personal_index_pointer BEFORE INSERT OR UPDATE OR DELETE ON personal_index_pointers
 FOR EACH ROW EXECUTE FUNCTION os_guard_personal_index_pointer();
CREATE FUNCTION os_commit_personal_index() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE g personal_index_generations%ROWTYPE; s personal_learning_settings%ROWTYPE;
 expected bigint; members bigint; ready bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  s=NEW;
  SELECT * INTO g FROM personal_index_generations WHERE settings_id=s.id AND generation=s.index_generation;
 ELSE
  g=NEW;
  SELECT * INTO s FROM personal_learning_settings WHERE id=g.settings_id FOR UPDATE;
 END IF;
 IF g.state IN ('FAILED','STALE') THEN RETURN NULL; END IF;
 PERFORM os_personal_index_owner(g.id);
 IF ROW(g.settings_version,g.learning_epoch,g.recall_epoch,g.context_revision,g.profile_ref)
  IS DISTINCT FROM ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.choice->>'embeddingProfile')
 THEN RAISE EXCEPTION 'personal_index_current_settings'; END IF;
 SELECT count(*) INTO expected FROM personal_knowledge_entries e WHERE e.settings_id=s.id AND os_personal_index_eligible(e.id);
 SELECT count(*) INTO members FROM personal_index_members WHERE generation_id=g.id;
 SELECT count(*) INTO ready FROM personal_index_pointers p JOIN personal_index_attempts a ON a.id=p.attempt_id
  WHERE p.generation_id=g.id AND a.state='READY';
 IF g.expected_entries<>expected OR members<>expected OR EXISTS(
  SELECT 1 FROM personal_index_members m JOIN personal_knowledge_entries e ON e.id=m.entry_id WHERE m.generation_id=g.id
   AND (NOT COALESCE(os_personal_index_eligible(e.id),false)
    OR ROW(m.revision_id,m.entry_version) IS DISTINCT FROM ROW(e.active_revision_id,e.version)))
 THEN RAISE EXCEPTION 'personal_index_exact_members'; END IF;
 IF g.state='READY' AND (ready<>expected OR s.index_generation<>g.generation OR s.updated_at<>g.completed_at)
  THEN RAISE EXCEPTION 'personal_index_atomic_activation'; END IF;
 IF TG_TABLE_NAME='personal_learning_settings' AND (g.id IS NULL OR g.state<>'READY')
  THEN RAISE EXCEPTION 'personal_index_activation_receipt'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_personal_index_generation AFTER INSERT OR UPDATE ON personal_index_generations
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_personal_index();
CREATE CONSTRAINT TRIGGER commit_personal_index_activation AFTER UPDATE ON personal_learning_settings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (NEW.index_generation<>OLD.index_generation)
 EXECUTE FUNCTION os_commit_personal_index();
DROP TRIGGER commit_knowledge_context ON personal_learning_settings;
CREATE CONSTRAINT TRIGGER commit_knowledge_context AFTER UPDATE ON personal_learning_settings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (NEW.context_revision<>OLD.context_revision)
 EXECUTE FUNCTION os_guard_knowledge_commit();
"""
