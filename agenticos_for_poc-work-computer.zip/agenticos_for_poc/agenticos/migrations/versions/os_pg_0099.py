"""Add explicit direct placement; retain canonical task and admission guards.

Frozen source0098 predecessor. This is an isolated candidate revision requiring
protected populated rehearsal before upstream return; no frozen file is edited.
"""
from alembic import op

revision = 'os_pg_0099'
down_revision = 'os_pg_0098'
branch_labels = None
depends_on = None

DDL = r"""
ALTER TABLE os_dispatches DROP CONSTRAINT ck_dispatch_profile;
ALTER TABLE os_dispatches ADD CONSTRAINT ck_dispatch_profile CHECK (workflow_profile IN ('OSAdmissionTransport/1','OSTaskDriver/1','OSTrustedTaskDriver/1','OSTrustedTaskDriver/2','OSTaskMemoryDriver/1','OSNativeTaskDriver/1','OSAgentTaskDriver/1','OSAgentDirectDriver/1'));
CREATE TABLE os_direct_executions (
 installation_id uuid NOT NULL, application_id uuid NOT NULL, tenant_id varchar(256) NOT NULL, subject_id varchar(256) NOT NULL,
 id uuid PRIMARY KEY, task_id uuid NOT NULL, dispatch_id uuid NOT NULL,
 execution_id varchar(256) NOT NULL UNIQUE, epoch uuid NOT NULL, owner_instance uuid NOT NULL,
 payload_digest varchar(64) NOT NULL, state varchar(16) NOT NULL,
 started_at timestamptz NOT NULL, deadline timestamptz NOT NULL,
 CONSTRAINT uq_direct_owner_id UNIQUE(installation_id,application_id,tenant_id,subject_id,id),
 CONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,task_id) REFERENCES os_tasks(installation_id,application_id,tenant_id,subject_id,id),
 CONSTRAINT fk_os_dispatches_dispatch_id FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,dispatch_id) REFERENCES os_dispatches(installation_id,application_id,tenant_id,subject_id,id),
 CONSTRAINT uq_direct_task UNIQUE(task_id), CONSTRAINT uq_direct_dispatch UNIQUE(dispatch_id),
 CONSTRAINT ck_direct_digest CHECK(payload_digest ~ '^[a-f0-9]{64}$'),
 CONSTRAINT ck_direct_state CHECK(state IN ('STARTING','RUNNING','EXITED','INTERRUPTED')),
 CONSTRAINT ck_direct_horizon CHECK(started_at<deadline)
);
CREATE FUNCTION os_guard_direct_execution() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_dispatches%ROWTYPE; t os_tasks%ROWTYPE; a os_admissions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'direct_execution_retained'; END IF;
 IF TG_OP='UPDATE' THEN
  IF (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state')
   OR NOT ((OLD.state='STARTING' AND NEW.state IN ('RUNNING','INTERRUPTED'))
    OR (OLD.state='RUNNING' AND NEW.state IN ('EXITED','INTERRUPTED')))
   THEN RAISE EXCEPTION 'direct_execution_transition'; END IF;
  RETURN NEW;
 END IF;
 SELECT * INTO d FROM os_dispatches WHERE id=NEW.dispatch_id FOR SHARE;
 SELECT * INTO t FROM os_tasks WHERE id=NEW.task_id FOR SHARE;
 SELECT * INTO a FROM os_admissions WHERE task_id=t.id;
 IF NOT COALESCE(d.task_id=t.id AND d.workflow_id=NEW.execution_id AND d.workflow_profile='OSAgentDirectDriver/1'
  AND d.state='LEASED' AND d.lease_until>clock_timestamp()
  AND (d.installation_id,d.application_id,d.tenant_id,d.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
  AND t.deadline=NEW.deadline AND NEW.deadline>clock_timestamp() AND NEW.started_at<=clock_timestamp()
  AND NEW.state='STARTING' AND a.bot->'runtime'->>'workflowProfile'='OSAgentDirectDriver/1',false)
  THEN RAISE EXCEPTION 'direct_execution_binding'; END IF;
 PERFORM os_assert_agent_admission(a.id);
 RETURN NEW;
END $$;
CREATE TRIGGER guard_direct_execution BEFORE INSERT OR UPDATE OR DELETE ON os_direct_executions
FOR EACH ROW EXECUTE FUNCTION os_guard_direct_execution();
"""

GUARDS = r"""
CREATE OR REPLACE FUNCTION os_guard_agent_profile() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE app os_applications%ROWTYPE; d jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'agent_profile_immutable'; END IF;
 SELECT * INTO app FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR SHARE;
 d:=NEW.payload->'definition';
 IF NOT COALESCE(app.id IS NOT NULL AND app.active AND app.revision=NEW.registration_revision
  AND app.generation=NEW.application_generation AND NEW.created_at<=clock_timestamp()
  AND NEW.digest=os_agent_profile_digest('manifest',NEW.payload)
  AND NEW.payload=jsonb_build_object('definition',d,'runtime',NEW.payload->'runtime','harness',NEW.payload->'harness',
   'model',NEW.payload->'model','resources',NEW.payload->'resources','grantCeiling',NEW.payload->'grantCeiling','capabilities',NEW.payload->'capabilities')
  AND d->>'id'=NEW.definition_ref AND d->>'revision'=NEW.revision::text AND d->>'schema'='agent-production/1'
  AND d->'profile'=os_agent_profile_pin(NEW.payload->'runtime','manifest')
  AND d->'model'=os_agent_profile_pin(NEW.payload->'model','manifest')
  AND d->'harness'=NEW.payload->'harness'->'harness'
  AND d->'capabilityPolicy'=os_agent_profile_pin(NEW.payload->'capabilities','policy')
  AND d->'resourcePolicy'->>'digest'=os_agent_profile_digest('policy',NEW.payload->'resources')
  AND d->'purpose'=NEW.payload->'capabilities'->'purpose'
  AND NEW.payload->'runtime'->>'workflowProfile' IN ('OSAgentTaskDriver/1','OSAgentDirectDriver/1')
  AND (NEW.payload->'runtime'->>'workflowProfile'<>'OSAgentDirectDriver/1' OR (
   (NEW.payload->'runtime'->>'authorizationHorizonMs')::bigint<=120000
   AND (NEW.payload->'runtime'->>'maxActiveTasks')::bigint<=2
   AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements_text(NEW.payload->'capabilities'->'allowedKinds') kind
    WHERE kind NOT IN ('read','propose','effect','memory','schedule')))),false)
  THEN RAISE EXCEPTION 'agent_profile_binding'; END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_assert_agent_admission(aid uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE a os_admissions%ROWTYPE; p os_agent_profiles%ROWTYPE; t os_tasks%ROWTYPE;
 r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; s os_segments%ROWTYPE;
 i os_source_inputs%ROWTYPE; c os_commands%ROWTYPE; d os_dispatches%ROWTYPE; ctrl os_task_controls%ROWTYPE;
 owner_json jsonb; configured jsonb; admitted timestamptz; horizon timestamptz;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_admissions WHERE id=aid;
 IF a.context->>'accountingFormat' IS DISTINCT FROM 'agent-resources/1' THEN RETURN; END IF;
 SELECT * INTO t FROM os_tasks WHERE id=a.task_id;
 SELECT * INTO p FROM os_agent_profiles WHERE installation_id=a.installation_id AND application_id=a.application_id
  AND definition_ref=t.definition_ref AND revision=t.definition_revision;
 SELECT * INTO r FROM os_budget_roots WHERE id=t.budget_root_id;
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=r.id;
 SELECT * INTO s FROM os_segments WHERE id=a.segment_id;
 SELECT * INTO i FROM os_source_inputs WHERE id=a.source_input_id;
 SELECT * INTO c FROM os_commands WHERE accepted_task_id=t.id AND kind='agent.task.start';
 SELECT * INTO d FROM os_dispatches WHERE task_id=t.id;
 SELECT * INTO ctrl FROM os_task_controls WHERE task_id=t.id;
 owner_json:=jsonb_build_object('installationId',a.installation_id,'applicationId',a.application_id,'tenantId',a.tenant_id,'subjectId',a.subject_id);
 configured:=p.payload->'definition';
 admitted:=(a.context->>'admittedAt')::timestamptz; horizon:=(a.context->>'authorizationHorizon')::timestamptz;
 IF NOT COALESCE(p.definition_ref IS NOT NULL AND a.bot=p.payload
  AND p.digest=os_agent_profile_digest('manifest',p.payload) AND p.registration_revision=a.registration_revision
  AND p.application_generation=q.application_generation
  AND configured->>'lifecycle'='qualified' AND p.payload->'model'->>'lifecycle'='qualified'
  AND r.id IS NOT NULL AND r.accounting_format='agent-resources/1' AND r.profile_ref='agent-production/1'
  AND r.root_task_id=t.id AND r.admission_id=a.id AND r.definition_digest=os_agent_profile_digest('definition',configured)
  AND q.id IS NOT NULL AND q.policy=p.payload->'resources' AND q.grant_ceiling=p.payload->'grantCeiling'
  AND q.policy_ref=configured->'resourcePolicy'->>'ref' AND q.policy_revision::text=configured->'resourcePolicy'->>'revision'
  AND q.policy_digest=configured->'resourcePolicy'->>'digest' AND q.purpose=configured->>'purpose'
  AND r.ceiling=p.payload->'resources'->'limits' AND q.horizon=r.deadline AND t.deadline=r.deadline AND horizon=r.deadline
  AND admitted=c.created_at AND admitted<=clock_timestamp() AND admitted<horizon
  AND horizon<=admitted+((p.payload->'runtime'->>'authorizationHorizonMs')::bigint*interval '1 millisecond')
  AND EXISTS(SELECT 1 FROM pg_timezone_names WHERE name=p.payload->'runtime'->>'timeZone')
  AND a.context=jsonb_build_object('subject',owner_json,'taskId',t.id,'conversationId',t.conversation_id,'segmentId',s.id,
   'purpose',configured->'purpose','definition',os_agent_profile_pin(configured,'definition'),
   'profile',configured->'profile','harness',configured->'harness','model',configured->'model','resourcePolicy',configured->'resourcePolicy',
   'authorityRef',a.context->'authorityRef','scopeRef',a.context->'scopeRef','delegationRef',NULL,
   'rootId',r.id,'accountingFormat','agent-resources/1','intentRevision',1,'controlEpoch',1,
   'admittedAt',a.context->'admittedAt','authorizationHorizon',a.context->'authorizationHorizon','timeZone',p.payload->'runtime'->'timeZone')
  AND s.task_id=t.id AND s.conversation_id=t.conversation_id AND s.ordinal=1 AND s.state='OPEN'
  AND ctrl.epoch=1 AND ctrl.state='ACTIVE' AND i.admitted_task_id=t.id AND i.expires_at>admitted
  AND c.id IS NOT NULL AND d.command_id=c.id AND d.workflow_profile=p.payload->'runtime'->>'workflowProfile'
  AND d.workflow_profile IN ('OSAgentTaskDriver/1','OSAgentDirectDriver/1')
  AND a.authority->'subject'=owner_json AND q.session_id::text=a.authority->>'sessionId'
  AND a.digest=os_agent_profile_digest('command',jsonb_build_object('commandDigest',c.request_digest,
   'context',a.context,'bot',a.bot,'authority',a.authority,'sourceDigest',i.digest,'registrationRevision',a.registration_revision))
  AND a.launch=jsonb_build_object('installationId',a.installation_id,'applicationId',a.application_id,'taskId',t.id,'admissionDigest',a.digest),false)
  THEN RAISE EXCEPTION 'agent_admission_binding'; END IF;
 PERFORM os_agent_resource_owner(q);
 PERFORM os_assert_agent_memory_context(a.context,true);
END $$;

CREATE OR REPLACE FUNCTION os_guard_agent_admission_commit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_TABLE_NAME='os_admissions' THEN PERFORM os_assert_agent_admission(NEW.id);
 ELSIF NEW.workflow_profile IN ('OSAgentTaskDriver/1','OSAgentDirectDriver/1') THEN
  IF NOT EXISTS(SELECT 1 FROM os_admissions WHERE task_id=NEW.task_id AND context->>'accountingFormat'='agent-resources/1')
   THEN RAISE EXCEPTION 'agent_dispatch_admission'; END IF;
  PERFORM os_assert_agent_admission((SELECT id FROM os_admissions WHERE task_id=NEW.task_id));
 END IF;
 RETURN NULL;
END $$;
"""

# Exact current0095 tool predicates, with the explicit direct DTO adapter only.
TOOL_GUARDS = r"""
CREATE OR REPLACE FUNCTION os_assert_agent_tool_current(o os_agent_tool_operations) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; app os_applications%ROWTYPE; parent os_agent_operations%ROWTYPE;
 accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; w os_agent_payload_writes%ROWTYPE; cap os_agent_capabilities%ROWTYPE;
 c jsonb; i jsonb; dep jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM os_assert_agent_memory_context(o.payload->'context',true);
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=o.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (o.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=o.root_id)) ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=o.root_id FOR UPDATE;SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=o.installation_id AND id=o.application_id;
 c:=o.payload->'context';i:=o.payload->'identity';dep:=o.payload->'modelResult';
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO parent FROM os_agent_operations WHERE id=o.parent_operation_id;
 SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=o.source_acceptance_id;
 SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
 SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=o.binding_id;
 SELECT * INTO w FROM os_agent_payload_writes WHERE id=f.write_id;
 SELECT * INTO cap FROM os_agent_capabilities WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND application_generation=app.generation AND capability_ref=o.payload->'capability'->>'ref' ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND r.accounting_format='agent-resources/1'
 AND ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
 AND os_agent_context_matches(a,c) AND o.task_id=r.root_task_id AND o.digest=os_agent_profile_digest('command',o.payload)
 AND o.payload=jsonb_build_object('context',c,'identity',i,'binding',o.payload->'binding','modelOperationId',o.parent_operation_id,
  'modelResult',dep,'capability',o.payload->'capability','profile',o.payload->'profile')
 AND i=jsonb_build_object('operationId',o.id,'taskId',o.task_id,'rootId',o.root_id,'segmentId',a.segment_id,
  'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','planRevision',parent.payload->'identity'->'planRevision',
  'parentOperationId',o.parent_operation_id,'iteration',parent.payload->'identity'->'iteration','kind','tool','inputDigest',i->'inputDigest')
 AND i->>'inputDigest' ~ '^[a-f0-9]{64}$' AND parent.root_id=o.root_id AND parent.payload->'context'=c
 AND producer.root_id=o.root_id AND producer.request->'context'=c AND producer.expires_at>clock_timestamp()
 AND EXISTS(SELECT 1 FROM os_agent_operation_models link WHERE link.operation_id=parent.id AND link.id=producer.id)
 AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
   'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
   'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
   'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
 AND (dep->>'acceptedAt')::timestamptz=accepted.created_at
 AND ROW(producer.installation_id,producer.application_id,producer.tenant_id,producer.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND (w.model_context=c OR w.model_context IS NULL AND c=a.context AND c->'harness'->>'ref' NOT LIKE 'private-planned-read/%')
 AND w.task_id=o.task_id AND w.root_id=o.root_id AND w.schema_ref='AgentSDKToolBinding' AND w.schema_version=1 AND w.expires_at>clock_timestamp()
 AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND o.payload->'binding'=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',w.plain_bytes,'schemaRef',w.schema_ref,'schemaVersion',w.schema_version)
 AND p.application_generation=app.generation AND p.registration_revision=app.revision AND p.digest=os_agent_profile_digest('policy',p.payload)
 AND o.payload->'profile'=jsonb_build_object('ref',p.payload->'execution'->'id','revision',p.payload->'execution'->'revision','digest',p.policy_digest)
 AND ((p.payload->'verification'->'capability'=o.payload->'capability'
  AND p.payload->'verification'->'harness'=c->'harness' AND c=a.context
  AND p.payload->'verification'->>'installationId'=o.installation_id::text
  AND p.payload->'verification'->>'applicationId'=o.application_id::text
  AND cap.payload->>'kind'='native' AND cap.payload->>'adapterRef'='native.verify-tool/1'
  AND cap.payload->>'scopePolicyRef'='owner-cases-verified-tool/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix))
 OR (p.payload->'read'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='read' AND (cap.payload->>'adapterRef'='mcp.read/1' OR (cap.payload->>'adapterRef'='poc.mcp.read/1' AND a.bot->'runtime'->>'workflowProfile'='OSAgentDirectDriver/1')))
 OR (p.payload->'preparation'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='propose'
  AND cap.payload->>'adapterRef'='typed.prepare/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'memory'->'capability'=o.payload->'capability' AND p.payload->'memory'->'harness'=c->'harness'
  AND p.payload->'memory'->>'installationId'=o.installation_id::text
  AND p.payload->'memory'->>'applicationId'=o.application_id::text AND cap.payload->>'kind'='memory'
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)
  AND cap.payload->>'adapterRef'='owner.memory.read/1' AND cap.payload->>'scopePolicyRef'='owner-approved-memory/1'
  AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'knowledge'->'capability'=o.payload->'capability' AND p.payload->'knowledge'->'harness'=c->'harness'
  AND c<>a.context AND p.payload->'knowledge'->'planning'=CASE WHEN jsonb_typeof(p.payload->'knowledge')='object' THEN os_agent_planning_profile(a) ELSE NULL END
  AND p.payload->'knowledge'->>'installationId'=o.installation_id::text
  AND p.payload->'knowledge'->>'applicationId'=o.application_id::text
  AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='private.knowledge.read/1'
  AND cap.payload->>'scopePolicyRef'='private-reviewed-knowledge/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'discovery'->'capability'=o.payload->'capability' AND p.payload->'discovery'->'harness'=c->'harness'
  AND c=a.context AND p.payload->'discovery'->'planning'=CASE WHEN jsonb_typeof(p.payload->'discovery')='object' THEN os_agent_discovery_profile(a) ELSE NULL END
  AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='os.capabilities.discover/1'
  AND cap.payload->>'scopePolicyRef'='current-task-capability-metadata/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix))
 OR (p.payload->'proactive'->'capability'=o.payload->'capability' AND p.payload->'proactive'->'harness'=c->'harness'
  AND c=a.context AND p.payload->'proactive'->'planning'=CASE WHEN jsonb_typeof(p.payload->'proactive')='object' THEN os_agent_proactive_profile(a) ELSE NULL END
  AND cap.payload->>'kind'='schedule' AND cap.payload->>'adapterRef'='os.proactivity.prepare/1'
  AND cap.payload->>'scopePolicyRef'='owner-reviewed-proactivity/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)))
 AND os_agent_capability_matches(a,c,o.payload->'capability')
 AND cap.payload->>'lifecycle'='qualified' AND cap.payload->>'purpose'=c->>'purpose'
 AND o.payload->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
 AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=o.task_id
  AND k.state='ACTIVE' AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp()
  AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
 AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.task_id=o.task_id AND s.state='OPEN'),false)
 THEN RAISE EXCEPTION 'agent_tool_operation_binding'; END IF;
END $$;
"""

def upgrade():
    op.execute(GUARDS)
    op.execute(DDL)
    op.execute(TOOL_GUARDS)


def downgrade():
    raise RuntimeError("Direct execution requires independent predecessor recovery; preserve unresolved outcomes")
