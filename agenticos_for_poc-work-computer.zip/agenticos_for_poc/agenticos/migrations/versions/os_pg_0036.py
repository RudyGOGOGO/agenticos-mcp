"""Atomic reviewed publication, exact supersession and source-bound erasure."""
from alembic import op

revision = "os_pg_0036"
down_revision = "os_pg_0035"
branch_labels = None
depends_on = None


def upgrade():
    for statement in TABLES:
        op.get_bind().exec_driver_sql(statement)
    op.execute("ALTER TABLE personal_knowledge_entries DROP CONSTRAINT ck_knowledge_entry_states")
    op.execute("ALTER TABLE personal_knowledge_entries ADD CONSTRAINT ck_knowledge_entry_states CHECK (state IN ('ACTIVE','PAUSED','SUPERSEDED','FORGOTTEN') AND projection_state IN ('PENDING','PURGING','PURGED'))")
    op.execute(GUARDS)
    op.execute(LEGACY_GUARDS)


# Static snapshots; no live model or prior migration imports.
TABLES = (
    """
CREATE TABLE personal_candidate_decisions (
    id UUID NOT NULL,
    candidate_id UUID NOT NULL,
    candidate_revision_id UUID NOT NULL,
    session_id UUID NOT NULL,
    command_id UUID NOT NULL,
    expected_version BIGINT NOT NULL,
    accepted_version BIGINT NOT NULL,
    decision VARCHAR(24) NOT NULL,
    context_revision BIGINT NOT NULL,
    request_mac VARCHAR(64),
    mac_key_id UUID,
    receipt JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    installation_id UUID NOT NULL,
    application_id UUID NOT NULL,
    tenant_id VARCHAR(256) NOT NULL,
    subject_id VARCHAR(256) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_candidate_decision_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_candidates_candidate_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_id) REFERENCES personal_knowledge_candidates (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_candidate_revisions_candidate_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_revision_id) REFERENCES personal_knowledge_candidate_revisions (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT uq_candidate_decision_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id),
    CONSTRAINT uq_candidate_decision_once UNIQUE (installation_id, application_id, tenant_id, subject_id, candidate_id),
    CONSTRAINT ck_candidate_decision_versions CHECK (decision IN ('accept','edit-and-accept','reject') AND expected_version BETWEEN 1 AND 64 AND accepted_version=expected_version+(CASE WHEN decision='edit-and-accept' THEN 1 ELSE 0 END) AND accepted_version<=64 AND context_revision>0),
    CONSTRAINT ck_candidate_decision_mac CHECK ((request_mac IS NULL AND mac_key_id IS NULL) OR (request_mac IS NOT NULL AND request_mac ~ '^[a-f0-9]{64}$' AND mac_key_id IS NOT NULL))
)
""",
    """
CREATE TABLE personal_knowledge_publications (
    id UUID NOT NULL,
    decision_id UUID NOT NULL,
    candidate_id UUID NOT NULL,
    candidate_revision_id UUID NOT NULL,
    entry_id UUID NOT NULL,
    revision_id UUID NOT NULL,
    operation_id UUID NOT NULL,
    epistemic VARCHAR(24) NOT NULL,
    operation VARCHAR(16) NOT NULL,
    target_count BIGINT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    installation_id UUID NOT NULL,
    application_id UUID NOT NULL,
    tenant_id VARCHAR(256) NOT NULL,
    subject_id VARCHAR(256) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_knowledge_publication_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_candidate_decisions_decision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, decision_id) REFERENCES personal_candidate_decisions (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_candidates_candidate_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_id) REFERENCES personal_knowledge_candidates (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_candidate_revisions_candidate_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, candidate_revision_id) REFERENCES personal_knowledge_candidate_revisions (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_operations_operation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, operation_id) REFERENCES personal_knowledge_operations (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT uq_knowledge_publication_candidate UNIQUE (installation_id, application_id, tenant_id, subject_id, candidate_id),
    CONSTRAINT uq_knowledge_publication_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, entry_id, revision_id),
    CONSTRAINT uq_knowledge_publication_operation UNIQUE (installation_id, application_id, tenant_id, subject_id, operation_id),
    CONSTRAINT ck_knowledge_publication_operation CHECK (epistemic='user-stated' AND ((operation='add' AND target_count=0) OR (operation='supersede' AND target_count=1) OR (operation='merge' AND target_count BETWEEN 2 AND 8)))
)
""",
    """
CREATE TABLE personal_knowledge_supersessions (
    id UUID NOT NULL,
    publication_id UUID NOT NULL,
    entry_id UUID NOT NULL,
    revision_id UUID NOT NULL,
    expected_version BIGINT NOT NULL,
    accepted_version BIGINT NOT NULL,
    prior_state VARCHAR(16) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    installation_id UUID NOT NULL,
    application_id UUID NOT NULL,
    tenant_id VARCHAR(256) NOT NULL,
    subject_id VARCHAR(256) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_knowledge_supersession_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_publications_publication_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, publication_id) REFERENCES personal_knowledge_publications (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT fk_personal_knowledge_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, id),
    CONSTRAINT uq_knowledge_supersession_member UNIQUE (installation_id, application_id, tenant_id, subject_id, publication_id, entry_id),
    CONSTRAINT uq_knowledge_supersession_version UNIQUE (installation_id, application_id, tenant_id, subject_id, entry_id, accepted_version),
    CONSTRAINT ck_knowledge_supersession_transition CHECK (expected_version>0 AND accepted_version=expected_version+1 AND prior_state IN ('ACTIVE','PAUSED'))
)
""",
)
LEGACY_GUARDS = r"""
CREATE OR REPLACE FUNCTION os_guard_knowledge_entry() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'knowledge_entry_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.version<>1 OR NEW.content_revision<>1 OR NEW.state<>'ACTIVE' OR NEW.projection_state<>'PENDING'
   OR NEW.created_at<>NEW.updated_at THEN RAISE EXCEPTION 'knowledge_initial_entry'; END IF;
 ELSE
  IF (to_jsonb(NEW)-ARRAY['version','content_revision','active_revision_id','state','projection_state','valid_until','updated_at'])
    IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['version','content_revision','active_revision_id','state','projection_state','valid_until','updated_at'])
    OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'knowledge_entry_identity'; END IF;
  IF NEW.version=OLD.version THEN
   IF OLD.state<>'FORGOTTEN' OR OLD.projection_state<>'PURGING' OR NEW.projection_state<>'PURGED'
    OR (to_jsonb(NEW)-'projection_state') IS DISTINCT FROM (to_jsonb(OLD)-'projection_state')
    THEN RAISE EXCEPTION 'knowledge_cleanup_transition'; END IF;
  ELSIF NEW.version<>OLD.version+1 OR OLD.state='FORGOTTEN' THEN RAISE EXCEPTION 'knowledge_entry_version';
  ELSIF NEW.active_revision_id IS DISTINCT FROM OLD.active_revision_id THEN
   IF NEW.content_revision<>OLD.content_revision+1 OR NEW.state<>'ACTIVE' OR NEW.projection_state<>'PENDING'
    THEN RAISE EXCEPTION 'knowledge_revision_transition'; END IF;
  ELSIF NEW.state='SUPERSEDED' THEN
   IF OLD.state NOT IN ('ACTIVE','PAUSED') OR NEW.content_revision<>OLD.content_revision
    OR NEW.valid_until IS DISTINCT FROM OLD.valid_until OR NEW.projection_state<>'PENDING'
    THEN RAISE EXCEPTION 'knowledge_supersession_transition'; END IF;
  ELSE
   IF NEW.content_revision<>OLD.content_revision OR NEW.valid_until IS DISTINCT FROM OLD.valid_until
    OR NOT ((OLD.state='ACTIVE' AND NEW.state='PAUSED') OR (OLD.state='PAUSED' AND NEW.state='ACTIVE') OR NEW.state='FORGOTTEN')
    OR NEW.projection_state<>(CASE WHEN NEW.state='FORGOTTEN' THEN 'PURGING' ELSE 'PENDING' END)
    THEN RAISE EXCEPTION 'knowledge_state_transition'; END IF;
  END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_assert_knowledge_entry(eid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE e personal_knowledge_entries%ROWTYPE; r personal_knowledge_revisions%ROWTYPE;
 s personal_learning_settings%ROWTYPE; c personal_knowledge_operations%ROWTYPE;
 session os_interactive_sessions%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
 j personal_forget_journal%ROWTYPE; p personal_knowledge_projection_jobs%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=e.settings_id;
 SELECT * INTO r FROM personal_knowledge_revisions WHERE id=e.active_revision_id;

 IF e.state='SUPERSEDED' THEN PERFORM os_assert_knowledge_supersession(e.id,live);RETURN;END IF;
 IF r.envelope IS NULL AND os_revision_source_forgotten(r.id) AND e.state<>'FORGOTTEN' THEN
  IF live OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE revision_id=r.id AND operation='INDEX' AND state='PENDING')
   OR EXISTS(SELECT 1 FROM personal_knowledge_operations WHERE id=r.operation_id AND request_mac IS NOT NULL)
   THEN RAISE EXCEPTION 'knowledge_source_cleanup_incomplete';END IF;
  RETURN;
 END IF;
 SELECT * INTO c FROM personal_knowledge_operations WHERE entry_id=e.id AND accepted_version=e.version;
 IF e.id IS NULL OR s.id IS NULL OR r.id IS NULL OR c.id IS NULL
  OR r.entry_id<>e.id OR r.ordinal<>e.content_revision OR c.settings_id<>s.id
  OR c.created_at<>e.updated_at OR c.context_revision>s.context_revision
  OR c.receipt IS DISTINCT FROM jsonb_build_object('commandId',c.command_id,'operationId',c.id,'entryId',e.id,
    'revision',e.version,'contextRevision',c.context_revision,'state',e.state,
    'projectionState',CASE WHEN e.state='FORGOTTEN' THEN 'PURGING' ELSE 'PENDING' END)
 THEN RAISE EXCEPTION 'knowledge_atomic_receipt'; END IF;
 IF live THEN
  IF c.context_revision<>s.context_revision OR s.updated_at<>c.created_at OR c.request_mac IS NULL
   THEN RAISE EXCEPTION 'knowledge_atomic_context'; END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=c.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=e.installation_id AND id=e.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=e.installation_id AND application_id=e.application_id
   AND tenant_id=e.tenant_id AND subject_id=e.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'knowledge_current_owner'; END IF;
 END IF;
 IF e.state='FORGOTTEN' THEN
  SELECT * INTO j FROM personal_forget_journal WHERE entry_id=e.id;
  SELECT * INTO p FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND entry_version=e.version;
  IF c.kind<>'FORGET' OR j.id IS NULL OR j.operation_id<>c.id OR j.context_revision<>c.context_revision
   OR j.forgotten_at<>c.created_at OR p.id IS NULL OR p.operation<>'PURGE' OR p.operation_id<>c.id
   OR p.created_at<>c.created_at OR p.revision_id<>r.id
   OR (e.projection_state='PURGING' AND (j.completed_at IS NOT NULL OR p.state<>'PENDING'))
   OR (e.projection_state='PURGED' AND (j.completed_at IS NULL OR p.state<>'COMPLETE'
    OR EXISTS(SELECT 1 FROM personal_knowledge_revisions WHERE entry_id=e.id AND envelope IS NOT NULL)
    OR EXISTS(SELECT 1 FROM personal_knowledge_operations WHERE entry_id=e.id AND kind<>'FORGET' AND request_mac IS NOT NULL)))
   OR e.projection_state NOT IN ('PURGING','PURGED')
   OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND operation='INDEX' AND state='PENDING')
   THEN RAISE EXCEPTION 'knowledge_forget_barrier'; END IF;
 ELSE
  IF r.envelope IS NULL OR e.projection_state<>'PENDING' OR EXISTS(SELECT 1 FROM personal_forget_journal WHERE entry_id=e.id)
   THEN RAISE EXCEPTION 'knowledge_live_revision'; END IF;
  IF c.kind IN ('SAVE','REVISE') AND (r.operation_id<>c.id OR r.created_at<>c.created_at)
   THEN RAISE EXCEPTION 'knowledge_revision_operation'; END IF;
  IF live AND c.kind IN ('SAVE','REVISE','RESUME') AND e.valid_until IS NOT NULL AND e.valid_until<=clock_timestamp()
   THEN RAISE EXCEPTION 'knowledge_expired_publication'; END IF;
  IF e.state='ACTIVE' THEN
   SELECT * INTO p FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND entry_version=e.version;
   IF c.kind NOT IN ('SAVE','REVISE','RESUME') OR p.id IS NULL OR p.operation<>'INDEX' OR p.state<>'PENDING'
    OR p.revision_id<>r.id OR p.operation_id<>c.id OR p.created_at<>c.created_at
    OR p.index_generation<>s.index_generation OR (live AND p.recall_epoch<>s.recall_epoch)
    THEN RAISE EXCEPTION 'knowledge_projection_intent'; END IF;
  ELSIF c.kind<>'PAUSE' OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND state='PENDING')
   THEN RAISE EXCEPTION 'knowledge_pause_barrier'; END IF;
 END IF;
END $$;

CREATE OR REPLACE FUNCTION os_guard_knowledge_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE e personal_knowledge_entries%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'knowledge_record_retained'; END IF;
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=OLD.entry_id;
 IF TG_TABLE_NAME='personal_knowledge_revisions' THEN
  IF OLD.envelope IS NULL OR NEW.envelope IS NOT NULL OR (e.state<>'FORGOTTEN' AND NOT os_revision_source_forgotten(OLD.id))
   OR (to_jsonb(NEW)-'envelope') IS DISTINCT FROM (to_jsonb(OLD)-'envelope')
   THEN RAISE EXCEPTION 'knowledge_revision_immutable'; END IF;
 ELSIF TG_TABLE_NAME='personal_knowledge_operations' THEN
  IF OLD.kind='FORGET' OR OLD.request_mac IS NULL OR NEW.request_mac IS NOT NULL OR NEW.mac_key_id IS NOT NULL
   OR (e.state<>'FORGOTTEN' AND NOT EXISTS(SELECT 1 FROM personal_knowledge_publications p WHERE p.operation_id=OLD.id AND os_revision_source_forgotten(p.revision_id))) OR (to_jsonb(NEW)-ARRAY['request_mac','mac_key_id']) IS DISTINCT FROM
    (to_jsonb(OLD)-ARRAY['request_mac','mac_key_id']) THEN RAISE EXCEPTION 'knowledge_operation_immutable'; END IF;
 ELSE
  IF OLD.completed_at IS NOT NULL OR NEW.completed_at IS NULL OR e.state<>'FORGOTTEN'
   OR (to_jsonb(NEW)-'completed_at') IS DISTINCT FROM (to_jsonb(OLD)-'completed_at')
   THEN RAISE EXCEPTION 'knowledge_journal_immutable'; END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_knowledge_job() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE e personal_knowledge_entries%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'knowledge_job_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'PENDING' THEN RAISE EXCEPTION 'knowledge_job_initial'; END IF;
 ELSE
  SELECT * INTO e FROM personal_knowledge_entries WHERE id=OLD.entry_id;
  IF OLD.state<>'PENDING' OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state')
   OR NOT ((OLD.operation='INDEX' AND NEW.state='CANCELLED' AND (e.version>OLD.entry_version OR e.state<>'ACTIVE' OR os_revision_source_forgotten(OLD.revision_id)))
    OR (OLD.operation='PURGE' AND NEW.state='COMPLETE' AND e.state='FORGOTTEN'))
   THEN RAISE EXCEPTION 'knowledge_job_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_guard_knowledge_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE eid uuid; live boolean; e personal_knowledge_entries%ROWTYPE; c personal_knowledge_operations%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE settings_id=NEW.id AND context_revision=NEW.context_revision;
  IF c.id IS NULL THEN RAISE EXCEPTION 'knowledge_context_receipt'; END IF;
  eid=c.entry_id; live=true;
 ELSIF TG_TABLE_NAME='personal_knowledge_entries' THEN
  eid=NEW.id; live=(TG_OP='INSERT');
  IF TG_OP='UPDATE' THEN live=NEW.version<>OLD.version; END IF;
  IF NEW.state='SUPERSEDED' THEN
   IF TG_OP='UPDATE' AND live THEN
    IF NOT EXISTS(SELECT 1 FROM personal_knowledge_supersessions m WHERE m.entry_id=NEW.id
     AND m.expected_version=OLD.version AND m.accepted_version=NEW.version AND m.prior_state=OLD.state)
     THEN RAISE EXCEPTION 'knowledge_reviewed_target_transition';END IF;
   END IF;
   PERFORM os_assert_knowledge_supersession(eid,live);RETURN NULL;
  END IF;
  IF live THEN
   SELECT * INTO c FROM personal_knowledge_operations WHERE entry_id=eid AND accepted_version=NEW.version;
   IF TG_OP='INSERT' THEN
    IF c.kind IS DISTINCT FROM 'SAVE' THEN RAISE EXCEPTION 'knowledge_save_operation'; END IF;
   ELSE
    IF c.kind IS DISTINCT FROM (CASE WHEN NEW.active_revision_id<>OLD.active_revision_id THEN 'REVISE'
     WHEN NEW.state='FORGOTTEN' THEN 'FORGET' WHEN NEW.state='PAUSED' THEN 'PAUSE' ELSE 'RESUME' END)
     THEN RAISE EXCEPTION 'knowledge_transition_operation'; END IF;
   END IF;
  END IF;
 ELSE
  eid=NEW.entry_id; live=(TG_OP='INSERT');
  -- PL/pgSQL resolves record fields when preparing an expression, even if
  -- another operand in that expression would make an AND condition false.
  IF TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
   IF TG_OP='UPDATE' AND NEW.state='CANCELLED' THEN RETURN NULL; END IF;
  END IF;
 END IF;
 PERFORM os_assert_knowledge_entry(eid,live);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;
 IF TG_OP='UPDATE' AND TG_TABLE_NAME='personal_knowledge_revisions' THEN
  IF os_revision_source_forgotten(NEW.id) THEN RETURN NULL;END IF;
 ELSIF TG_OP='UPDATE' AND TG_TABLE_NAME='personal_knowledge_operations' THEN
  IF EXISTS(SELECT 1 FROM personal_knowledge_publications p WHERE p.operation_id=NEW.id AND os_revision_source_forgotten(p.revision_id))
   THEN RETURN NULL;END IF;
 END IF;
 IF NOT live AND TG_TABLE_NAME IN ('personal_knowledge_revisions','personal_knowledge_operations','personal_forget_journal')
  AND e.projection_state<>'PURGED' THEN RAISE EXCEPTION 'knowledge_cleanup_incomplete'; END IF;
 IF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_revisions' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE id=NEW.operation_id;
  IF NEW.id<>e.active_revision_id OR NEW.envelope IS NULL OR c.kind NOT IN ('SAVE','REVISE')
   OR c.accepted_version<>e.version OR NEW.created_at<>c.created_at
   THEN RAISE EXCEPTION 'knowledge_revision_binding'; END IF;
 ELSIF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
  IF NEW.entry_version<>e.version OR NEW.revision_id<>e.active_revision_id THEN RAISE EXCEPTION 'knowledge_job_binding'; END IF;
 END IF;
 RETURN NULL;
END $$;
"""

GUARDS = r"""
CREATE FUNCTION os_revision_source_forgotten(rid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_knowledge_publications p JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
 JOIN personal_learning_sources s ON s.id=e.source_id WHERE p.revision_id=rid AND s.state='FORGOTTEN')
$$;
CREATE FUNCTION os_revision_sources_current(rid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT NOT EXISTS(SELECT 1 FROM personal_knowledge_publications p JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
 JOIN personal_learning_sources s ON s.id=e.source_id WHERE p.revision_id=rid AND
 (s.state<>'AVAILABLE' OR s.revision<>e.source_revision OR s.expires_at<=clock_timestamp()))
$$;
CREATE FUNCTION os_candidate_erasure_allowed(cid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT os_learning_candidate_invalid(cid) OR EXISTS(SELECT 1 FROM personal_knowledge_publications p
 JOIN personal_knowledge_entries e ON e.id=p.entry_id WHERE p.candidate_id=cid AND e.state='FORGOTTEN')
$$;

CREATE FUNCTION os_assert_candidate_decision(did uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE d personal_candidate_decisions%ROWTYPE; c personal_knowledge_candidates%ROWTYPE;
 r personal_knowledge_candidate_revisions%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 s personal_learning_settings%ROWTYPE; p personal_knowledge_publications%ROWTYPE;
 op personal_knowledge_operations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; expected jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO d FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=d.candidate_id;
 SELECT * INTO r FROM personal_knowledge_candidate_revisions WHERE id=d.candidate_revision_id;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO p FROM personal_knowledge_publications WHERE decision_id=d.id;
 IF d.id IS NULL OR c.id IS NULL OR r.id IS NULL OR j.state IS DISTINCT FROM 'SUCCEEDED' OR s.id IS NULL
  OR r.candidate_id<>c.id OR r.ordinal<>d.accepted_version OR c.version<>d.accepted_version
  OR c.state<>(CASE WHEN d.decision='reject' THEN 'REJECTED' ELSE 'ACCEPTED' END)
  OR c.updated_at<>d.created_at OR d.context_revision>s.context_revision
  OR (r.envelope IS NULL AND NOT os_candidate_erasure_allowed(c.id))
  THEN RAISE EXCEPTION 'candidate_decision_binding'; END IF;
 IF d.decision='reject' THEN
  IF p.id IS NOT NULL THEN RAISE EXCEPTION 'candidate_rejection_publication'; END IF;
  expected='null'::jsonb;
 ELSE
  SELECT * INTO op FROM personal_knowledge_operations WHERE id=p.operation_id;
  IF p.id IS NULL OR p.candidate_id<>c.id OR p.candidate_revision_id<>r.id OR p.created_at<>d.created_at
   OR op.id IS NULL OR op.kind<>'SAVE' OR op.entry_id<>p.entry_id OR op.command_id<>d.command_id
   OR op.session_id<>d.session_id OR op.context_revision<>d.context_revision OR op.created_at<>d.created_at
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions kr WHERE kr.id=p.revision_id AND kr.entry_id=p.entry_id AND kr.operation_id=op.id)
   OR (SELECT count(*) FROM personal_knowledge_supersessions WHERE publication_id=p.id)<>p.target_count
   THEN RAISE EXCEPTION 'candidate_atomic_publication'; END IF;
  expected=op.receipt;
 END IF;
 IF d.receipt IS DISTINCT FROM jsonb_build_object('commandId',d.command_id,'decisionId',d.id,'candidateId',c.id,
  'candidateRevision',c.version,'state',c.state,'contextRevision',d.context_revision,'knowledge',expected)
  THEN RAISE EXCEPTION 'candidate_atomic_receipt'; END IF;
 IF live THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE id=d.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=d.installation_id AND application_id=d.application_id
   AND tenant_id=d.tenant_id AND subject_id=d.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp() OR d.request_mac IS NULL
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation OR owner.id IS NULL
   OR NOT owner.active OR owner.generation<>session.subject_generation OR c.expires_at<=clock_timestamp()
   OR os_learning_candidate_invalid(c.id) THEN RAISE EXCEPTION 'candidate_current_review'; END IF;
  IF d.decision<>'reject' THEN
   IF s.context_revision<>d.context_revision OR s.updated_at<>d.created_at OR s.learning_epoch<>j.learning_epoch
    OR s.choice->'learnConversation' IS DISTINCT FROM 'true'::jsonb OR s.choice->>'extractorProfile'<>j.profile_ref
    OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
     IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
    THEN RAISE EXCEPTION 'candidate_current_learning'; END IF;
   PERFORM os_assert_knowledge_entry(p.entry_id,true);
  END IF;
 END IF;
END $$;

CREATE FUNCTION os_assert_knowledge_supersession(eid uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE e personal_knowledge_entries%ROWTYPE; m personal_knowledge_supersessions%ROWTYPE;
 p personal_knowledge_publications%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;
 SELECT * INTO m FROM personal_knowledge_supersessions WHERE entry_id=e.id AND accepted_version=e.version;
 SELECT * INTO p FROM personal_knowledge_publications WHERE id=m.publication_id;
 IF e.state IS DISTINCT FROM 'SUPERSEDED' OR m.id IS NULL OR p.id IS NULL OR e.active_revision_id<>m.revision_id
  OR e.updated_at<>p.created_at OR m.created_at<>p.created_at OR e.projection_state<>'PENDING'
  OR p.entry_id=e.id OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions WHERE id=m.revision_id AND entry_id=e.id)
  OR NOT EXISTS(SELECT 1 FROM personal_knowledge_operations WHERE entry_id=e.id AND accepted_version=m.expected_version)
  OR EXISTS(SELECT 1 FROM personal_knowledge_projection_jobs WHERE entry_id=e.id AND state='PENDING')
  THEN RAISE EXCEPTION 'knowledge_exact_supersession'; END IF;
 PERFORM os_assert_candidate_decision(p.decision_id,live);
 IF live AND ((e.valid_until IS NOT NULL AND e.valid_until<=clock_timestamp()) OR NOT os_revision_sources_current(m.revision_id))
  THEN RAISE EXCEPTION 'knowledge_supersession_source_expired'; END IF;
END $$;

CREATE FUNCTION os_guard_publication_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'knowledge_publication_retained'; END IF;
 IF TG_TABLE_NAME<>'personal_candidate_decisions' THEN RAISE EXCEPTION 'knowledge_publication_immutable'; END IF;
 IF OLD.request_mac IS NULL OR NEW.request_mac IS NOT NULL OR NEW.mac_key_id IS NOT NULL
  OR NOT os_candidate_erasure_allowed(OLD.candidate_id)
  OR (to_jsonb(NEW)-ARRAY['request_mac','mac_key_id']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['request_mac','mac_key_id'])
  THEN RAISE EXCEPTION 'candidate_decision_immutable'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER immutable_candidate_decision BEFORE UPDATE OR DELETE ON personal_candidate_decisions
 FOR EACH ROW EXECUTE FUNCTION os_guard_publication_immutable();
CREATE TRIGGER immutable_knowledge_publication BEFORE UPDATE OR DELETE ON personal_knowledge_publications
 FOR EACH ROW EXECUTE FUNCTION os_guard_publication_immutable();
CREATE TRIGGER immutable_knowledge_supersession BEFORE UPDATE OR DELETE ON personal_knowledge_supersessions
 FOR EACH ROW EXECUTE FUNCTION os_guard_publication_immutable();

CREATE FUNCTION os_guard_publication_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE did uuid; p personal_knowledge_publications%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_candidate_decisions' THEN did=NEW.id;
 ELSIF TG_TABLE_NAME='personal_knowledge_publications' THEN did=NEW.decision_id;
 ELSE
  SELECT * INTO p FROM personal_knowledge_publications WHERE id=NEW.publication_id;did=p.decision_id;
  PERFORM os_assert_knowledge_supersession(NEW.entry_id,true);
 END IF;
 PERFORM os_assert_candidate_decision(did,TG_OP='INSERT');RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_candidate_decision AFTER INSERT OR UPDATE ON personal_candidate_decisions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_publication_commit();
CREATE CONSTRAINT TRIGGER commit_knowledge_publication AFTER INSERT ON personal_knowledge_publications
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_publication_commit();
CREATE CONSTRAINT TRIGGER commit_knowledge_supersession AFTER INSERT ON personal_knowledge_supersessions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_publication_commit();

CREATE OR REPLACE FUNCTION os_guard_learning_candidate() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_candidate_retained'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'PENDING_REVIEW' OR NEW.version<>1 OR NEW.created_at<>NEW.updated_at
   THEN RAISE EXCEPTION 'learning_candidate_initial'; END IF;
 ELSE
  IF OLD.state<>'PENDING_REVIEW' OR NEW.state NOT IN ('ACCEPTED','REJECTED','INVALIDATED')
   OR NEW.version NOT IN (OLD.version,OLD.version+1) OR (NEW.state<>'ACCEPTED' AND NEW.version<>OLD.version)
   OR (NEW.state='INVALIDATED' AND NOT os_learning_candidate_invalid(OLD.id))
   OR (to_jsonb(NEW)-ARRAY['state','version','updated_at']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['state','version','updated_at'])
   OR NEW.updated_at<OLD.updated_at THEN RAISE EXCEPTION 'learning_candidate_transition'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_guard_learning_candidate_revision() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE c personal_knowledge_candidates%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'learning_candidate_revision_retained'; END IF;
 IF TG_OP='INSERT' THEN
  SELECT * INTO c FROM personal_knowledge_candidates WHERE id=NEW.candidate_id;
  IF NEW.envelope IS NULL OR NOT (NEW.ordinal=1 OR c.state='PENDING_REVIEW' AND NEW.ordinal=c.version+1)
   THEN RAISE EXCEPTION 'learning_candidate_revision_initial'; END IF;
 ELSE
  IF OLD.envelope IS NULL OR NEW.envelope IS NOT NULL OR NOT os_candidate_erasure_allowed(OLD.candidate_id)
   OR (to_jsonb(NEW)-'envelope') IS DISTINCT FROM (to_jsonb(OLD)-'envelope')
   THEN RAISE EXCEPTION 'learning_candidate_revision_immutable'; END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION os_guard_learning_candidate_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid; c personal_knowledge_candidates%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 n bigint; d personal_candidate_decisions%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='personal_knowledge_candidates' THEN cid=NEW.id;ELSE cid=NEW.candidate_id;END IF;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=cid;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT count(*) INTO n FROM personal_knowledge_candidate_sources WHERE candidate_id=cid;
 IF c.id IS NULL OR j.state<>'SUCCEEDED' OR c.ordinal>j.result_count OR n NOT BETWEEN 1 AND 20
  OR NOT EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND ordinal=c.version)
  OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e WHERE e.candidate_id=cid AND NOT EXISTS(
   SELECT 1 FROM personal_learning_job_sources r WHERE r.job_id=j.id AND r.source_id=e.source_id AND r.source_revision=e.source_revision))
  THEN RAISE EXCEPTION 'learning_candidate_atomic_provenance'; END IF;
 IF c.state IN ('ACCEPTED','REJECTED') THEN
  SELECT * INTO d FROM personal_candidate_decisions WHERE candidate_id=c.id;
  IF d.id IS NULL THEN RAISE EXCEPTION 'candidate_decision_missing'; END IF;
  IF os_candidate_erasure_allowed(cid) AND EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL) THEN
   IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
    OR d.request_mac IS NOT NULL THEN RAISE EXCEPTION 'candidate_cleanup_incomplete'; END IF;
   PERFORM os_assert_candidate_decision(d.id,false);
  ELSE PERFORM os_assert_candidate_decision(d.id,true);END IF;
 ELSIF TG_OP='INSERT' THEN
  IF c.state<>'PENDING_REVIEW' OR c.version<>1 OR c.created_at<>j.updated_at
   OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NULL)
   THEN RAISE EXCEPTION 'learning_candidate_result_binding'; END IF;
  PERFORM os_assert_learning_job_live(j);
 ELSE
  IF c.state<>'INVALIDATED' OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_revisions WHERE candidate_id=cid AND envelope IS NOT NULL)
   THEN RAISE EXCEPTION 'learning_candidate_cleanup_incomplete'; END IF;
 END IF;
 RETURN NULL;
END $$;

CREATE FUNCTION os_guard_source_derivative_cleanup() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.completed_at IS NOT NULL THEN
  IF EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e JOIN personal_knowledge_candidate_revisions r ON r.candidate_id=e.candidate_id
   WHERE e.source_id=NEW.source_id AND r.envelope IS NOT NULL)
   OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e JOIN personal_candidate_decisions d ON d.candidate_id=e.candidate_id
    WHERE e.source_id=NEW.source_id AND d.request_mac IS NOT NULL)
   OR EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e JOIN personal_knowledge_publications p ON p.candidate_id=e.candidate_id
    JOIN personal_knowledge_revisions r ON r.id=p.revision_id WHERE e.source_id=NEW.source_id AND r.envelope IS NOT NULL)
   THEN RAISE EXCEPTION 'source_derivative_cleanup_incomplete'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_source_derivative_cleanup AFTER UPDATE ON personal_learning_source_forgets
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_guard_source_derivative_cleanup();
"""


def downgrade():
    raise RuntimeError("Owned populated data requires protected forward recovery")
