"""Audit current foreground approval independently of original execution authority.

Draft until protected populated runtime, negative guards and recovery pass.
The existing grant/current-root/ceiling/movement guards remain unchanged.
"""
from alembic import op

revision='os_pg_0075'
down_revision='os_pg_0074'
branch_labels=None
depends_on=None

APPROVER=r"""
ALTER TABLE os_agent_resource_grants ADD COLUMN authorizing_session_id uuid NULL;
ALTER TABLE os_agent_resource_grants ADD CONSTRAINT fk_os_interactive_sessions_authorizing_session_id
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,authorizing_session_id)
 REFERENCES os_interactive_sessions(installation_id,application_id,tenant_id,subject_id,id);
CREATE FUNCTION os_guard_agent_resource_approver() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s os_interactive_sessions%ROWTYPE; a os_applications%ROWTYPE; u os_subjects%ROWTYPE;
BEGIN
 IF NEW.authorizing_session_id IS NULL THEN RETURN NEW; END IF;
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_applications WHERE installation_id=NEW.installation_id AND id=NEW.application_id FOR SHARE;
 SELECT * INTO u FROM os_subjects WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
  AND tenant_id=NEW.tenant_id AND subject_id=NEW.subject_id FOR SHARE;
 SELECT * INTO s FROM os_interactive_sessions WHERE id=NEW.authorizing_session_id FOR SHARE;
 IF NOT COALESCE(s.installation_id=NEW.installation_id AND s.application_id=NEW.application_id
  AND s.tenant_id=NEW.tenant_id AND s.subject_id=NEW.subject_id
  AND NOT s.revoked AND s.expires_at>clock_timestamp() AND a.active AND u.active
  AND s.application_generation=a.generation AND s.subject_generation=u.generation,false)
 THEN RAISE EXCEPTION 'agent_resource_approver_not_current'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_agent_resource_approver BEFORE INSERT ON os_agent_resource_grants
 FOR EACH ROW EXECUTE FUNCTION os_guard_agent_resource_approver();
"""

def upgrade():op.execute(APPROVER)

def downgrade():raise RuntimeError('Use the protected recovery procedure')
