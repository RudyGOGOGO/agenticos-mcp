"""Draft: exact OIDC authentication origins for repair and activation.

The original review, finite inverse and proactive delegation remain their
authorities. One encrypted flow authenticates one immutable domain command.
Qualification must precede freezing this additive revision.
"""
from alembic import op

revision='os_pg_0095'
down_revision='os_pg_0094'
branch_labels=None
depends_on=None

TABLES=r"""
ALTER TABLE os_oidc_assurance_flows ALTER COLUMN challenge_id DROP NOT NULL;
ALTER TABLE os_oidc_assurance_flows ADD COLUMN repair_challenge_id uuid;
ALTER TABLE os_oidc_assurance_flows ADD COLUMN activation_revision_id uuid;
ALTER TABLE os_oidc_assurance_flows ADD COLUMN activation_command_id uuid;
ALTER TABLE os_oidc_assurance_flows ADD CONSTRAINT fk_os_repair_challenges_repair_challenge_id
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,repair_challenge_id)
 REFERENCES os_repair_challenges(installation_id,application_id,tenant_id,subject_id,id);
ALTER TABLE os_oidc_assurance_flows ADD CONSTRAINT fk_os_proactive_revisions_activation_revision_id
 FOREIGN KEY(installation_id,application_id,tenant_id,subject_id,activation_revision_id)
 REFERENCES os_proactive_revisions(installation_id,application_id,tenant_id,subject_id,id);
ALTER TABLE os_oidc_assurance_flows ADD CONSTRAINT uq_oidc_flow_repair_challenge
 UNIQUE(installation_id,application_id,tenant_id,subject_id,repair_challenge_id);
ALTER TABLE os_oidc_assurance_flows ADD CONSTRAINT uq_oidc_flow_activation_command
 UNIQUE(installation_id,application_id,tenant_id,subject_id,activation_command_id);
ALTER TABLE os_oidc_assurance_flows ADD CONSTRAINT ck_oidc_flow_command_origin CHECK(
 num_nonnulls(challenge_id,repair_challenge_id,activation_revision_id)=1
 AND ((activation_revision_id IS NOT NULL)=(activation_command_id IS NOT NULL)));
"""

REPAIR_SHAPES=r"""
ALTER TABLE os_repair_challenges DROP CONSTRAINT ck_repair_challenge_closed;
ALTER TABLE os_repair_challenges ADD CONSTRAINT ck_repair_challenge_closed CHECK (COALESCE((jsonb_typeof((binding))='object' AND (binding) ?& ARRAY['subject','sessionId','sessionGeneration','hostSessionRef','policyGeneration','challengeId','nonce','proposalId','proposalRevision','proposalDigest','assuranceProfile','assuranceProviderRef','requiredAssurance','createdAt','expiresAt'] AND ((binding) - ARRAY['subject','sessionId','sessionGeneration','hostSessionRef','policyGeneration','challengeId','nonce','proposalId','proposalRevision','proposalDigest','assuranceProfile','assuranceProviderRef','requiredAssurance','createdAt','expiresAt'])='{}'::jsonb AND binding->>'requiredAssurance'='local-synthetic') OR (jsonb_typeof((binding))='object' AND (binding) ?& ARRAY['subject','sessionId','sessionGeneration','hostSessionRef','policyGeneration','challengeId','nonce','proposalId','proposalRevision','proposalDigest','assuranceProfile','assuranceProviderRef','requiredAssurance','createdAt','expiresAt','provider','ownerMapping'] AND ((binding) - ARRAY['subject','sessionId','sessionGeneration','hostSessionRef','policyGeneration','challengeId','nonce','proposalId','proposalRevision','proposalDigest','assuranceProfile','assuranceProviderRef','requiredAssurance','createdAt','expiresAt','provider','ownerMapping'])='{}'::jsonb AND binding->>'requiredAssurance'='oidc-step-up/1'),false));
ALTER TABLE os_repair_approvals DROP CONSTRAINT ck_repair_attestation_closed;
ALTER TABLE os_repair_approvals ADD CONSTRAINT ck_repair_attestation_closed CHECK (COALESCE((jsonb_typeof((attestation))='object' AND (attestation) ?& ARRAY['subject','sessionId','challengeId','bindingDigest','assertionRef','commandId','commandDigest','decision','assuranceRef','observedAt','expiresAt'] AND ((attestation) - ARRAY['subject','sessionId','challengeId','bindingDigest','assertionRef','commandId','commandDigest','decision','assuranceRef','observedAt','expiresAt'])='{}'::jsonb AND attestation->>'assuranceRef'='local-synthetic') OR (jsonb_typeof((attestation))='object' AND (attestation) ?& ARRAY['subject','sessionId','challengeId','bindingDigest','assertionRef','commandId','commandDigest','decision','assuranceRef','observedAt','expiresAt','provider','ownerMapping','flowId','authentication'] AND ((attestation) - ARRAY['subject','sessionId','challengeId','bindingDigest','assertionRef','commandId','commandDigest','decision','assuranceRef','observedAt','expiresAt','provider','ownerMapping','flowId','authentication'])='{}'::jsonb AND attestation->>'assuranceRef'='oidc-step-up/1'),false));
"""

COMMANDS=r"""
CREATE FUNCTION os_oidc_assert_identity(s os_interactive_sessions,b jsonb,target_run text,deadline timestamptz)
 RETURNS void LANGUAGE plpgsql AS $$
DECLARE p os_oidc_assurance_profiles%ROWTYPE; m os_oidc_subject_mappings%ROWTYPE; a os_applications%ROWTYPE;
 registration os_registrations%ROWTYPE; e os_embed_registrations%ROWTYPE; u os_subjects%ROWTYPE; client_profile jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM os_proactive_session(s.installation_id,s.application_id,s.tenant_id,s.subject_id,s.id);
 SELECT * INTO a FROM os_applications WHERE installation_id=s.installation_id AND id=s.application_id;
 SELECT * INTO registration FROM os_registrations WHERE installation_id=s.installation_id AND application_id=s.application_id AND revision=a.revision;
 SELECT * INTO e FROM os_embed_registrations WHERE installation_id=s.installation_id AND application_id=s.application_id AND id=s.embed_ref;
 SELECT * INTO u FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 SELECT x INTO client_profile FROM jsonb_array_elements(registration.payload->'clientProfiles') x WHERE x->>'id'=e.payload->>'clientProfile';
 SELECT * INTO p FROM os_oidc_assurance_profiles WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND profile_ref=b->'provider'->>'ref' ORDER BY revision DESC LIMIT 1;
 SELECT * INTO m FROM os_oidc_subject_mappings WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id AND provider_ref=p.profile_ref ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(s.id IS NOT NULL AND deadline>clock_timestamp()
  AND (b->>'createdAt')::timestamptz<=clock_timestamp()+interval '1 second'
  AND (b->>'expiresAt')::timestamptz>clock_timestamp()
  AND (b->>'expiresAt')::timestamptz>(b->>'createdAt')::timestamptz
  AND (b->>'expiresAt')::timestamptz<=(b->>'createdAt')::timestamptz+interval '60 seconds'
  AND (b->>'expiresAt')::timestamptz<=deadline AND (b->>'expiresAt')::timestamptz<=s.expires_at
  AND b=jsonb_build_object('subject',b->'subject','sessionId',s.id,'sessionGeneration',s.session_generation,
   'hostSessionRef',s.host_session_ref,'policyGeneration',u.host_policy_generation,'challengeId',b->'challengeId',
   'nonce',b->'nonce','proposalId',b->'proposalId','proposalRevision',b->'proposalRevision','proposalDigest',b->'proposalDigest',
   'assuranceProfile','oidc-step-up-assurance/1','assuranceProviderRef',b->'assuranceProviderRef','requiredAssurance','oidc-step-up/1',
   'provider',b->'provider','ownerMapping',b->'ownerMapping','createdAt',b->'createdAt','expiresAt',b->'expiresAt')
  AND b->>'nonce' ~ '^[A-Za-z0-9_-]{43,128}$'
  AND b->>'assuranceProfile'='oidc-step-up-assurance/1' AND b->>'requiredAssurance'='oidc-step-up/1'
  AND b->>'assuranceProviderRef'=p.profile_ref AND b->'provider'=jsonb_build_object('ref',p.profile_ref,'revision',p.revision,'digest',p.digest)
  AND b->'ownerMapping'=jsonb_build_object('ref',m.id,'revision',m.revision,'digest',m.digest)
  AND p.run_id=target_run AND m.run_id=target_run AND p.payload->'active'='true'::jsonb AND m.payload->'active'='true'::jsonb
  AND p.digest=os_agent_profile_digest('manifest',p.payload) AND m.digest=os_agent_profile_digest('manifest',m.payload)
  AND m.payload->>'issuer'=p.payload->'client'->>'issuer' AND client_profile=p.payload->'clientProfile'
  AND registration.digest=os_agent_profile_digest('manifest',registration.payload) AND registration.generation=a.generation
  AND e.application_generation=a.generation AND e.payload->'active'='true'::jsonb
  AND b->'subject'=jsonb_build_object('installationId',s.installation_id,'applicationId',s.application_id,'tenantId',s.tenant_id,'subjectId',s.subject_id)
  AND b->>'sessionId'=s.id::text AND (b->>'sessionGeneration')::bigint=s.session_generation
  AND b->>'hostSessionRef'=s.host_session_ref AND (b->>'policyGeneration')::bigint=u.host_policy_generation,false)
 THEN RAISE EXCEPTION 'oidc_current_command_identity';END IF;
END $$;

CREATE FUNCTION os_repair_required_assurance(d os_repair_admissions) RETURNS text LANGUAGE plpgsql AS $$
DECLARE g jsonb;
BEGIN
 IF d.id IS NULL THEN RAISE EXCEPTION 'repair_original_assurance_missing';END IF;
 IF d.original_kind<>'agent-reviewed' THEN RETURN 'local-synthetic';END IF;
 SELECT os_agent_reviewed_grant(w.invocation_id) INTO g FROM os_work_attempts w WHERE w.id=d.production_binding_id
  AND w.task_id=d.parent_task_id AND w.root_id=d.root_id AND w.kind='agent.effect' AND w.state='SETTLED' AND w.actual IS NOT NULL;
 IF g->>'reviewId' IS DISTINCT FROM d.production_review_id::text
  OR g->'decision'->>'assuranceRef' IS NULL OR g->'decision'->>'assuranceRef' NOT IN ('local-synthetic','oidc-step-up/1')
 THEN RAISE EXCEPTION 'repair_original_assurance_missing';END IF;
 RETURN g->'decision'->>'assuranceRef';
END $$;

CREATE FUNCTION os_oidc_assert_repair_challenge(q os_repair_challenges,target_run text,phase text DEFAULT 'review')
 RETURNS void LANGUAGE plpgsql AS $$
DECLARE d os_repair_admissions%ROWTYPE; p os_repair_prepared%ROWTYPE; s os_interactive_sessions%ROWTYPE; t os_tasks%ROWTYPE; b jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 b:=q.binding;
 SELECT * INTO d FROM os_repair_admissions WHERE id=q.admission_id;
 SELECT * INTO p FROM os_repair_prepared WHERE id=q.prepared_id;
 SELECT * INTO s FROM os_interactive_sessions WHERE id=q.session_id;
 SELECT * INTO t FROM os_tasks WHERE id=d.task_id;
 PERFORM os_assert_repair_current(d,d.authority);
 PERFORM os_oidc_assert_identity(s,b,target_run,LEAST(d.expires_at,p.expires_at));
 IF NOT COALESCE(q.id IS NOT NULL AND os_repair_required_assurance(d)='oidc-step-up/1'
  AND ROW(q.installation_id,q.application_id,q.tenant_id,q.subject_id)=ROW(d.installation_id,d.application_id,d.tenant_id,d.subject_id)
  AND ROW(s.installation_id,s.application_id,s.tenant_id,s.subject_id)=ROW(d.installation_id,d.application_id,d.tenant_id,d.subject_id)
  AND q.session_id=d.session_id AND p.admission_id=d.id AND p.expires_at>clock_timestamp()
  AND b->>'challengeId'=q.id::text AND b->>'proposalId'=p.proposal_id::text AND b->>'proposalDigest'=p.proposal_digest
  AND b->>'proposalRevision'='1' AND q.binding_digest=os_agent_profile_digest('verification',b)
  AND (b->>'createdAt')::timestamptz=q.created_at AND (b->>'expiresAt')::timestamptz=q.expires_at
  AND ((phase='review' AND t.state='WAITING_APPROVAL')
   OR (phase='approval' AND t.state IN ('VALIDATING','FAILED') AND EXISTS(SELECT 1 FROM os_oidc_assurance_flows f
    WHERE f.repair_challenge_id=q.id AND f.state='CONSUMED' AND f.claim->'binding'=b))
   OR (phase IN ('review','effect','approval') AND t.state IN ('VALIDATING','RUNNING')
   AND EXISTS(SELECT 1 FROM os_repair_approvals approval JOIN os_repair_grants grantrow ON grantrow.approval_id=approval.id
    JOIN os_oidc_assurance_flows f ON f.repair_challenge_id=q.id
    WHERE approval.challenge_id=q.id AND approval.admission_id=d.id AND approval.decision='approve'
     AND f.state='CONSUMED' AND f.claim=approval.claim AND f.authentication=approval.attestation->'authentication'
     AND NOT EXISTS(SELECT 1 FROM os_repair_revocations revoked WHERE revoked.approval_id=approval.id)))),false)
 THEN RAISE EXCEPTION 'oidc_current_repair_command';END IF;
END $$;

CREATE FUNCTION os_oidc_assert_activation_record(v jsonb,revision_id uuid,target_run text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_proactive_revisions%ROWTYPE; d os_proactive_definitions%ROWTYPE; s os_interactive_sessions%ROWTYPE; b jsonb; c jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 b:=v->'binding';c:=v->'command';
 SELECT * INTO r FROM os_proactive_revisions WHERE id=revision_id;
 SELECT * INTO d FROM os_proactive_definitions WHERE id=r.definition_id;
 SELECT * INTO s FROM os_interactive_sessions WHERE id=(b->>'sessionId')::uuid;
 PERFORM os_oidc_assert_identity(s,b,target_run,(r.configuration->>'validUntil')::timestamptz);
 PERFORM os_assert_agent_proactive_link(r,'activate');
 IF NOT COALESCE(r.id IS NOT NULL AND d.state='awaiting-review' AND d.version=(c->>'expectedRevision')::bigint
  AND d.configuration_revision=r.revision AND v->>'definitionId'=d.id::text
  AND ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)=ROW(s.installation_id,s.application_id,s.tenant_id,s.subject_id)
  AND d.registration_revision=r.registration_revision AND d.application_generation=s.application_generation
  AND d.subject_generation=s.subject_generation AND d.policy_generation=(b->>'policyGeneration')::bigint
  AND r.configuration_digest=os_agent_profile_digest('definition',r.configuration)
  AND c=jsonb_build_object('commandId',c->'commandId','expectedRevision',d.version,'configurationDigest',r.configuration_digest,'decision',c->'decision')
  AND c->>'commandId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$' AND c->>'decision' IN ('activate','reject')
  AND v->>'decision'=CASE WHEN c->>'decision'='activate' THEN 'approve' ELSE 'reject' END
  AND b->>'challengeId'=v->>'id' AND b->>'proposalId'=r.id::text AND b->>'proposalDigest'=r.configuration_digest
  AND (b->>'proposalRevision')::bigint=r.revision
  AND (r.agent_operation_id IS NULL OR EXISTS(SELECT 1 FROM os_agent_tool_operations operation
   JOIN os_budget_roots root ON root.id=operation.root_id WHERE operation.id=r.agent_operation_id
    AND (b->>'expiresAt')::timestamptz<=root.deadline))
  AND NOT EXISTS(SELECT 1 FROM os_proactive_commands done WHERE done.installation_id=r.installation_id AND done.application_id=r.application_id
   AND done.tenant_id=r.tenant_id AND done.subject_id=r.subject_id AND done.command_id=(c->>'commandId')::uuid)
  AND (SELECT count(*) FROM os_oidc_assurance_flows f WHERE f.activation_revision_id=r.id AND f.id::text<>v->>'id')<8,false)
 THEN RAISE EXCEPTION 'oidc_current_activation_command';END IF;
END $$;

CREATE FUNCTION os_oidc_challenge_material(i uuid,a uuid,challenge uuid,target_run text) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE material jsonb; matches bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT count(*),min(item::text)::jsonb INTO matches,material FROM (
  SELECT jsonb_build_object('kind','review','binding',h.binding,'flowId',f.id) item FROM os_agent_review_challenges h
   LEFT JOIN os_oidc_assurance_flows f ON f.challenge_id=h.id WHERE h.id=challenge AND h.installation_id=i AND h.application_id=a
  UNION ALL
  SELECT jsonb_build_object('kind','repair','binding',q.binding,'flowId',f.id) FROM os_repair_challenges q
   LEFT JOIN os_oidc_assurance_flows f ON f.repair_challenge_id=q.id WHERE q.id=challenge AND q.installation_id=i AND q.application_id=a
  UNION ALL
  SELECT jsonb_build_object('kind','activation','binding',f.payload->'binding','flowId',f.id) FROM os_oidc_assurance_flows f
   WHERE f.id=challenge AND f.installation_id=i AND f.application_id=a AND f.activation_revision_id IS NOT NULL
 ) known;
 IF matches<>1 OR material->'binding'->>'requiredAssurance' IS DISTINCT FROM 'oidc-step-up/1'
 THEN RAISE EXCEPTION 'oidc_command_origin_missing';END IF;
 RETURN material;
END $$;

CREATE FUNCTION os_oidc_assert_owner_command(b jsonb,target_run text,phase text DEFAULT 'review') RETURNS void LANGUAGE plpgsql AS $$
DECLARE known jsonb; q os_repair_challenges%ROWTYPE; f os_oidc_assurance_flows%ROWTYPE;
BEGIN
 known:=os_oidc_challenge_material((b->'subject'->>'installationId')::uuid,(b->'subject'->>'applicationId')::uuid,(b->>'challengeId')::uuid,target_run);
 IF known->'binding' IS DISTINCT FROM b OR phase NOT IN ('review','effect') THEN RAISE EXCEPTION 'oidc_command_binding';END IF;
 IF known->>'kind'='review' THEN PERFORM os_oidc_assert_current(b,target_run,phase);
 ELSIF known->>'kind'='repair' THEN
  SELECT * INTO q FROM os_repair_challenges WHERE id=(b->>'challengeId')::uuid;
  PERFORM os_oidc_assert_repair_challenge(q,target_run,phase);
 ELSE
  SELECT * INTO f FROM os_oidc_assurance_flows WHERE id=(known->>'flowId')::uuid;
  IF phase<>'review' OR f.run_id IS DISTINCT FROM target_run THEN RAISE EXCEPTION 'oidc_activation_phase';END IF;
  PERFORM os_oidc_assert_activation_record(f.payload,f.activation_revision_id,target_run);
 END IF;
END $$;

CREATE FUNCTION os_oidc_assert_repair_approval(approval os_repair_approvals,q os_repair_challenges) RETURNS void LANGUAGE plpgsql AS $$
DECLARE f os_oidc_assurance_flows%ROWTYPE; a jsonb;
BEGIN
 SELECT * INTO f FROM os_oidc_assurance_flows WHERE repair_challenge_id=q.id;
 a:=approval.attestation;
 IF NOT COALESCE(f.id IS NOT NULL AND f.state='CONSUMED' AND f.claim=approval.claim
  AND f.payload->'binding'=q.binding AND f.authentication=a->'authentication'
  AND a->>'flowId'=f.id::text AND a->>'assuranceRef'='oidc-step-up/1'
  AND a->'provider'=q.binding->'provider' AND a->'ownerMapping'=q.binding->'ownerMapping'
  AND approval.claim->>'assertionRef'='assertion/'||f.assertion_id::text
  AND approval.decision_ref->>'assuranceRef'='oidc-step-up/1',false)
 THEN RAISE EXCEPTION 'oidc_repair_exact_approval';END IF;
 PERFORM os_oidc_assert_repair_challenge(q,f.run_id,'approval');
END $$;
"""

OWNER=r"""
CREATE OR REPLACE FUNCTION os_oidc_assert_owner(v os_agent_reviews,s os_interactive_sessions,b jsonb,target_run text,phase text DEFAULT 'review')
 RETURNS void LANGUAGE plpgsql AS $$
DECLARE p os_oidc_assurance_profiles%ROWTYPE; m os_oidc_subject_mappings%ROWTYPE; a os_applications%ROWTYPE;
 registration os_registrations%ROWTYPE; e os_embed_registrations%ROWTYPE; u os_subjects%ROWTYPE; client_profile jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO a FROM os_applications WHERE installation_id=v.installation_id AND id=v.application_id;
 SELECT * INTO registration FROM os_registrations WHERE installation_id=v.installation_id AND application_id=v.application_id AND revision=a.revision;
 SELECT * INTO e FROM os_embed_registrations WHERE installation_id=v.installation_id AND application_id=v.application_id AND id=s.embed_ref;
 SELECT * INTO u FROM os_subjects WHERE installation_id=v.installation_id AND application_id=v.application_id AND tenant_id=v.tenant_id AND subject_id=v.subject_id;
 SELECT x INTO client_profile FROM jsonb_array_elements(registration.payload->'clientProfiles') x WHERE x->>'id'=e.payload->>'clientProfile';
 SELECT * INTO p FROM os_oidc_assurance_profiles WHERE installation_id=v.installation_id AND application_id=v.application_id
  AND profile_ref=b->'provider'->>'ref' ORDER BY revision DESC LIMIT 1;
 SELECT * INTO m FROM os_oidc_subject_mappings WHERE installation_id=v.installation_id AND application_id=v.application_id
  AND tenant_id=v.tenant_id AND subject_id=v.subject_id AND provider_ref=p.profile_ref ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE((v.payload->'context'->'harness'->>'ref'='agent-sdk-reviewed-change/1'
  OR (v.payload->'context'->'harness'->>'ref'='agent-sdk-serialized-reviewed-change/1'
   AND EXISTS(SELECT 1 FROM os_agent_write_conflict_roots selected
    JOIN os_agent_write_conflict_policies policy ON policy.installation_id=selected.installation_id
     AND policy.application_id=selected.application_id AND policy.policy_digest=selected.policy_digest
    JOIN os_budget_roots root ON root.id=selected.root_id
    JOIN os_admissions admission ON admission.id=root.admission_id
    WHERE selected.root_id=v.root_id AND selected.installation_id=v.installation_id AND selected.application_id=v.application_id
     AND selected.tenant_id=v.tenant_id AND selected.subject_id=v.subject_id
     AND root.root_task_id=v.task_id AND admission.context=v.payload->'context'
     AND policy.payload->'harness'=admission.context->'harness'
     AND policy.registration_revision=admission.registration_revision
     AND policy.digest=os_agent_profile_digest('policy',policy.payload)))
  OR (v.payload->'context'->'harness'->>'ref'='agent-sdk-repairable-change/1'
   AND EXISTS(SELECT 1 FROM os_agent_repair_roots selected
    JOIN os_budget_roots root ON root.id=selected.root_id
    JOIN os_admissions admission ON admission.id=selected.admission_id
    WHERE selected.root_id=v.root_id AND selected.admission_id=root.admission_id
     AND ROW(selected.installation_id,selected.application_id,selected.tenant_id,selected.subject_id)=
      ROW(v.installation_id,v.application_id,v.tenant_id,v.subject_id)
     AND root.root_task_id=v.task_id AND admission.context=v.payload->'context'
     AND selected.id=os_query_source_uuid5(root.id,'agent-original-root-repair/1')
     AND selected.policy=jsonb_build_object('profileRef','agent-original-root-repair/1','context',admission.context,
      'maxRepairs',1,'inverseProfile','typed-update-restore/1')
     AND selected.digest=os_agent_profile_digest('policy',selected.policy))))
  AND (b->>'expiresAt')::timestamptz>clock_timestamp()
  AND (b->>'expiresAt')::timestamptz<=v.expires_at AND (b->>'expiresAt')::timestamptz<=s.expires_at
  AND b->>'assuranceProfile'='oidc-step-up-assurance/1' AND b->>'requiredAssurance'='oidc-step-up/1'
  AND b->>'assuranceProviderRef'=p.profile_ref AND b->'provider'=jsonb_build_object('ref',p.profile_ref,'revision',p.revision,'digest',p.digest)
  AND b->'ownerMapping'=jsonb_build_object('ref',m.id,'revision',m.revision,'digest',m.digest)
  AND p.run_id=target_run AND m.run_id=target_run AND p.payload->'active'='true'::jsonb AND m.payload->'active'='true'::jsonb
  AND p.digest=os_agent_profile_digest('manifest',p.payload) AND m.digest=os_agent_profile_digest('manifest',m.payload)
  AND m.payload->>'issuer'=p.payload->'client'->>'issuer' AND client_profile=p.payload->'clientProfile'
  AND registration.digest=os_agent_profile_digest('manifest',registration.payload) AND registration.generation=a.generation
  AND e.application_generation=a.generation AND e.payload->'active'='true'::jsonb
  AND b->'subject'=jsonb_build_object('installationId',v.installation_id,'applicationId',v.application_id,'tenantId',v.tenant_id,'subjectId',v.subject_id)
  AND b->>'sessionId'=s.id::text AND (b->>'sessionGeneration')::bigint=s.session_generation
  AND b->>'hostSessionRef'=s.host_session_ref AND (b->>'policyGeneration')::bigint=u.host_policy_generation
  AND EXISTS(SELECT 1 FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=v.task_id
   AND ((phase='review' AND t.state='WAITING_APPROVAL') OR (phase='effect' AND t.state='RUNNING'))
   AND r.state='ACTIVE' AND r.deadline>clock_timestamp() AND (b->>'expiresAt')::timestamptz<=r.deadline),false)
 THEN RAISE EXCEPTION 'oidc_current_owner_binding'; END IF;
END $$;
"""

FLOW_GUARD=r"""CREATE OR REPLACE FUNCTION os_guard_oidc_assurance_flow() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE p os_oidc_assurance_profiles%ROWTYPE;
 material jsonb; expected_record jsonb;
 m os_oidc_subject_mappings%ROWTYPE; v jsonb; b jsonb; fact jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'oidc_flow_immutable'; END IF;
 v:=NEW.payload;b:=v->'binding';
 IF TG_OP='INSERT' THEN
  IF NEW.activation_revision_id IS NOT NULL THEN
   IF NEW.id::text IS DISTINCT FROM b->>'challengeId' OR NEW.activation_command_id::text IS DISTINCT FROM v->'command'->>'commandId'
    THEN RAISE EXCEPTION 'oidc_activation_origin';END IF;
   PERFORM os_oidc_assert_activation_record(v,NEW.activation_revision_id,NEW.run_id);
   expected_record:=jsonb_build_object('definitionId',v->'definitionId','command',v->'command');
  ELSE
   material:=os_oidc_challenge_material(NEW.installation_id,NEW.application_id,(b->>'challengeId')::uuid,NEW.run_id);
   IF material->'binding' IS DISTINCT FROM b OR NOT COALESCE(
    (material->>'kind'='review' AND NEW.challenge_id::text=b->>'challengeId' AND NEW.repair_challenge_id IS NULL)
    OR (material->>'kind'='repair' AND NEW.repair_challenge_id::text=b->>'challengeId' AND NEW.challenge_id IS NULL),false)
    THEN RAISE EXCEPTION 'oidc_domain_origin';END IF;
   PERFORM os_oidc_assert_owner_command(b,NEW.run_id);
   expected_record:='{}'::jsonb;
  END IF;
  IF NOT COALESCE(NEW.version=1 AND NEW.state='CREATED' AND NEW.created_at BETWEEN clock_timestamp()-interval '2 seconds' AND clock_timestamp()
   AND b->'subject'=jsonb_build_object('installationId',NEW.installation_id,'applicationId',NEW.application_id,'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id)
   AND NEW.digest=os_agent_profile_digest('command',v)
   AND v=expected_record||jsonb_build_object('id',NEW.id,'binding',b,'decision',v->'decision','stateDigest',NEW.state_digest,
    'nonceDigest',v->'nonceDigest','createdAt',v->'createdAt','expiresAt',v->'expiresAt')
   AND v->>'decision' IN ('approve','reject') AND v->>'nonceDigest' ~ '^[a-f0-9]{64}$'
   AND (v->>'createdAt')::timestamptz=NEW.created_at AND (v->>'expiresAt')::timestamptz=NEW.expires_at AND NEW.expires_at<=(b->>'expiresAt')::timestamptz
   AND b->'provider'=jsonb_build_object('ref',NEW.provider_ref,'revision',NEW.provider_revision,'digest',NEW.provider_digest)
   AND b->'ownerMapping'=jsonb_build_object('ref',NEW.mapping_id,'revision',NEW.mapping_revision,'digest',NEW.mapping_digest)
   AND NEW.authentication IS NULL AND NEW.assertion_id IS NULL AND NEW.claim IS NULL AND NEW.failure_code IS NULL,false)
  THEN RAISE EXCEPTION 'oidc_flow_initial_binding'; END IF;
 ELSE
  IF NOT COALESCE(ROW(NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.challenge_id,NEW.repair_challenge_id,NEW.activation_revision_id,NEW.activation_command_id,
   NEW.provider_ref,NEW.provider_revision,NEW.provider_digest,NEW.mapping_id,NEW.mapping_revision,NEW.mapping_digest,
   NEW.run_id,NEW.state_digest,NEW.payload,NEW.digest,NEW.created_at,NEW.expires_at)
   IS NOT DISTINCT FROM ROW(OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.challenge_id,OLD.repair_challenge_id,OLD.activation_revision_id,OLD.activation_command_id,
   OLD.provider_ref,OLD.provider_revision,OLD.provider_digest,OLD.mapping_id,OLD.mapping_revision,OLD.mapping_digest,
   OLD.run_id,OLD.state_digest,OLD.payload,OLD.digest,OLD.created_at,OLD.expires_at)
   AND NEW.version=OLD.version+1 AND (
    (OLD.state='CREATED' AND NEW.state='EXCHANGING' AND NEW.secret_envelope=OLD.secret_envelope)
    OR (OLD.state='EXCHANGING' AND NEW.state='AUTHENTICATED')
    OR (OLD.state='AUTHENTICATED' AND NEW.state='CONSUMED' AND NEW.authentication=OLD.authentication AND NEW.assertion_id=OLD.assertion_id)
    OR (OLD.state IN ('CREATED','EXCHANGING','AUTHENTICATED') AND NEW.state='FAILED')
    OR (OLD.state='EXCHANGING' AND NEW.state='UNKNOWN')),false)
  THEN RAISE EXCEPTION 'oidc_flow_transition'; END IF;
  IF NEW.state NOT IN ('FAILED','UNKNOWN') THEN PERFORM os_oidc_assert_owner_command(b,NEW.run_id); END IF;
 END IF;
 IF NEW.state IN ('CREATED','EXCHANGING') THEN
  IF NEW.expires_at<=clock_timestamp() THEN RAISE EXCEPTION 'oidc_flow_expired'; END IF;
  IF NOT COALESCE(NEW.secret_envelope=jsonb_build_object('version',1,'keyId',NEW.secret_envelope->'keyId',
   'nonce',NEW.secret_envelope->'nonce','ciphertext',NEW.secret_envelope->'ciphertext')
   AND NEW.secret_envelope->>'keyId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   AND NEW.secret_envelope->>'nonce' ~ '^[A-Za-z0-9+/]{16}$'
   AND NEW.secret_envelope->>'ciphertext' ~ '^[A-Za-z0-9+/]+={0,2}$',false)
  THEN RAISE EXCEPTION 'oidc_flow_encrypted_secret'; END IF;
 END IF;
 IF NEW.state IN ('AUTHENTICATED','CONSUMED') THEN
  SELECT * INTO p FROM os_oidc_assurance_profiles WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id
   AND profile_ref=NEW.provider_ref AND revision=NEW.provider_revision;
  SELECT * INTO m FROM os_oidc_subject_mappings WHERE id=NEW.mapping_id;
  fact:=NEW.authentication;
  IF NOT COALESCE(fact=jsonb_build_object('issuer',p.payload->'client'->'issuer','subject',m.payload->'oidcSubject',
   'authenticatedAt',fact->'authenticatedAt','acr',p.payload->'client'->'required_acr','amr',fact->'amr','expiresAt',fact->'expiresAt')
   AND (fact->>'authenticatedAt')::timestamptz BETWEEN NEW.created_at-interval '1 second' AND clock_timestamp()+interval '1 second'
   AND (fact->>'expiresAt')::timestamptz>clock_timestamp() AND (fact->>'expiresAt')::timestamptz<=NEW.expires_at
   AND jsonb_typeof(fact->'amr')='array' AND jsonb_array_length(fact->'amr') BETWEEN 1 AND 16
   AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(fact->'amr') method WHERE jsonb_typeof(method)<>'string')
   AND (p.payload->'client'->'required_amr') <@ (fact->'amr'),false)
  THEN RAISE EXCEPTION 'oidc_flow_fresh_identity'; END IF;
 END IF;
 IF NEW.state='CONSUMED' THEN
  IF NOT COALESCE(NEW.claim=jsonb_build_object('binding',b,'assertionRef','assertion/'||NEW.assertion_id::text,
   'commandId',NEW.claim->'commandId','commandDigest',NEW.claim->'commandDigest','decision',v->'decision')
   AND NEW.claim->>'commandId' ~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   AND NEW.claim->>'commandDigest' ~ '^[a-f0-9]{64}$',false)
  THEN RAISE EXCEPTION 'oidc_flow_exact_command'; END IF;
  IF NEW.activation_revision_id IS NOT NULL AND NOT COALESCE(
   NEW.claim->>'commandId'=v->'command'->>'commandId'
   AND NEW.claim->>'commandDigest'=os_agent_profile_digest('command',(v->'command')||
    jsonb_build_object('challengeId',NEW.id,'assertionRef','assertion/'||NEW.assertion_id::text)),false)
  THEN RAISE EXCEPTION 'oidc_activation_exact_command';END IF;
 END IF;
 RETURN NEW;
END $$;
"""

REPAIR_GUARDS=r"""CREATE OR REPLACE FUNCTION public.os_assert_repair_grant(g os_repair_grants)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE d os_repair_admissions%ROWTYPE; p os_repair_prepared%ROWTYPE;
 approval os_repair_approvals%ROWTYPE; q os_repair_challenges%ROWTYPE; reg os_repair_registrations%ROWTYPE;
 now_at timestamptz;
BEGIN
 SELECT * INTO d FROM os_repair_admissions WHERE id=g.admission_id;
 PERFORM os_assert_repair_current(d,g.payload->'authority');
 SELECT * INTO approval FROM os_repair_approvals WHERE id=g.approval_id;
 SELECT * INTO p FROM os_repair_prepared WHERE id=approval.prepared_id;
 SELECT * INTO q FROM os_repair_challenges WHERE id=approval.challenge_id;
 SELECT * INTO reg FROM os_repair_registrations WHERE challenge_id=q.id;
 now_at=clock_timestamp();
 IF COALESCE((approval.decision='approve' AND approval.admission_id=d.id AND p.admission_id=d.id
  AND q.admission_id=d.id AND q.prepared_id=p.id AND approval.claim->'binding'=q.binding
  AND approval.claim->>'decision'='approve' AND approval.attestation->>'decision'='approve'
  AND approval.attestation->>'bindingDigest'=q.binding_digest
  AND reg.binding_digest=q.binding_digest AND reg.registration->>'bindingDigest'=q.binding_digest
  AND reg.registration->>'challengeId'=q.id::text AND reg.registration->>'expiresAt'=q.binding->>'expiresAt'
  AND q.binding->>'proposalId'=p.proposal_id::text AND q.binding->>'proposalDigest'=p.proposal_digest
  AND q.binding->>'proposalRevision'='1' AND q.binding->>'challengeId'=q.id::text
  AND q.session_id=(g.payload->'authority'->>'sessionId')::uuid
  AND g.payload->>'id'=g.id::text AND g.payload->>'repairId'=d.id::text
  AND g.payload->>'taskId'=d.task_id::text AND g.payload->>'parentTaskId'=d.parent_task_id::text
  AND g.payload->>'rootId'=d.root_id::text AND g.payload->>'segmentId'=approval.successor_segment_id::text
  AND g.payload->>'preparedId'=p.id::text AND g.payload->>'approvalId'=approval.id::text
  AND g.payload->>'grantDigest'=g.grant_digest AND g.payload->>'profileRef'=(CASE WHEN os_repair_required_assurance(d)='oidc-step-up/1' THEN 'agent-oidc-update-repair-execution/1' WHEN d.original_kind='agent-reviewed' THEN 'agent-typed-update-repair-execution/1' ELSE 'typed-update-repair-execution/1' END)
  AND g.payload->'subject'=g.payload->'authority'->'subject'
  AND (d.original_kind<>'agent-reviewed' OR g.grant_digest=os_agent_profile_digest('command',g.payload-'grantDigest'))
  AND g.payload->>'bundleRevision'=(CASE WHEN os_repair_required_assurance(d)='oidc-step-up/1' THEN '11' WHEN d.original_kind='agent-reviewed' THEN '8' ELSE '7' END) AND g.payload->>'controlEpoch'='1'
  AND g.payload->>'proposalId'=p.proposal_id::text AND g.payload->>'proposalDigest'=p.proposal_digest
  AND g.payload->>'proposalRevision'='1' AND g.payload->>'stageId'=p.stage_id::text
  AND g.payload->>'capabilityRef'=d.capability_ref AND g.payload->>'definitionDigest'=d.definition_digest
  AND g.payload->>'registrationRevision'=d.registration_revision::text
  AND g.payload->>'originalReceiptId'=d.original_receipt_id::text
  AND g.payload->>'originalReceiptVersion'=d.original_receipt_version::text
  AND g.payload->>'invocationId'<>(CASE WHEN d.original_kind='agent-reviewed' THEN d.production_original->>'invocationId' WHEN d.original_kind='input-delegated' THEN
    (SELECT payload->>'invocationId' FROM os_input_delegated_receipts WHERE id=d.delegated_projection_id)
    ELSE (SELECT payload->>'invocationId' FROM os_input_reviewed_receipt_projections WHERE id=d.reviewed_projection_id) END)
  AND g.payload->'authorization'=jsonb_build_object('kind','review_decision','decision',approval.decision_ref)
  AND approval.decision_ref->>'id'=approval.id::text AND approval.decision_ref->>'proposalId'=p.proposal_id::text
  AND approval.decision_ref->>'digest'=p.proposal_digest AND approval.decision_ref->>'proposalRevision'='1'
  AND approval.decision_ref->>'assuranceRef'=os_repair_required_assurance(d)
  AND (approval.decision_ref->>'expiresAt')::timestamptz=g.expires_at
  AND (g.payload->>'createdAt')::timestamptz=g.created_at AND (g.payload->>'expiresAt')::timestamptz=g.expires_at
  AND g.created_at<=now_at AND g.expires_at>now_at AND g.expires_at<=approval.expires_at
  AND g.expires_at<=q.expires_at AND g.expires_at<=p.expires_at AND g.expires_at<=d.expires_at),false) IS NOT TRUE
  OR EXISTS(SELECT 1 FROM os_repair_revocations WHERE approval_id=approval.id)
 THEN RAISE EXCEPTION 'repair_fresh_grant'; END IF;
 IF os_repair_required_assurance(d)='oidc-step-up/1' THEN PERFORM os_oidc_assert_repair_approval(approval,q);END IF;
END $function$
;
CREATE OR REPLACE FUNCTION public.os_guard_repair_commit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE d os_repair_admissions%ROWTYPE; p os_repair_prepared%ROWTYPE; b os_repair_work%ROWTYPE;
 w os_work_attempts%ROWTYPE; q os_repair_challenges%ROWTYPE; approval os_repair_approvals%ROWTYPE;
 g os_repair_grants%ROWTYPE; artifact os_artifacts%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 command os_commands%ROWTYPE; now_at timestamptz;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_repair_admissions' THEN
  PERFORM os_assert_repair_current(NEW,NEW.authority);
  SELECT * INTO command FROM os_commands WHERE id=NEW.command_id;
  IF command.kind<>(CASE WHEN NEW.original_kind='agent-reviewed' THEN 'agent.repair.admit' ELSE 'repair.admit' END) OR command.accepted_task_id<>NEW.task_id OR command.request_digest<>NEW.command_digest
   OR NEW.session_id IS DISTINCT FROM (NEW.authority->>'sessionId')::uuid
   OR NEW.created_at>clock_timestamp() OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=NEW.task_id AND state='ACCEPTED')
  THEN RAISE EXCEPTION 'repair_admission_binding'; END IF;
  IF NEW.original_kind='agent-reviewed' THEN
   IF NEW.command_digest<>os_agent_profile_digest('command',jsonb_build_object('commandId',command.command_id,'original',NEW.production_original))
    OR EXISTS(SELECT 1 FROM os_budget_roots root,jsonb_each(root.outstanding) held WHERE root.id=NEW.root_id AND held.value<>'0'::jsonb)
    OR EXISTS(SELECT 1 FROM os_budget_roots root JOIN os_admissions admitted ON admitted.id=root.admission_id,
     jsonb_each(jsonb_build_object('workMs',70000+(admitted.bot->'resources'->>'requestTimeoutMs')::bigint,
      'computeMs',(admitted.bot->'resources'->>'requestTimeoutMs')::bigint,'storageBytes',2101248)) needed
     WHERE root.id=NEW.root_id AND (root.spent->>needed.key)::bigint+(needed.value::text)::bigint>
      (root.ceiling->>needed.key)::bigint+COALESCE((root.granted->>needed.key)::bigint,0))
    THEN RAISE EXCEPTION 'agent_repair_original_allowance'; END IF;
  END IF;
 ELSIF TG_TABLE_NAME='os_repair_work' OR TG_TABLE_NAME='os_work_attempts' THEN
  IF TG_TABLE_NAME='os_repair_work' THEN b=NEW;
  ELSE
   SELECT * INTO b FROM os_repair_work WHERE attempt_id=NEW.id;
   IF b.id IS NULL THEN
    SELECT * INTO d FROM os_repair_admissions WHERE task_id=NEW.task_id;
    IF d.id IS NOT NULL AND NOT COALESCE(d.original_kind='agent-reviewed' AND NEW.kind='agent.storage'
     AND NEW.accounting_format='agent-resources/1' AND NEW.root_id=d.root_id AND NEW.segment_id=d.segment_id
     AND NEW.control_epoch=1 AND EXISTS(SELECT 1 FROM os_agent_payload_writes write
      WHERE write.attempt_id=NEW.id AND write.id=os_query_source_uuid5(d.id,'prepared-content/1')
       AND write.root_id=d.root_id AND write.task_id=d.task_id AND write.segment_id=d.segment_id
       AND write.schema_ref='AgentRepairPreparedContent' AND write.schema_version=1),false)
     THEN RAISE EXCEPTION 'repair_orphan_work'; END IF;
    RETURN NULL;
   END IF;
   IF TG_OP='UPDATE' AND (NEW.state<>'RUNNING' OR OLD.state=NEW.state) THEN RETURN NULL; END IF;
  END IF;
  SELECT * INTO d FROM os_repair_admissions WHERE id=b.admission_id;
  PERFORM os_assert_repair_current(d,b.authority);
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  IF w.task_id<>d.task_id OR w.root_id<>d.root_id OR w.control_epoch<>1 OR w.lease_until<=clock_timestamp()
   OR w.lease_until>d.expires_at OR w.created_at<>b.created_at OR w.actual IS NOT NULL
   OR w.state<>(CASE WHEN TG_TABLE_NAME='os_work_attempts' AND TG_OP='UPDATE' THEN 'RUNNING' ELSE 'RESERVED' END)
   OR b.session_id IS DISTINCT FROM (b.authority->>'sessionId')::uuid
  THEN RAISE EXCEPTION 'repair_work_binding'; END IF;
  IF d.original_kind='agent-reviewed' THEN
   IF NOT COALESCE(w.kind='agent.repair' AND w.accounting_format='agent-resources/1'
    AND w.reserved=jsonb_build_object('tokens',0,'costMicros',0,'computeMs',0,'storageBytes',0,'workMs',(w.reserved->>'workMs')::bigint)
    AND (w.reserved->>'workMs')::bigint BETWEEN 1 AND CASE WHEN b.phase='prepare' THEN 25000 ELSE 45000 END
    AND w.request_digest=os_agent_profile_digest('command',jsonb_build_object('schema','agent-resource-reservation/1',
     'taskId',w.task_id,'segmentId',w.segment_id,'epoch',1,'invocationId',w.invocation_id,'kind','agent.repair',
     'inputDigest',os_agent_profile_digest('command',jsonb_build_object('profile','agent-repair-work/1','repairDigest',d.repair_digest,
      'phase',b.phase,'workMs',(w.reserved->>'workMs')::bigint,'grantId',b.grant_id)),
     'units',w.reserved,'timeoutMs',(w.reserved->>'workMs')::bigint)),false)
    THEN RAISE EXCEPTION 'agent_repair_work_binding'; END IF;
   IF b.phase='prepare' THEN
    IF w.segment_id<>d.segment_id OR w.invocation_id<>os_query_source_uuid5(d.id,'preparation/1')
     OR b.grant_id IS NOT NULL OR b.permit_id IS NOT NULL THEN RAISE EXCEPTION 'agent_repair_preparation_binding'; END IF;
   ELSE
    SELECT * INTO g FROM os_repair_grants WHERE id=b.grant_id;
    PERFORM os_assert_repair_grant(g);
    IF NOT COALESCE(g.admission_id=d.id AND b.authority=g.payload->'authority'
     AND w.invocation_id::text=g.payload->>'invocationId' AND b.effect_request_digest=g.payload->>'effectRequestDigest'
     AND w.segment_id::text=g.payload->>'segmentId' AND w.lease_until<=g.expires_at
     AND b.permit_id=os_query_source_uuid5(w.id,'repair-permit/1'),false)
     THEN RAISE EXCEPTION 'agent_repair_effect_binding'; END IF;
   END IF;
  ELSIF b.phase='prepare' THEN
   IF w.kind<>'read' OR w.segment_id<>d.segment_id OR (w.reserved->>'workMs')::bigint NOT BETWEEN 1 AND 25000
    OR w.reserved<>jsonb_build_object('stages',0,'children',0,'tokens',0,'toolCalls',2,'nativeJobs',0,'costMicros',0,'workMs',(w.reserved->>'workMs')::bigint,'repairs',0,'planRevisions',0)
   THEN RAISE EXCEPTION 'repair_preparation_budget'; END IF;
  ELSE
   SELECT * INTO g FROM os_repair_grants WHERE id=b.grant_id;
   PERFORM os_assert_repair_grant(g);
   IF g.admission_id<>d.id OR b.authority<>g.payload->'authority' OR w.kind<>'effect'
    OR w.invocation_id::text<>g.payload->>'invocationId' OR b.effect_request_digest<>g.payload->>'effectRequestDigest'
    OR w.segment_id::text<>g.payload->>'segmentId' OR w.lease_until>g.expires_at
    OR (w.reserved->>'workMs')::bigint NOT BETWEEN 1 AND 45000
    OR w.reserved<>jsonb_build_object('stages',1,'children',0,'tokens',0,'toolCalls',1,'nativeJobs',0,'costMicros',0,'workMs',(w.reserved->>'workMs')::bigint,'repairs',1,'planRevisions',0)
   THEN RAISE EXCEPTION 'repair_effect_budget'; END IF;
  END IF;
  IF w.lease_until>w.created_at+((w.reserved->>'workMs')::bigint*interval '1 millisecond')
   OR NOT EXISTS(SELECT 1 FROM os_segments WHERE id=w.segment_id AND task_id=d.task_id AND state='OPEN')
   OR EXISTS(SELECT 1 FROM os_budget_roots r,jsonb_object_keys(w.reserved) k WHERE r.id=d.root_id AND (r.outstanding->>k)::bigint<(w.reserved->>k)::bigint)
  THEN RAISE EXCEPTION 'repair_original_reservation'; END IF;
 ELSIF TG_TABLE_NAME='os_repair_prepared' THEN
  SELECT * INTO d FROM os_repair_admissions WHERE id=NEW.admission_id;
  SELECT * INTO b FROM os_repair_work WHERE id=NEW.work_binding_id;
  PERFORM os_assert_repair_current(d,b.authority);
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  SELECT * INTO artifact FROM os_artifacts WHERE id=NEW.artifact_id;
  IF b.phase<>'prepare' OR b.admission_id<>d.id OR w.state<>'SETTLED' OR w.lease_until<=clock_timestamp()
   OR artifact.purpose<>'artifact' OR artifact.classification<>'protected' OR artifact.ciphertext_digest<>NEW.ciphertext_digest
   OR (CASE WHEN d.original_kind='agent-reviewed' THEN NOT COALESCE(
    NEW.expires_at<=artifact.expires_at AND EXISTS(SELECT 1 FROM os_agent_private_payloads ready
     JOIN os_agent_payload_writes write ON write.id=ready.write_id JOIN os_work_attempts storage ON storage.id=write.attempt_id
     WHERE ready.id=artifact.id AND ready.root_id=d.root_id AND ready.ciphertext_digest=NEW.ciphertext_digest
      AND write.id=os_query_source_uuid5(d.id,'prepared-content/1') AND write.root_id=d.root_id AND write.task_id=d.task_id
      AND write.segment_id=d.segment_id AND write.schema_ref='AgentRepairPreparedContent' AND write.schema_version=1
      AND storage.state='SETTLED' AND storage.actual IS NOT NULL),false)
    ELSE artifact.expires_at<>NEW.expires_at END) OR NEW.expires_at>d.expires_at OR NEW.expires_at<=clock_timestamp()
   OR NOT EXISTS(SELECT 1 FROM os_tasks WHERE id=d.task_id AND state='WAITING_APPROVAL')
  THEN RAISE EXCEPTION 'repair_prepared_result'; END IF;
 ELSIF TG_TABLE_NAME='os_repair_challenges' OR TG_TABLE_NAME='os_repair_registrations' OR TG_TABLE_NAME='os_repair_approvals' THEN
  IF TG_TABLE_NAME='os_repair_challenges' THEN q=NEW;
  ELSE SELECT * INTO q FROM os_repair_challenges WHERE id=NEW.challenge_id; END IF;
  SELECT * INTO d FROM os_repair_admissions WHERE id=q.admission_id;
  SELECT * INTO p FROM os_repair_prepared WHERE id=q.prepared_id;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=q.session_id;
  PERFORM os_assert_repair_current(d,jsonb_build_object('subject',q.binding->'subject','sessionId',q.session_id,
   'sessionGeneration',session.session_generation,'applicationGeneration',session.application_generation,'subjectGeneration',session.subject_generation,
   'hostSessionRef',q.binding->>'hostSessionRef','profileRef',CASE WHEN d.original_kind='agent-reviewed' THEN d.authority->>'profileRef' ELSE 'local-synthetic' END,
   'policyGeneration',(q.binding->>'policyGeneration')::bigint));
  now_at=clock_timestamp();
  SELECT * INTO command FROM os_commands WHERE id=q.command_id;
  IF COALESCE((q.binding->>'challengeId'=q.id::text AND q.binding->>'sessionId'=q.session_id::text
   AND q.binding->>'proposalId'=p.proposal_id::text AND q.binding->>'proposalDigest'=p.proposal_digest
   AND q.binding->>'proposalRevision'='1' AND q.binding->>'requiredAssurance'=os_repair_required_assurance(d)
   AND q.binding->>'assuranceProfile'=CASE WHEN os_repair_required_assurance(d)='oidc-step-up/1' THEN 'oidc-step-up-assurance/1' ELSE 'local-synthetic-assurance/1' END
   AND length(q.binding->>'nonce') BETWEEN 32 AND 128 AND p.admission_id=d.id
   AND (q.binding->>'createdAt')::timestamptz=q.created_at AND (q.binding->>'expiresAt')::timestamptz=q.expires_at
   AND q.expires_at>now_at AND q.expires_at<=p.expires_at AND q.expires_at<=session.expires_at
   AND (q.binding->>'sessionGeneration')::bigint=session.session_generation),false) IS NOT TRUE
   OR command.kind<>'repair.challenge' OR command.accepted_task_id<>d.task_id OR command.request_digest<>q.command_digest
  THEN RAISE EXCEPTION 'repair_fresh_challenge'; END IF;
  IF os_repair_required_assurance(d)='oidc-step-up/1' THEN
   PERFORM os_oidc_assert_repair_challenge(q,(SELECT run_id FROM os_oidc_assurance_profiles WHERE installation_id=d.installation_id
    AND application_id=d.application_id AND profile_ref=q.binding->'provider'->>'ref' ORDER BY revision DESC LIMIT 1),
    CASE WHEN TG_TABLE_NAME='os_repair_approvals' THEN 'approval' ELSE 'review' END);
  END IF;
  IF (SELECT count(*) FROM os_repair_challenges WHERE admission_id=d.id)>8 THEN RAISE EXCEPTION 'repair_challenge_ceiling'; END IF;
  IF TG_TABLE_NAME='os_repair_registrations' THEN
   IF NEW.binding_digest<>q.binding_digest OR NEW.registration<>jsonb_build_object('challengeId',q.id,'bindingDigest',q.binding_digest,'expiresAt',q.binding->>'expiresAt')
   THEN RAISE EXCEPTION 'repair_registered_challenge'; END IF;
  END IF;
  IF TG_TABLE_NAME='os_repair_approvals' THEN
   SELECT * INTO command FROM os_commands WHERE id=NEW.command_id;
   IF COALESCE((NEW.admission_id=d.id AND NEW.prepared_id=p.id AND NEW.claim->'binding'=q.binding
    AND NEW.claim->>'decision'=NEW.decision AND NEW.claim->>'commandDigest'=NEW.command_digest
    AND NEW.attestation->>'bindingDigest'=q.binding_digest AND NEW.attestation->>'subject'=q.binding->>'subject'
    AND NEW.attestation->>'sessionId'=q.session_id::text AND NEW.attestation->>'challengeId'=q.id::text
    AND NEW.attestation->>'decision'=NEW.decision AND NEW.attestation->>'commandDigest'=NEW.command_digest
    AND NEW.attestation->>'assertionRef'=NEW.claim->>'assertionRef' AND NEW.attestation->>'commandId'=NEW.claim->>'commandId'
    AND command.kind='repair.approval' AND command.accepted_task_id=d.task_id AND command.request_digest=NEW.command_digest
    AND NEW.claim->>'commandId'=command.command_id::text
    AND (NEW.attestation->>'observedAt')::timestamptz BETWEEN now_at-interval '5 seconds' AND now_at+interval '1 second'
    AND NEW.expires_at>now_at AND NEW.expires_at<=q.expires_at AND NEW.expires_at<=(NEW.attestation->>'expiresAt')::timestamptz
    AND EXISTS(SELECT 1 FROM os_repair_registrations WHERE challenge_id=q.id AND binding_digest=q.binding_digest)),false) IS NOT TRUE
   THEN RAISE EXCEPTION 'repair_fresh_approval'; END IF;
   IF os_repair_required_assurance(d)='oidc-step-up/1' THEN PERFORM os_oidc_assert_repair_approval(NEW,q);END IF;
  END IF;
 ELSIF TG_TABLE_NAME='os_repair_grants' THEN PERFORM os_assert_repair_grant(NEW);
 ELSIF TG_TABLE_NAME='os_repair_revocations' THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE
   (installation_id,application_id,tenant_id,subject_id,id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
  IF session.revoked OR session.expires_at<=clock_timestamp() OR session.id IS NULL
   OR NOT EXISTS(SELECT 1 FROM os_applications a JOIN os_subjects s ON s.installation_id=a.installation_id AND s.application_id=a.id
    WHERE (s.installation_id,s.application_id,s.tenant_id,s.subject_id)=(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id)
    AND a.active AND s.active AND a.generation=session.application_generation AND s.generation=session.subject_generation)
  THEN RAISE EXCEPTION 'repair_revocation_owner'; END IF;
 ELSE
  SELECT * INTO b FROM os_repair_work WHERE id=NEW.binding_id;
  SELECT * INTO w FROM os_work_attempts WHERE id=b.attempt_id;
  SELECT * INTO g FROM os_repair_grants WHERE id=b.grant_id;
  IF COALESCE((b.phase='effect' AND w.state IN ('RUNNING','UNKNOWN','SETTLED')
   AND NEW.payload->>'providerRef'=g.payload->>'providerRef' AND NEW.payload->'subject'=g.payload->'subject'
   AND NEW.payload->>'invocationId'=g.payload->>'invocationId' AND NEW.payload->>'requestDigest'=g.payload->>'effectRequestDigest'
   AND NEW.payload->>'attestationProfile'='atomic-host-receipt-observation/1'),false) IS NOT TRUE
  THEN RAISE EXCEPTION 'repair_admitted_receipt_only'; END IF;
 END IF;
 RETURN NULL;
END $function$
;
"""

GROUP_GUARDS=r"""
CREATE OR REPLACE FUNCTION os_guard_agent_resource_group() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a os_agent_group_accounts%ROWTYPE; original os_agent_resource_accounts%ROWTYPE; r os_budget_roots%ROWTYPE;
 d os_admissions%ROWTYPE; c jsonb; member jsonb; required jsonb; w os_work_attempts%ROWTYPE; expected_kind text; expected_count integer;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'agent_group_immutable'; END IF;
 SELECT * INTO r FROM os_budget_roots WHERE id=NEW.root_id FOR UPDATE;
 SELECT * INTO a FROM os_agent_group_accounts WHERE id=NEW.group_account_id;
 SELECT * INTO original FROM os_agent_resource_accounts WHERE id=a.account_id;
 IF TG_OP='UPDATE' THEN
  IF OLD.state<>'WAITING' OR NEW.state NOT IN ('ADMITTED','CANCELLED','EXPIRED')
   OR (to_jsonb(NEW)-'state') IS DISTINCT FROM (to_jsonb(OLD)-'state') THEN RAISE EXCEPTION 'agent_group_transition'; END IF;
  IF NEW.state='ADMITTED' THEN
   PERFORM os_agent_resource_owner(original);
   w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
   w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));
   PERFORM os_assert_agent_work_current(w);
   IF EXISTS(SELECT 1 FROM os_agent_resource_groups WHERE root_id=NEW.root_id AND state='WAITING' AND ticket<NEW.ticket)
    THEN RAISE EXCEPTION 'agent_group_fifo'; END IF;
  END IF;
  RETURN NEW;
 END IF;
 PERFORM os_agent_resource_owner(original);
 SELECT * INTO d FROM os_admissions WHERE id=r.admission_id;
 c=NEW.request->'context';required=os_agent_group_required(NEW.request->'members');
 expected_kind=CASE NEW.profile_ref WHEN 'repair-reservation/1' THEN 'agent.repair' WHEN 'wasm-creation-reservation/1' THEN 'agent.native' WHEN 'model-reservation/1' THEN 'agent.model' WHEN 'tool-reservation/1' THEN CASE WHEN c->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END WHEN 'compute-reservation/1' THEN 'agent.compute' WHEN 'effect-reservation/1' THEN 'agent.effect' WHEN 'native-reservation/1' THEN 'agent.native' WHEN 'memory-reservation/1' THEN 'agent.memory' ELSE 'agent.storage' END;
 expected_count=CASE NEW.profile_ref WHEN 'wasm-creation-reservation/1' THEN 2 WHEN 'model-reservation/1' THEN 3 WHEN 'tool-reservation/1' THEN 2 WHEN 'memory-reservation/1' THEN 2 ELSE 1 END;
 IF a.id IS NULL OR a.root_id<>r.id OR NEW.group_account_id<>a.id OR NEW.state<>'WAITING' OR NEW.ticket<>a.next_ticket-1
  OR NEW.created_at>clock_timestamp() OR NEW.created_at>=r.deadline OR NOT COALESCE(os_agent_context_matches(d,c) OR (NEW.profile_ref IN ('repair-reservation/1','storage-reservation/1') AND os_agent_repair_child_context(d,c)),false)
  OR NEW.request IS DISTINCT FROM jsonb_build_object('context',c,'groupId',NEW.id::text,'profile',NEW.profile_ref,'sourceId',NEW.source_id::text,'members',NEW.request->'members')
  OR c->>'rootId'<>NEW.root_id::text OR c->>'taskId'<>NEW.task_id::text OR c->>'segmentId'<>NEW.segment_id::text
  OR (c->>'controlEpoch')::bigint<>NEW.control_epoch
  OR NEW.request_digest<>os_agent_profile_digest('command',NEW.request||jsonb_build_object('schema','agent-resource-group/1'))
  OR jsonb_array_length(NEW.request->'members')<>expected_count
  OR NEW.request->'members'->0->>'kind'<>expected_kind OR NEW.request->'members'->0->>'invocationId'<>NEW.source_id::text
  OR (SELECT count(DISTINCT value->>'invocationId') FROM jsonb_array_elements(NEW.request->'members'))<>expected_count
  THEN RAISE EXCEPTION 'agent_group_binding'; END IF;
 FOR member IN SELECT value FROM jsonb_array_elements(NEW.request->'members') LOOP
  IF member IS DISTINCT FROM jsonb_build_object('taskId',NEW.task_id::text,'segmentId',NEW.segment_id::text,'controlEpoch',NEW.control_epoch,
    'invocationId',member->'invocationId','kind',member->'kind','inputDigest',member->'inputDigest','units',member->'units','timeoutMs',member->'timeoutMs')
   OR jsonb_typeof(member->'invocationId') IS DISTINCT FROM 'string' OR (member->>'invocationId') !~ '^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$'
   OR jsonb_typeof(member->'inputDigest') IS DISTINCT FROM 'string' OR (member->>'inputDigest') !~ '^[a-f0-9]{64}$'
   OR member->>'kind' NOT IN ('agent.model','agent.tool','agent.storage','agent.compute','agent.effect','agent.native','agent.memory','agent.schedule','agent.repair')
   OR jsonb_typeof(member->'kind') IS DISTINCT FROM 'string'
   OR jsonb_typeof(member->'timeoutMs') IS DISTINCT FROM 'number' OR (member->>'timeoutMs') !~ '^[1-9][0-9]*$'
   OR (member->>'timeoutMs')::numeric>(original.policy->>'requestTimeoutMs')::numeric
   OR (member->'units')-ARRAY['tokens','costMicros','workMs','computeMs','storageBytes']<>'{}'::jsonb
   OR (member->'units'->>'workMs')::numeric<1 THEN RAISE EXCEPTION 'agent_group_member_request'; END IF;
 END LOOP;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(NEW.request->'members') WITH ORDINALITY AS m(value,ordinal) WHERE ordinal>1 AND value->>'kind'<>'agent.storage')
  THEN RAISE EXCEPTION 'agent_group_member_kind'; END IF;
 IF expected_kind='agent.schedule' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id
   AND tool.payload->'context'=c AND tool.payload->'capability'=os_agent_proactive_profile(d)->'capability'
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_proactive_group_source';END IF;
 IF NEW.profile_ref='memory-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND (p.payload ? 'memory' OR p.payload ? 'knowledge')
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_memory_group_source';END IF;
 IF NEW.profile_ref='wasm-creation-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_tool_operations tool JOIN os_agent_tool_profiles p ON p.installation_id=tool.installation_id
   AND p.application_id=tool.application_id AND p.policy_digest=tool.payload->'profile'->>'digest'
  WHERE tool.root_id=NEW.root_id AND tool.task_id=NEW.task_id AND tool.payload->'context'=c AND p.payload ? 'verification'
   AND os_query_source_uuid5(tool.id,'tool-attempt/'||(COALESCE((SELECT max(ordinal) FROM os_agent_tool_calls WHERE operation_id=tool.id),0)+1)::text)=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_wasm_creation_group_source'; END IF;
 IF NEW.profile_ref='native-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_native_operations native WHERE native.root_id=NEW.root_id AND native.task_id=NEW.task_id
   AND native.payload->'context'=c AND os_query_source_uuid5(native.id,'tool-attempt/1')=NEW.source_id)
 THEN RAISE EXCEPTION 'agent_native_group_source'; END IF;
 IF NEW.profile_ref='effect-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
   JOIN os_tasks task ON task.id=review.task_id
  WHERE decision.id=NEW.source_id AND review.root_id=NEW.root_id AND review.task_id=NEW.task_id
   AND review.payload->'context'=c AND decision.payload->'command'->>'decision'='approve'
   AND decision.expires_at>clock_timestamp() AND task.state='RUNNING'
   AND (NEW.request->'members'->0->>'inputDigest')=(os_agent_reviewed_grant(decision.id)->>'grantDigest'))
 THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
 IF NEW.profile_ref='repair-reservation/1' AND NOT EXISTS(
  SELECT 1 FROM os_repair_admissions repair JOIN os_tasks child ON child.id=repair.task_id
   LEFT JOIN os_repair_grants grant_row ON grant_row.admission_id=repair.id
  WHERE repair.original_kind='agent-reviewed' AND repair.root_id=NEW.root_id AND repair.task_id=NEW.task_id
   AND os_agent_repair_child_context(d,c) AND (
    (NEW.source_id=os_query_source_uuid5(repair.id,'preparation/1') AND NEW.segment_id=repair.segment_id
     AND child.state='ACCEPTED' AND NEW.request->'members'->0->>'inputDigest'=os_agent_profile_digest('command',
      jsonb_build_object('profile','agent-repair-work/1','repairDigest',repair.repair_digest,'phase','prepare',
       'workMs',(NEW.request->'members'->0->'units'->>'workMs')::bigint,'grantId',null)))
    OR (NEW.source_id=(grant_row.payload->>'invocationId')::uuid AND child.state='VALIDATING'
     AND NEW.segment_id=(grant_row.payload->>'segmentId')::uuid AND grant_row.expires_at>clock_timestamp()
     AND NEW.request->'members'->0->>'inputDigest'=os_agent_profile_digest('command',
      jsonb_build_object('profile','agent-repair-work/1','repairDigest',repair.repair_digest,'phase','effect',
       'workMs',(NEW.request->'members'->0->'units'->>'workMs')::bigint,'grantId',grant_row.id)))))
 THEN RAISE EXCEPTION 'agent_group_repair_source'; END IF;
 w.root_id=NEW.root_id;w.task_id=NEW.task_id;w.segment_id=NEW.segment_id;w.control_epoch=NEW.control_epoch;
 w.lease_until=LEAST(r.deadline,(SELECT deadline FROM os_tasks WHERE id=NEW.task_id));PERFORM os_assert_agent_work_current(w);
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION os_check_agent_group_complete() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE gid uuid; g os_agent_resource_groups%ROWTYPE; expected_count integer; actual uuid[]; claimed uuid[];
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF TG_TABLE_NAME='os_agent_resource_groups' THEN gid=NEW.id;
 ELSIF TG_TABLE_NAME='os_agent_group_members' THEN gid=NEW.group_id;
 ELSE SELECT group_id INTO gid FROM os_agent_group_members WHERE id=NEW.member_id; END IF;
 SELECT * INTO g FROM os_agent_resource_groups WHERE id=gid;
 IF g.id IS NULL THEN RAISE EXCEPTION 'agent_group_missing'; END IF;
 expected_count=jsonb_array_length(g.request->'members');
 SELECT array_agg(c.attempt_id ORDER BY c.attempt_id) INTO claimed FROM os_agent_group_claims c JOIN os_agent_group_members m ON m.id=c.member_id WHERE m.group_id=gid;
 IF g.state<>'ADMITTED' THEN
  IF EXISTS(SELECT 1 FROM os_agent_group_members WHERE group_id=gid) THEN RAISE EXCEPTION 'agent_group_unadmitted_work'; END IF;
  RETURN NEW;
 END IF;
 IF (SELECT count(*) FROM os_agent_group_members WHERE group_id=gid)<>expected_count OR cardinality(claimed) IS DISTINCT FROM expected_count
  THEN RAISE EXCEPTION 'agent_group_incomplete'; END IF;
 IF g.profile_ref='model-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_model_calls WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND request->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_model_source'; END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_model_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_model_slots WHERE call_id=g.source_id) s;
 ELSIF g.profile_ref IN ('tool-reservation/1','memory-reservation/1','wasm-creation-reservation/1') THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
    WHERE c.id=g.source_id AND c.root_id=g.root_id AND o.task_id=g.task_id AND o.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_tool_source'; END IF;
  IF NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_work_attempts w ON w.id=c.attempt_id
   WHERE c.id=g.source_id AND w.kind=CASE WHEN g.profile_ref='wasm-creation-reservation/1' THEN 'agent.native' WHEN g.profile_ref='memory-reservation/1' THEN 'agent.memory'
    WHEN g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%' THEN 'agent.schedule' ELSE 'agent.tool' END)
   OR (g.profile_ref='tool-reservation/1' AND g.request->'context'->'harness'->>'ref' LIKE 'reviewed-proactivity/%'
    AND NOT EXISTS(SELECT 1 FROM os_agent_tool_calls c JOIN os_agent_tool_operations o ON o.id=c.operation_id
     JOIN os_budget_roots r ON r.id=o.root_id JOIN os_admissions a ON a.id=r.admission_id
     JOIN os_agent_tool_profiles p ON p.installation_id=o.installation_id AND p.application_id=o.application_id
      AND p.policy_digest=o.payload->'profile'->>'digest'
     WHERE c.id=g.source_id AND p.payload ? 'proactive'
      AND p.payload->'proactive'->'capability'=o.payload->'capability'
      AND o.payload->'capability'=os_agent_proactive_profile(a)->'capability'))
  THEN RAISE EXCEPTION 'agent_group_tool_lane';END IF;
  SELECT array_agg(v ORDER BY v) INTO actual FROM (
   SELECT attempt_id v FROM os_agent_tool_calls WHERE id=g.source_id
   UNION ALL SELECT attempt_id v FROM os_agent_tool_slots WHERE id=g.source_id) s;
 ELSIF g.profile_ref='effect-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_review_decisions decision JOIN os_agent_reviews review ON review.id=decision.review_id
    WHERE decision.id=g.source_id AND review.root_id=g.root_id AND review.task_id=g.task_id
     AND review.payload->'context'=g.request->'context' AND decision.payload->'command'->>'decision'='approve')
   THEN RAISE EXCEPTION 'agent_group_effect_source'; END IF;
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.effect';
 ELSIF g.profile_ref='native-reservation/1' THEN
  IF NOT EXISTS(SELECT 1 FROM os_agent_native_calls call JOIN os_agent_native_operations native ON native.id=call.operation_id
   WHERE call.id=g.source_id AND call.root_id=g.root_id AND native.task_id=g.task_id AND native.payload->'context'=g.request->'context')
   THEN RAISE EXCEPTION 'agent_group_native_source'; END IF;
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_native_calls WHERE id=g.source_id;
 ELSIF g.profile_ref='repair-reservation/1' THEN
  SELECT array_agg(w.id ORDER BY w.id) INTO actual FROM os_work_attempts w
   JOIN os_repair_work b ON b.attempt_id=w.id JOIN os_repair_admissions repair ON repair.id=b.admission_id
   WHERE w.invocation_id=g.source_id AND w.root_id=g.root_id AND w.task_id=g.task_id
    AND w.segment_id=g.segment_id AND w.control_epoch=g.control_epoch AND w.kind='agent.repair'
    AND w.accounting_format='agent-resources/1' AND repair.original_kind='agent-reviewed'
    AND repair.root_id=g.root_id AND repair.task_id=g.task_id;
 ELSIF g.profile_ref='compute-reservation/1' THEN
  SELECT array_agg(id ORDER BY id) INTO actual FROM os_work_attempts
   WHERE invocation_id=g.source_id AND root_id=g.root_id AND task_id=g.task_id
    AND segment_id=g.segment_id AND control_epoch=g.control_epoch AND kind='agent.compute';
 ELSE
  SELECT array_agg(attempt_id ORDER BY attempt_id) INTO actual FROM os_agent_payload_writes
   WHERE id=g.source_id AND root_id=g.root_id AND task_id=g.task_id AND segment_id=g.segment_id AND control_epoch=g.control_epoch;
 END IF;
 IF actual IS DISTINCT FROM claimed THEN RAISE EXCEPTION 'agent_group_source_members'; END IF;
 RETURN NEW;
END $$;

"""

# Optional lane validators must run only for their declared policy object.
# Keep every original0092 tool/parent/owner/accounting predicate unchanged.
TOOL_CURRENT=r"""
CREATE OR REPLACE FUNCTION os_assert_agent_tool_current(o os_agent_tool_operations) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r os_budget_roots%ROWTYPE; q os_agent_resource_accounts%ROWTYPE; a os_admissions%ROWTYPE;
 p os_agent_tool_profiles%ROWTYPE; app os_applications%ROWTYPE; parent os_agent_operations%ROWTYPE;
 accepted os_agent_model_acceptances%ROWTYPE; producer os_agent_model_calls%ROWTYPE; archive os_agent_model_archives%ROWTYPE;
 f os_agent_private_payloads%ROWTYPE; w os_agent_payload_writes%ROWTYPE; cap os_agent_capabilities%ROWTYPE;
 c jsonb; i jsonb; dep jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 PERFORM os_assert_agent_memory_context(o.payload->'context',true);
 SELECT * INTO q FROM os_agent_resource_accounts WHERE root_id=o.root_id;PERFORM os_agent_resource_owner(q);
 PERFORM 1 FROM os_task_controls WHERE task_id IN (o.task_id,(SELECT root_task_id FROM os_budget_roots WHERE id=o.root_id)) ORDER BY task_id FOR UPDATE;
 SELECT * INTO r FROM os_budget_roots WHERE id=o.root_id FOR UPDATE;SELECT * INTO a FROM os_admissions WHERE id=r.admission_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=o.installation_id AND id=o.application_id;
 c:=o.payload->'context';i:=o.payload->'identity';dep:=o.payload->'modelResult';
 SELECT * INTO p FROM os_agent_tool_profiles WHERE installation_id=o.installation_id AND application_id=o.application_id AND policy_digest=o.payload->'profile'->>'digest';
 SELECT * INTO parent FROM os_agent_operations WHERE id=o.parent_operation_id;
 SELECT * INTO accepted FROM os_agent_model_acceptances WHERE id=o.source_acceptance_id;
 SELECT * INTO producer FROM os_agent_model_calls WHERE id=accepted.call_id;
 SELECT * INTO archive FROM os_agent_model_archives WHERE id=accepted.artifact_id;
 SELECT * INTO f FROM os_agent_private_payloads WHERE id=o.binding_id;
 SELECT * INTO w FROM os_agent_payload_writes WHERE id=f.write_id;
 SELECT * INTO cap FROM os_agent_capabilities WHERE installation_id=o.installation_id AND application_id=o.application_id
  AND application_generation=app.generation AND capability_ref=o.payload->'capability'->>'ref' ORDER BY revision DESC LIMIT 1;
 IF NOT COALESCE(r.state='ACTIVE' AND r.deadline>clock_timestamp() AND r.accounting_format='agent-resources/1'
 AND ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)=ROW(r.installation_id,r.application_id,r.tenant_id,r.subject_id)
 AND os_agent_context_matches(a,c) AND o.task_id=r.root_task_id AND o.digest=os_agent_profile_digest('command',o.payload)
 AND o.payload=jsonb_build_object('context',c,'identity',i,'binding',o.payload->'binding','modelOperationId',o.parent_operation_id,
  'modelResult',dep,'capability',o.payload->'capability','profile',o.payload->'profile')
 AND i=jsonb_build_object('operationId',o.id,'taskId',o.task_id,'rootId',o.root_id,'segmentId',a.segment_id,
  'intentRevision',c->'intentRevision','controlEpoch',c->'controlEpoch','planRevision',parent.payload->'identity'->'planRevision',
  'parentOperationId',o.parent_operation_id,'iteration',parent.payload->'identity'->'iteration','kind','tool','inputDigest',i->'inputDigest')
 AND i->>'inputDigest' ~ '^[a-f0-9]{64}$' AND parent.root_id=o.root_id AND parent.payload->'context'=c
 AND producer.root_id=o.root_id AND producer.request->'context'=c AND producer.expires_at>clock_timestamp()
 AND EXISTS(SELECT 1 FROM os_agent_operation_models link WHERE link.operation_id=parent.id AND link.id=producer.id)
 AND dep=jsonb_build_object('subject',c->'subject','taskId',producer.task_id,'rootId',producer.root_id,'resultId',accepted.id,
   'producerStepId',producer.id,'acceptedAttemptId',producer.attempt_id,'payload',jsonb_build_object('artifactRef','artifact/'||archive.id,
   'ciphertextDigest',archive.ciphertext_digest,'bytes',archive.plain_bytes,'schemaRef','AgentProviderResponse','schemaVersion',1),
   'lineageRef',null,'scopeRef',producer.request->'context'->'scopeRef','acceptedAt',dep->'acceptedAt')
 AND (dep->>'acceptedAt')::timestamptz=accepted.created_at
 AND ROW(producer.installation_id,producer.application_id,producer.tenant_id,producer.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND (w.model_context=c OR w.model_context IS NULL AND c=a.context AND c->'harness'->>'ref' NOT LIKE 'private-planned-read/%')
 AND w.task_id=o.task_id AND w.root_id=o.root_id AND w.schema_ref='AgentSDKToolBinding' AND w.schema_version=1 AND w.expires_at>clock_timestamp()
 AND ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id)=ROW(o.installation_id,o.application_id,o.tenant_id,o.subject_id)
 AND o.payload->'binding'=jsonb_build_object('artifactRef','artifact/'||f.id,'ciphertextDigest',f.ciphertext_digest,'bytes',w.plain_bytes,'schemaRef',w.schema_ref,'schemaVersion',w.schema_version)
 AND p.application_generation=app.generation AND p.registration_revision=app.revision AND p.digest=os_agent_profile_digest('policy',p.payload)
 AND o.payload->'profile'=jsonb_build_object('ref',p.payload->'execution'->'id','revision',p.payload->'execution'->'revision','digest',p.policy_digest)
 AND ((p.payload->'verification'->'capability'=o.payload->'capability'
  AND p.payload->'verification'->'harness'=c->'harness' AND c=a.context
  AND p.payload->'verification'->>'installationId'=o.installation_id::text
  AND p.payload->'verification'->>'applicationId'=o.application_id::text
  AND cap.payload->>'kind'='native' AND cap.payload->>'adapterRef'='native.verify-tool/1'
  AND cap.payload->>'scopePolicyRef'='owner-cases-verified-tool/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix))
 OR (p.payload->'read'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='mcp.read/1')
 OR (p.payload->'preparation'->'capability'=o.payload->'capability' AND cap.payload->>'kind'='propose'
  AND cap.payload->>'adapterRef'='typed.prepare/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'memory'->'capability'=o.payload->'capability' AND p.payload->'memory'->'harness'=c->'harness'
  AND p.payload->'memory'->>'installationId'=o.installation_id::text
  AND p.payload->'memory'->>'applicationId'=o.application_id::text AND cap.payload->>'kind'='memory'
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)
  AND cap.payload->>'adapterRef'='owner.memory.read/1' AND cap.payload->>'scopePolicyRef'='owner-approved-memory/1'
  AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'knowledge'->'capability'=o.payload->'capability' AND p.payload->'knowledge'->'harness'=c->'harness'
  AND c<>a.context AND p.payload->'knowledge'->'planning'=CASE WHEN jsonb_typeof(p.payload->'knowledge')='object' THEN os_agent_planning_profile(a) ELSE NULL END
  AND p.payload->'knowledge'->>'installationId'=o.installation_id::text
  AND p.payload->'knowledge'->>'applicationId'=o.application_id::text
  AND cap.payload->>'kind'='memory' AND cap.payload->>'adapterRef'='private.knowledge.read/1'
  AND cap.payload->>'scopePolicyRef'='private-reviewed-knowledge/1' AND cap.payload->'mcp'='null'::jsonb)
 OR (p.payload->'discovery'->'capability'=o.payload->'capability' AND p.payload->'discovery'->'harness'=c->'harness'
  AND c=a.context AND p.payload->'discovery'->'planning'=CASE WHEN jsonb_typeof(p.payload->'discovery')='object' THEN os_agent_discovery_profile(a) ELSE NULL END
  AND cap.payload->>'kind'='read' AND cap.payload->>'adapterRef'='os.capabilities.discover/1'
  AND cap.payload->>'scopePolicyRef'='current-task-capability-metadata/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix))
 OR (p.payload->'proactive'->'capability'=o.payload->'capability' AND p.payload->'proactive'->'harness'=c->'harness'
  AND c=a.context AND p.payload->'proactive'->'planning'=CASE WHEN jsonb_typeof(p.payload->'proactive')='object' THEN os_agent_proactive_profile(a) ELSE NULL END
  AND cap.payload->>'kind'='schedule' AND cap.payload->>'adapterRef'='os.proactivity.prepare/1'
  AND cap.payload->>'scopePolicyRef'='owner-reviewed-proactivity/1' AND cap.payload->'mcp'='null'::jsonb
  AND EXISTS(SELECT 1 FROM jsonb_array_elements_text(a.bot->'capabilities'->'capabilityPrefixes') prefix
   WHERE left(cap.capability_ref,length(prefix))=prefix)))
 AND os_agent_capability_matches(a,c,o.payload->'capability')
 AND cap.payload->>'lifecycle'='qualified' AND cap.payload->>'purpose'=c->>'purpose'
 AND o.payload->'capability'=jsonb_build_object('ref',cap.capability_ref,'revision',cap.revision,'digest',cap.digest)
 AND EXISTS(SELECT 1 FROM os_task_controls k JOIN os_tasks t ON t.id=k.task_id WHERE k.task_id=o.task_id
  AND k.state='ACTIVE' AND k.epoch=(c->>'controlEpoch')::bigint AND t.deadline>clock_timestamp()
  AND t.state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED'))
 AND EXISTS(SELECT 1 FROM os_segments s WHERE s.id=a.segment_id AND s.task_id=o.task_id AND s.state='OPEN'),false)
 THEN RAISE EXCEPTION 'agent_tool_operation_binding'; END IF;
END $$;
"""

# Derive the extended command only from its exact consumed OIDC fact.
# The separate commit guard retains current identity and complete proof checks.
PROACTIVE_COMMAND=r"""
CREATE OR REPLACE FUNCTION os_proactive_command_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE d os_proactive_definitions%ROWTYPE; r os_proactive_revisions%ROWTYPE;
BEGIN
 PERFORM os_proactive_session(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.session_id);
 SELECT * INTO d FROM os_proactive_definitions WHERE id=NEW.definition_id FOR UPDATE;
 IF d.version<>NEW.accepted_version OR NEW.receipt->>'commandId'<>NEW.command_id::text
  OR NEW.receipt->'definition'->'subject'<>jsonb_build_object('installationId',NEW.installation_id::text,'applicationId',NEW.application_id::text,
   'tenantId',NEW.tenant_id,'subjectId',NEW.subject_id) THEN RAISE EXCEPTION 'proactive_command_binding';END IF;
 SELECT * INTO r FROM os_proactive_revisions WHERE definition_id=d.id AND revision=d.configuration_revision;
 IF r.agent_operation_id IS NOT NULL AND NEW.kind='draft' AND NOT COALESCE(
  NEW.expected_version=0 AND NEW.accepted_version=1 AND NEW.command_id=os_query_source_uuid5(r.agent_operation_id,'proactive-draft/1')
  AND NEW.request_digest=os_agent_profile_digest('command',jsonb_build_object('commandId',NEW.command_id,'expectedRevision',null,'configuration',r.configuration)),false)
 THEN RAISE EXCEPTION 'agent_proactive_draft_command';END IF;
 IF r.agent_operation_id IS NOT NULL AND NEW.kind='activate' AND NOT COALESCE(NEW.expected_version=1 AND NEW.accepted_version=2
  AND NEW.request_digest=os_agent_profile_digest('command',jsonb_build_object('commandId',NEW.command_id,'expectedRevision',1,
   'configurationDigest',r.configuration_digest,'decision','activate')||COALESCE((SELECT jsonb_build_object('challengeId',f.payload->'binding'->>'challengeId',
    'assertionRef','assertion/'||f.assertion_id::text) FROM os_oidc_assurance_flows f
    WHERE ROW(f.installation_id,f.application_id,f.tenant_id,f.subject_id,f.activation_command_id)=
     ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.command_id)
     AND f.activation_revision_id=r.id AND f.state='CONSUMED' AND f.payload->'binding'->>'sessionId'=NEW.session_id::text),'{}'::jsonb)),false)
 THEN RAISE EXCEPTION 'agent_proactive_review_command';END IF;
 RETURN NEW;
END $$;
"""

ACTIVATION_COMMIT=r"""
CREATE FUNCTION os_oidc_proactive_command_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s os_interactive_sessions%ROWTYPE; f os_oidc_assurance_flows%ROWTYPE; r os_proactive_revisions%ROWTYPE;
 e os_embed_registrations%ROWTYPE; b jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 IF NEW.kind NOT IN ('activate','reject') THEN RETURN NEW;END IF;
 SELECT * INTO s FROM os_interactive_sessions WHERE id=NEW.session_id;
 SELECT * INTO e FROM os_embed_registrations WHERE installation_id=NEW.installation_id AND application_id=NEW.application_id AND id=s.embed_ref;
 -- Once this current client is operator-configured for OIDC, removing a fact
 -- or disabling its profile cannot downgrade an activation to local assurance.
 IF NOT EXISTS(SELECT 1 FROM os_oidc_assurance_profiles p WHERE p.installation_id=NEW.installation_id
  AND p.application_id=NEW.application_id AND p.payload->'clientProfile'->>'id'=e.payload->>'clientProfile')
 THEN RETURN NEW;END IF;
 SELECT * INTO f FROM os_oidc_assurance_flows WHERE
  ROW(installation_id,application_id,tenant_id,subject_id,activation_command_id)=
  ROW(NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.command_id);
 SELECT * INTO r FROM os_proactive_revisions WHERE id=f.activation_revision_id;
 b:=f.payload->'binding';
 IF NOT COALESCE(f.id IS NOT NULL AND f.state='CONSUMED' AND f.expires_at>clock_timestamp()
  AND f.payload->>'definitionId'=NEW.definition_id::text AND r.definition_id=NEW.definition_id
  AND r.configuration_digest=f.payload->'command'->>'configurationDigest'
  AND f.payload->'command'->>'decision'=NEW.kind
  AND (f.payload->'command'->>'expectedRevision')::bigint=NEW.expected_version
  AND f.claim->>'commandDigest'=NEW.request_digest AND f.claim->>'commandId'=NEW.command_id::text
  AND f.claim->>'decision'=CASE WHEN NEW.kind='activate' THEN 'approve' ELSE 'reject' END
  AND b->>'sessionId'=NEW.session_id::text
  AND (f.authentication->>'expiresAt')::timestamptz>clock_timestamp(),false)
 THEN RAISE EXCEPTION 'oidc_proactive_exact_command';END IF;
 PERFORM os_oidc_assert_identity(s,b,f.run_id,(r.configuration->>'validUntil')::timestamptz);
 RETURN NEW;
END $$;
CREATE TRIGGER guard_oidc_proactive_command BEFORE INSERT ON os_proactive_commands
 FOR EACH ROW EXECUTE FUNCTION os_oidc_proactive_command_guard();
"""


def upgrade():
    op.execute(TABLES)
    op.execute(REPAIR_SHAPES)
    op.execute(COMMANDS)
    op.execute(OWNER)
    op.execute(FLOW_GUARD)
    op.execute(REPAIR_GUARDS)
    op.execute(GROUP_GUARDS)
    op.execute(TOOL_CURRENT)
    op.execute(PROACTIVE_COMMAND)
    op.execute(ACTIVATION_COMMIT)


def downgrade():
    raise RuntimeError('OIDC command origins require protected forward recovery')
