"""Immutable selected accepted inputs/outcomes and versioned learning dispatch."""
from alembic import op

revision="os_pg_0037"
down_revision="os_pg_0036"
branch_labels=None
depends_on=None


def upgrade():
    for statement in TABLES:op.get_bind().exec_driver_sql(statement)
    op.execute(GUARDS)


# Static DDL/guard snapshots; no imports from changing models or prior revisions.
TABLES = (
    """
CREATE TABLE personal_learning_source_origins (
	id UUID NOT NULL, 
	source_id UUID NOT NULL, 
	task_id UUID NOT NULL, 
	segment_id UUID NOT NULL, 
	input_id UUID, 
	result_id UUID, 
	artifact_id UUID NOT NULL, 
	ciphertext_digest VARCHAR(64) NOT NULL, 
	task_version BIGINT NOT NULL, 
	policy_generation BIGINT NOT NULL, 
	occurred_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	installation_id UUID NOT NULL, 
	application_id UUID NOT NULL, 
	tenant_id VARCHAR(256) NOT NULL, 
	subject_id VARCHAR(256) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_learning_source_origin_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_personal_learning_sources_source_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, source_id) REFERENCES personal_learning_sources (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_tasks_task_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, task_id) REFERENCES os_tasks (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_segments_segment_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, segment_id) REFERENCES os_segments (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_source_inputs_input_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, input_id) REFERENCES os_source_inputs (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_accepted_results_result_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, result_id) REFERENCES os_accepted_results (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT fk_os_artifacts_artifact_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, artifact_id) REFERENCES os_artifacts (installation_id, application_id, tenant_id, subject_id, id), 
	CONSTRAINT uq_learning_source_origin_once UNIQUE (installation_id, application_id, tenant_id, subject_id, source_id), 
	CONSTRAINT uq_learning_source_selected_input UNIQUE (installation_id, application_id, tenant_id, subject_id, input_id), 
	CONSTRAINT uq_learning_source_selected_result UNIQUE (installation_id, application_id, tenant_id, subject_id, result_id), 
	CONSTRAINT ck_learning_source_origin_kind CHECK ((input_id IS NOT NULL AND result_id IS NULL) OR (input_id IS NULL AND result_id IS NOT NULL)), 
	CONSTRAINT ck_learning_source_origin_versions CHECK (task_version>0 AND policy_generation>0 AND created_at>=occurred_at), 
	CONSTRAINT ck_learning_source_origin_digest CHECK (ciphertext_digest ~ '^[a-f0-9]{64}$')
)
""",
    """
ALTER TABLE personal_learning_sources DROP CONSTRAINT ck_learning_source_state
""",
    """
ALTER TABLE personal_learning_sources ADD CONSTRAINT ck_learning_source_state CHECK (kind IN ('owner-statement/1','accepted-user-turn/1','accepted-outcome/1') AND learning_epoch>0 AND ((state='AVAILABLE' AND revision=1) OR (state='FORGOTTEN' AND revision=2)))
""",
    """
ALTER TABLE personal_learning_sources DROP CONSTRAINT ck_learning_source_time
""",
    """
ALTER TABLE personal_learning_sources ADD CONSTRAINT ck_learning_source_time CHECK (updated_at>=created_at AND expires_at>created_at AND expires_at<=created_at+interval '14 days' AND (kind<>'owner-statement/1' OR expires_at=created_at+interval '14 days'))
""",
    """
ALTER TABLE personal_learning_jobs DROP CONSTRAINT ck_learning_job_profile
""",
    """
ALTER TABLE personal_learning_jobs ADD CONSTRAINT ck_learning_job_profile CHECK (profile_ref='synthetic-staging/1' AND prompt_ref IN ('mem0-2.2.1-owner-source/1','mem0-2.2.1-accepted-source/2') AND source_mac ~ '^[a-f0-9]{64}$')
""",
    """
ALTER TABLE personal_knowledge_publications DROP CONSTRAINT ck_knowledge_publication_operation
""",
    """
ALTER TABLE personal_knowledge_publications ADD CONSTRAINT ck_knowledge_publication_operation CHECK (epistemic IN ('user-stated','derived-outcome') AND ((operation='add' AND target_count=0) OR (operation='supersede' AND target_count=1) OR (operation='merge' AND target_count BETWEEN 2 AND 8)))
""",
)

GUARDS = r"""
CREATE FUNCTION os_selected_learning_source_current(sid uuid) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
 t os_tasks%ROWTYPE; segment os_segments%ROWTYPE; a os_artifacts%ROWTYPE; owner os_subjects%ROWTYPE;
 input os_source_inputs%ROWTYPE; result os_accepted_results%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 IF s.id IS NULL THEN RETURN false; END IF;
 IF s.kind='owner-statement/1' THEN RETURN NOT EXISTS(SELECT 1 FROM personal_learning_source_origins WHERE source_id=sid); END IF;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO t FROM os_tasks WHERE id=o.task_id;
 SELECT * INTO segment FROM os_segments WHERE id=o.segment_id;
 SELECT * INTO a FROM os_artifacts WHERE id=o.artifact_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 IF o.id IS NULL OR t.state IS DISTINCT FROM 'COMPLETED' OR t.version<>o.task_version
  OR segment.task_id<>t.id OR segment.state IS DISTINCT FROM 'FINISHED'
  OR NOT EXISTS(SELECT 1 FROM os_task_controls WHERE task_id=t.id AND state='ACTIVE')
  OR owner.id IS NULL OR NOT owner.active OR owner.host_policy_generation<>o.policy_generation
  OR a.id IS NULL OR a.expires_at<=clock_timestamp() OR a.ciphertext_digest<>o.ciphertext_digest
  OR s.expires_at>a.expires_at OR o.created_at<>s.created_at
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'name'='os.grounded/1')
  OR NOT EXISTS(SELECT 1 FROM os_public_events WHERE segment_id=segment.id AND visibility_generation=o.policy_generation
      AND payload->>'type'='RUN_FINISHED') THEN RETURN false; END IF;
 IF o.input_id IS NOT NULL THEN
  SELECT * INTO input FROM os_source_inputs WHERE id=o.input_id;
  RETURN s.kind='accepted-user-turn/1' AND input.admitted_task_id=t.id AND input.artifact_id=a.id
   AND input.expires_at>clock_timestamp() AND s.expires_at<=input.expires_at
   AND a.purpose='intent' AND a.classification='owner-private' AND o.occurred_at=input.created_at
   AND EXISTS(SELECT 1 FROM os_admissions WHERE task_id=t.id AND source_input_id=input.id AND segment_id=segment.id);
 ELSE
  SELECT * INTO result FROM os_accepted_results WHERE id=o.result_id;
  RETURN s.kind='accepted-outcome/1' AND result.task_id=t.id AND result.segment_id=segment.id
   AND result.artifact_id=a.id AND result.ciphertext_digest=a.ciphertext_digest AND result.contract_ref='ReadStageResult'
   AND a.purpose='artifact' AND a.classification='protected' AND o.occurred_at=result.created_at
   AND EXISTS(SELECT 1 FROM os_work_attempts WHERE id=result.attempt_id AND state='SETTLED');
 END IF;
END $$;
CREATE FUNCTION os_guard_selected_learning_origin() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'selected_learning_origin_immutable'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_selected_learning_origin BEFORE INSERT OR UPDATE OR DELETE ON personal_learning_source_origins
 FOR EACH ROW EXECUTE FUNCTION os_guard_selected_learning_origin();
CREATE FUNCTION os_commit_selected_learning_origin() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NOT COALESCE(os_selected_learning_source_current(NEW.source_id),false)
 THEN RAISE EXCEPTION 'selected_learning_origin_binding'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_selected_learning_origin AFTER INSERT ON personal_learning_source_origins
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_selected_learning_origin();

CREATE OR REPLACE FUNCTION os_guard_learning_source_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE sid uuid; settings personal_learning_settings%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_learning_sources' THEN
  sid=NEW.id;
  IF TG_OP='INSERT' THEN
   SELECT * INTO settings FROM personal_learning_settings WHERE id=NEW.settings_id;
   IF settings.choice->'learnConversation' IS DISTINCT FROM 'true'::jsonb
    OR settings.learning_epoch<>NEW.learning_epoch OR NEW.expires_at<=clock_timestamp()
    OR (SELECT count(*) FROM personal_learning_sources WHERE settings_id=NEW.settings_id AND state='AVAILABLE')>64
    THEN RAISE EXCEPTION 'learning_source_consent_capacity'; END IF;
   PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
  END IF;
 ELSE
  sid=NEW.source_id;
  IF TG_TABLE_NAME='personal_learning_source_forgets' THEN
   IF TG_OP='INSERT' THEN PERFORM os_assert_learning_source_owner(sid,NEW.session_id);
   ELSE PERFORM os_assert_learning_source_owner(sid,NEW.cleanup_session_id); END IF;
  END IF;
 END IF;
 PERFORM os_assert_learning_source(sid);
 IF TG_TABLE_NAME='personal_learning_sources' AND TG_OP='INSERT' AND NOT COALESCE(os_selected_learning_source_current(sid),false)
  THEN RAISE EXCEPTION 'selected_learning_source_binding'; END IF;
 RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION os_assert_learning_job_live(j personal_learning_jobs) RETURNS void LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO app FROM os_applications WHERE installation_id=j.installation_id AND id=j.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=j.installation_id AND application_id=j.application_id
  AND tenant_id=j.tenant_id AND subject_id=j.subject_id;
 IF s.id IS NULL OR s.learning_epoch<>j.learning_epoch OR s.choice->'learnConversation' IS DISTINCT FROM 'true'::jsonb
  OR s.choice->>'extractorProfile'<>j.profile_ref OR app.id IS NULL OR NOT app.active OR owner.id IS NULL OR NOT owner.active
  OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
  OR j.expires_at<=clock_timestamp() OR j.account_valid_until<=clock_timestamp()
  OR j.account_checked_at<clock_timestamp()-interval '5 seconds'
  OR j.account_checked_at>clock_timestamp()+interval '5 seconds'
  OR NOT EXISTS(SELECT 1 FROM personal_learning_job_sources WHERE job_id=j.id)
  OR EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id
   JOIN personal_learning_source_intents i ON i.id=e.intent_id WHERE e.job_id=j.id
    AND (r.settings_id<>j.settings_id OR r.state<>'AVAILABLE' OR r.revision<>e.source_revision
     OR r.learning_epoch<>j.learning_epoch OR r.expires_at<=clock_timestamp() OR r.envelope IS NULL
     OR i.source_id<>r.id OR i.learning_epoch<>j.learning_epoch OR i.state<>'PENDING_DISPATCH'
     OR i.extractor_ref<>j.profile_ref OR i.due_at>j.created_at
     OR NOT COALESCE(os_selected_learning_source_current(r.id),false)
     OR (j.prompt_ref='mem0-2.2.1-owner-source/1' AND r.kind<>'owner-statement/1')
     OR (j.prompt_ref='mem0-2.2.1-accepted-source/2' AND r.kind='owner-statement/1')))
  OR (SELECT count(DISTINCT r.kind) FROM personal_learning_job_sources e JOIN personal_learning_sources r ON r.id=e.source_id WHERE e.job_id=j.id)<>1
 THEN RAISE EXCEPTION 'learning_job_current_authority'; END IF;
END $$;
CREATE OR REPLACE FUNCTION os_learning_candidate_invalid(cid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT EXISTS(SELECT 1 FROM personal_knowledge_candidate_sources e JOIN personal_learning_sources s ON s.id=e.source_id
  WHERE e.candidate_id=cid AND (s.state<>'AVAILABLE' OR s.revision<>e.source_revision OR s.expires_at<=clock_timestamp() OR NOT COALESCE(os_selected_learning_source_current(s.id),false)))
$$;

CREATE OR REPLACE FUNCTION os_revision_sources_current(rid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT NOT EXISTS(SELECT 1 FROM personal_knowledge_publications p JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
 JOIN personal_learning_sources s ON s.id=e.source_id WHERE p.revision_id=rid AND
 (s.state<>'AVAILABLE' OR s.revision<>e.source_revision OR s.expires_at<=clock_timestamp()
  OR NOT COALESCE(os_selected_learning_source_current(s.id),false)))
$$;

CREATE OR REPLACE FUNCTION os_assert_candidate_decision(did uuid,live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE d personal_candidate_decisions%ROWTYPE; c personal_knowledge_candidates%ROWTYPE;
 r personal_knowledge_candidate_revisions%ROWTYPE; j personal_learning_jobs%ROWTYPE;
 s personal_learning_settings%ROWTYPE; p personal_knowledge_publications%ROWTYPE;
 op personal_knowledge_operations%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE; expected jsonb;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO d FROM personal_candidate_decisions WHERE id=did;
 SELECT * INTO c FROM personal_knowledge_candidates WHERE id=d.candidate_id;
 SELECT * INTO r FROM personal_knowledge_candidate_revisions WHERE id=d.candidate_revision_id;
 SELECT * INTO j FROM personal_learning_jobs WHERE id=c.job_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=j.settings_id;
 SELECT * INTO p FROM personal_knowledge_publications WHERE decision_id=d.id;
 IF d.id IS NULL OR c.id IS NULL OR r.id IS NULL OR j.state IS DISTINCT FROM 'SUCCEEDED' OR s.id IS NULL
  OR r.candidate_id<>c.id OR r.ordinal<>d.accepted_version OR c.version<>d.accepted_version
  OR c.state<>(CASE WHEN d.decision='reject' THEN 'REJECTED' ELSE 'ACCEPTED' END)
  OR c.updated_at<>d.created_at OR d.context_revision>s.context_revision
  OR (r.envelope IS NULL AND NOT os_candidate_erasure_allowed(c.id))
  THEN RAISE EXCEPTION 'candidate_decision_binding'; END IF;
 IF d.decision='reject' THEN
  IF p.id IS NOT NULL THEN RAISE EXCEPTION 'candidate_rejection_publication'; END IF;
  expected='null'::jsonb;
 ELSE
  SELECT * INTO op FROM personal_knowledge_operations WHERE id=p.operation_id;
  IF p.id IS NULL OR p.candidate_id<>c.id OR p.candidate_revision_id<>r.id OR p.created_at<>d.created_at
   OR op.id IS NULL OR op.kind<>'SAVE' OR op.entry_id<>p.entry_id OR op.command_id<>d.command_id
   OR op.session_id<>d.session_id OR op.context_revision<>d.context_revision OR op.created_at<>d.created_at
   OR NOT EXISTS(SELECT 1 FROM personal_knowledge_revisions kr WHERE kr.id=p.revision_id AND kr.entry_id=p.entry_id AND kr.operation_id=op.id)
   OR (SELECT count(*) FROM personal_knowledge_supersessions WHERE publication_id=p.id)<>p.target_count
   THEN RAISE EXCEPTION 'candidate_atomic_publication'; END IF;
  IF p.epistemic IS DISTINCT FROM (CASE WHEN d.decision='edit-and-accept' THEN 'user-stated'
    WHEN EXISTS(SELECT 1 FROM personal_learning_job_sources e JOIN personal_learning_sources s ON s.id=e.source_id
     WHERE e.job_id=j.id AND s.kind='accepted-outcome/1') THEN 'derived-outcome' ELSE 'user-stated' END)
   THEN RAISE EXCEPTION 'candidate_epistemic_origin'; END IF;
  expected=op.receipt;
 END IF;
 IF d.receipt IS DISTINCT FROM jsonb_build_object('commandId',d.command_id,'decisionId',d.id,'candidateId',c.id,
  'candidateRevision',c.version,'state',c.state,'contextRevision',d.context_revision,'knowledge',expected)
  THEN RAISE EXCEPTION 'candidate_atomic_receipt'; END IF;
 IF live THEN
  SELECT * INTO session FROM os_interactive_sessions WHERE id=d.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=d.installation_id AND id=d.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=d.installation_id AND application_id=d.application_id
   AND tenant_id=d.tenant_id AND subject_id=d.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp() OR d.request_mac IS NULL
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation OR owner.id IS NULL
   OR NOT owner.active OR owner.generation<>session.subject_generation OR c.expires_at<=clock_timestamp()
   OR os_learning_candidate_invalid(c.id) THEN RAISE EXCEPTION 'candidate_current_review'; END IF;
  IF d.decision<>'reject' THEN
   IF s.context_revision<>d.context_revision OR s.updated_at<>d.created_at OR s.learning_epoch<>j.learning_epoch
    OR s.choice->'learnConversation' IS DISTINCT FROM 'true'::jsonb OR s.choice->>'extractorProfile'<>j.profile_ref
    OR ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
     IS DISTINCT FROM ROW(j.application_revision,j.application_generation,j.subject_generation,j.policy_generation)
    THEN RAISE EXCEPTION 'candidate_current_learning'; END IF;
   PERFORM os_assert_knowledge_entry(p.entry_id,true);
  END IF;
 END IF;
END $$;
"""


def downgrade():
    raise RuntimeError("Protected selected-source restore requires the owned recovery procedure")
