"""Erase source-observer verification material with governed source cleanup."""
from alembic import op
revision="os_pg_0041"
down_revision="os_pg_0040"
branch_labels=None
depends_on=None


def upgrade():
    op.execute("ALTER TABLE personal_source_observations ALTER COLUMN request_digest DROP NOT NULL")
    op.execute("ALTER TABLE personal_source_observations ADD CONSTRAINT ck_source_observation_private CHECK (NOT active OR request_digest IS NOT NULL)")
    op.execute(GUARDS)

GUARDS = r"""
CREATE OR REPLACE FUNCTION os_personal_source_observation_current(sid uuid) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
DECLARE s personal_learning_sources%ROWTYPE; o personal_learning_source_origins%ROWTYPE;
 v personal_source_observations%ROWTYPE; app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 SELECT * INTO s FROM personal_learning_sources WHERE id=sid;
 SELECT * INTO o FROM personal_learning_source_origins WHERE source_id=sid;
 SELECT * INTO v FROM personal_source_observations WHERE source_id=sid;
 SELECT * INTO app FROM os_applications WHERE installation_id=s.installation_id AND id=s.application_id;
 SELECT * INTO owner FROM os_subjects WHERE installation_id=s.installation_id AND application_id=s.application_id
  AND tenant_id=s.tenant_id AND subject_id=s.subject_id;
 RETURN COALESCE(s.kind='accepted-outcome/1' AND s.state='AVAILABLE' AND s.envelope IS NOT NULL
  AND s.expires_at>clock_timestamp() AND o.id IS NOT NULL AND v.id IS NOT NULL AND v.request_digest IS NOT NULL
  AND v.active AND app.active AND owner.active AND v.artifact_id=o.artifact_id
  AND v.ciphertext_digest=o.ciphertext_digest
  AND v.checked_at>=clock_timestamp()-interval '3 seconds' AND v.checked_at<=clock_timestamp()+interval '1 second'
  AND v.valid_until>clock_timestamp()
  AND ROW(app.revision,app.generation,owner.generation,owner.host_policy_generation)
   =ROW(v.application_revision,v.application_generation,v.subject_generation,v.policy_generation),false);
END $$;
CREATE OR REPLACE FUNCTION os_guard_personal_source_observation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'personal_source_observation_retained'; END IF;
 IF TG_OP='UPDATE' THEN
  IF OLD.request_digest IS NOT NULL AND NEW.request_digest IS NULL AND NOT NEW.active
   AND (to_jsonb(NEW)-ARRAY['active','request_digest']) IS NOT DISTINCT FROM
       (to_jsonb(OLD)-ARRAY['active','request_digest'])
   AND EXISTS(SELECT 1 FROM personal_learning_sources WHERE id=NEW.source_id AND state='FORGOTTEN' AND envelope IS NULL)
  THEN RETURN NEW; END IF;
  IF ROW(NEW.id,NEW.installation_id,NEW.application_id,NEW.tenant_id,NEW.subject_id,NEW.source_id,
    NEW.artifact_id,NEW.ciphertext_digest,NEW.request_digest)
   IS DISTINCT FROM ROW(OLD.id,OLD.installation_id,OLD.application_id,OLD.tenant_id,OLD.subject_id,OLD.source_id,
    OLD.artifact_id,OLD.ciphertext_digest,OLD.request_digest)
  THEN RAISE EXCEPTION 'personal_source_observation_immutable'; END IF;
  -- A negative invalidation cannot grant authority and need not renew time.
  IF NOT NEW.active AND (to_jsonb(NEW)-'active') IS NOT DISTINCT FROM (to_jsonb(OLD)-'active') THEN RETURN NEW; END IF;
  IF NEW.checked_at<=OLD.checked_at THEN RAISE EXCEPTION 'personal_source_observation_order'; END IF;
 END IF;
 IF NEW.checked_at<clock_timestamp()-interval '3 seconds' OR NEW.checked_at>clock_timestamp()+interval '1 second'
  OR NEW.valid_until<=clock_timestamp()
 THEN RAISE EXCEPTION 'personal_source_observation_expired'; END IF;
 RETURN NEW;
END $$;
CREATE FUNCTION os_commit_personal_source_target() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM personal_knowledge_publications p
  JOIN personal_knowledge_candidate_sources e ON e.candidate_id=p.candidate_id
  JOIN personal_learning_sources s ON s.id=e.source_id
  WHERE p.revision_id=NEW.revision_id AND (s.state<>'AVAILABLE' OR s.revision<>e.source_revision
   OR s.expires_at<=clock_timestamp() OR NOT COALESCE(os_selected_learning_source_current(s.id),false)))
 THEN RAISE EXCEPTION 'personal_source_target_expired'; END IF;
 RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_personal_source_target AFTER INSERT ON personal_knowledge_supersessions
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_personal_source_target();
"""
