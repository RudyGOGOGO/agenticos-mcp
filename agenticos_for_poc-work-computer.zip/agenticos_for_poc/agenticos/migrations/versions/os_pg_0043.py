"""Registered encrypted contexts, typed memory bindings and current index fences."""
from alembic import op

revision = "os_pg_0043"
down_revision = "os_pg_0042"
branch_labels = None
depends_on = None

TABLES = r"""

CREATE TABLE owner_memory_contexts (
	id UUID NOT NULL,
	settings_id UUID NOT NULL,
	kind VARCHAR(16) NOT NULL,
	state VARCHAR(16) NOT NULL,
	version BIGINT NOT NULL,
	context_revision BIGINT NOT NULL,
	envelope JSONB,
	created_at TIMESTAMP WITH TIME ZONE NOT NULL,
	updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
	installation_id UUID NOT NULL,
	application_id UUID NOT NULL,
	tenant_id VARCHAR(256) NOT NULL,
	subject_id VARCHAR(256) NOT NULL,
	PRIMARY KEY (id),
	CONSTRAINT uq_owner_memory_context_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_personal_learning_settings_settings_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, settings_id) REFERENCES personal_learning_settings (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT ck_owner_memory_context_kind_state CHECK (kind IN ('context','claim-key') AND state IN ('ACTIVE','RETIRED','FORGOTTEN')),
	CONSTRAINT ck_owner_memory_context_version_time CHECK (version BETWEEN 1 AND 32 AND context_revision>1 AND updated_at>=created_at),
	CONSTRAINT ck_owner_memory_context_erasure CHECK ((state='FORGOTTEN')=(envelope IS NULL)),
	CONSTRAINT ck_owner_memory_context_envelope CHECK (envelope IS NULL OR COALESCE(envelope=jsonb_build_object('version',1,'keyId',envelope->'keyId','nonce',envelope->'nonce','ciphertext',envelope->'ciphertext') AND jsonb_typeof(envelope->'keyId')='string' AND envelope->>'keyId' ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' AND jsonb_typeof(envelope->'nonce')='string' AND length(envelope->>'nonce')=16 AND jsonb_typeof(envelope->'ciphertext')='string' AND length(envelope->>'ciphertext') BETWEEN 24 AND 2048,false))
);

CREATE TABLE owner_memory_context_commands (
	id UUID NOT NULL,
	settings_id UUID NOT NULL,
	context_id UUID NOT NULL,
	session_id UUID NOT NULL,
	command_id UUID NOT NULL,
	kind VARCHAR(16) NOT NULL,
	expected_version BIGINT NOT NULL,
	accepted_version BIGINT NOT NULL,
	context_revision BIGINT NOT NULL,
	request_mac VARCHAR(64),
	mac_key_id UUID,
	receipt JSONB NOT NULL,
	created_at TIMESTAMP WITH TIME ZONE NOT NULL,
	installation_id UUID NOT NULL,
	application_id UUID NOT NULL,
	tenant_id VARCHAR(256) NOT NULL,
	subject_id VARCHAR(256) NOT NULL,
	PRIMARY KEY (id),
	CONSTRAINT uq_owner_memory_context_command_owner_id UNIQUE (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_personal_learning_settings_settings_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, settings_id) REFERENCES personal_learning_settings (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_owner_memory_contexts_context_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, context_id) REFERENCES owner_memory_contexts (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_os_interactive_sessions_session_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, session_id) REFERENCES os_interactive_sessions (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT uq_owner_memory_context_command UNIQUE (installation_id, application_id, tenant_id, subject_id, command_id),
	CONSTRAINT uq_owner_memory_context_command_version UNIQUE (installation_id, application_id, tenant_id, subject_id, context_id, accepted_version),
	CONSTRAINT uq_owner_memory_context_command_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, context_revision),
	CONSTRAINT ck_owner_memory_context_command_kind CHECK (kind IN ('CREATE','RENAME','RETIRE')),
	CONSTRAINT ck_owner_memory_context_command_versions CHECK (expected_version BETWEEN 0 AND 31 AND accepted_version=expected_version+1 AND context_revision>1),
	CONSTRAINT ck_owner_memory_context_command_mac CHECK ((request_mac IS NULL AND mac_key_id IS NULL) OR (request_mac IS NOT NULL AND request_mac ~ '^[a-f0-9]{64}$' AND mac_key_id IS NOT NULL))
);

CREATE TABLE classified_knowledge_bindings (
	revision_id UUID NOT NULL,
	entry_id UUID NOT NULL,
	operation_id UUID NOT NULL,
	context_id UUID,
	claim_key_id UUID,
	lane VARCHAR(16) NOT NULL,
	content_kind VARCHAR(32) NOT NULL,
	language VARCHAR(8) NOT NULL,
	workflow_ref VARCHAR(64),
	tool_refs JSONB NOT NULL,
	created_at TIMESTAMP WITH TIME ZONE NOT NULL,
	installation_id UUID NOT NULL,
	application_id UUID NOT NULL,
	tenant_id VARCHAR(256) NOT NULL,
	subject_id VARCHAR(256) NOT NULL,
	PRIMARY KEY (revision_id),
	CONSTRAINT uq_classified_knowledge_revision UNIQUE (installation_id, application_id, tenant_id, subject_id, revision_id),
	CONSTRAINT fk_personal_knowledge_entries_entry_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id) REFERENCES personal_knowledge_entries (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_personal_knowledge_operations_operation_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, operation_id) REFERENCES personal_knowledge_operations (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_personal_knowledge_revisions_revision_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_owner_memory_contexts_context_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, context_id) REFERENCES owner_memory_contexts (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_owner_memory_contexts_claim_key_id FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, claim_key_id) REFERENCES owner_memory_contexts (installation_id, application_id, tenant_id, subject_id, id),
	CONSTRAINT fk_classified_knowledge_exact_revision FOREIGN KEY(installation_id, application_id, tenant_id, subject_id, entry_id, revision_id) REFERENCES personal_knowledge_revisions (installation_id, application_id, tenant_id, subject_id, entry_id, id) DEFERRABLE INITIALLY DEFERRED,
	CONSTRAINT ck_classified_knowledge_kind_lane CHECK (language='en' AND ((content_kind='preference' AND lane='preference') OR (content_kind IN ('personal-context','relationship-context') AND lane='semantic') OR (content_kind='episode' AND lane='episodic') OR (content_kind='procedure' AND lane='procedural'))),
	CONSTRAINT ck_classified_knowledge_claim_key CHECK ((content_kind IN ('preference','procedure'))=(claim_key_id IS NOT NULL)),
	CONSTRAINT ck_classified_knowledge_tools CHECK (jsonb_typeof(tool_refs)='array' AND CASE WHEN jsonb_typeof(tool_refs)='array' THEN jsonb_array_length(tool_refs) ELSE -1 END BETWEEN 0 AND 8 AND ((content_kind='procedure' AND workflow_ref='registered-tool-sequence/1' AND jsonb_array_length(tool_refs)>0) OR (content_kind<>'procedure' AND workflow_ref IS NULL AND tool_refs='[]'::jsonb)))
);
"""

GUARDS = r"""
CREATE FUNCTION os_classified_tools_current(rid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT CASE WHEN b.revision_id IS NULL OR b.content_kind<>'procedure' THEN true ELSE
  b.workflow_ref='registered-tool-sequence/1'
  AND jsonb_typeof(b.tool_refs)='array'
  AND jsonb_array_length(b.tool_refs) BETWEEN 1 AND 8
  AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(b.tool_refs) tool WHERE
   tool IS DISTINCT FROM jsonb_build_object('id',tool->'id','revision',tool->'revision')
   OR jsonb_typeof(tool->'id') IS DISTINCT FROM 'string'
   OR NOT COALESCE(tool->>'id' ~ '^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$',false)
   OR jsonb_typeof(tool->'revision') IS DISTINCT FROM 'number'
   OR NOT COALESCE(tool->>'revision' ~ '^[1-9][0-9]{0,15}$',false)
   OR NOT EXISTS(SELECT 1 FROM os_applications app JOIN os_registrations reg
    ON reg.installation_id=app.installation_id AND reg.application_id=app.id AND reg.revision=app.revision,
    jsonb_array_elements(reg.payload->'capabilities') capability
    WHERE app.installation_id=e.installation_id AND app.id=e.application_id AND app.active
     AND reg.generation=app.generation
     AND capability->'descriptor'->'id'=tool->'id'
     AND capability->'descriptor'->'revision'=tool->'revision'
     AND capability->'descriptor'->>'kind'='read')) END
 FROM personal_knowledge_revisions r JOIN personal_knowledge_entries e ON e.id=r.entry_id
 LEFT JOIN classified_knowledge_bindings b ON b.revision_id=r.id WHERE r.id=rid
$$;
CREATE OR REPLACE FUNCTION os_personal_index_eligible(eid uuid) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT COALESCE(e.state='ACTIVE' AND (e.valid_until IS NULL OR e.valid_until>clock_timestamp())
  AND r.envelope IS NOT NULL AND os_revision_sources_current(r.id)
  AND (b.revision_id IS NULL OR ((b.context_id IS NULL OR EXISTS(SELECT 1 FROM owner_memory_contexts c
   WHERE c.id=b.context_id AND c.kind='context' AND c.state='ACTIVE'))
   AND (b.claim_key_id IS NULL OR EXISTS(SELECT 1 FROM owner_memory_contexts c
    WHERE c.id=b.claim_key_id AND c.kind='claim-key' AND c.state='ACTIVE'))))
  AND os_classified_tools_current(r.id),false)
 FROM personal_knowledge_entries e JOIN personal_knowledge_revisions r ON r.id=e.active_revision_id
 LEFT JOIN classified_knowledge_bindings b ON b.revision_id=r.id WHERE e.id=eid
$$;

CREATE FUNCTION os_assert_owner_memory_context(cid uuid, live boolean) RETURNS void LANGUAGE plpgsql AS $$
DECLARE c owner_memory_contexts%ROWTYPE; m owner_memory_context_commands%ROWTYPE;
 s personal_learning_settings%ROWTYPE; session os_interactive_sessions%ROWTYPE;
 app os_applications%ROWTYPE; owner os_subjects%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO c FROM owner_memory_contexts WHERE id=cid;
 SELECT * INTO s FROM personal_learning_settings WHERE id=c.settings_id;
 SELECT * INTO m FROM owner_memory_context_commands WHERE context_id=c.id AND accepted_version=c.version;
 IF c.id IS NULL OR s.id IS NULL OR m.id IS NULL OR m.settings_id<>s.id
  OR m.context_revision<>c.context_revision OR m.created_at<>c.updated_at OR c.context_revision>s.context_revision
  OR m.receipt IS DISTINCT FROM jsonb_build_object('commandId',m.command_id,'contextRevision',m.context_revision,
    'contextId',c.id,'revision',c.version,'kind',c.kind,'state',c.state)
  OR (c.version=1 AND m.kind<>'CREATE') OR (c.version>1 AND m.kind='CREATE')
  OR (c.state='RETIRED')<>(m.kind='RETIRE') OR c.state='FORGOTTEN'
 THEN RAISE EXCEPTION 'memory_context_atomic_receipt';END IF;
 IF live THEN
  IF s.context_revision<>c.context_revision OR s.updated_at<>c.updated_at OR m.request_mac IS NULL
   THEN RAISE EXCEPTION 'memory_context_atomic_revision';END IF;
  SELECT * INTO session FROM os_interactive_sessions WHERE id=m.session_id;
  SELECT * INTO app FROM os_applications WHERE installation_id=c.installation_id AND id=c.application_id;
  SELECT * INTO owner FROM os_subjects WHERE installation_id=c.installation_id AND application_id=c.application_id
   AND tenant_id=c.tenant_id AND subject_id=c.subject_id;
  IF session.id IS NULL OR session.revoked OR session.expires_at<=clock_timestamp()
   OR ROW(session.installation_id,session.application_id,session.tenant_id,session.subject_id)
    IS DISTINCT FROM ROW(c.installation_id,c.application_id,c.tenant_id,c.subject_id)
   OR app.id IS NULL OR NOT app.active OR app.generation<>session.application_generation
   OR owner.id IS NULL OR NOT owner.active OR owner.generation<>session.subject_generation
   THEN RAISE EXCEPTION 'memory_context_current_owner';END IF;
 END IF;
END $$;
CREATE FUNCTION os_guard_owner_memory_context() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s personal_learning_settings%ROWTYPE; total bigint; active bigint;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'memory_context_retained';END IF;
 SELECT * INTO s FROM personal_learning_settings WHERE id=NEW.settings_id FOR UPDATE;
 IF s.id IS NULL THEN RAISE EXCEPTION 'memory_context_settings';END IF;
 IF NEW.context_revision<>s.context_revision+1 THEN RAISE EXCEPTION 'memory_context_next_revision';END IF;
 IF TG_OP='INSERT' THEN
  SELECT count(*),count(*) FILTER(WHERE kind=NEW.kind AND state='ACTIVE') INTO total,active
   FROM owner_memory_contexts WHERE settings_id=s.id;
  IF total>=64 OR active>=(CASE WHEN NEW.kind='context' THEN 16 ELSE 32 END)
   OR NEW.state<>'ACTIVE' OR NEW.version<>1 OR NEW.created_at<>NEW.updated_at
   THEN RAISE EXCEPTION 'memory_context_initial_bound';END IF;
 ELSE
  IF OLD.state<>'ACTIVE' OR NEW.version<>OLD.version+1 OR NEW.updated_at<OLD.updated_at
   OR NEW.context_revision<>s.context_revision+1 OR NEW.state NOT IN ('ACTIVE','RETIRED')
   OR (to_jsonb(NEW)-ARRAY['state','version','context_revision','envelope','updated_at']) IS DISTINCT FROM
      (to_jsonb(OLD)-ARRAY['state','version','context_revision','envelope','updated_at'])
   OR (NEW.state='RETIRED' AND NEW.envelope IS DISTINCT FROM OLD.envelope)
   THEN RAISE EXCEPTION 'memory_context_transition';END IF;
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER guard_owner_memory_context BEFORE INSERT OR UPDATE OR DELETE ON owner_memory_contexts
 FOR EACH ROW EXECUTE FUNCTION os_guard_owner_memory_context();
CREATE FUNCTION os_commit_owner_memory_context() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid; m owner_memory_context_commands%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='owner_memory_contexts' THEN
  cid=NEW.id;
  SELECT * INTO m FROM owner_memory_context_commands WHERE context_id=cid AND accepted_version=NEW.version;
  IF TG_OP='UPDATE' AND m.kind IS DISTINCT FROM (CASE WHEN NEW.state='RETIRED' THEN 'RETIRE' ELSE 'RENAME' END)
   THEN RAISE EXCEPTION 'memory_context_transition_receipt';END IF;
 ELSE
  cid=NEW.context_id;
  IF NEW.accepted_version<>(SELECT version FROM owner_memory_contexts WHERE id=cid)
   THEN RAISE EXCEPTION 'memory_context_command_version';END IF;
 END IF;
 PERFORM os_assert_owner_memory_context(cid,true);RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_owner_memory_context AFTER INSERT OR UPDATE ON owner_memory_contexts
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_owner_memory_context();
CREATE CONSTRAINT TRIGGER commit_owner_memory_context_command AFTER INSERT ON owner_memory_context_commands
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_owner_memory_context();
CREATE FUNCTION os_guard_classified_knowledge_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'classified_memory_receipt_retained';END $$;
CREATE TRIGGER guard_owner_memory_context_command BEFORE UPDATE OR DELETE ON owner_memory_context_commands
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE TRIGGER guard_classified_knowledge_binding BEFORE UPDATE OR DELETE ON classified_knowledge_bindings
 FOR EACH ROW EXECUTE FUNCTION os_guard_classified_knowledge_immutable();
CREATE FUNCTION os_commit_classified_knowledge_binding() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE e personal_knowledge_entries%ROWTYPE; r personal_knowledge_revisions%ROWTYPE;
 o personal_knowledge_operations%ROWTYPE; s personal_learning_settings%ROWTYPE;
 context owner_memory_contexts%ROWTYPE; claim owner_memory_contexts%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true);PERFORM set_config('statement_timeout','3s',true);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=NEW.entry_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=e.settings_id FOR UPDATE;
 SELECT * INTO r FROM personal_knowledge_revisions WHERE id=NEW.revision_id;
 SELECT * INTO o FROM personal_knowledge_operations WHERE id=NEW.operation_id;
 IF e.id IS NULL OR r.id IS NULL OR o.id IS NULL OR s.id IS NULL OR e.state<>'ACTIVE'
  OR r.operation_id<>o.id OR r.entry_id<>e.id OR o.entry_id<>e.id OR o.kind NOT IN ('SAVE','REVISE')
  OR e.active_revision_id<>r.id OR o.accepted_version<>e.version OR o.context_revision<>s.context_revision
  OR NEW.created_at<>r.created_at OR r.envelope IS NULL
  THEN RAISE EXCEPTION 'classified_memory_exact_revision';END IF;
 IF NEW.context_id IS NOT NULL THEN
  SELECT * INTO context FROM owner_memory_contexts WHERE id=NEW.context_id;
  IF context.id IS NULL OR context.kind<>'context' OR context.state<>'ACTIVE'
   THEN RAISE EXCEPTION 'classified_memory_registered_context';END IF;
 END IF;
 IF NEW.claim_key_id IS NOT NULL THEN
  SELECT * INTO claim FROM owner_memory_contexts WHERE id=NEW.claim_key_id;
  IF claim.id IS NULL OR claim.kind<>'claim-key' OR claim.state<>'ACTIVE'
   THEN RAISE EXCEPTION 'classified_memory_registered_claim';END IF;
 END IF;
 IF NOT COALESCE(os_classified_tools_current(r.id),false) THEN RAISE EXCEPTION 'classified_memory_registered_tools';END IF;
 PERFORM os_assert_knowledge_entry(e.id,true);RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER commit_classified_knowledge_binding AFTER INSERT ON classified_knowledge_bindings
 DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION os_commit_classified_knowledge_binding();

CREATE OR REPLACE FUNCTION os_guard_knowledge_commit() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE eid uuid; live boolean; e personal_knowledge_entries%ROWTYPE; c personal_knowledge_operations%ROWTYPE; m owner_memory_context_commands%ROWTYPE;
BEGIN
 IF TG_TABLE_NAME='personal_learning_settings' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE settings_id=NEW.id AND context_revision=NEW.context_revision;
  SELECT * INTO m FROM owner_memory_context_commands WHERE settings_id=NEW.id AND context_revision=NEW.context_revision;
  IF (c.id IS NULL)=(m.id IS NULL) THEN RAISE EXCEPTION 'memory_context_exact_receipt';END IF;
  IF m.id IS NOT NULL THEN PERFORM os_assert_owner_memory_context(m.context_id,true);RETURN NULL;END IF;
  IF c.id IS NULL THEN RAISE EXCEPTION 'knowledge_context_receipt'; END IF;
  eid=c.entry_id; live=true;
 ELSIF TG_TABLE_NAME='personal_knowledge_entries' THEN
  eid=NEW.id; live=(TG_OP='INSERT');
  IF TG_OP='UPDATE' THEN live=NEW.version<>OLD.version; END IF;
  IF live THEN
   SELECT * INTO c FROM personal_knowledge_operations WHERE entry_id=eid AND accepted_version=NEW.version;
   IF TG_OP='INSERT' THEN
    IF c.kind IS DISTINCT FROM 'SAVE' THEN RAISE EXCEPTION 'knowledge_save_operation'; END IF;
   ELSE
    IF c.kind IS DISTINCT FROM (CASE WHEN NEW.active_revision_id<>OLD.active_revision_id THEN 'REVISE'
     WHEN NEW.state='FORGOTTEN' THEN 'FORGET' WHEN NEW.state='PAUSED' THEN 'PAUSE' ELSE 'RESUME' END)
     THEN RAISE EXCEPTION 'knowledge_transition_operation'; END IF;
   END IF;
  END IF;
 ELSE
  eid=NEW.entry_id; live=(TG_OP='INSERT');
  -- PL/pgSQL resolves record fields when preparing an expression, even if
  -- another operand in that expression would make an AND condition false.
  IF TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
   IF TG_OP='UPDATE' AND NEW.state='CANCELLED' THEN RETURN NULL; END IF;
  END IF;
 END IF;
 PERFORM os_assert_knowledge_entry(eid,live);
 SELECT * INTO e FROM personal_knowledge_entries WHERE id=eid;
 IF NOT live AND TG_TABLE_NAME IN ('personal_knowledge_revisions','personal_knowledge_operations','personal_forget_journal')
  AND e.projection_state<>'PURGED' THEN RAISE EXCEPTION 'knowledge_cleanup_incomplete'; END IF;
 IF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_revisions' THEN
  SELECT * INTO c FROM personal_knowledge_operations WHERE id=NEW.operation_id;
  IF NEW.id<>e.active_revision_id OR NEW.envelope IS NULL OR c.kind NOT IN ('SAVE','REVISE')
   OR c.accepted_version<>e.version OR NEW.created_at<>c.created_at
   THEN RAISE EXCEPTION 'knowledge_revision_binding'; END IF;
 ELSIF TG_OP='INSERT' AND TG_TABLE_NAME='personal_knowledge_projection_jobs' THEN
  IF NEW.entry_version<>e.version OR NEW.revision_id<>e.active_revision_id THEN RAISE EXCEPTION 'knowledge_job_binding'; END IF;
 END IF;
 RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION os_guard_personal_index_attempt() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE b classified_knowledge_bindings%ROWTYPE; g personal_index_generations%ROWTYPE; s personal_learning_settings%ROWTYPE; e personal_knowledge_entries%ROWTYPE;
BEGIN
 PERFORM set_config('lock_timeout','2s',true); PERFORM set_config('statement_timeout','3s',true);
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'personal_index_attempt_retained'; END IF;
 SELECT * INTO g FROM personal_index_generations WHERE id=NEW.generation_id;
 SELECT * INTO s FROM personal_learning_settings WHERE id=g.settings_id FOR UPDATE;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'RUNNING' OR NEW.completed_at IS NOT NULL OR NEW.created_at<>g.created_at
   OR NEW.lease_until<>NEW.created_at+interval '120 seconds'
   OR ROW(NEW.recall_epoch,NEW.context_revision) IS DISTINCT FROM ROW(g.recall_epoch,g.context_revision)
   OR NOT EXISTS(SELECT 1 FROM personal_index_members m WHERE m.generation_id=g.id AND m.entry_id=NEW.entry_id
    AND m.revision_id=NEW.revision_id AND m.entry_version=NEW.entry_version)
   THEN RAISE EXCEPTION 'personal_index_attempt_binding'; END IF;
 ELSE
  IF OLD.state<>'RUNNING' OR NEW.state='RUNNING' OR (to_jsonb(NEW)-ARRAY['state','completed_at']) IS DISTINCT FROM
    (to_jsonb(OLD)-ARRAY['state','completed_at']) THEN RAISE EXCEPTION 'personal_index_attempt_transition'; END IF;
 END IF;
 IF TG_OP='INSERT' OR NEW.state='READY' THEN
  PERFORM os_personal_index_owner(g.id);
  SELECT * INTO e FROM personal_knowledge_entries WHERE id=NEW.entry_id;
  IF g.state<>'BUILDING' OR NEW.lease_until<=clock_timestamp()
   OR ROW(g.settings_version,g.learning_epoch,g.recall_epoch,g.context_revision,g.profile_ref)
    IS DISTINCT FROM ROW(s.version,s.learning_epoch,s.recall_epoch,s.context_revision,s.choice->>'embeddingProfile')
   OR NOT COALESCE(os_personal_index_eligible(e.id),false)
   OR ROW(NEW.revision_id,NEW.entry_version) IS DISTINCT FROM ROW(e.active_revision_id,e.version)
   THEN RAISE EXCEPTION 'personal_index_attempt_obsolete'; END IF;
 END IF;
 SELECT * INTO b FROM classified_knowledge_bindings WHERE revision_id=NEW.revision_id;
 IF b.revision_id IS NOT NULL THEN
  IF ROW(NEW.lane,NEW.context_ref) IS DISTINCT FROM ROW(b.lane,CASE WHEN b.context_id IS NULL THEN 'general/1' ELSE 'context/'||b.context_id::text||'/1' END)
   THEN RAISE EXCEPTION 'classified_memory_projection_metadata';END IF;
 ELSIF NEW.context_ref<>'general/1' THEN RAISE EXCEPTION 'classified_memory_missing_binding';END IF;
 RETURN NEW;
END $$;
"""

def upgrade():
    op.execute(TABLES)
    op.execute(GUARDS)

def downgrade():
    raise RuntimeError("Use the protected additive recovery plan; populated memory is retained")
