"""Draft RDS-exact keyword projections with no fabricated embedding vector."""
from alembic import op

revision='os_rds_store_0002'
down_revision='os_rds_store_0001'
branch_labels=None
depends_on=None


def selected():
    config=op.get_context().config
    if config.attributes.get('storage_profile')!='aws-rds-postgres16-vector082-exact/1':
        raise RuntimeError('Explicit RDS exact storage profile required')
    return config.attributes['component']=='retrieval'

def upgrade():
    if selected():op.execute(r"""ALTER TABLE personal_knowledge_vectors ALTER COLUMN embedding DROP NOT NULL;
ALTER TABLE personal_knowledge_vectors DROP CONSTRAINT ck_personal_vector_profile;
ALTER TABLE personal_knowledge_vectors ADD CONSTRAINT ck_personal_vector_profile CHECK (profile_ref IN ('minilm-english-onnx/1','keyword-fts/1'));
ALTER TABLE personal_knowledge_vectors DROP CONSTRAINT ck_personal_vector_normalization;
ALTER TABLE personal_knowledge_vectors ADD CONSTRAINT ck_personal_vector_normalization CHECK ((profile_ref='minilm-english-onnx/1' AND embedding IS NOT NULL AND vector_dims(embedding)=384 AND abs(vector_norm(embedding)-1)<0.00001) OR (profile_ref='keyword-fts/1' AND embedding IS NULL));""")

def downgrade():
    if selected():op.execute(r"""DO $$ BEGIN IF EXISTS(SELECT 1 FROM personal_knowledge_vectors WHERE profile_ref<>'minilm-english-onnx/1' OR embedding IS NULL)
 THEN RAISE EXCEPTION 'keyword_retrieval_downgrade_refused'; END IF; END $$;
ALTER TABLE personal_knowledge_vectors DROP CONSTRAINT ck_personal_vector_profile;
ALTER TABLE personal_knowledge_vectors ADD CONSTRAINT ck_personal_vector_profile CHECK (profile_ref='minilm-english-onnx/1');
ALTER TABLE personal_knowledge_vectors DROP CONSTRAINT ck_personal_vector_normalization;
ALTER TABLE personal_knowledge_vectors ADD CONSTRAINT ck_personal_vector_normalization CHECK (vector_dims(embedding)=384 AND abs(vector_norm(embedding)-1)<0.00001);
ALTER TABLE personal_knowledge_vectors ALTER COLUMN embedding SET NOT NULL;""")
