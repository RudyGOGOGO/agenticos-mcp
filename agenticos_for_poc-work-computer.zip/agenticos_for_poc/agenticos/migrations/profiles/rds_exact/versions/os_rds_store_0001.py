"""RDS pgvector0.8.2 exact retrieval: remove unsafe optional ANN physical path.

Applied after the immutable component lineage in the same fresh-install
transaction, before any runtime writes. No extension downgrade or adoption.
"""
from alembic import op

revision='os_rds_store_0001'
down_revision='os_store_0004'
branch_labels=None
depends_on=None


def upgrade():
    config=op.get_context().config
    if config.attributes.get('storage_profile')!='aws-rds-postgres16-vector082-exact/1':
        raise RuntimeError('Explicit RDS exact storage profile required')
    if config.attributes['component']=='retrieval':op.drop_index('ix_personal_vector_hnsw',table_name='personal_knowledge_vectors')


def downgrade():
    raise RuntimeError('No automatic downgrade to an unsafe ANN catalog')
