"""Migrations require a supplied, already ownership-validated connection."""
from alembic import context
from agentic_os.adapters.postgres.models import Base
from agentic_os.adapters.postgres.migrate import bind_source_revisions

connection = context.config.attributes.get("connection")
if connection is None or context.is_offline_mode():
    raise RuntimeError("OS migrations require an explicit validated live connection")
context.configure(connection=connection, target_metadata=Base.metadata,
                  compare_type=True, compare_server_default=True)
bind_source_revisions(context.get_context().script,context.config.get_main_option('script_location'))
with context.begin_transaction():
    context.run_migrations()
