"""Trusted Linux placement process; guest text never proves cleanup or usage.

Only an explicit root-owned installation invokes this file. No shell commands,
network configuration, host mounts, API server or guest-originated service exist.
The original attempt names the exclusive jail/cgroup; recovery never starts it.
"""
import base64
import json
import os
from pathlib import Path
import selectors
import shutil
import stat
import subprocess
import sys
import time
from uuid import UUID


def emit(value):
    sys.stdout.write(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n');sys.stdout.flush()


def location():
    root=Path(os.environ['AOS_FIRECRACKER_ROOT']);ident=os.environ['AOS_ATTEMPT_ID']
    installation=os.environ['AOS_INSTALLATION_ID'];owner=os.environ['AOS_FIRECRACKER_RUN_ID']
    if (os.geteuid()!=0 or not root.is_absolute() or root.resolve()!=root
            or any(str(UUID(value))!=value for value in (ident,installation,owner))):raise ValueError()
    info=root.stat()
    if info.st_uid!=0 or info.st_mode&0o077:raise ValueError()
    name='aos-n-'+ident.replace('-','')
    return root,name,root/'home'/'jails'/'runtime'/name,Path('/sys/fs/cgroup/agentic-os')/installation/owner/name


def private_dir(path,uid=0):
    info=path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid!=uid or info.st_mode&0o022 or path.resolve()!=path:
        raise ValueError()


def pids(group):
    private_dir(group)
    values=(group/'cgroup.procs').read_text().split()
    if len(values)>64 or any(not x.isdigit() or int(x)<1 for x in values):raise ValueError()
    return list(map(int,values))


def cleanup(root,name,jail,group):
    # The original exclusive cgroup is stronger than a reusable PID. Kill
    # only this group, including a VM whose create ACK was lost.
    if group.exists():
        private_dir(group);(group/'cgroup.kill').write_text('1')
        until=time.monotonic()+2
        while 'populated 1' in (group/'cgroup.events').read_text():
            if time.monotonic()>=until:raise TimeoutError()
            time.sleep(.01)
        if pids(group):raise ValueError()
        group.rmdir()
    if jail.exists() or jail.is_symlink():
        private_dir(jail)
        # Do not follow a foreign mount or a replaced parent during teardown.
        device=jail.stat().st_dev
        for directory,children,names in os.walk(jail,followlinks=False):
            for entry in children+names:
                path=Path(directory)/entry;info=path.lstat()
                if info.st_dev!=device or stat.S_ISLNK(info.st_mode):raise ValueError()
        shutil.rmtree(jail)
    if jail.exists() or group.exists():raise ValueError()


def inspect(root,name,jail,group):
    values=pids(group);uid=int(os.environ['AOS_FIRECRACKER_UID'])
    candidates=[]
    for pid in values:
        try:
            exe=os.readlink('/proc/'+str(pid)+'/exe')
            status=Path('/proc/'+str(pid)+'/status').read_text()
        except FileNotFoundError:continue
        if exe not in {'/runtime',str(jail/'root'/'runtime')}:
            # The jailer has not exec-ed yet; admission must wait for its
            # independent executable/credential/seccomp observation.
            continue
        lines=dict(line.split(':',1) for line in status.splitlines() if ':' in line)
        if (list(map(int,lines['Uid'].split()))!=[uid]*4 or lines['Seccomp'].strip()!='2'):
            raise ValueError()
        candidates.append(pid)
    if len(candidates)!=1:raise ValueError()
    return dict(name=name,id='local:'+str(candidates[0]),status='Running')


def analysis(root,name,jail,group):
    if jail.exists() or jail.is_symlink() or group.exists():raise ValueError()
    parent=group.parent;private_dir(parent)
    if not {'cpu','memory','pids'}<=set((parent/'cgroup.subtree_control').read_text().split()):raise ValueError()
    group.mkdir(mode=0o700)
    uid=int(os.environ['AOS_FIRECRACKER_UID']);gid=int(os.environ['AOS_FIRECRACKER_GID'])
    if uid<1 or gid<1:raise ValueError()
    # Persist physical identities before launch. Core's NativeOwner already
    # persisted its original immutable attempt before invoking this process.
    jail.mkdir(mode=0o700,parents=True);guest=jail/'root';guest.mkdir(mode=0o700)
    for source,target in [('kernel','kernel'),('rootfs.ext4','rootfs.ext4')]:
        shutil.copyfile(root/source,guest/target);(guest/target).chmod(0o444)
    config={'boot-source':{'kernel_image_path':'/kernel',
        'boot_args':'console=ttyS0 quiet loglevel=1 reboot=k panic=1 root=/dev/vda ro init=/init'},
        'drives':[{'drive_id':'rootfs','path_on_host':'/rootfs.ext4','is_root_device':True,'is_read_only':True}],
        'machine-config':{'vcpu_count':1,'mem_size_mib':1024,'smt':False},'network-interfaces':[]}
    (guest/'config.json').write_text(json.dumps(config));(guest/'config.json').chmod(0o444)
    # The executable remains default-seccomp, jailed and unprivileged. The
    # cgroup caps host memory, task count and one CPU independently of guest.
    command=[str(root/'jailer'),'--id',name,'--exec-file',str(root/'runtime'),
        '--uid',str(uid),'--gid',str(gid),'--chroot-base-dir',str(root/'home'/'jails'),
        '--cgroup-version','2','--parent-cgroup',str(group.parent.relative_to('/sys/fs/cgroup')),
        '--cgroup','memory.max=1610612736','--cgroup','pids.max=64',
        '--cgroup','cpu.max=100000 100000','--resource-limit','no-file=64',
        '--','--no-api','--config-file','/config.json']
    child=None;selector=selectors.DefaultSelector();ready=False;finished=False;allocated=False
    serial=bytearray();input_buffer=bytearray();outgoing=bytearray();started=time.monotonic();wire=0
    written=0;received=0;frames=0;input_sequence=-1
    try:
        child=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
            env={'PATH':'/usr/bin:/bin'},close_fds=True)
        for stream in (child.stdin,child.stdout,sys.stdin.buffer):os.set_blocking(stream.fileno(),False)
        selector.register(child.stdout,selectors.EVENT_READ,'guest')
        selector.register(sys.stdin.buffer,selectors.EVENT_READ,'input')
        while child.poll() is None or not finished:
            if time.monotonic()-started>=29:raise TimeoutError()
            if not allocated:
                try:observation=inspect(root,name,jail,group)
                except ValueError:
                    if child.poll() is not None:raise
                else:
                    emit(dict(event='created',name=name,placementId=observation['id']));allocated=True
            if ready and outgoing and (jail/'allocation-observed').exists():
                try:
                    count=os.write(child.stdin.fileno(),outgoing[:65536]);del outgoing[:count];written+=count
                except BlockingIOError:pass
            for key,_ in selector.select(.005):
                if key.data=='input':
                    raw=os.read(key.fd,65536)
                    if not raw:selector.unregister(key.fileobj);continue
                    wire+=len(raw)
                    if wire>8*1024**2:raise ValueError()
                    input_buffer.extend(raw)
                    while b'\n' in input_buffer:
                        line,_,rest=input_buffer.partition(b'\n');input_buffer=bytearray(rest)
                        if len(line)>65536:raise ValueError()
                        packet=json.loads(line)
                        if type(packet) is not dict or set(packet)!={'input'}:raise ValueError()
                        outgoing.extend(base64.b64decode(packet['input'],validate=True))
                    if len(input_buffer)>65536:raise ValueError()
                else:
                    raw=os.read(key.fd,65536)
                    if not raw:
                        selector.unregister(key.fileobj)
                        if not finished:raise ValueError()
                        continue
                    received+=len(raw);serial.extend(raw)
                    while b'\n' in serial:
                        line,_,rest=serial.partition(b'\n');serial=bytearray(rest);line=line.rstrip(b'\r')
                        if len(line)>65536:raise ValueError()
                        if not ready:
                            if line==b'AOS_ANALYSIS_READY':ready=True
                            continue
                        # AnalysisOutput in the parent validates every frame,
                        # sequence, binding and output limit independently.
                        frame=json.loads(line);frames+=1
                        if finished:raise ValueError()
                        if type(frame) is dict and frame.get('op')=='input-progress':
                            if (set(frame)!={'op','sequence'} or type(frame['sequence']) is not int
                                    or frame['sequence']!=input_sequence+1 or frame['sequence']>8*1024**2):raise ValueError()
                            input_sequence=frame['sequence'];continue
                        emit(dict(event='stdout',data=base64.b64encode(line+b'\n').decode()))
                        if type(frame) is dict and frame.get('op')=='result':
                            finished=True;emit(dict(event='done'))
                    if len(serial)>65536:raise ValueError()
            if finished:break
        if not finished or not allocated:raise ValueError()
    finally:
        selector.close()
        if child is not None:
            if child.poll() is None:child.kill()
            child.wait(timeout=2)
        # Diagnostics must never prevent physical process cleanup. Fixed
        # bounded counters only; no guest bytes, programs or exception text.
        try:
            sys.stderr.write(json.dumps(dict(schema='firecracker-transfer/1',ready=ready,
                allocated=allocated,finished=finished,wireBytes=wire,writtenBytes=written,
                pendingBytes=len(outgoing),serialBytes=received,frames=frames,
                partialSerialBytes=len(serial),inputPackets=input_sequence+1))+'\n');sys.stderr.flush()
        except OSError:pass
        # Keep the exact backing/cgroup until NativeOwner's cleanup command.
        # This retains physical identity through a lost completion ACK.


def main():
    root,name,jail,group=location();operation=sys.argv[1]
    if operation=='analysis':analysis(root,name,jail,group)
    elif operation=='inspect':
        observation=inspect(root,name,jail,group)
        (jail/'allocation-observed').touch(mode=0o600,exist_ok=True)
        emit(observation)
    elif operation=='reconcile':
        existed=jail.exists() or group.exists()
        placement=os.environ.get('AOS_PLACEMENT_ID','')
        if existed and not placement:
            try:placement=inspect(root,name,jail,group)['id']
            except (ValueError,FileNotFoundError):pass
        cleanup(root,name,jail,group)
        # A lost create ACK may leave no truthful PID observation. Preserve
        # UNKNOWN instead of fabricating a physical allocation identity.
        if existed and not placement:raise ValueError()
        emit(dict(event='reconciled' if existed else 'absent-record',name=name,id=placement))
    else:raise ValueError()


if __name__=='__main__':
    try:main()
    except BaseException:raise SystemExit(2) from None
