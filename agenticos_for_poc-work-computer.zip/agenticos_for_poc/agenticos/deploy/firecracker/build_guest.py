"""Build the offline image from an operator-pinned Linux Python base.

No downloads, package installs or mounted images. Source inventory is emitted
beside the artifact; the operator must pin the completed image in the sandbox
installation. Run only in a fresh owned build directory on authorized storage.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import sysconfig


def build(output,runtime,init):
    if (platform.system()!='Linux' or os.geteuid()!=0 or sys.version_info[:2]!=(3,12)
            or not output.is_absolute() or output.resolve()!=output or output.exists()
            or not runtime.is_file() or not init.is_file()):raise ValueError('Fresh root Linux Python3.12 build required')
    # The outer build directory is private. The filesystem's root must be
    # traversable by the unprivileged guest runtime after dropping UID/GID.
    output.mkdir(mode=0o700);root=output/'tree';root.mkdir(mode=0o755)
    for name in ('bin','dev','proc','sys','tmp','usr/bin','usr/lib'):(root/name).mkdir(parents=True,exist_ok=True)
    inventory={}
    def copy(source,target):
        source=source.resolve(strict=True);target=root/target
        if target.exists():return
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        target.chmod(0o755 if os.access(source,os.X_OK) else 0o644)
        inventory[str(source)]=hashlib.sha256(source.read_bytes()).hexdigest()
    def libraries(source):
        value=subprocess.run(['/usr/bin/ldd',str(source)],check=True,capture_output=True,text=True,timeout=10).stdout
        for path in re.findall(r'(?:^|\s)(/[^\s]+)',value):
            copy(Path(path),path.lstrip('/'))
            # Relocated /usr/bin/python retains its origin-relative lib
            # search path. Official Python images install libpython under
            # /usr/local/lib, unlike distribution /usr/bin builds.
            if Path(path).name.startswith('libpython3.12'):
                copy(Path(path),'usr/lib/'+Path(path).name)
    copy(Path('/bin/busybox'),'bin/busybox')
    python=Path(sys.executable).resolve(strict=True);copy(python,'usr/bin/python3.12');libraries(python)
    stdlib=Path(sysconfig.get_path('stdlib')).resolve(strict=True)
    for directory,children,names in os.walk(stdlib):
        children[:]=[x for x in sorted(children) if x not in {'__pycache__','test','tests','idlelib','tkinter','ensurepip','site-packages','dist-packages'}]
        for name in sorted(names):
            source=Path(directory)/name
            if source.is_file():
                copy(source,'usr/lib/python3.12/'+str(source.relative_to(stdlib)))
                if source.suffix=='.so':libraries(source)
    copy(runtime,'analysis_runtime.py');copy(init,'init');(root/'init').chmod(0o755)
    # Fixed trusted build smoke only: prove the relocated loader/stdlib works
    # as the guest UID before producing ext4. This neither runs model code nor
    # substitutes chroot for the mandatory Firecracker/KVM containment gates.
    smoke="import sys,json,resource,math,hashlib,decimal,statistics,select; assert sys.prefix=='/usr'; assert math.isclose(statistics.mean([2,4]),3); print('guest_stdlib_passed')"
    result=subprocess.run(['/usr/sbin/chroot','--userspec=65534:65534',str(root),
        '/usr/bin/python3.12','-I','-B','-c',smoke],check=True,capture_output=True,text=True,timeout=15,
        env={'PATH':'/usr/sbin:/usr/bin:/bin','LANG':'C.UTF-8'})
    if result.stdout.strip()!='guest_stdlib_passed':raise ValueError('Relocated guest Python prerequisites failed')
    image=output/'rootfs.ext4'
    with image.open('xb') as target:target.truncate(512*1024**2)
    # A fresh ext4 contains only the allowlisted root above, without developer
    # homes, package caches, credentials, sockets or external dependencies.
    subprocess.run(['/usr/sbin/mkfs.ext4','-F','-q','-d',str(root),str(image)],check=True,timeout=90)
    image.chmod(0o400)
    manifest=dict(version=1,architecture=platform.machine(),python=sys.version,
        pythonSource=str(python),stdlibSource=str(stdlib),actualRelocatedUnprivilegedStdlibSmoke=True,
        image=dict(bytes=image.stat().st_size,sha256=hashlib.file_digest(image.open('rb'),'sha256').hexdigest()),
        sources=inventory,network='none',temporaryMiB=8,guestWallSeconds=25)
    (output/'build.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--analysis-runtime',type=Path,required=True)
    args=parser.parse_args()
    result=build(args.output,args.analysis_runtime,Path(__file__).with_name('guest-init'))
    print(json.dumps(dict(image=result['image'],architecture=result['architecture'])))
