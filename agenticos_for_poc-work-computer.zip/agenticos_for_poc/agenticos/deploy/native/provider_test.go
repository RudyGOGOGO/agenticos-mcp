package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// Selected fields from an observed 0.7.6 persisted configuration. Recovery
// must reject weakened settings even when the allocation labels still match.
const persisted = `{"labels":{"attempt":"owned","io.agentic-os.profile":"core-codex-stdio/1"},"image":{"Oci":{"reference":"docker.io/library/python@sha256:54c85f3c47607a77f32adec749d3c81d1348bf25833671f512b26a9b6d778cb3","root_disk":{"kind":"managed","size_mib":512}}},"pull_policy":"Never","manifest_digest":"sha256:349275ed26e7aea20752e1fd63c40c30a0281d324e51fb41612c2433cb6482d4","security_profile":"restricted","deployment_profile":"multi_tenant","external_mount_policy":"strict","init":null,"lifecycle":{"ephemeral":false,"idle_timeout_secs":null,"max_duration_secs":120},"runtime":{"user":"1000:1000","workdir":"/tmp"},"resources":{"cpus":1,"max_cpus":1,"memory_mib":1024,"max_memory_mib":1024},"network":{"strict":true,"trust_host_cas":false,"secrets":{"secrets":[]},"policy":{"default_egress":"deny","default_ingress":"deny","rules":[]},"ports":[]},"mounts":[{"type":"Tmpfs","guest":"/tmp","size_mib":8,"options":{"noexec":true,"nosuid":true,"nodev":true,"readonly":false}}]}`

func TestOfflineAnalysisProfileRetainsContainmentAndOriginalThirtySeconds(t *testing.T) {
	analysis := strings.ReplaceAll(persisted, "core-codex-stdio/1", "python-offline-analysis/1")
	analysis = strings.Replace(analysis, `"max_duration_secs":120`, `"max_duration_secs":30`, 1)
	labels := map[string]string{"attempt": "owned", "io.agentic-os.profile": "python-offline-analysis/1"}
	if e := qualifyConfig(analysis, labels); e != nil {
		t.Fatal(e)
	}
	for _, change := range [][2]string{
		{`"max_duration_secs":30`, `"max_duration_secs":120`},
		{`"python-offline-analysis/1"`, `"core-codex-stdio/1"`},
		{`"default_egress":"deny"`, `"default_egress":"allow"`},
		{`"secrets":[]`, `"secrets":[{"name":"model"}]`},
		{`"init":null`, `"init":{"path":"/host/program"}`},
		{`"Tmpfs"`, `"Bind"`},
	} {
		if qualifyConfig(strings.Replace(analysis, change[0], change[1], 1), labels) == nil {
			t.Fatal("changed analysis profile was accepted")
		}
	}
}

func TestPersistedProfileFences(t *testing.T) {
	labels := map[string]string{"attempt": "owned", "io.agentic-os.profile": "core-codex-stdio/1"}
	if e := qualifyConfig(persisted, labels); e != nil {
		t.Fatal(e)
	}
	mutations := map[string][2]string{
		"rootKind":         {`"kind":"managed"`, `"kind":"disk_image"`},
		"rootSize":         {`"size_mib":512`, `"size_mib":8192`},
		"owner":            {`"owned"`, `"other"`},
		"image":            {`python@sha256`, `busybox@sha256`},
		"pull":             {`"Never"`, `"Always"`},
		"security":         {`"restricted"`, `"permissive"`},
		"deployment":       {`"multi_tenant"`, `"single_tenant"`},
		"externalMount":    {`"external_mount_policy":"strict"`, `"external_mount_policy":"permissive"`},
		"init":             {`"init":null`, `"init":{"path":"/host/script"}`},
		"vsock":            {`"init":null`, `"init":null,"vsock":[{"path":"/host/socket"}]`},
		"ephemeral":        {`"ephemeral":false`, `"ephemeral":true`},
		"idle":             {`"idle_timeout_secs":null`, `"idle_timeout_secs":10`},
		"duration":         {`"max_duration_secs":120`, `"max_duration_secs":0`},
		"uid":              {`"1000:1000"`, `"0:0"`},
		"workdir":          {`"workdir":"/tmp"`, `"workdir":"/"`},
		"cpus":             {`"cpus":1`, `"cpus":2`},
		"maxCpus":          {`"max_cpus":1`, `"max_cpus":2`},
		"memory":           {`"memory_mib":1024`, `"memory_mib":2048`},
		"maxMemory":        {`"max_memory_mib":1024`, `"max_memory_mib":2048`},
		"networkStrict":    {`"strict":true`, `"strict":false`},
		"hostCAs":          {`"trust_host_cas":false`, `"trust_host_cas":true`},
		"secret":           {`"secrets":[]`, `"secrets":[{"name":"host"}]`},
		"egress":           {`"default_egress":"deny"`, `"default_egress":"allow"`},
		"ingress":          {`"default_ingress":"deny"`, `"default_ingress":"allow"`},
		"networkRule":      {`"rules":[]`, `"rules":[{"allow":"host"}]`},
		"port":             {`"ports":[]`, `"ports":[8080]`},
		"mountType":        {`"Tmpfs"`, `"Bind"`},
		"mountDestination": {`"guest":"/tmp"`, `"guest":"/host"`},
		"mountSize":        {`"size_mib":8`, `"size_mib":128`},
		"noexec":           {`"noexec":true`, `"noexec":false`},
		"nosuid":           {`"nosuid":true`, `"nosuid":false`},
		"nodev":            {`"nodev":true`, `"nodev":false`},
	}
	for name, change := range mutations {
		t.Run(name, func(t *testing.T) {
			mutated := strings.Replace(persisted, change[0], change[1], 1)
			if mutated == persisted || !json.Valid([]byte(mutated)) {
				t.Fatal("invalid test mutation")
			}
			if qualifyConfig(mutated, labels) == nil {
				t.Fatal("changed profile was accepted")
			}
		})
	}
	for _, raw := range []string{"{}", "null", "{", `{"labels":{"attempt":"owned","io.agentic-os.profile":"core-codex-stdio/1"}}`} {
		if qualifyConfig(raw, labels) == nil {
			t.Fatal("incomplete configuration accepted")
		}
	}
}

func TestManagedBackingFences(t *testing.T) {
	home, e := filepath.EvalSymlinks(t.TempDir())
	if e != nil {
		t.Fatal(e)
	}
	name := "owned"
	directory := filepath.Join(home, "sandboxes", name)
	if e = os.MkdirAll(directory, 0700); e != nil {
		t.Fatal(e)
	}
	path := filepath.Join(directory, "upper.ext4")
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_RDWR, 0600)
	if e != nil {
		t.Fatal(e)
	}
	defer f.Close()
	if e = f.Truncate(512 * 1024 * 1024); e != nil {
		t.Fatal(e)
	}
	if e = qualifyBacking(home, name); e != nil {
		t.Fatal(e)
	}
	if e = f.Truncate(1024); e != nil {
		t.Fatal(e)
	}
	if qualifyBacking(home, name) == nil {
		t.Fatal("resized backing accepted")
	}
	if e = f.Truncate(512 * 1024 * 1024); e != nil {
		t.Fatal(e)
	}
	if e = os.Chmod(path, 0666); e != nil {
		t.Fatal(e)
	}
	if qualifyBacking(home, name) == nil {
		t.Fatal("publicly writable backing accepted")
	}
	if e = os.Rename(path, path+".original"); e != nil {
		t.Fatal(e)
	}
	if e = os.Symlink(path+".original", path); e != nil {
		t.Fatal(e)
	}
	if qualifyBacking(home, name) == nil {
		t.Fatal("aliased backing accepted")
	}
}
