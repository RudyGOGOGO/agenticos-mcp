// Host-only native SDK process. Controller stdin owns launch and lifecycle;
// guest stdout is emitted only as tagged data and can never become a command.
package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	sdk "github.com/superradcompany/microsandbox/sdk/go"
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"strings"
	"time"
)

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 135*time.Second)
	defer cancel()
	cfg := sdk.RuntimeConfig{Home: os.Getenv("MSB_HOME"), MSBPath: os.Getenv("MSB_PATH"), LibkrunfwPath: os.Getenv("MSB_LIBKRUNFW_PATH")}
	runtime, e := sdk.ResolveRuntime(cfg)
	if e != nil {
		panic(e)
	}
	v, e := sdk.RuntimeVersion()
	if e != nil {
		panic(e)
	}
	if v != "0.7.6" || sdk.SDKVersion() != "0.7.6" || runtime.MSBPath != cfg.MSBPath || runtime.LibkrunfwPath != cfg.LibkrunfwPath {
		panic("version/resolver mismatch")
	}
	if len(os.Args) == 1 {
		json.NewEncoder(os.Stdout).Encode(map[string]any{"ffi": v, "sdk": sdk.SDKVersion(), "runtime": runtime})
		return
	}
	attempt := os.Getenv("AOS_ATTEMPT_ID")
	installation := os.Getenv("AOS_INSTALLATION_ID")
	task := os.Getenv("AOS_TASK_ID")
	requestDigest := os.Getenv("AOS_REQUEST_DIGEST")
	uuid := regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`)
	if !uuid.MatchString(attempt) || !uuid.MatchString(installation) || !uuid.MatchString(task) || !regexp.MustCompile(`^[0-9a-f]{64}$`).MatchString(requestDigest) {
		panic("invalid controller identity")
	}
	name := "aos-n-" + strings.ReplaceAll(attempt, "-", "")
	profile := os.Getenv("AOS_NATIVE_PROFILE")
	if profile == "" {
		profile = "core-codex-stdio/1"
	}
	if profile != "core-codex-stdio/1" && profile != "python-offline-analysis/1" {
		panic("unregistered native execution profile")
	}
	labels := map[string]string{"io.agentic-os.installation": installation, "io.agentic-os.task": task, "io.agentic-os.attempt": attempt, "io.agentic-os.request": requestDigest, "io.agentic-os.profile": profile}
	if os.Args[1] == "inspect" || os.Args[1] == "reconcile" {
		h, e := sdk.GetSandbox(ctx, name)
		if sdk.IsKind(e, sdk.ErrSandboxNotFound) && os.Args[1] == "reconcile" {
			if _, err := os.Lstat(filepath.Join(cfg.Home, "sandboxes", name)); !os.IsNotExist(err) {
				panic("unregistered native directory requires recovery")
			}
			// This reports metadata absence only. The outer controller still
			// must observe process/backing release before accounting teardown.
			json.NewEncoder(os.Stdout).Encode(map[string]any{"event": "absent-record", "name": name, "id": os.Getenv("AOS_PLACEMENT_ID")})
			return
		}
		if e != nil {
			panic("owned native inspection unavailable")
		}
		qualify(h, labels, cfg.Home)
		if expected := os.Getenv("AOS_PLACEMENT_ID"); expected != "" && expected != h.ID() {
			panic("native placement identity changed")
		}
		if os.Args[1] == "reconcile" {
			cleanup, done := context.WithTimeout(context.Background(), 15*time.Second)
			defer done()
			if h.Kill(cleanup, sdk.WithKillTimeout(10*time.Second)) != nil || h.Remove(cleanup) != nil {
				panic("native cleanup unconfirmed")
			}
			if _, e := os.Lstat(filepath.Join(cfg.Home, "sandboxes", name)); !os.IsNotExist(e) {
				panic("native directory cleanup unconfirmed")
			}
			json.NewEncoder(os.Stdout).Encode(map[string]any{"event": "reconciled", "name": name, "id": h.ID()})
			return
		}
		json.NewEncoder(os.Stdout).Encode(map[string]any{"name": h.Name(), "id": h.ID(), "status": h.Status()})
		return
	}
	const image = "docker.io/library/python@sha256:54c85f3c47607a77f32adec749d3c81d1348bf25833671f512b26a9b6d778cb3"
	analysis := profile == "python-offline-analysis/1"
	if analysis && (len(os.Args) != 3 || os.Args[1] != "analysis") || !analysis && (len(os.Args) != 6 || os.Args[1] != image) {
		panic("unregistered native profile")
	}
	duration, execution := 120*time.Second, 120*time.Second
	if analysis {
		duration, execution = 30*time.Second, 20*time.Second
	}
	options := []sdk.SandboxOption{sdk.WithImage(image), sdk.WithPullPolicy(sdk.PullPolicyNever), sdk.WithCPUs(1), sdk.WithMemory(1024), sdk.WithMaxCPUs(1), sdk.WithMaxMemory(1024), sdk.WithRootDisk(sdk.RootDisk.Managed(512)), sdk.WithNetwork(sdk.NetworkPolicy.None()), sdk.WithSecurityProfile(sdk.SecurityProfileRestricted), sdk.WithDeploymentProfile(sdk.DeploymentProfileMultiTenant), sdk.WithUser("1000:1000"), sdk.WithWorkdir("/tmp"), sdk.WithMounts(map[string]sdk.MountConfig{"/tmp": sdk.Mount.Tmpfs(sdk.TmpfsOptions{SizeMiB: 8, Noexec: true, Nosuid: true, Nodev: true})}), sdk.WithMaxDuration(duration), sdk.WithQuietLogs(), sdk.WithDetached(), sdk.WithLabels(labels)}
	if !analysis {
		mode := uint32(0755)
		options = append(options, sdk.WithPatches(sdk.Patch.CopyFile(os.Args[5], "/etc/ssl/certs/aos-ca.crt", sdk.PatchOptions{}), sdk.Patch.CopyFile(os.Args[2], "/usr/local/bin/oac-daemon", sdk.PatchOptions{Mode: &mode}), sdk.Patch.CopyFile(os.Args[3], "/usr/local/bin/codex", sdk.PatchOptions{Mode: &mode})))
	}

	sb, e := sdk.CreateSandbox(ctx, name, options...)
	if e != nil {
		panic(e)
	}
	defer func() {
		cleanup, done := context.WithTimeout(context.Background(), 15*time.Second)
		defer done()
		if e := sb.Kill(cleanup); e != nil {
			panic(e)
		}
		if e := sb.Close(); e != nil {
			panic(e)
		}
		if e := sdk.RemoveSandbox(cleanup, name); e != nil {
			panic(e)
		}
	}()
	h, e := sdk.GetSandbox(ctx, name)
	if e != nil {
		panic(e)
	}
	qualify(h, labels, cfg.Home)
	json.NewEncoder(os.Stdout).Encode(map[string]any{"event": "created", "name": name, "placementId": h.ID()})
	runner := os.Args[2]
	if !analysis {
		runner = os.Args[4]
	}
	data, e := os.ReadFile(runner)
	if e != nil {
		panic(e)
	}
	arguments := []string{"-I", "-u", "-c", string(data)}
	if analysis {
		arguments = []string{"-I", "-B", "-u", "-c", string(data)}
	}
	stream, e := sb.ExecStream(ctx, "/usr/local/bin/python3", arguments, sdk.WithExecTimeout(execution), sdk.WithExecStdinPipe())
	if e != nil {
		panic(e)
	}
	sink := stream.TakeStdin()
	if sink == nil {
		panic("stdin missing")
	}
	go func() {
		scanner := bufio.NewScanner(os.Stdin)
		scanner.Buffer(make([]byte, 65536), 65536)
		for scanner.Scan() {
			var packet struct {
				Input string `json:"input"`
			}
			decoder := json.NewDecoder(bytes.NewReader(scanner.Bytes()))
			decoder.DisallowUnknownFields()
			if decoder.Decode(&packet) != nil {
				cancel()
				return
			}
			data, e := base64.StdEncoding.DecodeString(packet.Input)
			if e != nil || len(data) > 65536 {
				cancel()
				return
			}
			if _, e := sink.WriteCtx(ctx, data); e != nil {
				cancel()
				return
			}
		}
		if scanner.Err() != nil {
			cancel()
			return
		}
		sink.Close()
	}()
	total := 0
	exit := -1
	for {
		ev, e := stream.Recv(ctx)
		if e != nil {
			panic(e)
		}
		switch ev.Kind {
		case sdk.ExecEventStdout, sdk.ExecEventStderr:
			total += len(ev.Data)
			if total > 12*1024*1024 {
				panic("output envelope")
			}
			kind := "stdout"
			if ev.Kind == sdk.ExecEventStderr {
				kind = "stderr"
			}
			json.NewEncoder(os.Stdout).Encode(map[string]any{"event": kind, "data": base64.StdEncoding.EncodeToString(ev.Data)})
		case sdk.ExecEventExited:
			exit = ev.ExitCode
		case sdk.ExecEventFailed, sdk.ExecEventStdinError:
			panic("stream failed")
		case sdk.ExecEventDone:
			if e := stream.Close(); e != nil {
				panic(e)
			}
			if exit != 0 {
				panic(fmt.Sprintf("guest exit %d", exit))
			}
			fmt.Println(`{"event":"done"}`)
			return
		}
	}
}

func qualify(h *sdk.SandboxHandle, labels map[string]string, home string) {
	if qualifyConfig(h.ConfigJSON(), labels) != nil {
		panic("native persisted profile mismatch")
	}
	// Check the actual managed upper as well as the persisted image settings.
	// This does not claim the overlay root is wholly read-only.
	if qualifyBacking(home, h.Name()) != nil {
		panic("native backing envelope changed")
	}
}

func qualifyBacking(home, name string) error {
	path := filepath.Join(home, "sandboxes", name, "upper.ext4")
	canonical, e := filepath.EvalSymlinks(path)
	if e != nil || canonical != path {
		return errors.New("native backing location changed")
	}
	info, e := os.Lstat(path)
	if e != nil || !info.Mode().IsRegular() || info.Size() != 512*1024*1024 || info.Mode().Perm()&0022 != 0 {
		return errors.New("native backing envelope changed")
	}
	return nil
}

func qualifyConfig(raw string, labels map[string]string) error {
	duration := uint64(120)
	if labels["io.agentic-os.profile"] == "python-offline-analysis/1" {
		duration = 30
	} else if labels["io.agentic-os.profile"] != "core-codex-stdio/1" {
		return errors.New("native execution profile mismatch")
	}
	var c struct {
		Labels map[string]string `json:"labels"`
		Image  struct {
			OCI *struct {
				Reference string `json:"reference"`
				Root      struct {
					Kind string `json:"kind"`
					Size uint32 `json:"size_mib"`
				} `json:"root_disk"`
			} `json:"Oci"`
		} `json:"image"`
		Pull      string          `json:"pull_policy"`
		External  string          `json:"external_mount_policy"`
		Init      json.RawMessage `json:"init"`
		Vsock     []any           `json:"vsock"`
		Lifecycle struct {
			Ephemeral *bool           `json:"ephemeral"`
			Idle      json.RawMessage `json:"idle_timeout_secs"`
			Duration  uint64          `json:"max_duration_secs"`
		} `json:"lifecycle"`
		Mounts []struct {
			Guest   string `json:"guest"`
			Type    string `json:"type"`
			Size    uint32 `json:"size_mib"`
			Options struct {
				Noexec   bool `json:"noexec"`
				Nosuid   bool `json:"nosuid"`
				Nodev    bool `json:"nodev"`
				Readonly bool `json:"readonly"`
			} `json:"options"`
		} `json:"mounts"`
		Manifest   string `json:"manifest_digest"`
		Security   string `json:"security_profile"`
		Deployment string `json:"deployment_profile"`
		Runtime    struct {
			User    string `json:"user"`
			Workdir string `json:"workdir"`
		} `json:"runtime"`
		Resources struct {
			CPUs      uint32 `json:"cpus"`
			Memory    uint32 `json:"memory_mib"`
			MaxCPUs   uint32 `json:"max_cpus"`
			MaxMemory uint32 `json:"max_memory_mib"`
		} `json:"resources"`
		Network struct {
			Strict       bool `json:"strict"`
			TrustHostCAs bool `json:"trust_host_cas"`
			Secrets      struct {
				Secrets []any `json:"secrets"`
			} `json:"secrets"`
			Policy struct {
				Egress  string `json:"default_egress"`
				Ingress string `json:"default_ingress"`
				Rules   []any  `json:"rules"`
			} `json:"policy"`
			Ports []any `json:"ports"`
		} `json:"network"`
	}
	if json.Unmarshal([]byte(raw), &c) != nil || !reflect.DeepEqual(c.Labels, labels) || c.Manifest != "sha256:349275ed26e7aea20752e1fd63c40c30a0281d324e51fb41612c2433cb6482d4" || c.Security != "restricted" || c.Deployment != "multi_tenant" || c.Runtime.User != "1000:1000" || c.Runtime.Workdir != "/tmp" || c.Resources.CPUs != 1 || c.Resources.MaxCPUs != 1 || c.Resources.Memory != 1024 || c.Resources.MaxMemory != 1024 || c.Network.Policy.Egress != "deny" || c.Network.Policy.Ingress != "deny" || len(c.Network.Policy.Rules) != 0 || len(c.Network.Ports) != 0 || !c.Network.Strict || c.Network.TrustHostCAs || len(c.Network.Secrets.Secrets) != 0 {
		return errors.New("native persisted profile mismatch")
	}
	if c.Image.OCI == nil || c.Image.OCI.Reference != "docker.io/library/python@sha256:54c85f3c47607a77f32adec749d3c81d1348bf25833671f512b26a9b6d778cb3" || c.Image.OCI.Root.Kind != "managed" || c.Image.OCI.Root.Size != 512 || c.Pull != "Never" || c.External != "strict" || !bytes.Equal(bytes.TrimSpace(c.Init), []byte("null")) || len(c.Vsock) != 0 || c.Lifecycle.Ephemeral == nil || *c.Lifecycle.Ephemeral || c.Lifecycle.Duration != duration || !bytes.Equal(bytes.TrimSpace(c.Lifecycle.Idle), []byte("null")) || len(c.Mounts) != 1 {
		return errors.New("native persisted lifecycle mismatch")
	}
	mount := c.Mounts[0]
	if mount.Guest != "/tmp" || mount.Type != "Tmpfs" || mount.Size != 8 || !mount.Options.Noexec || !mount.Options.Nosuid || !mount.Options.Nodev || mount.Options.Readonly {
		return errors.New("native persisted mount mismatch")
	}
	return nil
}
