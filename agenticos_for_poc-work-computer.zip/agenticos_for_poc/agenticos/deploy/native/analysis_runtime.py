"""Fixed one-off Python runner inside an offline, separately owned microVM.

This file must never run as the Host's program executor. The qualified provider
supplies no Host mounts, model/Host credentials, network, ports or vsock route.
Stdio frames are private input/output data, never authority or usage evidence.
"""
import base64
import hashlib
import json
import os
import resource
import selectors
import signal
import subprocess
import sys
import time
from uuid import UUID

MAX_FRAME=65536
MAX_SOURCE=65536
MAX_INPUT=4*1024**2
MAX_OUTPUT=8*1024**2


def packet():
    raw=sys.stdin.buffer.readline(MAX_FRAME+1)
    if not raw or len(raw)>MAX_FRAME or not raw.endswith(b'\n'):raise ValueError()
    def unique(items):
        value={}
        for key,item in items:
            if key in value:raise ValueError()
            value[key]=item
        return value
    return json.loads(raw,object_pairs_hook=unique)


def emit(value):
    raw=json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\n'
    if len(raw)>MAX_FRAME:raise ValueError()
    sys.stdout.buffer.write(raw);sys.stdout.buffer.flush()


def main():
    serial=sys.argv[1:]==['--serial']
    if serial:
        # Readiness belongs to this live reader, after UID/GID drop and Python
        # initialization. The serial provider consumes these bounded transfer
        # observations; they never establish authority or execution usage.
        sys.stdout.buffer.write(b'AOS_ANALYSIS_READY\n');sys.stdout.buffer.flush()
    boot=packet()
    if (type(boot) is not dict or set(boot)!={'schema','attemptId','requestDigest','programDigest','inputDigest',
            'maxInputBytes','maxOutputBytes','executionMs'} or boot['schema']!='agent-native-analysis-runtime/1'
            or str(UUID(boot['attemptId']))!=boot['attemptId']
            or any(type(boot[key]) is not str or len(boot[key])!=64
                or any(ch not in '0123456789abcdef' for ch in boot[key])
                for key in ('requestDigest','programDigest','inputDigest'))
            or any(type(boot[key]) is not int or not 1<=boot[key]<=maximum
                for key,maximum in [('maxInputBytes',MAX_INPUT),('maxOutputBytes',MAX_OUTPUT),('executionMs',20000)])):
        raise ValueError()
    for kind,limit in [(resource.RLIMIT_CORE,0),(resource.RLIMIT_NOFILE,64),
            (resource.RLIMIT_NPROC,32),(resource.RLIMIT_FSIZE,8*1024**2)]:
        resource.setrlimit(kind,(limit,limit))
    root='/tmp/analysis';os.mkdir(root,mode=0o700)
    source=bytearray();input_bytes=0;sequence=0;input_started=False
    input_path=root+'/input.jsonl';program_path=root+'/program.py'
    with os.fdopen(os.open(input_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as inputs:
        if serial:emit(dict(op='input-progress',sequence=0))
        while True:
            value=packet();sequence+=1
            if (type(value) is not dict or value.get('sequence')!=sequence
                    or type(value.get('sequence')) is not int):raise ValueError()
            if serial:emit(dict(op='input-progress',sequence=sequence))
            if value.get('op')=='run':
                if set(value)!={'op','sequence'}:raise ValueError()
                break
            if set(value)!={'op','sequence','data'} or value['op'] not in {'program','input'}:raise ValueError()
            data=base64.b64decode(value['data'],validate=True)
            if not 1<=len(data)<=32768:raise ValueError()
            if value['op']=='program':
                if input_started or len(source)+len(data)>MAX_SOURCE:raise ValueError()
                source.extend(data)
            else:
                input_started=True;input_bytes+=len(data)
                if input_bytes>boot['maxInputBytes']:raise ValueError()
                inputs.write(data)
    if not source or hashlib.sha256(source).hexdigest()!=boot['programDigest']:raise ValueError()
    source.decode('utf-8')
    with os.fdopen(os.open(program_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as program:
        program.write(source)
    # Only the isolated guest interprets the model's program. There is no
    # shell, dependency install, inherited environment or model/Host facade.
    child=None;selector=selectors.DefaultSelector();output_bytes=0;failure=None
    started=time.monotonic();until=started+boot['executionMs']/1000
    try:
        with open(input_path,'rb') as inputs:
            child=subprocess.Popen([sys.executable,'-I','-B',program_path],stdin=inputs,
                stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,cwd=root,
                env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':root,'TMPDIR':root,
                    'LANG':'C.UTF-8','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1'},
                start_new_session=True,close_fds=True)
        os.set_blocking(child.stdout.fileno(),False)
        selector.register(child.stdout,selectors.EVENT_READ)
        eof=False;out_sequence=0
        while not eof:
            if time.monotonic()>=until:failure='execution-expired';break
            for key,_ in selector.select(min(.05,max(0,until-time.monotonic()))):
                data=os.read(key.fileobj.fileno(),8192)
                if not data:eof=True;break
                output_bytes+=len(data)
                if output_bytes>boot['maxOutputBytes']:failure='output-limit';break
                out_sequence+=1
                emit(dict(op='output',sequence=out_sequence,data=base64.b64encode(data).decode('ascii')))
            if failure:break
        if failure is None:
            try:exit_code=child.wait(timeout=max(.001,until-time.monotonic()))
            except subprocess.TimeoutExpired:failure='execution-expired'
            else:
                if exit_code!=0:failure='program-failed'
    finally:
        selector.close()
        if child is not None:
            # Reap this process group even when the direct child has exited.
            # The outer provider still destroys the entire VM and proves all
            # backing/process release before the Core may settle native usage.
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait(timeout=1)
            child.stdout.close()
    emit(dict(op='result',attemptId=boot['attemptId'],requestDigest=boot['requestDigest'],
        programDigest=boot['programDigest'],inputDigest=boot['inputDigest'],outputBytes=output_bytes,
        failure=failure))


if __name__=='__main__':
    try:main()
    except BaseException:
        # Never place source, input values, stack locals or arbitrary program
        # errors in provider/service logs. Missing completion stays unaccepted.
        raise SystemExit(2) from None
