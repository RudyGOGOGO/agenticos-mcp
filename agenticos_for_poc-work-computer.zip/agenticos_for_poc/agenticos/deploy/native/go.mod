module agentic-os-native-provider

go 1.26.8

require github.com/superradcompany/microsandbox/sdk/go v0.7.6
