"""Fixed Core runtime bootstrap and reverse stream inside an assigned guest.

The controller owns bootstrap identity, deadlines and credential issuance. No
host URL, socket path, operator key or arbitrary subprocess command is accepted.
"""
import resource, signal, time
import asyncio, base64, hashlib, hmac, json, os, sys, subprocess
boot = json.loads(sys.stdin.buffer.readline(65536))
if set(boot) != {'streamKey', 'attemptId', 'requestDigest', 'credential', 'environmentId', 'deadlineSeconds'}:
    raise RuntimeError('Invalid runtime bootstrap')
if type(boot['deadlineSeconds']) is not int or not 1 <= boot['deadlineSeconds'] <= 120:
    raise RuntimeError('Invalid runtime deadline')
for kind, limit in [(resource.RLIMIT_CORE, 0), (resource.RLIMIT_NOFILE, 128),
                    (resource.RLIMIT_NPROC, 64), (resource.RLIMIT_FSIZE, 8*1024**2)]:
    resource.setrlimit(kind, (limit, limit))
key = bytes.fromhex(boot.pop('streamKey'))
if len(key) != 32: raise RuntimeError('Invalid runtime channel')
attempt = boot.pop('attemptId')
request_digest = boot.pop('requestDigest')
def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
def signature(direction, value):
    return hmac.new(key, direction+b'\0'+canonical(value), hashlib.sha256).hexdigest()
async def main():
    incoming = 0; outgoing = 0; connections = {}; total = 0
    loop = asyncio.get_running_loop()
    reader = asyncio.StreamReader(limit=65536)
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin.buffer)
    async def emit(body):
        nonlocal outgoing, total
        outgoing += 1
        body = {'attemptId': attempt, 'requestDigest': request_digest, 'sequence': outgoing, **body}
        content = canonical({'body': body, 'mac': signature(b'guest', body)})+b'\n'
        total += len(content)
        if len(content) > 65536 or total > 8*1024**2: raise RuntimeError('envelope exhausted')
        sys.stdout.buffer.write(content); sys.stdout.buffer.flush()
    async def connection(r, w, service):
        if len(connections) >= 4: w.close(); return
        ident = os.urandom(16).hex(); connections[ident] = w
        await emit({'op': 'open', 'id': ident, 'service': service})
        try:
            while data := await r.read(8192):
                await emit({'op': 'data', 'id': ident, 'data': base64.b64encode(data).decode()})
        finally:
            connections.pop(ident, None); w.close()
            await emit({'op': 'close', 'id': ident})
    servers = []
    for port, service in [(19090, 'core'), (19091, 'gateway')]:
        servers.append(await asyncio.start_server(lambda r,w,s=service: connection(r,w,s), '127.0.0.1', port))
    # Parent-controlled launch, no operator key or host route in the guest.
    os.mkdir('/tmp/aos', mode=0o700); os.mkdir('/tmp/aos/capabilities', mode=0o700); os.mkdir('/tmp/workspace', mode=0o700)
    credential = '/tmp/aos/executor.json'
    with os.fdopen(os.open(credential, os.O_WRONLY|os.O_CREAT|os.O_EXCL, 0o600), 'w') as f:
        json.dump(boot['credential'], f)
    logfile = open('/tmp/aos/daemon.log', 'wb')
    env = {'PATH':'/usr/local/bin:/usr/bin:/bin', 'HOME':'/tmp/aos', 'OAC_RUNTIME_HOME':'/tmp/aos/.oac',
           'OAC_RUNTIME_WORKSPACE':'/tmp/workspace', 'OAC_RUNTIME_CAPABILITY_DIRECTORY':'/tmp/aos/capabilities', 'LANG':'C.UTF-8', 'SSL_CERT_FILE':'/etc/ssl/certs/aos-ca.crt', 'CODEX_CA_CERTIFICATE':'/etc/ssl/certs/aos-ca.crt', 'OAC_RUNTIME_CODEX_BIN':'/usr/local/bin/codex'}
    daemon = subprocess.Popen(['/usr/local/bin/oac-daemon', 'connect', '--remote',
                              'wss://127.0.0.1:19090/api/v1/agent-daemon/ws', '--environment-id',
                              boot['environmentId'], '--credential-file', credential],
                             stdin=subprocess.DEVNULL, stdout=logfile, stderr=logfile,
                             env=env, cwd='/tmp/workspace', start_new_session=True)
    await emit({'op':'ready', 'id':'', 'uid':os.getuid()})
    try:
        while raw := await reader.readline():
            if len(raw)>65536: raise RuntimeError('frame size')
            packet = json.loads(raw); body = packet['body']
            incoming += 1
            assert body['attemptId'] == attempt and body['requestDigest'] == request_digest and type(body['sequence']) is int and body['sequence'] == incoming
            assert hmac.compare_digest(packet['mac'], signature(b'host', body))
            if body['op'] == 'data':
                w = connections.get(body['id'])
                if w:
                    w.write(base64.b64decode(body['data'], validate=True)); await w.drain()
            elif body['op'] == 'close':
                w = connections.get(body['id'])
                if w: w.close()
            elif body['op'] == 'stop': break
            else: raise RuntimeError('unknown command')
    finally:
        try: os.killpg(daemon.pid, signal.SIGTERM)
        except ProcessLookupError: pass
        try: daemon.wait(timeout=2)
        except subprocess.TimeoutExpired: os.killpg(daemon.pid, signal.SIGKILL); daemon.wait(timeout=2)
        for s in servers: s.close(); await s.wait_closed()
        for w in tuple(connections.values()): w.close()
        logfile.close()
async def bounded():
    async with asyncio.timeout(boot['deadlineSeconds']): await main()
asyncio.run(bounded())
