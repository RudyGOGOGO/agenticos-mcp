# Explicit private Core and native roles

## Configured public Core

The existing public identity/UI/conversation routes can explicitly borrow the
same configured Core model, tool, source, private-state and native journals:

```sh
agentic-os agent-public-config-check --role-config /owned/public-core.json --role-config-sha256 REVIEWED_SHA256
agentic-os agent-public-serve --role-config /owned/public-core.json --role-config-sha256 REVIEWED_SHA256
```

Startup checks the packaged migration head through the configured control and
declared private-store credentials before initializing private contexts. Run the
supported embedding service for memory/knowledge profiles. `/os/readiness`
checks those current stores, the connected Temporal service and the conversation
controller; finite proactivity also checks its connected scheduler Temporal.
Unavailable dependencies return HTTP503 with no enabled lanes. This probe grants
no authority and does not certify worker capacity, inference, sandbox containment
or production qualification. `/os/health` remains the health-only process probe.
The legacy all-component `readiness` command retains its separate Core-database
requirements; it is not the selected official-SDK/native-analysis profile probe.

The private JSON has exactly `schema: agent-public-core-service/1`, `core` (the
complete `role: core` configuration below), `applications`, `operator_key_file`,
`worker`, `model_label` and `external_inference`, with optional `journey_schema`
and the journey-specific `review`/`reviews` and `activation` configurations below.
The default remains `agent-query-source-child-join-journey/1`; explicitly select
`agent-read-journey/1` for ordinary verified reads or `agent-analysis-journey/1`
for the existing exact-decimal query/analysis verifier. Exact analysis preserves
registered metric criteria, query coverage, winning identities and derived/original
sources through the shared journals and installed SDK. Select
`agent-owner-input-journey/1` for the existing registered record-selection
question and authenticated owner reply. Its profile uses the registered owner-input
harness; the reply resumes the original finite Root and grants no authority.
Select `agent-memory-read-journey/1` for existing approved personal-memory recall.
Its Core configuration additionally contains `memory` with exactly `journal_root`
(the existing private surviving consent/deletion journal outside the installation)
and `policies` (1–64 registered `AgentMemoryToolProfile` objects). Each application
supplies its own `discovery_capabilities` from those memory policies and its
registered memory harness. Host `readers` may be empty for memory-only service.
Startup borrows the existing classified index, canonical consent, scoped recall,
source verification and task-derived erasure services; it never provisions a
journal, key, consent choice or index. The owner must explicitly choose a recall
context when admitting a task. AWS uses the existing isolated component-store
credentials and private material; all component stores must be configured.
Local PostgreSQL/Temporal and login-token identity require no Cloud credentials.
The separately selected `agent-private-planned-read-journey/1` uses `knowledge`,
with the existing `journal_root` and 1–64 registered
`AgentPrivateKnowledgeToolProfile` objects in `policies`, one per selected
application. Each application selects its complete private planning profile.
Identical capability pins in unrelated applications select their own journals;
selection grants no authority. Its declared Host
read adapters must match the configured read profiles. Startup checks the
registered public model and planning harness; planner/public models, provider
credentials and disjoint encrypted-history key roles retain their existing
separation. Only the accepted closed ordering directive enters fresh public
synthesis; private KB passages never become public answer or source content.

For the explicitly owned local profile, select
`agent-reviewed-change-journey/1`. Supply one application using the registered
`agent-sdk-reviewed-change/1` harness and one Core `preparations` entry with
exactly `profile` (the registered `AgentPreparationToolProfile`) and `policy`.
The policy contains the existing loopback OPA `origin`, registered
`credential_ref`, `revision: 2` and reviewed `bundle_digest`. Core resolves the
credential from its private registry; never embed the token in this document.
Host `readers` may be empty for this preparation-only profile.

The public document additionally requires `review` with exactly
`kind: owned-local-synthetic`, `assurance_manifest` (the absolute canonical path
to an already provisioned owned assurance `manifest.json` for this installation)
and `effect_work_ms` (integer 1000–30000). Startup creates no assurance service,
provider registration or approval. The existing trusted current-owner review,
exact-input decision, effect executor and authoritative receipt lookup remain
the only execution path. Worker replacement cannot approve or repeat a change.
This profile deliberately refuses AWS and production assurance labels. Production
step-up assurance and remote effect/receipt transports use the separately
configured OIDC profile below. Local protocol acceptance uses an owned issuer;
actual IdP/AWS qualification remains separate from production write readiness.

For multiple reviewed applications, replace `review` with `reviews`, an exact
application UUID map of the same review settings. Supply one preparation lane,
selected definition and worker binding per application. Each OIDC entry selects
its own registered `provider`; its optional `repair_policy` resolves that
application's registered inverse-policy credential. Effect work ceilings remain
per application, fixed before admission. All entries must select the same
assurance kind; local synthetic and OIDC ceremonies cannot be mixed in one cohort.
The original single-application `review` form remains supported. Supplying both
forms, omitting a peer, or relying on a first-application default is refused.
Current owner checks, exact commands, original deadlines, accounting and separate
inverse approval still apply on every path.

### Finite proactive checks

Explicitly select `journey_schema: "agent-proactive-journey/1"` with registered
application/profile bindings and Core `proactivity`. It has exactly `policies`
(1–64 existing `AgentProactiveToolProfile` objects, one per selected application),
one of `read_policy` or `read_policies`, `temporal` and `scheduler`. The lane
selects only `registered-read/1`; it prepares an inactive schedule or registered
event subscription. The existing current-owner UI reviews the exact configuration.
Canonical activation completes the original Agent request; future runs use a
separate finite delegation, Root, deadline and current Host permission.
A settled, encrypted tool candidate awaiting acceptance can wake its original SDK
operation after an interrupted reply. Replay performs current source/owner/Stop
and original deadline checks; it grants no new dispatch or renewed budget. Unknown
work, absent archives and tool errors remain held or refused.

`read_policy` has exactly `origin`, `network`, `credential_ref`, `revision` and
`bundle_digest`. Resolve its token through the existing installation credential
registry. Owned local service uses `owned-local-http/1`, `temporal: null`,
`scheduler: {kind: "local-temporal"}` and the existing revision1 read-policy pin
(or the explicit revision10 pin). Local PostgreSQL, Temporal and login-token
identity require no AWS or Cloud credentials. The public service owns the existing
private scheduler worker and bounded start-intent reconciliation during its ASGI
lifespan; it creates no installation, namespace, registration or key.

Multiple applications require `read_policies`, an exact application UUID map of
those policy settings. Each credential resolves in its own application scope;
endpoints and secrets may differ, while revision, bundle digest and policy
protocol must agree. The existing broker and scheduler select the original
application on each evaluation. The single-application `read_policy` form remains
supported. OIDC activation is explicit public configuration:
`activation: {kind: "oidc-step-up", providers: <application UUID to AgentVersionPin map>}`.
Its provider keys must exactly cover the selected applications. The original
single-application `provider` form is also supported. Neither interactive
confirmation nor application selection grants authority to a future run.

Each `applications` binding may explicitly set its own `journey_schema`; an
omitted value retains the document's existing global selection and default.
Configure only the fields required by that binding's journey. One Core can
compose the declared read, analysis, owner-input, memory, private-KB, reviewed
change, proactive and reusable-Wasm journeys over the same journals and SDK.
Startup binds each complete registered definition to its existing verifier and
worker start; immutable task definition/profile/harness/resource-policy pins
select that wiring for execution, completion, sources and History. Selection
never caches current authorization. Definitions in one application share its
assigned public model/meter and worker configuration; private planning retains
its separate declared model, credentials and history-key role. Reviewed-change
cohorts still require one reviewed definition per application, and creation
retains its single configured verification policy. The compatible `memory` and
`knowledge` components must use the same surviving consent/deletion journal;
their task contexts and opaque source receipts remain separate. Required final
profile, installation and production qualification remain in the implementation
register.

AWS selects `web-pki/1` and revision10, whose exact wheel-owned policy is
`policies/scheduled_read.rego`. `adapters.opa.scheduled_read.bundle_pin()` supplies
its revision/digest; OPA loads the matching private `data.profile` and
`data.operator.token`. The decision is a current low-read eligibility result,
never synthetic production authentication or an effect approval. `temporal` must
exactly equal the public worker's existing `temporal-cloud-operator/1` document.
The remote configuration also accepts `temporal-self-hosted-operator/1`, with
explicit `endpoint` and equal `server_name`; both require mTLS, namespace UUID,
retention and immutable credential pins. Local configuration remains `null`.
`scheduler` has `kind: "eventbridge"`, `region`, `account`, `function_arn` (a
qualified alias/version) and `role_arn`. Its existing `SchedulerPlacement` policy
bounds schedule group, target and passed role. EKS uses its projected Core identity;
Cloud uses the existing pinned secret/mTLS/encrypted-history connection. EventBridge
supplies wake hints to the same Temporal/SQL driver and never admits work itself.

Core uses the selected installation's encrypted artifact/key ports and checks
current placement at SQL boundaries. Default health startup enables no proactivity.
Configured native/Wasm scheduling, complete lifecycle/recovery/system gates and
actual AWS/Cloud qualification remain separate obligations. The concrete Lambda
entry below is explicitly packaged; current image/platform and live deployment
qualification are separate from configured local scheduler acceptance.

### Lambda schedule wake role

The private `agent-lambda-schedule-wake/1` document contains exactly `schema` and
`core`, reusing the configured AWS Core/proactivity document above. Its installation
manifest must be `/mnt/agentic-os/installation/manifest.json`. EKS supports that
same canonical shared mount, retaining the original `/run/...` profile. The
operator must supply a qualified shared EFS installation with private files,
keys/recovery proofs and supported locking. Select the explicit
`aws-shared-private65534/1` profile described below: the generated Core pod and
Lambda use UID65534, while the root native supervisor uses the existing
path-scoped selected-owner checks for that same installation. The legacy
process-owner profile retains its UID0 Core composition and is not the shared
EKS/Lambda lane. Local ownership/configuration acceptance is retained separately
from actual AWS EFS ownership and locking qualification. Do not widen file
permissions, copy gates or run Lambda as root to bypass the selected profile.
No symlink, copied unqualified key store or new installation is created at startup.
Place the pinned RDS/Cloud CA material under the shared installation's `config`
directory (or explicitly include public CA files at their reviewed image paths).
EKS may retain its separate private role/TLS/workload configuration claim; Lambda
does not create a Kubernetes client or read an EKS projected token.

```sh
agentic-os lambda-wake-config-check --role-config /owned/lambda.json --role-config-sha256 REVIEWED_SHA256
agentic-os lambda-wake-plan --command-file /owned/lambda-deployment.json
```

The deployment document has exactly `schema: agent-lambda-schedule-deployment/1`,
`configuration` (the private document above), `configuration_path` (a `config/*.json`
file under the shared root), `configuration_sha256` (the exact canonical bytes),
`image` (installation/account/region-scoped ECR `lambda@sha256:...`), `efs`
(`filesystem` and `access_point` ARNs), `subnets` (two to four explicit subnet IDs)
and `security_groups` (one to four IDs). It renders a reviewable CloudFormation
plan with a named qualified alias, invocation-scoped execution role, bounded
network/logging/filesystem permissions and concurrency1. The function version
binds both image and configuration identity; prior versions are retained.
The plan provisions nothing. The EFS access-point root, private network routes,
security-group reachability, IAM/EFS enforcement and actual services require
separate AWS qualification. It does not access Temporal Cloud persistence tables.

Use the existing guarded image builder with `--lambda-wake --image-lock` pointing
to the absolute packaged `deploy/release/lambda-image-lock.json`, plus its normal
owned manifest/wheel/output/capacity arguments. It reuses the frozen Core dependency
export, pinned installer, hash-required binary wheels, image inspection and OCI
export. The distinct official AWS Python3.12 ARM64 base includes its runtime
interface client; it is pinned by digest. This mode builds only the `lambda` role,
never Core/native/SDK images or another dependency graph. Its handler is
`agentic_os.adapters.aws.lambda_entry.handler`; no public API/server is started.
Image build, Linux/runtime/security and live AWS/Cloud acceptance remain explicit
gates, not consequences of rendering a recipe or passing synthetic SDK tests.

Only deployment supplies `AGENTIC_OS_LAMBDA_CONFIGURATION` and its `_SHA256`
variable. Invocation events contain only the existing closed `driver` state.
The handler checks the qualified function ARN before acquiring credentials.
Each invocation reads the Lambda runtime's temporary execution credentials and
verifies STS identity against the installation's distinct `scheduler` role;
workstation profiles/files, metadata and permanent keys are refused. AWS documents
these [runtime credential variables](https://docs.aws.amazon.com/lambda/latest/dg/configuration-envvars.html)
and the [container runtime interface](https://docs.aws.amazon.com/lambda/latest/dg/python-image.html).
One serial event loop survives warm invocations; AWS clients and the control store
close per invocation. The supported Temporal client has no close API; both owned
adapter references to its native connection are released after awaited wake RPCs.
Every invocation reconstructs its scoped services and reads current credentials. The existing
25second wake bound and current SQL/recovery/owner/deadline/accounting guards remain.
Only the existing durable driver can admit future work; a wake carries no task,
clock, owner grant, model input or budget extension.

### OIDC step-up configuration

The original OIDC reviewed-change profile has local synthetic acceptance through
the configured ceremony, installed SDK, both Host adapters, trusted browser and
independent Core/worker artifacts. This does not qualify an external identity
provider or AWS deployment. Control0091 has
passed protected populated runtime, rollback, forward/catalog and independent
0090 recovery; it is checksum-frozen. The original reviewed-change harness is its first supported scope.
Serialized changes, repairs and scheduled approvals retain their separate
production gates. Default startup enables no OIDC or reviewed-write lane.

Select public `review: {kind: "oidc-step-up", provider: <AgentVersionPin>,
effect_work_ms: 20000}`. Its preparation policy uses exactly
`schema: "oidc-preparation-policy/1"`, `network`, `origin`, `credential_ref`,
`revision: 9`, `bundle_digest` and `required_assurance: "oidc-step-up/1"`.
The wheel contains `policies/oidc_effect_preparation.rego` and
`policies/operator_auth.rego`; `adapters.opa.oidc_preparation.bundle_pin()`
returns their shared revision/digest. An authenticated OPA deployment loads
`data.profile` with that pin and `data.operator.token` from a private secret.
Keep its management/compiler/query endpoints inaccessible to callers.

Provision `OIDCAssuranceProfile` and exact issuer/sub `OIDCSubjectMapping`
revisions using `oidc-profile-register` and `oidc-owner-map-register`, with the
existing private `--manifest`, `--operator-key`, `--application-id`,
`--command-file` and optional `--installation-config`. Register a read-only Host
first; the profile requires an existing application and the mapping an existing
authenticated subject. Then `host-register --oidc-profile <private-pin.json>`
selects that current catalog pin for its exact high-risk client profile. Profile
selection grants no approval. No email lookup or automatic subject linking is
supported. The Host provider must explicitly accept `oidc-step-up/1` and still
authenticate each current OS permit; neither an ID token nor assertion is a Host
effect credential.

Run the separate-origin ceremony from the same Core wheel/image:

```sh
agentic-os agent-oidc-config-check --role-config /run/agentic-os/oidc.json
agentic-os agent-oidc-serve --role-config /run/agentic-os/oidc.json \
  --role-config-sha256 <reviewed-raw-file-sha256>
```

This closed `agent-oidc-assurance-service/1` document contains `installation`,
`os_origin`, a distinct `origin`, `listen`, `tls`, `application_id` and the
registered `provider` pin. AWS reuses Core installation ports, its projected
identity, authenticated PostgreSQL, immutable credential refs and encrypted keys.
Deploy the existing pinned Core image with this entry command and a separate
private configuration mount; expose only the ceremony HTTPS listener. The role
exposes no task, model, effect-dispatch or operator endpoint. Supply Host session
credentials for fresh owner checks and an optional OIDC client-secret reference
only to this role. Core review verification needs no client-secret access.
Provision private TLS/DNS, egress and IAM separately; this configuration neither
provisions infrastructure nor qualifies the actual deployment.

OIDC client metadata pins issuer, authorization/token endpoints, redirect URI,
client ID, RSA public keys, required signed ACR and AMR. Raw codes and ID/access/
refresh tokens are never persisted. Code/S256/state/nonce and fresh `auth_time`
produce only an authentication fact; the existing current-owner exact-command
decision and authoritative Host receipt still determine the change. Missing or
insufficient signed assurance claims fail closed. Key/profile/mapping revisions
are explicit and current; there is no key-URL discovery or authority cache.

Owned local E2E keeps `owned-local-http/1` and its existing `local-synthetic`
login identity, with an owned synthetic issuer over the same protocol. HTTPS
production requires the exact `dpop-qualified` client. Local acceptance does not
qualify an external issuer. Expired or retired-placement protocol secrets clear
without releasing UNKNOWN usage or renewing a Root; a physical restore requires
operator recertification of profile/mapping pins. Existing consumed decisions
remain minimal audit/receipt metadata. Actual issuer ACR/AMR behavior, browser
redirect/opener policy, key rotation, TLS/egress, recovery and AWS qualification
remain required independent gates.

Registered Host effect consumers use the installation registry's explicit network
profile: `owned-local-http/1` remains loopback only, while `web-pki/1` requires the
reviewed HTTPS endpoint and ordinary CA/hostname validation. Preparation and
current inspection, original execution/cancellation, receipt-only observation,
repair and delegation control retain their separate fixed routes and credentials.
Receipt lookup resolves only its observer credential, so retiring an execution
credential does not prevent reconciliation of an original invocation. Redirects,
proxy discovery and cookie reuse remain disabled. This transport support does
not enable production review registration or synthetic approval in AWS; those
assurance, policy, current-owner and deployment qualification gates remain open.

For EKS private planning, `core.workload.planner` contains exactly `audience`
(`core.workload.audience` plus `/planner.read/1`) and `assignments`. Each private
assignment names an existing primary worker principal with the same application
and current SA UID, and its distinct planner model/meter pins. Configure the
paired native role with the same workload declaration. The original scoped Job
projects a second read-only token at `/run/agentic-os/planner-workload`; the private
SDK configuration's `planner.workloadTokenRoot` selects that path. Each token is
freshly reviewed for its own audience and model assignment. Provider secrets and
history key material stay in the existing immutable private worker claim.
The existing `agent-eks-public-role-deployment/1` document additionally requires
`privacy_journal_claim` for memory/private-KB services. It names a prepared PVC
distinct from installation and configuration/worker claims. Set the context's
`journal_root` to `/run/agentic-os/privacy-journal`; the renderer mounts it writable
only in Core. It creates no PVC and never mounts the surviving journal in the
native role or SDK worker. Existing private permissions, registered journal/key
bindings and coordinated restore fences remain required.
Each
application entry contains `applicationId` and `profile` (registered definition
pin), plus `child_read_policy` (registered policy pin) only for the query-child
journey. Discovery-backed analysis explicitly selects
`agent-adaptive-analysis-journey/1`, `agent-chart-analysis-journey/1`,
`agent-paged-analysis-journey/1`, `agent-planned-analysis-journey/1` or
`agent-comparison-journey/1`. Each application then supplies
`discovery_capabilities`: a nonempty list of exact registered `AgentVersionPin`
objects for its own configured `AgentQueryPage/1` readers. The original
application and admitted harness select that list; missing or foreign bindings
cannot fall back to another application's readers. Planning reuses the existing
private plan admission and computation journals. Current operator, registration,
generation, qualified profile and matching harness are checked before selection.
Every selected application must have its own explicit catalog authority and
workload binding. Core routes by the original installation/application context;
every Host call still checks current authority. Other product journeys retain
their separate integration gates. Startup
creates no registration, task, Root, budget or schema. Default `serve` and private
Core startup retain their existing behavior.

For `owned-local`, `worker` contains exactly `kind: local-process`,
`temporal_manifest` (the Core installation manifest), `root`, `environment`,
`concurrency` (1–4), and either `command` (one explicit installed SDK command
array for a single application) or `commands` (an exact application UUID to
command-array map). Multiple applications require the explicit map. Each
command selects that application's private worker configuration and workload
credential. Placement validates the original start before choosing its command;
an unconfigured application cannot fall back to another application's worker.
The existing owned Temporal service and private-history namespace must agree.
The process environment uses the existing closed local-worker allowlist; it
requires owned external `HOME`, `TMPDIR`, `UV_CACHE_DIR` directories and never
inherits application/provider credentials. Supply private SDK configuration
through the selected command, as before. Local Host login-token/bootstrap and
local PostgreSQL/Temporal/sandbox/scheduler services need no AWS/Cloud credentials.
Local synthetic inference stays explicitly labeled.

For AWS, `worker` contains exactly `kind: eks-assigned`, `deployment` (the
existing complete native-role deployment document), `concurrency` (1–4),
`temporal` (the existing
`temporal-cloud-operator/1` document), and either the legacy single-application
`configuration_claim`/`configuration_sha256` or `configurations`: an exact
application UUID map of `{claim, sha256}` private configuration pins. Multiple
applications require separate claims and explicit current service-account UID
assignments in the paired Core/native workload configuration. The deployment
renders only these same-namespace worker accounts; their projected RPC identity
remains bound to one application/model/meter. The existing functional AWS worker
role trusts only the explicitly declared accounts. Job selection preserves the
original start/input/root/deadline and picks the matching account/claim/hash;
an undeclared application cannot use the primary worker as fallback. Each
private configuration must contain that application's reviewed credential pins.
The deployment's Core configuration and
Cloud installation must equal `core`; the Cloud namespace must equal the
private-history namespace. AWS requires explicit external inference. Existing
reviewed CA, namespace UUID/retention and immutable Secrets Manager mTLS pins
are reused with the same installation ports. No Cloud persistence database is
opened or copied. Missing credentials fail this explicit startup, while local
engineering remains independent.

Pre-provision a separate worker-only private claim containing `assigned.json`,
owned by the worker UID with mode0600. Core receives only its immutable raw-file
SHA256 and claim name; it does not receive provider/history keys. Every original
Job pins that configuration and input digest. Original start JSON is sent over
standard `v5.channel.k8s.io` stdin followed by stream-close; no task text or
secret enters Job metadata, environment or a ConfigMap. Policy preparation
must pass before Job creation. Exact Job/Pod UID, owner, image, private mounts,
security settings and original horizon are checked; typed original controls
acknowledge start. Lost acknowledgements can observe the existing Cloud workflow
without sending its input again. Replacement retires only a verified terminal
Job UID after terminal Pod inspection. Closing Core does not cancel workflows,
delete active Jobs, renew deadlines or release UNKNOWN usage.

`eks-public-plan --command-file /owned/deployment.json --root /owned/new-bundle`
validates a closed `agent-eks-public-role-deployment/1` document with `service`
(the public document) and `ingress`. The latter contains exactly `scheme`
(`internal` or `internet-facing`), account/region-bound ACM `certificate_arn`,
two to eight explicit `subnets`, private IPv4 `subnet_cidrs` for ALB-to-Pod
policy and explicit `client_cidrs`. The generated Core uses the public command
and full configuration digest, existing private native role, namespace-scoped
Job/Pod/attach/network-policy permissions, HTTPS frontend/backend and no shared
IngressGroup. It grants no Secrets/exec permission to the dispatcher. A new
private configuration directory is required; validation failure writes nothing
and the completion plan is written last. Applying the generated resources would
create billable infrastructure and needs separate authorization. Actual ACM/DNS,
ALB controller, CNI policy enforcement, TLS trust, UID/RBAC, private PVC ownership,
Cloud retention/recovery and full AWS qualification remain required. See the
[controller's documented annotations](https://kubernetes-sigs.github.io/aws-load-balancer-controller/latest/guide/ingress/annotations/).

## Private RPC configuration

The independently installed Core wheel exposes:

```sh
agentic-os agent-native-config-check --role-config /run/agentic-os/core.json
agentic-os agent-native-serve --role-config /run/agentic-os/core.json
```

Select `role: native` in a separately supplied configuration to host native
execution. These are the existing authenticated worker RPC roles, not an owner
login server or a new public admission API. The Core role can inspect native
source state but cannot execute a native operation. The native role only exposes
`execute-native`. Existing task, Host, model assignment, policy, source,
accounting, Stop and recovery checks remain in effect on every request/replay.

Supply canonical UTF-8 JSON in a private file, owned by the service UID with no
group/other access. Use absolute canonical paths without aliases. All fields
below are required; unknown fields are rejected. Configuration validation does
not provision, migrate, register profiles, start a worker or qualify deployment.
The operator must prepare the installation, registered immutable profiles,
credentials, history keys and native owner before selecting the role.

| Top-level field | Value |
| --- | --- |
| `schema` | `agent-native-rpc-role/1` |
| `role` | `core` or `native` |
| `installation` | Installation configuration described below |
| `os_origin` | Exact owner-facing OS origin; HTTPS, or loopback HTTP for local development |
| `listen` | Object with `host` and `port` (1024–65535); local roles bind loopback, AWS roles bind `0.0.0.0` or `::` |
| `tls` | Object with `certificate_file`, `key_file`, `certificate_sha256`; local loopback may use `null` |
| `catalog` | Object with registered `AgentHostScopeProfile` in `host`, private exactly32-byte `cursor_key_file`, and optionally1–63 `additional_hosts`; each application appears once, all belong to this installation, and each reader must have an explicit catalog authority |
| `readers` | Array of exact registered read lanes, described below; nonempty except for explicitly selected memory-only or preparation-only public profiles |
| `native` | Object with exact registered native tool `profile` and `sandbox` |
| `workload` | Explicit private RPC authentication, described below |
| `history` | Object with `namespace`, `key_ids` (canonical UUID list) and `planning_key_ids` |

TLS material must be private and match the pinned certificate digest and public
key. The leaf must be current, non-CA and valid for server authentication. The
operator supplies its trust chain and endpoint names to clients. There is no
interactive passphrase prompt or automatic certificate discovery. Rotate by
preparing the new private files and reviewed configuration before replacing the
role; do not edit a live native owner's controller files.

Each reader has exactly `profile`, `policy`, `observation` and
`observation_policy`. `profile` is the registered `{read, execution}` tool policy;
the other fields are separate `AgentHostScopeProfile` objects for existing read
policy, Host observation and observation policy endpoints. They retain the same
installation and application as the read lane. Credential references resolve
through that installation's registry adapters, never environment defaults. AWS
endpoints require HTTPS. The registered read profile, current Host permissions
and independent observation checks continue to govern every source.

History key IDs select the existing encrypted-history boundary; they contain no
key material. `planning_key_ids` is `null` for a non-planning role or exactly
`{"planner.read/1": [...], "public.synthesis/1": [...]}`. Both sets must be
nonempty, disjoint and together equal `key_ids`. Provision the matching retained
keys and namespace for the independently installed SDK worker. The role does
not create histories or renew original task deadlines at startup.

For Core, `native.sandbox` is `null`: no native owner/lease is acquired. For a
native role it has exactly `kind`, `home` and `capacity_root`. Local development
can select `core-offline` or `firecracker`; AWS selects `firecracker`. `home`
points to the existing provisioned native installation root and `capacity_root`
to its private capacity inventory on the same filesystem. Runtime, placement,
verifier and installation pins must match the registered native profile before
the controller lease is acquired. Linux Firecracker still requires the separately
qualified dedicated root/KVM/cgroup supervisor. No guest artifact is downloaded,
installed or repinned by this entry point. An unresolved placement retains its
original holds; restarting the service never authorizes a duplicate allocation.

## Installation and authentication

A local installation object has exactly `schema:
agent-installation-configuration/1`, `provider: owned-local` and `manifest` (the
existing signed `manifest.json`). It reuses the owned PostgreSQL, private artifact,
key, credential, operator and recovery adapters, without AWS or Cloud credentials.
Local Temporal, scheduler and login-token server remain separately configured
existing services over the same installation and core contracts.

An AWS installation has those fields with `provider: aws-eks`, plus `aws`:

- `account`, `region`, `role`: reviewed commercial AWS account/region and the same
  `core` or `native` role as the RPC configuration.
- `token_root`: the separate STS-audience projected-token directory produced by
  `aws_workload_identity`; private RPC and STS audiences must remain separate.
- `postgres`: exactly `host`, `port`, `database`, `user`, `ca`, `ca_sha256`,
  `password`. The existing TLS RDS adapter requires the installation's exact
  `aos_<uuidhex>_control` namespace and runtime role, current control schema and
  reviewed CA. `password` is a Secrets Manager `{arn, version}` pin.
- `operator`: exactly `pin` (Secrets Manager `{arn, version}`) and `generation`.
- `credentials`: list of `{application_id, reference, pin}` immutable Host
  credentials, with no duplicate application/reference.

Secret pins must belong to the exact installation/control or application scope.
The role uses only its rotating projected-token callback and bounded regional
STS/Secrets clients. It closes clients with the role. The existing signed,
certified coordinated release guard remains mandatory for AWS transactions;
this entry point cannot bootstrap an unqualified production recovery proof.
It never creates or stops the target PostgreSQL service.

Local `workload` may use `kind: pinned-jwt` with exactly `issuer`, `audience`,
`keys` (key-ID to Ed25519 public PEM), `assignments` (subject to
`{application_id, model_digest, meter_digest}`). No private signing key belongs
in the role configuration. AWS requires `kind: kubernetes-tokenreview` with
exactly `api_origin`, `audience`, `assignments`, `reviewer_root`, `ca`,
`ca_sha256`. Assignment keys are exact service-account usernames and values add
an immutable service-account `uid` to those three assignment fields. The reviewer
projection and reviewed Kubernetes CA feed the existing live Pod-bound
TokenReview adapter. Successful reviews are not cached. Changed/revoked identity
must still fail accepted replay.

The Core and SDK worker remain independently installed with separate locked
dependencies. Their dependency-free projected-token guard is shared through the
existing generated-source parity check. Configuration/service and independent
artifact checks are local evidence. Current profile/release acceptance and actual
EKS node/network enforcement, AWS/Temporal Cloud identity, supported retention,
containment, outage and recovery qualification retain their separate gates.

## Independently installed assigned SDK worker

Run the existing worker entry point in its own locked environment:

```sh
python -m agentic_os_agent_worker.task_service --configuration /run/agentic-os/assigned.json < /run/agentic-os/start.json
```

The private configuration and original start retain their existing assigned
local/Cloud schemas. Each public or planner credential section selects exactly
one of `workloadToken` (explicit static token) and `workloadTokenRoot` (canonical
read-only projected-token directory). Both fields together are rejected. The
projected reader rereads the current token for every RPC, including accepted
replay. Missing, unsafe or expired credentials fail without static/environment
fallback and do not extend a task's original authority or deadline.

An optional top-level `nativeOrigin` pins the separately hosted native HTTPS
service. Only `execute-native` goes there; `native-source-state` and every other
operation continue to use `kernelOrigin`. Omitting it preserves an explicitly
combined service. Local synthetic loopback HTTP retains its existing selection;
Cloud assignments require HTTPS for both origins. Optional `rpcTLS` contains
exactly `ca` (the server CA PEM) and `sha256` (its ASCII-byte digest). It selects
that explicit trust store with certificate and hostname verification required;
no verification-disable option or environment trust override is available. The
internal service DNS names generated below require their matching private CA in
the assignment. Omitting `rpcTLS` retains ordinary system web-PKI trust. This
trust is separate from Temporal Cloud mTLS and provider transport credentials.
The endpoint is operator
configuration, never model input, tool arguments or workflow history.

Private planning retains separate provider credentials, transports, key IDs and
history keys. Its planner credential section can independently select a rotating
projection. Those tokens must represent the registered assignments: mounting the
same service account twice does not create another model assignment. Completing
EKS private/public model identity configuration remains a deployment obligation.
This entry point starts no Host, SQL database, login server or namespace, and
accepts no replacement initial checkpoint or renewed original start.

## Linux ARM64 images and EKS configuration artifacts

The existing image builder accepts an explicit runtime selection:

```sh
python tools/build_images.py --manifest /private/owned/manifest.json \
  --wheel /private/release/agentic_os-0.1.0-py3-none-any.whl \
  --worker-wheel /private/release/agentic_os_agent_worker-0.1.0-py3-none-any.whl \
  --runtime-roles --output /private/new-images --capacity-root /private/capacity
```

Use the maintained verification runner and its frozen source/prepared environment
for qualification. Both wheels must match that source. The existing image lock
pins the Linux ARM64 Python base and installer. Core/native use the Core lock;
the assigned SDK image uses its separate worker lock, an actual dependency probe
and disabled tracing. Image records bind each wheel, lock, requirements, command,
user, build log and exported content-addressed archive. The original health API
and legacy worker recipes remain separate compatible selections. Building images
starts no task or cloud resource. Image conformance separately checks actual
Linux imports, independent packages, commands and missing-configuration denial;
it does not qualify native hardware or live EKS/Cloud deployment.

`eks-native-plan` renders the explicitly selected single-model native profile:

```sh
agentic-os eks-native-plan --command-file /private/deployment.json \
  --root /private/new-prepared-role-configurations
```

Omit `--root` for rendering alone. A new private destination receives exact
canonical `core/role.json`, `native/role.json` and `plan.json`, after the complete
input validates. Existing output is never overwritten or adopted. Copy those
exact role bytes to their prepared configuration claims. The generated command
binds their SHA256 and role before SQL or a native lease; editing whitespace also
changes the file digest. Prepare the referenced cursor key, TLS certificate/key,
Kubernetes/RDS CAs and installation separately, with the required private
ownership/modes. A configuration bundle alone does not make those prerequisites
ready. No Secret atomic-writer symlink is accepted as a canonical role file.

The private input object has exactly these fields:

| Field | Required value |
| --- | --- |
| `schema` | `agent-eks-native-role-deployment/1` |
| `installation_id`, `namespace` | Exact installation UUID and owned Kubernetes namespace |
| `account`, `region`, `issuer_id` | Reviewed AWS account, commercial region and EKS OIDC issuer ID |
| `accounts` | Distinct `core`, `native`, `worker` service-account names |
| `images` | `core`, `native`, `sdk` immutable references of the form `<account>.dkr.ecr.<region>.amazonaws.com/agentic-os/<installation>/<role>@sha256:<digest>` |
| `configurations` | Exact `core` and `native` role objects described above; AWS provider, private TLS, port8443 and the generated worker audience/account/UID assignment |
| `configuration_claims` | Distinct prepared private `core` and `native` PVC names |
| `installation_claim` | Separate prepared owned installation/artifact/key PVC |
| `native_home` | `/srv/agentic-os/<installation>/native` on the dedicated node |
| `native_node` | One exact provisioned Linux ARM64 Kubernetes node name |

Role configuration paths under `/run/agentic-os/config` refer to the prepared
configuration claim; the signed installation manifest is
`/run/agentic-os/installation/manifest.json`. The AWS and reviewer projections use
the canonical mounts already generated by `aws_workload_identity`. Configuration
shares the same read/native/history/profile contracts; it introduces no workflow
or accounting format.

Create the namespace and service accounts using the existing identity plan first,
then read each actual service-account UID from Kubernetes. Bind that current UID
in the workload assignment before preparing these role configurations. A guessed
UID or a recreated account is not a valid assignment. Rendered identity resources
can be reapplied without recreating the accounts; this renderer does not perform
that bootstrap or grant admission.

The result includes namespace/service-account/TokenReview bindings, one Core
Deployment, one native Deployment pinned to that exact node, ClusterIP services,
network policies, configuration hashes and existing IAM trust inputs. Both
Deployments use one replica and `Recreate`; native replacement requires quiescence
and reconciliation of its existing attested owner/physical ledger. Do not scale
native supervisors or move an unfinished owner to another node. The native
controller's actual installation/runtime/placement checks remain mandatory.
Provision the node's existing `/dev/kvm`, cgroup v2 tree and private native owner
before deployment; host paths use existing-directory/device checks, not implicit
creation. The node also needs the installation label and matching native
`NoSchedule` taint/toleration shown in the plan.

This namespace explicitly permits the trusted native supervisor's privileged
container. Core runs as UID65534 for `aws-shared-private65534/1`, or as UID0
for the legacy process-owner profile, with all capabilities dropped, no privilege
escalation and a read-only root filesystem. The native
supervisor requires UID0/KVM/cgroup access; its analysis guest retains the existing
separate isolation and original-attempt controls. The SDK remains non-root and
mounts neither the installation/control store nor host paths. All Pods disable
automatic service-account mounting and host network/PID/IPC namespaces. Network
policies require actual cluster enforcement; TLS, current workload/Host authority
and registered scopes remain mandatory. The plan creates no public ingress or
IAM permissions; review exact secret/KMS/ECR/network permissions separately.

For one already admitted original worker assignment:

```sh
agentic-os eks-native-job --command-file /private/original-worker-placement.json
```

This input has exactly `schema: agent-eks-assigned-native-worker/1`, `deployment`
(the object above), `context` (the original `AgentTaskContext`) and
`assignment_claim` (a separate prepared private PVC). The claim contains
`assigned.json` and `start.json`, owned by UID65534 with private file modes.
Set its Core/native origins to the rendered `privateOrigins`, and pin their CA
through `rpcTLS`; both server certificates must cover those exact DNS names.
`--start-file` uses the existing bounded private-file reader and the same initial
start/schema/Cloud guards as stdin. The Job binds installation/application/model,
records the original Root/horizon, uses the remaining horizon as its placement
limit, disables automatic retries/restarts, and has no automatic TTL cleanup.
Current Core checks still own every execution grant and original deadline.
Replacement must preserve accepted Temporal history and UNKNOWN holds; it cannot
create a new task or silently renew a start. A prepared Job is not the complete
Core outbox/worker-dispatch adapter or a passed Cloud recovery qualification.

Both planning commands emit artifacts only. The configured public service, local
profile, worker dispatch, initial bootstrap and supported Cloud retention/recovery
use the shared Core paths documented in the product README. Current complete
profile/release acceptance and actual node/storage/identity/network/containment/
recovery qualification remain separate required gates. Missing AWS/Cloud
credentials does not block local engineering or the independent local E2E profile.
See the Kubernetes
[projected-volume](https://kubernetes.io/docs/concepts/storage/projected-volumes/)
and [audience-aware TokenReview](https://kubernetes.io/docs/reference/kubernetes-api/definitions/token-review-v1-authentication/)
contracts for the reused identity boundaries.


### Fresh AWS shared filesystem profile

Select `installation.aws.private_files: "aws-shared-private65534/1"` in both
Core/native objects for the supported EKS/Lambda shared installation. Bootstrap,
Core and Lambda use UID65534, private0700/0600files and one signed gate/key tree.
Native remains root and carries only a path-scoped selected-owner policy for
that installation; existing owner/mode/link checks remain fail-closed. No live
installation is automatically adopted or chowned. Core/SDK use group0 for
root0440 projected workload tokens, without fsGroup on private claims.

All control/component RDS CA files must be inside the shared installation root.
The initial-readiness Temporal operator configuration and its server CA must
also live there at identical absolute paths in EKS/Lambda/native. Role-specific
TLS/config files remain on distinct private claims, owned65534 for Core/SDK/
Lambda and0 for native. The privacy journal is a distinct surviving65534 claim.

Native `installation.aws.control_binding` is the exact Core *installation*
object, retaining Core's original readiness-proof digest. It contains only
reviewed references, not secret values. Native still authenticates as native,
uses its own token and has only its reduced credentials. The parser rejects
recursive bindings, another manifest/postgres/operator/storage/owner profile,
extra native credentials or this field on Core. The EKS generator verifies that
it equals the supplied Core installation. Update the reviewed native reference
when Core installation configuration changes; never duplicate readiness gates.

Native capacity must be `/srv/agentic-os/<installation>/capacity`, a sibling of
its immutable `/srv/agentic-os/<installation>/native` inventory. The packaged
`agentic_os.adapters.sandbox.firecracker_operator` supports explicit finite node
preparation with an exact profile SHA256, host/KVM checks before allocation and
existing owner/provision APIs. It creates no task, activation or READY proof.
