# AWS documents Debian + its Runtime Interface Client as a supported container
# construction path. The RIC/entrypoint/emulator come from one pinned AWS stage;
# only the final official Python base supplies the interpreter and stdlib.
COPY --from=lambda_interface /var/runtime/ /var/runtime/
COPY --from=lambda_interface /lambda-entrypoint.sh /lambda-entrypoint.sh
COPY --from=lambda_interface /usr/local/bin/aws-lambda-rie /usr/local/bin/aws-lambda-rie
RUN python -I -B -c "import ctypes; ctypes.CDLL('libstdc++.so.6')" \
 && dpkg-query -W -f='${Package}\t${Version}\t${Architecture}\n' > /usr/local/share/lambda-runtime-packages.tsv \
 && find /usr/local/lib/python3.12/site-packages/awslambdaric /usr/local/lib/python3.12/site-packages/simplejson -type d -name __pycache__ -prune -exec rm -rf '{}' + \
 && mkdir -p /var/lang /var/task \
 && ln -s /usr/local/bin /var/lang/bin
ENV LAMBDA_TASK_ROOT=/var/task LAMBDA_RUNTIME_DIR=/var/runtime
