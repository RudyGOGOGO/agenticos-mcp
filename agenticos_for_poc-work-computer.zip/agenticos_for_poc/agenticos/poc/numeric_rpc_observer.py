"""Private opt-in numeric qualification spans; preserve original RPC semantics."""
from contextvars import ContextVar
from datetime import datetime, timezone
from pathlib import Path
import json
import os
import time
from sqlalchemy import event
from sqlalchemy.engine import Engine
from agentic_os.production.model_rpc import ModelWorkerService, WORKER_ACTIONS


def install(path):
    path = Path(path)
    assert path.is_absolute() and not path.exists()
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    stream = os.fdopen(descriptor, 'w', buffering=1)
    current = ContextVar('poc_numeric_rpc', default=None)
    count = 0
    original = ModelWorkerService.dispatch

    def before(conn, cursor, statement, parameters, context, executemany):
        # Never retain SQL text, parameters, subjects or returned data.
        context._poc_numeric_start = time.perf_counter_ns() if current.get() is not None else None

    def after(conn, cursor, statement, parameters, context, executemany):
        row = current.get()
        began = getattr(context, '_poc_numeric_start', None)
        elapsed = time.perf_counter_ns() - began if began is not None else 0
        while row is not None and began is not None:
            row['sqlStatements'] += 1
            row['sqlElapsedNanoseconds'] += elapsed
            row = row.get('_parent')

    event.listen(Engine, 'before_cursor_execute', before)
    event.listen(Engine, 'after_cursor_execute', after)

    async def observed(self, assignment, action, value):
        nonlocal count
        if action not in WORKER_ACTIONS:
            return await original(self, assignment, action, value)
        row = dict(schema='poc-private-rpc-numeric-span/1', action=action,
                   beganAtUTC=datetime.now(timezone.utc).isoformat(),
                   sqlStatements=0, sqlElapsedNanoseconds=0)
        token = current.set(row)
        began = time.perf_counter_ns()
        succeeded = False
        try:
            result = await original(self, assignment, action, value)
            succeeded = True
            return result
        finally:
            current.reset(token)
            row.update(elapsedNanoseconds=time.perf_counter_ns()-began, succeeded=succeeded)
            # Bounded diagnostics cannot change a result or mask its exception.
            try:
                if count < 4096:
                    count += 1
                    stream.write(json.dumps(row, separators=(',', ':'))+'\n')
            except (OSError, ValueError):
                pass

    ModelWorkerService.dispatch = observed
    # Extend this existing numeric collector at the demonstrated finite effect
    # boundary. No arguments, credentials, SQL or exception messages enter it.
    # Nested SQL counts are inclusive, so these spans must not be summed.
    from agentic_os.production.reviewed_effect import ProductionEffectAuthority, ProductionReviewedEffectLedger
    from agentic_os.effects.reviewed_permit import ReviewedPermitService
    from agentic_os.effects.reviewed_executor import ReviewedEffectExecutor
    from agentic_os.adapters.poc.effect_context import EffectContextSigner
    from agentic_os.adapters.poc.effect_provider import VerizonEffectProvider
    for owner, method, action in (
        (ProductionEffectAuthority,'current','effect-authority-current'),
        (ProductionReviewedEffectLedger,'reserve','effect-reserve'),
        (ProductionReviewedEffectLedger,'begin','effect-begin'),
        (ReviewedPermitService,'_validated','effect-permit-current'),
        (ReviewedEffectExecutor,'run','effect-executor-run'),
        (EffectContextSigner,'sign','effect-sign'),
        (VerizonEffectProvider,'execute','effect-provider-execute')):
        previous = getattr(owner, method)
        async def measured(self,*args,_previous=previous,_action=action,**kwargs):
            nonlocal count
            row=dict(schema='poc-private-rpc-numeric-span/1',action=_action,
                beganAtUTC=datetime.now(timezone.utc).isoformat(),
                sqlStatements=0,sqlElapsedNanoseconds=0,_parent=current.get())
            token=current.set(row);began=time.perf_counter_ns();succeeded=False
            try:
                result=await _previous(self,*args,**kwargs);succeeded=True;return result
            except BaseException as error:
                row['errorType']=type(error).__name__
                from agentic_os.errors import OSErrorCode
                if isinstance(error,OSErrorCode):row['errorCode']=error.code
                raise
            finally:
                current.reset(token);row.pop('_parent',None)
                row.update(elapsedNanoseconds=time.perf_counter_ns()-began,succeeded=succeeded,
                    nestedSQLCountsInclusive=True)
                try:
                    if count<4096:
                        count+=1;stream.write(json.dumps(row,separators=(',',':'))+'\n')
                except (OSError,ValueError):pass
        setattr(owner,method,measured)
    return original
