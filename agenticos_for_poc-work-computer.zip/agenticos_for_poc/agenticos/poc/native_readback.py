"""Qualification projection of an actual authenticated Core source surface.

This is display evidence, never a task, expected model answer or authority.
The caller separately checks canonical admission, source causality and effects.
"""
from copy import deepcopy
from decimal import Decimal
import re
from uuid import UUID

from agentic_os.contracts.validation import validate_contract
from agentic_os.interaction.catalog import surface_hash,validate_messages


def source_tables(surface,source_proof_sha256,*,empty_labels=None):
    """Keep exact server-rendered strings and unique header associations.

    Empty labels must be supplied from the actual qualified renderer. Missing
    empty-state evidence is refused rather than synthesized from a zero count.
    """
    validate_contract('AssistantSurface',surface)
    if surface_hash(surface)!=surface['snapshotHash']:
        raise ValueError('Actual bound Core surface required')
    if (type(source_proof_sha256) is not str
            or re.fullmatch('[a-f0-9]{64}',source_proof_sha256) is None):
        raise ValueError('Exact retained source proof digest required')
    components=validate_messages(surface['surfaceId'],surface['messages'])
    task=str(UUID(surface['taskId']));tables=[];matrices=set()
    empty_labels={} if empty_labels is None else deepcopy(empty_labels)
    used_empty=set()
    for component in components.values():
        if component['component']!='Table':continue
        columns=component['columns'];rows=component['rows']
        if not columns or len(columns)>32 or len(set(columns))!=len(columns):
            raise ValueError('Unique bounded source columns required')
        if len(rows)>500 or any(len(row)!=len(columns) for row in rows):
            raise ValueError('Complete bounded source rows required')
        if any(type(cell) is not str or len(cell.encode('utf-16-le'))//2>2000 for row in rows for cell in row):
            raise ValueError('Exact bounded displayed cells required')
        decimals=[name for name in columns if name in {'latitude','longitude'}]
        for column in decimals:
            for row in rows:
                value=row[columns.index(column)]
                if value!='Unknown' and re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]{1,6})?',value) is None:
                    raise ValueError('Exact plain source coordinates required')
        # The native decimal checker cannot treat Unknown as a coordinate.
        # Keep a nullable coordinate column as exact ordinary displayed text.
        decimals=[name for name in decimals if all(row[columns.index(name)]!='Unknown' for row in rows)]
        key=(tuple(columns),tuple(tuple(Decimal(value) if columns[index] in decimals else value
            for index,value in enumerate(row)) for row in rows))
        if key in matrices:raise ValueError('Ambiguous identical source matrices')
        label=None
        if not rows:
            label=empty_labels.get(component['id'])
            if type(label) is not str or not 1<=len(label)<=256:
                raise ValueError('Actual table-associated empty label required')
            used_empty.add(component['id'])
        tables.append(dict(columns=deepcopy(columns),rows=deepcopy(rows),decimalColumns=decimals,emptyLabel=label))
        matrices.add(key)
    if not 1<=len(tables)<=8 or set(empty_labels)!=used_empty:
        raise ValueError('Actual unambiguous source tables and empty evidence required')
    return dict(schema='vf.native-source-tables/1',taskId=task,sourceProofSHA256=source_proof_sha256,
        tables=tables,narratives=[])
