# Preview-first workload retirement

`poc/pocctl.py teardown` is an operator command. It provisions nothing and does
not stop services, expire tasks, release accounting or retry an effect. Drain
through the normal runtime, stop the Core, and retain its original installation.
The command requires the same private `poc-runtime.lock`; a running Core refuses
retirement. Every canonical nonterminal task/Root/work/learning/Direct binding,
outstanding resource and signed SDK physical lease refuses it, including an
expired UNKNOWN. Observation never clears those records.

The private environment document has schema `poc-eks-retirement/1` and these exact
fields: `installation_id`, `installation_configuration` (the existing reference-only
AWS installation configuration), `account`, `region`, `cluster`, `namespace`,
`namespace_uid`, `kubeconfig`, `context`, `aws_profile`, and `resources`.
`resources` contains the actual creation receipts `{kind,name,uid}`. Capture these
from the separately approved deployment; do not infer ownership from labels or
the installation UUID. Restored fixtures can share an installation UUID.

The command independently reads STS account and EKS endpoint/CA, compares the
selected explicit kubeconfig, verifies namespace UID and installation label, and
requires an empty dedicated namespace with all recorded Deployments at zero.
The existing configured installation must name that same account/region and
installation. No local installation can stand in for the AWS control store.

```sh
python poc/pocctl.py teardown --environment /private/owned/environment.json \
  --kubectl /absolute/resolved/path/to/kubectl --dry-run
python poc/pocctl.py teardown --environment /private/owned/environment.json \
  --kubectl /absolute/resolved/path/to/kubectl --apply \
  --preview-digest REVIEWED_PREVIEW_SHA256
```

Dry-run is the default. Apply must match the observed preview digest. Before
each deletion it rechecks canonical/physical work and current ownership. Only
recorded Deployment, Service, Ingress, NetworkPolicy, ConfigMap and ServiceAccount
resources are eligible. Each raw DELETE carries exact UID and resourceVersion
preconditions and `propagationPolicy=Orphan`; a replacement/conflict/unavailable
response stops the operation. An uncertain deletion is inspected manually, never
automatically replayed. The [kubectl raw DELETE interface](https://kubernetes.io/docs/reference/generated/kubectl/kubectl-commands.html)
provides the underlying transport; no selector, wildcard or namespace cascade is
used.

Namespace, databases, PVCs, Secrets, keys, artifacts, retained ReplicaSets and
evidence are preserved. Their later disposition requires a separate explicit
retention decision. The command has no data-erasure option. Preserve the dry-run
and command result with the deployment evidence. A failure after an acknowledged
deletion requires inspection of the exact remaining creation receipts before
preparing a fresh preview; do not claim the whole operation completed.

Local engineering evidence is `../evidence/p4-teardown.json`: actual read-only
canonical refusal on the original baseline and four protected fault fixtures,
unchanged accounting/deadline/lease fingerprints, exact resource replacement and
AWS endpoint/CA refusal vectors, and the actual installed kubectl wire against a
loopback fixture. All original fixtures refuse retirement; the baseline has two
older ACCEPTED tasks/ACTIVE Roots even though outstanding usage is zero. The
successful Verizon task is independently CLOSED/settled. No AWS request, cloud
resource deletion, real kube authorization or external TLS qualification was run.
Full P4 and A1 remain open.
