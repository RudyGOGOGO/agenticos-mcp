#!/usr/bin/env python3
"""Operator-only POC resource preview. Never provisions or activates a runtime."""
import argparse
import json
from pathlib import Path

from agentic_os.adapters.local.files import OwnershipError, private_read
from agentic_os.adapters.configured_installation import canonical_file
from agentic_os.adapters.poc.teardown import operate
from agentic_os.contracts.canonical import parse_canonical_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    teardown = commands.add_parser('teardown', help='Retire exact drained workload/routing resources; retain all data')
    teardown.add_argument('--environment', type=Path, required=True)
    teardown.add_argument('--kubectl', required=True, help='Absolute installed operator kubectl path')
    mode = teardown.add_mutually_exclusive_group()
    mode.add_argument('--dry-run', action='store_true')
    mode.add_argument('--apply', action='store_true')
    teardown.add_argument('--preview-digest')
    args = parser.parse_args()
    if args.apply and not args.preview_digest:
        parser.error('--apply requires the reviewed original --preview-digest')
    try:
        value = parse_canonical_json(private_read(canonical_file(str(args.environment)), 65536))
        result = operate(value, kubectl=args.kubectl, apply=args.apply, preview_digest=args.preview_digest)
    except (OwnershipError, ValueError, KeyError, TypeError, OSError):
        parser.exit(2, 'Retirement refused or unavailable; preserve resources and inspect the original evidence.\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
