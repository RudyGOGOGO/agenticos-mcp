# Continuous local synthetic access

Status: installed engineering; actual native sign-in, Agent Ready and native
product reads pass. The complete native create/edit/confirm/write/reopen journey,
continuous-session renewal/revocation acceptance and full design remain OPEN.
Exact peer evidence is in `evidence/native-active-session-readiness.json` and
`evidence/mcp-current-native-access.json`.
See `evidence/local-native-access-prerequisites.json`. This profile is off by
default and is rejected by the closed AWS configuration. It supplies login
continuity, not task/effect authority. No ordinary user refresh command is part
of the intended native experience.

The app owns a durable private registry and a non-expiring opaque credential in
native Keychain. Explicit sign-in creates a new UUID and monotonic revision;
sign-out, revocation and environment stop deny the old credential. Relaunch
reuses the current credential, and never silently signs a revoked owner back in.
Core validates that credential only at the fixed backend native-status route.
It publishes authenticated metadata, never the credential, in its private shared
record. Native transitions wait for the exact publication acknowledgment.

Existing OS sessions expire after five minutes and the embedded frame renews
150seconds early through a fresh Host challenge/bootstrap. Existing Host
bindings remain900seconds, with an additional native session UUID/revision.
Neither renewal destroys the same-owner conversation/drafts nor renews a Root.
For local native trusted review only, proactive renewal waits while that review
is open, then resumes one handshake on close. The actual OS expiry/current
denial still applies; an expired credential is never kept alive by an open form.
Changing accounts destroys the old native containers. Current Host checks pull
fresh private app status. Reads and effect signing resolve the original Root's
admitted Host session and reject a different native epoch, including same-owner
re-login. Java/backend additionally bind each original delegated request.

Core obtains fresh finite account workload tokens through the pinned app-owned
issuer, with an environment read-only grant that can observe signed-out/revoked
accounts. It renews ahead of expiry. A genuinely unexpired retained token can
still report STOPPED; its expiry is never extended. Receipt credentials use a
separate pinned MCP-owned issuer and public verification key, require ACTIVE
current access and carry the three accepted local binding claims. Every such
JWT stays at most900seconds. Each execution JWT stays at most60seconds and no
later than its original authorization horizon. There is no cached receipt
credential fallback after access changes.

Trusted native confirmation keeps the real in-app review and separate owner
ceremony windows. An explicit Confirm action invokes the native-only bridge.
Core rechecks native login, original Root, current canonical review/challenge,
owner session, exact proposal and unchanged deadline, then transports the exact
existing owner command to the existing fixture provider. Its separate owner
credential stays server-side. No native/model/controller credential is used as
an approval, and the normal review decision and execution permit remain required.
The ordinary diagnostic browser and production OIDC branches remain unchanged.

## Explicit installation inputs

The existing private `poc-family-runtime/1` configuration adds one closed
`local_access` object with schema `poc-local-native-access/1`, `state_file`,
`environment_id`, `account_issuer` and `receipt_issuer`. Existing memory/account
observation must be enabled. The wire namespace must equal the accepted local
MCP namespace. Paths are private canonical absolute references on authorized
verification storage; source contains no runtime credential.

`account_issuer` contains exactly `python`, `python_sha256`, `script`, `files`
(reviewed absolute source/import path→SHA256 map), `fixture` and
`session_registry`. Its fixed script is app `issue_account_token.py`; the existing
`memory_account.token_files` map names its protected outputs for each supported
subject. Core invokes only the documented environment account role.

`receipt_issuer` contains exactly `python`, `python_sha256`, `script`, `files`,
`fixture`, `token_files`, `issuer`, `audience`, `client_id`, `public_key_file`.
The public key is included in `files`. Its fixed script is MCP
`fixture-credentials.py`; Core always supplies `--purpose observation --ttl900`
and the protected shared-record reference. Configured issuer/audience/client and
the actual RS256 JWT must match. No signing-key argument is accepted.

App enables its committed local registry/shared-record flags; Java enables
`MCP_LOCAL_PERSISTENT_ACCESS_ENABLED=true`, the same
`MCP_LOCAL_ACCESS_STATE_FILE` and its reviewed app issuer renewal configuration.
Use the committed peer pin manifests; do not substitute working-tree scripts.
Adopt at verified idle: backend/private observer, Core, Java, then native. Core
startup observes both permitted account states and publishes only the newest
actual selected account; an unrelated inactive account revocation does not
displace a still-active account. It does not create a login. Start the detached Core through
the existing `poc/checks/family_runtime.py` operator with explicit private config,
existing live controls, allowance report and capacity root. Retain the original
sole ledger and all UNKNOWN holds. AWS uses its existing configured entry.

Deliberate environment stop must stop the app registry and publish STOPPED while
the current environment observer is still usable, then stop the services.
Restart/reset is an explicit environment operation with a new environment UUID
and preserved old publication/evidence; it never revives a former native login.
An idle Core binary upgrade preserves the running environment UUID/registry.
Exact live paths, revisions and installation commands belong in the deployment
handoff after coordinated adoption. Missing adoption or native acceptance is
local work, not external AWS qualification.
