# Current portable bootstrap checkpoint

Use [root AGENTS.md](../../AGENTS.md) and
[supported local setup](../../supportive_docs/local-setup/README.md). The fresh
persistent-local initializer is implemented and tested through independent locked
builds, schema/seed/identity initialization, real HTTP Host/DPoP/Java/backend/receipt
connectivity and restart. Default model reservations are disabled. The native app
build passes; full native create/edit/confirm/write/readback acceptance remains OPEN.
The original running services were not upgraded. Older status paragraphs below
retain their historical pins and are superseded for current setup instructions.

---

> Flattened portable source: see [root AGENTS.md](../../AGENTS.md).
> Original source and installed revisions below remain distinct; packaging only.

# Paused portable checkpoint — November3

Feature development, latency optimization and new acceptance are paused by the
owner until explicit resume. The portable project's root WORK-COMPUTER-HANDOFF.md
supersedes historical local launch/refresh/deadline instructions below. Installed
Core1f967152/SDKae0a353 are unchanged. New7d71295b/38b8d20f/664d1f17 latency changes
passed focused prerequisites but are not installed or accepted end to end.
Fresh persistent-local family initialization remains missing local packaging
engineering; do not call it external AWS qualification or use baseline install
as the three-store POC initializer. Read release.json for current open gates.

## Structured prior read coverage — candidate, actual acceptance pending

The next immutable contextual read profile is definition5, with the private
`agent-contextual-lookup-read-journey/2` start and coverage context. It adds the
prior accepted requested capability/resource/field selection to each eligible
owner turn. It carries no old values. Complete context is bounded to8192UTF8
bytes, including whole turn/coverage pairs; owner request/reply text keeps its
4096-byte/two-turn bound. Unavailable or expired prior canonical goal metadata
stops context collection rather than skipping back. The old955 contracts and
read definition4 remain exact. No migration or peer-wire change is needed.

With matching Core/SDK, `owner_read_context: true` selects the retained read4.
The additional explicit `owner_read_context_version: 2` selects candidate read5;
version1 is the default. Both immutable profiles remain available for old tasks.
Focused Core/SDK/protected105
question/reply/fresh read/old-review/expiry and package prerequisites pass in
`evidence/owner-read-coverage-prerequisites.json`. Actual short-follow-up field
coverage is NOT yet accepted; the earlier omission remains an open defect until
the new installed path produces all requested fields from fresh sources. Actual
read5 seedb2b52b54 completed with all fields, but follow-up2cadd0d4 asked an
unnecessary record clarification despite correct prior requested-field context,
then expired at its original deadline. It was not retried or revived. That
quality failure is preserved; read5 is not an accepted replacement for read4.

## November3 delivery correction — native and continuous access OPEN

The VF native app/WKWebView is the primary experience. External Chrome is
diagnostic only. Essential native creation, authoritative form edits, separate
in-app confirmation, real Core/SDK→Java→backend effect, Agent outcome, exact
native detail and reopen persistence remain required engineering acceptance.
The physical-only Simulator runner configuration failure is retained as an
automation setup failure, not a product failure or a manual-completion exit.

The corrected standard Simulator driver20 now passes the retained new-record
native read-back/reopen subgate: actual Practice Center Reviewed address,
coordinates and Mia425/BOTH/enabled values were seen in two native cycles,
with zero Send/edit/Save/decision and unchanged app/data. See
`evidence/native-product-readback-activation.json` (39.367seconds). The original
failed run remains failed. This closes read-back of the prior browser-created
record only; full Agent creation/edits/confirmation inside native is still OPEN.

Explicit revocable continuous access is authorized only for local synthetic
testing. The accepted native-session registry, original current-session binding
and transparent finite account/receipt renewal are implemented and installed in
Corea527ad28/SDKb748, Java22809e0, backend840c355 and native22/cfc1dfb.
Actual native sign-in, renewal/revocation and the complete new Agent journey
remain open. Actual explicit native sign-in, Agent Ready and authenticated
native product reads now pass; current Java nine-tool handshake and finite
receipt renewal pass too. See `evidence/native-active-session-readiness.json`
and `evidence/mcp-current-native-access.json`. Inner WK composer/forms/trusted
confirmation remain unverified and use the existing supported XCTest route;
native accessibility controls do not expose inner WK content.
The native installation wrapper directory comparison failed and
remains UNKNOWN; exact binary hashes and the preexisting outbox are retained.
OS sessions,
per-action grants, Root deadlines, accounting and production/AWS defaults remain
finite and unchanged. Installed engineering is distinct from actual integrated
acceptance; do not mark this correction accepted before native verification passes. The pending-question
progress fix reuses current authorized identity checks to reload canonical task
state after expiry; it never infers a result or repeats a command.

## Bounded contextual reads — record resolution accepted; full coverage open

`owner_read_context: true` together with `table_display_mapping: "vf.units-labelled/1"`
selects new read definition4, while retaining definitions1–3 for their original
records. Default is false. Core and the separately packaged SDK must be upgraded
together. The new private context contains at most two contiguous completed owner
read requests and authenticated clarification replies, at most4096 UTF8 bytes.
It carries no prior facts, model prose or execution authority. Fresh authorized
reads are still required. A necessary record clarification stays on the same
finite Root. Definition4 also preserves requested extra table fields, including
coordinates. No database migration or peer wire change is needed.

Focused prerequisites are in `evidence/owner-read-context-prerequisites.json`.
Actual official-model/Java/backend read resolution and explicit coordinate display
are accepted in `evidence/owner-read-context-activation.json`. A repeat-summary
request still omits the earlier requested coordinates despite correct record
resolution and fresh data; full requested coverage and conversational quality
remain OPEN. The first malformed-goal failure and both partial follow-ups are
preserved. Do not interpret canonical completion as full quality acceptance. Install only at verified idle, preserve original artifacts and data, and
qualify the SDK in a separate environment. Installed SDK environments have a
runtime-role marker which the qualification runner refuses before setup. General
write follow-ups and supported alternatives remain separate open requirements.

# Verizon Family POC — Core integration

Current November3 completion review: mandatory v2.1 completion remains **OPEN**.
Retained actual7d Chrome official-embed evidence covers Agent planning,
owner-edited new-place and Mia425/BOTH boundary forms, separate owner confirmations,
two Java/backend committed receipts and a current real-Agent seven-column read.
These are two explicit requests sharing the actual new location ID; one-utterance
compound completion is unaccepted. The exact new-place native detail/coordinates/
rule/reopen subgate now passes with corrected supported Simulator driver20;
the original read-only driver failed Xcode70 before test execution because its
mode requires a physical iOS device. The full native Agent journey remains open.
Core actual forced-stream/cursor/current-state and scope-denial checks pass;
native T1/T9 and native whole-field editing remain required and open. S4 inbox-to-edited-effect,
future consequential scheduling/current-scope refusal, the full ordered demo and
general contextual/alternative quality remain local engineering/acceptance.
Both memory paths, read schedules, advisory reflection, S1/S2/S3/S5 and canonical/
native recovery retain their original passing evidence. Source-only922-file build,
922Core/33SDK image probe and backend fresh initializer proof pass. Concrete fresh
credential publication/pinning instructions are supplied in the export operator guide;
actual approved AWS/IdP/real Verizon execution remains external. See `release.json`,
`evidence/actual-created-place-boundary-read.json`,
`evidence/new-resource-native-readback-gate.json` and the completion review index.

Bounded standalone English greetings and thanks now receive frame-local courtesy
replies without a task/model/receipt. Actual greeting/thanks and an actual unchanged
waiting question pass; an ambiguous literal answer stays available only through
the original current task/version/question-bound reply control. Stop/uncertain
recovery disables it. Current corrected UI passes43 affected checks, actual recorded
question-state replay, type/build and live greeting/New conversation checks; all64
Roots/memory/ledger bytes stay exact. One real missing-details probe used1model,
0tools/effects,2257micros and was normally stopped/CLOSED0held. Its3c runtime
provenance is retained; the conservativec9 Stop guard is qualified separately.
This is a small courtesy slice, not full contextual dialogue or supported-alternative
acceptance. See `evidence/conversational-courtesy-activation.json`.

This directory composes the retained production Core with a bounded, fixed SDK subprocess. The original Temporal selector remains the default. Direct tasks use the distinct persisted `OSAgentDirectDriver/1` profile and cannot claim original Temporal dispatches.

P0 is an explicitly deterministic plumbing fixture. It looks up the synthetic Tom member through the committed Java service, retains real admission, authorization, accounting, encrypted artifacts and completion validation, and makes no paid model call. This fixture does not qualify dynamic reasoning, writes, memory, schedules, native embedding or AWS deployment. Those remain separate integration gates.

The separate `poc-family-runtime/1` candidate consumes all five committed read
DTOs and four typed preparation lanes. It reuses exact capability routing,
current Host observation, original model/tool journals and separate owner review.
Lookup harness revision 2 selects accepted table results against immutable
row/field criteria; revision 1 retains field-selection semantics. Empty rules,
nullable battery and truncated history remain explicit. At most four selected
evidence pages fit one public result; larger results cannot silently complete.

`checks/family_runtime.py` is an explicit synthetic live-qualification operator,
not an AWS entry point. It validates the existing approved model/privacy controls
and reserves/binds the original Root in the single existing allowance before
the installed child receives its protected credential reference. Only original
SQL provider observations, unchanged deadline, closed Root and zero held usage
can settle that reservation; uncertainty keeps the full hold. No inherited row
is transitioned. Actual installed Core/SDK, official model, Java MCP, synthetic backend and native iOS
integration retains passing S1/S2/S3/S5, authoritative radius/notification edits,
both memory paths/privacy, finite read schedules, advisory reflection/inbox and
canonical T8 receipt-only recovery after native Stop and Core process loss.
S4 inbox-to-edited-effect remains unproven. A later actual Chrome child form changes
Tom to Mia,300 to425meters and arrival-only to BOTH with fresh confirmation and
canonical receipt; its native new-resource read-back is manual as described above.
The original UNKNOWN usage remains held. See
`evidence/full-local-integration-checkpoint.json` for exact pins and retained
evidence. Actual native process death/relaunch preserves the durable original
operation key with no automatic replay; one explicit unchanged-key resume
recovers the committed result and native read-back. T3 records one matched
operation with9 native and14 agent UI actions, with no minimum-step, latency or
statistical claim. The narrower functional checkpoints remain accepted; the mandatory completion
review above controls status. Actual AWS/issuer/real API qualification is external.

The sections below retain implementation and historical checkpoint detail.
Earlier references to open scenario/package gates describe those checkpoints;
`release.json` and the current integration checkpoint define accepted status.

Native top-level roots may send the unchanged embed/2 control envelope through
the exact `agentic-os.native-control/1` port. Iframes and popup documents retain
real browser postMessage. Review origin/opener/source/proof checks are unchanged.
Actual native popup, separate owner ceremony, canonical committed receipts and
reconnect acceptance are recorded in the current integration checkpoint.

## Local operation

Keep all environments, owned databases, private configuration, keys, caches, temporary files and evidence on authorized SSD storage. Use the existing installer, target, capacity and migration guards. Never adopt a service because its port matches. The protected `poc-local-runtime/1` configuration has explicit paths and loopback origins; it contains private references and must not be committed.

`local_runtime.py --config PATH` runs one Core process with separate public, Host bootstrap and TLS private listeners. Three owned OPA processes and a separate locked SDK environment are required. The private role factory rejects native placement and local authority when selecting AWS. It rejects synthetic identity headers at the private listener. The local Host bridge alone handles synthetic native identity.

`checks/p0_read.py --config PATH --report PATH` exercises actual native sign-in, DPoP admission, one real Java lookup, scoped TLS identity negatives and canonical persisted completion. The process observation supplements SQL/public evidence; it never establishes completion.

`checks/p0_lifecycle.py --config PATH --report PATH` interrupts a real begun child through public Stop. After restarting Core, run the same command with `--after-restart`. It requires the original process epoch, one model operation, preserved UNKNOWN holds and denied stale executable input. An interrupted process is never automatically respawned. Exact original finish bookkeeping retains the existing accounting semantics and grants no new executable input or acceptance authority.

`checks/p0_sql.py --config PATH --report PATH` checks positive registration and relevant negative SQL/assignment guards, rolling back its test rows. Original task accounting, deadlines, UNKNOWN holds and Temporal dispatches must remain unchanged.

The fixed child uses a bounded parent-owned pipe for existing typed wait/resume control. A wake requires the original live SQL process binding and canonical accepted operation; it grants no task or effect authority. `checks/p0_read.py --expect-control-pause` proves one accepted-operation wake through a complete read. `checks/p2_parent_death.py interrupt` requires the exact owned Core identity and an explicit deterministic pause fixture, then terminates that Core while its child waits before any tool. After restarting the same configuration, `verify` checks child EOF exit, the original interrupted binding, failed task/closed Root, unchanged deadline and accounting, and preservation of preexisting UNKNOWN holds. It never starts a replacement child.

Local synthetic Host sessions survive a Core restart only through signed, private state bound to the same owned installation run, namespace and endpoints. Original expiry and current Host generation checks remain in force; restored or foreign installations cannot adopt these sessions.

`checks/rehearse.py` selects the existing protected populated rehearsal primitives. `prepare --source PATH --root NEW_PATH --revision REVISION` requires an idle populated adjacent predecessor and the source checkpoint matching that revision, then makes a distinct candidate. `recover --root PATH` verifies the exact predecessor from its authenticated snapshot. Neither operation alone accepts runtime behavior. Applied0099 through0105 and the two RDS component overlays are checksum-frozen after their respective protected runtime, SQL guards, forward/catalog and independent recovery evidence; subsequent SQL changes require an additive revision.

The canonical owner-amendment service is accepted locally with actual synthetic Host preparation, approval and one authoritative effect. Successor reviews preserve the original model preparation, Root and horizon, and retain separately governed owner input. The existing `agent.review` work kind has an explicit command-bound reservation group; generic compute stays prohibited during approval. Stale forms/challenges and altered SQL origin/work/input/version bindings are refused. This service/storage checkpoint does not accept the Verizon write wire, edit UI, SDK reviewed journey or native scenarios; those gates remain open. See `evidence/p2-review-backbone.json`.

## Boundaries

The SDK receives bounded stdin, an exact task/process-epoch token file and a verified private CA. It has MCP1.30.0 and no Core package; Core keeps MCP2.2.0. The direct provider enforces eight model calls across phases, sixteen tool calls and the original two-minute horizon. Checkpoints retain the original SDK serialization contract. No Temporal worker, native/VM execution, generated command or automatic uncertain provider retry is selected by this composition.

Production ancestry is preserved in the isolated source repository. Return upstream changes through reviewed commits/patches; never merge into the active authoritative checkout as an integration shortcut. The POC export must retain source/export revision mappings and conflict-safe synchronization. Actual AWS trust, deployment and real Verizon API qualification remain external and unqualified until their named acceptance gates run.


The installed Direct reviewed-change journey and trusted owner amendment UI are
accepted locally with deterministic inference. The separate SDK crosses actual
private TLS RPC and the existing two-Host review/assurance/effect path. A lost
edit reply recovers the original command; a separate fresh confirmation applies
one final change. History/reload, mobile layout and current-access withdrawal
are observed. The original preparation, Root and deadline remain unchanged;
known work settles and the Root closes with zero outstanding usage. Evidence:
`evidence/p2-reviewed-journey.json`. This is a Core integration prerequisite;
That prerequisite is now consumed by the canonical Verizon slice described below. Full scenarios and P1–P4 overall gates remain open.


`agentic_os.adapters.poc.effect_context` signs external effect contexts only
from the existing production permit service's current authority and RUNNING
work attempt. It validates the actual scoped bearer, maps the operator-pinned
registered form without adding defaults, hashes exact public arguments using
the accepted JCS implementation, and bounds expiry by the permit, original Root
and bearer. It allocates no task, key or receipt journal. All four argument
projections, actual owner-edited permit signing and unchanged Host receipt flow
are observed in `evidence/p2-effect-context.json`. This proves the Core signer
prerequisite. The actual canonical Verizon composition below now consumes it and the committed receipt lookup.


The canonical Direct read-schedule prerequisite is accepted locally. Explicit
`IdentityRuntime.enable_direct_schedules(local_synthetic=True, demo=...)` reuses
existing proactive definitions, immutable owner revisions, sealed delegations,
runs, task controls, budgets, dispatches and private notifications. It shares two
physical placement slots with installed SDK children and starts no Temporal or
native process. Normal polling is 60 seconds with 120 seconds late grace; explicit
local demo polling is 2 seconds with 10 seconds grace, visibly labelled in the UI.
A task deadline also ends by that occurrence's grace cutoff. Missed occurrences
have terminal MISSED metadata and no executable work, dispatch or result.

Current owner access and the exact approved revision are rechecked before reads
and publication. A delivered DUE launch can recover only its original identity
and deadline; a changed revision cancels before reading. A recovered RUNNING
identity is quarantined without replay or release of its unknown usage. Saved
read evidence is opened through fresh owner and original-source-scope checks,
without running another read. Actual UI create/review, lost reply recovery, due
read, source values/reload/mobile, inbox acknowledgement/removal and owner change
pass alongside the installed Direct reviewed SDK journey. Default admitted-read
semantics remain unchanged. Protected revision0101 and independent0100 recovery
are pinned by `evidence/p3-direct-schedules.json`.

This is the canonical two-Host read-scheduling foundation. Verizon capability
composition, complete memory/reflection, S4 and future
consequential delegation remain open, as do full P1/P2 and P4 packaging. The
current local P0 command does not yet assemble those full scenarios.

## Canonical keyword memory foundation

The explicitly selected `keyword-fts/1` index reuses canonical owner knowledge,
consent, contexts, encrypted revisions, publication generations and erasure
fences. It creates PostgreSQL word-search lexemes and a NULL embedding, never
an embedding client, model directory, process or fabricated vector. It offers
only lexical recall. The original offline minilm factory and normalized non-null
vector requirements remain the default; the RDS-exact overlay retains no ANN
index. Wrong profile/vector shapes and cross-owner writes are refused in SQL.

`enable_keyword_memory_component` requires an explicit owned local POC target
and private recovery directory. The existing owner Memory & privacy UI can save,
correct, forget and update search readiness, recover the exact command after a
lost reply, and inspect/recover an interrupted generation. A ready index alone
grants no disclosure authority. Source revision, owner, context and current
consent are checked again at hydration and publication; correction or erasure
invalidates old task readers, and revoked consent refuses publication without
changing original accounting.

The installed Direct worker accepts the existing memory read/response journeys
through the shared SDK implementation, private TLS RPC and canonical outbox.
The qualified synthetic response uses one real recall and two metered model
responses, persists its sourced answer, and closes the original Root with no
outstanding usage. The actual owner browser also checks mobile layout, two
lost-reply recoveries, correction/reindex/forget and account isolation. Evidence
and protected0102/RDS0002 plus independent0101/RDS0001 recovery are pinned in
`evidence/p3-keyword-memory.json`.

This accepts manual typed owner memory and its Direct recall foundation. POC
source labels, immutable source-turn links, directed remember, scoped standing
inference consent, reflection, full T7/S4 and final deployment remain open.

The owner can also inspect the exact commands behind manual saved/corrected
revisions in Memory origin & history. The bounded read returns revision metadata,
never old memory text. Forgotten entries expose no private command/source history;
other owners and revoked sessions are refused. The real owner browser covers
initial/corrected/forgotten history alongside installed Direct recall. Evidence
is pinned in `evidence/p3-memory-provenance.json`. Projection of existing learned
source origins is implemented, but actual no-embedding learned-source/agent-
inferred POC acceptance remains open. The inherited Mem0 extraction stage uses
a synthetic vector overlay and is not selected as the POC directed-remember or
inference write path.


The explicit `enable_directed_memory_component(local_synthetic=True)` composition
adds the owner-only “Remember selected message” action to completed production
tasks. It presents the exact original input and a typed editable memory. Saving
one entry does not enable conversation learning or recall. The canonical source
has a separate14-day expiry, a truthful `owner-directed-turn/1` origin and a
CANCELLED extraction intent; it launches no learning, model or embedding job.
Current recall consent remains separate. One source slot belongs to its original
save command/session and one entry; exact retries recover the same receipt and
expiry. A different save uses the existing memory's correction controls.

Correction, source history, entry/source erasure and task-derived cleanup reuse
the original canonical stores and journals. An entry deletion includes only its
exact retained source; an ordinary learning source for that same input retains
its own expiry and deletion command. Actual owner DPoP, private TLS and the
installed SDK verify the saved-source reply and unchanged original Root usage.
The real browser verifies lost-reply recovery, correction, source inspection,
forgetting, mobile layout, blocked storage and another owner's isolation.
Memory controls pause the task view's periodic memory read while they are open;
current identity and server checks remain active, with task validation resumed
on close. Direct dispatch consumes preparation time from its original absolute
horizon immediately before launch, preserving SQL deadline/lease checks.
Evidence: `evidence/p3-directed-memory.json`. Standing inference, reflection,
full Verizon composition/T7/S4 and P4 remain open.


Scoped inference is an explicitly selected local component over the existing owner settings, controls journal, finite learning jobs and supervised SDK lifecycle. The owner grants categories and purposes; one exact completed owner turn may produce one typed inferred ADD. A current standing grant publishes with its actual grant/source/job basis and no invented per-entry decision. Revocation blocks new publication while retaining stored entries; recall consent stays independent. Without standing consent automatic source selection is disabled, and ordinary explicitly selected proposals still require a real owner decision. Conflicts remain pending review. Physical source/derived erasure preserves unresolved usage holds. The fixed isolated SDK makes no embeddings, vector writes, tools or network calls; the metered parent supplies the one bounded model response. Actual provider qualification remains separate. Protected immutable104, independent103 recovery, real grant/revoke/lost-ACK, automatic recall, known/UNKNOWN, review fallback and mobile owner UI evidence are pinned in `evidence/p3-scoped-inference.json`. Full reflection/T7/S4 and P3 remain open.

The receipt-only coordination dependency is closed: committed MCP/backend artifacts,
agreed private observation wire, canonical mutation/MCP read-back and the original
School/Tom native visual chain are accepted below at their original revisions.
The newer created-place native read-back gate is separately manual, not a reopened
receipt contract gap. Public nine-tool descriptors and EffectCallContext/1 are unchanged.


The explicit `poc/review_runtime.py` local composition now completes one real canonical Verizon write through the installed isolated SDK. Actual native-style DPoP sign-in, a prepared Tom/School300m/BOTH proposal, owner450m/LEAVE_ONLY amendment, stale-confirmation refusal and a fresh independent owner ceremony lead to exactly one Java dispatch. The committed private peer observes the actual backend idempotency record; Core persists its correlated canonical COMMITTED projection, settles measured known work and closes the original Root with zero outstanding usage and the original deadline. Fresh MCP read-back matches. A later receipt-only observation after the original execution window preserves the same receipt identity and all accounting. Existing encrypted private-file primitives retain only the original transport arguments/correlation, never execution state or cached outcome authority. Missing/uncertain evidence never authorizes replay.

`checks/p2_verizon.py` is the explicit deterministic integration check, selected only through the guarded runner's `--poc-review-config` and exact integration case. It retains the original task on failure and refuses implicit readmission. The earlier missing read-only inspection branch failed before any effect; its expired task/closed Root/zero holds remain retained. Current evidence is `evidence/p2-verizon-canonical.json`. Native visual read-back of this exact rule is accepted at app0c524953. The later actual signed-WK review/receipt/close/reopen/account-isolation/reconnect/native-read-back checkpoint is accepted at app84ea5d2/packageb01cfee; see evidence/p2-native-review.json. Owner ceremony decisions and full S1–S5 remain separate. The earlier selected runtime exposes one CreateGeofence preparation lane. The separate runtime_family composition registers all five actual reads and four owner-reviewed preparations, with versioned source guidance and bounded table completion. Installed live quality acceptance remains open; reflection and the full configured P4 package remain open. This local adapter cannot select AWS identity.


P4 engineering now extracts the accepted local compositions into installed `agentic_os.adapters.poc.runtime_local` / `runtime_review`; the old script commands remain compatibility wrappers. Exact accepted default function ASTs, packaged contract bytes and hash-bound static entry selection pass8focused checks, including guarded reuse of unchanged dependency bytes after the one wheel-data metadata addition. The selected image entry is `python -I -B -m agentic_os.adapters.poc.entry --config PATH --config-sha256 SHA`. Static validation does not establish readiness. `poc/build_image.py` selects the existing release locks/capacity/archive primitives for one Core+SDK image with separate virtual environments, pinned OPA/process tools, frozen wheel-only dependency installation and actual pip install reports. Image/runtime/deployment acceptance is still pending; no AWS profile is enabled by this extraction.


The first installed Linux ARM64 image foundation is accepted in `evidence/p4-image-foundation.json`. Image e48e6998 contains CoreMCP2.2.0 and a separate SDK environment with MCP1.30.0/Agents0.19.4. With no product source mount, networking or writable root, the actual supervised SDK stage completes one fixture call, reports measured usage, erases its private work and observes zero network/embedding/vector activity. Exact dependency installation reports and installed notice inventories are retained; existing pinned supplemental notices cover tokenizers/flatbuffers. The OCI archive and every source/wheel/base/policy pin are verified. This accepts the image/stage foundation, not configured Core/Host/SQL, A1, full scenarios or final deployment-package readiness.


Preview-first workload retirement is implemented in `poc/pocctl.py` over original canonical stores and exact operator resource receipts. It refuses nonterminal/UNKNOWN/held work, changed account/EKS CA/namespace/resource UID and undrained pods. Explicit apply uses UID/resourceVersion preconditions and never deletes namespaces, databases, PVCs, Secrets, keys or evidence. Actual local original-fixture refusals and installed kubectl wire pass in `evidence/p4-teardown.json`; AWS identity/API execution remains unqualified. See `deploy/teardown.md`. The baseline has two older ACCEPTED tasks/ACTIVE Roots with zero outstanding, so it also correctly refuses retirement. The canonical Verizon task is independently CLOSED/settled. Full P4 remains open.


Installed image runtime qualification exposed a terminal child wait: real owner rejection closes the Root correctly but a waiting SDK is absent from the nonterminal controller scan. The Direct coordinator now selects only its exact owned live child bindings whose canonical task is terminal, sends the existing bounded stop frame, and joins with existing cancellation fallback. It changes no Root/work accounting or UNKNOWN state. Six focused stop-binding/default-Temporal/deadline/shared-slot prerequisites pass; rebuilt-image current owner rejection and prompt physical exit remain pending. The earlier duplicate preparation UNKNOWN and failed image aggregates remain retained.


The requested single canonical School write/authoritative receipt/MCP/native read-back chain is accepted from app evidence0c524953 after owner unlock. Core independently inspected the exact hashed School detail and rule-control PNGs: Tom450meters/leave-only/On/revision1, unchanged binary82d25e85, no additional business action. Full S1–S5/dynamic reasoning is still open.

Installed Linux imageff6fa7a0 from sourcee495404/Corewheel5e465685 and unchanged SDKa8c803fe now passes actual local Core/Host/privateTLS/ownedSQL/current-owner prior receipt read plus eligible Home/Tom preparation and real owner REJECT/exact retry. Task0eefa306 isFAILED/RootCLOSED/all known work settled/zeroheld/originaldeadline; one canonical terminal stop wakes the original SDK, whose normal stopped result is accepted and physical bindingEXITED. Actual process observation sees1Core/4OPA/0SDK/0Temporal/0native. No additional business effect or paid call. Prior accounting/deadlines and duplicate preparation UNKNOWN316202e8 remain unchanged. The first two image aggregates remain failed; full deployment/A1/current native popup and S1–S5 gates remain open. Exact pins and scope are `evidence/p4-image-runtime.json`. The immutable image remains running for the app owner's native embed/reconnect qualification; this metadata checkpoint does not change that tested artifact.

Configured A1 native bootstrap engineering uses `ConfiguredNativeBootstrap`
with the pinned `NativeHostVerifier`, separate TLS account-only observer and
an exact registered DPoP client profile. It rejects local headers, cookies,
foreign origins and other bearer roles before account/Core access. The actual
Core challenge, bootstrap ticket and one-use DPoP exchange remain authoritative.
Only finite signed Host session metadata is retained, bounded by the original
native JWT expiry and current Host generations; the native bearer is never
stored or forwarded. Every active session check observes the current backend
account. Independent private CA pins are mandatory for account and Core calls.
The configured runtime factory must explicitly wire this broker and its session
check; component checks alone do not establish a deployable A1 runtime or AWS
qualification. Local bootstrap remains exclusively in the local composition.

The A1 `ConfiguredFamilyHost` composes the shared VF read/preparation/effect
mappings without running the local Host constructor. Its private app has no
native bootstrap route; the separately returned public app accepts only the
approved native Host identity. Current account/Host scope checks, private CA
verification and disjoint execution/receipt keys remain explicit. Historical
receipt observation can issue only a fresh receipt-only workload credential;
it neither consults an expired owner session nor recreates execution scope.
The execution audience remains the frozen `[vf-mcp]` value. Backend credentials
are separate approved-provider projections, never the incoming native bearer.

Configured keyword memory, directed memory, scoped inference and due polling
now have an explicit `configured=True` placement. Selection requires the same
actual InstallationPorts on registry/store, an AWS installation, web PKI,
RDS-exact0.8.2 control adapter and isolated component ports. It rejects mixed
local/configured flags, another control-store binding and the legacy ANN
profile. The local selector retains its original manifest/profile checks.
These composition seams still require the complete configured factory,
operator preparation, readiness and package acceptance; they activate nothing
on their own and make no AWS qualification claim.

The native memory editor has an explicit Clear memory text action. It changes
only the editable draft and keeps the existing busy/recovery and exact-source
save checks. Automatic inference now requests the packaged closed
AgentKeywordInferenceReply shape through strict structured output; content and
source/category/claim authority are still independently checked by the isolated
SDK and Core. Numeric usage remains known even if the proposal is invalid.
The provider observation records only a proposal-schema validity boolean,
never private output content. The Responses shape follows the [official
structured-output contract](https://developers.openai.com/api/docs/guides/structured-outputs).

Private keyword-job recovery reconciles an expired original RUNNING lease before
any current account, session or source hydration. A begun call without canonical
usage stays OUTCOME_UNKNOWN; known usage stays known. Original lease, expiry,
source edges and foreground accounting remain unchanged; no inference is
replayed. Controlled connection/SQL failures keep due polling alive for this
same-record observation, while unexpected programming errors still terminate
it. The focused actual SQL/isolated-SDK recovery and normal publication/recall/
correction/erasure checks pass. These prerequisites do not promote the failed
Verizon inference or the unsaved native Remember attempt to acceptance.


Configured A1 entry engineering now selects `poc-configured-family-runtime/1`
through the installed hash-bound entry. `runtime_configured` assembles the actual
certified RDS-exact ports, configured Host/native broker, distinct signing roles,
private CA transports, existing OIDC review policy9, installed direct SDK and the
same family business graph used by local verification. Finite schedules bind the
same OIDC assurance explicitly. Only public Core binds outside loopback.
Worker RPC remains authenticated loopback TLS with a pinned CA and fixed Ed25519
identity. Current account checks reuse the exact configured private Host trust.
Serving requires pre-existing registered Host/OIDC profiles, installation keys
and both surviving memory recovery profiles; it cannot adopt absent journals.

The original cumulative allowance, Root observation and learning observation
implementations are now installed modules. Existing tools retain compatibility
imports. A1 launch requires explicit existing qualification controls, a new
observation report, capacity allocation and bundled pinned OPA bytes. It creates
no allowance, changes no inherited hold and performs no provider call at startup.
Fourteen affected funding safeguards and the physical-learning cleanup check
pass; configured input/namespace/key/CA/role and listener refusal checks pass.
All failed setup aggregates remain retained. This is engineering evidence, not
actual AWS qualification or complete package acceptance. The new shared factory
still needs installed runtime acceptance; topology, operator input assembly and
the rebuilt current Linux image remain separate open package exits.

The shared family composition selects the existing10000ms reviewed-effect work
envelope for both local and configured placements. The generic production
default remains20000ms. This reserves less work inside the original120s Root
after native editing and owner ceremony; it grants no extra time or authority.
The canonical ledger still requires the entire selected window before the
original grant expiry. Any ambiguous timeout remains UNKNOWN and can only be
observed, never automatically dispatched again.


### Optional local journey observations and inbox follow-up

`poc/checks/family_runtime.py --journey-observation /absolute/new-private-file.json`
opts this owned local runtime into bounded numeric diagnostics. The default
runtime has no capture route or client reporting. Enabled WebViews record Send,
admission, accepted meaningful rendering, trusted review/form rendering,
accepted tool-step completion and verified task completion on one WebView
monotonic clock. The `Server-Timing` header measures Core response-header time;
SSE body time, native automation and separate model/backend durations are not
that measurement. Review-window notifications are timed on receipt in the
conversation frame, including its next paint. Reports are untrusted diagnostics,
never completion, authority, accounting or cost evidence. No conversation text,
arguments, credentials or raw query URLs are captured. Identity/session teardown
clears the in-memory collector. Private capture is bounded and requires the
currently authenticated task owner. Preserve real failed reports and the sole
API ledger; instrumentation does not authorize an additional paid call.

An inbox result can be inspected through its original notification/run binding.
A matching reflection offers **Review this suggestion**. Clicking it rechecks
current owner/source/consent/version guards before filling a normal editable
composer draft. The user must Send and review the newly prepared exact change.
Inspecting a result or acknowledging an inbox entry never approves an effect.
This feature alone does not establish actual reflection-to-write acceptance or
compound saved-place/boundary creation.

Family preparation revision3 retains the original resource/version/fields and
adds a required nullable `remainingRequest`. Its closed operator-pinned schema
marks `agent-change-continuation/1`; that draft text never enters public MCP
arguments or grants. Revision1/2 pins remain available and unchanged. A matching
first review displays that requested work remains. Only a canonical COMPLETED,
SETTLED, COMMITTED first change can offer **Continue remaining request**. The
read-only follow-up re-observes the original provider receipt and reads its
actual affected resource under current access before drafting a fresh user
message. It requires a new Send and separate approval; it offers no atomic
two-effect commit, automatic retry or extension of the first Root. An uncertain
first change cannot continue. Actual compound native acceptance and missing-
detail clarification still require their own real integration evidence.


### Reviewed-change missing details (explicit profile2)

The selected Family runtime can opt into `change_clarification: true` with
`profile_revision: 2`, `table_revision: 3` and no legacy table2 selection. Its
reviewed harness revision2 uses a separately closed clarified-review wire.
Existing revision1 review/read profiles are loaded and compared byte-for-byte
when present; fresh installations do not invent historical profiles.

Missing required values produce one bounded plain-text question through the
existing private owner-input journal. The normal composer reply is an exact,
idempotent owner command on the same task, segment and original finite Root.
It supplies data for current reads and editable preparation; it cannot widen
capabilities, change the owner or renew the original120s horizon. One
clarification is supported per reviewed request. An incomplete or late reply
can require a fresh user request. No coordinates or other required values may
be invented. An accepted first effect still requires a fresh Send and separate
approval for its dependent continuation.

Additive control migration0105 extends only the two existing owner-reply SQL
harness predicates. Its new alternative requires reviewed harness revision2
and an exact settled encrypted `AgentChangeQuestion` in canonical `protected`
classification, on the same owner/Root/task/segment/epoch. All previous reply,
source, expiry, control, command and accounting predicates remain. Downgrade
refuses once a new question/reply exists; use protected forward recovery.
Migration104 is unchanged. Apply owned migrations explicitly through the
existing initialization/operator lifecycle, with no active execution.

Opt-in journey timing treats a rendered missing-detail question as meaningful
output. An authenticated task snapshot may carry a numeric accepted-tool hint;
its client arrival is an upper bound on tool-result observation, not the raw
backend completion instant. Independent Java/backend spans retain their own
clocks. Diagnostic failures preserve the ordinary response and never grant
execution or read source content.

The sole live-qualification ledger accepts its retained100/101/104USD ceilings
and the operator-selected cumulative120USD ceiling under the owner's November3
approval of all essential POC tests. It never raises a ledger automatically.
`RootAllowance.authorize_ceiling` is an explicit private operator amendment,
retaining all attempts, spend metadata and UNKNOWN holds. Normal Root
reservations remain500000micros; model/price/deadline bounds are unchanged.

Fresh A1 inputs can now explicitly enable `change_clarification: true` with immutable profile2/table3/read4-or-newer. The exported A1 example and initialization guide select it and require migration105. Omission preserves legacy behavior; conflicting populated profiles are refused. This configuration support is engineering, distinct from actual AWS/IdP qualification.

### Immutable table display mapping

Both local and A1 configuration accept the optional fixed mapping
`table_display_mapping: "vf.units-labelled/1"`, with clarification2/table3/read4
or newer enabled as above. It registers and selects read definition3 of
`poc-family-read/1`; exact original read2 and existing read1 bindings remain.
Omitting the setting retains the original read2 selection. The setting cannot
accept arbitrary columns, code, tool arguments or a model-supplied mapping.

For a newly admitted read3 task, the saved-location table header becomes
`Radius (meters)`. Verified row values, units, source references and all current
authorization checks are unchanged. Historical tasks retain their exact old
definition and original heading. No database migration, SDK change, Java change
or native rebuild is required. Install the qualified Core artifact before
selecting this configuration; do not change an active task or overwrite an
existing definition. Change the explicit configuration only at an idle operator
boundary, update its configured SHA pin, then reload the WebView and issue a
fresh read. A historical answer alone cannot demonstrate the new mapping.

T1 acceptance still requires actual before/after native table observation and
reload, the same native binary digest, exact source values and successful
current authorization. The focused configuration/rendering/SQL registration
proofs in `evidence/table-display-mapping-engineering.json` establish engineering
prerequisites only. Running AQ remains on its original installed artifact until
the native draft check releases the interaction window.
