"""Small real-HTTP synthetic client of existing bootstrap/DPoP/task APIs."""
import hashlib
import secrets
import time
from urllib.parse import urlsplit
from uuid import uuid4

from cryptography.hazmat.primitives.asymmetric import ec
import httpx
import jwt

from agentic_os.identity.proof import b64,thumbprint


class LocalClient:
    def __init__(self,origin,host_origin,*,subject='test-user-001',embed_ref='vf.poc.embed/1'):
        self.origin,self.host_origin,self.subject,self.embed_ref=origin,host_origin,subject,embed_ref
        self.key=ec.generate_private_key(ec.SECP256R1());public=self.key.public_key().public_numbers()
        self.jwk=dict(kty='EC',crv='P-256',x=b64(public.x.to_bytes(32,'big')),y=b64(public.y.to_bytes(32,'big')))
        self.http=httpx.Client(trust_env=False,follow_redirects=False,timeout=15)
        self.session=None

    def proof(self,method,path,nonce,token=None):
        claims=dict(jti=str(uuid4()),htm=method,htu=self.origin+urlsplit(path).path,iat=int(time.time()),nonce=nonce)
        if token is not None:claims['ath']=b64(hashlib.sha256(token.encode()).digest())
        return jwt.encode(claims,self.key,algorithm='ES256',headers={'typ':'dpop+jwt','jwk':self.jwk})

    def sign_in(self,*,native_origin_header=True):
        response=self.http.post(self.origin+'/os/embed/challenges',headers={'Origin':self.origin},json=dict(
            request=dict(embedRef=self.embed_ref,frameNonce=secrets.token_urlsafe(32),proofKeyThumbprint=thumbprint(self.jwk)),
            publicKey=self.jwk))
        response.raise_for_status();challenge=response.json()
        binding={k:challenge[k] for k in ('challengeId','embedRef','frameNonce','proofKeyThumbprint','expiresAt')}
        headers={'X-POC-Test-User':self.subject}
        if native_origin_header:headers['Origin']=self.host_origin
        response=self.http.post(self.host_origin+'/native/bootstrap',json=binding,headers=headers)
        response.raise_for_status();ticket=response.json()
        response=self.http.post(self.origin+'/os/embed/exchange',json=dict(challengeId=challenge['challengeId'],
            ticket=ticket['ticket'],proofRef='dpop-header'),headers={'Origin':self.origin,
                'DPoP':self.proof('POST','/os/embed/exchange',challenge['serverNonce'])})
        response.raise_for_status();self.session=response.json()
        return self

    def request(self,method,path,*,body=None):
        token=self.session['accessToken']
        response=self.http.request(method,self.origin+path,json=body,headers={'Origin':self.origin,
            'Authorization':'DPoP '+token,'DPoP':self.proof(method,path,self.session['serverNonce'],token)})
        response.raise_for_status()
        return response.json()

    def start(self,text,definition,*,revision=1):
        captured=self.request('POST','/os/inputs',body=dict(commandId=str(uuid4()),text=text))
        return self.request('POST','/os/tasks',body=dict(commandId=str(uuid4()),conversationId=None,
            intentRef=captured['intentRef'],artifactRefs=captured['artifactRefs'],definitionRef=definition,
            definitionRevision=revision,clientProfile='poc-frame/1'))

    def close(self):self.http.close()
