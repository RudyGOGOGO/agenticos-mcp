"""Qualification-only single SSE end during an already completed read replay.

Disabled unless an operator installs it with an exact private finite target.
Never applies to executing work, writes, human waits or another conversation.
It ends after an already validated event; normal cursor and fresh-state handling
remain in the real native WebView. No cursor/token/content is recorded.
"""
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import threading
import time
from uuid import UUID

from agentic_os.adapters.local.files import OwnershipError, private_read, private_write
from agentic_os.adapters.local.ownership import load_manifest, POC_PROFILE
from agentic_os.adapters.local.target import connect_owned
from agentic_os.contracts.canonical import canonical_bytes


def validate_target(value, now=None):
    clock=time.time() if now is None else now
    if (type(value) is not dict or set(value)!={'schema','authorization','subject','taskId','conversationId','expiresAtEpoch'}
            or value['schema']!='poc-native-stream-close/1'
            or type(value['expiresAtEpoch']) is not int or not 0<value['expiresAtEpoch']-clock<=900
            or set(value['subject'])!={'installationId','applicationId','tenantId','subjectId'}
            or value['subject']['subjectId']!='test-user-001'):
        raise ValueError('Exact finite synthetic replay target required')
    for item in [value['authorization'],value['taskId'],value['conversationId'],
                 value['subject']['installationId'],value['subject']['applicationId']]:
        if type(item) is not str or str(UUID(item))!=item:raise ValueError('Canonical target identity required')
    return deepcopy(value)


def qualify_completed_read(manifest, target):
    owned=load_manifest(manifest)
    if owned['profile']!=POC_PROFILE or owned['installationId']!=target['subject']['installationId']:
        raise ValueError('Owned POC installation required')
    subject=target['subject']
    with connect_owned(manifest) as db:
        if (db.execute("SELECT count(*) FROM os_direct_executions WHERE state IN ('STARTING','RUNNING')").fetchone()[0]
                or db.execute("SELECT count(*) FROM personal_learning_jobs WHERE state='RUNNING'").fetchone()[0]):
            raise ValueError('Qualification installation requires an idle owned runtime')
        row=db.execute("""SELECT t.state,t.conversation_id,r.state,r.outstanding,a.bot
            FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id
            JOIN os_admissions a ON a.task_id=t.id
            WHERE t.id=%s AND t.installation_id=%s AND t.application_id=%s
              AND t.tenant_id=%s AND t.subject_id=%s""",(target['taskId'],subject['installationId'],
                subject['applicationId'],subject['tenantId'],subject['subjectId'])).fetchone()
        effects=db.execute("SELECT count(*) FROM os_work_attempts WHERE task_id=%s AND kind='agent.effect'",
                           (target['taskId'],)).fetchone()[0]
    if (not row or row[0]!='COMPLETED' or str(row[1])!=target['conversationId'] or row[2]!='CLOSED'
            or not row[3] or any(type(v) is not int or v!=0 for v in row[3].values())
            or row[4]['capabilities']['allowedKinds']!=['read'] or effects):
        raise ValueError('Only a completed read-only Task with CLOSED zero-held Root is eligible')


class OneReplayEnd:
    def __init__(self,target,report,*,clock=time.time,monotonic=time.monotonic):
        self.target=validate_target(target,clock());self.report=Path(report)
        if not self.report.is_absolute() or self.report.exists():raise ValueError('Fresh protected probe report required')
        self.clock,self.monotonic=clock,monotonic;self.lock=threading.Lock();self.disabled=False
        self.value=dict(schema='poc-native-stream-close-observation/1',state='ARMED_COMPLETED_READ_ONLY',
            atUTC=datetime.now(timezone.utc).isoformat(),authorization=self.target['authorization'],
            taskId=self.target['taskId'],conversationId=self.target['conversationId'],
            expiresAtEpoch=self.target['expiresAtEpoch'],injectedEnds=0,requests=[],
            newTaskOrEffect=False,credentialOrRootRenewal=False,contentOrTokenRecorded=False)
        self.save()

    def save(self):
        private_write(self.report,canonical_bytes(self.value),replace=self.report.exists())

    def pause(self,event):
        with self.lock:
            if (self.disabled or self.clock()>=self.target['expiresAtEpoch'] or self.value['injectedEnds']
                    or event.get('taskId')!=self.target['taskId']
                    or event.get('event',{}).get('type')!='TEXT_MESSAGE_CONTENT'
                    or type(event.get('sequence')) is not int or event['sequence']<1):return False
            self.value.update(state='ONE_VALIDATED_EVENT_STREAM_END_INJECTED',injectedEnds=1,
                eventSequence=event['sequence'],eventType='TEXT_MESSAGE_CONTENT',faultMonotonicNs=int(self.monotonic()*10**9))
            try:self.save()
            except (OSError,OwnershipError):
                self.disabled=True;return False
            return True

    def http(self,method,path,*,cursor_present,status,started):
        targets={'/os/conversations/'+self.target['conversationId']+'/events':'events',
                 '/os/tasks/'+self.target['taskId']:'task-snapshot',
                 '/os/ui/tasks/'+self.target['taskId']+'/surface':'surface'}
        if method!='GET' or path not in targets:return
        with self.lock:
            if self.disabled or self.clock()>=self.target['expiresAtEpoch'] or len(self.value['requests'])>=128:return
            self.value['requests'].append(dict(route=targets[path],cursorPresent=bool(cursor_present),
                status=int(status),startedMonotonicNs=int(started*10**9),
                headersElapsedNs=max(0,int((self.monotonic()-started)*10**9))))
            try:self.save()
            except (OSError,OwnershipError):self.disabled=True


def install(manifest,target_file,report):
    """Call only from the owned qualification launcher before serving traffic."""
    target=validate_target(json.loads(private_read(Path(target_file),16384)))
    qualify_completed_read(Path(manifest),target)
    probe=OneReplayEnd(target,report)
    from agentic_os.production.presentation import ProductionPresentation
    from agentic_os.adapters.poc import runtime_local
    original_pause=ProductionPresentation.stream_paused;original_build=runtime_local.build_os_app
    def paused(self,event):
        # Every original human-wait/uncertainty boundary takes precedence.
        if original_pause(self,event):return True
        return probe.pause(event)
    def build(*args,**kwargs):
        app=original_build(*args,**kwargs)
        @app.middleware('http')
        async def observe(request,call_next):
            started=probe.monotonic();response=await call_next(request)
            probe.http(request.method,request.url.path,cursor_present=bool(request.query_params.get('cursor')),
                       status=response.status_code,started=started)
            return response
        return app
    ProductionPresentation.stream_paused=paused;runtime_local.build_os_app=build
    return probe
