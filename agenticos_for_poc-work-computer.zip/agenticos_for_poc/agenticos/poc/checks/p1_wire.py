#!/usr/bin/env python3
"""Full committed Java discovery and read wire; mutations require P2 permits."""
import argparse
import asyncio
from decimal import Decimal
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from agentic_os.adapters.local.files import private_read,private_write
from agentic_os.adapters.poc.mcp import POCMCP,POCToolError
from agentic_os.adapters.poc.external_json import external_sha256
from agentic_os.errors import OSErrorCode
from jsonschema import Draft202012Validator
import jwt


def decimals(value):
    if type(value) is float:return Decimal(str(value))
    if type(value) is dict:return {key:decimals(child) for key,child in value.items()}
    if type(value) is list:return [decimals(child) for child in value]
    return value


async def run(endpoint,key_file):
    contract=ROOT/'poc/contracts/tools.json';raw=contract.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='47769c9b308ed581c4e678fe569ad17e5b5a5ad0e9ac9cd4d984e0851225cf8e'
    expected=json.loads(raw)['tools'];key=private_read(key_file,4096)
    def token(*tools,subject='test-user-001'):
        now=int(time.time())
        return jwt.encode(dict(iss='vf-poc-local',aud=['vf-mcp'],sub=subject,client_id='core-poc',installation='vf-poc',
            application='verizon-family',environment='local',tools=list(tools),iat=now,exp=now+60),key,algorithm='HS256')
    client=POCMCP(endpoint);catalog=await client.request(token('LookupMemberByName'))
    assert catalog==expected
    fixtures=[('LookupMemberByName',dict(displayName='Tom')),
        ('GetLastKnownLocation',dict(memberId='member-tom')),('ListSavedLocations',{}),
        ('GetSavedLocationWithGeofences',dict(savedLocationId='sl-school')),
        ('GetSavedLocationWithGeofences',dict(savedLocationId='sl-home')),
        ('GetLocationHistory',dict(memberId='member-tom')),
        ('GetLocationHistory',dict(memberId='member-mia'))]
    reads=[]
    for tool,arguments in fixtures:
        result=await client.request(token(tool),tool=tool,arguments=arguments)
        schema=next(item['outputSchema'] for item in expected if item['name']==tool)
        Draft202012Validator(decimals(schema)).validate(decimals(result))
        reads.append(dict(tool=tool,arguments=arguments,result=result))
    lookup,last,locations,school,home,history,mia=[value['result'] for value in reads]
    assert lookup['members'][0]['memberId']=='member-tom'
    assert {item['id'] for item in locations['savedLocations']}=={'sl-school','sl-home'}
    assert school['geofences']==[] and len(home['geofences'])==1
    assert len(history['points'])==24 and history['truncated'] is False and mia['points']==[]
    latest=max(history['points'],key=lambda point:datetime.fromisoformat(point['recordedAt'].replace('Z','+00:00')))
    assert all(latest[field]==last[field] for field in ('latitude','longitude','recordedAt'))
    negatives=[]
    for tool,arguments,credential,expected_code in [
        ('GetLastKnownLocation',dict(memberId='member-mia'),token('LookupMemberByName'),'FORBIDDEN'),
        ('GetLastKnownLocation',dict(memberId='member-foreign'),token('GetLastKnownLocation'),'NOT_FOUND'),
        ('GetLastKnownLocation',dict(memberId='member-mia'),token('GetLastKnownLocation',subject='test-user-tom-only'),'FORBIDDEN'),
        ('GetLastKnownLocation',dict(memberId='member-tom',unexpected=True),token('GetLastKnownLocation'),'VALIDATION_ERROR'),
        ('CreateSavedLocation',dict(name='Wire refusal probe',latitude=40.1,longitude=-74.1),token('CreateSavedLocation'),'FORBIDDEN'),
        ('UpdateSavedLocation',dict(savedLocationId='sl-school',name='Wire refusal probe'),token('UpdateSavedLocation'),'FORBIDDEN'),
        ('CreateGeofence',dict(savedLocationId='sl-school',memberId='member-tom',radiusMeters=450,notificationType='BOTH'),token('CreateGeofence'),'FORBIDDEN'),
        ('UpdateGeofence',dict(savedLocationId='sl-home',geofenceId=home['geofences'][0]['id'],radiusMeters=450),token('UpdateGeofence'),'FORBIDDEN')]:
        try:await client.request(credential,tool=tool,arguments=arguments)
        except POCToolError as error:
            assert error.external['error']['code']==expected_code,(tool,error.external['error']['code'],expected_code)
            negatives.append(dict(tool=tool,externalCode=expected_code,httpStatus=error.metadata['httpStatus']))
        except OSErrorCode as error:
            assert expected_code=='VALIDATION_ERROR' and error.code=='INVALID'
            negatives.append(dict(tool=tool,phase='Core client schema validation',code='INVALID'))
        else:raise AssertionError('Unpermitted/invalid operation succeeded')
    current=await client.request(token('GetSavedLocationWithGeofences'),tool='GetSavedLocationWithGeofences',arguments=dict(savedLocationId='sl-school'))
    assert current==school
    return dict(schema='poc-full-java-wire/1',status='PASS',protocol='2025-11-25',
        descriptorSHA256=external_sha256(catalog),readResults=reads,negativeResults=negatives,
        mutations='All four refused before backend dispatch without canonical effect context; positive writes remain P2',
        P1='PARTIAL: full read/metadata wire accepted; canonical positive mutation wire still pending')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--endpoint',required=True);parser.add_argument('--key-file',type=Path,required=True)
    parser.add_argument('--report',type=Path,required=True);args=parser.parse_args()
    report=dict(schema='poc-full-java-wire/1',status='FAIL')
    try:report=asyncio.run(run(args.endpoint,args.key_file))
    except BaseException as error:report['failureType']=type(error).__name__;raise
    finally:private_write(args.report,json.dumps(report,indent=2).encode())
