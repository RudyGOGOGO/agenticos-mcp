#!/usr/bin/env python3
"""One real owner-amended canonical Verizon effect and fresh MCP read-back.

This is deterministic local integration evidence, not paid/dynamic planning or
native acceptance. A saved task admission refuses another run; uncertainty is
diagnosed using the original task and read-only observation, never a new send.
"""
import asyncio
from copy import deepcopy
import json
from pathlib import Path
import time
from uuid import UUID, uuid4

import httpx
import jwt

from agentic_os.adapters.local.files import private_read, private_write
from agentic_os.adapters.local.target import connect_owned
from agentic_os.adapters.poc.mcp import POCMCP
from agentic_os.adapters.poc.receipt_observation import ReceiptObservationClient, ReceiptWire
from poc.client import LocalClient


def run(value, report_path):
    report_path = Path(report_path)
    if report_path.exists():
        raise ValueError('Retain and inspect the original task evidence; never automatically readmit')
    manifest = Path(value['manifest'])
    report = dict(schema='poc-canonical-verizon-write/1', status='RUNNING',
        inference='Actual installed SDK with deterministic inference; no paid call',
        nativeReadBack='PENDING separate app-owned simulator check')
    def save():
        private_write(report_path, json.dumps(report, indent=2, default=str).encode(), replace=report_path.exists())
    client = LocalClient(value['public_origin'], value['host_origin'],
        embed_ref='vf.poc.embed/' + value['application_id']).sign_in(native_origin_header=False)
    try:
        review_profile = client.request('GET', '/os/ui/review-profile')
        assert review_profile['profileRef'] == 'agent-trusted-review/1'
        task = client.start('Add a School alert for Tom at 300 meters for both entering and leaving.',
            'poc-family-assistant/1', revision=2)
        report['task'] = task
        save()
        task_id = task['taskId']
        with connect_owned(manifest) as db:
            original = db.execute('SELECT t.deadline,t.budget_root_id FROM os_tasks t WHERE t.id=%s', (task_id,)).fetchone()
        report['originalDeadline'], report['rootId'] = original
        route = '/os/ui/agent-review/tasks/' + task_id
        deadline = time.monotonic() + 60
        while True:
            try:
                view = client.request('GET', route + '/review')
                break
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code not in {404, 409}:
                    raise
            if time.monotonic() >= deadline:
                report['lastStatus'] = client.request('GET', route)
                raise AssertionError('Original task did not reach trusted review')
            time.sleep(.2)
        assert view['canAmend']
        original_fields = {f['name']: f['value'] for f in view['proposal']['intent']['fields']}
        assert original_fields == dict(savedLocationId='sl-school', memberId='member-tom', radiusMeters=300,
            notificationType='BOTH', enabled=True)
        command = dict(commandId=str(uuid4()), taskId=task_id, reviewId=view['reviewId'],
            proposalDigest=view['proposal']['digest'], expectedTaskVersion=view['taskVersion'])
        assurance = json.loads(private_read(Path(value['reviewed_effect']['assurance_manifest']).parent
            / 'synthetic-assurance/config.json'))
        owner = next(v for v in assurance['owners'] if v['subject']['subjectId'] == 'test-user-001')
        def confirm(challenge):
            with httpx.Client(trust_env=False, timeout=5) as http:
                response = http.post('http://127.0.0.1:' + str(assurance['port']) + '/ceremony/confirm',
                    json=dict(challengeId=challenge['challenge']['id'], decision='approve'),
                    headers={'Authorization': 'Bearer ' + owner['ceremonyKey']})
                response.raise_for_status()
                return response.json()['assertionRef']
        old_challenge = client.request('POST', '/os/ui/agent-review/challenges', body=command)
        old_assertion = confirm(old_challenge)
        fields = deepcopy(view['proposal']['intent']['fields'])
        for field in fields:
            if field['name'] == 'radiusMeters':
                field['value'] = 450
            elif field['name'] == 'notificationType':
                field['value'] = 'LEAVE_ONLY'
        amendment = command | dict(commandId=str(uuid4()), fields=fields)
        changed = client.request('POST', '/os/ui/agent-review/amendments', body=amendment)
        assert client.request('POST', '/os/ui/agent-review/amendments', body=amendment) == changed
        stale = command | dict(commandId=str(uuid4()), challengeId=old_challenge['challenge']['id'],
            assertionRef=old_assertion, decision='approve')
        try:
            client.request('POST', '/os/ui/agent-review/decisions', body=stale)
        except httpx.HTTPStatusError as exc:
            assert exc.response.status_code == 409
        else:
            raise AssertionError('Stale owner confirmation was accepted')
        current = {k: changed[k] for k in ('taskId', 'reviewId', 'taskVersion')}
        command = dict(commandId=str(uuid4()), taskId=task_id, reviewId=current['reviewId'],
            proposalDigest=changed['proposal']['digest'], expectedTaskVersion=current['taskVersion'])
        challenge = client.request('POST', '/os/ui/agent-review/challenges', body=command)
        decision = command | dict(commandId=str(uuid4()), challengeId=challenge['challenge']['id'],
            assertionRef=confirm(challenge), decision='approve')
        acknowledged = client.request('POST', '/os/ui/agent-review/decisions', body=decision)
        assert client.request('POST', '/os/ui/agent-review/decisions', body=decision) == acknowledged
        report.update(originalReviewId=view['reviewId'], currentReviewId=changed['reviewId'],
            authoritativeOwnerFields=fields, staleConfirmationRefused=True, exactAmendmentAndDecisionRetry=True)
        save()
        deadline = time.monotonic() + 60
        while True:
            status = client.request('GET', route)
            state = status['snapshot']['taskState']
            if state in {'COMPLETED', 'FAILED', 'EXPIRED', 'CANCELLED', 'QUARANTINED'}:
                break
            if time.monotonic() >= deadline:
                break
            time.sleep(.2)
        report['canonicalStatus'] = status
        save()
        assert state == 'COMPLETED', state
        projection = status['receipt']
        assert projection['observation']['status'] == 'COMMITTED'
        with connect_owned(manifest) as db:
            deadline_task, deadline_root, root_state, spent, outstanding = db.execute(
                'SELECT t.deadline,r.deadline,r.state,r.spent,r.outstanding FROM os_tasks t '
                'JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=%s', (task_id,)).fetchone()
            attempts = db.execute('SELECT kind,state,actual FROM os_work_attempts WHERE task_id=%s ORDER BY kind', (task_id,)).fetchall()
            direct_id = db.execute('SELECT id FROM os_direct_executions WHERE task_id=%s', (task_id,)).fetchone()[0]
        assert deadline_task == deadline_root == original[0]
        assert root_state == 'CLOSED' and all(v == 0 for v in outstanding.values())
        assert all(v[1] == 'SETTLED' for v in attempts)
        assert len([v for v in attempts if v[0] == 'agent.effect']) == 1
        async def read_back():
            now = int(time.time())
            token = jwt.encode(dict(iss='vf-poc-local', aud=['vf-mcp'], sub='test-user-001', client_id='core-poc',
                installation='vf-poc', application='verizon-family', environment='local',
                tools=['GetSavedLocationWithGeofences'], iat=now, exp=now + 60),
                private_read(Path(value['mcp_key_file']), 4096), algorithm='HS256')
            return await POCMCP(value['mcp_url']).request(token, tool='GetSavedLocationWithGeofences',
                arguments=dict(savedLocationId='sl-school'))
        actual = asyncio.run(read_back())
        rules = [v for v in actual['geofences'] if v['memberId'] == 'member-tom']
        assert len(rules) == 1
        rule = rules[0]
        assert (rule['radiusMeters'], rule['notificationType'], rule['enabled'], rule['revision']) == (450, 'LEAVE_ONLY', True, 1)
        process_path = manifest.parent / 'direct-observations' / (str(direct_id) + '.json')
        for _ in range(40):
            if process_path.exists():
                break
            time.sleep(.05)
        process = json.loads(private_read(process_path))
        assert process['stateUpdateApplied'] is True
        assert process['processResult']['environment'] == dict(mcp='1.30.0', corePackageVisible=False, temporalDriverImported=False)
        report.update(status='PASS', freshMCPReadBack=actual, resourceId=rule['id'],
            originalRootClosed=True, zeroOutstanding=True, deadlinesPreserved=True, attempts=attempts, spent=spent,
            isolatedSDKObservation=process, dispatchCount=1, paidCalls=0,
            businessAndAccountingTruth='Normal controller observed authoritative receipt and measured known work')
        save()
        return report
    except BaseException as error:
        report.update(status='FAILED', failureType=type(error).__name__)
        if isinstance(error, httpx.HTTPStatusError):
            report['httpFailure'] = dict(status=error.response.status_code, safeBody=error.response.text[:1024])
        save()
        raise
    finally:
        client.close()
