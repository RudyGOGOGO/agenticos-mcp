#!/usr/bin/env python3
"""Actual public admission, isolated SDK, TLS RPC and Java P0 acceptance."""
import argparse
import json
from pathlib import Path
import ssl
import sys
import time
from uuid import uuid4

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from poc.client import LocalClient
from poc.local_runtime import configuration
from agentic_os.adapters.local.files import private_read,private_write
from agentic_os.adapters.local.target import connect_owned
from cryptography.hazmat.primitives import serialization
import httpx
import jwt


def run(value,report,*,expect_control_pause=False):
    manifest=Path(value['manifest'])
    client=LocalClient(value['public_origin'],value['host_origin']).sign_in()
    try:
        task=client.start('Look up Tom and show his display name and device ID.','poc-family-assistant/1',revision=2)
        report.update(task=task,transport='actual HTTP DPoP admission, TLS private RPC, separate locked SDK and Java MCP')
        task_id=task['taskId'];deadline=time.monotonic()+40
        with connect_owned(manifest) as db:
            original=db.execute('SELECT deadline FROM os_tasks WHERE id=%s',(task_id,)).fetchone()[0]
        while time.monotonic()<deadline:
            with connect_owned(manifest) as db:
                row=db.execute("SELECT c.request,e.epoch,e.execution_id FROM os_agent_model_calls c "
                    "JOIN os_agent_model_starts s ON s.id=c.id JOIN os_direct_executions e ON e.task_id=c.task_id "
                    "WHERE c.task_id=%s AND e.state='RUNNING' ORDER BY c.created_at LIMIT 1",(task_id,)).fetchone()
            if row:break
            time.sleep(.05)
        else:raise AssertionError('No actual assigned model start; inspect retained service/SQL state')
        request,epoch,execution_id=row
        key=serialization.load_pem_private_key(private_read(Path(value['signing_key_file'])),password=None)
        now=int(time.time())
        claims=dict(iss='poc-direct-core',aud='poc-direct-private',sub='poc-sdk',jti=str(uuid4()),iat=now,exp=now+60,
            profile='agent-direct-workload/1',taskId=task_id,executionId=execution_id,epoch=str(epoch))
        # The child already received its one-shot input. An exact duplicate
        # authenticates but must conflict rather than repeat a provider call.
        from agentic_os.adapters.poc.configuration import admission_profile
        _,meter=admission_profile(value['sdk_lock'])
        transport=dict(modelDigest=request['context']['model']['digest'],endpointRef=meter['model']['endpointRef'],
            credentialRef=meter['model']['credentialRef'],baseUrl='https://api.openai.com/v1',
            requestTimeoutMs=meter['requestTimeoutMs'],maxRequestBytes=meter['maxRequestBytes'],
            maxResponseBytes=meter['maxResponseBytes'],inferenceGeo=None)
        body=dict(request=request,transport=transport)
        cases=[('wrong-audience',dict(aud='other-private-service'),401),
            ('expired',dict(iat=now-120,exp=now-60),401),('wrong-task',dict(taskId=str(uuid4())),403),
            ('wrong-epoch',dict(epoch=str(uuid4())),403),('assigned-one-shot-replay',{},409)]
        checks={}
        with httpx.Client(verify=ssl.create_default_context(cafile=value['ca_file']),trust_env=False,timeout=5) as private:
            for name,changes,expected in cases:
                token=jwt.encode(claims|changes,key,algorithm='EdDSA',headers={'kid':'poc-direct-key/1'})
                response=private.post(value['private_origin']+'/private/agent/model/begin',json=body,
                    headers={'Authorization':'Bearer '+token})
                checks[name]=dict(status=response.status_code,code=response.json().get('code'))
                assert response.status_code==expected,(name,checks[name])
            response=private.post(value['private_origin']+'/private/agent/model/execute-native',json={})
            checks['native-role-absent']=dict(status=response.status_code)
            assert response.status_code==403
        with httpx.Client(trust_env=False,timeout=3) as public:
            for headers in ({},{'X-Forwarded-Host':'127.0.0.1:18883','X-Forwarded-Proto':'https'}):
                response=public.post(value['public_origin']+'/private/agent/model/begin',headers=headers,json={})
                assert response.status_code==404
        report['privateTLS']=checks
        deadline=time.monotonic()+75
        while time.monotonic()<deadline:
            with connect_owned(manifest) as db:
                state=db.execute('SELECT state FROM os_tasks WHERE id=%s',(task_id,)).fetchone()[0]
            if state in {'COMPLETED','FAILED','EXPIRED','CANCELLED','QUARANTINED'}:break
            time.sleep(.15)
        report['observedTaskState']=state
        report['snapshot']=client.request('GET','/os/tasks/'+task_id)
        assert state=='COMPLETED',state
        with connect_owned(manifest) as db:
            task_deadline,root_deadline,root_state,spent,outstanding=db.execute(
                'SELECT t.deadline,r.deadline,r.state,r.spent,r.outstanding FROM os_tasks t '
                'JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=%s',(task_id,)).fetchone()
            binding_id,process_state=db.execute('SELECT id,state FROM os_direct_executions WHERE task_id=%s',(task_id,)).fetchone()
            calls=db.execute('SELECT count(*) FROM os_agent_model_calls WHERE task_id=%s',(task_id,)).fetchone()[0]
            profile=db.execute('SELECT workflow_profile FROM os_dispatches WHERE task_id=%s',(task_id,)).fetchone()[0]
            attempts=db.execute('SELECT state,count(*) FROM os_work_attempts WHERE task_id=%s GROUP BY state',(task_id,)).fetchall()
        assert task_deadline==root_deadline==original
        assert root_state=='CLOSED' and all(v==0 for v in outstanding.values())
        assert profile=='OSAgentDirectDriver/1' and 1<=calls<=8
        assert not {'RUNNING','UNKNOWN'}&{s for s,_ in attempts}
        observation_path=manifest.parent/'direct-observations'/(str(binding_id)+'.json')
        for _ in range(40):
            if observation_path.exists():break
            time.sleep(.05)
        process=json.loads(private_read(observation_path))
        assert process['stateUpdateApplied'] is True
        result=process['processResult']
        assert result['environment']==dict(mcp='1.30.0',corePackageVisible=False,temporalDriverImported=False)
        assert result['toolCalls']==1 and result['modelCalls']==calls
        if expect_control_pause:
            assert value.get('control_pause_after_goal') is True
            assert process['channel']==dict(statusFrames=1,resumeCommands=1)
            report['canonicalControlWake']='PASS: one accepted-operation wake, no model replay or horizon extension'
        report.update(status='PASS',driverProfile=profile,originalDeadline=original.isoformat(),
            root=dict(state=root_state,spent=spent,outstanding=outstanding),workStates=dict(attempts),
            process=process,proof='persisted canonical completion and public snapshot; process observation is supplementary')
        return report
    finally:client.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True);parser.add_argument('--report',type=Path,required=True)
    parser.add_argument('--expect-control-pause',action='store_true')
    args=parser.parse_args();report=dict(schema='poc-direct-read-report/1',status='FAIL')
    try:run(configuration(args.config),report,expect_control_pause=args.expect_control_pause)
    except BaseException as error:
        report['failureType']=type(error).__name__
        raise
    finally:
        private_write(args.report,json.dumps(report,indent=2,default=str).encode())
