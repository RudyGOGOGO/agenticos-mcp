#!/usr/bin/env python3
"""Current installed-image prepare/owner-reject, with no product mutation.

An existing authoritative MCP read supplies an eligible resource. This is a
distinct owner-rejection case, never a retry of an UNKNOWN task or an execution.
"""
import argparse
import json
from pathlib import Path
import time
from uuid import uuid4

import httpx

from agentic_os.adapters.local.files import private_read, private_write
from agentic_os.adapters.local.target import connect_owned
from poc.client import LocalClient


def run(value, work):
    path = work / 'owner-reject.json'
    if path.exists():
        raise ValueError('Inspect the original admission; no implicit replacement')
    manifest = Path(value['manifest'])
    expected = {field['name']: field['value'] for field in value['reviewed_effect']['arguments']['fields']}
    eligibility = json.loads(private_read(work / 'eligible-read.json', 65536))
    if (expected['savedLocationId'] != eligibility['detail']['id']
            or expected['memberId'] != eligibility['selectedMember']['memberId']
            or any(g['memberId'] == expected['memberId'] for g in eligibility['detail']['geofences'])):
        raise ValueError('Actual current eligible resource read required')
    report = dict(schema='poc-image-owner-rejection/1', status='RUNNING',
        inference='Actual installed image SDK; deterministic fixture, no paid call', expectedFields=expected,
        productEffectsExpected=0, originalUnknownIsNotRetried=True)
    def save():
        private_write(path, json.dumps(report, indent=2, default=str).encode(), replace=path.exists())
    def originals():
        with connect_owned(manifest) as db:
            rows = db.execute('SELECT t.id,t.deadline,r.deadline,r.spent,r.outstanding FROM os_tasks t '
                'JOIN os_budget_roots r ON r.id=t.budget_root_id ORDER BY t.id').fetchall()
        return {str(row[0]): row[1:] for row in rows}
    before = originals(); report['originalAccountingBefore'] = before; save()
    client = LocalClient(value['public_origin'], value['host_origin'], embed_ref='vf.poc.embed/' + value['application_id'])
    try:
        client.sign_in(native_origin_header=False)
        original = client.request('GET', '/os/ui/agent-review/tasks/869e23c3-4d0b-4844-999d-91a634dbeee7')
        assert original['snapshot']['taskState'] == 'COMPLETED' and original['receipt']['observation']['status'] == 'COMMITTED'
        report['originalCanonicalHTTPRead'] = original; save()
        task = client.start('Prepare a Home alert for Tom at 300 meters for entering and leaving so I can review it.',
            'poc-family-assistant/1', revision=2)
        report['task'] = task; save()
        task_id = task['taskId']; route = '/os/ui/agent-review/tasks/' + task_id
        with connect_owned(manifest) as db:
            original_deadline = db.execute('SELECT deadline FROM os_tasks WHERE id=%s', (task_id,)).fetchone()[0]
        report['originalDeadline'] = original_deadline; save()
        until = time.monotonic() + 45
        while True:
            try:
                view = client.request('GET', route + '/review')
                break
            except httpx.HTTPStatusError as error:
                if error.response.status_code not in {404, 409}:
                    raise
            if time.monotonic() >= until:
                raise AssertionError('Original image task did not prepare')
            time.sleep(.2)
        report['preparedReview'] = view; save()
        assert {field['name']: field['value'] for field in view['proposal']['intent']['fields']} == expected
        command = dict(commandId=str(uuid4()), taskId=task_id, reviewId=view['reviewId'],
            proposalDigest=view['proposal']['digest'], expectedTaskVersion=view['taskVersion'])
        challenge = client.request('POST', '/os/ui/agent-review/challenges', body=command)
        assurance = json.loads(private_read(Path(value['reviewed_effect']['assurance_manifest']).parent
            / 'synthetic-assurance/config.json', 65536))
        owner = next(v for v in assurance['owners'] if v['subject']['subjectId'] == 'test-user-001')
        with httpx.Client(trust_env=False, timeout=5) as http:
            proof = http.post('http://127.0.0.1:' + str(assurance['port']) + '/ceremony/confirm',
                json=dict(challengeId=challenge['challenge']['id'], decision='reject'),
                headers={'Authorization': 'Bearer ' + owner['ceremonyKey']})
            proof.raise_for_status()
        decision = command | dict(commandId=str(uuid4()), challengeId=challenge['challenge']['id'],
            assertionRef=proof.json()['assertionRef'], decision='reject')
        accepted = client.request('POST', '/os/ui/agent-review/decisions', body=decision)
        assert client.request('POST', '/os/ui/agent-review/decisions', body=decision) == accepted
        report['ownerRejected'] = accepted; save()
        until = time.monotonic() + 45
        while True:
            status = client.request('GET', route); report['canonicalStatus'] = status; save()
            if status['snapshot']['taskState'] in {'FAILED', 'CANCELLED', 'COMPLETED', 'EXPIRED', 'QUARANTINED'}:
                break
            if time.monotonic() >= until:
                raise AssertionError('Original rejected task did not settle')
            time.sleep(.2)
        with connect_owned(manifest) as db:
            task_root = db.execute('SELECT t.state,t.deadline,r.state,r.deadline,r.spent,r.outstanding '
                'FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=%s', (task_id,)).fetchone()
            attempts = db.execute('SELECT kind,state,actual FROM os_work_attempts WHERE task_id=%s ORDER BY id', (task_id,)).fetchall()
            direct = db.execute('SELECT id,state FROM os_direct_executions WHERE task_id=%s', (task_id,)).fetchone()
        report.update(taskRoot=task_root, attempts=attempts, direct=direct); save()
        assert task_root[0] == 'FAILED' and task_root[2] == 'CLOSED'
        assert task_root[1] == task_root[3] == original_deadline
        assert all(v == 0 for v in task_root[5].values())
        assert all(v[1] in {'SETTLED', 'RELEASED'} for v in attempts)
        assert not any(v[0] == 'agent.effect' for v in attempts) and status['receipt'] is None
        process_path = manifest.parent / 'direct-observations' / (str(direct[0]) + '.json')
        for _ in range(50):
            if process_path.exists():
                break
            time.sleep(.1)
        process = json.loads(private_read(process_path, 1_048_576))
        report['isolatedSDKObservation'] = process; save()
        assert process['processResult']['environment'] == dict(mcp='1.30.0', corePackageVisible=False, temporalDriverImported=False)
        after = originals(); report['originalAccountingAfter'] = {key: after[key] for key in before}
        assert all(before[key] == after[key] for key in before)
        report.update(status='PASS', currentOwnerRejected=True, exactDecisionRetry=True, productEffects=0,
            zeroOutstanding=True, originalAccountingPreserved=True, paidCalls=0)
        save(); return report
    except BaseException as error:
        report.update(status='FAILED', error=type(error).__name__)
        if isinstance(error, httpx.HTTPStatusError):
            report['httpFailure'] = dict(status=error.response.status_code, safeBody=error.response.text[:1024])
        save(); raise
    finally:
        client.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', type=Path, required=True)
    args = parser.parse_args()
    result = run(json.loads(private_read(args.work / 'runtime.json', 65536)), args.work)
    print(json.dumps(dict(status=result['status'], taskId=result['task']['taskId'], productEffects=0)))
