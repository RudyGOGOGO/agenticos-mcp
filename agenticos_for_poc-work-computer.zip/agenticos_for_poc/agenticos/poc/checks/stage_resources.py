#!/usr/bin/env python3
"""Stage current package resources without rebuilding unchanged UI assets."""
from pathlib import Path
import hashlib
import shutil

ROOT=Path(__file__).resolve().parents[2]

def stage(root=ROOT):
    changed=0
    for name in ('migrations','deploy','policies'):
        source=root/name;target=root/'src/agentic_os'/name
        expected={p.relative_to(source) for p in source.rglob('*') if p.is_file() and p.suffix!='.pyc' and '__pycache__' not in p.parts}
        if target.is_symlink():raise ValueError('Resource destination must not be a symlink')
        if target.exists():
            for path in target.rglob('*'):
                if path.is_symlink():raise ValueError('Resource destination contains a symlink')
                if path.is_file() and path.relative_to(target) not in expected:
                    path.unlink();changed+=1
        for relative in sorted(expected):
            path=target/relative;raw=(source/relative).read_bytes()
            if path.exists() and path.read_bytes()==raw:continue
            path.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/relative,path);changed+=1
    # Only these reviewed runtime contracts enter the installed composition.
    # Fixtures/OpenAPI/evidence/secrets are not runtime authority or package data.
    contracts=root/'poc/contracts';target=root/'src/agentic_os/poc_contracts'
    expected={'tools.json','effect-context.schema.json','receipt-observation.schema.json'}
    if target.is_symlink():raise ValueError('Contract destination must not be a symlink')
    target.mkdir(exist_ok=True)
    for path in target.iterdir():
        if path.is_symlink() or not path.is_file():raise ValueError('Unexpected package contract entry')
        if path.name not in expected:path.unlink();changed+=1
    for name in sorted(expected):
        path=target/name;raw=(contracts/name).read_bytes()
        if path.exists() and path.read_bytes()==raw:continue
        shutil.copy2(contracts/name,path);changed+=1
    return changed

if __name__=='__main__':print({'stagedChangedFiles':stage(),'uiBuild':'not selected'})
