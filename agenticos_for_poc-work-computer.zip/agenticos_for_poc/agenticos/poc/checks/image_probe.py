#!/usr/bin/env python3
"""Run inside the built image without a source mount, network or task authority."""
import asyncio
import hashlib
from importlib import metadata, util
from importlib.resources import files
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
from uuid import uuid4

from agentic_os.adapters.mem0.stage import ExtractorReply
from agentic_os.adapters.poc.inference_stage import KeywordInferenceStage
from agentic_os.adapters.poc.effect_context import EffectContracts
from agentic_os.adapters.poc.receipt_observation import ReceiptWire
from agentic_os.adapters.poc import runtime_local, runtime_review
from agentic_os.adapters.poc.entry import bundled_opa


def inventory():
    packages = []
    for dist in metadata.distributions():
        notices = []
        for item in dist.files or []:
            name = Path(str(item)).name.lower()
            if name.startswith(('license', 'licence', 'copying', 'notice')):
                path = dist.locate_file(item)
                if path.is_file() and path.stat().st_size <= 2 * 1024**2:
                    content = path.read_bytes()
                    notices.append(dict(path=str(item), sha256=hashlib.sha256(content).hexdigest(), bytes=len(content)))
        packages.append(dict(name=dist.metadata['Name'], version=dist.version,
            license=dist.metadata.get('License-Expression') or dist.metadata.get('License'), notices=notices))
    return sorted(packages, key=lambda p: p['name'].lower())


def proposal(frame):
    return dict(operation='ADD', targets=[], sourceRefs=[{k: frame['sources'][0][k] for k in ('id', 'revision')}],
        content=dict(text='The owner generally prefers concise written summaries.', language='en',
            contextRef='general/1', validUntil=None, body=dict(kind='personal-context')))


class Provider:
    def __init__(self, frame):
        self.frame, self.calls = frame, 0

    async def complete(self, messages, *, profile, max_output_tokens):
        assert profile == 'keyword-inference/1' and max_output_tokens == 2048
        self.calls += 1
        assert json.loads(messages[1]['content'])['sources'] == self.frame['sources']
        return ExtractorReply(json.dumps(dict(candidates=[proposal(self.frame)])), 23, 17, 4)


def main():
    assert metadata.version('mcp') == '2.2.0'
    assert util.find_spec('agentic_os_agent_worker') is None
    contract_root = Path(str(files('agentic_os').joinpath('poc_contracts')))
    assert len(EffectContracts(contract_root).tools) == 9
    ReceiptWire(contract_root / 'receipt-observation.schema.json')
    assert Path(runtime_local.__file__).is_relative_to('/opt/agentic-os/core')
    assert Path(runtime_review.__file__).is_relative_to('/opt/agentic-os/core')
    sdk = '/opt/agentic-os/sdk/bin/python'
    code = ('import importlib.metadata as m,importlib.util as u,json;'
        'print(json.dumps(dict(mcp=m.version("mcp"),agents=m.version("openai-agents"),'
        'coreVisible=u.find_spec("agentic_os") is not None)))')
    isolated = json.loads(subprocess.check_output([sdk, '-I', '-B', '-c', code]))
    assert isolated == dict(mcp='1.30.0', agents='0.19.4', coreVisible=False)
    frame = dict(schema='OSKeywordMemoryInference/1', profile='keyword-inference/1', jobId=str(uuid4()),
        subject=dict(installationId=str(uuid4()), applicationId=str(uuid4()), tenantId='synthetic', subjectId='owner'),
        sources=[dict(id=str(uuid4()), revision=1, text='I normally want concise written summaries.')], approved=[],
        contexts=[], claimKeys=[], tools=[], contextRevision=1, learningEpoch=1,
        allowedCategories=['personal-context'], purpose='assistant.personalize/1', mode='extract', operations=[])
    with tempfile.TemporaryDirectory(prefix='poc-image-') as temporary:
        root = Path(temporary) / 'sdk'
        root.mkdir(mode=0o700)
        worker = KeywordInferenceStage(root, sdk_python=sdk, registry=SimpleNamespace())
        provider = Provider(frame)
        async def run():
            await worker.recover()
            return await worker.run(frame, provider)
        result = asyncio.run(run())
        assert result.state == 'SUCCEEDED' and result.candidates == (proposal(frame),), result
        assert result.provider_calls == provider.calls == 1
        assert result.cleanup_complete is True and worker.process_slots.active == 0
        assert worker.lifecycle.snapshot() == dict(active=0, held=0, queued=0)
        assert not list((root / 'work').iterdir())
        assert result.observed['embeddingCalls'] == result.observed['vectorWrites'] == result.observed['networkAttempts'] == 0
        assert not result.observed['corePackageVisible'] and not result.observed['temporalDriverImported']
        assert not result.observed['mem0Imported']
    policy = subprocess.check_output(['/opt/agentic-os/bin/opa', 'version'], text=True)
    assert 'Version: 1.21.1' in policy
    bundled_opa(Path('/tmp/uninitialized-manifest.json'), Path('/opt/agentic-os/bin/opa'), stage=False)
    subprocess.run(['ps', '-o', 'pid=,pgid=,rss=,lstart=,command=', '-p', str(__import__('os').getpid())],
        check=True, stdout=subprocess.DEVNULL)
    reports = {name: json.loads(Path('/release/' + name + '-dependencies.json').read_bytes()) for name in ('core', 'sdk')}
    for report in reports.values():
        assert report['version'] == '1' and report['install']
        assert all('sha256' in row['download_info']['archive_info']['hashes'] for row in report['install'])
    print(json.dumps(dict(schema='poc-image-probe/1', status='PASS', coreMCP='2.2.0', sdk=isolated,
        actualIsolatedSDK=result.observed, syntheticProviderCalls=provider.calls, syntheticReportedUsage=result.measured,
        privateSDKWorkErased=True, noTaskOrEffectAuthority=True, paidCalls=0, opa='1.21.1',
        dependencyInstallReports=reports, coreInstalledInventory=inventory(),
        qualification='Installed image/stage acceptance only; configured Core/Host/SQL/deployment remain separate')))


if __name__ == '__main__':
    main()
