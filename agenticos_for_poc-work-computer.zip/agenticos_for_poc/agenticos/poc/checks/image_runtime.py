#!/usr/bin/env python3
"""Own one local same-image runtime fixture over retained synthetic services.

The relay and Engine socket are local qualification inputs, never A1 placement.
This launcher observes process health only; canonical SQL/public results own
task, receipt and readiness evidence. It never dispatches a business operation.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
from uuid import uuid4

import httpx

from agentic_os.adapters.local.capacity import Capacity, GiB, owned_docker_headroom
from agentic_os.adapters.local.docker import DockerControl
from agentic_os.adapters.local.files import private_read, private_write
from agentic_os.adapters.local.ownership import POC_PROFILE
from agentic_os.adapters.local.target import validate_target


def run(manifest_path, work, capacity_root):
    manifest = validate_target(manifest_path)
    if manifest['profile'] != POC_PROFILE or manifest['ownerUid'] != os.getuid():
        raise ValueError('Exact owned local three-store fixture required')
    config = json.loads(private_read(work / 'runtime.json', 65536))
    inputs = json.loads(private_read(work / 'inputs.json', 65536))
    if (config['manifest'] != str(manifest_path) or config['schema'] != 'poc-reviewed-runtime/1'
            or hashlib.sha256(private_read(work / 'runtime.json', 65536)).hexdigest() != inputs['configurationSHA256']
            or inputs['privatePortPublished'] is not False or inputs['productSourceMounts'] != 0):
        raise ValueError('Prepared exact image fixture inputs required')
    for port in inputs['publicPorts']:
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', port))
    docker = DockerControl(manifest)
    nonce = uuid4().hex
    roles = {}; processes = []; stopping = False
    report = dict(schema='poc-installed-image-runtime/1', state='STARTING', fixtureOnly=True,
        image=inputs['image'], nonce=nonce, productSourceMounts=0, privatePortPublished=False,
        currentConfigurationSHA256=inputs['configurationSHA256'], containers=roles,
        readiness='Process health is not canonical task or deployment readiness')
    target = work / 'launch.json'
    if target.exists():
        raise ValueError('Retain and inspect the original launch; no silent replacement')
    def save():
        private_write(target, json.dumps(report, indent=2).encode(), replace=target.exists())
    def stop(*args):
        nonlocal stopping
        stopping = True
    def launch(role, options, command):
        labels = {'io.agentic-os.installation': manifest['installationId'],
            'io.agentic-os.component': 'p4-local-image-' + role, 'io.agentic-os.fixture': nonce}
        name = 'p4-image-' + nonce[:12] + '-' + role
        arguments = ['run', '-d', '--name', name]
        for key, value in labels.items():
            arguments += ['--label', key + '=' + value]
        arguments += ['--user', str(os.getuid()) + ':' + str(os.getgid()), '--read-only', '--cap-drop=ALL',
            '--security-opt=no-new-privileges', '--pids-limit=128', *options, inputs['image'], *command]
        ident = docker.command(*arguments, timeout=60).strip()
        if len(ident) != 64 or any(c not in '0123456789abcdef' for c in ident):
            raise ValueError('Unidentified image fixture container')
        roles[role] = dict(id=ident, name=name, labels=labels)
        save()
        actual = json.loads(docker.command('inspect', ident))[0]
        if (actual['Image'] != inputs['image'] or any(actual['Config']['Labels'].get(k) != v for k, v in labels.items())
                or not actual['State']['Running']):
            raise ValueError('Actual fixture identity/start differs')
        return ident
    save()
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, stop)
    with Capacity(capacity_root).reserve(GiB, purpose='artifact', docker_free=owned_docker_headroom(manifest_path), docker_peak=2 * GiB):
        try:
            helper = launch('relay', ['--network', 'bridge', '--memory=128m',
                '-p', '127.0.0.1:18910:23910', '-p', '127.0.0.1:18911:23911',
                '--mount', 'type=bind,src=' + str(work / 'relay.py') + ',dst=/fixture/relay.py,readonly',
                '--entrypoint', '/opt/agentic-os/core/bin/python'], ['-I', '-B', '/fixture/relay.py'])
            with (work / 'relay.log').open('wb') as log:
                docker_log = subprocess.Popen(['docker', 'logs', '-f', helper], env=docker.environment, stdout=log, stderr=log)
                processes.append(docker_log)
            time.sleep(.3)
            engine = manifest['dockerEndpoint'].removeprefix('unix://')
            mounts = [(Path(manifest['root']), Path(manifest['root']), False),
                (work, work, False), (Path(config['controls_file']).parent, Path(config['controls_file']).parent, True),
                (work / 'opa-linux-arm64', Path(manifest['root']) / 'dependencies/opa', False),
                (Path(engine), Path(engine), True)]
            options = ['--network', 'container:' + helper, '--memory=3g', '--group-add=0',
                '--tmpfs', '/tmp:rw,noexec,nosuid,size=134217728,mode=1777',
                '--env', 'PYTHONDONTWRITEBYTECODE=1', '--env', 'OPENAI_AGENTS_DISABLE_TRACING=1',
                '--env', 'HOME=' + str(Path(manifest['root']) / 'home'), '--workdir', str(work)]
            for source, destination, readonly in mounts:
                options += ['--mount', 'type=bind,src=' + str(source) + ',dst=' + str(destination) + (',readonly' if readonly else '')]
            core = launch('core', options, ['--config', str(work / 'runtime.json'),
                '--config-sha256', inputs['configurationSHA256']])
            with (work / 'core.log').open('wb') as log:
                docker_log = subprocess.Popen(['docker', 'logs', '-f', core], env=docker.environment, stdout=log, stderr=log)
                processes.append(docker_log)
            with httpx.Client(trust_env=False, timeout=1) as client:
                until = time.monotonic() + 45
                while True:
                    actual = json.loads(docker.command('inspect', core))[0]
                    if not actual['State']['Running']:
                        raise ValueError('Installed Core exited; private log retained')
                    try:
                        response = client.get(config['host_origin'] + '/health')
                        if response.status_code == 200:
                            report.update(state='LISTENING', hostHealth=response.json())
                            save(); print(json.dumps(dict(state='LISTENING', work=str(work), containers=roles)), flush=True)
                            break
                    except httpx.HTTPError:
                        pass
                    if time.monotonic() >= until:
                        raise ValueError('Installed Core health deadline exceeded')
                    time.sleep(.2)
            while not stopping:
                time.sleep(.5)
        except BaseException as error:
            report.update(state='FAILED', error=type(error).__name__); save()
            raise
        finally:
            for role in ('core', 'relay'):
                if role not in roles:
                    continue
                item = roles[role]
                actual = json.loads(docker.command('inspect', item['id']))[0]
                if (actual['Image'] != inputs['image'] or any(actual['Config']['Labels'].get(k) != v for k, v in item['labels'].items())):
                    raise ValueError('Fixture identity changed; no cleanup of an unverified resource')
                docker.command('stop', '--time', '20', item['id'], timeout=30)
                final = json.loads(docker.command('inspect', item['id']))[0]
                item.update(exitCode=final['State']['ExitCode'], stopped=not final['State']['Running'])
                docker.command('rm', item['id'])
            for process in processes:
                process.wait(5)
            if report['state'] != 'FAILED':
                report['state'] = 'STOPPED'
            save()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--capacity-root', type=Path, required=True)
    args = parser.parse_args()
    run(args.manifest, args.work, args.capacity_root)
