#!/usr/bin/env python3
"""Interrupt a real assigned child and retain its original UNKNOWN hold."""
import argparse
import json
from pathlib import Path
import ssl
import sys
import time
from uuid import uuid4

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from poc.client import LocalClient
from poc.local_runtime import configuration
from agentic_os.adapters.local.files import private_read,private_write
from agentic_os.adapters.local.target import connect_owned
from cryptography.hazmat.primitives import serialization
import httpx
import jwt


def binding(db,task):
    return db.execute('SELECT id,epoch,execution_id,state,owner_instance,deadline FROM os_direct_executions WHERE task_id=%s',
        (task,)).fetchone()


def refused(value,task,row,request):
    from agentic_os.adapters.poc.configuration import admission_profile
    _,meter=admission_profile(value['sdk_lock']);now=int(time.time())
    key=serialization.load_pem_private_key(private_read(Path(value['signing_key_file'])),password=None)
    token=jwt.encode(dict(iss='poc-direct-core',aud='poc-direct-private',sub='poc-sdk',jti=str(uuid4()),
        iat=now,exp=now+30,profile='agent-direct-workload/1',taskId=task,executionId=row[2],epoch=str(row[1])),
        key,algorithm='EdDSA',headers={'kid':'poc-direct-key/1'})
    transport=dict(modelDigest=request['context']['model']['digest'],endpointRef=meter['model']['endpointRef'],
        credentialRef=meter['model']['credentialRef'],baseUrl='https://api.openai.com/v1',requestTimeoutMs=5000,
        maxRequestBytes=65536,maxResponseBytes=8192,inferenceGeo=None)
    with httpx.Client(verify=ssl.create_default_context(cafile=value['ca_file']),trust_env=False,timeout=3) as client:
        response=client.post(value['private_origin']+'/private/agent/model/begin',
            headers={'Authorization':'Bearer '+token},json=dict(request=request,transport=transport))
    assert response.status_code==403,response.status_code
    return dict(status=403,code=response.json()['code'])


def run(value,report,*,restart=False,resume=False):
    manifest=Path(value['manifest']);client=LocalClient(value['public_origin'],value['host_origin']).sign_in()
    try:
        if restart or resume:
            task=report['task']['taskId']
        else:
            task_record=client.start('Look up Tom; this synthetic task tests owner Stop.','poc-family-assistant/1',revision=2)
            report['task']=task_record;task=task_record['taskId']
        limit=time.monotonic()+20
        while time.monotonic()<limit:
            with connect_owned(manifest) as db:
                row=binding(db,task)
                started=db.execute('SELECT c.request FROM os_agent_model_calls c JOIN os_agent_model_starts s ON s.id=c.id '
                    'WHERE c.task_id=%s ORDER BY c.created_at LIMIT 1',(task,)).fetchone()
            if row and started:break
            time.sleep(.02)
        else:raise AssertionError('No actual assigned child/model start')
        if not restart:
            if not resume:
                assert row[3]=='RUNNING'
                report['originalBinding']=list(map(str,row))
                client.request('POST','/os/tasks/'+task+'/cancel',body=dict(commandId=str(uuid4()),expectedControlVersion=1))
            limit=time.monotonic()+40
            while time.monotonic()<limit:
                with connect_owned(manifest) as db:
                    row=binding(db,task)
                    states=dict(db.execute('SELECT state,count(*) FROM os_work_attempts WHERE task_id=%s GROUP BY state',(task,)).fetchall())
                if row[3]=='INTERRUPTED' and states.get('UNKNOWN',0)>0 and not states.get('RUNNING',0):break
                time.sleep(.1)
            else:raise AssertionError('Stop did not fence child and retain uncertainty')
        else:
            assert row[3]=='INTERRUPTED'
            original=report['originalBinding']
            assert all(str(row[index])==original[index] for index in (0,1,2,4,5))
        with connect_owned(manifest) as db:
            task_state,root_state,deadline,outstanding=db.execute('SELECT t.state,r.state,r.deadline,r.outstanding '
                'FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=%s',(task,)).fetchone()
            attempts=dict(db.execute('SELECT state,count(*) FROM os_work_attempts WHERE task_id=%s GROUP BY state',(task,)).fetchall())
            counts=dict(modelCalls=db.execute('SELECT count(*) FROM os_agent_model_calls WHERE task_id=%s',(task,)).fetchone()[0],
                executions=db.execute('SELECT count(*) FROM os_direct_executions WHERE task_id=%s',(task,)).fetchone()[0])
        assert task_state=='RECONCILING' and root_state=='ACTIVE'
        assert attempts.get('UNKNOWN',0)>0 and any(outstanding.values()) and counts==dict(modelCalls=1,executions=1)
        assert str(deadline)==report['originalBinding'][5]
        result=dict(taskState=task_state,rootState=root_state,workStates=attempts,outstanding=outstanding,
            counts=counts,staleAssignedToken=refused(value,task,row,started[0]))
        if restart:
            assert counts==report['interruption']['counts'] and outstanding==report['interruption']['outstanding']
            report.update(restart=result,status='PASS')
        else:report.update(interruption=result,status='AWAITING_RESTART_CHECK')
        report['snapshot']=client.request('GET','/os/tasks/'+task)
    finally:client.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True);parser.add_argument('--report',type=Path,required=True)
    parser.add_argument('--after-restart',action='store_true')
    parser.add_argument('--resume-from',type=Path);args=parser.parse_args()
    if args.after_restart and args.resume_from:parser.error('Select one retained continuation')
    report=(json.loads(private_read(args.resume_from or args.report)) if args.after_restart or args.resume_from
        else dict(schema='poc-child-lifecycle-report/1',status='FAIL'))
    report.pop('failureType',None)
    try:run(configuration(args.config),report,restart=args.after_restart,resume=args.resume_from is not None)
    except BaseException as error:
        report.update(status='FAIL',failureType=type(error).__name__);raise
    finally:private_write(args.report,json.dumps(report,indent=2,default=str).encode(),replace=args.report.exists())
