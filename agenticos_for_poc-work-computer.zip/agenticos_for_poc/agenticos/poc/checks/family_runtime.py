#!/usr/bin/env python3
"""Explicit installed family qualification with the owner's existing allowance.

This operator is not a product task journal. Core alone owns Tasks, original
Root deadlines, provider observations, usage and publication. Never creates a
ledger or releases an inherited reservation, even after process loss.
"""
import argparse
import asyncio
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
from uuid import UUID

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import live_outcome as live

from sqlalchemy import select
from agentic_os.adapters.local.files import private_read,private_write
from agentic_os.adapters.local.capacity import Capacity,GiB
from agentic_os.adapters.postgres.models import BudgetRoot,AgentModelCall,AgentModelFinish
from agentic_os.adapters.postgres.store import ControlStore
from agentic_os.adapters.poc import runtime_family as family
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.identity.context import timestamp,utcnow


from agentic_os.adapters.poc.root_qualification import QualificationAllowance


def selected_controls(path):
    settings=live.controls(path)
    if settings['profile'] not in {live.LOOKUP_PROFILE,live.ANALYSIS_PROFILE}:
        raise ValueError('One finite Family lookup or analysis qualification profile required')
    meter,privacy=live.selected_model_profile(settings,journey='analysis' if settings['profile']==live.ANALYSIS_PROFILE else 'lookup')
    if live.root_ceiling(meter)!=live.ROOT_CEILING:
        raise ValueError('Family qualification retains the original 0.50 USD Root ceiling')
    return settings,meter,privacy


def prepare_configuration(base,controls,output):
    """Create a separate runtime selection. Never edit an existing profile or ledger."""
    value=family.configuration(base)
    settings,meter,privacy=selected_controls(controls)
    if output.exists():
        raise ValueError('Select a new private runtime configuration path')
    base_meter=private_read(Path(value['live']['meter_file']),65536)
    base_provider=parse_canonical_json(base_meter)['model']['provider']
    if base_provider==meter['model']['provider']=='openai':
        # The preserved OpenAI base keeps its immutable definition namespace.
        if base_meter!=canonical_bytes(meter) or private_read(Path(value['live']['privacy_file']),65536)!=canonical_bytes(privacy):
            raise ValueError('Use the original Family base and matching OpenAI model/account policy')
    else:
        for name,document in (('meter',meter),('privacy',privacy)):
            target=output.with_name(output.name+'.'+name+'.json')
            private_write(target,canonical_bytes(document))
            value['live'][name+'_file']=str(target)
    value['live']['credential_file']=settings['credentialFile']
    private_write(output,canonical_bytes(value))


async def run(args):
    value=family.configuration(args.config)
    settings,meter,privacy=selected_controls(args.live_controls)
    if (value['live']['credential_file']!=settings['credentialFile']
            or private_read(Path(value['live']['meter_file']),65536)!=canonical_bytes(meter)
            or private_read(Path(value['live']['privacy_file']),65536)!=canonical_bytes(privacy)):
        raise ValueError('Exact existing approved model/privacy/credential controls required')
    allowance=QualificationAllowance(settings,Path(value['manifest']),args.allowance_report)
    learning=None
    if value.get('inference'):
        from poc_learning_allowance import LearningQualification
        learning=LearningQualification(allowance.allowance,allowance.store,
            args.allowance_report.with_name(args.allowance_report.stem+'-learning.json'))
    async def compose(configuration,pins,tokens):
        options=dict(reserve_root=allowance.reserve)
        if learning is not None:
            from agentic_os.adapters.poc.keyword_provider import QualifiedKeywordProvider
            async def reserve_job(binding,meter):
                if settings.get('verificationRootLimit') is not None:
                    from agentic_os.errors import OSErrorCode
                    raise OSErrorCode('PROFILE_DISABLED')
                return await learning.reserve(binding,meter)
            options['inference_provider']=QualifiedKeywordProvider(meter=meter,
                credential=lambda:live.credential(Path(settings['credentialFile']),provider=meter['model']['provider']),
                reserve_job=reserve_job,observe=learning.observe,local_synthetic=True)
        result=await family.compose(configuration,pins,tokens,**options)
        if args.journey_observation is not None:
            from agentic_os.adapters.poc.journey_observation import JourneyObservations
            result[0].journey_observations=JourneyObservations(args.journey_observation)
        if learning is not None:learning.stage=result[0].inference_jobs.stage
        return result
    async def observer():
        while True:
            await allowance.settle()
            if learning is not None:await learning.settle()
            await asyncio.sleep(1)
    monitor=asyncio.create_task(observer())
    server=asyncio.create_task(family.base.serve(value,composer=compose,policies=family.policies))
    try:
        done,_=await asyncio.wait((monitor,server),return_when=asyncio.FIRST_COMPLETED)
        for task in done:await task
    finally:
        # Installed runtime performs its normal bounded shutdown. No model
        # replay, accounting repair or Root reopening occurs here.
        for task in (server,monitor):
            if not task.done():task.cancel()
        await asyncio.gather(server,monitor,return_exceptions=True)
        await allowance.settle(closing=True)
        if learning is not None:await learning.settle(closing=True)
        allowance.store.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--live-controls',type=Path,required=True)
    parser.add_argument('--prepare-provider-config',type=Path,help='Write a new private provider configuration, then exit without serving')
    parser.add_argument('--allowance-report',type=Path)
    parser.add_argument('--capacity-root',type=Path)
    parser.add_argument('--journey-observation',type=Path,help='New private bounded numeric timing report; no authority or content')
    args=parser.parse_args()
    if args.prepare_provider_config is not None:
        if any(not path.is_absolute() for path in (args.config,args.live_controls,args.prepare_provider_config)):
            parser.error('Absolute private configuration paths required')
        prepare_configuration(args.config,args.live_controls,args.prepare_provider_config)
        return
    if any(path is None or not path.is_absolute() for path in (args.config,args.live_controls,args.allowance_report,args.capacity_root)):
        raise ValueError('Explicit protected operator paths required')
    with Capacity(args.capacity_root).reserve(2*GiB,purpose='verification'):
        asyncio.run(run(args))


if __name__=='__main__':main()
