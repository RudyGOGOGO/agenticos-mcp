#!/usr/bin/env python3
"""Owned Core death during a real SDK pause; verify EOF and no replacement."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from poc.client import LocalClient
from poc.local_runtime import configuration
from agentic_os.adapters.local.files import private_read,private_write
from agentic_os.adapters.local.target import connect_owned


def process(pid):
    result=subprocess.run(['ps','-p',str(pid),'-o','uid=','-o','lstart=','-o','command='],capture_output=True,text=True)
    fields=result.stdout.strip().split(None,6)
    if result.returncode or len(fields)!=7:return None
    return dict(pid=pid,uid=int(fields[0]),started=' '.join(fields[1:6]),command=fields[6])


def same_process(identity):return process(identity['pid'])==identity


def unknown(db):
    return [[str(row[0]),row[1],row[2]] for row in db.execute('SELECT r.id,r.outstanding,r.spent FROM os_budget_roots r '
        "WHERE EXISTS(SELECT 1 FROM os_work_attempts w WHERE w.root_id=r.id AND w.state='UNKNOWN') ORDER BY r.id").fetchall()]


def owned_core(value,config_path):
    observed=json.loads(private_read(Path(value['manifest']).parent/'composition-observation.json'))
    identity=process(observed['pid'])
    if (identity is None or identity['uid']!=os.getuid() or observed['driverProfile']!='OSAgentDirectDriver/1'
            or 'poc/local_runtime.py --config '+str(config_path) not in identity['command']):
        raise ValueError('Exact owned Core identity required; no signal sent')
    cwd=subprocess.check_output(['lsof','-a','-p',str(identity['pid']),'-d','cwd','-Fn'],text=True)
    if 'n'+str(ROOT)+'\n' not in cwd:raise ValueError('Owned Core checkout differs; no signal sent')
    return identity


def interrupt(value,config_path,log,report):
    if value.get('control_pause_after_goal') is not True:raise ValueError('Explicit deterministic pause fixture required')
    parent=owned_core(value,config_path);manifest=Path(value['manifest'])
    client=LocalClient(value['public_origin'],value['host_origin']).sign_in()
    try:
        task=client.start('Synthetic parent-loss control test before the first tool.','poc-family-assistant/1',revision=2)
        report.update(parent=parent,task=task)
        deadline=time.monotonic()+30
        marker='Direct child wait observed: task='+task['taskId']+' status=waiting-reconciliation'
        while time.monotonic()<deadline:
            if marker in log.read_text():break
            time.sleep(.02)
        else:raise AssertionError('No actual child pause observed; Core was not signalled')
        with connect_owned(manifest) as db:
            before=db.execute('SELECT t.state,t.deadline,r.spent,r.outstanding FROM os_tasks t '
                'JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=%s',(task['taskId'],)).fetchone()
            binding=db.execute('SELECT id,epoch,execution_id,owner_instance FROM os_direct_executions WHERE task_id=%s',
                (task['taskId'],)).fetchone()
            models=db.execute('SELECT count(*) FROM os_agent_model_calls WHERE task_id=%s',(task['taskId'],)).fetchone()[0]
            tools=db.execute('SELECT count(*) FROM os_agent_tool_calls c JOIN os_work_attempts w ON w.id=c.attempt_id '
                'WHERE w.task_id=%s',(task['taskId'],)).fetchone()[0]
            original_unknown=unknown(db)
        assert models==1 and tools==0 and all(number==0 for number in before[3].values())
        rows=subprocess.check_output(['ps','-axo','pid=,ppid='],text=True).splitlines()
        children=[process(int(row.split()[0])) for row in rows if len(row.split())==2 and int(row.split()[1])==parent['pid']]
        opa=[];sdk=[]
        for child in children:
            if child is None or child['uid']!=os.getuid():raise ValueError('Unowned child; no signal sent')
            if child['command'].startswith(str(manifest.parent/'dependencies/opa')+' '):opa.append(child)
            elif child['command'].startswith(value['sdk_python']+' -I -m agentic_os_agent_worker.direct_driver'):sdk.append(child)
            else:raise ValueError('Unexpected Core child; no signal sent')
        assert len(opa)==3 and len(sdk)==1
        if not same_process(parent):raise ValueError('Core identity changed; no signal sent')
        report.update(binding=list(map(str,binding)),originalDeadline=str(before[1]),spent=before[2],
            originalUnknown=original_unknown,children=children)
        os.kill(parent['pid'],signal.SIGKILL)
        deadline=time.monotonic()+8
        while time.monotonic()<deadline and same_process(sdk[0]):time.sleep(.05)
        child_exited=not same_process(sdk[0])
        # Only children captured from this exact parent are eligible. No
        # listener/port-based adoption or shared-service cleanup is used.
        for child in opa:
            if same_process(child):os.kill(child['pid'],signal.SIGTERM)
        assert child_exited,'SDK did not exit on parent pipe EOF; no replacement was started'
        report.update(status='AWAITING_RESTART_CHECK',sdkEOFExit='PASS',knownBeforeDeath=dict(modelCalls=models,toolCalls=tools))
    finally:client.close()


def verify(value,config_path,report):
    parent=owned_core(value,config_path)
    assert parent!=report['parent']
    manifest=Path(value['manifest']);task=report['task']['taskId'];deadline=time.monotonic()+12
    while time.monotonic()<deadline:
        with connect_owned(manifest) as db:
            row=db.execute('SELECT t.state,t.deadline,r.state,r.spent,r.outstanding FROM os_tasks t '
                'JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=%s',(task,)).fetchone()
        if row[0]=='FAILED':break
        time.sleep(.1)
    with connect_owned(manifest) as db:
        binding=db.execute('SELECT id,epoch,execution_id,owner_instance,state FROM os_direct_executions WHERE task_id=%s',(task,)).fetchone()
        calls=db.execute('SELECT count(*) FROM os_agent_model_calls WHERE task_id=%s',(task,)).fetchone()[0]
        work=dict(db.execute('SELECT state,count(*) FROM os_work_attempts WHERE task_id=%s GROUP BY state',(task,)).fetchall())
        assert unknown(db)==report['originalUnknown']
    assert list(map(str,binding[:4]))==report['binding'] and binding[4]=='INTERRUPTED'
    assert row[0]=='FAILED' and row[2]=='CLOSED' and str(row[1])==report['originalDeadline']
    assert row[3]==report['spent'] and all(number==0 for number in row[4].values()) and calls==1
    assert not {'RUNNING','UNKNOWN'}&set(work)
    client=LocalClient(value['public_origin'],value['host_origin']).sign_in()
    try:report['snapshot']=client.request('GET','/os/tasks/'+task)
    finally:client.close()
    report.update(status='PASS',restart=dict(parent=parent,taskState=row[0],rootState=row[2],modelCalls=calls,
        bindingState=binding[4],outstanding=row[4],workStates=work,originalUnknown='unchanged'))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['interrupt','verify']);parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--core-log',type=Path);parser.add_argument('--report',type=Path,required=True);args=parser.parse_args()
    if args.command=='interrupt' and args.core_log is None:parser.error('Explicit owned Core log required')
    value=configuration(args.config);report=(json.loads(private_read(args.report)) if args.command=='verify'
        else dict(schema='poc-parent-death-report/1',status='FAIL'))
    try:
        if args.command=='interrupt':interrupt(value,args.config,args.core_log,report)
        else:verify(value,args.config,report)
    except BaseException as error:report.update(status='FAIL',failureType=type(error).__name__);raise
    finally:private_write(args.report,json.dumps(report,indent=2,default=str).encode(),replace=args.report.exists())
