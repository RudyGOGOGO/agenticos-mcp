#!/usr/bin/env python3
"""Observe installed kubectl DeleteOptions against an owned loopback fixture.

This checks the actual operator wire, not AWS identity/TLS or a real deletion.
"""
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
import threading
from uuid import uuid4

from agentic_os.adapters.local.files import private_directory, private_write, OwnershipError
from agentic_os.adapters.poc.teardown import OperatorKubernetes


def run(work, report_path, kubectl):
    if report_path.exists():
        raise ValueError('Retain the original transport evidence')
    private_directory(work)
    uid = str(uuid4()); seen = []
    report = dict(schema='poc-kubectl-precondition-transport/1', status='RUNNING', observed=seen,
        awsCalls=0, cloudOrProductResources=0,
        scope='Actual installed kubectl to synthetic loopback HTTP; no AWS/TLS/authorization acceptance')
    def save():
        private_write(report_path, json.dumps(report, indent=2).encode(), replace=report_path.exists())
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass
        def do_DELETE(self):
            raw = bytearray()
            if self.headers.get('Transfer-Encoding') == 'chunked':
                while True:
                    size = int(self.rfile.readline(128).split(b';')[0], 16)
                    if size == 0:
                        assert self.rfile.readline(128) == b'\r\n'
                        break
                    assert size <= 65536 and len(raw) + size <= 65536
                    raw.extend(self.rfile.read(size))
                    assert self.rfile.read(2) == b'\r\n'
            else:
                size = int(self.headers['Content-Length'])
                assert 0 < size <= 65536
                raw.extend(self.rfile.read(size))
            body = json.loads(raw)
            seen.append(dict(path=self.path, body=body))
            valid = (body.get('preconditions') == dict(uid=uid, resourceVersion='7')
                and body.get('propagationPolicy') == 'Orphan')
            response = dict(apiVersion='v1', kind='Status', status='Success' if valid else 'Failure',
                code=200 if valid else 409)
            payload = json.dumps(response).encode()
            self.send_response(response['code'])
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers(); self.wfile.write(payload)
    server = HTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start(); save()
    try:
        config = dict(apiVersion='v1', kind='Config', clusters=[dict(name='fixture', cluster=dict(
            server='http://127.0.0.1:' + str(server.server_port)))], contexts=[dict(name='fixture',
            context=dict(cluster='fixture', user='fixture'))], users=[dict(name='fixture', user={})],
            **{'current-context': 'fixture'})
        private_write(work / 'kubeconfig', json.dumps(config).encode())
        value = dict(schema='poc-eks-retirement/1', installation_id=str(uuid4()),
            installation_configuration=str(work / 'installation.json'), account='123456789012', region='us-east-1',
            cluster='local-transport-fixture', namespace='agenticos-poc-transport', namespace_uid=str(uuid4()),
            kubeconfig=str(work / 'kubeconfig'), context='fixture', aws_profile='NOT_INVOKED',
            resources=[dict(kind='Service', name='fixture', uid=uid)])
        api = OperatorKubernetes(value, kubectl=str(kubectl))
        path = '/api/v1/namespaces/agenticos-poc-transport/services/fixture'
        options = dict(apiVersion='v1', kind='DeleteOptions', propagationPolicy='Orphan',
            preconditions=dict(uid=uid, resourceVersion='7'))
        api.delete(path, options)
        try:
            api.delete(path, dict(options, preconditions=dict(uid=str(uuid4()), resourceVersion='7')))
        except OwnershipError:
            report['actual409Refused'] = True
        else:
            raise AssertionError('Actual server409 was not refused')
        assert len(seen) == 2 and seen[0]['body'] == options
        report.update(status='PASS', kubectl=str(kubectl), kubectlSHA256=hashlib.sha256(kubectl.read_bytes()).hexdigest())
        save()
        return report
    except BaseException as error:
        report.update(status='FAILED', error=type(error).__name__); save()
        raise
    finally:
        server.shutdown(); server.server_close(); thread.join()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--kubectl', type=Path, required=True)
    args = parser.parse_args()
    result = run(args.work, args.report, args.kubectl)
    print(json.dumps({key: result[key] for key in ('status', 'actual409Refused', 'awsCalls', 'cloudOrProductResources')}))
