"""Prepare/qualify one finite synthetic native read or workflow. Never Send or approve.

Reuses the app's existing readonly/2 or workflow/2 contract and actual native login.
No credential export, diagnostic login, task/effect submission or new allowance.
The actual UI driver and canonical observer independently prove the result.
"""
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
from uuid import uuid4
from agentic_os.adapters.local.files import private_read,private_write,private_directory,check_private
from agentic_os.adapters.local.target import connect_owned
from agentic_os.adapters.poc.local_synthetic_access import LocalAccessRecord,LocalAccountIssuer,LocalReceiptIssuer
from agentic_os.adapters.poc.qualification_allowance import controls,read_ledger,validate_ledger
from agentic_os.contracts.validation import validate_contract
from agentic_os.production.profiles import version_pin
from agentic_os.adapters.poc.family_composition import family_definition_ref


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(private_read(Path(p),16*1048576))
def save(p,value):private_write(Path(p),json.dumps(value,indent=2).encode())
def peer(source,name):
    import sys,importlib
    path=Path(source)/'scripts'
    if str(path) not in sys.path:sys.path.insert(0,str(path))
    return importlib.import_module(name)
def current(c):
    local=c['local_access'];record=LocalAccessRecord(local['state_file'],environment_id=local['environment_id'],backend_environment=c['reviewed_effect']['backend_environment'])
    record.require({'subjectId':'test-user-001'});return record

def prepare(a,c):
    if a.question is None or a.expected_inputs is None:raise ValueError('Frozen question and explicit expected read inputs required')
    question=a.question
    if not 1<=len(question)<=1000:raise ValueError('Bounded original read required')
    record=current(c);native={k:record.read()[k] for k in ('subject','sessionId','generation')}
    cfg=c.get('owner_read_context')
    revision=(7 if c.get('read_parallel_tools') else 6 if c.get('read_goal_completion') else 3+c.get('owner_read_context_version',1)) if cfg else (3 if c.get('table_display_mapping') else c.get('profile_revision',1))
    meter=load(c['live']['meter_file'])
    assistant=family_definition_ref('read',meter['model'])
    with connect_owned(Path(c['manifest']),autocommit=True) as db:
        db.read_only=True
        row=db.execute('SELECT payload,digest FROM os_agent_profiles WHERE application_id=%s AND definition_ref=%s AND revision=%s',(c['application_id'],assistant,revision)).fetchone()
    if row is None:raise ValueError('Running configuration has no selected registered read profile')
    profile,hashed=row;validate_contract('AgentAdmissionProfile',profile)
    if profile['capabilities']['allowedKinds']!=['read'] or profile['model']!=meter['model']:raise ValueError('Read-only profile required')
    expected=load(a.expected_inputs)
    allowed=['LookupMemberByName','GetLastKnownLocation','GetLocationHistory','ListSavedLocations','GetSavedLocationWithGeofences']
    if not expected or any(set(v)!={'tool','arguments'} or v['tool'] not in allowed for v in expected):raise ValueError('Exact read-only expected inputs required')
    app=Path(subprocess.check_output(['xcrun','simctl','get_app_container',a.device,'com.example.agenticos.vfpoc','app'],text=True).strip())
    runtime=dict(subject='test-user-001',mainSHA256=sha(app/'VFMock'),debugDylibSHA256=sha(app/'VFMock.debug.dylib'),configSHA256=sha(app/'Config.json'),launchEnvironment={})
    appconfig=json.loads((app/'Config.json').read_bytes())
    if any(appconfig[k]!=c[field] for k,field in [('osOrigin','public_origin'),('parentOrigin','host_origin')]) or appconfig.get('fixture') is not False or appconfig.get('localSessionAccess') is not True:raise ValueError('Actual bundled signed-in native profile required')
    run=str(uuid4());folder=a.native_root/'core-workflows'/run;private_directory(folder)
    eligibility=dict(schema='poc-current-native-read-eligibility/1',definition=version_pin(profile['definition'],'definition'),profile=profile['definition']['profile'],harness=profile['definition']['harness'],registeredProfileDigest=hashed,allowedKinds=['read'],expectedInputs=expected,authority=False,
        selectionBasis='Exact supplied running runtime configuration plus immutable registered profile; actual offered choice must be observed by the native UI driver',runtimeConfigSHA256=sha(a.runtime_config))
    file=folder/'read-eligibility.json';save(file,eligibility)
    labels=dict(composer='Message your assistant',send='Send',newConversation='New conversation',personalize='Personalize',assistant='Authorized assistant',savePersonalization='Save personalization',closePersonalization='Close Personalize your companion',terminalCompleted='Completed',acceptedAnswerRegion='Accepted answer',history='History',historyTitle='Your conversations',sourceTablePrefix='Source table. Scroll horizontally to view all columns.',disclosurePrefix='View supporting records')
    context=dict(schema='vf.native-readonly-context/2',runId=run,operation='send-readonly/1',runtime=runtime,question=question,actualResultFile=str(folder/'actual-result.json'),priorResultFile=None,reconnectCount=0,nativeSession=native,
        surfaceContract=dict(kind='source-tables/1',state='QUALIFIED',labels=labels,bounds=dict(maxTables=8,maxColumns=32,maxRowsPerTable=64,maxCellUTF16=2000)),
        admission=dict(assistantId=assistant,profileId=profile['definition']['profile']['ref'],profileRevision=profile['definition']['profile']['revision'],readCapabilities=sorted(allowed),eligibilityFile=str(file),eligibilitySHA256=sha(file)))
    validate=peer(a.app_source,'native_readonly_context');validate.validate_context(context)
    save(folder/'context.json',context)
    print(json.dumps(dict(state='CONTEXT_ONLY_NO_UI_OR_MODEL',context=str(folder/'context.json'),runId=run,definition=eligibility['definition'])))


def prepare_parent(a,c):
    if not a.question or a.requested_values is None or not a.name_suffix:
        raise ValueError('Exact supplied question, requested values and actual name append required')
    current(c)
    app=Path(subprocess.check_output(['xcrun','simctl','get_app_container',a.device,'com.example.agenticos.vfpoc','app'],text=True).strip())
    config=json.loads((app/'Config.json').read_bytes())
    if (config.get('fixture') is not False or config.get('localSessionAccess') is not True
            or any(config[k]!=c[v] for k,v in [('osOrigin','public_origin'),('parentOrigin','host_origin'),('backendBase','backend_url')])):
        raise ValueError('Actual signed-in synthetic app configuration required')
    requested=load(a.requested_values)
    from copy import deepcopy
    amended=deepcopy(requested);amended['location']['name']+=a.name_suffix
    runtime=dict(subject='test-user-001',mainSHA256=sha(app/'VFMock'),debugDylibSHA256=sha(app/'VFMock.debug.dylib'),configSHA256=sha(app/'Config.json'),
        launchEnvironment={key:config[field] for key,field in [('VF_OS_ORIGIN','osOrigin'),('VF_HOST_ORIGIN','parentOrigin'),('VF_EMBED_REF','embedRef'),
            ('VF_BOOTSTRAP_URL','bootstrapURL'),('VF_NATIVE_INTEGRATION_BASE','backendBase'),('VF_NATIVE_INTEGRATION_ENV','environment'),('VF_ASSURANCE_ORIGIN','assuranceOrigin')]})
    runtime['launchEnvironment']['VF_LOCAL_SESSION_ACCESS']='1'
    run=str(uuid4());folder=a.native_root/'core-workflows'/run;private_directory(folder)
    labels=dict(name='Name',address='Address',latitude='Latitude',longitude='Longitude')
    context=dict(schema='vf.native-workflow-context/2',workflow='create-location/1',runId=run,question=a.question,runtime=runtime,requested=requested,amended=amended,
        editor=dict(state='QUALIFIED',contract='core.location-edit/1',textLabels=labels,selectLabels={},optionalChangeLabels={key:label+' change' for key,label in labels.items()},expectedAssistantDefinitionRef='poc-family-change/1'),
        actualResultFile=str(folder/'actual-result.json'),priorResultFile=None,ownerQuestion=None,continueDraftLabel='Continue remaining request',
        editing=dict(kind='append-name-and-choices/1',nameSuffix=a.name_suffix),continuationDraftProof=None)
    peer(a.app_source,'native_workflow_context').validate_context(context)
    save(folder/'context.json',context)
    print(json.dumps(dict(state='CONTEXT_ONLY_NO_UI_OR_MODEL',context=str(folder/'context.json'),runId=run)))


def release(a,c):
    if a.context is None or a.test_bundle is None or a.live_controls is None:raise ValueError('Exact context/test bundle/existing approved controls required')
    context=load(a.context);writer=a.command=='release-write'
    contract=peer(a.app_source,'native_workflow_context' if writer else 'native_readonly_context')
    contract.validate_context(context)
    if context['schema']!=('vf.native-workflow-context/2' if writer else 'vf.native-readonly-context/2'):
        raise ValueError('Exact current native context required')
    folder=a.context.parent
    if folder.parent!=a.native_root/'core-workflows' or (folder/'release.json').exists():raise ValueError('New owned once-release required')
    record=current(c);original=record.read();native={k:original[k] for k in ('subject','sessionId','generation')}
    if not writer and native!=context['nativeSession']:raise ValueError('Original active native login changed')
    pins=peer(a.app_source,'check_local_backend_ready').process_pins()
    command=subprocess.check_output(['ps','-p',str(pins['core']['pid']),'-o','command='],text=True)
    import shlex
    args=shlex.split(command)
    if '--config' not in args or Path(args[args.index('--config')+1])!=a.runtime_config:raise ValueError('Exact running Core configuration required')
    b=controls(a.live_controls);ledger=read_ledger(Path(b['allowanceFile']));totals=validate_ledger(ledger)
    available=ledger['authorizedCostMicros']-sum(totals.values())
    if available<500000:raise ValueError('Existing allowance cannot reserve one original Root')
    from agentic_os.adapters.local.capacity import Capacity
    if not Capacity(a.native_root/'capacity').preview(6*1024**3)['admitted']:raise ValueError('Existing native capacity floor/holds not satisfied')
    account=LocalAccountIssuer(c['local_access']['account_issuer'],environment=c['memory_account']['environment'],token_files=c['memory_account']['token_files'])
    account.token({'subjectId':native['subject']});receipt=LocalReceiptIssuer(c['local_access']['receipt_issuer'],record=record);receipt.token(native['subject'])
    if record.read()!=original:raise ValueError('Native login changed during role preparation')
    readiness={}
    for role,issued in [('account',account._issued[native['subject']]),('receipt',receipt._issued[native['subject']])]:
        file=folder/(role+'-readiness.json');save(file,dict(schema='poc-native-finite-role-readiness/1',state='READY',role=role,subject=native['subject'],expiresAtEpoch=issued['expiresAt'],nativeSession=native,paidCalls=0,effectDispatch=0,loginCalls=0))
        readiness[role]=dict(state='READY',expiresAtEpoch=issued['expiresAt'],metadataFile=str(file),metadataSHA256=sha(file))
    readiness['canonicalExecution']=dict(mode='host-issued-per-invocation/1',rootMaximumSeconds=120,credentialMaximumSeconds=60)
    value=dict(schema='vf.native-readonly-release/2',state='RELEASED',runId=context['runId'],authorization=str(uuid4()),contextSHA256=sha(a.context),expiresAtEpoch=int(time.time())+900,
        maximum={},budget=dict(state='FUNDED_ONE_RUN',availableMicros=available,rootReservationMicros=500000,canonicalLedgerPreserved=True),processes=pins,readiness=readiness,testBundleSHA256=sha(a.test_bundle),nativeSession=native,initialScreen='Home')
    if writer:
        value.update(schema='vf.native-workflow-release/2',initialScreen='Home' if context['workflow']=='create-location/1' else 'Agent with continuation draft',maximum=dict(Send=1,ownerReply=1 if context['ownerQuestion'] else 0,amendment=1,ownerDecision=1,Stop=0,SignIn=0,assistantSelection=0,personaSave=0))
    else:value.update(maximum=contract.NATIVE_MAXIMUM,eligibilitySHA256=context['admission']['eligibilitySHA256'])
    with connect_owned(Path(c['manifest']),autocommit=True) as db:
        db.read_only=True
        for query in ("SELECT count(*) FROM os_direct_executions WHERE state IN ('STARTING','RUNNING')","SELECT count(*) FROM personal_learning_jobs WHERE state='RUNNING'","SELECT count(*) FROM os_tasks WHERE deadline>clock_timestamp() AND state IN ('ACCEPTED','RUNNING','WAITING_INPUT','WAITING_APPROVAL')"):
            if db.execute(query).fetchone()[0]:raise ValueError('Current operations must reach a safe checkpoint')
    file=folder/'release.json';save(file,value);contract.validate_release(a.context,context,file)
    print(json.dumps(dict(state='RELEASED_ONE_NATIVE_WORKFLOW_NO_SEND' if writer else 'RELEASED_ONE_NATIVE_READ_ONLY_NO_SEND',release=str(file),testBundleSHA256=sha(a.test_bundle),availableMicros=available)))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['prepare','release','prepare-parent','release-write']);p.add_argument('--runtime-config',type=Path,required=True);p.add_argument('--app-source',type=Path,required=True);p.add_argument('--native-root',type=Path,required=True);p.add_argument('--device',required=True);p.add_argument('--question');p.add_argument('--expected-inputs',type=Path);p.add_argument('--requested-values',type=Path);p.add_argument('--name-suffix');p.add_argument('--context',type=Path);p.add_argument('--test-bundle',type=Path);p.add_argument('--live-controls',type=Path);a=p.parse_args();os.umask(0o077)
    for path in (a.runtime_config,a.app_source,a.native_root):
        if not path.is_absolute() or path.resolve()!=path:raise ValueError('Explicit canonical source/runtime paths required')
    check_private(a.native_root,directory=True);c=load(a.runtime_config)
    if c.get('schema')!='poc-family-runtime/1' or c.get('mode')!='direct' or not c.get('local_access'):raise ValueError('Existing explicit synthetic native profile required')
    return prepare(a,c) if a.command=='prepare' else prepare_parent(a,c) if a.command=='prepare-parent' else release(a,c)

if __name__=='__main__':
    try:main()
    except Exception as error:
        import traceback
        print(json.dumps(dict(state='REFUSED_NO_REPLAY',errorType=type(error).__name__,frames=[dict(file=Path(f.filename).name,line=f.lineno) for f in traceback.extract_tb(error.__traceback__)])),file=__import__('sys').stderr);raise SystemExit(1)
