#!/usr/bin/env python3
"""P0 selection of the existing protected migration rehearsal primitives.

The populated source is read-only. Candidate forward application and runtime
acceptance use its separate, authenticated copy. Independent predecessor
recovery is retained separately; no component/phase readiness is synthesized.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import secrets
import sys
from importlib.resources import files as resource_files

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from migration_rehearsal import (check_draft_sql,component_watermark,material,decrypt_artifacts,
    protected_content,restore_protected_material,forward_rows_preserved,same)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from agentic_os.adapters.local.backup import READ_SECRET
from agentic_os.adapters.local.docker import DockerControl
from agentic_os.adapters.local.files import private_read,private_write,private_directory
from agentic_os.adapters.local.ownership import load_manifest,POC_PROFILE
from agentic_os.adapters.local.resources import file_lock
from agentic_os.adapters.local.target import validate_target,connect_owned
from agentic_os.adapters.postgres.migrate import migrate,migration_head,migration_config
from agentic_os.contracts.canonical import canonical_bytes


def keyword_component_rollback(source,root):
    """Reversible component DDL and physical shapes; no publication authority."""
    from uuid import uuid4
    from alembic import command
    from sqlalchemy import create_engine
    from sqlalchemy.pool import NullPool
    from sqlalchemy.exc import DBAPIError
    from agentic_os.adapters.postgres.profiles import RDS_EXACT
    from agentic_os.adapters.postgres.component_checks import assert_component_checks
    results={}
    for component in ('retrieval','knowledge'):
        before=component_watermark(source,component)
        if before['schemaVersions']!={'alembic_version':[['os_rds_store_0001']]}:
            raise ValueError('Exact adjacent RDS component source required')
        engine=create_engine('postgresql+psycopg://',poolclass=NullPool,
            creator=lambda selected=component:connect_owned(source,component=selected,role='migrator'))
        rejected=[]
        try:
            with engine.connect() as connection:
                transaction=connection.begin()
                try:
                    connection.exec_driver_sql("SET LOCAL lock_timeout='2s'");connection.exec_driver_sql("SET LOCAL statement_timeout='3s'")
                    config=migration_config(component,storage_profile=RDS_EXACT);config.attributes['connection']=connection
                    command.upgrade(config,'os_rds_store_0002');command.check(config)
                    assert_component_checks(connection,component,storage_profile=RDS_EXACT)
                    if component=='retrieval':
                        name='poc_keyword_shape_'+uuid4().hex
                        connection.exec_driver_sql(f'CREATE TEMP TABLE {name} (LIKE personal_knowledge_vectors INCLUDING CONSTRAINTS) ON COMMIT DROP')
                        vector='[1,'+','.join(['0']*383)+']'
                        sql=f'''INSERT INTO {name}(id,installation_id,application_id,tenant_id,subject_id,entry_id,revision_id,
                            entry_version,index_generation,profile_ref,lane,context_ref,embedding,lexemes)
                            VALUES(%s,%s,%s,'poc-shape','synthetic',%s,%s,1,2,%s,'semantic','general/1',CAST(%s AS vector(384)),to_tsvector('english','school'))'''
                        def insert(profile,value):
                            connection.exec_driver_sql(sql,(uuid4(),uuid4(),uuid4(),uuid4(),uuid4(),profile,value))
                        insert('minilm-english-onnx/1',vector);insert('keyword-fts/1',None)
                        for label,profile,value in [('default-null','minilm-english-onnx/1',None),
                                ('keyword-vector','keyword-fts/1',vector),('unknown-profile','unknown/1',None),
                                ('default-not-normalized','minilm-english-onnx/1','['+','.join(['0']*384)+']')]:
                            try:
                                with connection.begin_nested():insert(profile,value)
                            except DBAPIError as error:
                                if getattr(error.orig.diag,'constraint_name',None) not in {'ck_personal_vector_profile','ck_personal_vector_normalization'}:raise
                                rejected.append(label)
                            else:raise ValueError('Invalid keyword/default shape was accepted')
                    command.downgrade(config,'os_rds_store_0001')
                finally:transaction.rollback()
        finally:engine.dispose()
        if not same(before,component_watermark(source,component)):raise ValueError('Component rollback changed original rows/catalog')
        results[component]=dict(rollback='PASS',catalogAndRoles='PASS',rejectedShapes=rejected)
    private_write(root/'component-sql-rollback.json',canonical_bytes(results))
    return results


def prepare(source,root,revision):
    if revision not in {'os_pg_0099','os_pg_0100','os_pg_0101','os_pg_0102','os_pg_0103','os_pg_0104','os_pg_0105'}:raise ValueError('Explicit adjacent POC revision required')
    if revision!=migration_head():raise ValueError('Use the source checkpoint whose head is the explicit rehearsal revision')
    packaged=resource_files('agentic_os').joinpath('migrations')
    for path in (ROOT/'migrations').rglob('*.py'):
        if packaged.joinpath(str(path.relative_to(ROOT/'migrations'))).read_bytes()!=path.read_bytes():
            raise ValueError('Packaged migration differs from maintained source; prepare current build resources first')
    prior={'os_pg_0099':'os_pg_0098','os_pg_0100':'os_pg_0099','os_pg_0101':'os_pg_0100','os_pg_0102':'os_pg_0101','os_pg_0103':'os_pg_0102','os_pg_0104':'os_pg_0103','os_pg_0105':'os_pg_0104'}[revision]
    source=Path(source);root=Path(root)
    manifest=validate_target(source,role='migrator')
    if manifest['profile']!=POC_PROFILE or set(manifest['databases'])!={'control','retrieval','knowledge'}:
        raise ValueError('Explicit owned exact three-store source required')
    if root.exists():raise ValueError('Use the retained prepared target; do not repeat or overwrite a rehearsal')
    with file_lock(source.parent/'poc-runtime.lock',timeout=0):
        before={name:component_watermark(source,name) for name in manifest['databases']}
        if (before['control']['schemaVersions']!={'alembic_version':[[prior]]}
                or before['control']['counts'].get('os_admissions',0)<1):
            raise ValueError('Populated adjacent production admission required')
        with connect_owned(source) as db:
            if db.execute("SELECT EXISTS(SELECT 1 FROM os_work_attempts WHERE state IN ('RUNNING','UNKNOWN'))").fetchone()[0]:
                raise ValueError('Preserve unresolved source operations; no snapshot while work is uncertain')
        private_directory(root)
        check_draft_sql(source,root/'sql-rollback',revision)
        component_sql=keyword_component_rollback(source,root) if revision=='os_pg_0102' else None
        dumps={};docker=DockerControl(manifest)
        for name,definition in manifest['databases'].items():
            raw=docker.binary('exec','-i',manifest['postgres']['container'],'sh','-c',READ_SECRET,
                '--','pg_dump','--host','127.0.0.1','--username',definition['migrator'],'--dbname',definition['name'],
                '--format=custom','--no-owner','--no-acl','--no-comments',
                input=(definition['migratorPassword']+'\n').encode(),max_bytes=64*1048576)
            dumps[name]=base64.b64encode(raw).decode()
        private_files=material(source.parent);artifact_pins=decrypt_artifacts(source)
        for name in manifest['databases']:
            if not same(before[name],component_watermark(source,name)):raise ValueError('Source changed while snapshotting')
        migration_sha=hashlib.sha256((ROOT/('migrations/versions/'+revision+'.py')).read_bytes()).hexdigest()
        component_pins=({'os_rds_store_0002':hashlib.sha256((ROOT/'migrations/profiles/rds_exact/versions/os_rds_store_0002.py').read_bytes()).hexdigest()}
            if revision=='os_pg_0102' else {})
        binding=canonical_bytes(dict(schema='poc-protected-migration/1',source=str(source),
            installationId=manifest['installationId'],revision=revision,migrationSHA256=migration_sha,
            **(dict(componentMigrationSHA256=component_pins) if component_pins else {})))
        content=protected_content(dumps,private_files);key=AESGCM.generate_key(bit_length=256);nonce=secrets.token_bytes(12)
        private_write(root/'recovery.key',key)
        private_write(root/'protected.bin',nonce+AESGCM(key).encrypt(nonce,content,binding))
        metadata=dict(source=str(source),before=before,fileHashes={name:hashlib.sha256(base64.b64decode(raw)).hexdigest()
            for name,raw in private_files.items()},artifactPins=artifact_pins,
            bindingBase64=base64.b64encode(binding).decode(),migrationSHA256=migration_sha,prior=prior,revision=revision)
        if component_pins:metadata['componentMigrationSHA256']=component_pins
        # Recovery material exists only inside the authenticated encryption
        # envelope. Metadata and public reports contain hashes, never keys.
        private_write(root/'prepared.json',canonical_bytes(metadata))
        copy=restore_protected_material(source,root,'draft'+revision[-4:],archive_root=root,binding=binding,before=before,
            files=private_files,artifact_pins=artifact_pins,revision=revision)
        migrate(copy,revision=revision)
        migrate(copy,check_only=True)
        for name in ('retrieval','knowledge'):
            if component_pins:migrate(copy,component=name)
            migrate(copy,component=name,check_only=True)
            if component_pins and not forward_rows_preserved(before[name],component_watermark(copy,name),copy,'os_rds_store_0002'):
                raise ValueError('Component forward application changed predecessor rows')
        current=component_watermark(copy,'control')
        if not forward_rows_preserved(before['control'],current,copy,revision):
            raise ValueError('Forward application changed predecessor rows')
        report=dict(schema='poc-migration-rehearsal-report/1',source=str(source),candidate=str(copy),
            sourceHead=prior,candidateHead=revision,migrationSHA256=migration_sha,
            sqlRollback='PASS',protectedRestore='PASS',forwardRows='PASS',catalogAndRoles='PASS',
            runtime='NOT_RUN',independentRecovery='NOT_RUN',engineering='candidate; not frozen or phase accepted')
        if component_pins:report.update(componentMigrationSHA256=component_pins,componentSQL=component_sql,componentForwardRows='PASS')
        private_write(root/'report.json',canonical_bytes(report))
        return report


def recover(root):
    root=Path(root);metadata=json.loads(private_read(root/'prepared.json',256*1048576))
    source=Path(metadata['source']);before=metadata['before']
    revision=metadata.get('revision','os_pg_0099');prior=metadata.get('prior','os_pg_0098')
    binding=base64.b64decode(metadata['bindingBase64'])
    encrypted=private_read(root/'protected.bin',256*1048576)
    payload=json.loads(AESGCM(private_read(root/'recovery.key',32)).decrypt(encrypted[:12],encrypted[12:],binding))
    private_files=payload['files']
    if {name:hashlib.sha256(base64.b64decode(raw)).hexdigest() for name,raw in private_files.items()}!=metadata['fileHashes']:
        raise ValueError('Protected material identity differs')
    path=restore_protected_material(source,root,'independent'+prior[-4:],archive_root=root,binding=binding,before=before,
        files=private_files,artifact_pins=metadata['artifactPins'],revision=revision)
    if not all(same(before[name],component_watermark(path,name)) for name in before):
        raise ValueError('Independent predecessor recovery differs')
    if decrypt_artifacts(path)!=metadata['artifactPins']:raise ValueError('Recovered private material differs')
    report=json.loads(private_read(root/'report.json'))
    report.update(independentRecovery='PASS',recoveredManifest=str(path))
    private_write(root/'report.json',canonical_bytes(report),replace=True)
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['prepare','recover']);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--source',type=Path);parser.add_argument('--revision',choices=['os_pg_0099','os_pg_0100','os_pg_0101','os_pg_0102','os_pg_0103','os_pg_0104','os_pg_0105']);args=parser.parse_args()
    if args.command=='prepare' and (args.source is None or args.revision is None):parser.error('Explicit original source and adjacent revision required')
    print(json.dumps(prepare(args.source,args.root,args.revision) if args.command=='prepare' else recover(args.root),indent=2))
