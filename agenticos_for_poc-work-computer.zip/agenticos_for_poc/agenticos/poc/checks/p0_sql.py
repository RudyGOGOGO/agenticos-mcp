#!/usr/bin/env python3
"""Positive/negative direct profile and epoch SQL guards, rolled back."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
from uuid import uuid4

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from poc.local_runtime import configuration
from agentic_os.adapters.local.files import private_write,private_read
from agentic_os.adapters.local.target import connect_owned
from agentic_os.contracts.canonical import digest
from agentic_os.production.profiles import version_pin
import psycopg
from psycopg.types.json import Jsonb


class RollbackProof(Exception):pass


def run(value):
    results={}
    with connect_owned(Path(value['manifest'])) as db:
        before=db.execute('SELECT t.id,t.state,t.deadline,r.state,r.spent,r.outstanding FROM os_tasks t '
            'JOIN os_budget_roots r ON r.id=t.budget_root_id ORDER BY t.id').fetchall()
        profile=db.execute("SELECT installation_id,application_id,registration_revision,application_generation,payload "
            "FROM os_agent_profiles WHERE definition_ref='poc-family-assistant/1' AND revision=2").fetchone()
        assert profile is not None
        def insert(changes):
            payload=deepcopy(profile[4]);payload['definition']['id']='poc-guard-'+str(uuid4());payload['definition']['revision']=1
            changes(payload)
            payload['definition']['profile']=version_pin(payload['runtime'])
            payload['definition']['capabilityPolicy']=version_pin(payload['capabilities'],'policy')
            db.execute('INSERT INTO os_agent_profiles (installation_id,application_id,definition_ref,revision,'
                'registration_revision,application_generation,digest,payload,created_at) VALUES (%s,%s,%s,1,%s,%s,%s,%s,clock_timestamp())',
                (*profile[:2],payload['definition']['id'],*profile[2:4],digest('manifest',payload),Jsonb(payload)))
        try:
            with db.transaction():
                insert(lambda _:None)
                raise RollbackProof()
        except RollbackProof:results['valid-direct-profile']='PASS'
        def reject(name,execute,reason):
            try:
                with db.transaction():execute()
            except psycopg.errors.RaiseException as error:
                assert error.diag.message_primary==reason,(name,error.diag.message_primary)
                results[name]='PASS';return
            raise AssertionError('Guard did not refuse '+name)
        for kind in ('native','compute'):
            reject('direct-'+kind,lambda kind=kind:insert(lambda p:p['capabilities']['allowedKinds'].append(kind)),
                'agent_profile_binding')
        reject('direct-renewed-horizon',lambda:insert(lambda p:p['runtime'].update(authorizationHorizonMs=120001)),
            'agent_profile_binding')
        reject('direct-over-capacity',lambda:insert(lambda p:p['runtime'].update(maxActiveTasks=3)),
            'agent_profile_binding')
        row=db.execute("SELECT id FROM os_direct_executions WHERE state='INTERRUPTED' LIMIT 1").fetchone()
        assert row is not None
        for name,sql in [
            ('changed-child-epoch','UPDATE os_direct_executions SET epoch=gen_random_uuid() WHERE id=%s'),
            ('interrupted-restart','UPDATE os_direct_executions SET state=\'RUNNING\' WHERE id=%s'),
            ('renewed-child-deadline','UPDATE os_direct_executions SET deadline=deadline+interval \'1 second\' WHERE id=%s')]:
            reject(name,lambda sql=sql:db.execute(sql,row),'direct_execution_transition')
        reject('deleted-child-fence',lambda:db.execute('DELETE FROM os_direct_executions WHERE id=%s',row),
            'direct_execution_retained')
        # An interrupted exact worker may truthfully finish its original
        # bookkeeping, but cannot obtain executable input or accept results.
        # Inspect the real persisted assignment without changing any hold.
        from sqlalchemy import create_engine,select
        from sqlalchemy.orm import Session
        from sqlalchemy.pool import NullPool
        from agentic_os.adapters.postgres.models import DirectExecution,Admission,AgentModelCall
        from agentic_os.production.model_rpc import ModelWorkerService
        from agentic_os.production.workload_auth import DirectWorkerAssignment
        from agentic_os.errors import OSErrorCode
        engine=create_engine('postgresql+psycopg://',poolclass=NullPool,
            creator=lambda:connect_owned(Path(value['manifest'])))
        try:
            with Session(engine) as session:
                execution=session.get(DirectExecution,row[0])
                admission=session.scalar(select(Admission).where(Admission.task_id==execution.task_id))
                call=session.scalar(select(AgentModelCall).where(AgentModelCall.task_id==execution.task_id))
                context=call.request['context']
                assigned=DirectWorkerAssignment(str(execution.application_id),context['model']['digest'],call.meter_digest,
                    str(execution.task_id),execution.execution_id,str(execution.epoch))
                ModelWorkerService._execution_assignment(session,assigned,context,admission,bookkeeping=True)
                results['exact-interrupted-original-bookkeeping']='PASS'
                for name,worker in [('interrupted-executable-input',assigned),
                        ('foreign-finish-task',DirectWorkerAssignment(assigned.application_id,assigned.model_digest,
                            assigned.meter_digest,str(uuid4()),assigned.execution_id,assigned.epoch))]:
                    try:ModelWorkerService._execution_assignment(session,worker,context,admission,
                        bookkeeping=name=='foreign-finish-task')
                    except OSErrorCode as error:
                        assert error.code=='DENIED';results[name]='PASS'
                    else:raise AssertionError('Interrupted/foreign assignment received authority')
        finally:engine.dispose()
        after=db.execute('SELECT t.id,t.state,t.deadline,r.state,r.spent,r.outstanding FROM os_tasks t '
            'JOIN os_budget_roots r ON r.id=t.budget_root_id ORDER BY t.id').fetchall()
        assert before==after
        predecessor=json.loads(private_read(Path(value['manifest']).parents[1]/'prepared.json'))['source']
        with connect_owned(Path(predecessor)) as source:
            original=source.execute('SELECT id,workflow_id,workflow_profile,state,attempts,repair_count FROM os_dispatches ORDER BY id').fetchall()
        assert original
        for original_dispatch in original:
            retained=db.execute('SELECT id,workflow_id,workflow_profile,state,attempts,repair_count FROM os_dispatches WHERE id=%s',
                (original_dispatch[0],)).fetchone()
            assert retained==original_dispatch
        results['original-temporal-dispatches-unclaimed']='PASS'
        db.rollback()
    return dict(schema='poc-direct-sql-report/1',status='PASS',guards=results,
        originalAccountingDeadlinesAndUnknown='unchanged',mutations='all test rows and attempts rolled back')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True);parser.add_argument('--report',type=Path,required=True);args=parser.parse_args()
    report=dict(schema='poc-direct-sql-report/1',status='FAIL')
    try:report=run(configuration(args.config))
    except BaseException as error:report['failureType']=type(error).__name__;raise
    finally:private_write(args.report,json.dumps(report,indent=2).encode())
