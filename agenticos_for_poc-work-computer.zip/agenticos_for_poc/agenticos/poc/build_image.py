#!/usr/bin/env python3
"""One POC dual-environment image using the maintained release primitives.

No runtime, deployment or lane acceptance is inferred from a successful build.
Source/wheels, frozen exports, base, installer, OPA and process tools are pinned.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
import urllib.request
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from build_images import (checked_image_lock, checked_installer_bytes, checked_worker_wheel,
    checked_process_tools, checked_process_tool_bytes, process_tools_recipe)
from image_distribution import verify_oci
from test_os import source_digest
from agentic_os.adapters.local.capacity import Capacity, GiB, owned_docker_headroom
from agentic_os.adapters.local.docker import DockerControl
from agentic_os.adapters.local.files import private_directory, private_write
from agentic_os.adapters.local.target import validate_target
from agentic_os.distribution import archive_members, digest, read_regular


def fetched(url, maximum):
    with urllib.request.urlopen(url, timeout=30) as response:
        content = response.read(maximum + 1)
    if len(content) > maximum:
        raise ValueError('Pinned package download exceeds its bound')
    return content


def frozen_requirements(project, destination, log):
    # uv's default comment embeds the destination path. It is not dependency
    # input, but changes Docker's COPY digest on every unique owned build.
    # Retain the complete frozen hashes/annotations with a stable header-free
    # export, so product wheel changes cannot reinstall an unchanged graph.
    subprocess.run(['uv', 'export', '--project', str(project), '--frozen', '--no-dev', '--no-emit-project',
        '--no-header', '--format', 'requirements-txt', '--output-file', str(destination)],
        cwd=ROOT, check=True, stdout=log, stderr=log)


def build(args):
    if (any(not p.is_absolute() or '..' in p.parts for p in
            (args.manifest, args.wheel, args.sdk_wheel, args.output, args.capacity_root))
            or args.wheel.name != 'agentic_os-0.1.0-py3-none-any.whl'
            or args.sdk_wheel.name != 'agentic_os_agent_worker-0.1.0-py3-none-any.whl'):
        raise ValueError('Explicit owned build paths and independent wheels required')
    manifest = validate_target(args.manifest)
    docker = DockerControl(manifest)
    core, sdk = read_regular(args.wheel), read_regular(args.sdk_wheel)
    members = archive_members(core, 'api-wheel')
    expected = {str(p.relative_to(ROOT / 'src')): read_regular(p) for p in (ROOT / 'src/agentic_os').rglob('*')
        if p.is_file() and '__pycache__' not in p.parts and p.name != '.DS_Store'}
    if {n: v for n, v in members.items() if n.startswith('agentic_os/')} != expected:
        raise ValueError('Core wheel differs from the selected complete installed product')
    checked_worker_wheel(sdk)
    lock_raw = read_regular(ROOT / 'deploy/release/image-lock.json')
    lock = checked_image_lock(json.loads(lock_raw))
    process_raw = read_regular(ROOT / 'deploy/release/process-tools-lock.json')
    processes = checked_process_tools(json.loads(process_raw))
    source = source_digest()
    identifier = uuid4().hex[:12]
    started = time.monotonic()
    with Capacity(args.capacity_root).reserve(6 * GiB, purpose='artifact',
            docker_free=owned_docker_headroom(args.manifest), docker_peak=4 * GiB):
        private_directory(args.output)
        context = args.output / 'context'
        private_directory(context)
        installer = lock['installer']
        private_write(context / installer['filename'], checked_installer_bytes(lock, fetched(installer['url'], 4 * 1024**2)))
        private_write(context / 'installer-requirements.txt', ('pip @ file:///release/' + installer['filename']
            + ' --hash=sha256:' + installer['sha256'] + '\n').encode())
        for row in processes['packages']:
            private_write(context / row['filename'], checked_process_tool_bytes(row,
                fetched('https://deb.debian.org/debian/pool/main/p/procps/' + row['filename'], 2 * 1024**2)))
        opa = json.loads(read_regular(ROOT / 'deploy/source-lock.json'))['opa-linux-arm64']
        content = fetched(opa['url'], 200_000_000)
        if digest(content) != opa['sha256']:
            raise ValueError('Pinned Linux OPA bytes changed')
        private_write(context / 'opa', content)
        private_write(context / args.wheel.name, core)
        private_write(context / args.sdk_wheel.name, sdk)
        requirements = {}
        for role, project in [('core', ROOT), ('sdk', ROOT / 'harnesses/agent-worker')]:
            path = context / (role + '-requirements.txt')
            with (args.output / (role + '-requirements-export.log')).open('wb') as log:
                frozen_requirements(project, path, log)
            requirements[role] = dict(lockSHA256=digest(read_regular(project / 'uv.lock')),
                requirementsSHA256=digest(read_regular(path)))
        recipe = process_tools_recipe(read_regular(ROOT / 'poc/deploy/Dockerfile'), processes)
        private_write(context / 'Dockerfile', recipe)
        tag = 'agentic-os-poc-' + identifier + ':core-sdk'
        log_path = args.output / 'image-build.log'
        with log_path.open('wb') as log:
            subprocess.run(['docker', 'build', '--platform=linux/arm64', '--pull=false', '--network=default',
                '--build-arg', 'BASE_IMAGE=' + lock['base']['reference'], '--build-arg', 'WHEEL_SHA256=' + digest(core),
                '--build-arg', 'SDK_WHEEL_SHA256=' + digest(sdk), '--label', 'io.agentic-os.installation=' + manifest['installationId'],
                '--label', 'io.agentic-os.release=' + identifier, '--tag', tag, str(context)],
                env=docker.environment, cwd=args.output, stdout=log, stderr=log, check=True, timeout=900)
        inspection = json.loads(docker.command('image', 'inspect', tag))[0]
        config = inspection['Config']
        labels = config['Labels']
        if (inspection['Architecture'] != 'arm64' or inspection['Os'] != 'linux' or config['User'] != '65534:65534'
                or labels.get('io.agentic-os.wheel-sha256') != digest(core)
                or labels.get('io.agentic-os.sdk-wheel-sha256') != digest(sdk)
                or labels.get('io.agentic-os.release') != identifier
                or config['Entrypoint'] != ['/opt/agentic-os/core/bin/python', '-I', '-B', '-m',
                    'agentic_os.adapters.poc.entry', '--bundled-opa', '/opt/agentic-os/bin/opa']
                or config['Cmd'] != ['--help']):
            raise ValueError('Built image differs from its explicit POC selection')
        archive = args.output / 'core-sdk.oci.tar'
        subprocess.run(['docker', 'image', 'save', '--output', str(archive), tag], env=docker.environment,
            cwd=args.output, check=True, timeout=180)
        inventory = verify_oci(archive, wheel_sha256=digest(core))
        if source_digest() != source:
            raise ValueError('Source changed during the frozen image build')
        result = dict(schema='agentic-os.poc-image/1', status='BUILT_PENDING_ACCEPTANCE', sourceDigest=source,
            baseImage=lock['base']['reference'], imageLockSHA256=digest(lock_raw), platform='linux/arm64',
            coreWheelSHA256=digest(core), sdkWheelSHA256=digest(sdk), requirements=requirements,
            installerSHA256=installer['sha256'], processToolsLockSHA256=digest(process_raw), opaSHA256=opa['sha256'],
            dockerfileSHA256=digest(recipe), imageId=inspection['Id'], tag=tag, archive=archive.name,
            inventory=inventory, buildLogSHA256=digest(read_regular(log_path)), seconds=time.monotonic() - started,
            enabledLanes=[], qualification='Artifact only; configured runtime/local/deployment acceptance remains separate')
        private_write(args.output / 'manifest.json', (json.dumps(result, indent=2) + '\n').encode())
        print(json.dumps(dict(status=result['status'], imageId=result['imageId'], tag=tag,
            manifestSHA256=digest(read_regular(args.output / 'manifest.json')))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('manifest', 'wheel', 'sdk-wheel', 'output', 'capacity-root'):
        parser.add_argument('--' + name, type=Path, required=True)
    build(parser.parse_args())
