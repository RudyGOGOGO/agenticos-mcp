#!/usr/bin/env python3
"""Run explicitly released native POC stages over the existing guarded operators.

Default is preflight. This coordinator neither plans a reply nor grants authority,
refreshes credentials, resets fixtures or repeats a consumed native claim.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from agentic_os.adapters.local.files import private_read, private_write
from agentic_os.adapters.local.target import connect_owned

SCENARIOS = ('S1', 'S2', 'S3', 'S4', 'S5')
DRIVERS = {
    'vf.native-workflow-context/1': ('run_native_workflow_once.py', 'ordinary-workflow-',
        'PASS_ACTUAL_UI_AND_AUTHORIZED_BACKEND_READBACK', 'COMPLETED_ACTUAL_CANONICAL_RECEIPT'),
    'vf.native-readonly-context/1': ('run_native_readonly_once.py', 'readonly-request-',
        'PASS_ACTUAL_READONLY_UI_SOURCES_AND_REOPEN', 'COMPLETED_ACTUAL_READ_SOURCE_SURFACE'),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def document(path, maximum=1024 * 1024):
    return json.loads(private_read(path, maximum))


def owned_path(value, root):
    path = Path(value)
    if not path.is_absolute() or path.resolve() != path or not path.is_relative_to(root):
        raise ValueError('An exact path inside the owned verification storage is required')
    return path


def file_pin(value, root):
    if set(value) != {'path', 'sha256'}:
        raise ValueError('Exact file and SHA256 pin required')
    path = owned_path(value['path'], root)
    if sha(path) != value['sha256']:
        raise ValueError('Pinned input changed')
    return path


def environment(value):
    if (set(value) != {'schema', 'synthetic', 'storageRoot', 'nativeStorageRoot',
            'runtimeConfig', 'nativePython', 'historyTimezone', 'inference', 'drivers', 'stages'}
            or value['schema'] != 'poc-demo-environment/1' or value['synthetic'] is not True
            or value['inference'] not in {'live', 'deterministic'}):
        raise ValueError('Explicit synthetic demo configuration required')
    root = Path(value['storageRoot'])
    if (not root.is_absolute() or root.resolve() != root or root.parent != Path('/Volumes')
            or not os.path.ismount(root)):
        raise ValueError('Existing owned storage required')
    native = owned_path(value['nativeStorageRoot'], root)
    runtime = file_pin(value['runtimeConfig'], root)
    pin = value['nativePython']
    if set(pin) != {'path', 'sha256'}: raise ValueError('Pinned native interpreter required')
    python = Path(pin['path'])
    # A venv's executable may link to its installed base interpreter. Its private
    # environment and dependencies still live on the selected verification SSD.
    if (not python.is_absolute() or not python.is_relative_to(root)
            or python.parent.resolve() != python.parent or sha(python) != pin['sha256']
            or not os.access(python, os.X_OK)):
        raise ValueError('Existing native operator Python required')
    config = document(runtime)
    if bool(config.get('live')) != (value['inference'] == 'live'):
        raise ValueError('Requested inference must match the actual selected runtime')
    from urllib.parse import urlsplit
    if any(urlsplit(config[key]).hostname not in {'localhost', '127.0.0.1'}
           for key in ('public_origin', 'host_origin', 'backend_url')):
        raise ValueError('Only the owned loopback synthetic environment is supported')
    manifest = owned_path(config['manifest'], root)
    if set(value['drivers']) != {item[0] for item in DRIVERS.values()}:
        raise ValueError('Both peer-owned guarded drivers must be pinned')
    # Peer source may be an extracted package outside the private runtime root.
    # Its exact files are immutable inputs, never arbitrary command arguments.
    drivers = {}
    for name, pin in value['drivers'].items():
        if set(pin) != {'path', 'sha256'}:
            raise ValueError('Exact peer driver pin required')
        path = Path(pin['path'])
        if (not path.is_absolute() or path.resolve() != path or path.name != name
                or path.parent.name != 'scripts' or sha(path) != pin['sha256']):
            raise ValueError('Expected committed peer native driver required')
        drivers[name] = path
    if not isinstance(value['stages'], list) or not 1 <= len(value['stages']) <= 32:
        raise ValueError('Bounded ordered native stages required')
    ids = set()
    stages = []
    for row in value['stages']:
        if set(row) != {'id', 'scenario', 'context', 'release', 'requires'}:
            raise ValueError('Closed stage shape required')
        if (not isinstance(row['id'], str) or not row['id'].isascii()
                or not row['id'].replace('-', '').isalnum() or len(row['id']) > 80
                or row['id'] in ids or row['scenario'] not in SCENARIOS
                or not isinstance(row['requires'], list) or len(row['requires'])>32
                or any(not isinstance(item,str) for item in row['requires'])
                or len(set(row['requires']))!=len(row['requires'])):
            raise ValueError('Unique stage and bounded explicit dependencies required')
        ids.add(row['id'])
        context_path = file_pin(row['context'], root)
        ctx = document(context_path, 65536)
        if ctx.get('schema') not in DRIVERS or ctx['runtime']['subject'] != 'test-user-001':
            raise ValueError('Accepted finite synthetic native context required')
        from uuid import UUID
        if str(UUID(ctx['runId'])) != ctx['runId']:
            raise ValueError('Canonical single-run identity required')
        if context_path.parent.parent != native / 'core-workflows':
            raise ValueError('Peer-owned private native context directory required')
        if any(ctx['runtime']['launchEnvironment'][key] != config[field] for key, field in
               (('VF_OS_ORIGIN', 'public_origin'), ('VF_HOST_ORIGIN', 'host_origin'),
                ('VF_NATIVE_INTEGRATION_BASE', 'backend_url'))):
            raise ValueError('Native context must select the exact installed runtime')
        release = owned_path(row['release'], root) if row['release'] is not None else None
        stages.append(dict(row, contextPath=context_path, value=ctx, releasePath=release))
    return root, native, runtime, manifest, python, drivers, stages


def accepted_stage(stage, native, observer):
    """Join actual driver, canonical observer and exact single-run result facts."""
    ctx = stage['value']
    _, prefix, native_pass, observer_pass = DRIVERS[ctx['schema']]
    claim_path = native / 'evidence/native-ui-gesture' / (prefix + ctx['runId']) / 'once-claim.json'
    claim = document(claim_path)
    result_path = Path(ctx['actualResultFile'])
    result = document(result_path)
    if (claim['state'] != native_pass or claim['exitCode'] != 0
            or claim['runId'] != ctx['runId'] or claim['contextSHA256'] != sha(stage['contextPath'])
            or claim.get('authorityRenewal', False) is not False
            or observer['state'] != observer_pass or observer['result'] != result
            or result['runId'] != ctx['runId'] or result['taskState'] != 'COMPLETED'
            or observer['taskId'] != result['taskId']
            or not all(observer[key] is True for key in ('noTaskAdmission', 'noDecision', 'noEffectDispatch'))):
        raise ValueError('Actual native/canonical evidence did not join; preserve original run')
    canonical=observer['canonical']
    if (canonical[0]!='COMPLETED' or canonical[3]!='CLOSED' or not canonical[6]
            or any(type(value) is not int or value!=0 for value in canonical[6].values())):
        raise ValueError('Original canonical Root must be closed with zero held usage')
    if ctx['schema'] == 'vf.native-workflow-context/1':
        if (not claim.get('backendReadbackVerified') or observer['canonicalReceipt']['status'] != 'COMMITTED'
                or observer['canonicalReceipt']['id'] not in result['receiptIds']):
            raise ValueError('Canonical committed receipt and native product read-back required')
    elif result['productEffectCount'] != 0 or not claim.get('independentReadbackVerified'):
        raise ValueError('Actual read-only source and unchanged native product proof required')
    return dict(taskId=result['taskId'], result=dict(path=str(result_path), sha256=sha(result_path)),
                claim=dict(path=str(claim_path), sha256=sha(claim_path)))


def retained_stages(path, expected_sha, root, native, inference):
    """Retain actual passed stage evidence; never run a prior context again."""
    path=owned_path(str(path),root)
    if sha(path)!=expected_sha:raise ValueError('Exact original report SHA256 required')
    prior=document(path)
    if prior['schema']!='poc-demo-report/1' or prior['inference']!=inference:
        raise ValueError('Same explicit inference and original stage report required')
    retained={}
    for item in prior['stages']:
        # A failed aggregate stays failed. Only its independently passed stages
        # with all original native/canonical artifacts can be retained.
        if item['state']!='PASS_ACTUAL_UI_CANONICAL_AND_READBACK':continue
        context=file_pin(item['context'],root);ctx=document(context,65536)
        observer_path=file_pin(item['evidence']['observer'],root)
        stage=dict(value=ctx,contextPath=context)
        evidence=accepted_stage(stage,native,document(observer_path,16*1024*1024))
        if (item['runId']!=ctx['runId'] or item['id'] in retained
                or any(item['evidence'][key]!=evidence[key] for key in evidence)):
            raise ValueError('Retained stage facts differ from original native evidence')
        retained[item['id']]=dict(originalReport=str(path),originalReportSHA256=expected_sha,
                                 runId=ctx['runId'],evidence=evidence)
    if not retained:raise ValueError('No actual passed native stage can be retained')
    return retained


def main(argv=None):
    os.umask(0o077)
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['run'])
    p.add_argument('--environment', required=True, type=Path)
    p.add_argument('--scenarios', default=','.join(SCENARIOS))
    p.add_argument('--stage', action='append', default=[], help='Only explicit affected stages; no full-demo claim')
    p.add_argument('--inference', choices=['live', 'deterministic'], required=True)
    p.add_argument('--report', required=True, type=Path)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--retain-report',type=Path,help='Original stage report; never re-executed')
    p.add_argument('--retain-report-sha256',help='Exact separately retained original report digest')
    a = p.parse_args(argv)
    value = document(a.environment)
    root, native, runtime, manifest, python, drivers, stages = environment(value)
    report_path = owned_path(str(a.report), root)
    if report_path.exists() or not report_path.parent.is_dir():
        p.error('New report in an existing owned private directory required')
    requested = a.scenarios.split(',')
    if len(set(requested)) != len(requested) or not set(requested) <= set(SCENARIOS):
        p.error('Select distinct S1–S5 scenarios')
    if a.inference != value['inference']:
        p.error('Explicit inference selection differs from the installed runtime')
    if bool(a.retain_report)!=bool(a.retain_report_sha256):p.error('Complete original report pin required')
    retained=(retained_stages(a.retain_report,a.retain_report_sha256,root,native,a.inference)
              if a.retain_report else {})
    selected = [s for s in stages if s['scenario'] in requested and (not a.stage or s['id'] in a.stage)]
    if not selected or set(a.stage) - {s['id'] for s in selected}:
        p.error('Requested affected stage is absent')
    report = dict(schema='poc-demo-report/1', state='PREFLIGHT',
        atUTC=datetime.now(timezone.utc).isoformat(), inference=a.inference,
        environmentSHA256=sha(a.environment), stages=[], fullDemoAccepted=False,
        scope='ACTUAL_SELECTED_NATIVE_STAGES_ONLY', automaticRetry=False,
        serviceShutdown=False, fixtureReset=False, allowanceOrAuthorityRenewal=False)
    report['retainedStages']=retained
    def save():
        private_write(report_path, json.dumps(report, indent=2).encode(), replace=report_path.exists())
    save()
    missing = set(requested)-{s['scenario'] for s in selected}
    if missing:
        report.update(state='BLOCKED_UNCONFIGURED_SCENARIOS', unconfiguredScenarios=sorted(missing)); save(); return 2
    available=set(retained)
    for stage in selected:
        if stage['id'] in available or not set(stage['requires'])<=available:
            report.update(state='BLOCKED_DEPENDENCY_OR_ALREADY_PASSED_STAGE');save();return 2
        available.add(stage['id'])
    with (native / 'core-workflows/poc-demo.lock').open('a+b') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        completed = set(retained)
        for stage in selected:
            ctx = stage['value']; driver_name, _, _, _ = DRIVERS[ctx['schema']]
            item = dict(id=stage['id'], scenario=stage['scenario'], state='NOT_RUN', runId=ctx['runId'],
                        context=dict(path=str(stage['contextPath']),sha256=sha(stage['contextPath'])))
            report['stages'].append(item); save()
            if not set(stage['requires']) <= completed:
                item.update(state='BLOCKED', reason='Dependency has no pass in this invocation; never replay it automatically')
                report['state'] = 'BLOCKED'; save(); return 2
            command = [str(python), '-B', str(drivers[driver_name]), '--context', str(stage['contextPath'])]
            preflight = subprocess.run(command, capture_output=True, text=True,
                env=dict(os.environ, VF_SSD_ROOT=str(native), TMPDIR=str(native/'tmp'), PYTHONDONTWRITEBYTECODE='1'))
            item['preflightExitCode'] = preflight.returncode
            if preflight.returncode:
                item['state'] = report['state'] = 'FAIL_PREFLIGHT'; save(); return 1
            item['state'] = 'PREFLIGHT_PASS_NO_UI_OR_SEND'; save()
            if not a.execute:
                completed.add(stage['id']); continue
            if stage['releasePath'] is None:
                item['state'] = report['state'] = 'BLOCKED_MISSING_EXPLICIT_RELEASE'; save(); return 2
            # Current idle and finite peer release checks precede the sole Send.
            with connect_owned(manifest) as db:
                if (db.execute("SELECT count(*) FROM os_direct_executions WHERE state IN ('STARTING','RUNNING')").fetchone()[0]
                        or db.execute("SELECT count(*) FROM personal_learning_jobs WHERE state='RUNNING'").fetchone()[0]):
                    item['state'] = report['state'] = 'BLOCKED_ACTIVE_RUN'; save(); return 2
            observer_path = report_path.with_name(report_path.stem+'-'+stage['id']+'-observer.json')
            log_path = report_path.with_name(report_path.stem+'-'+stage['id']+'-observer.log')
            after = datetime.now(timezone.utc).isoformat()
            observer_command = [sys.executable, '-B', str(Path(__file__).with_name('native_observer.py')),
                '--runtime-config', str(runtime), '--context', str(stage['contextPath']), '--after', after,
                '--report', str(observer_path), '--history-timezone', value['historyTimezone']]
            if observer_path.exists() or log_path.exists():
                raise ValueError('Observer evidence must not preexist')
            with log_path.open('xb') as log:
                observer = subprocess.Popen(observer_command, stdout=log, stderr=subprocess.STDOUT,
                    env=dict(os.environ, TMPDIR=str(root/'tmp'), PYTHONDONTWRITEBYTECODE='1'))
                ready_until = time.monotonic()+30
                while observer.poll() is None and time.monotonic() < ready_until:
                    if observer_path.exists() and document(observer_path).get('readiness') == 'ACTUAL_VALIDATED_READ_ONLY_CONNECTION_AND_CURRENT_OWNER_READY':
                        break
                    time.sleep(.2)
                else:
                    # Only our observation process; no task or native execution started.
                    if observer.poll() is None: observer.terminate()
                    observer.wait(timeout=10)
                    item['state'] = report['state'] = 'FAIL_OBSERVER_READINESS'; save(); return 1
                item.update(state='RELEASED_TO_PEER_SINGLE_CLAIM', observerFile=str(observer_path)); save()
                ui_log = report_path.with_name(report_path.stem+'-'+stage['id']+'-native.log')
                with ui_log.open('xb') as out:
                    result = subprocess.run(command+['--release', str(stage['releasePath']), '--execute'],
                        stdout=out, stderr=subprocess.STDOUT,
                        env=dict(os.environ, VF_SSD_ROOT=str(native), TMPDIR=str(native/'tmp'), PYTHONDONTWRITEBYTECODE='1'))
                # The bounded read-only observer is allowed to collect original closure.
                observer.wait(timeout=460)
            item.update(nativeExitCode=result.returncode, observerExitCode=observer.returncode)
            try:
                if result.returncode or observer.returncode: raise ValueError('Original UI/observer failed')
                item['evidence'] = accepted_stage(stage, native, document(observer_path, 16*1024*1024))
                item['evidence']['observer']=dict(path=str(observer_path),sha256=sha(observer_path))
                item['state'] = 'PASS_ACTUAL_UI_CANONICAL_AND_READBACK'
            except (ValueError, KeyError, OSError):
                item['state'] = report['state'] = 'FAILED_OR_UNCERTAIN_DO_NOT_REPEAT'; save(); return 1
            completed.add(stage['id']); save()
        report['state'] = 'PASS_SELECTED_STAGES' if a.execute else 'PREFLIGHT_PASS_NO_UI_OR_SEND'
        # Scenario coverage alone does not prove every mandatory runbook obligation.
        # Full acceptance remains the requirement-to-evidence review's responsibility.
        report['coveredScenarios'] = sorted({s['scenario'] for s in selected})
        report['unconfiguredScenarios'] = sorted(set(requested)-{s['scenario'] for s in selected})
        save()
        return 2 if report['unconfiguredScenarios'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
