#!/usr/bin/env python3
"""Source-tree compatibility entry for the installed reviewed POC composition."""
from agentic_os.adapters.poc.runtime_review import configuration, validate_configuration, policies, compose, main


if __name__ == '__main__':
    main()
