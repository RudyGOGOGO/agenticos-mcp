# Guarded native demo stages

`poc/poc-demo` coordinates the existing peer-owned one-shot native drivers and the
packaged read-only `native_observer.py`. It does not create plans, model answers,
Tasks, approvals, effect receipts, credentials or fixture resets. The native app
performs every Send/edit/confirmation; Core owns authority and accounting. The
observer reads the actual authenticated UI/source state and original canonical
receipt, then supplies the finite native read-back handoff.

This is the executable native-stage portion of the complete demo runner. The
ordered fixture B/reflection, schedule, recovery and whole S1–S5 runbook acceptance
remain open. `fullDemoAccepted` is always false: a selected stage pass cannot
silently claim the complete design. Missing requested scenarios block before any
UI. Component tests and scripted replies do not establish integration acceptance.

## Inputs and commands

Keep the configuration, contexts, releases, reports, dependencies and temporary
files on the owned verification SSD. Use the installed Core Python for
`POC_CORE_PYTHON`; use the separately installed app operator Python in the
environment file. The exact committed peer scripts must already be available.
No dependency installation or build occurs here.

The private environment JSON has this closed shape (replace every example path
and SHA with the real artifact; these examples are not runnable credentials):

```json
{
  "schema": "poc-demo-environment/1",
  "synthetic": true,
  "storageRoot": "/Volumes/OWNED-VERIFICATION",
  "nativeStorageRoot": "/Volumes/OWNED-VERIFICATION/native-output",
  "runtimeConfig": {"path": "/Volumes/OWNED-VERIFICATION/core/runtime.json", "sha256": "ACTUAL_SHA256"},
  "nativePython": {"path": "/Volumes/OWNED-VERIFICATION/native-output/venv/bin/python", "sha256": "ACTUAL_EXECUTABLE_SHA256"},
  "historyTimezone": "America/New_York",
  "inference": "live",
  "drivers": {
    "run_native_workflow_once.py": {"path": "/absolute/app-package/scripts/run_native_workflow_once.py", "sha256": "ACTUAL_SHA256"},
    "run_native_readonly_once.py": {"path": "/absolute/app-package/scripts/run_native_readonly_once.py", "sha256": "ACTUAL_SHA256"}
  },
  "stages": [
    {
      "id": "location",
      "scenario": "S1",
      "context": {"path": "/Volumes/OWNED-VERIFICATION/native-output/core-workflows/ACTUAL_RUN_UUID/context.json", "sha256": "ACTUAL_SHA256"},
      "release": null,
      "requires": []
    }
  ]
}
```

Run default preparation first:

```sh
export POC_CORE_PYTHON=/absolute/installed-core/bin/python
export TMPDIR=/Volumes/OWNED-VERIFICATION/tmp
poc/poc-demo run --environment /absolute/private/demo.json --scenarios S1 \
  --stage location --inference live --report /absolute/private/new-preflight.json
```

Preflight invokes the actual peer script without `--execute`, checking native
binary pins and real synthetic product prerequisites. No UI or Send occurs.
Explicit `live` must match the selected runtime; there is no inference fallback.

Before execution the Core operator must independently check the sole cumulative
allowance, preserve every UNKNOWN, obtain the supported finite account/receipt
publication, and issue the existing closed one-run native release bound to the
exact context, processes and qualified test bundle. Put its actual path in
`release`; it is not an OS grant and cannot renew a Root. Run with a new report
and `--execute`. The coordinator checks actual idle state, waits for the observer's
real current-owner readiness, then invokes exactly one peer claim. The existing
peer capacity, current-process, finite credential and one-claim guards remain.

The report joins the actual UI exit, original single-run claim, canonical observer
and exact native result. A write needs the same COMMITTED receipt plus verified
product read-back. A read needs the actual source surface and zero product effects.
Failure or uncertainty stops dependent stages and retains all evidence. Inspect
the original Task/claim; never rerun a consumed context, recreate a possibly
committed object, extend a deadline or release UNKNOWN usage to obtain a pass.

The coordinator serializes its native stages with one private lock. Coordinate
exclusive simulator use with the app chat. It never stops the demonstration
services, deletes fixtures or destroys databases/keys/journals/outboxes. Finite
observer credentials still need their normal supported refresh; refresh is
separate from effect authority. The native, observer and canonical clocks remain
separate; do not subtract unrelated timestamps for latency claims.

## Receipt-derived follow-ups

After the actual location stage completes, prepare its child with the same
installed Core Python:

```sh
"$POC_CORE_PYTHON" -B poc/native_context.py boundary \
  --runtime-config /absolute/private/runtime.json \
  --native-root /Volumes/OWNED-VERIFICATION/native-output \
  --parent-context /absolute/private/completed-location/context.json
```

This obtains the current authenticated Core continuation and uses the actual
UI's `continuationDraft`, binding the exact committed receipt and resource. It
copies only the declared synthetic edit inputs and protected owner credential
for a later separately released UI step. It creates no release or Send.

After that child also completes, `poc/native_context.py read` accepts the same
arguments plus `--boundary-context /absolute/private/completed-child/context.json`.
It joins distinct completed Tasks/receipts and the same actual location, then
pins the currently offered read-only assistant, registered profile and exact
expected read inputs. The named Tom/place request is an explicit synthetic
qualification input, not a scripted model answer. Canonical admission, current
source validation and native read-back still happen during actual execution.
These commands do not substitute a guessed UUID, old unrelated receipt, failed
aggregate or UNKNOWN outcome for a completed parent. Their actual positive
integration remains open until the corresponding real stages complete.

A later invocation can satisfy an explicit `requires` dependency with
`--retain-report /absolute/private/original-report.json --retain-report-sha256
ACTUAL_REPORT_SHA256`. The coordinator rechecks the original context, native
claim, canonical observer and result digests; the original Root must be CLOSED
with zero held usage. It retains only actual passed stages, even when a later
stage made the aggregate fail. That original failed aggregate stays failed.
Changed artifacts/inference or unfinished/UNKNOWN stages cannot be retained.
Do not also select a retained stage for execution: that is refused before UI.
The new child still performs its current product/dependency/auth checks and needs
its own fresh release and owner decision. Retention grants no new authority and
does not refresh original credentials, deadlines or effects.

## Deliberate stream recovery prerequisite

`poc/native_stream_probe.py` is an opt-in local qualification helper, disabled in
normal services. Its `install(manifest, target_file, report)` is for the existing
owned qualification launcher before serving traffic. The private target has
schema `poc-native-stream-close/1`, a fresh UUID `authorization`, exact `subject`
namespace, completed read `taskId` and `conversationId`, and integer
`expiresAtEpoch` no more than900 seconds ahead. It refuses an active SDK/learning
run, a foreign installation, non-read profile, effect work or unclosed/held Root.

First obtain the actual current authenticated source surface. Historical passing
evidence is not permission to bypass a current403 or changed source. Only then,
at an owned idle boundary, may the qualification launcher install this helper.
It closes once after a validated text event during that completed read's replay.
Original human-wait/uncertainty stream boundaries take precedence. Existing
WebView code must perform cursor resume and fresh full-state/source reads.

The bounded report records only route categories, cursor presence, sequence,
status and monotonic numeric times; no text, cursor/token or headers. SQL
eligibility and helper tests alone do not close T9. Native recovery must still
show the same current answer, cursor-bearing resume, current snapshot refetch
and no new Task/effect. Preserve failed reports and disable the probe for normal
operation. It never renews credentials, Roots, budget or original effect keys.
