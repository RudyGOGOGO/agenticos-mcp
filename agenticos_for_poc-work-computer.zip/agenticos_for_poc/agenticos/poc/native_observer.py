"""Observe one exact synthetic native admission without submitting or approving it.

Use with the peer-owned one-shot native driver. Reports and result handoffs are
observations only; canonical Tasks, original accounting and receipts stay in Core.
No task, effect, owner decision, diagnostic login or service lifecycle call is made.
The explicit native profile may renew only its disjoint read-only receipt credential.
"""
from pathlib import Path
from types import SimpleNamespace as NS
from uuid import UUID
from datetime import datetime,timezone
import argparse,asyncio,json,sys,time,subprocess,os
from contextlib import nullcontext
from sqlalchemy import select
from agentic_os.adapters.local.files import private_read,private_write
from agentic_os.adapters.local.artifacts import LocalArtifacts,LocalKeys
from agentic_os.adapters.local.target import connect_owned
from agentic_os.adapters.postgres.store import ControlStore
from agentic_os.adapters.postgres.models import WorkAttempt
from agentic_os.interaction.history import captured_text
from agentic_os.production.reviewed_effect import ProductionReceiptAuthority,ProductionReviewedEffectLedger
from agentic_os.adapters.poc.effect_provider import ExternalRequestArtifacts
from agentic_os.adapters.poc.receipt_observation import ReceiptWire,ReceiptObservationClient,canonical_outcome
from agentic_os.contracts.validation import validate_contract
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from poc.client import LocalClient




def native_receipt(store,task,c,current,*,expected=None,expected_tool=None):
    """Read a stored settled invocation; this authority cannot execute work."""
    from copy import deepcopy
    from sqlalchemy import text
    from importlib.resources import files
    from agentic_os.adapters.postgres.agent_review_models import AgentEffectReceipt
    from agentic_os.adapters.poc.local_synthetic_access import LocalReceiptIssuer
    from agentic_os.contracts.canonical import digest
    ledger=ProductionReviewedEffectLedger(ProductionReceiptAuthority(store))
    with store.transaction() as db:
        db.execute(text('SET TRANSACTION READ ONLY'))
        receipts=db.scalars(select(AgentEffectReceipt).join(WorkAttempt,WorkAttempt.id==AgentEffectReceipt.binding_id)
            .where(WorkAttempt.task_id==UUID(task),AgentEffectReceipt.payload['status'].as_string()=='COMMITTED')).all()
        if len(receipts)!=1:raise ValueError('One actual committed receipt required')
        saved=deepcopy(receipts[0].payload)
        if digest('receipt',saved)!=receipts[0].observation_digest:raise ValueError('Canonical receipt digest differs')
        work=db.get(WorkAttempt,receipts[0].binding_id)
        if work.state!='SETTLED' or work.actual is None:raise ValueError('Unsettled effect is never a success')
        _,grant=ledger._binding(db,work)
        if grant['taskId']!=str(task) or grant['subject']['applicationId']!=c['application_id']:
            raise ValueError('Original task/application receipt required')
    current.require(grant['subject'])
    material=ExternalRequestArtifacts(Path(c['manifest']).parent/'vf-external-requests',LocalKeys(Path(c['manifest']).parent/'keys')).read(grant)
    if expected is not None and (material['request']['tool']!=expected_tool or material['request']['arguments']!=expected):
        raise ValueError('Actual final arguments differ from owner-edited values')
    wire=ReceiptWire(Path(str(files('agentic_os').joinpath('poc_contracts/receipt-observation.schema.json'))))
    observer=ReceiptObservationClient(wire,c['reviewed_effect']['receipt_url'],None,
        environment=c['reviewed_effect']['backend_environment'],
        local_credentials=LocalReceiptIssuer(c['local_access']['receipt_issuer'],record=current))
    observed=asyncio.run(observer.observe(material['request'],subject=grant['subject']['subjectId']))
    observation,receipt=canonical_outcome(grant,material['request'],observed,resource_type=material['resourceType'])
    if receipt is None or {k:v for k,v in observation.items() if k!='observedAt'}!={k:v for k,v in saved.items() if k!='observedAt'}:
        raise ValueError('Fresh authenticated backend observation differs from canonical receipt')
    return material,observed,observation,receipt


def published_read_surface(context,verification,revision):
    """Reconstruct only a hash-bound, actually committed publication.

    This is operator evidence of the recorded projection, not a new browser
    session, current API response, readiness record or permission. The native
    driver must independently observe these values in the protected WebView.
    """
    from uuid import uuid5
    from agentic_os.adapters.poc.family_reads import UnitLabelledFamilyReads
    from agentic_os.interaction.catalog import CATALOG,surface_hash
    validate_contract('AgentReadVerification',verification)
    if verification['context']!=context:raise ValueError('Exact recorded read context required')
    surface_id=str(uuid5(UUID(context['taskId']),'assistant-surface/1'))
    handles=['source/'+surface_id+'/'+v['id'] for v in verification['answer']['evidence']]
    renderer=UnitLabelledFamilyReads.__new__(UnitLabelledFamilyReads)
    renderer.display_definition=context['definition'];renderer.preserve_extra_fields=context['definition']['revision']>=4
    renderer.selective_rule_fields=context['definition']['revision'] in {6,7}
    messages=renderer.surface_messages(surface_id,verification['answer'],handles,verification)
    value=dict(schema='agentic-os.surface/3',surfaceId=surface_id,taskId=context['taskId'],
        conversationId=context['conversationId'],revision=revision['projectionGeneration'],expectedPreviousRevision=None,
        visibilityGeneration=revision['visibilityGeneration'],projectionGeneration=revision['projectionGeneration'],
        catalogRef=CATALOG,messages=messages)
    value['snapshotHash']=surface_hash(value);validate_contract('AssistantSurface',value)
    if value['snapshotHash']!=revision['snapshotHash']:raise ValueError('Stored publication projection hash differs')
    return value


def native_read_result(a,ctx,c,current,native,context,task,store,artifacts,db,row):
    """Passively corroborate one actual native read; never call a task API."""
    from copy import deepcopy
    from uuid import uuid5
    from sqlalchemy import text
    import hashlib
    from agentic_os.contracts.canonical import digest,parse_canonical_json
    from agentic_os.adapters.postgres.models import (AgentPrivatePayload,AgentPayloadWrite,AssistantSurfaceRevision,AssistantSurface,AgentProfileRecord)
    from poc.native_readback import source_tables
    eligibility_raw=private_read(Path(ctx['admission']['eligibilityFile']),8*1048576)
    if hashlib.sha256(eligibility_raw).hexdigest()!=ctx['admission']['eligibilitySHA256']:raise ValueError('Immutable read eligibility differs')
    eligibility=json.loads(eligibility_raw)
    if (context['definition']!=eligibility['definition'] or context['harness']!=eligibility['harness']
            or context['profile']['ref']!=ctx['admission']['profileId'] or context['profile']['revision']!=ctx['admission']['profileRevision']):raise ValueError('Exact actual admitted read profile required')
    with store.transaction() as orm:
        orm.execute(text('SET TRANSACTION READ ONLY'))
        profile=orm.get(AgentProfileRecord,(UUID(context['subject']['installationId']),UUID(c['application_id']),context['definition']['ref'],context['definition']['revision']))
        if (profile is None or profile.digest!=eligibility['registeredProfileDigest']
                or profile.payload['capabilities']['allowedKinds']!=['read']):raise ValueError('Read-only registered profile differs')
        surface_id=uuid5(UUID(task),'assistant-surface/1');surface=orm.get(AssistantSurface,surface_id)
        revision=orm.get(AssistantSurfaceRevision,uuid5(surface_id,'verified-read-revision/1'))
        ready=orm.get(AgentPrivatePayload,revision.artifact_id) if revision is not None else None
        write=orm.get(AgentPayloadWrite,ready.write_id) if ready is not None else None
        work=orm.get(WorkAttempt,write.attempt_id) if write is not None else None
        if (surface is None or surface.task_id!=UUID(task) or write is None or write.task_id!=UUID(task)
                or write.root_id!=UUID(context['rootId']) or write.schema_ref!='AgentReadVerification'
                or work is None or work.state!='SETTLED' or ready.ciphertext_digest!=revision.ciphertext_digest):raise ValueError('Actual settled read publication required')
        pin=artifacts.pin(str(ready.id))
        if pin['ciphertextDigest']!=ready.ciphertext_digest:raise ValueError('Actual published artifact pin differs')
        raw=artifacts.read(context['subject'],str(ready.id),purpose='artifact')
        if len(raw)!=write.plain_bytes:raise ValueError('Read publication byte bound differs')
        verification_bytes=raw;verification=parse_canonical_json(raw);projection=dict(projectionGeneration=revision.projection_generation,
            visibilityGeneration=revision.visibility_generation,snapshotHash=revision.snapshot_hash)
    surface=published_read_surface(context,verification,projection)
    used=[];calls=[]
    requests=db.execute('SELECT created_at,request FROM os_agent_tool_calls WHERE root_id=%s ORDER BY created_at,id',(context['rootId'],)).fetchall()
    for _,request in requests:
        name=request['record']['capability']['ref'];reference=request['record']['binding']
        if not name.startswith('vf.') or name[3:] not in ctx['admission']['readCapabilities']:raise ValueError('Unexpected non-read tool')
        if artifacts.pin(reference['artifactRef'][9:])['ciphertextDigest']!=reference['ciphertextDigest']:raise ValueError('Tool binding pin differs')
        raw=artifacts.read(context['subject'],reference['artifactRef'][9:],purpose='artifact')
        if len(raw)!=reference['bytes']:raise ValueError('Original tool binding bytes differ')
        binding=parse_canonical_json(raw);validate_contract('AgentSDKToolBinding',binding)
        if binding['context']!=context or binding['capability']!=request['record']['capability']:raise ValueError('Original read context differs')
        used.append(name[3:]);calls.append(dict(tool=name[3:],arguments=parse_canonical_json(binding['argumentsJson'])))
    if not used or not eligibility['expectedInputs'] or any(expected not in calls for expected in eligibility['expectedInputs']):raise ValueError('Original requested reads missing')
    effects=db.execute("SELECT count(*) FROM os_work_attempts WHERE root_id=%s AND kind='agent.effect'",(context['rootId'],)).fetchone()[0]
    if effects:raise ValueError('Read-only run dispatched an effect')
    current.require(context['subject'],native)
    finishes=db.execute('SELECT c.id,c.created_at,s.created_at,f.created_at,f.observation FROM os_agent_model_calls c LEFT JOIN os_agent_model_starts s ON s.id=c.id LEFT JOIN os_agent_model_finishes f ON f.id=c.id WHERE c.task_id=%s ORDER BY c.created_at',(task,)).fetchall()
    if not finishes or any(f[4] is None or f[4]['usage'] is None or f[4]['result']['operation']['usage']['completeness']!='known' for f in finishes):raise ValueError('Known canonical model usage required')
    folder=a.context.parent
    proof=dict(schema='poc-actual-native-read-source-proof/1',context=context,canonical=row,
        recordedCanonicalPublication=surface,publicationArtifactSHA256=hashlib.sha256(verification_bytes).hexdigest(),
        usedCapabilities=sorted(set(used)),actualReadArguments=calls,expectedInputs=eligibility['expectedInputs'],
        productEffectCount=effects,modelFinishes=finishes,noTaskOrEffectDispatchByObserver=True,noDiagnosticLogin=True,
        projectionBasis='ACTUAL_STORED_PUBLICATION_HASH_NOT_A_DIAGNOSTIC_HTTP_RESPONSE',nativeUIAcceptance=False)
    proof_file=folder/'actual-source-proof.json';private_write(proof_file,json.dumps(proof,indent=2,default=str).encode());proof_sha=hashlib.sha256(proof_file.read_bytes()).hexdigest()
    projected=source_tables(surface,proof_sha);projection_file=folder/'actual-source-projection.json'
    private_write(projection_file,json.dumps(projected,indent=2).encode())
    from agentic_os.interaction.history import request_title
    from agentic_os.identity.context import iso
    turn=db.execute('SELECT s.created_at FROM os_tasks t JOIN os_admissions a ON a.task_id=t.id JOIN os_source_inputs s ON s.id=a.source_input_id WHERE t.id=%s',(task,)).fetchone()
    count=db.execute('SELECT count(*) FROM os_tasks WHERE conversation_id=%s',(context['conversationId'],)).fetchone()[0]
    if count!=1 or turn is None:raise ValueError('Exact new single-question conversation required')
    date=subprocess.check_output(['node','-e','process.stdout.write(new Date(process.argv[1]).toLocaleString("en-US",{timeZone:process.argv[2]}))',iso(turn[0]),a.history_timezone],text=True)
    history_label=request_title(ctx['question'])+' 1 question · '+date
    result=dict(schema='vf.native-readonly-result/1',runId=ctx['runId'],question=ctx['question'],taskId=task,rootId=context['rootId'],taskState='COMPLETED',
        historyButtonLabel=history_label,admission=dict(assistantId=ctx['admission']['assistantId'],profileId=context['profile']['ref'],profileRevision=context['profile']['revision'],readOnly=True,usedCapabilities=sorted(set(used))),
        productEffectCount=0,sourceProofFile=str(proof_file),sourceProofSHA256=proof_sha,surfaceFile=str(projection_file),surfaceSHA256=hashlib.sha256(projection_file.read_bytes()).hexdigest())
    private_write(Path(ctx['actualResultFile']),json.dumps(result,indent=2).encode())
    return result


def observe_local_native(a,ctx,c):
    """Diagnostic observation only; the native UI performs every owner action.

    Use canonical SQL and the existing disjoint current-session receipt role.
    Never create a diagnostic login, task, decision, permit or effect.
    """
    from copy import deepcopy
    from sqlalchemy import text
    from agentic_os.adapters.local.resources import read_signed
    from agentic_os.adapters.poc.local_synthetic_access import LocalAccessRecord,LocalReceiptIssuer
    from agentic_os.adapters.postgres.models import Admission,BudgetRoot
    from agentic_os.adapters.postgres.agent_review_models import AgentEffectReceipt
    from agentic_os.contracts.canonical import digest
    from agentic_os.identity.context import iso
    from agentic_os.interaction.history import request_title
    from importlib.resources import files
    readonly=ctx['schema']=='vf.native-readonly-context/2'
    if (not readonly and (ctx['workflow'] not in {'create-location/1','create-boundary-at-created-location/1'}
            or ctx['runtime']['launchEnvironment'].get('VF_LOCAL_SESSION_ACCESS')!='1')):
        raise ValueError('Explicit current native local workflow required')
    configured=c['local_access'];manifest=Path(c['manifest']);review=c['reviewed_effect']
    current=LocalAccessRecord(configured['state_file'],environment_id=configured['environment_id'],
        backend_environment=review['backend_environment'])
    native=current.require({'subjectId':ctx['runtime']['subject']})
    if readonly and (ctx['runtime']['launchEnvironment']!={} or ctx['nativeSession']!={k:current.read()[k] for k in ('subject','sessionId','generation')}):
        raise ValueError('Exact current keyless native read binding required')
    wire=ReceiptWire(Path(str(files('agentic_os').joinpath('poc_contracts/receipt-observation.schema.json'))))
    if a.preflight:
        with connect_owned(manifest,autocommit=True) as db:
            db.read_only=True
            db.execute('SELECT payload,binding_id,observation_digest FROM os_agent_effect_receipts WHERE false').fetchall()
            db.execute('SELECT context,authority FROM os_admissions WHERE false').fetchall()
        value=dict(schema='poc-native-observer-readiness/1',state='PREFLIGHT_PASS_NATIVE_READ_ONLY',
            nativeBinding=native,paidCalls=0,effectDispatch=0,loginCalls=0,providerCalls=0,
            resultSchema='vf.native-readonly-result/1' if readonly else 'vf.native-workflow-result/1')
        if a.existing_receipt_task is not None:
            task=str(UUID(a.existing_receipt_task));store=ControlStore(manifest)
            try:
                material,observed,observation,receipt=native_receipt(store,task,c,current)
                value.update(state='PASS_CURRENT_NATIVE_ROLE_EXISTING_CANONICAL_RECEIPT',taskId=task,
                    originalFinalMCPRequest=material['request'],providerReceipt=observed,canonicalReceipt=receipt,
                    providerCalls=1,originalTaskOrGrantExtended=False,actualNativeUIAcceptance=False)
            finally:store.close()
        private_write(a.report,json.dumps(value,indent=2).encode());print(json.dumps(value));return
    artifacts=LocalArtifacts(manifest.parent/'artifacts',LocalKeys(manifest.parent/'keys'))
    report=dict(schema='poc-actual-native-workflow-observer/1',context=str(a.context),after=a.after,
        noTaskAdmission=True,noDecision=True,noEffectDispatch=True,noDiagnosticLogin=True,
        nativeBinding=native,state='WAITING_EXACT_NATIVE_ADMISSION',atUTC=datetime.now(timezone.utc).isoformat())
    def save():private_write(a.report,json.dumps(report,indent=2,default=str).encode(),replace=a.report.exists())
    save();started=time.monotonic();deadline=started+450;selected=None
    with connect_owned(manifest,autocommit=True) as db:
        db.read_only=True
        while time.monotonic()<deadline:
            rows=db.execute("SELECT d.context,t.id,s.artifact_id,s.expires_at,s.digest,a.purpose,a.classification,a.expires_at,a.ciphertext_digest,s.created_at FROM os_tasks t JOIN os_admissions d ON d.task_id=t.id JOIN os_source_inputs s ON s.id=d.source_input_id JOIN os_artifacts a ON a.id=s.artifact_id WHERE s.created_at>=%s AND d.context->'subject'->>'applicationId'=%s AND d.context->'subject'->>'subjectId'=%s ORDER BY s.created_at LIMIT 8",(a.after,c['application_id'],ctx['runtime']['subject'])).fetchall()
            matches=[]
            for context,tid,aid,expiry,hashed,purpose,classification,artifact_expiry,cipher,created in rows:
                question=captured_text(artifacts,context['subject'],NS(expires_at=expiry,digest=hashed),
                    NS(id=aid,purpose=purpose,classification=classification,expires_at=artifact_expiry,ciphertext_digest=cipher))
                if question==ctx['question']:matches.append((context,str(tid),created))
            if len(matches)>1:raise ValueError('Ambiguous native admission; never select a replacement')
            if matches:selected=matches[0];break
            time.sleep(.5)
        if selected is None:raise TimeoutError('No exact actual native admission')
        context,task,created=selected
        if readonly:
            if context['definition']['ref']!='poc-family-read/1':raise ValueError('Actual read-only journey required')
        elif context['definition']['ref']!='poc-family-change/1' or context['definition']['revision']!=2:
            raise ValueError('Exact registered change journey required')
        store=ControlStore(manifest)
        try:
            with store.transaction() as orm:
                orm.execute(text('SET TRANSACTION READ ONLY'))
                root=orm.get(BudgetRoot,UUID(context['rootId']));admission=orm.get(Admission,root.admission_id)
                if admission.context!=context or admission.authority['subject']!=context['subject']:
                    raise ValueError('Original canonical admission required')
                sessions=read_signed(manifest.parent/('vf-host-sessions-'+c['application_id']+'.json'),
                    manifest.parent/'owner.key',maximum=131072)['sessions']
                session=sessions.get(admission.authority['hostSessionRef'])
                if (not session or session['subject']!=context['subject'] or session.get('native')!=native
                        or session['generation']!=admission.authority['sessionGeneration']):
                    raise ValueError('Original native Host binding required, not a diagnostic replacement')
                initial_deadline=root.deadline
            report.update(contextBinding=context,taskId=task,inputCapturedAt=created,originalDeadline=initial_deadline,state='ADMITTED');save()
            print(json.dumps(dict(state='OBSERVER_BOUND_ACTUAL_NATIVE_ADMISSION',taskId=task)),flush=True)
            while time.monotonic()<deadline:
                row=db.execute('SELECT t.state,t.deadline,r.state,r.deadline,r.spent,r.outstanding FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=%s',(task,)).fetchone()
                if row[3]!=initial_deadline:raise ValueError('Original Root deadline changed')
                current.require(context['subject'],native)
                if row[0]!=report['state']:report.update(state=row[0],canonical=row);save()
                if row[0] in {'COMPLETED','FAILED','EXPIRED','CANCELLED','QUARANTINED'}:break
                time.sleep(.5)
            if row[0]!='COMPLETED' or row[2]!='CLOSED' or any(row[5].values()):
                raise ValueError('No complete settled canonical outcome; never publish a successful result')
            if readonly:
                result=native_read_result(a,ctx,c,current,native,context,task,store,artifacts,db,row)
                report.update(result=result,state='COMPLETED_ACTUAL_READ_SOURCE_SURFACE',observerElapsedMs=int((time.monotonic()-started)*1000),actualNativeUIAcceptance=False);save()
                print(json.dumps(dict(state=report['state'],taskId=task,result=ctx['actualResultFile'])));return
            expected=deepcopy(ctx['amended']['location'] if ctx['workflow']=='create-location/1' else ctx['amended']['boundary'])
            if ctx['workflow']=='create-location/1':
                from decimal import Decimal
                for field in ('latitude','longitude'):
                    if type(expected[field]) is str:
                        decimal=Decimal(expected[field]);number=float(decimal)
                        if Decimal(str(number))!=decimal:raise ValueError('Inexact expected coordinate')
                        expected[field]=number
            expected_tool='CreateSavedLocation' if ctx['workflow']=='create-location/1' else 'CreateGeofence'
            if expected_tool=='CreateGeofence':
                parent=json.loads(private_read(Path(ctx['priorResultFile']),65536))
                if parent['schema']!='vf.native-workflow-result/1' or parent['taskState']!='COMPLETED' or parent['geofenceId'] is not None:
                    raise ValueError('Actual completed parent receipt required for passive location verification')
                expected['savedLocationId']=parent['locationId']
            material,observed,observation,receipt=native_receipt(store,task,c,current,expected=expected,expected_tool=expected_tool)
            turns=db.execute("SELECT t.id,s.created_at,s.artifact_id,s.expires_at,s.digest,a.purpose,a.classification,a.expires_at,a.ciphertext_digest FROM os_tasks t JOIN os_admissions d ON d.task_id=t.id JOIN os_source_inputs s ON s.id=d.source_input_id JOIN os_artifacts a ON a.id=s.artifact_id WHERE t.conversation_id=%s AND d.context->'subject'=%s::jsonb ORDER BY s.created_at,t.id",(context['conversationId'],json.dumps(context['subject']))).fetchall()
            if not turns or task not in {str(v[0]) for v in turns}:raise ValueError('Original conversation metadata missing')
            first=turns[0];question=captured_text(artifacts,context['subject'],NS(expires_at=first[3],digest=first[4]),
                NS(id=first[2],purpose=first[5],classification=first[6],expires_at=first[7],ciphertext_digest=first[8]))
            title=request_title(question) if question is not None else 'Application conversation'
            date=subprocess.check_output(['node','-e','process.stdout.write(new Date(process.argv[1]).toLocaleString("en-US",{timeZone:process.argv[2]}))',iso(turns[-1][1]),a.history_timezone],text=True)
            label=title+' '+str(len(turns))+(' question' if len(turns)==1 else ' questions')+' · '+date
            resource=observed['evidence']['resourceId']
            result=dict(schema='vf.native-workflow-result/1',runId=ctx['runId'],workflow=ctx['workflow'],taskId=task,
                taskState='COMPLETED',receiptIds=[observation['receiptId']],locationId=resource if expected_tool=='CreateSavedLocation' else expected['savedLocationId'],
                geofenceId=None if expected_tool=='CreateSavedLocation' else resource,historyButtonLabel=label)
            if ctx['priorResultFile'] is not None:
                result['parentReceiptId']=json.loads(private_read(Path(ctx['priorResultFile']),65536))['receiptIds'][0]
            report.update(result=result,originalFinalMCPRequest=material['request'],providerReceipt=observed,
                canonicalReceipt=receipt,canonical=row,state='COMPLETED_ACTUAL_CANONICAL_RECEIPT',
                observerElapsedMs=int((time.monotonic()-started)*1000),actualNativeUIAcceptance=False)
            private_write(Path(ctx['actualResultFile']),json.dumps(result,indent=2).encode());save()
            print(json.dumps(dict(state=report['state'],taskId=task,receiptId=observation['receiptId'],result=ctx['actualResultFile'])))
        except BaseException as error:
            report.update(observerErrorType=type(error).__name__);save();raise
        finally:store.close()


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runtime-config',required=True,type=Path);p.add_argument('--context',required=True,type=Path);p.add_argument('--after',required=True);p.add_argument('--report',required=True,type=Path);p.add_argument('--preflight',action='store_true');p.add_argument('--history-timezone',required=True);p.add_argument('--native-profile',action='store_true');p.add_argument('--existing-receipt-task');a=p.parse_args(argv)
    ctx=json.loads(private_read(a.context,65536));c=json.loads(private_read(a.runtime_config,65536));manifest=Path(c['manifest'])
    if a.existing_receipt_task is not None and not(a.native_profile and a.preflight):raise ValueError('Existing receipt lookup requires explicit native preflight')
    assert a.context.is_absolute() and a.runtime_config.is_absolute() and a.report.is_absolute()
    from urllib.parse import urlsplit
    from zoneinfo import ZoneInfo
    ZoneInfo(a.history_timezone)
    assert all(urlsplit(c[key]).hostname in {'127.0.0.1','localhost'} for key in ('public_origin','host_origin'))
    assert ctx['runtime']['subject']=='test-user-001'
    if ctx['schema']=='vf.native-readonly-context/2':
        if not a.native_profile or ctx['runtime']['launchEnvironment']!={}:raise ValueError('Explicit current native read profile required')
    else:
        assert ctx['runtime']['launchEnvironment']['VF_OS_ORIGIN']==c['public_origin']
        assert ctx['runtime']['launchEnvironment']['VF_HOST_ORIGIN']==c['host_origin']
    readonly=ctx['schema'] in {'vf.native-readonly-context/1','vf.native-readonly-context/2'}
    assert readonly or ctx['schema'] in {'vf.native-workflow-context/1','vf.native-workflow-context/2'}
    assert not a.report.exists() and not Path(ctx['actualResultFile']).exists()
    if a.native_profile:
        if ctx['schema'] not in {'vf.native-workflow-context/1','vf.native-workflow-context/2','vf.native-readonly-context/2'} or c.get('local_access') is None:raise ValueError('Explicit current local native observer required')
        try:return observe_local_native(a,ctx,c)
        except BaseException as error:
            failed=(json.loads(private_read(a.report,2*1024*1024)) if a.report.exists() else
                dict(schema='poc-actual-native-workflow-observer/1',context=str(a.context)))
            failed.update(state='FAILED_OR_UNCERTAIN_OBSERVER_NO_REPLAY',observerErrorType=type(error).__name__,
                noTaskAdmission=True,noDecision=True,noEffectDispatch=True,noDiagnosticLogin=True)
            private_write(a.report,json.dumps(failed,indent=2,default=str).encode(),replace=a.report.exists())
            raise
    if c.get('local_access') is not None:raise ValueError('Native profile cannot use a diagnostic browser login')
    if a.preflight:
        from importlib.resources import files
        wire=Path(str(files('agentic_os').joinpath('poc_contracts/receipt-observation.schema.json')));ReceiptWire(wire)
        with connect_owned(manifest) as db:
            db.execute('SELECT c.id,c.created_at,s.created_at,f.created_at,f.observation FROM os_agent_model_calls c LEFT JOIN os_agent_model_starts s ON s.id=c.id LEFT JOIN os_agent_model_finishes f ON f.id=c.id WHERE false').fetchall()
            db.execute('SELECT created_at,request FROM os_agent_tool_calls WHERE false ORDER BY created_at,id').fetchall()
            db.execute('SELECT t.state,t.deadline,r.id,r.state,r.deadline,r.spent,r.outstanding FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE false').fetchall()
        date=subprocess.check_output(['node','-e','process.stdout.write(new Date("2026-11-03T04:33:33Z").toLocaleString("en-US",{timeZone:process.argv[1]}))',a.history_timezone],text=True)
        value=dict(schema='poc-native-observer-readiness/1',state='PREFLIGHT_PASS_NO_TASK_OR_PROVIDER_CALL',installedReceiptWire=str(wire),sqlProjectionColumns='PASS',nodeHistoryFormatter=date,paidCalls=0,effectDispatch=0)
        private_write(a.report,json.dumps(value,indent=2).encode());print(json.dumps(value));raise SystemExit(0)
    artifacts=LocalArtifacts(manifest.parent/'artifacts',LocalKeys(manifest.parent/'keys'))
    client=LocalClient(c['public_origin'],c['host_origin'],embed_ref='vf.poc.embed/'+c['application_id'])
    report=dict(schema='poc-actual-native-workflow-observer/1',context=str(a.context),after=a.after,noTaskAdmission=True,noDecision=True,noEffectDispatch=True,state='STARTING_READ_ONLY_OBSERVER',atUTC=datetime.now(timezone.utc).isoformat())
    def save():private_write(a.report,json.dumps(report,indent=2,default=str).encode(),replace=a.report.exists())
    save();start=time.monotonic();deadline=start+450;task=None;read_db=None
    try:
        read_db=connect_owned(manifest,autocommit=True)
        read_db.read_only=True
        client.sign_in(native_origin_header=False)
        report.update(state='WAITING_EXACT_NATIVE_ADMISSION',readiness='ACTUAL_VALIDATED_READ_ONLY_CONNECTION_AND_CURRENT_OWNER_READY');save()
        print(json.dumps(dict(state='OBSERVER_READY_NO_SEND',report=str(a.report))),flush=True)
        while time.monotonic()<deadline:
            with nullcontext(read_db) as db:
                rows=db.execute("SELECT d.context,t.id,s.artifact_id,s.expires_at,s.digest,a.purpose,a.classification,a.expires_at,a.ciphertext_digest,s.created_at FROM os_tasks t JOIN os_admissions d ON d.task_id=t.id JOIN os_source_inputs s ON s.id=d.source_input_id JOIN os_artifacts a ON a.id=s.artifact_id WHERE s.created_at>=%s AND d.context->'subject'->>'applicationId'=%s AND d.context->'subject'->>'subjectId'=%s ORDER BY s.created_at LIMIT 8",(a.after,c['application_id'],'test-user-001')).fetchall()
            matches=[]
            for context,tid,aid,expiry,hashed,purpose,classification,artifact_expiry,cipher,created in rows:
                text=captured_text(artifacts,context['subject'],NS(expires_at=expiry,digest=hashed),NS(id=aid,purpose=purpose,classification=classification,expires_at=artifact_expiry,ciphertext_digest=cipher))
                if text==ctx['question']:matches.append((context,str(tid),created))
            assert len(matches)<=1,'Ambiguous exact native admission; never select a replacement'
            if matches:
                context,task,created=matches[0]
                if readonly:
                    eligibility=json.loads(private_read(Path(ctx['admission']['eligibilityFile']),8*1048576))
                    assert eligibility['schema']=='poc-current-native-read-eligibility/1' and eligibility['allowedKinds']==['read']
                    assert __import__('hashlib').sha256(private_read(Path(ctx['admission']['eligibilityFile']),8*1048576)).hexdigest()==ctx['admission']['eligibilitySHA256']
                    assert context['definition']==eligibility['definition'] and context['harness']==eligibility['harness']
                    assert context['profile']['ref']==ctx['admission']['profileId'] and context['profile']['revision']==ctx['admission']['profileRevision']
                    assert context['definition']['ref']==ctx['admission']['assistantId']=='poc-family-read/1'
                else:assert context['definition']['ref']=='poc-family-change/1' and context['definition']['revision']==2
                report.update(contextBinding=context,taskId=task,inputCapturedAt=created,state='ADMITTED');save();break
            time.sleep(1)
        if task is None:raise TimeoutError('No exact native admission')
        while time.monotonic()<deadline:
            with nullcontext(read_db) as db:
                state=db.execute('SELECT state FROM os_tasks WHERE id=%s',(task,)).fetchone()[0]
            if state!=report['state']:report.update(state=state,observedAtUTC=datetime.now(timezone.utc).isoformat());save()
            if state=='WAITING_INPUT' and 'ownerQuestion' not in report:
                report['ownerQuestion']=client.request('GET','/os/ui/tasks/'+task+'/owner-input');save()
            if state=='WAITING_APPROVAL' and 'preparedReview' not in report:
                report['preparedReview']=client.request('GET','/os/ui/agent-review/tasks/'+task+'/review')
                report['pendingContinuation']=client.request('GET','/os/ui/agent-review/tasks/'+task+'/continuation');save()
            if state in {'COMPLETED','FAILED','EXPIRED','CANCELLED','QUARANTINED'}:break
            time.sleep(.5)
        report['status']=(dict(snapshot=client.request('GET','/os/tasks/'+task),receipt=None) if readonly else
            client.request('GET','/os/ui/agent-review/tasks/'+task))
        with nullcontext(read_db) as db:
            report['canonical']=db.execute('SELECT t.state,t.deadline,r.id,r.state,r.deadline,r.spent,r.outstanding FROM os_tasks t JOIN os_budget_roots r ON r.id=t.budget_root_id WHERE t.id=%s',(task,)).fetchone()
            report['modelFinishes']=db.execute('SELECT c.id,c.created_at,s.created_at,f.created_at,f.observation FROM os_agent_model_calls c LEFT JOIN os_agent_model_starts s ON s.id=c.id LEFT JOIN os_agent_model_finishes f ON f.id=c.id WHERE c.task_id=%s ORDER BY c.created_at',(task,)).fetchall()
            report['toolRequests']=db.execute('SELECT created_at,request FROM os_agent_tool_calls WHERE root_id=%s ORDER BY created_at,id',(context['rootId'],)).fetchall()
        save()
        assert state=='COMPLETED','Original task did not complete; no result manufactured'
        if readonly:
            import hashlib
            from poc.native_readback import source_tables
            assert report['canonical'][3]=='CLOSED' and not any(report['canonical'][6].values())
            allowed=set(ctx['admission']['readCapabilities']);used=[];read_calls=[]
            with nullcontext(read_db) as db:
                current_profile=db.execute('SELECT payload,digest FROM os_agent_profiles WHERE installation_id=%s AND application_id=%s AND definition_ref=%s AND revision=%s',
                    (context['subject']['installationId'],context['subject']['applicationId'],context['definition']['ref'],context['definition']['revision'])).fetchone()
            assert current_profile is not None and current_profile[1]==eligibility['registeredProfileDigest']
            assert current_profile[0]['capabilities']['allowedKinds']==['read']
            from agentic_os.production.profiles import version_pin
            assert version_pin(current_profile[0]['definition'],'definition')==context['definition']
            for _,request in report['toolRequests']:
                name=request['record']['capability']['ref']
                assert name.startswith('vf.') and name[3:] in allowed
                used.append(name[3:])
                reference=request['record']['binding']
                assert artifacts.pin(reference['artifactRef'][9:])['ciphertextDigest']==reference['ciphertextDigest']
                raw_binding=artifacts.read(context['subject'],reference['artifactRef'][9:],purpose='artifact')
                assert len(raw_binding)==reference['bytes']
                binding=json.loads(raw_binding);validate_contract('AgentSDKToolBinding',binding)
                assert binding['context']==context and binding['capability']==request['record']['capability']
                read_calls.append(dict(tool=name[3:],arguments=json.loads(binding['argumentsJson'])))
            assert used
            assert eligibility['expectedInputs']
            for expected in eligibility['expectedInputs']:
                assert set(expected)=={'tool','arguments'} and expected['tool'] in allowed
                assert any(call['tool']==expected['tool'] and all(call['arguments'].get(k)==v for k,v in expected['arguments'].items()) for call in read_calls)
            with nullcontext(read_db) as db:
                effects=db.execute("SELECT count(*) FROM os_work_attempts WHERE root_id=%s AND kind='agent.effect'",(context['rootId'],)).fetchone()[0]
            assert effects==0
            surface=client.request('GET','/os/ui/tasks/'+task+'/surface')
            assert surface['taskId']==task and surface['conversationId']==context['conversationId']
            folder=a.context.parent
            proof=dict(schema='poc-actual-native-read-source-proof/1',context=context,canonical=report['canonical'],
                snapshot=report['status']['snapshot'],actualSourceSurface=surface,usedCapabilities=sorted(set(used)),
                actualReadArguments=read_calls,expectedInputs=eligibility['expectedInputs'],
                productEffectCount=effects,modelFinishes=report['modelFinishes'],noTaskOrEffectDispatchByObserver=True)
            raw=json.dumps(proof,indent=2,default=str).encode();proof_file=folder/'actual-source-proof.json';private_write(proof_file,raw);proof_sha=hashlib.sha256(raw).hexdigest()
            projection=source_tables(surface,proof_sha)
            projection_file=folder/'actual-source-projection.json';projection_raw=json.dumps(projection,indent=2).encode();private_write(projection_file,projection_raw)
            history=client.request('GET','/os/ui/history');turns=sorted([v for v in history['tasks'] if v['conversationId']==context['conversationId']],key=lambda x:x['createdAt'])
            assert len(turns)==1 and turns[0]['taskId']==task
            date=subprocess.check_output(['node','-e','process.stdout.write(new Date(process.argv[1]).toLocaleString("en-US",{timeZone:process.argv[2]}))',turns[0]['createdAt'],a.history_timezone],text=True)
            label=(turns[0].get('title') or 'Application conversation')+' 1 question · '+date
            result=dict(schema='vf.native-readonly-result/1',runId=ctx['runId'],question=ctx['question'],taskId=task,
                rootId=context['rootId'],taskState='COMPLETED',historyButtonLabel=label,
                admission=dict(assistantId=ctx['admission']['assistantId'],profileId=context['profile']['ref'],profileRevision=context['profile']['revision'],readOnly=True,usedCapabilities=sorted(set(used))),
                productEffectCount=effects,sourceProofFile=str(proof_file),sourceProofSHA256=proof_sha,
                surfaceFile=str(projection_file),surfaceSHA256=hashlib.sha256(projection_raw).hexdigest())
            private_write(Path(ctx['actualResultFile']),json.dumps(result,indent=2).encode())
            report.update(result=result,state='COMPLETED_ACTUAL_READ_SOURCE_SURFACE',observerElapsedMs=int((time.monotonic()-start)*1000));save()
            print(json.dumps(dict(state=report['state'],taskId=task,result=ctx['actualResultFile'])))
            raise SystemExit(0)
        receiptref=report['status']['receipt'];assert receiptref['observation']['status']=='COMMITTED'
        store=ControlStore(manifest)
        try:
            ledger=ProductionReviewedEffectLedger(ProductionReceiptAuthority(store))
            with store.transaction() as db:
                work=db.get(WorkAttempt,UUID(receiptref['bindingId']))
                assert str(work.task_id)==task and work.state=='SETTLED' and work.actual is not None
                _,grant=ledger._binding(db,work)
            material=ExternalRequestArtifacts(manifest.parent/'vf-external-requests',LocalKeys(manifest.parent/'keys')).read(grant)
            from importlib.resources import files
            wire=ReceiptWire(Path(str(files('agentic_os').joinpath('poc_contracts/receipt-observation.schema.json'))))
            observer=ReceiptObservationClient(wire,c['reviewed_effect']['receipt_url'],c['reviewed_effect']['receipt_token_file'],environment=c['reviewed_effect']['backend_environment'])
            observed=asyncio.run(observer.observe(material['request'],subject='test-user-001'))
            observation,receipt=canonical_outcome(grant,material['request'],observed,resource_type=material['resourceType'])
            validate_contract('EffectReceipt',receipt)
            assert observation['receiptId']==receiptref['observation']['receiptId'] and receipt['status']=='COMMITTED'
            evidence=observed['evidence'];resource=evidence['resourceId']
            report.update(originalFinalMCPRequest=material['request'],providerReceipt=observed,canonicalReceipt=receipt)
        finally:store.close()
        history=client.request('GET','/os/ui/history');turns=sorted([v for v in history['tasks'] if v['conversationId']==context['conversationId']],key=lambda x:x['createdAt'])
        assert any(v['taskId']==task for v in turns)
        title=turns[0].get('title') or 'Application conversation';created=turns[-1]['createdAt'];count=len(turns)
        date=subprocess.check_output(['node','-e','process.stdout.write(new Date(process.argv[1]).toLocaleString("en-US",{timeZone:process.argv[2]}))',created,a.history_timezone],text=True)
        label=title+' '+str(count)+(' question' if count==1 else ' questions')+' · '+date
        result=dict(schema='vf.native-workflow-result/1',runId=ctx['runId'],workflow=ctx['workflow'],taskId=task,taskState='COMPLETED',receiptIds=[observation['receiptId']],locationId=resource if ctx['workflow']=='create-location/1' else material['request']['arguments']['savedLocationId'],geofenceId=None if ctx['workflow']=='create-location/1' else resource,historyButtonLabel=label)
        if ctx['priorResultFile'] is not None:result['parentReceiptId']=json.loads(private_read(Path(ctx['priorResultFile']),65536))['receiptIds'][0]
        continuation=client.request('GET','/os/ui/agent-review/tasks/'+task+'/continuation');report['readyContinuation']=continuation
        private_write(Path(ctx['actualResultFile']),json.dumps(result,indent=2).encode())
        report.update(result=result,state='COMPLETED_ACTUAL_CANONICAL_RECEIPT',observerElapsedMs=int((time.monotonic()-start)*1000));save()
        print(json.dumps(dict(state=report['state'],taskId=task,receiptId=observation['receiptId'],result=ctx['actualResultFile'])))
    except SystemExit as error:
        if not (readonly and error.code==0 and report['state']=='COMPLETED_ACTUAL_READ_SOURCE_SURFACE'):
            report['observerErrorType']=type(error).__name__;save()
        raise
    except BaseException as error:
        report['observerErrorType']=type(error).__name__;save();raise
    finally:
        client.close()
        if read_db is not None:read_db.close()


if __name__=='__main__':main()
