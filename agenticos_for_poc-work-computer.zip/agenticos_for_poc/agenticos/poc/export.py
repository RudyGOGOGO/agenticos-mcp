#!/usr/bin/env python3
"""POC checkpoint export over the unchanged conflict-safe upstream sync."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile

BASE='62b208b74bded2160f11bcb2187ab14591465c0f'
RELEASE='modules/agentic-os/poc/release.json'


def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])


def metadata(repo,manifest):
    value=json.loads(manifest);commit=value['sourceCommit']
    release=json.loads(git(repo,'show',commit+':'+RELEASE))
    if release['schema']!='poc-release-source/1' or release['sourceBaseCommit']!=BASE:
        raise ValueError('Explicit POC source lineage required')
    if subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',BASE,commit]).returncode:
        raise ValueError('Frozen authoritative ancestry missing')
    return dict(schema='poc-export-checkpoint/1',sourceCommit=commit,release=release,
        upstreamExportManifestSHA256=hashlib.sha256(manifest).hexdigest(),
        sync='unchanged committed deploy/agentic-os/sync.py; full source paths, SHA256 and modes',
        safety='Dry-run by default; managed conflicts and unowned files preserved; no activation or provisioning')


def export(repo,revision,destination,*,apply=False):
    if destination.is_symlink() or destination.name!='agenticos_deployment_aws':
        raise ValueError('Use the dedicated separate POC export directory')
    repo=repo.resolve(strict=True);destination=destination.resolve(strict=True)
    commit=git(repo,'rev-parse','--verify','--end-of-options',revision+'^{commit}').decode().strip()
    tool=repo/'deploy/agentic-os/sync.py'
    if tool.read_bytes()!=git(repo,'show',commit+':deploy/agentic-os/sync.py'):
        raise ValueError('Use the exact committed upstream synchronizer')
    spec=importlib.util.spec_from_file_location('poc_upstream_sync',tool)
    sync=importlib.util.module_from_spec(spec);spec.loader.exec_module(sync)
    prior=destination/'export-manifest.json';marker=destination/'poc-export.json'
    if marker.is_symlink():raise ValueError('POC metadata must be a regular owned file')
    if prior.exists():
        expected=metadata(repo,prior.read_bytes())
        if not marker.is_file() or json.loads(marker.read_bytes())!=expected:
            raise ValueError('POC metadata conflict; preserve and return the edit upstream')
    elif marker.exists():raise ValueError('Unowned POC metadata already exists')
    # Validate the selected release before any destination mutation.
    metadata(repo,json.dumps(dict(sourceCommit=commit)).encode())
    selected,changes=sync.synchronize(repo,commit,destination,apply=apply)
    if apply:
        value=metadata(repo,prior.read_bytes())
        fd,path=tempfile.mkstemp(prefix='.poc-export-',dir=destination)
        try:
            with os.fdopen(fd,'w') as out:json.dump(value,out,sort_keys=True,indent=2);out.write('\n')
            os.chmod(path,0o644);os.replace(path,marker)
        finally:
            if os.path.exists(path):os.unlink(path)
    return dict(mode='APPLIED' if apply else 'DRY_RUN',sourceCommit=selected,changedFiles=len(changes),
        additions=sum(action=='+' for action,_ in changes),updates=sum(action=='~' for action,_ in changes),
        removals=sum(action=='-' for action,_ in changes))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-repo',type=Path,required=True);parser.add_argument('--revision',required=True)
    parser.add_argument('--destination',type=Path,required=True);parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    print(json.dumps(export(args.source_repo,args.revision,args.destination,apply=args.apply),indent=2))
