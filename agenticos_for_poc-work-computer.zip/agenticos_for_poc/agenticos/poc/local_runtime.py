#!/usr/bin/env python3
"""Source-tree compatibility entry for the installed local POC composition."""
import argparse
import asyncio
from pathlib import Path

from agentic_os.adapters.poc.runtime_local import (
    configuration, validate_configuration, policy_processes, compose, serve, _serve)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    asyncio.run(serve(configuration(args.config)))
