"""Independent Host-owned exact read authorization. No kernel imports.

Only the existing notes read is supported. Operator-reviewed OS pins never
supply Host resource permission. The Host reviews its own pin/profile mapping,
checks exact arguments and re-reads every disclosed value/version locally.
"""
from datetime import datetime,timedelta,timezone
import hashlib
import json
import re
import sqlite3
from uuid import UUID,uuid5
from agent_scope import canonical,scope_request,scope_response


def parse(raw):
    if len(raw)>65536:raise ValueError()
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise ValueError()
            result[key]=value
        return result
    def reject(_):raise ValueError()
    value=json.loads(raw,object_pairs_hook=pairs,parse_float=reject,parse_constant=reject)
    canonical(value).encode('utf-8')
    return value


def keys(value,names):
    if type(value) is not dict or set(value)!=set(names.split(',')):raise ValueError()


def ident(value):
    if type(value) is not str or str(UUID(value))!=value:raise ValueError()


def number(value,minimum=0):
    if type(value) is not int or not minimum<=value<=2**53-1:raise ValueError()


def reference(value):
    if type(value) is not str or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}',value):raise ValueError()


def fingerprint(value,domain='command'):
    return hashlib.sha256(('agentic-os.hash/1\0'+domain+'\0'+canonical(value)).encode()).hexdigest()


def request(raw,cfg,*,observation_until=None,root=None):
    value=parse(raw);keys(value,'binding,profile,providerRef,phase,candidateJson');b=value['binding']
    keys(b,'context,identity,modelOperationId,modelResult,capability,toolName,callId,callIndex,argumentsJson')
    # Reuse the independently implemented Host context/pin reader, not OS code.
    scope_request(canonical(dict(context=b['context'],capabilities=[b['capability'],value['profile']])).encode(),cfg,observation_until=observation_until)
    c=b['context'];i=b['identity'];keys(i,'operationId,taskId,rootId,segmentId,intentRevision,controlEpoch,planRevision,parentOperationId,iteration,kind,inputDigest')
    for k in ('taskId','rootId','segmentId','intentRevision','controlEpoch'):
        if canonical(i[k])!=canonical(c[k]):raise ValueError()
    for k in ('operationId','modelOperationId'):ident(i[k] if k=='operationId' else b[k])
    if i['kind']!='tool' or i['parentOperationId']!=b['modelOperationId']:raise ValueError()
    number(i['iteration']);number(i['planRevision'],1);number(b['callIndex'])
    if type(b['callId']) is not str or not 1<=len(b['callId'])<=512:raise ValueError()
    if i['operationId']!=str(uuid5(UUID(b['modelOperationId']),'sdk-tool/'+b['callId'])):raise ValueError()
    r=b['modelResult'];keys(r,'subject,taskId,rootId,resultId,producerStepId,acceptedAttemptId,payload,lineageRef,scopeRef,acceptedAt')
    if any(r[k]!=c[k] for k in ('subject','taskId','rootId')):raise ValueError()
    for k in ('resultId','producerStepId','acceptedAttemptId'):ident(r[k])
    if r['lineageRef'] is not None:reference(r['lineageRef'])
    reference(r['scopeRef'])
    if type(r['acceptedAt']) is not str or not 1<=len(r['acceptedAt'])<=40:raise ValueError()
    accepted=datetime.fromisoformat(r['acceptedAt'].replace('Z','+00:00'))
    if not datetime.fromisoformat(c['admittedAt'].replace('Z','+00:00'))<=accepted<=datetime.now(timezone.utc):raise ValueError()
    p=r['payload'];keys(p,'artifactRef,ciphertextDigest,bytes,schemaRef,schemaVersion');reference(p['artifactRef']);number(p['bytes']);number(p['schemaVersion'],1)
    if p['schemaRef']!='AgentProviderResponse' or p['schemaVersion']!=1 or not re.fullmatch('[a-f0-9]{64}',p['ciphertextDigest']):raise ValueError()
    binding={k:b[k] for k in ('modelResult','capability','callId','callIndex','toolName','argumentsJson')}
    if i['inputDigest']!=fingerprint(binding):raise ValueError()
    if b['toolName']!='cap_'+hashlib.sha256(canonical(b['capability']).encode()).hexdigest()[:40]:raise ValueError()
    if value['phase'] not in {'dispatch','disclose'} or (value['phase']=='dispatch')!=(value['candidateJson'] is None):raise ValueError()
    if value['candidateJson'] is not None and (type(value['candidateJson']) is not str or not 2<=len(value['candidateJson'].encode())<=65536):raise ValueError()
    if value['providerRef']!=cfg['mcpRef']:raise PermissionError()
    if b['capability']['ref']!=cfg['descriptor']['id'] and (root is None or not reviewed_read(value,root)):
        raise PermissionError()
    if type(b['argumentsJson']) is not str:raise ValueError()
    arguments=parse(b['argumentsJson'].encode());keys(arguments,'resourceType,externalIds,fieldNames')
    if arguments['resourceType']!='note':raise PermissionError()
    for name in ('externalIds','fieldNames'):
        items=arguments[name]
        if (type(items) is not list or len(items)>32 or any(type(v) is not str or not 1<=len(v)<=256 for v in items)
                or len(set(items))!=len(items)):raise ValueError()
    return value,fingerprint(value),arguments


def rows(cfg,root,user,arguments):
    ids=arguments['externalIds'] or cfg['users'][user]['resources'];fields=arguments['fieldNames'] or ['title','body']
    if len(ids)>32 or set(ids)-set(cfg['users'][user]['resources']) or set(fields)-{'title','body'}:raise PermissionError()
    records=[];refs=[];subject={**cfg['namespace'],'tenantId':cfg['tenant'],'subjectId':user}
    with sqlite3.connect((root/'notes.sqlite').as_uri()+'?mode=ro',uri=True) as db:
        for key in ids:
            row=db.execute('SELECT title,body,revision FROM notes WHERE note_key=? AND owner=?',(key,user)).fetchone()
            if row:
                records.append([dict(name=n,value=row[i]) for i,n in enumerate(['title','body']) if n in fields])
                refs.append(dict(subject=subject,providerId=cfg['mcpRef'],resourceType='note',contractVersion=1,externalId=key,observedVersion=str(row[2])))
    return fields,records,refs


def reviewed_read(value,root):
    """Only explicit Host-owned pin/profile mappings alias the same notes read."""
    binding=value['binding'];context=binding['context']
    path=root/'agent-capabilities.json'
    reviews=json.loads(path.read_bytes()) if path.exists() else []
    return any(item['pin']==binding['capability'] and item['purpose']==context['purpose'] and item['kind']=='read'
        and context['subject']['subjectId'] in item['subjects']
        and item.get('read')==dict(profile=value['profile'],toolName='agent_notes_read') for item in reviews)


def response(value,hashed,arguments,cfg,state,root,issue,*,observation_until=None):
    b=value['binding'];c=b['context'];user=c['subject']['subjectId'];tool='agent_notes_read'
    if observation_until is not None and value['phase']!='disclose':raise PermissionError()
    scope=scope_response(dict(context=c,capabilities=[b['capability']]),hashed,cfg,state,root,observation_until=observation_until)
    allowed=bool(scope['capabilities']) and reviewed_read(value,root)
    if allowed:
        fields,records,refs=rows(cfg,root,user,arguments)
        if value['phase']=='disclose':
            candidate=parse(value['candidateJson'].encode());keys(candidate,'evidence,records,nextCursor');e=candidate['evidence']
            keys(e,'id,subject,providerRef,resourceRefs,observedAt,classification,quality,completeness,publicFields,formatterRef,formatterVersion,coreDigest')
            ident(e['id'])
            if type(e['observedAt']) is not str or not 1<=len(e['observedAt'])<=40:raise ValueError()
            observed=datetime.fromisoformat(e['observedAt'].replace('Z','+00:00'))
            if not datetime.fromisoformat(c['admittedAt'].replace('Z','+00:00'))<=observed<=datetime.now(timezone.utc):raise ValueError()
            core=dict(evidence={k:v for k,v in e.items() if k!='coreDigest'},records=candidate['records'])
            allowed=allowed and e['subject']==c['subject'] and e['providerRef']==cfg['mcpRef'] and canonical(e['resourceRefs'])==canonical(refs) and canonical(candidate['records'])==canonical(records)
            allowed=allowed and e['publicFields']==fields and e['classification']=='host-authorized' and e['quality']=='synthetic' and e['completeness']=='1.00'
            allowed=allowed and e['formatterRef']=='notes-table' and type(e['formatterVersion']) is int and e['formatterVersion']==1 and e['coreDigest']==fingerprint(core,'evidence') and candidate['nextCursor'] is None
    credential=issue(user,tool,arguments,scope['validUntil']) if allowed and value['phase']=='dispatch' else None
    return dict(requestDigest=hashed,subject=c['subject'],taskId=c['taskId'],rootId=c['rootId'],policyGeneration=scope['policyGeneration'],
        scopeRef=scope['scopeRef'],allowed=bool(allowed),validUntil=scope['validUntil'],credential=credential)


def observation_request(raw,cfg,*,root=None):
    value=parse(raw);keys(value,'schema,read,policyGeneration,validUntil')
    if (value['schema']!='agent-read-observation/1' or type(value['read']) is not dict
            or value['read'].get('phase')!='disclose'):raise ValueError()
    number(value['policyGeneration'],1)
    if type(value['validUntil']) is not str or not 1<=len(value['validUntil'])<=40:raise ValueError()
    until=datetime.fromisoformat(value['validUntil'].replace('Z','+00:00'));now=datetime.now(timezone.utc)
    if not now<until<=now+timedelta(seconds=30):raise ValueError()
    read,_,arguments=request(canonical(value['read']).encode(),cfg,observation_until=until,root=root)
    return value,read,arguments,until,fingerprint(value)


def observation_response(value,read,arguments,until,hashed,cfg,state,root):
    if state['users'][read['binding']['context']['subject']['subjectId']]['policyGeneration']!=value['policyGeneration']:raise PermissionError()
    def no_execution(*_):raise PermissionError()
    return response(read,hashed,arguments,cfg,state,root,no_execution,observation_until=until)


def matches(grant,tool,arguments):
    return grant.get('readBinding') is None or grant['readBinding']==dict(toolName=tool,arguments=fingerprint(arguments))
