"""Owned synthetic SQLite host; standalone wire implementation, no OS imports.

Local test identities are explicit. Host sessions/CSRF/current notes authority stay
in this process, not in the OS. Test controls live in a private owned fixture file.
"""
import argparse,base64,hashlib,hmac,json,secrets,sqlite3,time
from contextlib import asynccontextmanager
from datetime import datetime,timedelta,timezone
from pathlib import Path
from uuid import uuid4
import httpx
import uvicorn
from typing import Any,Annotated
from pydantic import BaseModel,Field
from agent_models import AgentReadArguments,AgentReadPage

class ReadResult(BaseModel):
    evidence: dict[str,Any]
    records: list[list[dict[str,Any]]]
    nextCursor: str | None = None

from mcp.server.mcpserver import MCPServer,Context
from starlette.applications import Starlette
from starlette.routing import Route,Mount
from starlette.responses import JSONResponse
from source_validity import source_request, permitted
from agent_scope import scope_request,scope_response,scope_observation_request
from agent_read import request as read_request,response as read_response,matches as read_matches,fingerprint
from agent_read import observation_request,observation_response


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,required=True)
    args=parser.parse_args();cfg=json.loads(args.config.read_text());root=args.config.parent
    assert cfg['fixture']=='owned-agentic-os-host' and cfg['kind']=='python-notes'
    sessions={}; grants={}
    def controls():return json.loads((root/'controls.json').read_text())
    def now():return datetime.now(timezone.utc)
    def iso(t):return t.isoformat().replace('+00:00','Z')
    def subject(user):return {**cfg['namespace'],'tenantId':cfg['tenant'],'subjectId':user}
    def exact_subject(value):return value==subject(value.get('subjectId')) and value.get('subjectId') in cfg['users']
    def enabled(user):return user in cfg['users'] and controls()['users'][user]['active']
    def bridge(req):return hmac.compare_digest(req.headers.get('authorization',''),'Bearer '+cfg['bridgeKey'])
    def signed_in(req):
        session=sessions.get(req.cookies.get('notes_login'))
        return session if session and enabled(session['user']) and session['expires']>time.time() else None
    def csrf(req,session):return session and req.headers.get('origin')==cfg['origin'] and hmac.compare_digest(req.headers.get('x-csrf-token',''),session['csrf'])
    async def login(req):
        if req.headers.get('origin')!=cfg['origin']:return JSONResponse({'error':'origin'},403)
        body=await req.json();user=body.get('userRef')
        if set(body)!={'userRef'} or not enabled(user):return JSONResponse({'error':'login'},401)
        cookie=secrets.token_urlsafe(32);generation=controls()['users'][user]['sessionGeneration']
        session={'user':user,'ref':str(uuid4()),'generation':generation,'csrf':secrets.token_urlsafe(32),'expires':time.time()+3600};sessions[cookie]=session
        res=JSONResponse({'csrf':session['csrf'],'hostSessionRef':session['ref'],'sessionGeneration':generation})
        res.set_cookie('notes_login',cookie,httponly=True,samesite='strict');return res
    async def me(req):
        session=signed_in(req)
        return JSONResponse({'userRef':session['user'],'csrf':session['csrf']}) if session else JSONResponse({'error':'login'},401)
    async def bootstrap(req):
        session=signed_in(req)
        if not csrf(req,session):return JSONResponse({'error':'csrf'},403)
        body=await req.json()
        if set(body)!={'challengeId','embedRef','frameNonce','proofKeyThumbprint','expiresAt'} or body['embedRef']!=cfg['embedRef']:
            return JSONResponse({'error':'binding'},400)
        payload={'binding':{'subject':subject(session['user']),**body,'sessionGeneration':session['generation'],
                'audience':'agentic-os.browser','replayId':str(uuid4())},'hostSessionRef':session['ref']}
        # Restored managed installations also verify current release ancestry.
        # Keep the shared finite eight-second client bound: the retained
        # five-operation credential ancestry measured 5.22s for bootstrap.
        async with httpx.AsyncClient(trust_env=False,follow_redirects=False,timeout=8) as client:
            response=await client.post(cfg['osOrigin']+'/os/embed/bootstrap',json=payload,headers={'Authorization':'Bearer '+cfg['bridgeKey']})
        return JSONResponse(response.json(),response.status_code)
    async def check(req):
        if not bridge(req):return JSONResponse({'error':'credential'},401)
        if req.url.path.endswith('/learning/accounts/check'):
            return await learning_account(req)
        if req.url.path.endswith('/learning/sources/check'):
            return await learning_source(req)
        body=await req.json();owner=body.get('subject',{});user=owner.get('subjectId')
        if not exact_subject(owner):return JSONResponse({'error':'scope'},403)
        control=controls()['users'][user];route=req.url.path.rsplit('/',1)[-1]
        if controls().get('outage'):return JSONResponse({'error':'unavailable'},503)
        if route=='check' and req.url.path.endswith('/sessions/check'):
            found=next((s for s in sessions.values() if s['ref']==body.get('hostSessionRef') and s['user']==user),None)
            return JSONResponse({'subject':owner,'active':bool(found and enabled(user) and found['expires']>time.time()
                and found['generation']==control['sessionGeneration']==body.get('sessionGeneration')),
                'sessionGeneration':control['sessionGeneration'],'policyGeneration':control['policyGeneration'],
                'checkedAt':iso(now()),'validUntil':iso(now()+timedelta(seconds=15))})
        if not enabled(user):return JSONResponse({'error':'removed'},403)
        if req.url.path.endswith('/capabilities'):
            return JSONResponse({'capabilities':[cfg['descriptor']] if control['read'] else []})
        bounds=[{'resourceType':'note','externalIds':cfg['users'][user]['resources'],'fieldNames':['title','body']}]
        if req.url.path.endswith('/authority/check'):
            if not control['read'] or body.get('capabilityRef')!=cfg['descriptor']['id'] or body.get('delegationRef') is not None:
                return JSONResponse({'error':'denied'},403)
            ident=str(uuid4());return JSONResponse({'id':ident,'subject':owner,'active':True,
                'policyGeneration':control['policyGeneration'],'capabilityRefs':[cfg['descriptor']['id']],
                'resourceBounds':bounds,'purpose':body['purpose'],'checkedAt':iso(now()),
                'validUntil':iso(now()+timedelta(seconds=15)),'assuranceRef':'local-synthetic','delegationRef':None})
        if req.url.path.endswith('/credentials/issue'):
            if (body.get('endpointRef')!=cfg['mcpRef'] or body.get('capabilityRef')!=cfg['descriptor']['id'] or not control['read']):
                return JSONResponse({'error':'denied'},403)
            access=secrets.token_urlsafe(32);grants[access]={'user':user,'expires':time.time()+30,'generation':control['policyGeneration']}
            return JSONResponse({'accessToken':access,'audienceRef':cfg['mcpAudience'],'subject':owner,
                'capabilityRef':cfg['descriptor']['id'],'expiresAt':iso(now()+timedelta(seconds=30))})
        return JSONResponse({'error':'unsupported'},404)
    async def learning_source(req):
        try:
            if (req.headers.get('content-type','').split(';')[0]!='application/json'
                    or req.headers.get('content-encoding','identity')!='identity'):raise ValueError()
            raw=bytearray()
            async for chunk in req.stream():
                raw.extend(chunk)
                if len(raw)>65536:return JSONResponse({'error':'size'},413)
            value,hashed=source_request(bytes(raw),cfg)
        except (ValueError,TypeError,UnicodeError,RecursionError):return JSONResponse({'error':'invalid'},400)
        state=controls()
        if state.get('outage'):return JSONResponse({'error':'unavailable'},503)
        checked=now()
        return JSONResponse({'subject':value['subject'],'purpose':'OSPersonalSourceValidity/1',
            'active':permitted(value,cfg,state,root),'policyGeneration':state['users'][value['subject']['subjectId']]['policyGeneration'],
            'requestDigest':hashed,'checkedAt':iso(checked),'validUntil':iso(checked+timedelta(seconds=3))})
    async def agent_scope(req):
        if not bridge(req):return JSONResponse({'error':'credential'},401)
        try:
            if (req.headers.get('content-type','').split(';')[0]!='application/json'
                    or req.headers.get('content-encoding','identity')!='identity'):raise ValueError()
            raw=bytearray()
            async for chunk in req.stream():
                raw.extend(chunk)
                if len(raw)>65536:return JSONResponse({'error':'size'},413)
            observation=req.url.path.endswith('/scope-observe')
            if observation:value,hashed,until=scope_observation_request(bytes(raw),cfg)
            else:value,hashed=scope_request(bytes(raw),cfg);until=None
            state=controls()
            if state.get('outage'):return JSONResponse({'error':'unavailable'},503)
            return JSONResponse(scope_response(value,hashed,cfg,state,root,observation_until=until))
        except PermissionError:return JSONResponse({'error':'denied'},403)
        except (ValueError,TypeError,KeyError,UnicodeError,RecursionError):return JSONResponse({'error':'invalid'},400)
    async def agent_read(req):
        if not bridge(req):return JSONResponse({'error':'credential'},401)
        try:
            if (req.headers.get('content-type','').split(';')[0]!='application/json'
                    or req.headers.get('content-encoding','identity')!='identity'):raise ValueError()
            raw=bytearray()
            async for chunk in req.stream():
                raw.extend(chunk)
                if len(raw)>65536:return JSONResponse({'error':'size'},413)
            state=controls()
            if state.get('outage'):return JSONResponse({'error':'unavailable'},503)
            if req.url.path.endswith('/observe'):
                value,read,arguments,until,hashed=observation_request(bytes(raw),cfg,root=root)
                return JSONResponse(observation_response(value,read,arguments,until,hashed,cfg,state,root))
            value,hashed,arguments=read_request(bytes(raw),cfg,root=root)
            def issue(user,tool,arguments,until):
                current=controls()['users'][user]
                if (not current['active'] or not current['read'] or not current.get('assistant',True)
                        or current['policyGeneration']!=state['users'][user]['policyGeneration']):raise PermissionError()
                access=secrets.token_urlsafe(32)
                grants[access]=dict(user=user,expires=datetime.fromisoformat(until.replace('Z','+00:00')).timestamp(),
                    generation=current['policyGeneration'],readBinding=dict(toolName=tool,arguments=fingerprint(arguments)))
                return dict(accessToken=access,audienceRef=cfg['mcpAudience'],subject=subject(user),capabilityRef=value['binding']['capability']['ref'],expiresAt=until)
            return JSONResponse(read_response(value,hashed,arguments,cfg,state,root,issue))
        except PermissionError:return JSONResponse({'error':'denied'},403)
        except (ValueError,TypeError,KeyError,UnicodeError,RecursionError):return JSONResponse({'error':'invalid'},400)
    async def learning_account(req):
        # New closed, bounded account-only DTO. No login or resource grant.
        try:
            if (req.headers.get('content-type','').split(';')[0]!='application/json'
                    or req.headers.get('content-encoding','identity')!='identity'):raise ValueError()
            raw=bytearray()
            async for chunk in req.stream():
                raw.extend(chunk)
                if len(raw)>4096:return JSONResponse({'error':'size'},413)
            def pairs(items):
                value={}
                for key,item in items:
                    if key in value:raise ValueError()
                    value[key]=item
                return value
            body=json.loads(bytes(raw),object_pairs_hook=pairs)
            json.dumps(body,ensure_ascii=False).encode('utf-8')
            if (type(body) is not dict or set(body)!={'subject','purpose'}
                    or body['purpose']!='OSPersonalLearning/1' or type(body['subject']) is not dict):raise ValueError()
            owner=body['subject'];user=owner.get('subjectId')
            if type(user) is not str or not exact_subject(owner):raise ValueError()
        except (ValueError,TypeError,UnicodeError):return JSONResponse({'error':'invalid'},400)
        state=controls()
        if state.get('outage'):return JSONResponse({'error':'unavailable'},503)
        control=state['users'][user];checked=now()
        return JSONResponse({'subject':owner,'purpose':'OSPersonalLearning/1',
            'active':bool(control['active'] and control.get('assistant',True)),
            'policyGeneration':control['policyGeneration'],'checkedAt':iso(checked),
            'validUntil':iso(checked+timedelta(seconds=15))})
    def grant(headers):
        token=headers.get('authorization','').removeprefix('Bearer ');g=grants.get(token)
        if not g or not enabled(g['user']) or g['expires']<=time.time():return None
        c=controls()['users'][g['user']]
        return g['user'] if c['read'] and c['policyGeneration']==g['generation'] and (not g.get('readBinding') or c.get('assistant',True)) else None
    class ReviewedReadServer(MCPServer):
        # Public server extension points preserve the legacy tool's schema.
        # This profile publishes and enforces the same closed argument model.
        async def list_tools(self):
            return [tool.model_copy(update={'input_schema':AgentReadArguments.model_json_schema()})
                if tool.name=='agent_notes_read' else tool for tool in await super().list_tools()]
        async def call_tool(self,name,arguments,context=None):
            if name=='agent_notes_read':
                invalid=False
                try:AgentReadArguments.model_validate(arguments)
                except ValueError:invalid=True
                if invalid:raise ValueError('INVALID')
            return await super().call_tool(name,arguments,context)
    server=ReviewedReadServer('owned-python-notes',version='1.0.0')
    def checked_read(tool,resourceType,externalIds,fieldNames,ctx):
        user=grant(ctx.request_context.request.headers)
        access=ctx.request_context.request.headers.get('authorization','').removeprefix('Bearer ')
        if (not user or resourceType!='note' or set(externalIds)-set(cfg['users'][user]['resources'])
                or set(fieldNames)-{'title','body'} or tool.startswith('agent_') and not grants[access].get('readBinding') or not read_matches(grants[access],tool,
                    dict(resourceType=resourceType,externalIds=externalIds,fieldNames=fieldNames))):raise ValueError('DENIED')
        ids=externalIds or cfg['users'][user]['resources'];records=[];refs=[]
        with sqlite3.connect((root/'notes.sqlite').as_uri()+'?mode=ro',uri=True) as db:
            for ident in ids:
                row=db.execute('SELECT title,body,revision FROM notes WHERE note_key=? AND owner=?',(ident,user)).fetchone()
                if row:
                    records.append([{'name':name,'value':row[index]} for index,name in enumerate(['title','body']) if not fieldNames or name in fieldNames])
                    refs.append({'subject':subject(user),'providerId':cfg['mcpRef'],'resourceType':'note','contractVersion':1,'externalId':ident,'observedVersion':str(row[2])})
        evidence={'id':str(uuid4()),'subject':subject(user),'providerRef':cfg['mcpRef'],'resourceRefs':refs,
            'observedAt':iso(now()),'classification':'host-authorized','quality':'synthetic','completeness':'1.00',
            'publicFields':fieldNames or ['title','body'],'formatterRef':'notes-table','formatterVersion':1,'coreDigest':'0'*64}
        core={'evidence':{k:v for k,v in evidence.items() if k!='coreDigest'},'records':records}
        evidence['coreDigest']=hashlib.sha256(b'agentic-os.hash/1\0evidence\0'+json.dumps(core,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
        return ReadResult(evidence=evidence,records=records,nextCursor=None)
    @server.tool(name='notes_read',structured_output=True)
    def read(resourceType:str,externalIds:list[str],fieldNames:list[str],ctx:Context)->ReadResult:
        return checked_read('notes_read',resourceType,externalIds,fieldNames,ctx)
    @server.tool(name='agent_notes_read',structured_output=True)
    def agent_read_tool(resourceType:Annotated[str,Field(max_length=32)],
                        externalIds:Annotated[list[Annotated[str,Field(max_length=256)]],Field(max_length=32)],
                        fieldNames:Annotated[list[Annotated[str,Field(max_length=256)]],Field(max_length=32)],ctx:Context)->AgentReadPage:
        value=checked_read('agent_notes_read',resourceType,externalIds,fieldNames,ctx)
        return AgentReadPage.model_validate(value.model_dump())
    class Auth:
        def __init__(self,app):self.app=app
        async def __call__(self,scope,receive,send):
            if scope['type']=='http':
                headers={k.decode():v.decode() for k,v in scope['headers']}
                if not grant(headers):return await JSONResponse({'error':'denied'},401)(scope,receive,send)
            await self.app(scope,receive,send)
    mcp=server.streamable_http_app(stateless_http=True,json_response=True,max_request_body_size=65536)
    async def assistant_host(req):
        from starlette.responses import FileResponse
        asset={'/assistant-host':'embed-host.html','/assistant-host.js':'embed-host.mjs','/assistant-host.css':'embed-host.css'}.get(req.url.path)
        if asset:return FileResponse(Path(__file__).resolve().parent.parent/'shared'/asset,media_type={'embed-host.html':'text/html','embed-host.mjs':'text/javascript','embed-host.css':'text/css'}[asset])
        return JSONResponse({k:cfg[k] for k in ('kind','osOrigin','embedRef')}|{'users':list(cfg['users']),'reviewPopups':cfg.get('reviewPopups') is True})
    routes=[Route('/auth/login',login,methods=['POST']),Route('/me',me),
        Route('/host-bridge/agent/v1/scope',agent_scope,methods=['POST']),
        Route('/host-bridge/agent/v1/scope-observe',agent_scope,methods=['POST']),
        Route('/host-bridge/agent/v1/read',agent_read,methods=['POST']),
        Route('/host-bridge/agent/v1/observe',agent_read,methods=['POST']),
        Route('/integrations/agentic-os/bootstrap',bootstrap,methods=['POST'])]
    routes += [Route(path,assistant_host) for path in ('/assistant-host','/assistant-host.js','/assistant-host.css','/assistant-host-config')]
    routes += [Route('/host-bridge/v1'+path,check,methods=['POST']) for path in
        ['/sessions/check','/learning/accounts/check','/learning/sources/check','/authority/check','/capabilities','/credentials/issue']]
    routes.append(Mount('/',Auth(mcp)))
    app=Starlette(routes=routes,lifespan=mcp.router.lifespan_context)
    uvicorn.run(app,host='127.0.0.1',port=cfg['port'],log_level='error',access_log=False)

if __name__=='__main__':main()
