"""Standalone source-only host observation. No OS, login or grant imports."""
import hashlib
import json
import re
import sqlite3

PROFILE = "OSPersonalSourceValidity/1"
REF = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$")


def source_request(raw, cfg):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:raise ValueError()
            result[key] = value
        return result
    def reject(_):raise ValueError()
    value = json.loads(raw, object_pairs_hook=pairs, parse_float=reject, parse_constant=reject)
    json.dumps(value, ensure_ascii=False).encode("utf-8")
    if type(value) is not dict or set(value) != {"subject", "purpose", "resourceRefs", "fieldNames"}:
        raise ValueError()
    owner = value["subject"]
    if (type(owner) is not dict or type(owner.get("subjectId")) is not str
            or owner["subjectId"] not in cfg["users"]
            or owner != {**cfg["namespace"], "tenantId":cfg["tenant"], "subjectId":owner["subjectId"]}
            or value["purpose"] != PROFILE):raise ValueError()
    fields, refs = value["fieldNames"], value["resourceRefs"]
    if (type(fields) is not list or not 1 <= len(fields) <= 32
            or any(type(f) is not str or not REF.fullmatch(f) for f in fields)
            or len(set(fields)) != len(fields) or type(refs) is not list or not 1 <= len(refs) <= 32):
        raise ValueError()
    keys = {"subject", "providerId", "resourceType", "contractVersion", "externalId", "observedVersion"}
    for ref in refs:
        if (type(ref) is not dict or set(ref) != keys or ref["subject"] != owner
                or type(ref["contractVersion"]) is not int or not 1 <= ref["contractVersion"] <= 2**53-1
                or any(type(ref[k]) is not str or not REF.fullmatch(ref[k]) for k in ["providerId", "resourceType"])
                or any(type(ref[k]) is not str or not 1 <= len(ref[k]) <= 256 for k in ["externalId", "observedVersion"])):
            raise ValueError()
    canonical = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    if len({json.dumps(r, sort_keys=True) for r in refs}) != len(refs):raise ValueError()
    return value, hashlib.sha256(b"agentic-os.hash/1\0verification\0"+canonical).hexdigest()


def permitted(value, cfg, state, root):
    user = value["subject"]["subjectId"]; control = state["users"][user]
    if (not control["active"] or not control.get("assistant", True) or not control["read"]
            or set(value["fieldNames"])-{"title", "body"}):return False
    with sqlite3.connect((root/"notes.sqlite").as_uri()+"?mode=ro", uri=True) as db:
        for ref in value["resourceRefs"]:
            if (ref["providerId"] != cfg["mcpRef"] or ref["resourceType"] != "note" or ref["contractVersion"] != 1
                    or ref["externalId"] not in cfg["users"][user]["resources"]):return False
            row = db.execute("SELECT revision FROM notes WHERE note_key=? AND owner=?", (ref["externalId"], user)).fetchone()
            if row is None or str(row[0]) != ref["observedVersion"]:return False
    return True
