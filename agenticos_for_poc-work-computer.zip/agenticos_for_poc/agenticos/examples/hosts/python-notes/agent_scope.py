"""Host-owned read-scope protocol example. No kernel imports or tool grants."""
from datetime import datetime,timedelta,timezone
import hashlib
import hmac
import json
import re
from uuid import UUID

CONTEXT={'subject','taskId','conversationId','segmentId','purpose','definition','profile','harness','model','resourcePolicy',
    'authorityRef','scopeRef','delegationRef','rootId','accountingFormat','intentRevision','controlEpoch','admittedAt','authorizationHorizon','timeZone'}
REF=re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$')


def canonical(value,depth=0):
    if depth>64:raise ValueError()
    if value is None or type(value) is bool:return json.dumps(value)
    if type(value) is int:
        if abs(value)>2**53-1:raise ValueError()
        return str(value)
    if type(value) is str:
        value.encode('utf-8');return json.dumps(value,ensure_ascii=False)
    if type(value) is list:return '['+','.join(canonical(v,depth+1) for v in value)+']'
    if type(value) is dict:
        if any(not key.isascii() for key in value):raise ValueError()
        return '{'+','.join(json.dumps(k)+':'+canonical(value[k],depth+1) for k in sorted(value))+'}'
    raise ValueError()


def document(raw):
    def pairs(items):
        value={}
        for key,item in items:
            if key in value:raise ValueError()
            value[key]=item
        return value
    def reject(_):raise ValueError()
    if len(raw)>65536:raise ValueError()
    return json.loads(raw,object_pairs_hook=pairs,parse_float=reject,parse_constant=reject)


def scope_request(raw,cfg,*,observation_until=None):
    value=document(raw)
    encoded=canonical(value).encode()
    if type(value) is not dict or set(value)!={'context','capabilities'}:raise ValueError()
    c=value['context']
    if type(c) is not dict or set(c)!=CONTEXT or c['accountingFormat']!='agent-resources/1' or c['delegationRef'] is not None:raise ValueError()
    s=c['subject']
    if (type(s) is not dict or type(s.get('subjectId')) is not str or s['subjectId'] not in cfg['users']
            or s!={**cfg['namespace'],'tenantId':cfg['tenant'],'subjectId':s['subjectId']}):raise ValueError()
    for key in ('taskId','conversationId','segmentId','rootId'):
        if type(c[key]) is not str or str(UUID(c[key]))!=c[key]:raise ValueError()
    for key in ('intentRevision','controlEpoch'):
        if type(c[key]) is not int or not 1<=c[key]<=2**53-1:raise ValueError()
    for key in ('purpose','authorityRef','scopeRef'):
        if type(c[key]) is not str or not REF.fullmatch(c[key]):raise ValueError()
    if type(c['timeZone']) is not str or not 1<=len(c['timeZone'])<=128:raise ValueError()
    def pin(p):
        if (type(p) is not dict or set(p)!={'ref','revision','digest'} or type(p['ref']) is not str or not REF.fullmatch(p['ref'])
                or type(p['revision']) is not int or not 1<=p['revision']<=2**53-1 or type(p['digest']) is not str
                or not re.fullmatch('[a-f0-9]{64}',p['digest'])):raise ValueError()
    for key in ('definition','profile','harness','model','resourcePolicy'):pin(c[key])
    for key in ('admittedAt','authorizationHorizon'):
        if type(c[key]) is not str or not 1<=len(c[key])<=40:raise ValueError()
    checked=datetime.now(timezone.utc)
    admitted=datetime.fromisoformat(c['admittedAt'].replace('Z','+00:00'));horizon=datetime.fromisoformat(c['authorizationHorizon'].replace('Z','+00:00'))
    if not admitted<=checked or not admitted<horizon<=admitted+timedelta(days=7):raise ValueError()
    if observation_until is None:
        if not checked<horizon:raise ValueError()
    elif not checked<observation_until<=checked+timedelta(seconds=30):raise ValueError()
    caps=value['capabilities']
    if type(caps) is not list or len(caps)>128:raise ValueError()
    for p in caps:pin(p)
    if len({p['ref'] for p in caps})!=len(caps):raise ValueError()
    return value,hashlib.sha256(b'agentic-os.hash/1\0command\0'+encoded).hexdigest()


def scope_observation_request(raw,cfg):
    value=document(raw)
    if (type(value) is not dict or set(value)!={'schema','scope','validUntil'}
            or value['schema']!='agent-capability-observation/1' or type(value['validUntil']) is not str
            or not 1<=len(value['validUntil'])<=40 or not re.search(r'(Z|[+-][0-9]{2}:[0-9]{2})$',value['validUntil'])):raise ValueError()
    until=datetime.fromisoformat(value['validUntil'].replace('Z','+00:00'))
    request,hashed=scope_request(canonical(value['scope']).encode(),cfg,observation_until=until)
    return request,hashed,until


def scope_response(value,hashed,cfg,state,root,*,observation_until=None):
    c=value['context'];s=c['subject'];control=state['users'][s['subjectId']]
    if not control['active'] or not control.get('assistant',True):raise PermissionError()
    file=root/'agent-capabilities.json'
    allowed=json.loads(file.read_bytes()) if file.exists() else []
    # Every kind still requires this Host's explicit owner/purpose/pin review.
    # Native permission grants no new source access or business tool authority.
    caps=[p for p in value['capabilities'] if control['read'] and any(item['pin']==p and item['purpose']==c['purpose']
        and item['kind'] in {'read','propose','native'} and s['subjectId'] in item['subjects'] for item in allowed)]
    binding=canonical(dict(requestDigest=hashed,policyGeneration=control['policyGeneration'])).encode()
    scope='scope/'+hmac.new(cfg['bridgeKey'].encode(),binding,'sha256').hexdigest()
    until=min(datetime.now(timezone.utc)+timedelta(seconds=30),observation_until or datetime.fromisoformat(c['authorizationHorizon'].replace('Z','+00:00')))
    return dict(subject=s,taskId=c['taskId'],rootId=c['rootId'],requestDigest=hashed,purpose=c['purpose'],
        intentRevision=c['intentRevision'],controlEpoch=c['controlEpoch'],policyGeneration=control['policyGeneration'],
        scopeRef=scope,capabilities=caps,validUntil=until.isoformat().replace('+00:00','Z'))
