"""Host-owned bounded MCP DTOs for the separately reviewed agent read profile."""
from typing import Annotated
from pydantic import BaseModel,ConfigDict,Field

Text=Annotated[str,Field(max_length=256)]
Identifier=Annotated[str,Field(max_length=36,json_schema_extra={'format':'uuid'})]
Instant=Annotated[str,Field(max_length=40,json_schema_extra={'format':'date-time'})]
Positive=Annotated[int,Field(ge=1,le=2**53-1)]


class Closed(BaseModel):
    model_config=ConfigDict(extra='forbid')


class AgentReadArguments(Closed):
    resourceType:Annotated[str,Field(max_length=32)]
    externalIds:Annotated[list[Text],Field(max_length=32)]
    fieldNames:Annotated[list[Text],Field(max_length=32)]


class Subject(Closed):
    installationId:Identifier
    applicationId:Identifier
    tenantId:Text
    subjectId:Text


class Resource(Closed):
    subject:Subject
    providerId:Text
    resourceType:Text
    contractVersion:Positive
    externalId:Text
    observedVersion:Text


class Evidence(Closed):
    id:Identifier
    subject:Subject
    providerRef:Text
    resourceRefs:Annotated[list[Resource],Field(max_length=32)]
    observedAt:Instant
    classification:Text
    quality:Text
    completeness:Annotated[str,Field(max_length=32)]
    publicFields:Annotated[list[Text],Field(max_length=32)]
    formatterRef:Text
    formatterVersion:Positive
    coreDigest:Annotated[str,Field(max_length=64)]


class Cell(Closed):
    name:Text
    value:Annotated[str,Field(max_length=65536)]


class AgentReadPage(Closed):
    evidence:Evidence
    records:Annotated[list[Annotated[list[Cell],Field(max_length=32)]],Field(max_length=32)]
    nextCursor:None
