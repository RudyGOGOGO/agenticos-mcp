"""Unrelated read fixture. G00 probe only; not a qualified HostBridge/MCP server.

Uses an explicitly supplied SQLite file in read-only mode, never a host application
database. G02 adds authenticated authority and MCP behind a separate test manifest.
"""
import argparse
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
import sqlite3


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--port", type=int, required=True)
    args = parser.parse_args()
    database = args.database.resolve(strict=True)

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path != "/fixture/notes":
                self.send_error(404); return
            with sqlite3.connect(database.as_uri() + "?mode=ro", uri=True) as db:
                records = [{"noteKey": key, "title": title}
                           for key, title in db.execute("SELECT note_key,title FROM notes ORDER BY note_key")]
            payload = json.dumps({"fixture": True, "qualified": False, "records": records}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload))); self.end_headers(); self.wfile.write(payload)

        def log_message(self, *_):
            pass

    HTTPServer(("127.0.0.1", args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
