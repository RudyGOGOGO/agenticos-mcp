// Independent laboratory Host. Data and conversion rules belong to this Host.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import {z} from 'zod';
import {canonical,parseCanonical} from './source-wire.mjs';
import {fingerprint,readAuthorization} from './agent-read.mjs';
import {agentOutput} from './agent-read-schema.mjs';

export const laboratoryTool='agent_laboratory_query';
export const laboratoryGrain=['projectId','sampleId','readingId','version'];
export const laboratoryGroups=['sampleId'];
const text=z.string().min(1).max(256),hash=z.string().min(64).max(64);
const integer=z.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
export const laboratoryInput=z.object({projectId:text,metric:text,targetUnit:text,cursor:z.string().min(1).max(256).nullable()}).strict();
const fields=['projectId','sampleId','readingId','version','state','metric','amount','unit','conversionFactor','targetUnit','conversionVersion'];
const projectFields=['projectId','name'];
const declaredEvidence=names=>agentOutput.shape.evidence.extend({publicFields:z.array(text).max(32).meta({const:names})});
const cell=z.object({name:text,value:z.union([z.string().max(65536),z.number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),z.boolean(),z.null()])}).strict();
export const laboratoryOutput=z.object({schema:z.string().max(32).meta({const:'agent-query-page/1'}),
 page:z.object({evidence:declaredEvidence(fields),records:z.array(z.array(cell).max(32)).max(32),nextCursor:z.string().max(256).nullable()}).strict(),
 coverage:z.object({queryRef:text,snapshotRef:text.nullable(),requestedScopeRef:text,coveredScopeRef:text,observedRows:integer,
  expectedRows:integer.nullable(),nextCursorRef:text.nullable(),status:z.enum(['complete','partial','unknown']).meta({maxLength:32}),explanationRef:text.nullable()}).strict(),
 queryDigest:hash,requestCursor:z.string().max(256).nullable(),pageOrdinal:integer,
 grain:z.array(text).min(1).max(64).meta({const:laboratoryGrain}),pageGroupFields:z.array(text).max(64).meta({const:laboratoryGroups})}).strict().describe(
 'amount and unit are raw source measurements, not normalized to the requested targetUnit. Convert with the returned conversionFactor, targetUnit and conversionVersion; filtering unit to the target discards convertible samples. The eligible population is distinct sampleId, including missing measurements; do not include values, states or revisions in population identity or filter missing samples out of that population. Available measurements require state accepted before latest integer version per readingId. Null amounts remain unknown.');
export const laboratoryMetadata={name:laboratoryTool,
 description:'Read every currently authorized sample in one laboratory project, including samples missing the requested metric. Returns all measurement revisions and states. Filter accepted state before selecting the latest integer version per readingId. Conversion factors and versions are Host evidence; apply only the returned targetUnit. Grain: projectId/sampleId/readingId/version. Follow every cursor; sample children stay together. Never treat missing amount as zero.',
 inputSchema:z.toJSONSchema(laboratoryInput,{target:'draft-2020-12',io:'input'}),
 outputSchema:z.toJSONSchema(laboratoryOutput,{target:'draft-2020-12',io:'output'})};
export const laboratoryProjectsTool='agent_laboratory_projects';
export const laboratoryProjectsInput=z.object({cursor:z.string().min(1).max(256).nullable()}).strict();
export const laboratoryProjectsOutput=laboratoryOutput.extend({
 page:laboratoryOutput.shape.page.extend({evidence:declaredEvidence(projectFields)}),
 grain:z.array(text).min(1).max(64).meta({const:['projectId']}),
 pageGroupFields:z.array(text).max(64).meta({const:['projectId']})}).describe('Authorized project identities and names only. A null page.nextCursor completes discovery; use only returned opaque cursors.');
export const laboratoryProjectsMetadata={name:laboratoryProjectsTool,
 description:'List current authorized laboratory projects. Use returned projectId values for measurement queries. Follow only returned nextCursor; null means complete. Never invent a cursor or project ID. Discovery grants no execution authority.',
 inputSchema:z.toJSONSchema(laboratoryProjectsInput,{target:'draft-2020-12',io:'input'}),
 outputSchema:z.toJSONSchema(laboratoryProjectsOutput,{target:'draft-2020-12',io:'output'})};
export function laboratoryArguments(value){const parsed=laboratoryInput.safeParse(value);if(!parsed.success)throw Error('INVALID');return parsed.data}
export function laboratoryProjectsArguments(value){const parsed=laboratoryProjectsInput.safeParse(value);if(!parsed.success)throw Error('INVALID');return parsed.data}
function owned(cfg,state,user,args){
 const c=state.users[user];
 if(cfg.analysisProfile!=='laboratory-query/1'||!c?.active||!c.read||!(c.assistant??true)||!cfg.labProjects?.[user]?.includes(args.projectId))throw Error('DENIED');
}
function ownedProjects(cfg,state,user){
 const c=state.users[user],projects=cfg.labProjects?.[user];
 if(cfg.analysisProfile!=='laboratory-query/1'||cfg.projectDiscoveryEnabled!==true||!c?.active||!c.read||!(c.assistant??true)
  ||!Array.isArray(projects)||new Set(projects).size!==projects.length
  ||projects.some(id=>typeof id!=='string'||id.length<1||id.length>256))throw Error('DENIED');
 return projects;
}
function cursor(cfg,value){
 const {offset,...binding}=value;
 const body=Buffer.from(canonical({binding:fingerprint(binding),offset})).toString('base64url');
 return body+'.'+crypto.createHmac('sha256',cfg.bridgeKey).update('laboratory.query.cursor/1\0'+body).digest('hex');
}
function offset(cfg,token,binding,count){
 if(token===null)return 0;
 if(typeof token!=='string'||token.length>256||!token.includes('.'))throw Error('INVALID');
 const [body,signature,...extra]=token.split('.');
 if(extra.length||!/^[a-f0-9]{64}$/.test(signature))throw Error('INVALID');
 const expected=crypto.createHmac('sha256',cfg.bridgeKey).update('laboratory.query.cursor/1\0'+body).digest('hex');
 if(!crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected)))throw Error('DENIED');
 const value=parseCanonical(Buffer.from(body,'base64url').toString());
 if(!Number.isSafeInteger(value.offset)||value.offset<=0||value.offset%2||value.offset>=count||canonical(value)!==canonical({binding:fingerprint(binding),offset:value.offset}))throw Error('DENIED');
 return value.offset;
}
function material(cfg,state,root,user,args){
 owned(cfg,state,user,args);
 const data=JSON.parse(fs.readFileSync(path.join(root,'laboratory.json')));
 const samples=data.samples.filter(v=>v.project===args.projectId).sort((a,b)=>a.id.localeCompare(b.id));
 if(new Set(samples.map(v=>v.id)).size!==samples.length)throw Error('INVALID');
 const groups=samples.map(sample=>{
  const readings=data.readings.filter(v=>v.sample===sample.id&&v.metric===args.metric).sort((a,b)=>a.id.localeCompare(b.id)||a.version-b.version);
  const values=readings.length?readings:[{id:'missing/'+sample.id+'/'+args.metric,version:0,state:'missing',metric:args.metric,amount:null,unit:null}];
  return values.map(reading=>{
   if(!Number.isSafeInteger(reading.version)||reading.version<0||!['accepted','rejected','missing'].includes(reading.state))throw Error('INVALID');
   if(reading.amount!==null&&(typeof reading.amount!=='string'||!/^[-]?[0-9]+(?:\.[0-9]+)?$/.test(reading.amount)))throw Error('INVALID');
   const rules=data.unitConversions.filter(v=>v.from===reading.unit&&v.to===args.targetUnit);
   if(rules.length>1)throw Error('INVALID');
   const rule=reading.unit===args.targetUnit?{factor:'1',version:'laboratory.identity-units/1'}:rules[0];
   if(reading.amount!==null&&(!rule||typeof rule.factor!=='string'||!/^\d+(?:\.\d+)?$/.test(rule.factor)||!/[1-9]/.test(rule.factor)||typeof rule.version!=='string'))throw Error('DENIED');
   return {projectId:sample.project,sampleId:sample.id,readingId:reading.id,version:reading.version,state:reading.state,metric:reading.metric,
    amount:reading.amount,unit:reading.unit,conversionFactor:rule?.factor??null,targetUnit:args.targetUnit,conversionVersion:rule?.version??null};
  });
 });
 if(groups.some(v=>v.length>32))throw Error('RESULT_TOO_LARGE_OR_INVALID');
 const subject={...cfg.namespace,tenantId:cfg.tenant,subjectId:user};
 const queryDigest=fingerprint({projectId:args.projectId,metric:args.metric,targetUnit:args.targetUnit});
 const snapshot=fingerprint({subject,queryDigest,groups},'laboratory-snapshot');
 const binding={subject,queryDigest,snapshot};const start=offset(cfg,args.cursor,binding,samples.length);
 const records=groups.slice(start,start+2).flat(),next=start+2<samples.length?cursor(cfg,{...binding,offset:start+2}):null;
 if(records.length>32)throw Error('RESULT_TOO_LARGE_OR_INVALID');
 return {subject,queryDigest,snapshot,records,next,start,total:groups.reduce((n,v)=>n+v.length,0)};
}
export function laboratoryPage(cfg,state,root,user,value,retained=null){
 const args=laboratoryArguments(value),m=material(cfg,state,root,user,args);
 const refs=m.records.map(v=>({subject:m.subject,providerId:cfg.mcpRef,resourceType:'laboratory-reading',contractVersion:1,
  externalId:v.readingId,observedVersion:String(v.version)}));
 const records=m.records.map(v=>fields.map(name=>({name,value:v[name]})));
 const evidence={id:retained?.id??crypto.randomUUID(),subject:m.subject,providerRef:cfg.mcpRef,resourceRefs:refs,
  observedAt:retained?.observedAt??new Date().toISOString(),classification:'host-authorized',quality:'synthetic',completeness:'1.00',
  publicFields:fields,formatterRef:'laboratory-table',formatterVersion:1};
 const coreDigest=fingerprint({evidence,records},'evidence');
 const scope='laboratory-project/'+fingerprint({subject:m.subject,projectId:args.projectId});
 const result={schema:'agent-query-page/1',page:{evidence:{...evidence,coreDigest},records,nextCursor:m.next},
  coverage:{queryRef:'laboratory-query/'+m.queryDigest,snapshotRef:'laboratory-snapshot/'+m.snapshot,requestedScopeRef:scope,coveredScopeRef:scope,
   observedRows:records.length,expectedRows:m.total,nextCursorRef:m.next===null?null:'cursor/'+fingerprint(m.next),
   status:m.next===null?'complete':'partial',explanationRef:null},queryDigest:m.queryDigest,requestCursor:args.cursor,
  pageOrdinal:m.start/2,grain:laboratoryGrain,pageGroupFields:laboratoryGroups};
 if(!laboratoryOutput.safeParse(result).success)throw Error('RESULT_TOO_LARGE_OR_INVALID');
 return result;
}
export function laboratoryProjectsPage(cfg,state,root,user,value,retained=null){
 const args=laboratoryProjectsArguments(value),authorized=ownedProjects(cfg,state,user);
 const data=JSON.parse(fs.readFileSync(path.join(root,'laboratory.json')));
 if(!Array.isArray(data.projects)||new Set(data.projects.map(p=>p.id)).size!==data.projects.length)throw Error('INVALID');
 const selected=authorized.slice().sort().map(id=>{
  const project=data.projects.find(p=>p.id===id);
  if(!project||typeof project.name!=='string'||project.name.length<1||project.name.length>256)throw Error('INVALID');
  return {projectId:id,name:project.name};
 });
 const subject={...cfg.namespace,tenantId:cfg.tenant,subjectId:user},queryDigest=fingerprint({});
 const snapshot=fingerprint({subject,queryDigest,projects:selected},'laboratory-projects-snapshot');
 const binding={subject,queryDigest,snapshot},start=offset(cfg,args.cursor,binding,selected.length),chosen=selected.slice(start,start+2);
 const next=start+2<selected.length?cursor(cfg,{...binding,offset:start+2}):null;
 const records=chosen.map(p=>[{name:'projectId',value:p.projectId},{name:'name',value:p.name}]);
 const evidence={id:retained?.id??crypto.randomUUID(),subject,providerRef:cfg.mcpRef,
  resourceRefs:chosen.map(p=>({subject,providerId:cfg.mcpRef,resourceType:'laboratory-project',contractVersion:1,
   externalId:p.projectId,observedVersion:fingerprint(p)})),observedAt:retained?.observedAt??new Date().toISOString(),
  classification:'host-authorized',quality:'synthetic',completeness:'1.00',publicFields:['projectId','name'],
  formatterRef:'laboratory-projects-table',formatterVersion:1};
 const scope='laboratory-projects/'+fingerprint({subject});
 const result={schema:'agent-query-page/1',page:{evidence:{...evidence,coreDigest:fingerprint({evidence,records},'evidence')},records,nextCursor:next},
  coverage:{queryRef:'laboratory-projects/'+queryDigest,snapshotRef:'laboratory-projects-snapshot/'+snapshot,requestedScopeRef:scope,coveredScopeRef:scope,
   observedRows:records.length,expectedRows:selected.length,nextCursorRef:next===null?null:'cursor/'+fingerprint(next),
   status:next===null?'complete':'partial',explanationRef:null},queryDigest,requestCursor:args.cursor,pageOrdinal:start/2,
  grain:['projectId'],pageGroupFields:['projectId']};
 if(!laboratoryProjectsOutput.safeParse(result).success)throw Error('RESULT_TOO_LARGE_OR_INVALID');
 return result;
}
export function laboratoryReadResponse(v,hashed,args,cfg,state,root,issue,observationUntil=null,projects=false){
 const c=v.binding.context,user=c.subject.subjectId,tool=projects?laboratoryProjectsTool:laboratoryTool;
 const page=projects?laboratoryProjectsPage:laboratoryPage;
 let {scope,allowed}=readAuthorization(v,hashed,cfg,state,root,tool,observationUntil);
 if(allowed){
  if(v.phase==='disclose'){
   const candidate=parseCanonical(v.candidateJson),e=candidate?.page?.evidence;
   const time=Date.parse(e?.observedAt);
   if(typeof e?.id!=='string'||!/^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(e.id)||!(Date.parse(c.admittedAt)<=time&&time<=Date.now()))throw Error('INVALID');
   const current=page(cfg,state,root,user,args,e),x=Buffer.from(canonical(current)),y=Buffer.from(canonical(candidate));
   allowed=x.length===y.length&&crypto.timingSafeEqual(x,y);
  }else if(v.phase==='query-navigation'){if(projects)ownedProjects(cfg,state,user);else owned(cfg,state,user,args)}
  else page(cfg,state,root,user,args);
 }
 return {requestDigest:hashed,subject:c.subject,taskId:c.taskId,rootId:c.rootId,policyGeneration:scope.policyGeneration,scopeRef:scope.scopeRef,
  allowed:Boolean(allowed),validUntil:scope.validUntil,credential:allowed&&v.phase==='dispatch'?issue(user,tool,args,scope.validUntil):null};
}
