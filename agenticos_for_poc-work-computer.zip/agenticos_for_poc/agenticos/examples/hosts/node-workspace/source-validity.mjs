// Standalone current-source observer. Read-only metadata; no login or grants.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {canonical,parseCanonical} from './source-wire.mjs';
const REF=/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$/;
const keys=(value,wanted)=>value&&typeof value==='object'&&!Array.isArray(value)
 &&Object.keys(value).sort().join()===wanted.sort().join();
export function sourceRequest(raw,cfg,exact){
 const b=parseCanonical(raw);
 if(!keys(b,['subject','purpose','resourceRefs','fieldNames'])||b.purpose!=='OSPersonalSourceValidity/1'||!exact(b.subject))throw Error('INVALID');
 if(!Array.isArray(b.fieldNames)||b.fieldNames.length<1||b.fieldNames.length>32
  ||b.fieldNames.some(v=>typeof v!=='string'||!REF.test(v))||new Set(b.fieldNames).size!==b.fieldNames.length
  ||!Array.isArray(b.resourceRefs)||b.resourceRefs.length<1||b.resourceRefs.length>32)throw Error('INVALID');
 for(const r of b.resourceRefs){
  if(!keys(r,['subject','providerId','resourceType','contractVersion','externalId','observedVersion'])
   ||canonical(r.subject)!==canonical(b.subject)||!Number.isSafeInteger(r.contractVersion)||r.contractVersion<1
   ||['providerId','resourceType'].some(k=>typeof r[k]!=='string'||!REF.test(r[k]))
   ||['externalId','observedVersion'].some(k=>typeof r[k]!=='string'||[...r[k]].length<1||[...r[k]].length>256))throw Error('INVALID');
 }
 if(new Set(b.resourceRefs.map(v=>canonical(v))).size!==b.resourceRefs.length)throw Error('INVALID');
 return [b,crypto.createHash('sha256').update('agentic-os.hash/1\0verification\0'+canonical(b)).digest('hex')];
}
export function permitted(b,cfg,state,root){
 const user=b.subject.subjectId,c=state.users[user];
 if(!c.active||!(c.assistant??true)||!c.read||b.fieldNames.some(v=>!['headline','text'].includes(v)))return false;
 const rows=JSON.parse(fs.readFileSync(path.join(root,'documents.json')));
 return b.resourceRefs.every(r=>r.providerId===cfg.mcpRef&&r.resourceType==='document'&&r.contractVersion===1
  &&cfg.users[user].resources.includes(r.externalId)
  &&rows.some(v=>v.key===r.externalId&&v.owner===user&&String(v.revision)===r.observedVersion));
}
