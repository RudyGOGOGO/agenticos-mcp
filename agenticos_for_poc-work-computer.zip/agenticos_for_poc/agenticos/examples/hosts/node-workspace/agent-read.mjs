// Independent Host-owned exact read authorization. No OS or kernel imports.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import {canonical,parseCanonical} from './source-wire.mjs';
import {scopeRequest,scopeResponse} from './agent-scope.mjs';
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
function keys(v,n){if(!object(v)||Object.keys(v).sort().join()!==n.split(',').sort().join())throw Error('INVALID')}
const uuid=v=>typeof v==='string'&&/^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(v);
function ident(v){if(!uuid(v))throw Error('INVALID')}
function number(v,min=0){if(!Number.isSafeInteger(v)||v<min)throw Error('INVALID')}
function reference(v){if(typeof v!=='string'||!/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$/.test(v))throw Error('INVALID')}
export const fingerprint=(v,domain='command')=>crypto.createHash('sha256').update('agentic-os.hash/1\0'+domain+'\0'+canonical(v)).digest('hex');
function parse(raw){if(Buffer.byteLength(raw)>65536)throw Error('INVALID');const value=parseCanonical(raw);canonical(value);return value}
function uuid5(namespace,name){
 const digest=crypto.createHash('sha1').update(Buffer.from(namespace.replaceAll('-',''),'hex')).update(name).digest();
 digest[6]=(digest[6]&15)|80;digest[8]=(digest[8]&63)|128;
 const hex=digest.subarray(0,16).toString('hex');return hex.slice(0,8)+'-'+hex.slice(8,12)+'-'+hex.slice(12,16)+'-'+hex.slice(16,20)+'-'+hex.slice(20);
}
function instant(v){if(typeof v!=='string'||v.length>40||!/(Z|[+-][0-9]{2}:[0-9]{2})$/.test(v))throw Error('INVALID');const n=Date.parse(v);if(!Number.isFinite(n))throw Error('INVALID');return n}
export function readRequest(raw,cfg,exact,observationUntil=null,argumentReader=null){
 const v=parse(raw);keys(v,'binding,profile,providerRef,phase,candidateJson');const b=v.binding;
 keys(b,'context,identity,modelOperationId,modelResult,capability,toolName,callId,callIndex,argumentsJson');
 scopeRequest(Buffer.from(canonical({context:b.context,capabilities:[b.capability,v.profile]})),cfg,exact,observationUntil);
 const c=b.context,i=b.identity;keys(i,'operationId,taskId,rootId,segmentId,intentRevision,controlEpoch,planRevision,parentOperationId,iteration,kind,inputDigest');
 for(const k of ['taskId','rootId','segmentId','intentRevision','controlEpoch'])if(i[k]!==c[k])throw Error('INVALID');
 ident(i.operationId);ident(b.modelOperationId);
 if(i.kind!=='tool'||i.parentOperationId!==b.modelOperationId)throw Error('INVALID');
 number(i.iteration);number(i.planRevision,1);number(b.callIndex);
 if(typeof b.callId!=='string'||b.callId.length<1||b.callId.length>512||i.operationId!==uuid5(b.modelOperationId,'sdk-tool/'+b.callId))throw Error('INVALID');
 const r=b.modelResult;keys(r,'subject,taskId,rootId,resultId,producerStepId,acceptedAttemptId,payload,lineageRef,scopeRef,acceptedAt');
 for(const k of ['subject','taskId','rootId'])if(canonical(r[k])!==canonical(c[k]))throw Error('INVALID');
 for(const k of ['resultId','producerStepId','acceptedAttemptId'])ident(r[k]);
 if(r.lineageRef!==null)reference(r.lineageRef);reference(r.scopeRef);
 if(!(instant(c.admittedAt)<=instant(r.acceptedAt)&&instant(r.acceptedAt)<=Date.now()))throw Error('INVALID');
 const p=r.payload;keys(p,'artifactRef,ciphertextDigest,bytes,schemaRef,schemaVersion');reference(p.artifactRef);number(p.bytes);number(p.schemaVersion,1);
 if(p.schemaRef!=='AgentProviderResponse'||p.schemaVersion!==1||typeof p.ciphertextDigest!=='string'||!/^[a-f0-9]{64}$/.test(p.ciphertextDigest))throw Error('INVALID');
 const binding=Object.fromEntries(['modelResult','capability','callId','callIndex','toolName','argumentsJson'].map(k=>[k,b[k]]));
 if(i.inputDigest!==fingerprint(binding)||b.toolName!=='cap_'+crypto.createHash('sha256').update(canonical(b.capability)).digest('hex').slice(0,40))throw Error('INVALID');
 if(!['dispatch','disclose','query-navigation'].includes(v.phase)||(v.phase!=='disclose')!==(v.candidateJson===null))throw Error('INVALID');
 if(v.phase==='query-navigation'&&argumentReader===null)throw Error('DENIED');
 if(v.candidateJson!==null&&(typeof v.candidateJson!=='string'||Buffer.byteLength(v.candidateJson)<2||Buffer.byteLength(v.candidateJson)>65536))throw Error('INVALID');
 if(v.providerRef!==cfg.mcpRef||b.capability.ref!==cfg.descriptor.id)throw Error('DENIED');
 if(typeof b.argumentsJson!=='string')throw Error('INVALID');
 const args=parse(b.argumentsJson);if(argumentReader!==null)return [v,fingerprint(v),argumentReader(args)];
 keys(args,'resourceType,externalIds,fieldNames');if(args.resourceType!=='document')throw Error('DENIED');
 for(const k of ['externalIds','fieldNames'])if(!Array.isArray(args[k])||args[k].length>32||new Set(args[k]).size!==args[k].length||args[k].some(v=>typeof v!=='string'||v.length<1||v.length>256))throw Error('INVALID');
 return [v,fingerprint(v),args];
}
function rows(cfg,root,user,args){
 const ids=args.externalIds.length?args.externalIds:cfg.users[user].resources,fields=args.fieldNames.length?args.fieldNames:['headline','text'];
 if(ids.length>32||ids.some(v=>!cfg.users[user].resources.includes(v))||fields.some(v=>!['headline','text'].includes(v)))throw Error('DENIED');
 const all=JSON.parse(fs.readFileSync(path.join(root,'documents.json'))),found=ids.map(v=>all.find(d=>d.key===v&&d.owner===user)).filter(Boolean);
 const subject={...cfg.namespace,tenantId:cfg.tenant,subjectId:user};
 return [fields,found.map(v=>fields.map(name=>({name,value:v[name]}))),found.map(v=>({subject,providerId:cfg.mcpRef,resourceType:'document',contractVersion:1,externalId:v.key,observedVersion:String(v.revision)}))];
}
export function readAuthorization(v,hashed,cfg,state,root,tool,observationUntil=null){
 if(observationUntil!==null&&!['disclose','query-navigation'].includes(v.phase))throw Error('DENIED');
 const b=v.binding,c=b.context,user=c.subject.subjectId;
 const scope=scopeResponse({context:c,capabilities:[b.capability]},hashed,cfg,state,root,observationUntil),file=path.join(root,'agent-capabilities.json');
 const reviews=fs.existsSync(file)?JSON.parse(fs.readFileSync(file)):[];
 const allowed=scope.capabilities.length>0&&reviews.some(r=>canonical(r.pin)===canonical(b.capability)&&r.purpose===c.purpose&&r.kind==='read'&&r.subjects.includes(user)&&r.read&&canonical(r.read)===canonical({profile:v.profile,toolName:tool}));
 return {scope,allowed};
}
export function readResponse(v,hashed,args,cfg,state,root,issue,observationUntil=null){
 const b=v.binding,c=b.context,user=c.subject.subjectId,tool='agent_documents_read';
 let {scope,allowed}=readAuthorization(v,hashed,cfg,state,root,tool,observationUntil);
 if(allowed){
  const [fields,records,refs]=rows(cfg,root,user,args);
  if(v.phase==='disclose'){
   if(typeof v.candidateJson!=='string')throw Error('INVALID');const candidate=parse(v.candidateJson);keys(candidate,'evidence,records,nextCursor');const e=candidate.evidence;
   keys(e,'id,subject,providerRef,resourceRefs,observedAt,classification,quality,completeness,publicFields,formatterRef,formatterVersion,coreDigest');ident(e.id);
   if(!(instant(c.admittedAt)<=instant(e.observedAt)&&instant(e.observedAt)<=Date.now()))throw Error('INVALID');
   const core={evidence:Object.fromEntries(Object.entries(e).filter(([k])=>k!=='coreDigest')),records:candidate.records};
   allowed=canonical(e.subject)===canonical(c.subject)&&e.providerRef===cfg.mcpRef&&canonical(e.resourceRefs)===canonical(refs)&&canonical(candidate.records)===canonical(records);
   allowed=allowed&&canonical(e.publicFields)===canonical(fields)&&e.classification==='host-authorized'&&e.quality==='synthetic'&&e.completeness==='1.00';
   allowed=allowed&&e.formatterRef==='workspace-table'&&e.formatterVersion===1&&e.coreDigest===fingerprint(core,'evidence')&&candidate.nextCursor===null;
  }
 }
 const credential=allowed&&v.phase==='dispatch'?issue(user,tool,args,scope.validUntil):null;
 return {requestDigest:hashed,subject:c.subject,taskId:c.taskId,rootId:c.rootId,policyGeneration:scope.policyGeneration,scopeRef:scope.scopeRef,allowed:Boolean(allowed),validUntil:scope.validUntil,credential};
}
export const readMatches=(grant,tool,args)=>!grant.readBinding||canonical(grant.readBinding)===canonical({toolName:tool,arguments:fingerprint(args)});

export function observationRequest(raw,cfg,exact,argumentReader=null){
 const v=parse(raw);keys(v,'schema,read,policyGeneration,validUntil');
 if(v.schema!=='agent-read-observation/1'||!['disclose','query-navigation'].includes(v.read?.phase))throw Error('INVALID');
 number(v.policyGeneration,1);const until=instant(v.validUntil),now=Date.now();
 if(!(now<until&&until<=now+30000))throw Error('INVALID');
 const [read,,args]=readRequest(Buffer.from(canonical(v.read)),cfg,exact,until,argumentReader);
 return [v,read,args,until,fingerprint(v)];
}
export function observationResponse(v,read,args,until,hashed,cfg,state,root){
 if(state.users[read.binding.context.subject.subjectId].policyGeneration!==v.policyGeneration)throw Error('DENIED');
 return readResponse(read,hashed,args,cfg,state,root,()=>{throw Error('DENIED')},until);
}
