// Independent Host-owned read-scope DTO. No OS imports, SDK or tool grants.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {canonical,parseCanonical} from './source-wire.mjs';
const contextKeys='subject,taskId,conversationId,segmentId,purpose,definition,profile,harness,model,resourcePolicy,authorityRef,scopeRef,delegationRef,rootId,accountingFormat,intentRevision,controlEpoch,admittedAt,authorizationHorizon,timeZone'.split(',').sort().join();
const ref=v=>typeof v==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$/.test(v);
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const keys=(v,k)=>object(v)&&Object.keys(v).sort().join()===k;
const positive=v=>Number.isSafeInteger(v)&&v>0;
function pin(p){
 if(!keys(p,'digest,ref,revision')||!ref(p.ref)||!positive(p.revision)||typeof p.digest!=='string'||!/^[a-f0-9]{64}$/.test(p.digest))throw Error('INVALID');
}
export function scopeRequest(raw,cfg,exact,observationUntil=null){
 if(raw.length>65536)throw Error('INVALID');
 const value=parseCanonical(raw),serialized=canonical(value);
 if(!keys(value,'capabilities,context'))throw Error('INVALID');
 const c=value.context;
 if(!keys(c,contextKeys)||!exact(c.subject)||c.accountingFormat!=='agent-resources/1'||c.delegationRef!==null)throw Error('INVALID');
 for(const key of ['taskId','conversationId','segmentId','rootId'])if(typeof c[key]!=='string'||!/^[a-f0-9]{8}(-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(c[key]))throw Error('INVALID');
 for(const key of ['intentRevision','controlEpoch'])if(!positive(c[key]))throw Error('INVALID');
 for(const key of ['purpose','authorityRef','scopeRef'])if(!ref(c[key]))throw Error('INVALID');
 if(typeof c.timeZone!=='string'||c.timeZone.length<1||c.timeZone.length>128)throw Error('INVALID');
 for(const key of ['definition','profile','harness','model','resourcePolicy'])pin(c[key]);
 for(const key of ['admittedAt','authorizationHorizon'])if(typeof c[key]!=='string'||c[key].length>40||!/(Z|[+-][0-9]{2}:[0-9]{2})$/.test(c[key]))throw Error('INVALID');
 const admitted=Date.parse(c.admittedAt),horizon=Date.parse(c.authorizationHorizon),now=Date.now();
 if(!(admitted<=now&&admitted<horizon&&horizon<=admitted+7*86400000))throw Error('INVALID');
 if(observationUntil===null?!(now<horizon):!(now<observationUntil&&observationUntil<=now+30000))throw Error('INVALID');
 if(!Array.isArray(value.capabilities)||value.capabilities.length>128)throw Error('INVALID');
 for(const p of value.capabilities)pin(p);
 if(new Set(value.capabilities.map(v=>v.ref)).size!==value.capabilities.length)throw Error('INVALID');
 return [value,crypto.createHash('sha256').update('agentic-os.hash/1\0command\0'+serialized).digest('hex')];
}
export function scopeObservationRequest(raw,cfg,exact){
 if(raw.length>65536)throw Error('INVALID');
 const v=parseCanonical(raw);
 if(!keys(v,'schema,scope,validUntil')||v.schema!=='agent-capability-observation/1'
  ||typeof v.validUntil!=='string'||v.validUntil.length>40||!/(Z|[+-][0-9]{2}:[0-9]{2})$/.test(v.validUntil))throw Error('INVALID');
 const until=Date.parse(v.validUntil),[value,hashed]=scopeRequest(Buffer.from(canonical(v.scope)),cfg,exact,until);
 return [value,hashed,until];
}
export function scopeResponse(value,hashed,cfg,state,root,observationUntil=null){
 const c=value.context,s=c.subject,control=state.users[s.subjectId];
 if(!control.active||!(control.assistant??true))throw Error('DENIED');
 const file=path.join(root,'agent-capabilities.json'),allowed=fs.existsSync(file)?JSON.parse(fs.readFileSync(file)):[];
 const capabilities=value.capabilities.filter(p=>control.read&&allowed.some(item=>canonical(item.pin)===canonical(p)&&item.purpose===c.purpose&&['read','propose','native'].includes(item.kind)&&item.subjects.includes(s.subjectId)));
 const binding=canonical({requestDigest:hashed,policyGeneration:control.policyGeneration});
 const scopeRef='scope/'+crypto.createHmac('sha256',cfg.bridgeKey).update(binding).digest('hex');
 return {subject:s,taskId:c.taskId,rootId:c.rootId,requestDigest:hashed,purpose:c.purpose,intentRevision:c.intentRevision,
  controlEpoch:c.controlEpoch,policyGeneration:control.policyGeneration,scopeRef,capabilities,
  validUntil:new Date(Math.min(Date.now()+30000,observationUntil??Date.parse(c.authorizationHorizon))).toISOString()};
}
