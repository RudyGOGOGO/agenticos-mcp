# Owned Node laboratory fixture

This synthetic Host retains its own documents, laboratory data and authorization.
The optional `laboratory-query/1` profile offers governed measurement pages. With
`projectDiscoveryEnabled: true` and a distinct reviewed `projectDescriptor`, it
also offers `agent_laboratory_projects`. The current owner's `labProjects` scope
selects project IDs and names from `laboratory.json`; no caller supplies an ID to
discovery. A signed cursor binds the owner and current project snapshot.

Metadata credentials can inspect tools but cannot execute them. Each project or
measurement read needs its exact capability, read profile, accepted arguments and
current scoped grant. Disclosure and history observation recheck the same data
and authority. The default document and measurement profiles remain available.

The frozen laboratory acceptance journey obtains its project ID from accepted
discovery, traverses all measurement pages, and uses the shared exact operator to
select latest accepted revisions before versioned unit conversion. Mean, maximum,
available population and missing samples retain their sources. Local synthetic
acceptance and actual-provider qualification are separate; the synthetic planner
is a fixture, not a production intent classifier.
