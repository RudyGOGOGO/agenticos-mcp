// Host-owned bounded wire profile. These are message/page bounds, not task caps.
import {z} from 'zod';
const text=z.string().max(256),identifier=z.string().max(36),instant=z.string().max(40),positive=z.number().int().min(1).max(Number.MAX_SAFE_INTEGER);
const subject=z.object({installationId:identifier,applicationId:identifier,tenantId:text,subjectId:text}).strict();
const resource=z.object({subject,providerId:text,resourceType:text,contractVersion:positive,externalId:text,observedVersion:text}).strict();
const evidence=z.object({id:identifier,subject,providerRef:text,resourceRefs:z.array(resource).max(32),observedAt:instant,
 classification:text,quality:text,completeness:z.string().max(32),publicFields:z.array(text).max(32),formatterRef:text,formatterVersion:positive,coreDigest:z.string().max(64)}).strict();
const cell=z.object({name:text,value:z.string().max(65536).nullable()}).strict();
export const agentInput=z.object({resourceType:z.string().max(32),externalIds:z.array(text).max(32),fieldNames:z.array(text).max(32)}).strict();
export const agentOutput=z.object({evidence,records:z.array(z.array(cell).max(32)).max(32),nextCursor:z.null()}).strict();

export const agentInputJSON=z.toJSONSchema(agentInput,{target:'draft-2020-12',io:'input'});
export const agentOutputJSON=z.toJSONSchema(agentOutput,{target:'draft-2020-12',io:'output'});
