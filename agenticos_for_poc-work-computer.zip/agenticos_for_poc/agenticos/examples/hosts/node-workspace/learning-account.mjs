// Host-owned closed string/object DTO reader. No OS or financial imports.
// This request has exactly two object levels and no array/numeric values.
export function learningAccountBody(raw) {
 const text=new TextDecoder('utf-8',{fatal:true}).decode(raw);let at=0;
 const space=()=>{while(/[\t\r\n ]/.test(text[at]??'!'))at++};
 function string(){
  space();if(text[at++]!=='"')throw Error('INVALID');const start=at-1;
  while(at<text.length){const c=text[at++];if(c==='\\'){at++;continue}if(c==='"'){
   const value=JSON.parse(text.slice(start,at));
   for(const point of value){const cp=point.codePointAt(0);if(cp>=0xd800&&cp<=0xdfff)throw Error('INVALID')}
   return value;
  }}throw Error('INVALID');
 }
 function object(depth){
  space();if(depth>1||text[at++]!=='{')throw Error('INVALID');const result=Object.create(null);space();
  if(text[at]==='}'){at++;return result}
  while(at<text.length){
   const key=string();if(Object.hasOwn(result,key))throw Error('INVALID');space();
   if(text[at++]!==':')throw Error('INVALID');space();
   result[key]=text[at]==='{'?object(depth+1):string();space();
   const next=text[at++];if(next==='}')return result;if(next!==',')throw Error('INVALID');
  }throw Error('INVALID');
 }
 const value=object(0);space();if(at!==text.length)throw Error('INVALID');return value;
}
