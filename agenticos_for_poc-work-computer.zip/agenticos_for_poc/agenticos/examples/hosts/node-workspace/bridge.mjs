// Owned synthetic document host. Separate wire implementation; no OS imports.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import express from 'express';import {z} from 'zod';
import {McpServer} from '@modelcontextprotocol/sdk/server/mcp.js';
import {Server} from '@modelcontextprotocol/sdk/server/index.js';
import {ListToolsRequestSchema,CallToolRequestSchema} from '@modelcontextprotocol/sdk/types.js';
import {StreamableHTTPServerTransport} from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import {localhostHostValidation} from '@modelcontextprotocol/sdk/server/middleware/hostHeaderValidation.js';
import {learningAccountBody} from './learning-account.mjs';
import {sourceRequest,permitted} from './source-validity.mjs';
import {parseCanonical} from './source-wire.mjs';
import {scopeRequest,scopeResponse,scopeObservationRequest} from './agent-scope.mjs';
import {readRequest,readResponse,readMatches,fingerprint,observationRequest,observationResponse} from './agent-read.mjs';
import {agentInput,agentOutput,agentInputJSON,agentOutputJSON} from './agent-read-schema.mjs';
import {laboratoryArguments,laboratoryReadResponse,laboratoryPage,laboratoryTool,laboratoryInput,laboratoryOutput,laboratoryMetadata,
 laboratoryProjectsArguments,laboratoryProjectsPage,laboratoryProjectsTool,laboratoryProjectsInput,laboratoryProjectsOutput,laboratoryProjectsMetadata} from './laboratory-query.mjs';
const file=process.argv[2],root=path.dirname(file),cfg=JSON.parse(fs.readFileSync(file));
if(cfg.fixture!=='owned-agentic-os-host'||cfg.kind!=='node-workspace')throw Error('Explicit owned fixture required');
const laboratory=cfg.analysisProfile==='laboratory-query/1';
if(cfg.analysisProfile!==undefined&&!laboratory)throw Error('Unsupported analysis profile');
const authorityCfg=laboratory?{...cfg,descriptor:cfg.agentDescriptor}:cfg;
if(laboratory&&!authorityCfg.descriptor)throw Error('Reviewed laboratory descriptor required');
// The explicit composition profile offers both existing governed lanes. Raw
// requests still pass their original closed parser and exact capability pin.
const querySource=laboratory&&cfg.querySourceProfile===true;
if(cfg.projectDiscoveryEnabled!==undefined&&typeof cfg.projectDiscoveryEnabled!=='boolean')throw Error('Explicit project discovery profile required');
const projectDiscovery=laboratory&&cfg.projectDiscoveryEnabled===true;
const projectsCfg=projectDiscovery?{...cfg,descriptor:cfg.projectDescriptor}:null;
if(cfg.projectDiscoveryEnabled===true&&(!projectsCfg?.descriptor||typeof projectsCfg.descriptor.id!=='string'
 ||!/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,255}$/.test(projectsCfg.descriptor.id)||projectsCfg.descriptor.id===authorityCfg.descriptor.id
 ||projectsCfg.descriptor.id===cfg.descriptor.id))throw Error('Distinct reviewed project discovery descriptor required');
const readConfig=(raw,observe=false)=>{
 if(!querySource&&!projectDiscovery)return authorityCfg;
 const request=parseCanonical(raw),ref=(observe?request.read:request).binding.capability.ref;
 if(projectDiscovery&&ref===projectsCfg.descriptor.id)return projectsCfg;
 return querySource&&ref===cfg.descriptor.id?cfg:authorityCfg;
};
const sessions=new Map(),grants=new Map(),controls=()=>JSON.parse(fs.readFileSync(path.join(root,'controls.json')));
const id=()=>crypto.randomUUID(),secret=()=>crypto.randomBytes(32).toString('base64url');
const subject=user=>({...cfg.namespace,tenantId:cfg.tenant,subjectId:user});
const enabled=user=>Object.hasOwn(cfg.users,user)&&controls().users[user].active;
const exact=s=>s&&Object.hasOwn(cfg.users,s.subjectId)&&JSON.stringify(Object.keys(s).sort())===JSON.stringify(Object.keys(subject(s.subjectId)).sort())&&Object.entries(subject(s.subjectId)).every(([k,v])=>s[k]===v);
const equal=(a,b)=>{if(typeof a!=='string'||typeof b!=='string')return false;const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&crypto.timingSafeEqual(x,y)};
const bridge=req=>equal(req.headers.authorization,'Bearer '+cfg.bridgeKey);
const loginSession=req=>{const token=/workspace_login=([^;]+)/.exec(req.headers.cookie??'')?.[1],s=sessions.get(token);return s&&enabled(s.user)&&s.expires>Date.now()?s:null};
const iso=ms=>new Date(Date.now()+ms).toISOString();
// Keep the SDK's loopback Host guard, but place the closed account parser
// before ordinary JSON parsing so duplicate keys cannot be discarded first.
const app=express();app.use(localhostHostValidation());
app.post('/host-bridge/agent/v1/read',express.raw({type:'application/json',limit:'64kb',inflate:false}),(req,res)=>{
 if(!bridge(req))return res.status(401).json({error:'credential'});
 try{
  if((req.headers['content-encoding']??'identity')!=='identity'||!Buffer.isBuffer(req.body))throw Error('INVALID');
  const selected=readConfig(req.body),queryRead=laboratory&&selected===authorityCfg,projectsRead=projectDiscovery&&selected===projectsCfg;
  const [value,hashed,args]=readRequest(req.body,selected,exact,null,projectsRead?laboratoryProjectsArguments:queryRead?laboratoryArguments:null),state=controls();if(state.outage)return res.status(503).json({error:'unavailable'});
  const issue=(user,tool,args,until)=>{
   const c=controls().users[user];if(!c.active||!c.read||!(c.assistant??true)||c.policyGeneration!==state.users[user].policyGeneration)throw Error('DENIED');
   const access=secret();grants.set(access,{user,expires:Date.parse(until),generation:c.policyGeneration,readBinding:{toolName:tool,arguments:fingerprint(args)}});
   return {accessToken:access,audienceRef:cfg.mcpAudience,subject:subject(user),capabilityRef:value.binding.capability.ref,expiresAt:until};
  };
  return res.json(queryRead||projectsRead?laboratoryReadResponse(value,hashed,args,cfg,state,root,issue,null,projectsRead):readResponse(value,hashed,args,cfg,state,root,issue));
 }catch(error){return res.status(error.message==='DENIED'?403:400).json({error:'denied-or-invalid'})}
});
app.post('/host-bridge/agent/v1/observe',express.raw({type:'application/json',limit:'64kb',inflate:false}),(req,res)=>{
 if(!bridge(req))return res.status(401).json({error:'credential'});
 try{
  if((req.headers['content-encoding']??'identity')!=='identity'||!Buffer.isBuffer(req.body))throw Error('INVALID');
  const selected=readConfig(req.body,true),queryRead=laboratory&&selected===authorityCfg,projectsRead=projectDiscovery&&selected===projectsCfg;
  const [v,read,args,until,hashed]=observationRequest(req.body,selected,exact,projectsRead?laboratoryProjectsArguments:queryRead?laboratoryArguments:null),state=controls();
  if(state.outage)return res.status(503).json({error:'unavailable'});
  if(queryRead||projectsRead){
   if(state.users[read.binding.context.subject.subjectId].policyGeneration!==v.policyGeneration)throw Error('DENIED');
   return res.json(laboratoryReadResponse(read,hashed,args,cfg,state,root,()=>{throw Error('DENIED')},until,projectsRead));
  }
  return res.json(observationResponse(v,read,args,until,hashed,cfg,state,root));
 }catch(error){return res.status(error.message==='DENIED'?403:400).json({error:'denied-or-invalid'})}
});
app.post('/host-bridge/agent/v1/scope',express.raw({type:'application/json',limit:'64kb',inflate:false}),(req,res)=>{
 if(!bridge(req))return res.status(401).json({error:'credential'});
 try{
  if((req.headers['content-encoding']??'identity')!=='identity'||!Buffer.isBuffer(req.body))throw Error('INVALID');
  const [value,hashed]=scopeRequest(req.body,cfg,exact),state=controls();
  if(state.outage)return res.status(503).json({error:'unavailable'});
  return res.json(scopeResponse(value,hashed,cfg,state,root));
 }catch(error){return res.status(error.message==='DENIED'?403:400).json({error:'denied-or-invalid'})}
});
app.post('/host-bridge/agent/v1/scope-observe',express.raw({type:'application/json',limit:'64kb',inflate:false}),(req,res)=>{
 if(!bridge(req))return res.status(401).json({error:'credential'});
 try{
  if((req.headers['content-encoding']??'identity')!=='identity'||!Buffer.isBuffer(req.body))throw Error('INVALID');
  const [value,hashed,until]=scopeObservationRequest(req.body,cfg,exact),state=controls();
  if(state.outage)return res.status(503).json({error:'unavailable'});
  return res.json(scopeResponse(value,hashed,cfg,state,root,until));
 }catch(error){return res.status(error.message==='DENIED'?403:400).json({error:'denied-or-invalid'})}
});
app.post('/host-bridge/v1/learning/accounts/check',express.raw({type:'application/json',limit:'4kb',inflate:false}),(req,res)=>{
 if(!bridge(req))return res.status(401).json({error:'credential'});
 let b;try{
  if((req.headers['content-encoding']??'identity')!=='identity'||!Buffer.isBuffer(req.body))throw Error('INVALID');
  b=learningAccountBody(req.body);
  if(Object.keys(b).sort().join()!=='purpose,subject'||b.purpose!=='OSPersonalLearning/1'||!exact(b.subject))throw Error('INVALID');
 }catch{return res.status(400).json({error:'invalid'})}
 const state=controls();if(state.outage)return res.status(503).json({error:'unavailable'});
 const c=state.users[b.subject.subjectId],checked=Date.now();
 return res.json({subject:b.subject,purpose:'OSPersonalLearning/1',active:Boolean(c.active&&(c.assistant??true)),
  policyGeneration:c.policyGeneration,checkedAt:new Date(checked).toISOString(),validUntil:new Date(checked+15000).toISOString()});
});
app.post('/host-bridge/v1/learning/sources/check',express.raw({type:'application/json',limit:'64kb',inflate:false}),(req,res)=>{
 if(!bridge(req))return res.status(401).json({error:'credential'});
 let b,hashed;try{
  if((req.headers['content-encoding']??'identity')!=='identity'||!Buffer.isBuffer(req.body))throw Error('INVALID');
  [b,hashed]=sourceRequest(req.body,cfg,exact);
 }catch{return res.status(400).json({error:'invalid'})}
 const state=controls();if(state.outage)return res.status(503).json({error:'unavailable'});
 const checked=Date.now();
 return res.json({subject:b.subject,purpose:'OSPersonalSourceValidity/1',active:permitted(b,cfg,state,root),
  policyGeneration:state.users[b.subject.subjectId].policyGeneration,requestDigest:hashed,
  checkedAt:new Date(checked).toISOString(),validUntil:new Date(checked+3000).toISOString()});
});
app.use(express.json({limit:'64kb'}));
app.post('/auth/login',(req,res)=>{
 const user=req.body.userRef;if(req.headers.origin!==cfg.origin||Object.keys(req.body).join()!=='userRef'||!enabled(user))return res.status(401).json({error:'login'});
 const cookie=secret(),s={user,ref:id(),generation:controls().users[user].sessionGeneration,csrf:secret(),expires:Date.now()+3600000};sessions.set(cookie,s);
 res.cookie('workspace_login',cookie,{httpOnly:true,sameSite:'strict'}).json({csrf:s.csrf,hostSessionRef:s.ref,sessionGeneration:s.generation});
});
app.get('/me',(req,res)=>{const s=loginSession(req);return s?res.json({userRef:s.user,csrf:s.csrf}):res.status(401).json({error:'login'})});
app.post('/integrations/agentic-os/bootstrap',async(req,res)=>{
 const s=loginSession(req);if(!s||req.headers.origin!==cfg.origin||!equal(req.headers['x-csrf-token'],s.csrf))return res.status(403).json({error:'csrf'});
 const keys=['challengeId','embedRef','expiresAt','frameNonce','proofKeyThumbprint'];if(JSON.stringify(Object.keys(req.body).sort())!==JSON.stringify(keys)||req.body.embedRef!==cfg.embedRef)return res.status(400).json({error:'binding'});
 const body={binding:{subject:subject(s.user),...req.body,sessionGeneration:s.generation,audience:'agentic-os.browser',replayId:id()},hostSessionRef:s.ref};
 try{const r=await fetch(cfg.osOrigin+'/os/embed/bootstrap',{method:'POST',redirect:'error',signal:AbortSignal.timeout(8000),headers:{'Authorization':'Bearer '+cfg.bridgeKey,'Content-Type':'application/json'},body:JSON.stringify(body)});res.status(r.status).json(await r.json())}
 catch{res.status(503).json({error:'unavailable'})}
});
app.post('/host-bridge/v1/:section/:operation',(req,res)=>handle(req,res));
app.post('/host-bridge/v1/capabilities',(req,res)=>handle(req,res));
function handle(req,res){
 if(!bridge(req))return res.status(401).json({error:'credential'});
 const b=req.body,s=b.subject,user=s?.subjectId;if(!exact(s))return res.status(403).json({error:'scope'});
 const c=controls().users[user];if(controls().outage)return res.status(503).json({error:'unavailable'});
 if(req.path.endsWith('/sessions/check')){
  const found=[...sessions.values()].find(v=>v.ref===b.hostSessionRef&&v.user===user);
  return res.json({subject:s,active:Boolean(found&&enabled(user)&&found.expires>Date.now()&&found.generation===c.sessionGeneration&&b.sessionGeneration===c.sessionGeneration),sessionGeneration:c.sessionGeneration,policyGeneration:c.policyGeneration,checkedAt:iso(0),validUntil:iso(15000)});
 }
 if(!enabled(user))return res.status(403).json({error:'removed'});
 if(req.path.endsWith('/capabilities'))return res.json({capabilities:c.read?[cfg.descriptor]:[]});
 if(req.path.endsWith('/authority/check')){
  if(!c.read||b.capabilityRef!==cfg.descriptor.id||b.delegationRef!==null)return res.status(403).json({error:'denied'});
  return res.json({id:id(),subject:s,active:true,policyGeneration:c.policyGeneration,capabilityRefs:[cfg.descriptor.id],resourceBounds:[{resourceType:'document',externalIds:cfg.users[user].resources,fieldNames:['headline','text']}],purpose:b.purpose,checkedAt:iso(0),validUntil:iso(15000),assuranceRef:'local-synthetic',delegationRef:null});
 }
 if(req.path.endsWith('/credentials/issue')){
  const metadataCapabilities=[cfg.descriptor.id,...(projectDiscovery?[projectsCfg.descriptor.id]:[])];
  if(!c.read||b.endpointRef!==cfg.mcpRef||!metadataCapabilities.includes(b.capabilityRef))return res.status(403).json({error:'denied'});
  const access=secret();grants.set(access,{user,expires:Date.now()+30000,generation:c.policyGeneration});
  return res.json({accessToken:access,audienceRef:cfg.mcpAudience,subject:s,capabilityRef:b.capabilityRef,expiresAt:iso(30000)});
 }
 return res.status(404).json({error:'unsupported'});
}
function grant(req){const g=grants.get((req.headers.authorization??'').replace(/^Bearer /,''));if(!g||!enabled(g.user)||g.expires<=Date.now())return null;const c=controls().users[g.user];return c.read&&c.policyGeneration===g.generation&&(!g.readBinding||(c.assistant??true))?g.user:null}
async function readDocuments(req,a,tool){
 const user=grant(req);if(!user)return {isError:true,content:[{type:'text',text:'DENIED'}]};
  const granted=grants.get((req.headers.authorization??'').replace(/^Bearer /,''));
  if(!grant(req)||(tool.startsWith('agent_')&&!granted.readBinding)||!readMatches(granted,tool,a)||a.resourceType!=='document'||a.externalIds.some(v=>!cfg.users[user].resources.includes(v))||a.fieldNames.some(v=>!['headline','text'].includes(v)))return {isError:true,content:[{type:'text',text:'DENIED'}]};
  const ids=a.externalIds.length?a.externalIds:cfg.users[user].resources,all=JSON.parse(fs.readFileSync(path.join(root,'documents.json'))),rows=ids.map(v=>all.find(d=>d.key===v&&d.owner===user)).filter(Boolean);
  const refs=rows.map(v=>({subject:subject(user),providerId:cfg.mcpRef,resourceType:'document',contractVersion:1,externalId:v.key,observedVersion:String(v.revision)}));
  const fields=a.fieldNames.length?a.fieldNames:['headline','text'],records=rows.map(v=>fields.map(name=>({name,value:v[name]})));
  const evidence={id:id(),subject:subject(user),providerRef:cfg.mcpRef,resourceRefs:refs,observedAt:iso(0),classification:'host-authorized',quality:'synthetic',completeness:'1.00',publicFields:fields,formatterRef:'workspace-table',formatterVersion:1,coreDigest:'0'.repeat(64)};
  const canonical=v=>v===null||typeof v!=='object'?JSON.stringify(v):Array.isArray(v)?'['+v.map(canonical).join(',')+']':'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}';
  const core={evidence:Object.fromEntries(Object.entries(evidence).filter(([k])=>k!=='coreDigest')),records};
  evidence.coreDigest=crypto.createHash('sha256').update('agentic-os.hash/1\0evidence\0'+canonical(core)).digest('hex');
  const data={evidence,records,nextCursor:null};return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:data};
 }

app.post('/mcp',async(req,res)=>{
 const user=grant(req);if(!user)return res.status(401).json({error:'denied'});
 const server=new McpServer({name:'owned-node-workspace',version:'1.0.0'});
 server.registerTool('documents_read',{description:'Read current authorized workspace documents',inputSchema:{resourceType:z.string(),externalIds:z.array(z.string()),fieldNames:z.array(z.string())}},a=>readDocuments(req,a,'documents_read'));
 const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined,enableJsonResponse:true});res.on('close',()=>{transport.close();server.close()});await server.connect(transport);await transport.handleRequest(req,res,req.body);
});
// The separate reviewed profile declares2020-12 explicitly through public
// low-level SDK handlers; the legacy MCP server keeps its original metadata.
app.post('/agent-mcp',async(req,res)=>{
 if(!grant(req))return res.status(401).json({error:'denied'});
 const server=new Server({name:'owned-node-agent-read',version:'1.0.0'},{capabilities:{tools:{}}});
 const documentMetadata={name:'agent_documents_read',description:'Read one current authorized document page',inputSchema:agentInputJSON,outputSchema:agentOutputJSON};
 server.setRequestHandler(ListToolsRequestSchema,async()=>({tools:laboratory?
  [laboratoryMetadata,...(projectDiscovery?[laboratoryProjectsMetadata]:[]),...(querySource?[documentMetadata]:[])]:[documentMetadata]}));
 server.setRequestHandler(CallToolRequestSchema,async request=>{
  if(projectDiscovery&&request.params.name===laboratoryProjectsTool){
   const user=grant(req),granted=grants.get((req.headers.authorization??'').replace(/^Bearer /,''));
   const parsed=laboratoryProjectsInput.safeParse(request.params.arguments);
   if(!user||!granted.readBinding||!parsed.success||!readMatches(granted,laboratoryProjectsTool,parsed.data))return {isError:true,content:[{type:'text',text:'DENIED'}]};
   try{
    const data=laboratoryProjectsPage(cfg,controls(),root,user,parsed.data);
    if(!grant(req)||!laboratoryProjectsOutput.safeParse(data).success)throw Error('DENIED');
    return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:data};
   }catch{return {isError:true,content:[{type:'text',text:'DENIED_OR_INVALID'}]}}
  }
  if(laboratory&&(!querySource||request.params.name===laboratoryTool)){
   const user=grant(req),granted=grants.get((req.headers.authorization??'').replace(/^Bearer /,''));
   const parsed=laboratoryInput.safeParse(request.params.arguments);
   if(request.params.name!==laboratoryTool||!user||!granted.readBinding||!parsed.success||!readMatches(granted,laboratoryTool,parsed.data))return {isError:true,content:[{type:'text',text:'DENIED'}]};
   try{
    const data=laboratoryPage(cfg,controls(),root,user,parsed.data);
    if(!grant(req)||!laboratoryOutput.safeParse(data).success)throw Error('DENIED');
    return {content:[{type:'text',text:JSON.stringify(data)}],structuredContent:data};
   }catch{return {isError:true,content:[{type:'text',text:'DENIED_OR_INVALID'}]}}
  }
  if(request.params.name!=='agent_documents_read')return {isError:true,content:[{type:'text',text:'DENIED'}]};
  const parsed=agentInput.safeParse(request.params.arguments);if(!parsed.success)return {isError:true,content:[{type:'text',text:'INVALID'}]};
  const result=await readDocuments(req,parsed.data,'agent_documents_read');
  if(!result.isError&&!agentOutput.safeParse(result.structuredContent).success)return {isError:true,content:[{type:'text',text:'RESULT_TOO_LARGE_OR_INVALID'}]};
  return result;
 });
 const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined,enableJsonResponse:true});res.on('close',()=>{transport.close();server.close()});await server.connect(transport);await transport.handleRequest(req,res,req.body);
});
app.get('/agent-mcp',(_,r)=>r.sendStatus(405));app.delete('/agent-mcp',(_,r)=>r.sendStatus(405));
app.get('/mcp',(_,r)=>r.sendStatus(405));app.delete('/mcp',(_,r)=>r.sendStatus(405));
for(const [route,file,type] of [['/assistant-host','embed-host.html','text/html'],['/assistant-host.js','embed-host.mjs','text/javascript'],['/assistant-host.css','embed-host.css','text/css']]){
 app.get(route,(req,res)=>res.type(type).sendFile(path.resolve(path.dirname(new URL(import.meta.url).pathname),'../shared',file)));
}
app.get('/assistant-host-config',(req,res)=>res.json({kind:cfg.kind,osOrigin:cfg.osOrigin,embedRef:cfg.embedRef,users:Object.keys(cfg.users),reviewPopups:cfg.reviewPopups===true}));
app.listen(cfg.port,'127.0.0.1');
