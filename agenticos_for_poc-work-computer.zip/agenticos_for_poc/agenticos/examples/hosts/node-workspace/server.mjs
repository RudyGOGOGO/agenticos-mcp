// Unrelated read fixture, not a qualified private connector. No OS SDK imports.
import {createServer} from 'node:http';
import {readFileSync} from 'node:fs';
const [file,port]=process.argv.slice(2);
if(!file || !Number.isSafeInteger(Number(port)))throw Error('Explicit synthetic fixture and port required');
const records=JSON.parse(readFileSync(file,'utf8'));
createServer((request,response)=>{
  if(request.method!=='GET' || request.url!=='/fixture/workspace'){
    response.writeHead(404);response.end();return;
  }
  response.writeHead(200,{'Content-Type':'application/json'});
  response.end(JSON.stringify({fixture:true,qualified:false,documents:records}));
}).listen(Number(port),'127.0.0.1');
