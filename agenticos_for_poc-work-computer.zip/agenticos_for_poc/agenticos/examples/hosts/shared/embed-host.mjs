// Host placement only: no assistant features, state, credentials or React.
const config=await fetch('/assistant-host-config',{credentials:'same-origin'}).then(r=>r.json());
document.getElementById('host-title').textContent=config.kind==='python-notes'?'Notes workspace':'Document workspace';
const selector=document.getElementById('account');for(const account of config.users){const option=document.createElement('option');option.value=account;option.textContent=account;selector.append(option);}
if(config.kind==='node-workspace')customElements.define('assistant-placement',class extends HTMLElement{connectedCallback(){this.setAttribute('aria-label','Document host assistant placement');}});
const {mountAssistant}=await import(config.osOrigin+'/os/ui/assets/embed.js');
let placement=null,csrf=null;
document.getElementById('login').addEventListener('submit',async event=>{event.preventDefault();placement?.accountChanged();placement=null;
 csrf=null;document.getElementById('open-assistant').disabled=true;document.getElementById('host-status').textContent='Signing in';
 const response=await fetch('/auth/login',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({userRef:selector.value})});
 if(!response.ok){document.getElementById('host-status').textContent='Sign-in unavailable';return;}
 csrf=(await response.json()).csrf;document.getElementById('open-assistant').disabled=false;document.getElementById('host-status').textContent='Signed in';});
document.getElementById('open-assistant').addEventListener('click',()=>{
 placement?.destroy();placement=mountAssistant({container:document.getElementById('placement'),origin:config.osOrigin,registration:config.embedRef,
  allowReviewPopups:config.reviewPopups===true,
  bootstrap:async binding=>{const response=await fetch('/integrations/agentic-os/bootstrap',{method:'POST',credentials:'same-origin',
   headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(binding)});if(!response.ok)throw Error('Bootstrap unavailable');return response.json();},
  onClose:()=>{placement=null;},onError:message=>{document.getElementById('host-status').textContent=message;}});
});
document.getElementById('switch-account').addEventListener('click',()=>{placement?.accountChanged();placement=null;});
document.querySelector('#login button').disabled=false;
