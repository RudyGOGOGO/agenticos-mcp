# Synthetic transactional host qualification

These independently executed Python and Node hosts demonstrate the remote
provider envelope required by G04. They import no OS kernel/ORM, know no OS or
financial database credentials, and do not replace either existing read fixture.
Each owns a separately provisioned SQLite store with a four-part namespace,
current host permissions, typed resource schema, immutable staging snapshots,
invocation identity/receipts, audit and outbox. Startup never creates tables or
seeds data. Private fixture configuration pins the copied wire-schema artifact;
requests cannot select a schema URL, database or authority endpoint.

The host validates every supplied field and preserves omitted versus null values,
strings versus integers and leading-zero identifiers. A staged update captures
before/after values, schema and expected resource version for ten minutes. An
immutable proposal binds that evidence, exact diff, source provenance, provider,
guarantee and risk. The short-lived OS permit is separately introspected over an
authenticated fixed loopback endpoint. An agent-supplied decision is not sufficient.
The local provider freshness limit is five seconds, with a host permission/version
check inside the final transaction. This is not zero-time distributed revocation.

A new accepted invocation is durably marked PENDING. The business mutation,
COMMITTED receipt, audit and outbox then commit together. Concurrent requests
serialize on stable invocation ID and digest; different digests conflict. A lost
reply or host restart reconciles through the persisted authoritative receipt,
without another permit or mutation. Receipt lookup is a trusted metadata-only
service operation after account removal; public evidence disclosure still needs
current owner/read authorization in the OS.

An absent lookup returns UNKNOWN. Cancellation may create a terminal absence
proof only by atomically persisting a tombstone that blocks every later execution
of the same invocation. An accepted PENDING request stays PENDING and may commit
after cancellation. Failed transaction tests retain uncertain PENDING truth; they
do not blindly rerun a write or pretend the record was rolled back safely.
Unresolved provider work needs OS quarantine/repair, not a new invocation ID.
Medium-risk delegation has exact capability/resource/field/time/usage bounds and
an independently current host record; high risk rejects delegation-only authority.

Qualification:

```sh
python3 tools/test_os.py --phase G04 --component host-effects --manifest /absolute/owned/manifest.json --report /absolute/private/host-effects.json
```

The test runner provisions synthetic stores under private owned directories,
starts actual separate processes, tests HTTP/SQLite concurrency/failure/restart,
and retains safe process logs. The isolated permit fixture is explicitly a
**component fixture**, not the OS review/HITL implementation. The combined G04
workflow, interactive assurance, decision transaction, continuation authority,
private notifications and compensation are separate pending gates. No financial
write or external communication is enabled. Final two-host browser and clean
installation acceptance remain pending.

The Node host qualifies the pinned Node 22 profile using its actual experimental
`node:sqlite` implementation; this is not a production or cross-platform guarantee.
Its AJV dependencies have their own exact lock. Python uses the frozen local test
runtime's FastAPI/HTTPX/jsonschema dependencies. Host applications can implement
the same wire guarantees in their own languages and databases; these fixture
choices do not constrain the independent OS's PostgreSQL stack.
