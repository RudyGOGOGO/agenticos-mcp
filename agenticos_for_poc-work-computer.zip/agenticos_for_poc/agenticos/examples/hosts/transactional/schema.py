"""Host-owned synthetic schema, provisioned externally; never by startup."""

DDL = r"""
-- Synthetic host-owned SQLite schema, provisioned externally, never by startup.
PRAGMA foreign_keys=ON;
CREATE TABLE principals(subject_id TEXT PRIMARY KEY,active INTEGER NOT NULL CHECK(active IN (0,1)),can_read INTEGER NOT NULL CHECK(can_read IN (0,1)),can_write INTEGER NOT NULL CHECK(can_write IN (0,1)),policy_generation INTEGER NOT NULL CHECK(policy_generation>0),resource_ids TEXT NOT NULL);
CREATE TABLE resources(external_id TEXT PRIMARY KEY,owner TEXT NOT NULL REFERENCES principals(subject_id),fields TEXT NOT NULL,revision INTEGER NOT NULL CHECK(revision>0),UNIQUE(external_id,owner));
CREATE TABLE stages(id TEXT PRIMARY KEY,owner TEXT NOT NULL REFERENCES principals(subject_id),resource_id TEXT NOT NULL,expected_revision INTEGER NOT NULL CHECK(expected_revision>0),payload TEXT NOT NULL,FOREIGN KEY(resource_id,owner) REFERENCES resources(external_id,owner));
CREATE TRIGGER immutable_stage_update BEFORE UPDATE ON stages BEGIN SELECT RAISE(ABORT,'immutable stage'); END;
CREATE TRIGGER immutable_stage_delete BEFORE DELETE ON stages BEGIN SELECT RAISE(ABORT,'immutable stage'); END;
CREATE TABLE invocations(id TEXT PRIMARY KEY,owner TEXT NOT NULL REFERENCES principals(subject_id),digest TEXT NOT NULL CHECK(length(digest)=64),state TEXT NOT NULL CHECK(state IN ('PENDING','COMMITTED','REJECTED_BEFORE_EFFECT','CONFIRMED_NOT_APPLIED')),receipt TEXT NOT NULL,envelope TEXT);
CREATE TRIGGER immutable_invocation_identity BEFORE UPDATE ON invocations WHEN OLD.id<>NEW.id OR OLD.owner<>NEW.owner OR OLD.digest<>NEW.digest OR OLD.envelope IS NOT NEW.envelope BEGIN SELECT RAISE(ABORT,'immutable invocation'); END;
CREATE TRIGGER terminal_invocation BEFORE UPDATE ON invocations WHEN OLD.state<>'PENDING' BEGIN SELECT RAISE(ABORT,'terminal receipt'); END;
CREATE TRIGGER immutable_invocation_delete BEFORE DELETE ON invocations BEGIN SELECT RAISE(ABORT,'immutable invocation'); END;
CREATE TABLE audit(id TEXT PRIMARY KEY,invocation_id TEXT NOT NULL UNIQUE REFERENCES invocations(id),owner TEXT NOT NULL REFERENCES principals(subject_id),payload TEXT NOT NULL);
CREATE TABLE outbox(id TEXT PRIMARY KEY,invocation_id TEXT NOT NULL UNIQUE REFERENCES invocations(id),payload TEXT NOT NULL);
CREATE TABLE delegations(id TEXT PRIMARY KEY,owner TEXT NOT NULL REFERENCES principals(subject_id),active INTEGER NOT NULL CHECK(active IN (0,1)),uses INTEGER NOT NULL CHECK(uses>=0),payload TEXT NOT NULL);
CREATE TABLE delegation_controls(id TEXT PRIMARY KEY REFERENCES delegations(id),definition_digest TEXT NOT NULL CHECK(length(definition_digest)=64));
CREATE TRIGGER immutable_delegation_control_update BEFORE UPDATE ON delegation_controls BEGIN SELECT RAISE(ABORT,'immutable delegation control'); END;
CREATE TRIGGER immutable_delegation_control_delete BEFORE DELETE ON delegation_controls BEGIN SELECT RAISE(ABORT,'immutable delegation control'); END;
CREATE TRIGGER finite_owned_delegation_update BEFORE UPDATE ON delegations WHEN EXISTS(SELECT 1 FROM delegation_controls WHERE id=OLD.id) AND (OLD.id<>NEW.id OR OLD.owner<>NEW.owner OR OLD.payload<>NEW.payload OR NEW.active>OLD.active OR NEW.uses<OLD.uses OR NEW.uses>1) BEGIN SELECT RAISE(ABORT,'finite delegation'); END;
CREATE TRIGGER finite_owned_delegation_delete BEFORE DELETE ON delegations WHEN EXISTS(SELECT 1 FROM delegation_controls WHERE id=OLD.id) BEGIN SELECT RAISE(ABORT,'immutable delegation'); END;
"""
