"""Independent owned synthetic effect host. No Agentic OS imports/DB access.

Provisioning is external. Startup never creates tables or seeds records. The
fixture demonstrates a provider's own transactional envelope, not production
identity or a reusable financial write implementation.
"""

import argparse, asyncio, hashlib, hmac, json, os, re, sqlite3, stat, time
from pathlib import Path
from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4, uuid5
from contextlib import contextmanager
import httpx, uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from wire import Wire, canonical_bytes, parse_canonical_json, digest
from jsonschema.exceptions import ValidationError


class Failure(Exception):
    def __init__(self, code, status=400):
        self.code = code
        self.status = status


def private(path, directory=False):
    path = Path(path)
    info = path.lstat()
    if (
        path.resolve() != path.absolute()
        or info.st_uid != os.getuid()
        or info.st_mode & 0o077
        or not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode))
    ):
        raise RuntimeError("Explicit private owned fixture required")


def instant():
    return datetime.now(timezone.utc)


def iso(value):
    return value.isoformat().replace("+00:00", "Z")


def clock(text):
    value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if value.tzinfo is None:
        raise Failure("INVALID")
    return value.astimezone(timezone.utc)


class Host:
    def __init__(self, path):
        private(path)
        self.root = path.parent
        private(self.root, True)
        self.cfg = parse_canonical_json(path.read_bytes())
        if (
            self.cfg["fixture"] != "owned-agentic-os-effects"
            or self.cfg["language"] != "python"
        ):
            raise RuntimeError("Wrong fixture")
        for name in ["store.sqlite", "contracts.json", "controls.json"]:
            private(self.root / name)
        if (
            hashlib.sha256((self.root / "contracts.json").read_bytes()).hexdigest()
            != self.cfg["contractsDigest"]
        ):
            raise RuntimeError("Wire release mismatch")
        self.wire = Wire(self.root / "contracts.json")
        self.schema = self.cfg["schema"]
        self.wire.validate("ResourceContract", self.schema)
        if self.schema["schemaHash"] != digest(
            "definition", {k: v for k, v in self.schema.items() if k != "schemaHash"}
        ):
            raise RuntimeError("Input schema mismatch")
        if self.cfg["permitOrigin"] != f"http://127.0.0.1:{self.cfg['permitPort']}":
            raise RuntimeError("Fixed loopback authority required")
        # Explicit reviewed profile; old preparation defaults remain unchanged.
        self.execution_profile = self.cfg.get("executionProfile")
        if "executionProfile" in self.cfg and (
            self.execution_profile != "reviewed-host-effect/1"
            or type(self.cfg.get("observerKey")) is not str
            or re.fullmatch(r"[A-Za-z0-9_-]{43,128}", self.cfg["observerKey"]) is None
            or self.cfg["observerKey"] in {self.cfg["bridgeKey"], self.cfg["permitKey"]}
        ):
            raise RuntimeError("Unqualified reviewed execution fixture")
        if self.execution_profile:
            self.wire.validate("CapabilityDescriptor", self.cfg.get("descriptor"))
            desc = self.cfg["descriptor"]
            if (desc["id"] != self.cfg["capabilityRef"] or desc["kind"] != "effect"
                    or desc["riskFloor"] != self.cfg["risk"]
                    or desc["guaranteeProfile"] != "atomic-host-effect/1"):
                raise RuntimeError("Reviewed descriptor mismatch")
        elif "observerKey" in self.cfg:
            raise RuntimeError("Observer credential requires qualified profile")
        self.review_assurance=self.cfg.get('reviewAssurance','local-synthetic')
        if (self.review_assurance not in {'local-synthetic','oidc-step-up/1'}
                or 'reviewAssurance' in self.cfg and not self.execution_profile):
            raise RuntimeError('Explicit supported reviewed assurance required')
        self.inspection_profile = self.cfg.get("inspectionProfile")
        if "inspectionProfile" in self.cfg and (
            self.inspection_profile != "reviewed-host-inspection/1" or not self.execution_profile
        ):
            raise RuntimeError("Unqualified reviewed inspection fixture")
        self.purposes = {"assistant.prepare", "assistant.execute"} if self.execution_profile else {"assistant.prepare"}
        if self.inspection_profile:
            self.purposes.add("assistant.inspect")
        self.delegation_profile = self.cfg.get("delegationProfile")
        if "delegationProfile" in self.cfg and (
            self.delegation_profile != "atomic-host-delegation/1" or not self.execution_profile
            or self.cfg["risk"] != "medium" or type(self.cfg.get("delegationKey")) is not str
            or re.fullmatch(r"[A-Za-z0-9_-]{43,128}",self.cfg["delegationKey"]) is None
            or self.cfg["delegationKey"] in {self.cfg["bridgeKey"],self.cfg["permitKey"],self.cfg["observerKey"]}):
            raise RuntimeError("Unqualified finite delegation fixture")
        if "delegationKey" in self.cfg and not self.delegation_profile:
            raise RuntimeError("Delegation credential requires explicit profile")
        self.running = set()

    @contextmanager
    def db(self, write=False):
        db = sqlite3.connect(
            (self.root / "store.sqlite").as_uri() + "?mode=rw",
            uri=True,
            timeout=2,
            isolation_level=None,
        )
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=2000")
        try:
            if write:
                db.execute("BEGIN IMMEDIATE")
            yield db
            if write:
                db.execute("COMMIT")
        except BaseException:
            if db.in_transaction:
                db.execute("ROLLBACK")
            raise
        finally:
            db.close()

    def owner(self, value):
        self.wire.validate("SubjectRef", value)
        if any(value[k] != v for k, v in self.cfg["namespace"].items()):
            raise Failure("DENIED", 403)
        return value["subjectId"]

    def policy(self, db, subject, write=False, resource=None):
        user = self.owner(subject)
        p = db.execute(
            "SELECT * FROM principals WHERE subject_id=?", (user,)
        ).fetchone()
        if (
            not p
            or not p["active"]
            or not p["can_read"]
            or write
            and not p["can_write"]
        ):
            raise Failure("DENIED", 403)
        if resource is not None and resource not in parse_canonical_json(
            p["resource_ids"]
        ):
            raise Failure("DENIED", 403)
        return p

    def authority(self, request):
        self.wire.validate('HostAuthorityRequest',request)
        descriptor=self.cfg.get('descriptor')
        if (not descriptor or request['capabilityRef']!=descriptor['id']
                or request['purpose'] not in self.purposes):
            raise Failure('DENIED',403)
        s=request['subject']
        with self.db() as db:
            principal=self.policy(db,s,request['purpose']!='assistant.inspect')
            ids=parse_canonical_json(principal['resource_ids'])
            for r in request['resourceRefs']:
                if (r['subject']!=s or r['providerId']!=self.cfg['providerRef']
                        or r['contractVersion']!=self.schema['revision'] or r['resourceType']!=self.schema['resourceType']
                        or r['externalId'] not in ids):
                    raise Failure('DENIED',403)
            if request['delegationRef'] is not None:
                if not self.delegation_profile or request['purpose']!='assistant.execute' or not request['delegationRef'].startswith('delegation/'):
                    raise Failure('DENIED',403)
                ident=request['delegationRef'].removeprefix('delegation/')
                row=db.execute('SELECT d.* FROM delegations d JOIN delegation_controls c ON c.id=d.id WHERE d.id=? AND d.owner=?',(ident,s['subjectId'])).fetchone()
                if not row: raise Failure('DENIED',403)
                delegated=parse_canonical_json(row['payload'])
                if not row['active'] or row['uses']>=1 or clock(delegated['validUntil'])<=instant(): raise Failure('DENIED',403)
                for r in request['resourceRefs']:
                    if not any(b['resourceType']==r['resourceType'] and r['externalId'] in b['externalIds'] for b in delegated['resourceBounds']):
                        raise Failure('DENIED',403)
            generation=principal['policy_generation']
        now=instant()
        value={'id':str(uuid4()),'subject':s,'active':True,'policyGeneration':generation,
            'capabilityRefs':[descriptor['id']],'resourceBounds':[{'resourceType':self.schema['resourceType'],
                'externalIds':ids,'fieldNames':[f['name'] for f in self.schema['fields']]}],
            'purpose':request['purpose'],'checkedAt':iso(now),'validUntil':iso(now+timedelta(seconds=5)),
            'assuranceRef':None,'delegationRef':request['delegationRef']}
        self.wire.validate('HostAuthority',value)
        return value

    def capabilities(self, request):
        self.wire.validate('HostCapabilitiesRequest',request)
        if request['purpose'] not in self.purposes or not self.cfg.get('descriptor'):
            raise Failure('DENIED',403)
        with self.db() as db:self.policy(db,request['subject'],request['purpose']!='assistant.inspect')
        return {'capabilities':[self.cfg['descriptor']]}

    def delegation_control(self, request, revoke=False):
        if not self.delegation_profile: raise Failure("DENIED",403)
        self.wire.validate("HostDelegationRevocationCommand" if revoke else "HostDelegationRegistrationCommand",request)
        if revoke:
            subject,ident=request["subject"],request["delegationId"]
        else:
            d=request["delegation"]
            subject,ident=d["subject"],d["id"]
            names={f["name"] for f in self.schema["fields"]}
            duration=clock(d["validUntil"])-clock(d["validFrom"])
            duration_ms=duration.days*86400000+duration.seconds*1000+duration.microseconds//1000
            if (not d["active"] or d["revision"]!=1 or d["maxRisk"]!="medium" or d["purpose"]!="assistant.change"
                or d["capabilityRefs"]!=[self.cfg["capabilityRef"]] or len(d["resourceBounds"])!=1
                or d["budget"]!={"maxStages":1,"maxChildren":0,"maxTokens":1,"maxToolCalls":1,"maxNativeJobs":0,"deadlineMs":d["budget"]["deadlineMs"]}
                or clock(d["validFrom"])>instant()+timedelta(seconds=1)
                or not instant()<clock(d["validUntil"])<=clock(d["validFrom"])+timedelta(minutes=5)
                or d["budget"]["deadlineMs"]!=duration_ms):
                raise Failure("DENIED",403)
            bound=d["resourceBounds"][0]
            if (bound["resourceType"]!=self.schema["resourceType"] or len(bound["externalIds"])!=1
                or not bound["fieldNames"] or not set(bound["fieldNames"])<=names): raise Failure("DENIED",403)
        with self.db(True) as db:
            self.policy(db,subject,True)
            row=db.execute('SELECT d.*,c.definition_digest FROM delegations d JOIN delegation_controls c ON c.id=d.id WHERE d.id=? AND d.owner=?',(ident,subject['subjectId'])).fetchone()
            if row:
                if row['definition_digest']!=request['definitionDigest'] or not revoke and parse_canonical_json(row['payload'])!=d:
                    raise Failure('CONFLICT',409)
                d=parse_canonical_json(row['payload'])
                if revoke and row['active']: db.execute('UPDATE delegations SET active=0 WHERE id=?',(ident,))
            elif revoke: raise Failure('DENIED',403)
            else:
                self.policy(db,subject,True,bound['externalIds'][0])
                db.execute('INSERT INTO delegations VALUES (?,?,?,?,?)',(ident,subject['subjectId'],1,0,canonical_bytes(d).decode()))
                db.execute('INSERT INTO delegation_controls VALUES (?,?)',(ident,request['definitionDigest']))
        result=dict(subject=subject,delegationId=ident,delegationDigest=request['definitionDigest'],providerRef=self.cfg['providerRef'],
            expiresAt=d['validUntil'],profileRef='atomic-host-delegation/1')
        self.wire.validate('HostDelegationRegistrationReceipt',result)
        return result

    def verify_stage(self, request):
        value=self.stage(request)
        resource=value['resource']
        with self.db() as db:
            self.policy(db,request['subject'],True,resource['externalId'])
            row=db.execute('SELECT * FROM resources WHERE external_id=? AND owner=?',
                (resource['externalId'],request['subject']['subjectId'])).fetchone()
            before={f['name']:f['value'] for f in value['beforeFields']}
            if (not row or str(row['revision'])!=resource['observedVersion']
                    or parse_canonical_json(row['fields'])!=before):
                raise Failure('STALE',409)
        return value

    def description(self, subject):
        with self.db() as db:
            self.policy(db, subject, write=True)
        return {
            "subject": subject,
            "schema": self.schema,
            "capabilityRef": self.cfg["capabilityRef"],
            "providerRef": self.cfg["providerRef"],
            "guaranteeRef": "atomic-host-effect/1",
            "risk": self.cfg["risk"],
        }

    def fields(self, fields):
        definitions = {f["name"]: f for f in self.schema["fields"]}
        result = {}
        errors = []
        for f in fields:
            self.wire.validate("FieldValue", f)
            name = f["name"]
            value = f["value"]
            if name in result:
                raise Failure("INVALID")
            result[name] = value
            d = definitions.get(name)
            code = None
            if d is None:
                code = "UNKNOWN_FIELD"
            elif value is None and not d["nullable"]:
                code = "NULL_NOT_ALLOWED"
            elif value is not None and (
                type(value) is not str or len(value) > d["maxLength"]
            ):
                code = "TYPE_OR_LENGTH"
            if code:
                errors.append(
                    {
                        "field": name,
                        "code": code,
                        "safeMessage": "Check this field against the registered input schema.",
                    }
                )
        return result, errors

    def validate(self, request):
        self.wire.validate("ResourceValidationRequest", request)
        s = request["subject"]
        r = request["resourceRef"]
        if (
            request["contractRef"] != self.schema["id"]
            or request["contractRevision"] != self.schema["revision"]
            or request["operation"] != "update"
            or not r
            or r["subject"] != s
            or r["resourceType"] != self.schema["resourceType"]
            or r["providerId"] != self.cfg["providerRef"]
            or r["contractVersion"] != self.schema["revision"]
        ):
            raise Failure("INVALID")
        patch, errors = self.fields(request["fields"])
        if not patch:
            raise Failure("INVALID")
        with self.db(True) as db:
            self.policy(db, s, True, r["externalId"])
            row = db.execute(
                "SELECT * FROM resources WHERE external_id=? AND owner=?",
                (r["externalId"], s["subjectId"]),
            ).fetchone()
            if not row:
                raise Failure("NOT_FOUND", 404)
            if str(row["revision"]) != r["observedVersion"]:
                raise Failure("STALE", 409)
            if errors:
                return {
                    "valid": False,
                    "stageRef": None,
                    "fieldErrors": errors,
                    "clarificationFields": [],
                }
            before = parse_canonical_json(row["fields"])
            after = {**before, **patch}
            if before == after:
                raise Failure("NO_CHANGE")
            created = instant()
            stage = {
                "id": str(uuid4()),
                "subject": s,
                "resource": r,
                "schema": self.schema,
                "operation": "update",
                "beforeFields": [
                    {"name": k, "value": v} for k, v in sorted(before.items())
                ],
                "afterFields": [
                    {"name": k, "value": v} for k, v in sorted(after.items())
                ],
                "evidenceDigest": "0" * 64,
                "createdAt": iso(created),
                "expiresAt": iso(created + timedelta(minutes=10)),
            }
            stage["evidenceDigest"] = digest(
                "evidence", {k: v for k, v in stage.items() if k != "evidenceDigest"}
            )
            self.wire.validate("HostChangeStage", stage)
            db.execute(
                "INSERT INTO stages VALUES (?,?,?,?,?)",
                (
                    stage["id"],
                    s["subjectId"],
                    r["externalId"],
                    int(row["revision"]),
                    canonical_bytes(stage).decode(),
                ),
            )
        return {
            "valid": True,
            "stageRef": "stage/" + stage["id"],
            "fieldErrors": [],
            "clarificationFields": [],
        }

    def stage(self, request):
        self.wire.validate("HostStageRequest", request)
        with self.db() as db:
            row = db.execute(
                "SELECT * FROM stages WHERE id=? AND owner=?",
                (request["stageId"], self.owner(request["subject"])),
            ).fetchone()
            if not row:
                raise Failure("NOT_FOUND", 404)
            self.policy(db, request["subject"], True, row["resource_id"])
            value = parse_canonical_json(row["payload"])
            if clock(value["expiresAt"]) <= instant():
                raise Failure("EXPIRED", 409)
            return value

    def base_receipt(self, request, status, resources=None):
        r = {
            "id": str(uuid5(UUID(request["invocationId"]), "host.receipt")),
            "subject": request["subject"],
            "providerRef": self.cfg["providerRef"],
            "invocationId": request["invocationId"],
            "requestDigest": request["requestDigest"],
            "status": status,
            "version": 1,
            "observedAt": iso(instant()),
            "affectedResources": resources or [],
            "auditRefs": [],
            "evidenceRefs": [],
            "attestationProfile": "atomic-host-effect/1",
        }
        self.wire.validate("EffectReceipt", r)
        return r

    def prior(self, db, request):
        row = db.execute(
            "SELECT * FROM invocations WHERE id=?", (request["invocationId"],)
        ).fetchone()
        if row and (
            row["owner"] != request["subject"]["subjectId"]
            or row["digest"] != request["requestDigest"]
        ):
            raise Failure("CONFLICT", 409)
        return row

    def lookup(self, request, cancel=False):
        self.wire.validate("EffectLookupRequest", request)
        if request["providerRef"] != self.cfg["providerRef"]:
            raise Failure("DENIED", 403)
        with self.db(cancel) as db:
            self.owner(request["subject"])
            if not db.execute(
                "SELECT subject_id FROM principals WHERE subject_id=?",
                (request["subject"]["subjectId"],),
            ).fetchone():
                raise Failure("DENIED", 403)
            row = self.prior(db, request)
            if self.execution_profile:
                self.policy(db, request["subject"], write=cancel)
                if row:
                    for resource in parse_canonical_json(row["receipt"])["affectedResources"]:
                        self.policy(db, request["subject"], resource=resource["externalId"])
            if row:
                return parse_canonical_json(row["receipt"])
            receipt = self.base_receipt(
                request, "CONFIRMED_NOT_APPLIED" if cancel else "UNKNOWN"
            )
            if cancel:
                # An absence-only cancellation is authoritative because this
                # tombstone serializes against every later admission in SQLite.
                db.execute(
                    "INSERT INTO invocations VALUES (?,?,?,?,?,?)",
                    (
                        request["invocationId"],
                        request["subject"]["subjectId"],
                        request["requestDigest"],
                        "CONFIRMED_NOT_APPLIED",
                        canonical_bytes(receipt).decode(),
                        None,
                    ),
                )
            return receipt

    def observe(self, request):
        """Receipt state only. Never a login/read/effect/cancel authority."""
        if self.execution_profile != "reviewed-host-effect/1":
            raise Failure("DENIED", 403)
        self.wire.validate("EffectLookupRequest", request)
        self.owner(request["subject"])
        if request["providerRef"] != self.cfg["providerRef"]:
            raise Failure("DENIED", 403)
        with self.db() as db:
            row = self.prior(db, request)
            receipt = parse_canonical_json(row["receipt"]) if row else None
        result = {
            "subject": request["subject"],
            "providerRef": request["providerRef"],
            "invocationId": request["invocationId"],
            "requestDigest": request["requestDigest"],
            "receiptId": receipt["id"] if receipt else None,
            "status": receipt["status"] if receipt else "UNKNOWN",
            "version": receipt["version"] if receipt else None,
            "observedAt": iso(instant()),
            "attestationProfile": "atomic-host-receipt-observation/1",
        }
        # Explicit owned synthetic response fault. The terminal receipt and
        # its integrity trigger stay intact; only this observation regresses.
        faults = parse_canonical_json((self.root / "controls.json").read_bytes())
        if (faults.get("regressReceiptVersion") is True
            and result["version"] is not None and result["version"] > 1):
            result["version"] -= 1
        self.wire.validate("ReceiptObservation", result)
        return result

    def bind(self, envelope, stage):
        p = envelope["proposal"]
        r = envelope["request"]
        intent = p["intent"]
        s = r["subject"]
        pd = digest("proposal", {k: v for k, v in p.items() if k != "digest"})
        rd = digest(
            "command",
            {
                "subject": s,
                "invocationId": r["invocationId"],
                "proposalDigest": p["digest"],
                "capabilityRef": envelope["capabilityRef"],
            },
        )
        if (
            pd != p["digest"]
            or rd != r["requestDigest"]
            or p["subject"] != s
            or intent["subject"] != s
            or r["proposalRef"] != "proposal/" + p["id"]
            or r["proposalRevision"] != p["revision"]
            or envelope["capabilityRef"] != self.cfg["capabilityRef"]
            or p["providerRef"] != self.cfg["providerRef"]
            or p["guaranteeRef"] != "atomic-host-effect/1"
            or p["risk"] != self.cfg["risk"]
            or p["requiredAssurance"] != self.review_assurance
            or p["evidenceDigest"] != stage["evidenceDigest"]
            or stage["subject"] != s
            or stage["schema"] != self.schema
            or p["expectedVersions"] != [stage["resource"]]
            or intent["targets"] != [stage["resource"]]
            or intent["contractRef"] != self.schema["id"]
            or intent["contractVersion"] != self.schema["revision"]
            or intent["operation"] != "update"
            or intent["destinationRefs"]
            or intent["scopeRef"] != self.cfg["scopeRef"]
            or intent["evidenceRefs"] != ["stage/" + stage["id"]]
            or clock(p["expiresAt"]) > clock(stage["expiresAt"])
        ):
            raise Failure("BINDING", 403)
        before = {f["name"]: f for f in stage["beforeFields"]}
        after = {f["name"]: f for f in stage["afterFields"]}
        changed = sorted(
            k for k in set(before) | set(after) if before.get(k) != after.get(k)
        )
        if (
            not changed
            or p["diff"]
            != [
                {"name": k, "before": before.get(k), "after": after.get(k)}
                for k in changed
            ]
            or intent["fields"] != [after[k] for k in changed]
        ):
            raise Failure("BINDING", 403)
        return rd

    async def permit(self, envelope):
        r = envelope["request"]
        p = envelope["proposal"]
        request = {
            "subject": r["subject"],
            "permitRef": envelope["permitRef"],
            "invocationId": r["invocationId"],
            "requestDigest": r["requestDigest"],
            "proposalDigest": p["digest"],
            "capabilityRef": envelope["capabilityRef"],
        }
        async with httpx.AsyncClient(
            trust_env=False, follow_redirects=False, timeout=2
        ) as client:
            async with client.stream(
                "POST",
                self.cfg["permitOrigin"] + "/os/internal/effects/introspect",
                content=canonical_bytes(request),
                headers={
                    "Authorization": "Bearer " + self.cfg["permitKey"],
                    "Content-Type": "application/json",
                    "Accept-Encoding": "identity",
                },
            ) as response:
                if (
                    response.status_code != 200
                    or response.headers.get("content-type", "").split(";")[0]
                    != "application/json"
                    or response.headers.get("content-encoding", "identity")
                    != "identity"
                ):
                    raise Failure("UNAVAILABLE", 503)
                content = bytearray()
                async for chunk in response.aiter_bytes():
                    content.extend(chunk)
                    if len(content) > 65536:
                        raise Failure("UNAVAILABLE", 503)
        value = parse_canonical_json(bytes(content))
        self.wire.validate("EffectPermitStatus", value)
        if (
            not value["valid"]
            or any(
                value[k] != request[k]
                for k in [
                    "subject",
                    "invocationId",
                    "requestDigest",
                    "proposalDigest",
                    "capabilityRef",
                ]
            )
            or value["authorityRef"] != r["authorityRef"]
            or value["authorization"] != r["authorization"]
            or value["assuranceRef"] != ("bounded-delegation/1" if self.delegation_profile and r["authorization"]["kind"]=="bounded_delegation" else self.review_assurance)
            or value["risk"] != p["risk"]
            or not instant() - timedelta(seconds=5)
            <= clock(value["checkedAt"])
            <= instant() + timedelta(seconds=5)
            or not instant()
            < clock(value["expiresAt"])
            <= min(instant() + timedelta(seconds=60), clock(p["expiresAt"]))
        ):
            raise Failure("DENIED", 403)
        if self.delegation_profile and r["authorization"]["kind"]=="bounded_delegation" and (
            clock(value["checkedAt"])>instant()+timedelta(seconds=1)
            or clock(value["expiresAt"])>clock(value["checkedAt"])+timedelta(seconds=5)):
            raise Failure("DENIED",403)
        auth = value["authorization"]
        if auth["kind"] == "review_decision":
            d = auth["decision"]
            if (
                d["subject"] != r["subject"]
                or d["proposalId"] != p["id"]
                or d["proposalRevision"] != p["revision"]
                or d["digest"] != p["digest"]
                or d["assuranceRef"] != self.review_assurance
                or not instant() < clock(d["expiresAt"]) <= clock(p["expiresAt"])
                or clock(value["expiresAt"]) > clock(d["expiresAt"])
            ):
                raise Failure("DENIED", 403)
        else:
            d = auth["delegation"]
            names = {f["name"] for f in p["intent"]["fields"]}
            resource = p["expectedVersions"][0]
            if (
                p["risk"] != "medium"
                or d["maxRisk"] != "medium"
                or not d["active"]
                or d["subject"] != r["subject"]
                or self.cfg["capabilityRef"] not in d["capabilityRefs"]
                or d["purpose"] != "assistant.change"
                or not clock(d["validFrom"]) <= instant() < clock(d["validUntil"])
                or clock(value["expiresAt"]) > clock(d["validUntil"])
                or not any(
                    b["resourceType"] == resource["resourceType"]
                    and resource["externalId"] in b["externalIds"]
                    and names <= set(b["fieldNames"])
                    for b in d["resourceBounds"]
                )
            ):
                raise Failure("DENIED", 403)
        return value

    async def execute(self, envelope):
        self.wire.validate("HostEffectEnvelope", envelope)
        r = envelope["request"]
        s = r["subject"]
        with self.db() as db:
            self.policy(db, s)
            existing = self.prior(db, r)
            if existing:
                return parse_canonical_json(existing["receipt"])
        stage = self.stage({"subject": s, "stageId": envelope["stageId"]})
        self.bind(envelope, stage)
        grant = await self.permit(envelope)
        accepted = time.monotonic()
        with self.db(True) as db:
            existing = self.prior(db, r)
            if existing:
                return parse_canonical_json(existing["receipt"])
            policy = self.policy(db, s, True, stage["resource"]["externalId"])
            if policy["policy_generation"] != grant["policyGeneration"]:
                raise Failure("DENIED", 403)
            receipt = self.base_receipt(r, "PENDING")
            db.execute(
                "INSERT INTO invocations VALUES (?,?,?,?,?,?)",
                (
                    r["invocationId"],
                    s["subjectId"],
                    r["requestDigest"],
                    "PENDING",
                    canonical_bytes(receipt).decode(),
                    canonical_bytes(envelope).decode(),
                ),
            )
        self.running.add(r["invocationId"])
        try:
            # Explicit fixture fault only, bounded by the declared five-second
            # introspection freshness. No delay or code comes from agent input.
            until = time.monotonic() + 3
            while (
                parse_canonical_json((self.root / "controls.json").read_bytes()).get(
                    "holdAccepted", False
                )
                and time.monotonic() < until
            ):
                await asyncio.sleep(0.02)
            with self.db(True) as db:
                existing = self.prior(db, r)
                if existing["state"] != "PENDING":
                    return parse_canonical_json(existing["receipt"])
                p = self.policy(db, s, True, stage["resource"]["externalId"])
                resource = db.execute(
                    "SELECT * FROM resources WHERE external_id=? AND owner=?",
                    (stage["resource"]["externalId"], s["subjectId"]),
                ).fetchone()
                if (
                    p["policy_generation"] != grant["policyGeneration"]
                    or time.monotonic() - accepted > 5
                    or clock(grant["expiresAt"]) <= instant()
                    or clock(stage["expiresAt"]) <= instant()
                    or not resource
                    or str(resource["revision"]) != stage["resource"]["observedVersion"]
                ):
                    receipt = self.base_receipt(r, "REJECTED_BEFORE_EFFECT")
                else:
                    if grant["authorization"]["kind"] == "bounded_delegation":
                        d = grant["authorization"]["delegation"]
                        row = db.execute(
                            "SELECT * FROM delegations WHERE id=? AND owner=?",
                            (d["id"], s["subjectId"]),
                        ).fetchone()
                        if (
                            not row
                            or not row["active"]
                            or parse_canonical_json(row["payload"]) != d
                            or row["uses"] >= d["budget"]["maxToolCalls"]
                            or clock(d["validUntil"]) <= instant()
                        ):
                            receipt = self.base_receipt(r, "REJECTED_BEFORE_EFFECT")
                        else:
                            db.execute(
                                "UPDATE delegations SET uses=uses+1 WHERE id=?",
                                (d["id"],),
                            )
                            receipt = None
                    else:
                        receipt = None
                    if receipt is None:
                        after = {f["name"]: f["value"] for f in stage["afterFields"]}
                        revision = resource["revision"] + 1
                        db.execute(
                            "UPDATE resources SET fields=?,revision=? WHERE external_id=? AND owner=?",
                            (
                                canonical_bytes(after).decode(),
                                revision,
                                stage["resource"]["externalId"],
                                s["subjectId"],
                            ),
                        )
                        refs = [{**stage["resource"], "observedVersion": str(revision)}]
                        receipt = self.base_receipt(r, "COMMITTED", refs)
                        audit = str(uuid4())
                        event = str(uuid4())
                        receipt["auditRefs"] = ["audit/" + audit]
                        receipt["evidenceRefs"] = ["stage/" + stage["id"]]
                        db.execute(
                            "INSERT INTO audit VALUES (?,?,?,?)",
                            (
                                audit,
                                r["invocationId"],
                                s["subjectId"],
                                canonical_bytes(
                                    {
                                        "before": stage["beforeFields"],
                                        "after": stage["afterFields"],
                                    }
                                ).decode(),
                            ),
                        )
                        db.execute(
                            "INSERT INTO outbox VALUES (?,?,?)",
                            (
                                event,
                                r["invocationId"],
                                canonical_bytes(
                                    {"resource": refs[0], "receiptId": receipt["id"]}
                                ).decode(),
                            ),
                        )
                if self.execution_profile:
                    # A reviewed observer can see PENDING before this commit.
                    # Preserve its identity and advance the receipt revision
                    # in the same transaction as the terminal host outcome.
                    previous = parse_canonical_json(existing["receipt"])
                    if previous["status"] != "PENDING" or previous["id"] != receipt["id"]:
                        raise Failure("BINDING", 403)
                    receipt["version"] = previous["version"] + 1
                self.wire.validate("EffectReceipt", receipt)
                db.execute(
                    "UPDATE invocations SET state=?,receipt=? WHERE id=?",
                    (
                        receipt["status"],
                        canonical_bytes(receipt).decode(),
                        r["invocationId"],
                    ),
                )
                if parse_canonical_json((self.root / "controls.json").read_bytes()).get(
                    "failCommit", False
                ):
                    db.execute("INSERT INTO missing_failure_injection_table VALUES (1)")
            if parse_canonical_json((self.root / "controls.json").read_bytes()).get(
                "loseAck", False
            ):
                raise Failure("ACK_LOST", 503)
            return receipt
        finally:
            self.running.discard(r["invocationId"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    host = Host(args.config)
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    @app.get("/health")
    def health():
        return {"fixture": "transactional-python", "assurance": "local-synthetic"}

    @app.post("/host-bridge/v1/{section}/{operation}")
    @app.post("/host-bridge/v1/{section}")
    async def handle(section: str, request: Request, operation: str=""):
        try:
            header = request.headers.get("authorization", "")
            controlling = (section, operation) in {("delegations","register"),("delegations","revoke")}
            observing = (section, operation) == ("effects", "observe")
            expected = host.cfg.get("delegationKey") if controlling and host.delegation_profile else (host.cfg.get("observerKey") if observing and host.execution_profile else host.cfg["bridgeKey"])
            if (controlling and not host.delegation_profile) or (observing and not host.execution_profile) or not hmac.compare_digest(header, "Bearer " + expected):
                raise Failure("DENIED", 401)
            raw = bytearray()
            async for chunk in request.stream():
                raw.extend(chunk)
                if len(raw) > 65536:
                    raise Failure("INVALID", 413)
            raw = bytes(raw)
            body = parse_canonical_json(raw)
            route = (section, operation)
            if route in {("delegations","register"),("delegations","revoke")}:
                value = await asyncio.to_thread(host.delegation_control,body,route[1]=="revoke")
            elif route == ("resources", "describe"):
                host.wire.validate("ResourceDescribeRequest", body)
                if (
                    body["contractRef"] != host.schema["id"]
                    or body["contractRevision"] != host.schema["revision"]
                ):
                    raise Failure("INVALID")
                value = await asyncio.to_thread(host.description, body["subject"])
            elif route == ("resources", "validate"):
                value = await asyncio.to_thread(host.validate, body)
            elif route == ("resources", "stage"):
                value = await asyncio.to_thread(host.stage, body)
            elif route == ("resources", "verify"):
                value = await asyncio.to_thread(host.verify_stage, body)
            elif route == ("authority", "check"):
                value = await asyncio.to_thread(host.authority, body)
            elif route == ("capabilities", ""):
                value = await asyncio.to_thread(host.capabilities, body)
            elif route == ("effects", "observe"):
                value = await asyncio.to_thread(host.observe, body)
            elif route == ("effects", "execute"):
                value = await host.execute(body)
            elif route in {("effects", "lookup"), ("effects", "cancel")}:
                value = await asyncio.to_thread(host.lookup, body, route[1] == "cancel")
            else:
                raise Failure("NOT_FOUND", 404)
            return JSONResponse(value)
        except Failure as error:
            return JSONResponse({"code": error.code}, status_code=error.status)
        except (ValueError, KeyError, TypeError, ValidationError):
            return JSONResponse({"code": "INVALID"}, status_code=400)
        except Exception:
            return JSONResponse({"code": "UNAVAILABLE"}, status_code=503)

    uvicorn.run(
        app,
        host="127.0.0.1",
        port=host.cfg["port"],
        log_level="error",
        access_log=False,
        limit_concurrency=32,
    )


if __name__ == "__main__":
    main()
