// agentic-os.hash/1 inspection helper. Server remains approval authority.
import { createHash } from "node:crypto";
export const purposes = new Set([
  "command",
  "manifest",
  "intent",
  "evidence",
  "proposal",
  "decision",
  "receipt",
  "surface",
  "artifact",
  "event",
  "knowledge",
  "schedule",
  "policy",
  "definition",
  "delegation",
  "verification",
]);
function checkedString(value) {
  for (const char of value) {
    const cp = char.codePointAt(0);
    if (cp >= 0xd800 && cp <= 0xdfff) throw Error("Unpaired surrogate");
  }
  return JSON.stringify(value);
}
export function canonical(value, depth = 0) {
  if (depth > 64) throw Error("Nesting limit");
  if (value === null || typeof value === "boolean")
    return JSON.stringify(value);
  if (typeof value === "string") return checkedString(value);
  if (typeof value === "number") {
    if (!Number.isSafeInteger(value)) throw Error("Unsafe number");
    return String(value === 0 ? 0 : value);
  }
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i++)
      if (!Object.hasOwn(value, i)) throw Error("Sparse array");
    return "[" + value.map((v) => canonical(v, depth + 1)).join(",") + "]";
  }
  if (
    typeof value === "object" &&
    [Object.prototype, null].includes(Object.getPrototypeOf(value))
  ) {
    if (Reflect.ownKeys(value).length !== Object.keys(value).length)
      throw Error("Hidden/symbol property");
    return (
      "{" +
      Object.keys(value)
        .sort()
        .map((k) => {
          if (!/^[\x00-\x7f]*$/.test(k)) throw Error("Non-ASCII key");
          const descriptor = Object.getOwnPropertyDescriptor(value, k);
          if (!descriptor || !("value" in descriptor))
            throw Error("Accessor property");
          return (
            checkedString(k) + ":" + canonical(descriptor.value, depth + 1)
          );
        })
        .join(",") +
      "}"
    );
  }
  throw Error("Unsupported type");
}
export function parseCanonical(raw) {
  const text =
    typeof raw === "string"
      ? raw
      : new TextDecoder("utf-8", { fatal: true }).decode(raw);
  let position = 0;
  function ws() {
    while (/[ \r\n\t]/.test(text[position] ?? "~")) position++;
  }
  function string() {
    const start = position++;
    let escaped = false;
    for (; position < text.length; position++) {
      const char = text[position];
      if (!escaped && char === '"') {
        position++;
        const result = JSON.parse(text.slice(start, position));
        checkedString(result);
        return result;
      }
      if (!escaped && char === "\\") escaped = true;
      else escaped = false;
    }
    throw Error("Unterminated string");
  }
  function value(depth = 0) {
    if (depth > 64) throw Error("Nesting limit");
    ws();
    const char = text[position];
    if (char === '"') return string();
    if (char === "{") {
      position++;
      ws();
      const result = Object.create(null);
      if (text[position] === "}") {
        position++;
        return result;
      }
      while (true) {
        ws();
        if (text[position] !== '"') throw Error("Expected key");
        const key = string();
        if (Object.hasOwn(result, key)) throw Error("Duplicate key");
        ws();
        if (text[position++] !== ":") throw Error("Expected colon");
        result[key] = value(depth + 1);
        ws();
        const end = text[position++];
        if (end === "}") return result;
        if (end !== ",") throw Error("Expected comma");
      }
    }
    if (char === "[") {
      position++;
      ws();
      const result = [];
      if (text[position] === "]") {
        position++;
        return result;
      }
      while (true) {
        result.push(value(depth + 1));
        ws();
        const end = text[position++];
        if (end === "]") return result;
        if (end !== ",") throw Error("Expected comma");
      }
    }
    for (const [word, result] of [
      ["null", null],
      ["true", true],
      ["false", false],
    ]) {
      if (text.startsWith(word, position)) {
        position += word.length;
        return result;
      }
    }
    const match = /^-?(?:0|[1-9][0-9]*)/.exec(text.slice(position));
    if (!match) throw Error("Invalid value");
    position += match[0].length;
    if (/[.eE0-9]/.test(text[position] ?? "~")) throw Error("Non-integer JSON");
    const number = Number(match[0]);
    if (!Number.isSafeInteger(number)) throw Error("Unsafe integer");
    return number;
  }
  const result = value();
  ws();
  if (position !== text.length) throw Error("Trailing input");
  canonical(result);
  return result;
}
export function digest(purpose, value) {
  if (!purposes.has(purpose)) throw Error("Unknown purpose");
  return createHash("sha256")
    .update("agentic-os.hash/1\0" + purpose + "\0" + canonical(value), "utf8")
    .digest("hex");
}

// Standalone wire implementation; no installed OS/UI or host framework imports.
import Ajv from "ajv/dist/2020.js";
import formats from "ajv-formats";
import { readFileSync } from "node:fs";
export class Wire {
  constructor(path) {
    this.schema = parseCanonical(readFileSync(path));
    this.ajv = new Ajv({ strict: true, allErrors: false });
    formats(this.ajv);
    this.ajv.addSchema(this.schema);
    this.cache = new Map();
  }
  validate(name, value) {
    canonical(value);
    if (!Object.hasOwn(this.schema.$defs, name)) throw Error("INVALID");
    if (!this.cache.has(name))
      this.cache.set(
        name,
        this.ajv.compile({ $ref: this.schema.$id + "#/$defs/" + name }),
      );
    if (!this.cache.get(name)(value)) throw Error("INVALID");
    return value;
  }
}
