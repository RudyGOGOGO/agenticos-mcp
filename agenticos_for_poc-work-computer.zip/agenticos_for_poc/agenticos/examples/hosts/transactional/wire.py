"""agentic-os.hash/1. This deliberately is not an RFC-8785 implementation."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any

SAFE_INTEGER = 2**53 - 1
PURPOSES = frozenset(
    {
        "command",
        "manifest",
        "intent",
        "evidence",
        "proposal",
        "decision",
        "receipt",
        "surface",
        "artifact",
        "event",
        "knowledge",
        "schedule",
        "policy",
        "definition",
        "delegation",
        "verification",
    }
)


class CanonicalError(ValueError):
    """Input is outside the approved canonical JSON subset."""


def _check(value: Any, depth: int = 0) -> None:
    if depth > 64:
        raise CanonicalError("Canonical nesting limit exceeded")
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        if abs(value) > SAFE_INTEGER:
            raise CanonicalError("Unsafe integer; use a schema-normalized string")
        return
    if type(value) is str:
        if any(0xD800 <= ord(char) <= 0xDFFF for char in value):
            raise CanonicalError("Unpaired surrogate")
        return
    if type(value) is list:
        for child in value:
            _check(child, depth + 1)
        return
    if type(value) is dict:
        for key, child in value.items():
            if type(key) is not str or not key.isascii():
                raise CanonicalError("Contract keys must be ASCII strings")
            _check(key)
            _check(child, depth + 1)
        return
    raise CanonicalError("Unsupported canonical JSON type")


def canonical_bytes(value: Any) -> bytes:
    _check(value)
    return json.dumps(
        value,
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _pairs(pairs: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise CanonicalError("Duplicate JSON key")
        result[key] = value
    return result


def parse_canonical_json(raw: str | bytes) -> Any:
    # Parse floats as rejected objects; 1.0 may not quietly become the integer 1.
    def reject(_: str) -> None:
        raise CanonicalError("Floating-point JSON is not canonical")

    try:
        value = json.loads(
            raw, object_pairs_hook=_pairs, parse_float=reject, parse_constant=reject
        )
        _check(value)
        return value
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise CanonicalError("Invalid canonical JSON") from exc


def digest(purpose: str, value: Any) -> str:
    if purpose not in PURPOSES or not re.fullmatch(r"[a-z]+", purpose):
        raise CanonicalError("Unregistered hash purpose")
    return hashlib.sha256(
        b"agentic-os.hash/1\0"
        + purpose.encode("ascii")
        + b"\0"
        + canonical_bytes(value)
    ).hexdigest()


# Standalone wire implementation. No installed OS module or host ORM imports.
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker


class Wire:
    def __init__(self, path):
        self.schema = parse_canonical_json(Path(path).read_bytes())
        self.validators = {
            name: Draft202012Validator(
                {**self.schema, "$ref": "#/$defs/" + name},
                format_checker=FormatChecker(),
            )
            for name in self.schema["$defs"]
        }

    def validate(self, name, value):
        canonical_bytes(value)
        self.validators[name].validate(value)
        return value
