// Independent owned synthetic transactional host. No OS/host ORM imports.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import http from "node:http";
import { DatabaseSync } from "node:sqlite";
import { Wire, canonical, parseCanonical, digest } from "./wire.mjs";
class Failure extends Error {
  constructor(code, status = 400) {
    super(code);
    this.status = status;
    this.code = code;
  }
}
function privatePath(file, directory = false) {
  const s = fs.lstatSync(file);
  if (
    fs.realpathSync(file) !== path.resolve(file) ||
    s.uid !== process.getuid() ||
    s.mode & 0o077 ||
    !(directory ? s.isDirectory() : s.isFile())
  )
    throw Error("Explicit private owned fixture required");
}
const file = process.argv[2];
privatePath(file);
const root = path.dirname(file);
privatePath(root, true);
const cfg = parseCanonical(fs.readFileSync(file));
if (cfg.fixture !== "owned-agentic-os-effects" || cfg.language !== "node")
  throw Error("Wrong fixture");
for (const name of ["store.sqlite", "contracts.json", "controls.json"])
  privatePath(path.join(root, name));
if (
  crypto
    .createHash("sha256")
    .update(fs.readFileSync(path.join(root, "contracts.json")))
    .digest("hex") !== cfg.contractsDigest
)
  throw Error("Wire release mismatch");
if (cfg.permitOrigin !== `http://127.0.0.1:${cfg.permitPort}`)
  throw Error("Fixed loopback authority required");
const executionProfile = cfg.executionProfile;
const reviewAssurance=cfg.reviewAssurance??'local-synthetic';
if(!['local-synthetic','oidc-step-up/1'].includes(reviewAssurance) ||
   (Object.hasOwn(cfg,'reviewAssurance')&&!executionProfile)) throw Error('Explicit supported reviewed assurance required');
if (Object.hasOwn(cfg, "executionProfile") &&
    (executionProfile !== "reviewed-host-effect/1" ||
     typeof cfg.observerKey !== "string" || !/^[A-Za-z0-9_-]{43,128}$/.test(cfg.observerKey) ||
     [cfg.bridgeKey, cfg.permitKey].includes(cfg.observerKey)))
  throw Error("Unqualified reviewed execution fixture");
const delegationProfile=cfg.delegationProfile;
if (Object.hasOwn(cfg,"delegationProfile") && (delegationProfile!=="atomic-host-delegation/1" || !executionProfile || cfg.risk!=="medium"
    || typeof cfg.delegationKey!=="string" || !/^[A-Za-z0-9_-]{43,128}$/.test(cfg.delegationKey)
    || [cfg.bridgeKey,cfg.permitKey,cfg.observerKey].includes(cfg.delegationKey))) throw Error("Unqualified finite delegation fixture");
if (Object.hasOwn(cfg,"delegationKey") && !delegationProfile) throw Error("Delegation credential requires explicit profile");
const purposes = executionProfile ? ["assistant.prepare", "assistant.execute"] : ["assistant.prepare"];
const inspectionProfile = cfg.inspectionProfile;
if (Object.hasOwn(cfg, "inspectionProfile") &&
    (inspectionProfile !== "reviewed-host-inspection/1" || !executionProfile))
  throw Error("Unqualified reviewed inspection fixture");
if (inspectionProfile) purposes.push("assistant.inspect");
const wire = new Wire(path.join(root, "contracts.json")),
  schema = cfg.schema;
wire.validate("ResourceContract", schema);
if (executionProfile) {
  wire.validate("CapabilityDescriptor",cfg.descriptor);
  const d=cfg.descriptor;
  if(d.id!==cfg.capabilityRef || d.kind!=="effect" || d.riskFloor!==cfg.risk || d.guaranteeProfile!=="atomic-host-effect/1")
    throw Error("Reviewed descriptor mismatch");
} else if(Object.hasOwn(cfg,"observerKey")) throw Error("Observer credential requires qualified profile");
if (
  schema.schemaHash !==
  digest(
    "definition",
    Object.fromEntries(
      Object.entries(schema).filter(([k]) => k !== "schemaHash"),
    ),
  )
)
  throw Error("Input schema mismatch");
const instant = () => Date.now(),
  iso = (ms) => new Date(ms).toISOString(),
  clock = (s) => {
    const t = Date.parse(s);
    if (!Number.isFinite(t)) throw new Failure("INVALID");
    return t;
  };
const same = (a, b) => canonical(a) === canonical(b),
  id = () => crypto.randomUUID();
const controls = () =>
  parseCanonical(fs.readFileSync(path.join(root, "controls.json")));
const equal = (a, b) => {
  if (typeof a !== "string" || typeof b !== "string") return false;
  const x = Buffer.from(a),
    y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
function db(fn, write = false) {
  const c = new DatabaseSync(path.join(root, "store.sqlite"));
  c.exec("PRAGMA foreign_keys=ON;PRAGMA busy_timeout=2000");
  try {
    if (write) c.exec("BEGIN IMMEDIATE");
    const result = fn(c);
    if (result instanceof Promise)
      throw Error("Await inside transaction refused");
    if (write) c.exec("COMMIT");
    return result;
  } catch (e) {
    if (c.isTransaction) c.exec("ROLLBACK");
    throw e;
  } finally {
    c.close();
  }
}
function owner(s) {
  wire.validate("SubjectRef", s);
  if (Object.entries(cfg.namespace).some(([k, v]) => s[k] !== v))
    throw new Failure("DENIED", 403);
  return s.subjectId;
}
function policy(c, s, write = false, resource = null) {
  const user = owner(s),
    p = c.prepare("SELECT * FROM principals WHERE subject_id=?").get(user);
  if (!p || p.active !== 1 || p.can_read !== 1 || (write && p.can_write !== 1))
    throw new Failure("DENIED", 403);
  if (resource !== null && !parseCanonical(p.resource_ids).includes(resource))
    throw new Failure("DENIED", 403);
  return p;
}
function authority(request) {
  wire.validate('HostAuthorityRequest',request);
  const descriptor=cfg.descriptor;
  if (!descriptor || request.capabilityRef!==descriptor.id || !purposes.includes(request.purpose) )
    throw new Failure('DENIED',403);
  const p=db(c=>{
    const principal=policy(c,request.subject,request.purpose!=="assistant.inspect");
    if(request.delegationRef!==null) {
      if(!delegationProfile || request.purpose!=="assistant.execute" || !request.delegationRef.startsWith("delegation/")) throw new Failure("DENIED",403);
      const ident=request.delegationRef.slice("delegation/".length);
      const row=c.prepare('SELECT d.* FROM delegations d JOIN delegation_controls x ON x.id=d.id WHERE d.id=? AND d.owner=?').get(ident,request.subject.subjectId);
      if(!row) throw new Failure("DENIED",403);
      const delegated=parseCanonical(row.payload);
      if(!row.active || row.uses>=1 || clock(delegated.validUntil)<=instant()) throw new Failure("DENIED",403);
      for(const r of request.resourceRefs) if(!delegated.resourceBounds.some(b=>b.resourceType===r.resourceType && b.externalIds.includes(r.externalId))) throw new Failure("DENIED",403);
    }
    return principal;
  });
  const ids=parseCanonical(p.resource_ids);
  for (const r of request.resourceRefs) {
    if (!same(r.subject,request.subject) || r.providerId!==cfg.providerRef || r.contractVersion!==cfg.schema.revision
      || r.resourceType!==cfg.schema.resourceType || !ids.includes(r.externalId)) throw new Failure('DENIED',403);
  }
  const now=Date.now();
  const value={id:id(),subject:request.subject,active:true,policyGeneration:p.policy_generation,
    capabilityRefs:[descriptor.id],resourceBounds:[{resourceType:cfg.schema.resourceType,externalIds:ids,
      fieldNames:cfg.schema.fields.map(f=>f.name)}],purpose:request.purpose,checkedAt:new Date(now).toISOString(),
    validUntil:new Date(now+5000).toISOString(),assuranceRef:null,delegationRef:request.delegationRef};
  wire.validate('HostAuthority',value);return value;
}
function capabilities(request) {
  wire.validate('HostCapabilitiesRequest',request);
  if (!purposes.includes(request.purpose) || !cfg.descriptor) throw new Failure('DENIED',403);
  db(c=>policy(c,request.subject,request.purpose!=="assistant.inspect"));
  return {capabilities:[cfg.descriptor]};
}
function delegationControl(request,revoke=false) {
  if(!delegationProfile) throw new Failure("DENIED",403);
  wire.validate(revoke?"HostDelegationRevocationCommand":"HostDelegationRegistrationCommand",request);
  let d=revoke?null:request.delegation;
  const subject=revoke?request.subject:d.subject, ident=revoke?request.delegationId:d.id;
  let bound;
  if(!revoke) {
    const budget={maxStages:1,maxChildren:0,maxTokens:1,maxToolCalls:1,maxNativeJobs:0,deadlineMs:d.budget.deadlineMs};
    if(!d.active || d.revision!==1 || d.maxRisk!=="medium" || d.purpose!=="assistant.change"
      || !same(d.capabilityRefs,[cfg.capabilityRef]) || d.resourceBounds.length!==1 || !same(d.budget,budget)
      || clock(d.validFrom)>instant()+1000 || clock(d.validUntil)<=instant() || clock(d.validUntil)>clock(d.validFrom)+300000
      || d.budget.deadlineMs!==clock(d.validUntil)-clock(d.validFrom)) throw new Failure("DENIED",403);
    bound=d.resourceBounds[0];
    const names=cfg.schema.fields.map(f=>f.name);
    if(bound.resourceType!==cfg.schema.resourceType || bound.externalIds.length!==1 || !bound.fieldNames.length
      || !bound.fieldNames.every(n=>names.includes(n))) throw new Failure("DENIED",403);
  }
  db(c=>{
    policy(c,subject,true);
    const row=c.prepare('SELECT d.*,x.definition_digest FROM delegations d JOIN delegation_controls x ON x.id=d.id WHERE d.id=? AND d.owner=?').get(ident,subject.subjectId);
    if(row) {
      if(row.definition_digest!==request.definitionDigest || !revoke && !same(parseCanonical(row.payload),d)) throw new Failure("CONFLICT",409);
      d=parseCanonical(row.payload);
      if(revoke && row.active) c.prepare('UPDATE delegations SET active=0 WHERE id=?').run(ident);
    } else if(revoke) throw new Failure("DENIED",403);
    else {
      policy(c,subject,true,bound.externalIds[0]);
      c.prepare('INSERT INTO delegations VALUES (?,?,?,?,?)').run(ident,subject.subjectId,1,0,canonical(d));
      c.prepare('INSERT INTO delegation_controls VALUES (?,?)').run(ident,request.definitionDigest);
    }
  },true);
  const result={subject,delegationId:ident,delegationDigest:request.definitionDigest,providerRef:cfg.providerRef,
    expiresAt:d.validUntil,profileRef:"atomic-host-delegation/1"};
  wire.validate("HostDelegationRegistrationReceipt",result); return result;
}
function verifyStage(request) {
  const value=stage(request), resource=value.resource;
  db(c=>{
    policy(c,request.subject,true,resource.externalId);
    const row=c.prepare('SELECT * FROM resources WHERE external_id=? AND owner=?').get(resource.externalId,request.subject.subjectId);
    const before=Object.fromEntries(value.beforeFields.map(f=>[f.name,f.value]));
    if (!row || String(row.revision)!==resource.observedVersion || !same(parseCanonical(row.fields),before)) throw new Failure('STALE',409);
  });
  return value;
}

function description(s) {
  db((c) => policy(c, s, true));
  return {
    subject: s,
    schema,
    capabilityRef: cfg.capabilityRef,
    providerRef: cfg.providerRef,
    guaranteeRef: "atomic-host-effect/1",
    risk: cfg.risk,
  };
}
function fields(values) {
  const definitions = new Map(schema.fields.map((f) => [f.name, f])),
    result = Object.create(null),
    errors = [];
  for (const f of values) {
    wire.validate("FieldValue", f);
    const name = f.name,
      value = f.value,
      d = definitions.get(name);
    if (Object.hasOwn(result, name)) throw new Failure("INVALID");
    result[name] = value;
    let code = null;
    if (!d) code = "UNKNOWN_FIELD";
    else if (value === null && !d.nullable) code = "NULL_NOT_ALLOWED";
    else if (
      value !== null &&
      (typeof value !== "string" || Array.from(value).length > d.maxLength)
    )
      code = "TYPE_OR_LENGTH";
    if (code)
      errors.push({
        field: name,
        code,
        safeMessage: "Check this field against the registered input schema.",
      });
  }
  return [result, errors];
}
function validate(request) {
  wire.validate("ResourceValidationRequest", request);
  const s = request.subject,
    r = request.resourceRef;
  if (
    request.contractRef !== schema.id ||
    request.contractRevision !== schema.revision ||
    request.operation !== "update" ||
    !r ||
    !same(r.subject, s) ||
    r.resourceType !== schema.resourceType ||
    r.providerId !== cfg.providerRef ||
    r.contractVersion !== schema.revision
  )
    throw new Failure("INVALID");
  const [patch, errors] = fields(request.fields);
  if (!Object.keys(patch).length) throw new Failure("INVALID");
  return db((c) => {
    policy(c, s, true, r.externalId);
    const row = c
      .prepare("SELECT * FROM resources WHERE external_id=? AND owner=?")
      .get(r.externalId, s.subjectId);
    if (!row) throw new Failure("NOT_FOUND", 404);
    if (String(row.revision) !== r.observedVersion)
      throw new Failure("STALE", 409);
    if (errors.length)
      return {
        valid: false,
        stageRef: null,
        fieldErrors: errors,
        clarificationFields: [],
      };
    const before = parseCanonical(row.fields),
      after = { ...before, ...patch };
    if (same(before, after)) throw new Failure("NO_CHANGE");
    const created = instant(),
      stage = {
        id: id(),
        subject: s,
        resource: r,
        schema,
        operation: "update",
        beforeFields: Object.keys(before)
          .sort()
          .map((name) => ({ name, value: before[name] })),
        afterFields: Object.keys(after)
          .sort()
          .map((name) => ({ name, value: after[name] })),
        evidenceDigest: "0".repeat(64),
        createdAt: iso(created),
        expiresAt: iso(created + 600000),
      };
    stage.evidenceDigest = digest(
      "evidence",
      Object.fromEntries(
        Object.entries(stage).filter(([k]) => k !== "evidenceDigest"),
      ),
    );
    wire.validate("HostChangeStage", stage);
    c.prepare("INSERT INTO stages VALUES (?,?,?,?,?)").run(
      stage.id,
      s.subjectId,
      r.externalId,
      row.revision,
      canonical(stage),
    );
    return {
      valid: true,
      stageRef: "stage/" + stage.id,
      fieldErrors: [],
      clarificationFields: [],
    };
  }, true);
}
function stage(request) {
  wire.validate("HostStageRequest", request);
  return db((c) => {
    const row = c
      .prepare("SELECT * FROM stages WHERE id=? AND owner=?")
      .get(request.stageId, owner(request.subject));
    if (!row) throw new Failure("NOT_FOUND", 404);
    policy(c, request.subject, true, row.resource_id);
    const value = parseCanonical(row.payload);
    if (clock(value.expiresAt) <= instant()) throw new Failure("EXPIRED", 409);
    return value;
  });
}
function uuid5(namespace, name) {
  const bytes = crypto
    .createHash("sha1")
    .update(Buffer.from(namespace.replaceAll("-", ""), "hex"))
    .update(name, "utf8")
    .digest()
    .subarray(0, 16);
  bytes[6] = (bytes[6] & 0x0f) | 0x50;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const h = bytes.toString("hex");
  return (
    h.slice(0, 8) +
    "-" +
    h.slice(8, 12) +
    "-" +
    h.slice(12, 16) +
    "-" +
    h.slice(16, 20) +
    "-" +
    h.slice(20)
  );
}
function receipt(r, status, resources = []) {
  return wire.validate("EffectReceipt", {
    id: uuid5(r.invocationId, "host.receipt"),
    subject: r.subject,
    providerRef: cfg.providerRef,
    invocationId: r.invocationId,
    requestDigest: r.requestDigest,
    status,
    version: 1,
    observedAt: iso(instant()),
    affectedResources: resources,
    auditRefs: [],
    evidenceRefs: [],
    attestationProfile: "atomic-host-effect/1",
  });
}
function prior(c, r) {
  const row = c
    .prepare("SELECT * FROM invocations WHERE id=?")
    .get(r.invocationId);
  if (
    row &&
    (row.owner !== r.subject.subjectId || row.digest !== r.requestDigest)
  )
    throw new Failure("CONFLICT", 409);
  return row;
}
function lookup(request, cancel = false) {
  wire.validate("EffectLookupRequest", request);
  if (request.providerRef !== cfg.providerRef) throw new Failure("DENIED", 403);
  return db((c) => {
    owner(request.subject);
    if (
      !c
        .prepare("SELECT subject_id FROM principals WHERE subject_id=?")
        .get(request.subject.subjectId)
    )
      throw new Failure("DENIED", 403);
    const row = prior(c, request);
    if (executionProfile) {
      policy(c, request.subject, cancel);
      if (row) for (const resource of parseCanonical(row.receipt).affectedResources)
        policy(c, request.subject, false, resource.externalId);
    }
    if (row) return parseCanonical(row.receipt);
    const value = receipt(
      request,
      cancel ? "CONFIRMED_NOT_APPLIED" : "UNKNOWN",
    );
    if (cancel)
      c.prepare("INSERT INTO invocations VALUES (?,?,?,?,?,?)").run(
        request.invocationId,
        request.subject.subjectId,
        request.requestDigest,
        "CONFIRMED_NOT_APPLIED",
        canonical(value),
        null,
      );
    return value;
  }, cancel);
}
function observe(request) {
  if (executionProfile !== "reviewed-host-effect/1") throw new Failure("DENIED", 403);
  wire.validate("EffectLookupRequest", request);
  owner(request.subject);
  if (request.providerRef !== cfg.providerRef) throw new Failure("DENIED", 403);
  const original = db(c => {
    const row = prior(c, request);
    return row ? parseCanonical(row.receipt) : null;
  });
  const result = {subject:request.subject, providerRef:request.providerRef,
    invocationId:request.invocationId, requestDigest:request.requestDigest,
    receiptId:original?.id ?? null, status:original?.status ?? "UNKNOWN",
    version:original?.version ?? null, observedAt:new Date().toISOString(),
    attestationProfile:"atomic-host-receipt-observation/1"};
  // Explicit owned synthetic response fault; stored terminal proof and its
  // integrity trigger remain intact.
  if (controls().regressReceiptVersion === true && result.version !== null && result.version > 1)
    result.version -= 1;
  wire.validate("ReceiptObservation", result);
  return result;
}
function bind(envelope, st) {
  const p = envelope.proposal,
    r = envelope.request,
    intent = p.intent,
    s = r.subject,
    pd = digest(
      "proposal",
      Object.fromEntries(Object.entries(p).filter(([k]) => k !== "digest")),
    ),
    rd = digest("command", {
      subject: s,
      invocationId: r.invocationId,
      proposalDigest: p.digest,
      capabilityRef: envelope.capabilityRef,
    });
  if (
    pd !== p.digest ||
    rd !== r.requestDigest ||
    !same(p.subject, s) ||
    !same(intent.subject, s) ||
    r.proposalRef !== "proposal/" + p.id ||
    r.proposalRevision !== p.revision ||
    envelope.capabilityRef !== cfg.capabilityRef ||
    p.providerRef !== cfg.providerRef ||
    p.guaranteeRef !== "atomic-host-effect/1" ||
    p.risk !== cfg.risk ||
    p.requiredAssurance !== reviewAssurance ||
    p.evidenceDigest !== st.evidenceDigest ||
    !same(st.subject, s) ||
    !same(st.schema, schema) ||
    !same(p.expectedVersions, [st.resource]) ||
    !same(intent.targets, [st.resource]) ||
    intent.contractRef !== schema.id ||
    intent.contractVersion !== schema.revision ||
    intent.operation !== "update" ||
    intent.destinationRefs.length ||
    intent.scopeRef !== cfg.scopeRef ||
    !same(intent.evidenceRefs, ["stage/" + st.id]) ||
    clock(p.expiresAt) > clock(st.expiresAt)
  )
    throw new Failure("BINDING", 403);
  const before = Object.fromEntries(st.beforeFields.map((f) => [f.name, f])),
    after = Object.fromEntries(st.afterFields.map((f) => [f.name, f])),
    changed = [...new Set([...Object.keys(before), ...Object.keys(after)])]
      .sort()
      .filter((k) => !same(before[k] ?? null, after[k] ?? null));
  if (
    !changed.length ||
    !same(
      p.diff,
      changed.map((name) => ({
        name,
        before: before[name] ?? null,
        after: after[name] ?? null,
      })),
    ) ||
    !same(
      intent.fields,
      changed.map((k) => after[k]),
    )
  )
    throw new Failure("BINDING", 403);
  return rd;
}
async function permit(envelope) {
  const r = envelope.request,
    p = envelope.proposal,
    request = {
      subject: r.subject,
      permitRef: envelope.permitRef,
      invocationId: r.invocationId,
      requestDigest: r.requestDigest,
      proposalDigest: p.digest,
      capabilityRef: envelope.capabilityRef,
    };
  const response = await fetch(
    cfg.permitOrigin + "/os/internal/effects/introspect",
    {
      method: "POST",
      redirect: "error",
      signal: AbortSignal.timeout(2000),
      headers: {
        Authorization: "Bearer " + cfg.permitKey,
        "Content-Type": "application/json",
        "Accept-Encoding": "identity",
      },
      body: canonical(request),
    },
  );
  if (
    response.status !== 200 ||
    response.headers.get("content-type")?.split(";")[0] !==
      "application/json" ||
    (response.headers.get("content-encoding") ?? "identity") !== "identity"
  )
    throw new Failure("UNAVAILABLE", 503);
  const reader = response.body.getReader();
  let size = 0,
    chunks = [];
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > 65536) throw new Failure("UNAVAILABLE", 503);
      chunks.push(value);
    }
  } finally {
    await reader.cancel();
  }
  const value = wire.validate(
    "EffectPermitStatus",
    parseCanonical(Buffer.concat(chunks)),
  );
  if (
    !value.valid ||
    [
      "subject",
      "invocationId",
      "requestDigest",
      "proposalDigest",
      "capabilityRef",
    ].some((k) => !same(value[k], request[k])) ||
    value.authorityRef !== r.authorityRef ||
    !same(value.authorization, r.authorization) ||
    value.assuranceRef !== (delegationProfile && r.authorization.kind==="bounded_delegation" ? "bounded-delegation/1" : reviewAssurance) ||
    value.risk !== p.risk ||
    clock(value.checkedAt) < instant() - 5000 ||
    clock(value.checkedAt) > instant() + 5000 ||
    clock(value.expiresAt) <= instant() ||
    clock(value.expiresAt) > Math.min(instant() + 60000, clock(p.expiresAt))
  )
    throw new Failure("DENIED", 403);
  if(delegationProfile && r.authorization.kind==="bounded_delegation" && (clock(value.checkedAt)>instant()+1000 || clock(value.expiresAt)>clock(value.checkedAt)+5000)) throw new Failure("DENIED",403);
  const auth = value.authorization,
    d = auth.kind === "review_decision" ? auth.decision : auth.delegation;
  if (auth.kind === "review_decision") {
    if (
      !same(d.subject, r.subject) ||
      d.proposalId !== p.id ||
      d.proposalRevision !== p.revision ||
      d.digest !== p.digest ||
      d.assuranceRef !== reviewAssurance ||
      clock(d.expiresAt) <= instant() ||
      clock(d.expiresAt) > clock(p.expiresAt) ||
      clock(value.expiresAt) > clock(d.expiresAt)
    )
      throw new Failure("DENIED", 403);
  } else {
    const names = p.intent.fields.map((f) => f.name),
      resource = p.expectedVersions[0];
    if (
      p.risk !== "medium" ||
      d.maxRisk !== "medium" ||
      !d.active ||
      !same(d.subject, r.subject) ||
      !d.capabilityRefs.includes(cfg.capabilityRef) ||
      d.purpose !== "assistant.change" ||
      clock(d.validFrom) > instant() ||
      clock(d.validUntil) <= instant() ||
      clock(value.expiresAt) > clock(d.validUntil) ||
      !d.resourceBounds.some(
        (b) =>
          b.resourceType === resource.resourceType &&
          b.externalIds.includes(resource.externalId) &&
          names.every((n) => b.fieldNames.includes(n)),
      )
    )
      throw new Failure("DENIED", 403);
  }
  return value;
}
async function execute(envelope) {
  wire.validate("HostEffectEnvelope", envelope);
  const r = envelope.request,
    s = r.subject;
  const existing = db((c) => {
    policy(c, s);
    return prior(c, r);
  });
  if (existing) return parseCanonical(existing.receipt);
  const st = stage({ subject: s, stageId: envelope.stageId });
  bind(envelope, st);
  const grant = await permit(envelope),
    accepted = performance.now();
  const duplicate = db((c) => {
    const priorRow = prior(c, r);
    if (priorRow) return parseCanonical(priorRow.receipt);
    const p = policy(c, s, true, st.resource.externalId);
    if (p.policy_generation !== grant.policyGeneration)
      throw new Failure("DENIED", 403);
    const value = receipt(r, "PENDING");
    c.prepare("INSERT INTO invocations VALUES (?,?,?,?,?,?)").run(
      r.invocationId,
      s.subjectId,
      r.requestDigest,
      "PENDING",
      canonical(value),
      canonical(envelope),
    );
    return null;
  }, true);
  if (duplicate) return duplicate;
  const until = performance.now() + 3000;
  while (controls().holdAccepted && performance.now() < until)
    await new Promise((resolve) => setTimeout(resolve, 20));
  const result = db((c) => {
    const old = prior(c, r);
    if (old.state !== "PENDING") return parseCanonical(old.receipt);
    const p = policy(c, s, true, st.resource.externalId),
      resource = c
        .prepare("SELECT * FROM resources WHERE external_id=? AND owner=?")
        .get(st.resource.externalId, s.subjectId);
    let value;
    if (
      p.policy_generation !== grant.policyGeneration ||
      performance.now() - accepted > 5000 ||
      clock(grant.expiresAt) <= instant() ||
      clock(st.expiresAt) <= instant() ||
      !resource ||
      String(resource.revision) !== st.resource.observedVersion
    )
      value = receipt(r, "REJECTED_BEFORE_EFFECT");
    else {
      if (grant.authorization.kind === "bounded_delegation") {
        const d = grant.authorization.delegation,
          row = c
            .prepare("SELECT * FROM delegations WHERE id=? AND owner=?")
            .get(d.id, s.subjectId);
        if (
          !row ||
          row.active !== 1 ||
          !same(parseCanonical(row.payload), d) ||
          row.uses >= d.budget.maxToolCalls ||
          clock(d.validUntil) <= instant()
        )
          value = receipt(r, "REJECTED_BEFORE_EFFECT");
        else
          c.prepare("UPDATE delegations SET uses=uses+1 WHERE id=?").run(d.id);
      }
      if (!value) {
        const after = Object.fromEntries(
            st.afterFields.map((f) => [f.name, f.value]),
          ),
          revision = resource.revision + 1;
        c.prepare(
          "UPDATE resources SET fields=?,revision=? WHERE external_id=? AND owner=?",
        ).run(canonical(after), revision, st.resource.externalId, s.subjectId);
        const refs = [{ ...st.resource, observedVersion: String(revision) }];
        value = receipt(r, "COMMITTED", refs);
        const audit = id(),
          event = id();
        value.auditRefs = ["audit/" + audit];
        value.evidenceRefs = ["stage/" + st.id];
        c.prepare("INSERT INTO audit VALUES (?,?,?,?)").run(
          audit,
          r.invocationId,
          s.subjectId,
          canonical({ before: st.beforeFields, after: st.afterFields }),
        );
        c.prepare("INSERT INTO outbox VALUES (?,?,?)").run(
          event,
          r.invocationId,
          canonical({ resource: refs[0], receiptId: value.id }),
        );
      }
    }
    if (executionProfile) {
      // Reviewed observers may have seen PENDING. Advance its revision with
      // the terminal outcome while preserving the original receipt identity.
      const previous = parseCanonical(old.receipt);
      if (previous.status !== "PENDING" || previous.id !== value.id)
        throw new Failure("BINDING", 403);
      value.version = previous.version + 1;
    }
    wire.validate("EffectReceipt", value);
    c.prepare("UPDATE invocations SET state=?,receipt=? WHERE id=?").run(
      value.status,
      canonical(value),
      r.invocationId,
    );
    if (controls().failCommit)
      c.exec("INSERT INTO missing_failure_injection_table VALUES (1)");
    return value;
  }, true);
  if (controls().loseAck) throw new Failure("ACK_LOST", 503);
  return result;
}
http
  .createServer(async (req, res) => {
    try {
      if (req.method === "GET" && req.url === "/health") {
        res.setHeader("Content-Type", "application/json");
        res.end(
          canonical({
            fixture: "transactional-node",
            assurance: "local-synthetic",
          }),
        );
        return;
      }
      const controlling=["/host-bridge/v1/delegations/register","/host-bridge/v1/delegations/revoke"].includes(req.url);
      const observing = req.url === "/host-bridge/v1/effects/observe";
      const expected = controlling && delegationProfile ? cfg.delegationKey : (observing && executionProfile ? cfg.observerKey : cfg.bridgeKey);
      if (
        req.method !== "POST" || (controlling && !delegationProfile) || (observing && !executionProfile) ||
        !equal(req.headers.authorization, "Bearer " + expected)
      )
        throw new Failure("DENIED", 401);
      const chunks = [];
      let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 65536) throw new Failure("INVALID", 413);
        chunks.push(chunk);
      }
      const body = (() => {
        try {
          return parseCanonical(Buffer.concat(chunks));
        } catch {
          throw new Failure("INVALID");
        }
      })();
      let value;
      switch (req.url) {
        case "/host-bridge/v1/delegations/register":
          value=delegationControl(body); break;
        case "/host-bridge/v1/delegations/revoke":
          value=delegationControl(body,true); break;
        case "/host-bridge/v1/resources/describe":
          wire.validate("ResourceDescribeRequest", body);
          if (
            body.contractRef !== schema.id ||
            body.contractRevision !== schema.revision
          )
            throw new Failure("INVALID");
          value = description(body.subject);
          break;
        case "/host-bridge/v1/resources/validate":
          value = validate(body);
          break;
        case "/host-bridge/v1/resources/stage":
          value = stage(body);
          break;
        case "/host-bridge/v1/resources/verify":
          value = verifyStage(body);
          break;
        case "/host-bridge/v1/authority/check":
          value = authority(body);
          break;
        case "/host-bridge/v1/capabilities":
          value = capabilities(body);
          break;
        case "/host-bridge/v1/effects/observe":
          value = observe(body);
          break;
        case "/host-bridge/v1/effects/execute":
          value = await execute(body);
          break;
        case "/host-bridge/v1/effects/lookup":
          value = lookup(body);
          break;
        case "/host-bridge/v1/effects/cancel":
          value = lookup(body, true);
          break;
        default:
          throw new Failure("NOT_FOUND", 404);
      }
      res.setHeader("Content-Type", "application/json");
      res.setHeader("Cache-Control", "no-store");
      res.end(canonical(value));
    } catch (e) {
      res.statusCode =
        e instanceof Failure
          ? e.status
          : e.message === "INVALID" || e.message?.startsWith("Invalid")
            ? 400
            : 503;
      res.setHeader("Content-Type", "application/json");
      res.end(
        canonical({
          code:
            e instanceof Failure
              ? e.code
              : res.statusCode === 400
                ? "INVALID"
                : "UNAVAILABLE",
        }),
      );
    }
  })
  .listen(cfg.port, "127.0.0.1");
