"""Independent OS. Host applications communicate over versioned remote ports."""

__version__ = "0.1.0"
