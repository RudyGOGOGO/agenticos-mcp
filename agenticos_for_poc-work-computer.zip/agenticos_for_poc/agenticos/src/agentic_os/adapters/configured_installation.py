"""Declarative installation assembly over the existing local and AWS ports.

Configuration contains immutable references, never credential material. Loading
or assembling it creates no database, key, registration, policy or cloud resource.
"""
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
import re
from uuid import UUID

from agentic_os.adapters.local.files import OwnershipError,private_read
from agentic_os.contracts.canonical import parse_canonical_json

SCHEMA='agent-installation-configuration/1'


def closed(value,fields):
    if type(value) is not dict or set(value)!=set(fields):raise ValueError()


def canonical_file(value):
    if type(value) is not str:raise ValueError()
    path=Path(value)
    if not path.is_absolute() or path.resolve()!=path:raise ValueError()
    return path


def installation_configuration(value):
    """Validate the complete handoff before creating a client or opening SQL."""
    try:
        value=deepcopy(value)
        if type(value) is not dict or value.get('schema')!=SCHEMA:raise ValueError()
        provider=value.get('provider')
        if provider not in {'owned-local','aws-eks'}:raise ValueError()
        closed(value,{'schema','provider','manifest'}|({'aws'} if provider=='aws-eks' else set()))
        manifest=canonical_file(value['manifest'])
        if manifest.name!='manifest.json':raise ValueError()
        value['manifest']=manifest
        if provider=='owned-local':return value
        from agentic_os.adapters.aws.backend import SecretPin
        from agentic_os.adapters.aws.workload import role_arn
        aws=value['aws'];closed(aws,{'account','region','role','token_root','postgres','operator','credentials'}
            |({'stores'} if 'stores' in aws else set())|({'storage_profile'} if 'storage_profile' in aws else set())
            |({'private_files'} if 'private_files' in aws else set())|({'control_binding'} if 'control_binding' in aws else set())
            |({'control_profile'} if 'control_profile' in aws else set()))
        if 'private_files' in aws:
            from .local.files import AWS_SHARED_FILES
            if aws['private_files']!=AWS_SHARED_FILES:raise ValueError()
        if 'storage_profile' in aws:
            from .postgres.profiles import checked_profile
            checked_profile(aws['storage_profile'])
        if 'control_profile' in aws:
            from .postgres.profiles import RDS_EXACT
            if (aws['control_profile']!='poc-direct-control/1' or aws['role']!='core'
                    or aws.get('storage_profile')!=RDS_EXACT or 'stores' not in aws):raise ValueError()
        if (type(aws['region']) is not str or re.fullmatch(r'[a-z]{2}(?:-[a-z]+)+-[0-9]+',aws['region']) is None
                or aws['region'].startswith(('cn-','us-gov-','us-iso'))
                or aws['role'] not in {'core','native'}):raise ValueError()
        role_arn(UUID(int=0),aws['account'],aws['role'])
        aws['token_root']=canonical_file(aws['token_root'])
        def secret(pin):
            closed(pin,{'arn','version'})
            return SecretPin(**pin)
        def postgres(value):
            closed(value,{'host','port','database','user','ca','ca_sha256','password'})
            value['ca']=canonical_file(value['ca'])
            if (type(value['host']) is not str or type(value['port']) is not int or not 1<=value['port']<=65535
                    or any(type(value[field]) is not str or not value[field] for field in ('database','user'))
                    or type(value['ca_sha256']) is not str or re.fullmatch(r'[a-f0-9]{64}',value['ca_sha256']) is None):raise ValueError()
            value['password']=secret(value['password'])
        postgres(aws['postgres'])
        if 'stores' in aws:
            if aws['role']!='core':raise ValueError()
            closed(aws['stores'],{'retrieval','knowledge','knowledge_public','knowledge_operator'})
            for store in aws['stores'].values():postgres(store)
            pins=[v['password'] for v in aws['stores'].values()]
            if len({(p.arn,p.version) for p in pins})!=4:raise ValueError()
        if 'private_files' in aws:
            common=[aws['postgres'],*aws.get('stores',{}).values()]
            if any(not settings['ca'].is_relative_to(manifest.parent) for settings in common):
                raise ValueError('Shared RDS CA must be available through the installation mount')
        operator=aws['operator'];closed(operator,{'pin','generation'})
        operator['pin']=secret(operator['pin'])
        if type(operator['generation']) is not int or not 1<=operator['generation']<=2**53-1:raise ValueError()
        if type(aws['credentials']) is not list:raise ValueError()
        pins={}
        for credential in aws['credentials']:
            closed(credential,{'application_id','reference','pin'})
            app=UUID(credential['application_id']);reference=credential['reference']
            if (str(app)!=credential['application_id'] or type(reference) is not str or not reference
                    or (app,reference) in pins):raise ValueError()
            pins[(app,reference)]=secret(credential['pin'])
        aws['credentials']=pins
        if 'control_binding' in aws:
            binding=aws['control_binding']
            if (aws['role']!='native' or type(binding) is not dict
                    or binding.get('aws',{}).get('role')!='core'):raise ValueError()
            core=installation_configuration(binding)
            if core['provider']!='aws-eks' or core['manifest']!=manifest:raise ValueError()
            if 'control_profile' in core['aws']:raise ValueError('Direct POC has no native control binding')
            for field in ('account','region','postgres','operator','storage_profile','private_files'):
                if aws.get(field)!=core['aws'].get(field):raise ValueError()
            if any(core['aws']['credentials'].get(key)!=pin for key,pin in pins.items()):raise ValueError()
        elif aws['role']=='native' and 'private_files' in aws:
            raise ValueError('Shared native role requires its exact certified Core binding')
        return value
    except Exception:raise OwnershipError('Invalid installation configuration') from None


def load_installation_configuration(path):
    try:
        path=canonical_file(str(path))
        value=parse_canonical_json(private_read(path,65536))
        installation_configuration(value)
        return value
    except Exception:raise OwnershipError('Installation configuration unavailable') from None


@contextmanager
def configured_installation(document,*,preparing_recovery=False,key_generation=None,lambda_session=None):
    with installation_file_context(document):
        with _configured_installation(document,preparing_recovery=preparing_recovery,
                key_generation=key_generation,lambda_session=lambda_session) as ports:
            yield ports


@contextmanager
def installation_file_context(document):
    """One explicit shared owner; no alternate key/gate copies or permission repair."""
    value=installation_configuration(document)
    if value['provider']=='aws-eks' and 'private_files' in value['aws']:
        import os
        from .local.files import aws_shared_private_files
        expected=0 if value['aws']['role']=='native' else 65534
        if os.getuid()!=expected:raise OwnershipError('AWS service process differs from its declared private-owner role')
        with aws_shared_private_files(value['manifest'].parent):yield
    else:yield


@contextmanager
def _configured_installation(document,*,preparing_recovery=False,key_generation=None,lambda_session=None):
    """Own SDK clients outside the caller's control-store/runtime lifespan."""
    value=installation_configuration(document)
    if lambda_session is not None:
        from agentic_os.adapters.aws.lambda_identity import AWSLambdaSession
        if (type(lambda_session) is not AWSLambdaSession or value['provider']!='aws-eks'
                or value['aws']['role']!='core' or preparing_recovery or key_generation is not None):
            raise OwnershipError('One explicit Lambda runtime session required')
    if type(preparing_recovery) is not bool or preparing_recovery and value['provider']!='aws-eks':
        raise OwnershipError('Explicit managed recovery preparation required')
    if key_generation is not None and (type(key_generation) is not int or key_generation<1
            or value['provider']!='aws-eks' or preparing_recovery):
        raise OwnershipError('Exact managed key inspection generation required')
    from agentic_os.adapters.local.ownership import load_manifest
    ownership=load_manifest(value['manifest'])
    root=Path(ownership['root']);installation=UUID(ownership['installationId'])
    if value['manifest']!=root/'manifest.json':raise OwnershipError('Installation configuration root differs')
    if value['provider']=='owned-local':
        from agentic_os.adapters.local.installation import owned_installation_ports
        yield owned_installation_ports(value['manifest'])
        return
    from agentic_os.adapters.kubernetes.projected_token import ProjectedTokenReader
    from agentic_os.adapters.aws.workload import AWSWebIdentitySession
    from agentic_os.adapters.aws.backend import (AWSSecrets,AWSHostCredentials,AWSOperator,RDSControl,
        RDSComponent,aws_component_ports,aws_installation_ports,secrets_client)
    aws=value['aws']
    if lambda_session is not None:
        if not lambda_session.matches(installation,aws['account'],aws['region']):
            raise OwnershipError('Lambda runtime belongs to another installation')
        session=lambda_session
    else:
        token=ProjectedTokenReader(aws['token_root'])
        session=AWSWebIdentitySession(installation_id=installation,account=aws['account'],region=aws['region'],
            role=aws['role'],token_provider=token.read)
    try:
        secrets=AWSSecrets(secrets_client(session,aws['region']),region=aws['region'],account=aws['account'],installation_id=installation)
        postgres=dict(aws['postgres']);password=postgres.pop('password')
        from .postgres.profiles import LEGACY_RDS
        storage_profile=aws.get('storage_profile',LEGACY_RDS)
        control=RDSControl(secrets,password,storage_profile=storage_profile,**postgres)
        credentials=AWSHostCredentials(secrets,aws['credentials'])
        operator=AWSOperator(secrets,aws['operator']['pin'],generation=aws['operator']['generation'])
        components=None
        if 'stores' in aws:
            stores={}
            for key,(component,role) in dict(retrieval=('retrieval','runtime'),knowledge=('knowledge','runtime'),
                    knowledge_public=('knowledge','public'),knowledge_operator=('knowledge','migrator')).items():
                settings=dict(aws['stores'][key]);password=settings.pop('password')
                stores[key]=RDSComponent(secrets,password,component=component,role=role,storage_profile=storage_profile,**settings)
            components=aws_component_ports(root=root,postgres=control,stores=stores)
        guard=None
        if ownership['profile']=='aws-eks/1':
            from agentic_os.adapters.aws.readiness import InitialControlRelease,installation_digest
            # Native has its own workload identity and reduced ports. Its
            # explicitly checked Core configuration names the single existing
            # release; never mint another gate or normalize arbitrary roles.
            binding=document['aws'].get('control_binding',document)
            if aws.get('control_profile')=='poc-direct-control/1':
                from agentic_os.adapters.poc.direct_readiness import DirectControlRelease
                guard=DirectControlRelease(value['manifest'],installation_digest(binding))
            else:guard=InitialControlRelease(value['manifest'],installation_digest(binding))
        yield aws_installation_ports(root=root,postgres=control,credentials=credentials,operator=operator,
            transaction_guard=guard,components=components,preparing_recovery=preparing_recovery,
            **({} if key_generation is None else dict(key_generation=key_generation)))
    finally:
        if lambda_session is None:session.close()
