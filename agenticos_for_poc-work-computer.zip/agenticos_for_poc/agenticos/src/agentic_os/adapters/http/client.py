"""Bounded remote JSON with no redirects, cookies, proxy discovery or raw errors."""
import asyncio
import httpx
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from .endpoint import reviewed_http_endpoint
from .circuit import AvailabilityCircuit
from .tls import reviewed_tls_context


class RemoteJSON:
    # Fixed per-adapter routes; requests and constructors cannot select them.
    allowed_routes = frozenset({"/sessions/check","/authority/check","/capabilities","/credentials/issue",
                         "/resources/validate","/resources/describe","/resources/stage","/resources/verify","/evidence/resolve","/effects/execute","/effects/lookup","/effects/cancel"})

    def __init__(self, endpoint, credential, timeout=3, max_bytes=1048576,*,network='owned-local-http/1',ca_file=None,ca_sha256=None):
        self.endpoint=reviewed_http_endpoint(endpoint,network)
        if self.endpoint.endswith('/'):raise OSErrorCode('INVALID')
        self.credential=credential
        self.tls=reviewed_tls_context(network,ca_file=ca_file,ca_sha256=ca_sha256)
        self.timeout=min(timeout,45)
        self.max_bytes=min(max_bytes,1048576)
        self.bulkhead=asyncio.Semaphore(4)
        self.circuit=AvailabilityCircuit()

    async def post(self, route, value, result_contract):
        if route not in self.allowed_routes:
            raise OSErrorCode("DENIED")
        try:
            payload=canonical_bytes(value)
            async with asyncio.timeout(self.timeout) as deadline:
                async with self.bulkhead:
                    with self.circuit.call(timed_out=deadline.expired):
                        async with httpx.AsyncClient(verify=self.tls,
                                trust_env=False, follow_redirects=False, timeout=self.timeout) as client:
                            async with client.stream("POST",self.endpoint+route,content=payload,headers={
                                "Authorization":"Bearer "+self.credential,"Content-Type":"application/json",
                                "Accept-Encoding":"identity"}) as response:
                                if response.status_code in {401,403}:
                                    raise OSErrorCode("DENIED")
                                if response.status_code==409:
                                    raise OSErrorCode("CONFLICT")
                                if response.status_code in {400,422}:
                                    raise OSErrorCode("INVALID")
                                if response.status_code!=200:
                                    raise OSErrorCode("UNAVAILABLE")
                                if not response.headers.get("content-type","").startswith("application/json"):
                                    raise OSErrorCode("UNAVAILABLE")
                                if response.headers.get('content-encoding','identity')!='identity':
                                    raise OSErrorCode('UNAVAILABLE')
                                output=bytearray()
                                async for chunk in response.aiter_bytes():
                                    output.extend(chunk)
                                    if len(output)>self.max_bytes:
                                        raise OSErrorCode("UNAVAILABLE")
                        result=parse_canonical_json(bytes(output))
                        validate_contract(result_contract,result)
                        return result
        except OSErrorCode:
            raise
        except Exception:
            raise OSErrorCode("UNAVAILABLE") from None
