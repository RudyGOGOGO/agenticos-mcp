"""Reviewed endpoint refs only. Local profile uses literal loopback, no DNS."""
from urllib.parse import urlsplit
import re
import httpx2
from agentic_os.errors import OSErrorCode


def reviewed_http_endpoint(url,network,*,origin_only=False):
    """Explicit operator-reviewed destination; never infer a network profile."""
    if network=='owned-local-http/1':return local_endpoint(url,origin_only=origin_only)
    if network!='web-pki/1':raise OSErrorCode('INVALID')
    try:
        parsed=urlsplit(url)
        if (type(url) is not str or parsed.scheme!='https' or not parsed.hostname
                or not re.fullmatch(r'[a-z0-9.-]+\.[a-z][a-z0-9-]*',parsed.hostname)
                or parsed.username or parsed.password or parsed.query or parsed.fragment or '%' in url or '\\' in url
                or any(part in {'.','..'} for part in parsed.path.split('/'))
                or origin_only and parsed.path or str(httpx2.URL(url))!=url):raise ValueError()
        return url
    except Exception:raise OSErrorCode('INVALID') from None


def reviewed_parent_origin(url,network):
    if network=='owned-local-http/1':return local_parent_origin(url)
    return reviewed_http_endpoint(url,network,origin_only=True)


def local_endpoint(url, *, origin_only=False):
    try:
        parsed=urlsplit(url)
        if (type(url) is not str or parsed.scheme!="http" or parsed.hostname!="127.0.0.1"
                or parsed.username or parsed.password or not parsed.port or not 1024<=parsed.port<=65535
                or parsed.query or parsed.fragment or "\\" in url or "%" in url
                or any(part in {".",".."} for part in parsed.path.split("/"))
                or origin_only and parsed.path):
            raise ValueError()
        normalized=f"http://127.0.0.1:{parsed.port}"+parsed.path
        if normalized!=url or parsed.path.endswith("/"):
            raise ValueError()
        return url
    except Exception:
        raise OSErrorCode("INVALID") from None


def local_parent_origin(url):
    """Registered browser parent only; never a server network destination."""
    if type(url) is str and url.startswith('http://127.0.0.1:'):
        return local_endpoint(url,origin_only=True)
    try:
        parsed=urlsplit(url)
        if (type(url) is not str or parsed.scheme!='http' or parsed.hostname!='localhost'
                or parsed.username or parsed.password or not parsed.port or not 1024<=parsed.port<=65535
                or parsed.path or parsed.query or parsed.fragment or url!=f'http://localhost:{parsed.port}'):
            raise ValueError()
        return url
    except Exception:
        raise OSErrorCode('INVALID') from None
