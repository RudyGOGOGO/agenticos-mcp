"""Registered source-only observations, without sessions or resource grants."""
from agentic_os.adapters.http.client import RemoteJSON
from agentic_os.adapters.http.learning_accounts import LearningHostBinding
from agentic_os.contracts.canonical import canonical_bytes, digest
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from datetime import timedelta
from agentic_os.identity.context import fresh, timestamp, utcnow

PROFILE = "OSPersonalSourceValidity/1"
ROUTE = "/learning/sources/check"


def source_host_binding(bundle):
    validate_contract("HostRegistration", bundle)
    app = bundle["application"]
    matches = [c for c in bundle["connectors"] if c["authorityProfile"] == PROFILE]
    endpoints = [e for e in bundle["endpoints"] if e["id"] == app["bridgeRef"]]
    if len(matches) != 1 or len(endpoints) != 1:
        raise OSErrorCode("PROFILE_DISABLED")
    c = matches[0]
    if (not app["active"] or c["id"] not in app["connectorRefs"]
            or c["transport"] != "host-bridge" or c["protocolProfile"] != "host-bridge/1"
            or c["endpointRef"] != app["bridgeRef"] or c["credentialRef"] != app["credentialRef"]
            or c["capabilityRefs"] or c["timeoutMs"] != 3000 or c["maxResponseBytes"] != 4096
            or c["conformance"] != "qualified" or endpoints[0]["purpose"] != "host-bridge"
            or any(not v["currentAuthority"] or not v["liveRevocation"]
                   for v in [app["guarantees"], c["guarantees"]])
            or any(cap["connectorRef"] == c["id"] for cap in bundle["capabilities"])):
        raise OSErrorCode("PROFILE_DISABLED")
    return LearningHostBinding(endpoints[0]["url"], c["credentialRef"], app["revision"], app["generation"])


class SourceJSON(RemoteJSON):
    allowed_routes = frozenset({ROUTE})


class RemotePersonalSource:
    def __init__(self, binding, credential):
        self.client = SourceJSON(binding.endpoint, credential, max_bytes=4096)

    async def check(self, request):
        validate_contract("HostPersonalSourceRequest", request)
        if len(canonical_bytes(request)) > 65536:
            raise OSErrorCode("CAPACITY")
        value = await self.client.post(ROUTE, request, "HostPersonalSourceState")
        fresh(value, subject=request["subject"])
        if (value["purpose"] != PROFILE or value["requestDigest"] != digest("verification", request)
                or not utcnow()-timedelta(seconds=3) <= timestamp(value["checkedAt"]) <= utcnow()+timedelta(seconds=1)
                or not 0 < (timestamp(value["validUntil"])-timestamp(value["checkedAt"])).total_seconds() <= 3):
            raise OSErrorCode("DENIED")
        return value
