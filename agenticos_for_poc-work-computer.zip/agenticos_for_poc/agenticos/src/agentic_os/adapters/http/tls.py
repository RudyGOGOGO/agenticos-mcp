"""Fixed public trust settings; local adapters still admit literal HTTP only."""
import ssl
import hashlib
from pathlib import Path
import re
import certifi

# Match HTTPX's trust_env=False defaults once, before request processing.
# This contains public CA certificates, never sessions, credentials or authority.
# Every request still creates and closes its own HTTP client/connection state.
LOCAL_HTTP_TLS_CONTEXT = ssl.create_default_context(cafile=certifi.where())


def reviewed_tls_context(network,*,ca_file=None,ca_sha256=None):
    """Operator-pinned private trust; no ambient roots or disabled name checks."""
    if ca_file is None and ca_sha256 is None:return LOCAL_HTTP_TLS_CONTEXT
    if (network!='web-pki/1' or not isinstance(ca_file,Path) or not ca_file.is_absolute()
            or re.fullmatch('[a-f0-9]{64}',ca_sha256 or '') is None):
        raise ValueError('Private CA requires explicit HTTPS profile, absolute file and SHA256')
    from agentic_os.distribution import read_regular
    raw=read_regular(ca_file,1048576)
    if hashlib.sha256(raw).hexdigest()!=ca_sha256:raise ValueError('Private CA bytes differ from approved pin')
    from cryptography import x509
    blocks=re.findall(rb'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',raw,re.DOTALL)
    if not blocks or re.sub(rb'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',b'',raw,flags=re.DOTALL).strip():
        raise ValueError('Private trust accepts only CA certificates')
    for block in blocks:
        certificate=x509.load_pem_x509_certificate(block)
        if not certificate.extensions.get_extension_for_class(x509.BasicConstraints).value.ca:
            raise ValueError('Private trust requires CA certificates')
    context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version=ssl.TLSVersion.TLSv1_2
    context.load_verify_locations(cadata=raw.decode('ascii'))
    if not context.get_ca_certs():raise ValueError('Private CA trust contains no CA certificate')
    return context
