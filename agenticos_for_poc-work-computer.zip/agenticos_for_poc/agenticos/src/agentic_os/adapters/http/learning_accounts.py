"""Purpose-bound current account observations; no login or resource credentials."""
from dataclasses import dataclass

from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import fresh, timestamp
from .client import RemoteJSON

PROFILE = "OSPersonalLearning/1"
ROUTE = "/learning/accounts/check"


@dataclass(frozen=True)
class LearningHostBinding:
    endpoint: str
    credential_ref: str
    application_revision: int
    application_generation: int


def learning_host_binding(bundle):
    """Select exactly one operator-pinned, account-only HostBridge connector.

    Existing HostRegistration/1 stays byte-compatible. This connector declares
    no capability and uses the application's authenticated bridge credential.
    Unknown, absent or ambiguous profiles cannot fall back to session checks.
    """
    validate_contract("HostRegistration", bundle)
    manifest = bundle["application"]
    matches = [c for c in bundle["connectors"] if c["authorityProfile"] == PROFILE]
    if len(matches) != 1:
        raise OSErrorCode("PROFILE_DISABLED")
    connector = matches[0]
    endpoints = [e for e in bundle["endpoints"] if e["id"] == manifest["bridgeRef"]]
    if (not manifest["active"] or len(endpoints) != 1
            or not manifest["guarantees"]["currentAuthority"]
            or not manifest["guarantees"]["liveRevocation"]
            or connector["id"] not in manifest["connectorRefs"]
            or connector["transport"] != "host-bridge"
            or connector["protocolProfile"] != "host-bridge/1"
            or connector["endpointRef"] != manifest["bridgeRef"]
            or connector["credentialRef"] != manifest["credentialRef"]
            or connector["conformance"] != "qualified"
            or connector["timeoutMs"] != 3000 or connector["maxResponseBytes"] != 4096
            or connector["capabilityRefs"]
            or not connector["guarantees"]["currentAuthority"]
            or not connector["guarantees"]["liveRevocation"]
            or endpoints[0]["purpose"] != "host-bridge"
            or any(c["connectorRef"] == connector["id"] for c in bundle["capabilities"])):
        raise OSErrorCode("PROFILE_DISABLED")
    return LearningHostBinding(endpoints[0]["url"], manifest["credentialRef"],
                               manifest["revision"], manifest["generation"])


class LearningAccountJSON(RemoteJSON):
    # A learning account adapter cannot use the generic client's other routes.
    allowed_routes = frozenset({ROUTE})


class RemoteLearningAccount:
    def __init__(self, binding, credential,*,network='owned-local-http/1',ca_file=None,ca_sha256=None):
        self.client = LearningAccountJSON(binding.endpoint, credential, max_bytes=4096,
            network=network,ca_file=ca_file,ca_sha256=ca_sha256)

    async def check(self, subject):
        request = dict(subject=subject, purpose=PROFILE)
        validate_contract("HostLearningAccountRequest", request)
        result = await self.client.post(ROUTE, request, "HostLearningAccountState")
        fresh(result, subject=subject)
        lifetime = (timestamp(result["validUntil"]) - timestamp(result["checkedAt"])).total_seconds()
        if not 0 < lifetime <= 15:
            raise OSErrorCode("DENIED")
        return result
