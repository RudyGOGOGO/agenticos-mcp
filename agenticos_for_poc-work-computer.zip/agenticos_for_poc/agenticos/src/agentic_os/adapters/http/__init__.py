"""Independent OS boundary. No host implementation imports."""
