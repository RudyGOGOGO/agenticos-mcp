"""HostBridge/1 over authenticated remote HTTP. No imported host implementation."""
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import fresh, utcnow, timestamp
from .client import RemoteJSON


class RemoteHostBridge:
    def __init__(self, bundle, credential,*,network='owned-local-http/1',ca_file=None,ca_sha256=None):
        self.manifest=bundle['application']
        self.endpoints={item['id']:item for item in bundle['endpoints']}
        endpoint=self.endpoints[self.manifest['bridgeRef']]
        self.client=RemoteJSON(endpoint['url'],credential,network=network,ca_file=ca_file,ca_sha256=ca_sha256)

    def check_subject(self, subject):
        validate_contract('SubjectRef',subject)
        if (subject['installationId']!=self.manifest['installationId']
                or subject['applicationId']!=self.manifest['applicationId']):
            raise OSErrorCode('DENIED')

    async def session(self, subject, host_session_ref, generation):
        self.check_subject(subject)
        result=await self.client.post('/sessions/check',{'subject':subject,'hostSessionRef':host_session_ref,
            'sessionGeneration':generation},'HostSessionState')
        fresh(result,subject=subject)
        if result['sessionGeneration']!=generation:
            raise OSErrorCode('DENIED')
        return result

    async def authority(self, request):
        validate_contract('HostAuthorityRequest',request);self.check_subject(request['subject'])
        result=await self.client.post('/authority/check',request,'HostAuthority')
        fresh(result,subject=request['subject'])
        if (result['purpose']!=request['purpose'] or result['delegationRef']!=request['delegationRef']
                or request['capabilityRef'] not in result['capabilityRefs']):
            raise OSErrorCode('DENIED')
        for resource in request['resourceRefs']:
            if resource['subject']!=request['subject'] or not any(bound['resourceType']==resource['resourceType']
                    and resource['externalId'] in bound['externalIds'] for bound in result['resourceBounds']):
                raise OSErrorCode('DENIED')
        return result

    async def capabilities(self, subject, purpose='assistant.read'):
        self.check_subject(subject)
        result=await self.client.post('/capabilities',{'subject':subject,'purpose':purpose},'HostCapabilitiesResult')
        return result['capabilities']

    async def credential(self, subject, endpoint_ref, capability_ref, purpose, authority_ref):
        self.check_subject(subject)
        if endpoint_ref not in self.endpoints:
            raise OSErrorCode('DENIED')
        result=await self.client.post('/credentials/issue',{'subject':subject,'endpointRef':endpoint_ref,
            'capabilityRef':capability_ref,'purpose':purpose,'authorityRef':authority_ref},'HostCredential')
        if (result['subject']!=subject or result['audienceRef']!=self.endpoints[endpoint_ref]['audienceRef']
                or result['capabilityRef']!=capability_ref or timestamp(result['expiresAt'])<=utcnow()
                or (timestamp(result['expiresAt'])-utcnow()).total_seconds()>60):
            raise OSErrorCode('DENIED')
        return result

    async def validate_resource(self, request):
        validate_contract('ResourceValidationRequest',request);self.check_subject(request['subject'])
        return await self.client.post('/resources/validate',request,'ResourceValidationResult')

    async def resolve_evidence(self, request):
        validate_contract('EvidenceRequest',request);self.check_subject(request['subject'])
        result=await self.client.post('/evidence/resolve',request,'EvidencePage')
        if result['evidence']['subject']!=request['subject']:
            raise OSErrorCode('DENIED')
        return result


class BridgeFactory:
    def __init__(self, registry,*,tls_by_endpoint=None):
        self.registry=registry;self.clients={}
        self.tls_by_endpoint={}
        if tls_by_endpoint is not None:
            from .endpoint import reviewed_http_endpoint
            from .tls import reviewed_tls_context
            if type(tls_by_endpoint) is not dict or not 1<=len(tls_by_endpoint)<=64:
                raise ValueError('Bounded exact Host endpoint trust required')
            for endpoint,trust in tls_by_endpoint.items():
                reviewed_http_endpoint(endpoint,registry.network)
                if type(trust) is not dict or set(trust)!={'ca_file','ca_sha256'}:
                    raise ValueError('Closed private Host trust required')
                reviewed_tls_context(registry.network,**trust)
                self.tls_by_endpoint[endpoint]=dict(trust)

    def for_application(self, app):
        return self._for_bundle(self.registry.application(app))

    def _for_bundle(self,bundle):
        # Internal composition only: the registry must freshly validate this
        # exact bundle in the enclosing operation. Clients retain no authority.
        manifest=bundle['application'];app=manifest['applicationId']
        key=(manifest['applicationId'],manifest['revision'],manifest['generation'])
        if key not in self.clients:
            credential=self.registry.credential(app,manifest['credentialRef'])
            self.clients={k:v for k,v in self.clients.items() if k[0]!=key[0]}
            endpoint=next(item['url'] for item in bundle['endpoints'] if item['id']==manifest['bridgeRef'])
            self.clients[key]=RemoteHostBridge(bundle,credential,network=self.registry.network,
                **self.tls_by_endpoint.get(endpoint,{}))
        return self.clients[key]
