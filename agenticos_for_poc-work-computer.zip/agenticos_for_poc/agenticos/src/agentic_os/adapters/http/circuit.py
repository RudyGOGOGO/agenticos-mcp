"""Process-local availability circuit; never retries or grants authority."""
from contextlib import contextmanager
from threading import Lock
from time import monotonic

from agentic_os.errors import OSErrorCode


class AvailabilityCircuit:
    def __init__(self, *, clock=monotonic):
        self._clock = clock
        self._lock = Lock()
        self._generation = 0
        self._failures = 0
        self._open_until = None
        self._probing = False

    def _enter(self):
        with self._lock:
            probe = self._open_until is not None
            if probe:
                if self._probing or self._clock() < self._open_until:
                    raise OSErrorCode('UNAVAILABLE')
                self._probing = True
            return self._generation, probe

    def _finish(self, attempt, failed):
        generation, probe = attempt
        with self._lock:
            # A late pre-trip success must not close a newly tripped circuit.
            if generation != self._generation:
                return
            if probe:
                self._probing = False
                self._generation += 1
                self._failures = 0
                self._open_until = None if failed is False else self._clock() + 5
            elif failed is True:
                self._failures += 1
                if self._failures >= 3:
                    self._generation += 1
                    self._failures = 0
                    self._open_until = self._clock() + 5
            elif failed is False:
                self._failures = 0

    @contextmanager
    def call(self, *, timed_out=None):
        attempt = self._enter()
        try:
            yield
        except OSErrorCode as error:
            # Valid denials/conflicts are responses, not availability failures.
            self._finish(attempt, error.code == 'UNAVAILABLE')
            raise
        except Exception:
            self._finish(attempt, True)
            raise
        except BaseException:
            # Cancellation neither establishes a healthy host nor strands a
            # half-open probe. It cannot settle any caller's uncertain usage.
            self._finish(attempt, True if timed_out is not None and timed_out() else None)
            raise
        else:
            self._finish(attempt, False)
