"""Explicit backend composition, never user input or deployment qualification.

The trusted installation factory supplies already configured adapters. Core
services retain namespace, authority, accounting and transaction semantics;
these dependencies must not discover a Host environment or create resources.
"""
from dataclasses import dataclass,field
from pathlib import Path
from typing import Callable,Any
from uuid import UUID

from agentic_os.adapters.local.files import OwnershipError,check_private


@dataclass(frozen=True)
class ComponentPorts:
    """Trusted factories for the existing isolated retrieval and KB stores.

    Factories are lazy: selecting a control-only role must neither provision nor
    connect optional stores. Public metadata and reviewed publication retain
    distinct credentials; no component can borrow the control credential.
    """
    installation_id:UUID
    retrieval:Callable=field(repr=False)
    knowledge:Callable=field(repr=False)
    knowledge_public:Callable=field(repr=False)
    knowledge_operator:Callable=field(repr=False)
    knowledge_keys:Callable=field(repr=False)
    embedding:Callable=field(repr=False)
    retrieval_modes:frozenset=field(default=frozenset({'exact','ann','lexical','hybrid'}))

    def __post_init__(self):
        if (type(self.installation_id) is not UUID or not all(callable(v) for v in (
                self.retrieval,self.knowledge,self.knowledge_public,self.knowledge_operator,
                self.knowledge_keys,self.embedding))
                or type(self.retrieval_modes) is not frozenset or not self.retrieval_modes
                or not self.retrieval_modes<=frozenset({'exact','ann','lexical','hybrid'})):
            raise OwnershipError('Complete isolated component adapters required')


@dataclass(frozen=True)
class InstallationPorts:
    installation_id:UUID
    root:Path
    connect:Callable=field(repr=False)
    transaction_guard:Callable=field(repr=False)
    operator:Callable=field(repr=False)
    credentials:Any=field(repr=False)
    artifacts:Any=field(repr=False)
    components:ComponentPorts|None=field(default=None,repr=False)

    def __post_init__(self):
        if (type(self.installation_id) is not UUID or not isinstance(self.root,Path)
                or not self.root.is_absolute() or self.root.resolve()!=self.root
                or not all(callable(v) for v in (self.connect,self.transaction_guard,self.operator))
                or not all(callable(getattr(self.credentials,k,None)) for k in ('get','put'))
                or not all(callable(getattr(self.artifacts,k,None)) for k in ('create','read','pin'))
                or not callable(getattr(getattr(self.artifacts,'keys',None),'active',None))):
            raise OwnershipError('Complete explicit installation adapters required')
        check_private(self.root,directory=True)
        if self.components is not None and (type(self.components) is not ComponentPorts
                or self.components.installation_id!=self.installation_id):
            raise OwnershipError('Component adapters belong to another installation')

    def require_components(self,manifest):
        from agentic_os.errors import OSErrorCode
        if Path(manifest)!=self.root/'manifest.json':
            raise OwnershipError('Component installation path differs')
        if self.components is None:raise OSErrorCode('PROFILE_DISABLED')
        return self.components

    def verify_operator(self,token):
        return self._operator_identity(self.operator(token))

    def operator_checkpoint(self,token):
        """Prepare before SQL; the adapter owns its short commit recheck.

        Local operators still recheck signed current state. Immutable remote
        credential versions may authenticate before SQL and retain only that
        exact identity through this one synchronous transaction.
        """
        prepare=getattr(self.operator,'checkpoint',None)
        if prepare is None:return lambda:self.verify_operator(token)
        check=prepare(token)
        if not callable(check):raise OwnershipError('Operator checkpoint unavailable')
        self._operator_identity(check())
        return lambda:self._operator_identity(check())

    def _operator_identity(self,value):
        if (type(value) is not dict or value.get('installationId')!=str(self.installation_id)
                or value.get('principal')!='installation-operator'
                or type(value.get('generation')) is not int or not 1<=value['generation']<=2**53-1
                or type(value.get('profile')) is not str or not value['profile']):
            raise OwnershipError('Operator adapter returned a foreign installation')
        return value
