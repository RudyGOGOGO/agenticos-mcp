"""Stop exact signed owner SDK work; uncertain forks and cost remain held."""
import asyncio,os,signal
from agentic_os.adapters.mem0.lifecycle import StageLifecycle
from agentic_os.adapters.local.files import OwnershipError,private_directory
from agentic_os.errors import OSErrorCode


class ForgettableStageLifecycle(StageLifecycle):
    def __init__(self,root):
        super().__init__(root);self._new_leases={}

    async def acquire(self,cookie,*,binding=None):
        await super().acquire(cookie,binding=binding)
        with self._locked() as state:
            record=state['leases'][cookie]
            self._new_leases[cookie]=(record['ownerPid'],record['ownerBirth'])

    def home(self,cookie):
        # Admission cancellation cannot create an unanchored home between the
        # state check and inode recording. The lock contains only local I/O.
        with self._locked() as state:
            record=state['leases'][cookie]
            if record['state']!='STARTING' or record['homeInode'] is not None:
                raise OSErrorCode('UNAVAILABLE')
            path=self.root/'work'/cookie;private_directory(path);info=path.stat()
            record.update(homeDevice=info.st_dev,homeInode=info.st_ino)
            return path

    async def acknowledge(self,process,cookie):
        identity=await self.identity(process.pid,cookie)
        if identity is None:raise OSErrorCode('UNAVAILABLE')
        cancelled=False
        with self._locked() as state:
            record=state['leases'][cookie]
            if record['pid'] or record['ownerPid']!=os.getpid():raise OSErrorCode('UNAVAILABLE')
            if record['state']=='STARTING':record['state']='RUNNING'
            elif record['state']=='HELD' and 'ownerMac' in record:cancelled=True
            else:raise OSErrorCode('UNAVAILABLE')
            # Record the exact fork ACK even when deletion won the race. The
            # caller then fails before frames/provider and joins this child.
            record.update(pid=process.pid,startIdentity=identity)
        if cancelled:raise OSErrorCode('DENIED')

    def settle(self,cookie,stopped):
        with self._locked() as state:
            record=state['leases'].get(cookie)
            if record is None:return True
            if (stopped and 'ownerMac' in record and record['ownerPid']==os.getpid()
                    and self._new_leases.get(cookie)==(record['ownerPid'],record['ownerBirth'])
                    and record['pid']==0 and record['homeDevice'] is None
                    and record['homeInode'] is None and not (self.root/'work'/cookie).exists()):
                # Only the live in-process owner may assert its known no-fork
                # path. An operator cannot release a crashed unanchored fork.
                state['leases'].pop(cookie);self._new_leases.pop(cookie,None);return True
            if stopped:
                try:self._remove_home(cookie,record)
                except (OSError,ValueError,OwnershipError,OSErrorCode):stopped=False
            if stopped:
                state['leases'].pop(cookie);self._new_leases.pop(cookie,None)
            else:record['state']='HELD'
            return stopped

    async def cancel_owner(self,subject):
        mac=self.owner_mac(subject)
        with self._locked() as state:
            removed=sum(v.get('ownerMac')==mac for v in state['queue'])
            state['queue']=[v for v in state['queue'] if v.get('ownerMac')!=mac]
            records={cookie:dict(v) for cookie,v in state['leases'].items() if v.get('ownerMac')==mac}
            for cookie in records:state['leases'][cookie]['state']='HELD'
        for cookie,record in records.items():
            if not record['pid'] or not record['startIdentity']:continue
            try:
                async with asyncio.timeout(3):
                    current=await self.identity(record['pid'],cookie)
                    if current is not None and current!=record['startIdentity']:continue
                    for action in (signal.SIGTERM,signal.SIGKILL):
                        if current is None:break
                        with self._locked() as state:
                            latest=state['leases'].get(cookie)
                            if (latest is None or latest.get('ownerMac')!=mac or latest['pid']!=record['pid']
                                    or latest['startIdentity']!=record['startIdentity']):break
                        current=await self.identity(record['pid'],cookie)
                        if current!=record['startIdentity']:break
                        os.killpg(record['pid'],action)
                        for _ in range(10):
                            if not self.group_exists(record['pid']):break
                            await asyncio.sleep(.05)
                        current=await self.identity(record['pid'],cookie)
                    owner=await self._probe('-o','lstart=','-p',str(record['ownerPid']))
                    if owner==record['ownerBirth'] or self.group_exists(record['pid']):continue
                    # An absent exact group and dead recorded worker can settle
                    # only this owner lease/home. Live workers join their calls.
                    with self._locked() as state:
                        latest=state['leases'].get(cookie)
                        if (latest is None or latest.get('ownerMac')!=mac or latest['pid']!=record['pid']
                                or latest['startIdentity']!=record['startIdentity']):continue
                        self._remove_home(cookie,latest);state['leases'].pop(cookie)
            except (TimeoutError,OSError,OwnershipError,OSErrorCode):continue
        snapshot=self.owner_snapshot(subject)
        return dict(removedQueue=removed,pending=bool(snapshot['leases'] or snapshot['queue'] or snapshot['unboundWork']),
            ownedLeases=len(snapshot['leases']),unboundWork=snapshot['unboundWork'])
