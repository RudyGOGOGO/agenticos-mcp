"""One disposable SDK process per stage, finite budgets and truthful uncertainty.

The caller must separately authorize/recheck learning and hold no SQL session.
This adapter has no canonical store, credential lookup, dispatch or retry path.
"""
import asyncio
from dataclasses import dataclass
import os
from pathlib import Path
import sys
from uuid import uuid4

from agentic_os.adapters.local.files import check_private
from agentic_os.adapters.mem0.lifecycle import MODULE, StageLifecycle
from agentic_os.adapters.mem0.protocol import (MAX_FRAME, PROFILE, checked_candidate,
    checked_request, closed, frame, sequence)
from agentic_os.contracts.canonical import parse_canonical_json
from agentic_os.errors import OSErrorCode


@dataclass(frozen=True)
class ExtractorReply:
    content: str
    input_tokens: int
    output_tokens: int
    cost_micros: int
    tool_calls: tuple = ()


@dataclass(frozen=True)
class StageResult:
    state: str
    candidates: tuple
    provider_calls: int
    measured: dict | None
    observed: dict | None
    peak_rss_bytes: int
    error: str | None
    cleanup_complete: bool | None = None


def checked_observed(value, provider_calls):
    closed(value,{"memoryWrites","entityWrites","historyEvents","embeddingCalls","providerCalls",
        "telemetryDisabled","inheritedAlgorithms","networkAttempts","peakRssBytes"})
    if (value["telemetryDisabled"] is not True or value["inheritedAlgorithms"] is not True
            or value["networkAttempts"] != 0 or type(value["networkAttempts"]) is not int
            or value["providerCalls"] != provider_calls or type(value["providerCalls"]) is not int):
        raise OSErrorCode("INVALID")
    for key in ["memoryWrites","entityWrites"]:
        if type(value[key]) is not dict or set(value[key]) - {"insert","update","delete","get","search","reset"}:
            raise OSErrorCode("INVALID")
        if any(type(n) is not int or not 0 <= n <= 4096 for n in value[key].values()):
            raise OSErrorCode("INVALID")
    sequence(value["historyEvents"],64)
    if any(n not in {"ADD","UPDATE","DELETE"} for n in value["historyEvents"]):
        raise OSErrorCode("INVALID")
    for key in ["embeddingCalls","peakRssBytes"]:
        if type(value[key]) is not int or not 0 <= value[key] <= 2**53-1:
            raise OSErrorCode("INVALID")


class Mem0Stage:
    def __init__(self, private_root: Path, *, timeout=20, max_rss_bytes=512*1024**2):
        private_root = Path(private_root).absolute()
        check_private(private_root,directory=True)
        if type(timeout) not in {int,float} or not 0 < timeout <= 30 or type(max_rss_bytes) is not int or not 0 < max_rss_bytes <= 512*1024**2:
            raise OSErrorCode("INVALID")
        self.root, self.timeout, self.max_rss = private_root, timeout, max_rss_bytes
        self.lifecycle = None

    async def _rss(self, process, peak):
        await self.lifecycle.rss(process, peak, self.max_rss)

    async def _stop(self, process, cookie):
        return await self.lifecycle.stop(process, cookie)

    async def recover(self):
        if self.lifecycle is None:
            self.lifecycle = StageLifecycle(self.root)
        return await self.lifecycle.recover()

    async def run(self, request, provider=None):
        value = checked_request(request)
        if value["mode"] == "extract" and provider is None:
            raise OSErrorCode("PROFILE_DISABLED")
        # Shared admission is persisted before any SDK fork. Private frames
        # are sent only after the actual child birth/group/cookie is recorded.
        process = monitor = work = None
        cookie = uuid4().hex
        acquired = clean = fork_started = False
        peak = [0]; calls = 0; measured = None; candidates = (); observed = None
        state, error = "FAILED", "UNAVAILABLE"
        try:
            if self.lifecycle is None:
                self.lifecycle = StageLifecycle(self.root)
            await self.lifecycle.acquire(cookie)
            acquired = True
            work = self.lifecycle.home(cookie)
            env = dict(HOME=str(work),MEM0_DIR=str(work/"mem0"),MEM0_TELEMETRY="false",
                PYTHONNOUSERSITE="1",OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1",MKL_NUM_THREADS="1")
            async with asyncio.timeout(self.timeout):
                fork_started = True
                process = await asyncio.create_subprocess_exec(sys.executable,"-I","-m",MODULE,cookie,
                    cwd=work,env=env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.DEVNULL,start_new_session=True,limit=MAX_FRAME+2)
                await self.lifecycle.acknowledge(process, cookie)
                async def exchange():
                    nonlocal calls, measured, candidates, observed
                    process.stdin.write(frame(value)); await process.stdin.drain()
                    while True:
                        raw = await process.stdout.readline()
                        if not raw.endswith(b"\n") or len(raw) > MAX_FRAME+1:
                            raise OSErrorCode("UNAVAILABLE")
                        reply = parse_canonical_json(raw)
                        if type(reply) is not dict:
                            raise OSErrorCode("INVALID")
                        if reply.get("type") == "call":
                            closed(reply,{"type","messages"}); sequence(reply["messages"],2,2)
                            if calls or value["mode"] != "extract":
                                raise OSErrorCode("DENIED")
                            for index,message in enumerate(reply["messages"]):
                                closed(message,{"role","content"})
                                if message["role"] != ["system","user"][index] or type(message["content"]) is not str or len(message["content"]) > 65536:
                                    raise OSErrorCode("INVALID")
                            calls = 1  # Started inference is uncertain until measured reply.
                            response = await provider.complete(reply["messages"],profile=PROFILE,max_output_tokens=2048)
                            if not isinstance(response,ExtractorReply) or any(type(n) is not int or not 0 <= n <= 2**53-1
                                    for n in [response.input_tokens,response.output_tokens,response.cost_micros]):
                                raise OSErrorCode("UNAVAILABLE")
                            measured = dict(inputTokens=response.input_tokens,outputTokens=response.output_tokens,costMicros=response.cost_micros)
                            if (response.tool_calls or response.output_tokens > 2048 or type(response.content) is not str
                                    or len(response.content.encode("utf8")) > 65536):
                                raise OSErrorCode("INVALID")
                            process.stdin.write(frame(dict(type="reply",content=response.content))); await process.stdin.drain()
                        elif reply.get("type") == "result":
                            closed(reply,{"type","candidates","observed"}); sequence(reply["candidates"],8)
                            sources={v["id"]:v for v in value["sources"]};approved={v["id"]:v for v in value["approved"]}
                            for candidate in reply["candidates"]:
                                checked_candidate(candidate,sources,approved)
                            if value["mode"] == "extract" and any(v["operation"] != "ADD" for v in reply["candidates"]):
                                raise OSErrorCode("INVALID")
                            if value["mode"] == "operations" and reply["candidates"] != value["operations"]:
                                raise OSErrorCode("INVALID")
                            checked_observed(reply["observed"],calls)
                            if reply["observed"]["peakRssBytes"] > self.max_rss:
                                raise OSErrorCode("CAPACITY")
                            peak[0] = max(peak[0],reply["observed"]["peakRssBytes"])
                            observed=reply["observed"]; candidates=tuple(reply["candidates"])
                            await asyncio.wait_for(process.wait(),2)
                            if process.returncode != 0 or await process.stdout.read(1):
                                raise OSErrorCode("UNAVAILABLE")
                            return
                        elif reply.get("type") == "failure":
                            closed(reply,{"type","error"})
                            if reply["error"] not in {"UNAVAILABLE","INVALID","CAPACITY","PROFILE_DISABLED","DENIED"}:
                                raise OSErrorCode("INVALID")
                            raise OSErrorCode(reply["error"])
                        else:
                            raise OSErrorCode("UNAVAILABLE")
                monitor = asyncio.create_task(self._rss(process,peak))
                activity = asyncio.create_task(exchange())
                try:
                    done,_ = await asyncio.wait([monitor,activity],return_when=asyncio.FIRST_COMPLETED)
                    if monitor in done:
                        await monitor
                    await activity
                finally:
                    activity.cancel()
                    await asyncio.gather(activity,return_exceptions=True)
                state, error = "SUCCEEDED", None
        except TimeoutError:
            error = "TIMEOUT"
        except OSErrorCode as exc:
            error = exc.code
        except Exception:
            error = "UNAVAILABLE"
        finally:
            async def cleanup():
                nonlocal clean
                if monitor is not None:
                    monitor.cancel(); await asyncio.gather(monitor,return_exceptions=True)
                if acquired:
                    stopped = False
                    try:
                        stopped = not fork_started or await self._stop(process, cookie)
                    except Exception:
                        pass
                    clean = self.lifecycle.settle(cookie, stopped)
            settle = asyncio.create_task(cleanup())
            try:
                await asyncio.shield(settle)
            except asyncio.CancelledError:
                await settle
                raise
            if acquired and not clean:
                state, error = "FAILED", "UNAVAILABLE"
        if state != "SUCCEEDED":
            candidates, observed = (), None
            if calls and measured is None:
                state = "OUTCOME_UNKNOWN"
        return StageResult(state,candidates,calls,measured,observed,peak[0],error)
