"""Closed bounded private IPC. These values confer no learning authority."""
from copy import deepcopy
import unicodedata
from uuid import UUID

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.memory.knowledge import FORBIDDEN

MAX_FRAME = 524288
PROFILE = "synthetic-staging/1"


def closed(value, keys):
    if type(value) is not dict or set(value) != set(keys):
        raise OSErrorCode("INVALID")


def uid(value):
    if type(value) is not str:
        raise OSErrorCode("INVALID")
    try:
        if str(UUID(value)) != value:
            raise ValueError
    except ValueError:
        raise OSErrorCode("INVALID") from None
    return value


def revision(value):
    if type(value) is not int or not 1 <= value <= 2**53-1:
        raise OSErrorCode("INVALID")


def text(value):
    if (type(value) is not str or not 1 <= len(value) <= 4000
            or not value.strip() or FORBIDDEN.search(unicodedata.normalize("NFKC", value))):
        raise OSErrorCode("INVALID")
    try:
        value.encode("utf8")
    except UnicodeError:
        raise OSErrorCode("INVALID") from None


def sequence(value, maximum, minimum=0):
    if type(value) is not list or not minimum <= len(value) <= maximum:
        raise OSErrorCode("INVALID")


def refs(values, known):
    sequence(values, 20, 1)
    if any(uid(value) not in known for value in values) or len(set(values)) != len(values):
        raise OSErrorCode("INVALID")


def checked_request(value):
    closed(value, {"schema", "profile", "subject", "sources", "approved", "operations", "mode"})
    if value["schema"] != "OSMemoryStage/1" or value["profile"] != PROFILE:
        raise OSErrorCode("PROFILE_DISABLED")
    validate_contract("SubjectRef", value["subject"])
    for key, maximum, minimum, total in [("sources",20,1,8000),("approved",64,0,64000)]:
        sequence(value[key], maximum, minimum)
        ids = set()
        for item in value[key]:
            closed(item, {"id", "revision", "text"})
            if uid(item["id"]) in ids:
                raise OSErrorCode("INVALID")
            ids.add(item["id"]); revision(item["revision"]); text(item["text"])
        if sum(len(item["text"]) for item in value[key]) > total:
            raise OSErrorCode("CAPACITY")
    sequence(value["operations"],8)
    if value["mode"] not in {"extract", "operations"} or (value["mode"] == "extract" and value["operations"]):
        raise OSErrorCode("INVALID")
    sources = {v["id"]:v for v in value["sources"]}
    approved = {v["id"]:v for v in value["approved"]}
    targets = set()
    for item in value["operations"]:
        checked_candidate(item, sources, approved)
        for target in item["targets"]:
            if target["id"] in targets:
                raise OSErrorCode("INVALID")
            targets.add(target["id"])
    raw = canonical_bytes(value)
    if len(raw) > MAX_FRAME:
        raise OSErrorCode("CAPACITY")
    return parse_canonical_json(raw)


def checked_candidate(item, sources, approved):
    closed(item, {"operation", "text", "targets", "sourceRefs"})
    operation = item["operation"]
    if operation not in {"ADD", "UPDATE", "DELETE", "MERGE"}:
        raise OSErrorCode("INVALID")
    if operation == "DELETE":
        if item["text"] is not None:
            raise OSErrorCode("INVALID")
    else:
        text(item["text"])
    sequence(item["targets"], 8)
    count = len(item["targets"])
    if (operation == "ADD" and count != 0 or operation in {"UPDATE","DELETE"} and count != 1
            or operation == "MERGE" and count < 2):
        raise OSErrorCode("INVALID")
    for values, known, maximum, minimum in [(item["sourceRefs"],sources,20,1),(item["targets"],approved,8,0)]:
        sequence(values, maximum, minimum)
        ids = set()
        for ref in values:
            closed(ref, {"id", "revision"}); revision(ref["revision"])
            if uid(ref["id"]) not in known or ref["revision"] != known[ref["id"]]["revision"] or ref["id"] in ids:
                raise OSErrorCode("INVALID")
            ids.add(ref["id"])


def checked_extraction(content, sources):
    if type(content) is not str or len(content.encode("utf8")) > 65536:
        raise OSErrorCode("INVALID")
    value = parse_canonical_json(content); closed(value, {"memory"}); sequence(value["memory"],8)
    seen = set()
    for item in value["memory"]:
        closed(item, {"text", "sourceIds"}); text(item["text"]); refs(item["sourceIds"], sources)
        if item["text"] in seen:
            raise OSErrorCode("INVALID")
        seen.add(item["text"])
    return deepcopy(value["memory"])


def frame(value):
    raw = canonical_bytes(value)
    if len(raw) > MAX_FRAME:
        raise OSErrorCode("CAPACITY")
    return raw + b"\n"
