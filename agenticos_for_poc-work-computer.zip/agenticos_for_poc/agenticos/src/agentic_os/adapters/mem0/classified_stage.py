"""Finite supervised private classified Mem0 stage; owner/job binding precedes fork."""
import asyncio,sys
from uuid import uuid4
from agentic_os.adapters.mem0.stage import Mem0Stage,StageResult,ExtractorReply,checked_observed
from agentic_os.adapters.mem0.lifecycle import MODULE,StageLifecycle
from agentic_os.adapters.mem0.protocol import MAX_FRAME,closed,frame,sequence
from agentic_os.adapters.mem0.classified_protocol import PROFILE,checked_request,checked_candidate
from agentic_os.contracts.canonical import parse_canonical_json
from agentic_os.errors import OSErrorCode


class ClassifiedMem0Stage(Mem0Stage):
    profile=PROFILE
    checked_request=staticmethod(checked_request)
    checked_candidate=staticmethod(checked_candidate)
    checked_observed=staticmethod(checked_observed)
    process_slots=None

    def command(self,cookie):
        return (sys.executable,'-I','-m',MODULE,cookie)

    def provider_reply(self,response):
        return dict(type='reply',content=response.content)

    def environment(self,work):
        return dict(HOME=str(work),MEM0_DIR=str(work/'mem0'),MEM0_TELEMETRY='false',
            PYTHONNOUSERSITE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')

    async def run(self, request, provider=None, *, before_start=None):
        value = self.checked_request(request)
        if value["mode"] == "extract" and provider is None:
            raise OSErrorCode("PROFILE_DISABLED")
        # Shared admission is persisted before any SDK fork. Private frames
        # are sent only after the actual child birth/group/cookie is recorded.
        process = monitor = work = None
        cookie = uuid4().hex
        acquired = clean = fork_started = False
        physical=None
        peak = [0]; calls = 0; measured = None; candidates = (); observed = None
        state, error = "FAILED", "UNAVAILABLE"
        try:
            if self.process_slots is not None:physical=await self.process_slots.acquire()
            if self.lifecycle is None:
                self.lifecycle = StageLifecycle(self.root)
            await self.lifecycle.acquire(cookie, binding=dict(subject=value["subject"],jobId=value["jobId"],profile=self.profile))
            acquired = True
            if before_start is not None:
                await before_start()
            work = self.lifecycle.home(cookie)
            env = self.environment(work)
            async with asyncio.timeout(self.timeout):
                fork_started = True
                process = await asyncio.create_subprocess_exec(*self.command(cookie),
                    cwd=work,env=env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.DEVNULL,start_new_session=True,limit=MAX_FRAME+2)
                await self.lifecycle.acknowledge(process, cookie)
                async def exchange():
                    nonlocal calls, measured, candidates, observed
                    process.stdin.write(frame(value)); await process.stdin.drain()
                    while True:
                        raw = await process.stdout.readline()
                        if not raw.endswith(b"\n") or len(raw) > MAX_FRAME+1:
                            raise OSErrorCode("UNAVAILABLE")
                        reply = parse_canonical_json(raw)
                        if type(reply) is not dict:
                            raise OSErrorCode("INVALID")
                        if reply.get("type") == "call":
                            closed(reply,{"type","messages"}); sequence(reply["messages"],2,2)
                            if calls or value["mode"] != "extract":
                                raise OSErrorCode("DENIED")
                            for index,message in enumerate(reply["messages"]):
                                closed(message,{"role","content"})
                                if message["role"] != ["system","user"][index] or type(message["content"]) is not str or len(message["content"]) > 65536:
                                    raise OSErrorCode("INVALID")
                            calls = 1  # Started inference is uncertain until measured reply.
                            response = await provider.complete(reply["messages"],profile=self.profile,max_output_tokens=2048)
                            if not isinstance(response,ExtractorReply) or any(type(n) is not int or not 0 <= n <= 2**53-1
                                    for n in [response.input_tokens,response.output_tokens,response.cost_micros]):
                                raise OSErrorCode("UNAVAILABLE")
                            measured = dict(inputTokens=response.input_tokens,outputTokens=response.output_tokens,costMicros=response.cost_micros)
                            if (response.tool_calls or response.output_tokens > 2048 or type(response.content) is not str
                                    or len(response.content.encode("utf8")) > 65536):
                                raise OSErrorCode("INVALID")
                            process.stdin.write(frame(self.provider_reply(response))); await process.stdin.drain()
                        elif reply.get("type") == "result":
                            closed(reply,{"type","candidates","observed"}); sequence(reply["candidates"],8)
                            sources={v["id"]:v for v in value["sources"]};approved={v["id"]:v for v in value["approved"]}
                            for candidate in reply["candidates"]:
                                self.checked_candidate(candidate,value)
                            if value["mode"] == "operations" and reply["candidates"] != value["operations"]:
                                raise OSErrorCode("INVALID")
                            self.checked_observed(reply["observed"],calls)
                            if reply["observed"]["peakRssBytes"] > self.max_rss:
                                raise OSErrorCode("CAPACITY")
                            peak[0] = max(peak[0],reply["observed"]["peakRssBytes"])
                            observed=reply["observed"]; candidates=tuple(reply["candidates"])
                            await asyncio.wait_for(process.wait(),2)
                            if process.returncode != 0 or await process.stdout.read(1):
                                raise OSErrorCode("UNAVAILABLE")
                            return
                        elif reply.get("type") == "failure":
                            closed(reply,{"type","error"})
                            if reply["error"] not in {"UNAVAILABLE","INVALID","CAPACITY","PROFILE_DISABLED","DENIED"}:
                                raise OSErrorCode("INVALID")
                            raise OSErrorCode(reply["error"])
                        else:
                            raise OSErrorCode("UNAVAILABLE")
                monitor = asyncio.create_task(self._rss(process,peak))
                activity = asyncio.create_task(exchange())
                try:
                    done,_ = await asyncio.wait([monitor,activity],return_when=asyncio.FIRST_COMPLETED)
                    if monitor in done:
                        await monitor
                    await activity
                finally:
                    activity.cancel()
                    await asyncio.gather(activity,return_exceptions=True)
                state, error = "SUCCEEDED", None
        except TimeoutError:
            error = "TIMEOUT"
        except OSErrorCode as exc:
            error = exc.code
        except Exception:
            error = "UNAVAILABLE"
        finally:
            async def cleanup():
                nonlocal clean
                if monitor is not None:
                    monitor.cancel(); await asyncio.gather(monitor,return_exceptions=True)
                if acquired:
                    stopped = False
                    try:
                        stopped = not fork_started or await self._stop(process, cookie)
                    except Exception:
                        pass
                    clean = self.lifecycle.settle(cookie, stopped)
                if physical is not None:
                    if not fork_started or clean:await self.process_slots.release(physical)
                    else:
                        held=getattr(self,'_held_process_slots',None)
                        if held is None:self._held_process_slots=held={}
                        held[cookie]=physical
            settle = asyncio.create_task(cleanup())
            try:
                await asyncio.shield(settle)
            except asyncio.CancelledError:
                await settle
                raise
            if acquired and not clean:
                state, error = "FAILED", "UNAVAILABLE"
        if state != "SUCCEEDED":
            candidates, observed = (), None
            if calls and measured is None:
                state = "OUTCOME_UNKNOWN"
        return StageResult(state,candidates,calls,measured,observed,peak[0],error,cleanup_complete=clean)
