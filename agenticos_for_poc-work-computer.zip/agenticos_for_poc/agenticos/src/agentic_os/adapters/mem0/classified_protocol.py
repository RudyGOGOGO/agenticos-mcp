"""Versioned private classified extraction IPC; it grants no publication authority."""
from copy import deepcopy
from agentic_os.adapters.mem0.protocol import (MAX_FRAME,closed,uid,revision,text,sequence)
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.memory.classified import checked_classified,context_id
from agentic_os.memory.contexts import checked_label

PROFILE='classified-staging/2'
SCHEMA='OSMemoryStage/2'


def catalog(values,maximum,*,labels=False):
    sequence(values,maximum)
    result={}
    for item in values:
        closed(item,{'id','revision','label'} if labels else {'id','revision'})
        ident=uid(item['id']) if labels else item['id']
        if not labels and (type(ident) is not str or not 1<=len(ident)<=128):
            raise OSErrorCode('INVALID')
        revision(item['revision'])
        if labels:checked_label(item['label'])
        key=ident if labels else (ident,item['revision'])
        if key in result:raise OSErrorCode('INVALID')
        result[key]=item
    return result


def content(value,contexts,keys,tools):
    checked_classified(value)
    cid=context_id(value['contextRef'])
    if cid is not None and str(cid) not in contexts:raise OSErrorCode('INVALID')
    body=value['body']
    if 'claimKeyId' in body and uid(body['claimKeyId']) not in keys:
        raise OSErrorCode('INVALID')
    if any((step['toolRef'],step['toolRevision']) not in tools for step in body.get('steps',[])):
        raise OSErrorCode('PROFILE_DISABLED')


def references(values,known,maximum,minimum):
    sequence(values,maximum,minimum)
    seen=set()
    for ref in values:
        closed(ref,{'id','revision'});ident=uid(ref['id']);revision(ref['revision'])
        if ident in seen or ident not in known or ref['revision']!=known[ident]['revision']:
            raise OSErrorCode('INVALID')
        seen.add(ident)


def checked_candidate(value,request):
    closed(value,{'operation','content','targets','sourceRefs'})
    operation=value['operation']
    if operation not in {'ADD','UPDATE','DELETE','MERGE'}:raise OSErrorCode('INVALID')
    count=len(value['targets']) if type(value['targets']) is list else -1
    if operation=='ADD' and count!=0 or operation in {'UPDATE','DELETE'} and count!=1 or operation=='MERGE' and not 2<=count<=8:
        raise OSErrorCode('INVALID')
    references(value['targets'],{v['id']:v for v in request['approved']},8,0)
    references(value['sourceRefs'],{v['id']:v for v in request['sources']},20,1)
    if operation=='DELETE':
        if value['content'] is not None:raise OSErrorCode('INVALID')
    else:
        content(value['content'],{v['id']:v for v in request['contexts']},
            {v['id']:v for v in request['claimKeys']},
            {(v['id'],v['revision']):v for v in request['tools']})


def candidates(values,request):
    sequence(values,8)
    targets=set();seen=set()
    for item in values:
        checked_candidate(item,request)
        bound=canonical_bytes(dict(operation=item['operation'],content=item['content'],targets=item['targets']))
        if bound in seen:raise OSErrorCode('INVALID')
        seen.add(bound)
        for target in item['targets']:
            if target['id'] in targets:raise OSErrorCode('INVALID')
            targets.add(target['id'])
    if sum(max(1,len(v['targets'])) for v in values)+2*len(values)>64:
        raise OSErrorCode('CAPACITY')
    return deepcopy(values)


def checked_request(value):
    closed(value,{'schema','profile','jobId','subject','sources','approved','contexts','claimKeys','tools',
        'contextRevision','learningEpoch','mode','operations'})
    if value['schema']!=SCHEMA or value['profile']!=PROFILE:raise OSErrorCode('PROFILE_DISABLED')
    uid(value['jobId']);validate_contract('SubjectRef',value['subject'])
    revision(value['contextRevision']);revision(value['learningEpoch'])
    contexts=catalog(value['contexts'],16,labels=True);keys=catalog(value['claimKeys'],32,labels=True)
    tools=catalog(value['tools'],128)
    if set(contexts)&set(keys):raise OSErrorCode('INVALID')
    sequence(value['sources'],20,1);source_ids=set()
    for item in value['sources']:
        closed(item,{'id','revision','text'});ident=uid(item['id']);revision(item['revision']);text(item['text'])
        if ident in source_ids:raise OSErrorCode('INVALID')
        source_ids.add(ident)
    if sum(len(v['text']) for v in value['sources'])>8000:raise OSErrorCode('CAPACITY')
    sequence(value['approved'],64);approved_ids=set()
    for item in value['approved']:
        closed(item,{'id','revision','content'});ident=uid(item['id']);revision(item['revision'])
        if ident in approved_ids:raise OSErrorCode('INVALID')
        approved_ids.add(ident);content(item['content'],contexts,keys,tools)
    if value['mode'] not in {'extract','operations'} or value['mode']=='extract' and value['operations']:
        raise OSErrorCode('INVALID')
    candidates(value['operations'],value)
    raw=canonical_bytes(value)
    if len(raw)>MAX_FRAME:raise OSErrorCode('CAPACITY')
    return parse_canonical_json(raw)


def checked_extraction(raw,request):
    if type(raw) is not str or len(raw.encode('utf8'))>65536:raise OSErrorCode('INVALID')
    value=parse_canonical_json(raw);closed(value,{'candidates'})
    return candidates(value['candidates'],request)
