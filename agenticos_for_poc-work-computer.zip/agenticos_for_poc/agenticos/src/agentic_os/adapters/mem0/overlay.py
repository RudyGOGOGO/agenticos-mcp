"""Bounded process-local stores and synthetic vectors; no retrieval qualification."""
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import math


DIMENSIONS = 16


class SyntheticEmbedder:
    def __init__(self):
        self.calls = 0

    def embed(self, value, memory_action=None):
        self.calls += 1
        raw = hashlib.sha256(value.encode("utf8")).digest()
        return [(raw[i]-127.5)/127.5 for i in range(DIMENSIONS)]

    def embed_batch(self, values, memory_action=None):
        return [self.embed(value, memory_action) for value in values]


@dataclass
class Row:
    id: str
    payload: dict
    score: float = 1.0


class Overlay:
    def __init__(self, owner, capacity=72):
        self.owner, self.capacity = owner, capacity
        self.rows = {}
        self.events = Counter()

    def _payload(self, value):
        if type(value) is not dict or value.get("user_id") != self.owner:
            raise ValueError("Stage scope")
        return deepcopy(value)

    def _vector(self, value):
        if (type(value) is not list or len(value) != DIMENSIONS
                or any(type(n) not in {float,int} or not math.isfinite(n) for n in value)):
            raise ValueError("Stage vector")
        return list(value)

    def _filters(self, filters):
        if filters != {"user_id":self.owner}:
            raise ValueError("Stage scope")

    def insert(self, vectors, payloads=None, ids=None):
        if not vectors or len(vectors) != len(payloads or []) or len(vectors) != len(ids or []):
            raise ValueError("Stage batch")
        if len(self.rows)+len(ids) > self.capacity or len(set(ids)) != len(ids) or any(i in self.rows for i in ids):
            raise ValueError("Stage capacity")
        checked = [(i,self._vector(v),self._payload(p)) for i,v,p in zip(ids,vectors,payloads)]
        for i,v,p in checked:
            self.rows[i] = (v,p); self.events["insert"] += 1

    def get(self, vector_id):
        self.events["get"] += 1
        return Row(vector_id,deepcopy(self.rows[vector_id][1])) if vector_id in self.rows else None

    def update(self, vector_id, vector=None, payload=None):
        old_v, old_p = self.rows[vector_id]
        self.rows[vector_id] = (self._vector(vector) if vector is not None else old_v,
            self._payload(payload) if payload is not None else old_p)
        self.events["update"] += 1

    def delete(self, vector_id):
        del self.rows[vector_id]; self.events["delete"] += 1

    def list(self, filters=None, top_k=None):
        self._filters(filters)
        return [[Row(i,deepcopy(p)) for i,(_,p) in sorted(self.rows.items())][:min(top_k or 72,72)]]

    def search(self, query, vectors, top_k=5, filters=None):
        self._filters(filters); q = self._vector(vectors)
        self.events["search"] += 1
        def score(v):
            return max(0.0,sum(a*b for a,b in zip(q,v))/(math.sqrt(sum(a*a for a in q)*sum(b*b for b in v)) or 1))
        rows = [Row(i,deepcopy(p),score(v)) for i,(v,p) in self.rows.items()]
        return sorted(rows,key=lambda r:(-r.score,r.id))[:min(top_k,72)]

    def search_batch(self, queries, vectors_list, top_k=1, filters=None):
        return [self.search(q,v,top_k,filters) for q,v in zip(queries,vectors_list)]

    def reset(self):
        self.rows.clear(); self.events["reset"] += 1

    def create_col(self, name, vector_size, distance):
        raise ValueError("Stage collection fixed")

    def list_cols(self):
        return []

    def delete_col(self):
        self.reset()

    def col_info(self):
        return {"points_count":len(self.rows)}
