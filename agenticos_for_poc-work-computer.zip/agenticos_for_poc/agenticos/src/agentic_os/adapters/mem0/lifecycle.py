"""Shared finite SDK admission and signed process/home teardown evidence.

The journal contains opaque ownership facts only. Unknown forks, reused PIDs,
replaced homes and unexpected files retain capacity across worker restarts.
"""
import asyncio
import hmac
from contextlib import contextmanager
import os
from pathlib import Path
import shutil
import signal
import stat
import time
from uuid import UUID

from agentic_os.adapters.local.files import (OwnershipError, check_private,
    private_directory, private_read)
from agentic_os.adapters.local.resources import (canonical_path, file_lock,
    initialize_key, read_signed, write_signed)
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode

MODULE = "agentic_os.adapters.mem0.child"
PROGRAMS={
    'classified-staging/2':'-I -m '+MODULE+' ',
    'keyword-inference/1':'-I -B -m agentic_os_agent_worker.memory_inference ',
}


class StageLifecycle:
    ACTIVE, QUEUED, QUEUE_SECONDS = 2, 14, 10

    def __init__(self, root):
        self.root = canonical_path(Path(root))
        self.ps = shutil.which("ps")
        if self.ps is None:
            raise OSErrorCode("PROFILE_DISABLED")
        initialize_key(self.root, allowed_entries={"admission.lock", "state.json", "work"})
        with file_lock(self.root / "admission.lock", timeout=.1):
            if not (self.root / "work").exists():
                private_directory(self.root / "work")
            check_private(self.root / "work", directory=True)
            if not (self.root / "state.json").exists():
                if list((self.root / "work").iterdir()):
                    raise OSErrorCode("UNAVAILABLE")
                self._save(dict(version=1, leases={}, queue=[]))
            self._load()

    def _save(self, state):
        write_signed(self.root / "state.json", state, self.root / "resource.key")

    @staticmethod
    def _binding_fields(record, base):
        fields = {"ownerMac", "jobId", "profile"}
        if set(record) == base:
            return True
        if set(record) != base | fields:
            return False
        mac, job = record["ownerMac"], record["jobId"]
        if (type(mac) is not str or len(mac) != 64
                or any(c not in "0123456789abcdef" for c in mac)
                or type(record['profile']) is not str or record['profile'] not in PROGRAMS or type(job) is not str):
            return False
        try:
            return str(UUID(job)) == job
        except ValueError:
            return False

    def owner_mac(self, subject):
        validate_contract("SubjectRef", subject)
        key = private_read(self.root / "resource.key", 32)
        return hmac.digest(key, b"agentic-os.mem0-owner/2\0" + canonical_bytes(subject), "sha256").hex()

    def _binding(self, binding):
        if binding is None:
            return {}
        if type(binding) is not dict or set(binding) != {"subject", "jobId", "profile"}:
            raise OSErrorCode("INVALID")
        value = dict(ownerMac=self.owner_mac(binding["subject"]),
            jobId=binding["jobId"], profile=binding["profile"])
        if not self._binding_fields(value, set()):
            raise OSErrorCode("INVALID")
        return value

    def owner_snapshot(self, subject):
        """Private opaque scope facts; legacy unbound work remains uncertain."""
        mac = self.owner_mac(subject)
        with self._locked() as state:
            leases = {cookie: dict(v) for cookie, v in state["leases"].items()
                if v.get("ownerMac") == mac}
            queued = [dict(v) for v in state["queue"] if v.get("ownerMac") == mac]
            unbound = any("ownerMac" not in v for v in [*state["leases"].values(), *state["queue"]])
            return dict(leases=leases, queue=queued, unboundWork=unbound)

    def _load(self):
        check_private(self.root, directory=True)
        check_private(self.root / "work", directory=True)
        value = read_signed(self.root / "state.json", self.root / "resource.key", maximum=16384)
        if (type(value) is not dict or set(value) != {"version", "leases", "queue"}
                or type(value["version"]) is not int or value["version"] != 1
                or type(value["leases"]) is not dict or len(value["leases"]) > self.ACTIVE
                or type(value["queue"]) is not list or len(value["queue"]) > self.QUEUED):
            raise OSErrorCode("UNAVAILABLE")
        def cookie(v):
            return type(v) is str and len(v) == 32 and all(c in "0123456789abcdef" for c in v)
        for key, record in value["leases"].items():
            if (not cookie(key) or type(record) is not dict or not self._binding_fields(record,
                    {"state", "pid", "startIdentity", "homeDevice", "homeInode", "ownerPid", "ownerBirth"})
                    or record["state"] not in {"STARTING", "RUNNING", "HELD"}
                    or type(record["pid"]) is not int or record["pid"] < 0
                    or type(record["ownerPid"]) is not int or record["ownerPid"] <= 0
                    or type(record["ownerBirth"]) is not str or not 0 < len(record["ownerBirth"]) <= 128
                    or record["startIdentity"] is not None and
                        (type(record["startIdentity"]) is not str or len(record["startIdentity"]) > 128)
                    or any(record[k] is not None and (type(record[k]) is not int or record[k] < 0)
                        for k in ("homeDevice", "homeInode"))):
                raise OSErrorCode("UNAVAILABLE")
            if (record["pid"] == 0) != (record["startIdentity"] is None):
                raise OSErrorCode("UNAVAILABLE")
            if record["state"] == "RUNNING" and not record["pid"]:
                raise OSErrorCode("UNAVAILABLE")
        keys = []
        for item in value["queue"]:
            if (type(item) is not dict or not self._binding_fields(item, {"cookie", "expiresMillis"})
                    or not cookie(item["cookie"]) or type(item["expiresMillis"]) is not int):
                raise OSErrorCode("UNAVAILABLE")
            keys.append(item["cookie"])
        if len(set(keys)) != len(keys) or set(keys) & set(value["leases"]):
            raise OSErrorCode("UNAVAILABLE")
        if {p.name for p in (self.root / "work").iterdir()} - set(value["leases"]):
            raise OSErrorCode("UNAVAILABLE")
        return value

    @contextmanager
    def _locked(self):
        with file_lock(self.root / "admission.lock", timeout=.1):
            state = self._load()
            yield state
            self._save(state)

    def snapshot(self):
        with self._locked() as state:
            return dict(active=sum(v["state"] == "RUNNING" for v in state["leases"].values()),
                held=sum(v["state"] != "RUNNING" for v in state["leases"].values()),
                queued=len(state["queue"]))

    async def acquire(self, cookie, *, binding=None):
        bound = self._binding(binding)
        birth = await self._probe("-o", "lstart=", "-p", str(os.getpid()))
        if not birth:
            raise OSErrorCode("UNAVAILABLE")
        deadline = time.monotonic() + self.QUEUE_SECONDS
        waiting = False
        try:
            while True:
                with self._locked() as state:
                    now = int(time.time()*1000)
                    state["queue"] = [v for v in state["queue"] if v["expiresMillis"] > now]
                    if waiting and not any(v["cookie"] == cookie for v in state["queue"]):
                        raise OSErrorCode("CAPACITY")
                    first = not state["queue"] or state["queue"][0]["cookie"] == cookie
                    if len(state["leases"]) < self.ACTIVE and first:
                        state["queue"] = [v for v in state["queue"] if v["cookie"] != cookie]
                        state["leases"][cookie] = dict(state="STARTING", pid=0,
                            startIdentity=None, homeDevice=None, homeInode=None,
                            ownerPid=os.getpid(), ownerBirth=birth, **bound)
                        return
                    if not waiting:
                        if len(state["queue"]) >= self.QUEUED:
                            raise OSErrorCode("CAPACITY")
                        state["queue"].append(dict(cookie=cookie,
                            expiresMillis=now+int(self.QUEUE_SECONDS*1000), **bound))
                        waiting = True
                if time.monotonic() >= deadline:
                    raise OSErrorCode("CAPACITY")
                await asyncio.sleep(.02)
        finally:
            if waiting:
                with self._locked() as state:
                    state["queue"] = [v for v in state["queue"] if v["cookie"] != cookie]

    def home(self, cookie):
        path = self.root / "work" / cookie
        private_directory(path)
        info = path.stat()
        with self._locked() as state:
            record = state["leases"][cookie]
            if record["state"] != "STARTING" or record["homeInode"] is not None:
                raise OSErrorCode("UNAVAILABLE")
            record.update(homeDevice=info.st_dev, homeInode=info.st_ino)
        return path

    async def _probe(self, *args, maximum=16384):
        probe = await asyncio.create_subprocess_exec(self.ps, *args, env={"LC_ALL": "C"},
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL, limit=maximum+2)
        try:
            raw, _ = await asyncio.wait_for(probe.communicate(), 1)
            if probe.returncode not in {0, 1} or len(raw) > maximum:
                raise OSErrorCode("UNAVAILABLE")
            return raw.decode("utf8").strip()
        finally:
            if probe.returncode is None:
                probe.kill()
                await probe.wait()

    async def identity(self, pid, cookie):
        with file_lock(self.root/'admission.lock',timeout=.1,shared=True):
            record=self._load()['leases'].get(cookie)
            profile=record.get('profile') if record is not None else None
            program=PROGRAMS[profile] if profile is not None else '-I -m '+MODULE+' '
        stamp = await self._probe("-o", "lstart=,pgid=", "-p", str(pid))
        command = await self._probe("-o", "command=", "-p", str(pid))
        if not stamp and not command:
            return None
        if (not stamp or not command or program not in command
                or command.split()[-1] != cookie or stamp.split()[-1] != str(pid)):
            raise OSErrorCode("UNAVAILABLE")
        return stamp

    async def acknowledge(self, process, cookie):
        identity = await self.identity(process.pid, cookie)
        if identity is None:
            raise OSErrorCode("UNAVAILABLE")
        with self._locked() as state:
            record = state["leases"][cookie]
            if record["state"] != "STARTING" or record["pid"]:
                raise OSErrorCode("UNAVAILABLE")
            record.update(state="RUNNING", pid=process.pid, startIdentity=identity)

    async def rss(self, process, peak, maximum):
        # Sum the owned group rather than measuring only its leader. This is
        # SDK process accounting; native containment remains a separate gate.
        while process.returncode is None:
            raw = await self._probe("-axo", "pid=,pgid=,rss=", maximum=262144)
            total = count = 0
            for line in raw.splitlines():
                pid, group, rss = map(int, line.split())
                if group == process.pid:
                    total += rss*1024
                    count += 1
            peak[0] = max(peak[0], total)
            if total > maximum or count > 8:
                raise OSErrorCode("CAPACITY")
            await asyncio.sleep(.1)

    @staticmethod
    def group_exists(pid):
        try:
            os.killpg(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            # A denied probe is uncertainty, never evidence of group absence.
            return True

    async def stop(self, process, cookie):
        if process is None:
            return False  # Fork/ACK uncertainty holds its durable slot.
        with self._locked() as state:
            record = dict(state["leases"][cookie])
        if not record["startIdentity"] or record["pid"] != process.pid:
            return False
        async with asyncio.timeout(3):
            for action in (signal.SIGTERM, signal.SIGKILL):
                current = await self.identity(process.pid, cookie)
                if current is None:
                    await asyncio.wait_for(process.wait(), 1)
                    while self.group_exists(process.pid):
                        await asyncio.sleep(.05)
                    return process.returncode is not None
                if current != record["startIdentity"]:
                    return False
                os.killpg(process.pid, action)
                try:
                    await asyncio.wait_for(process.wait(), 1)
                except TimeoutError:
                    pass
                if process.returncode is not None and not self.group_exists(process.pid):
                    return True
            while self.group_exists(process.pid):
                await asyncio.sleep(.05)
            return process.returncode is not None

    def _remove_home(self, cookie, record):
        path = self.root / "work" / cookie
        check_private(path, directory=True)
        info = path.stat()
        if (info.st_dev, info.st_ino) != (record["homeDevice"], record["homeInode"]):
            raise OSErrorCode("UNAVAILABLE")
        names = {p.name for p in path.iterdir()}
        if names - {"mem0"}:
            raise OSErrorCode("UNAVAILABLE")
        if "mem0" in names:
            directory = path / "mem0"
            check_private(directory, directory=True)
            if {p.name for p in directory.iterdir()} != {"config.json"}:
                raise OSErrorCode("UNAVAILABLE")
            config = directory / "config.json"
            info = config.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise OSErrorCode("UNAVAILABLE")
            value = parse_canonical_json(private_read(config, 2048))
            if type(value) is not dict or set(value) != {"user_id"} or type(value["user_id"]) is not str:
                raise OSErrorCode("UNAVAILABLE")
            UUID(value["user_id"])
            config.unlink()
            directory.rmdir()
        path.rmdir()

    def settle(self, cookie, stopped):
        with self._locked() as state:
            record = state["leases"][cookie]
            if stopped:
                try:
                    self._remove_home(cookie, record)
                except (OSError, ValueError, OwnershipError, OSErrorCode):
                    stopped = False
            if stopped:
                state["leases"].pop(cookie)
            else:
                record["state"] = "HELD"
        return stopped

    async def recover(self):
        # Explicitly inspect persisted ownership. No extraction is replayed and
        # absence of a birth/ACK anchor never means that a process is absent.
        with self._locked() as state:
            now = int(time.time()*1000)
            state["queue"] = [v for v in state["queue"] if v["expiresMillis"] > now]
            records = {k: dict(v) for k, v in state["leases"].items()}
        for cookie, record in records.items():
            if not record["pid"] or not record["startIdentity"]:
                continue
            try:
                if record["state"] != "HELD":
                    owner = await self._probe("-o", "lstart=", "-p", str(record["ownerPid"]))
                    if owner == record["ownerBirth"]:
                        continue  # Another live worker still owns this call.
                current = await self.identity(record["pid"], cookie)
                if current is not None and current != record["startIdentity"]:
                    continue
                if current is not None:
                    os.killpg(record["pid"], signal.SIGKILL)
                deadline = time.monotonic()+3
                while self.group_exists(record["pid"]) and time.monotonic() < deadline:
                    await asyncio.sleep(.05)
                if not self.group_exists(record["pid"]):
                    self.settle(cookie, True)
            except (OSError, OwnershipError, OSErrorCode):
                continue
        return self.snapshot()
