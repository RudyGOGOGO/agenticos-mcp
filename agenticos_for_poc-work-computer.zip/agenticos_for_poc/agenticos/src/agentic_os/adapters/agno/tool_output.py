"""Model-facing structured output; persisted tool contracts remain unchanged.

JSON inside a string is not constrained decoding. Inline the answer/guidance
shape for the local model, then serialize only at the existing port boundary.
Source references are choices from accepted reads, never new authority.
"""
import copy
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.contracts.validation import schema_registry,validate_contract
from agentic_os.errors import OSErrorCode


def _object(properties):
    return dict(type='object',properties=properties,required=list(properties),additionalProperties=False)


def structured_schema(schema,payload):
    result=copy.deepcopy(schema);fields=[];tables=[]
    for read in payload['reads']:
        page=read['page'];ref=dict(type='string',enum=[read['readRef']])
        tables.append(_object(dict(kind=dict(type='string',enum=['table']),readRef=ref)))
        if page['records']:
            fields.append(_object(dict(kind=dict(type='string',enum=['field']),readRef=ref,
                rowIndex=dict(type='integer',minimum=0,maximum=len(page['records'])-1),
                fieldRef=dict(type='string',enum=page['evidence']['publicFields']))))
    text=_object(dict(kind=dict(type='string',enum=['text']),
        text=dict(type='string',minLength=1,maxLength=160,pattern=r'^[^0-9]*$')))
    selections=tables+fields
    if fields:
        selections.append(_object(dict(kind=dict(type='string',enum=['sentence']),
            parts=dict(type='array',minItems=1,maxItems=16,items=dict(anyOf=[text,*fields])))))
    answer=_object(dict(blocks=dict(type='array',minItems=1,maxItems=32,items=dict(anyOf=selections)))) if selections else None
    result['properties']['answerJson']=dict(anyOf=[dict(type='null'),answer]) if answer else dict(type='null')
    result['properties']['guidanceJson']=dict(anyOf=[dict(type='null'),copy.deepcopy(schema_registry()['$defs']['ToolGuidance'])])
    return result


def normalize_output(content,schema):
    from jsonschema import Draft202012Validator
    value=parse_canonical_json(content)
    if not Draft202012Validator(schema).is_valid(value):raise OSErrorCode('INVALID')
    for key in ('answerJson','guidanceJson'):
        value[key]='' if value[key] is None else canonical_bytes(value[key]).decode()
    validate_contract('ToolModelDraft',value)
    return canonical_bytes(value).decode()
