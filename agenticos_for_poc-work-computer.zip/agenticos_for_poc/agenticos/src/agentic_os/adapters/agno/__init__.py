"""Qualified one-shot Agno adapter; it never owns durability or authority."""
