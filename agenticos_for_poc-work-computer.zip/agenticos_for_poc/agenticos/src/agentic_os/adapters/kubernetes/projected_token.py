"""Dependency-free rotating token guard shared with the independent worker.

The worker mirror is emitted by the existing contract generation command.
Tokens grant no local authority; the configured remote service verifies them.
"""
import asyncio
import os
from pathlib import Path
import re
import stat


class ProjectedTokenReader:
    def __init__(self,root:Path,filename='token'):
        try:
            if (not isinstance(root,Path) or not root.is_absolute() or root.resolve()!=root
                    or type(filename) is not str or re.fullmatch(r'[a-z][a-z0-9-]{0,62}',filename) is None):
                raise ValueError()
            self.root,self.filename=root,filename
            self._directory()
        except Exception:raise ValueError('Invalid projected token configuration') from None

    def _directory(self):
        info=self.root.lstat()
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid not in {0,os.getuid()}
                or info.st_mode&0o022 or self.root.resolve()!=self.root):raise ValueError()

    def read(self):
        try:
            self._directory()
            target=(self.root/self.filename).resolve(strict=True)
            if not target.is_relative_to(self.root):raise ValueError()
            descriptor=os.open(target,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
            with os.fdopen(descriptor,'rb') as stream:
                info=os.fstat(stream.fileno())
                if (not stat.S_ISREG(info.st_mode) or info.st_uid not in {0,os.getuid()}
                        or info.st_mode&0o227 or info.st_nlink!=1 or not 32<=info.st_size<=8192):raise ValueError()
                raw=stream.read(8193)
            token=raw.decode('ascii')
            if not 32<=len(token)<=8192 or re.fullmatch(r'[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',token) is None:
                raise ValueError()
            return token
        except Exception:raise ValueError('Projected token unavailable') from None

    async def __call__(self):return await asyncio.to_thread(self.read)
