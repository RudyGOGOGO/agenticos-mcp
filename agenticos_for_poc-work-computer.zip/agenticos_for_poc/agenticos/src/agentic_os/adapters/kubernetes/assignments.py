"""Bounded existing Kubernetes Job/Pod APIs and standard attach v5.

No task payload or credential is put in an API object. The assigned worker
receives its original stdin ephemerally, then the standard stream-close frame.
Its existing stdout acknowledgement remains the delivery boundary.
"""
import asyncio
from contextlib import asynccontextmanager
import re
import ssl
from urllib.parse import urlsplit
from uuid import UUID

import httpx
from httpx_ws import aconnect_ws

from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.errors import OSErrorCode
from .workload import NAME

PROTOCOL='v5.channel.k8s.io'


class KubernetesAssignments:
    def __init__(self,*,installation_id,namespace,api_origin,token_provider,tls_context,network_transport=None):
        try:
            parsed=urlsplit(api_origin)
            if (type(installation_id) is not UUID or type(namespace) is not str or len(namespace)>63
                    or re.fullmatch(NAME,namespace) is None or type(api_origin) is not str
                    or parsed.scheme!='https' or not parsed.hostname or parsed.path or parsed.query or parsed.fragment
                    or parsed.username or parsed.password or any(c in api_origin for c in ('\\','%','\n','\r','\t'))
                    or parsed.port is not None and not 1<=parsed.port<=65535 or not callable(token_provider)
                    or not isinstance(tls_context,ssl.SSLContext) or not tls_context.check_hostname
                    or tls_context.verify_mode!=ssl.CERT_REQUIRED):raise ValueError()
        except Exception:raise ValueError('Explicit installation-scoped Kubernetes TLS assignment API required') from None
        self.installation_id,self.namespace,self.origin,self.token_provider=installation_id,namespace,api_origin,token_provider
        self.jobs='/apis/batch/v1/namespaces/'+namespace+'/jobs'
        self.pods='/api/v1/namespaces/'+namespace+'/pods'
        self.policies='/apis/networking.k8s.io/v1/namespaces/'+namespace+'/networkpolicies'
        self.bulkhead=asyncio.Semaphore(4)
        self.client=httpx.AsyncClient(verify=tls_context,trust_env=False,follow_redirects=False,timeout=3,
            limits=httpx.Limits(max_connections=4,max_keepalive_connections=4),
            transport=network_transport or httpx.AsyncHTTPTransport(verify=tls_context,retries=0))

    def _name(self,value):
        if type(value) is not str or not 1<=len(value)<=63 or re.fullmatch(NAME,value) is None:raise OSErrorCode('INVALID')
        return value

    async def _headers(self):
        token=await self.token_provider()
        if type(token) is not str or not 1<=len(token)<=8192 or not token.isascii() or any(c.isspace() for c in token):
            raise OSErrorCode('UNAUTHENTICATED')
        return {'Authorization':'Bearer '+token,'Content-Type':'application/json','Accept-Encoding':'identity'}

    async def _request(self,method,path,*,value=None,parameters=None):
        try:
            raw=None if value is None else canonical_bytes(value)
            if raw is not None and len(raw)>1048576:raise OSErrorCode('CAPACITY')
            async with asyncio.timeout(3):
                async with self.bulkhead:
                    headers=await self._headers()
                    self.client.cookies.clear()
                    async with self.client.stream(method,self.origin+path,content=raw,params=parameters,headers=headers) as response:
                        if 'set-cookie' in response.headers or response.headers.get('content-encoding','identity')!='identity':
                            raise OSErrorCode('DENIED')
                        if response.status_code==404:return None
                        if response.status_code==409:raise OSErrorCode('CONFLICT')
                        if response.status_code in {401,403}:raise OSErrorCode('DENIED')
                        if (response.status_code not in {200,201,202}
                                or not response.headers.get('content-type','').startswith('application/json')):
                            raise OSErrorCode('UNAVAILABLE')
                        output=bytearray()
                        async for chunk in response.aiter_bytes():
                            if len(output)+len(chunk)>1048576:raise OSErrorCode('CAPACITY')
                            output.extend(chunk)
                    result=parse_canonical_json(bytes(output))
                    if type(result) is not dict:raise OSErrorCode('UNAVAILABLE')
                    return result
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None

    async def job(self,name):return await self._request('GET',self.jobs+'/'+self._name(name))

    async def ensure_policy(self,policy):
        metadata=policy.get('metadata',{});name=self._name(metadata.get('name'))
        if (policy.get('apiVersion')!='networking.k8s.io/v1' or policy.get('kind')!='NetworkPolicy'
                or metadata.get('namespace')!=self.namespace
                or metadata.get('labels',{}).get('agentic-os.installation')!=str(self.installation_id)):
            raise OSErrorCode('DENIED')
        current=await self._request('GET',self.policies+'/'+name)
        if current is None:
            try:current=await self._request('POST',self.policies,value=policy)
            except OSErrorCode as exc:
                if exc.code!='CONFLICT':raise
                current=await self._request('GET',self.policies+'/'+name)
        if (current is None or current.get('spec')!=policy['spec']
                or any(current.get('metadata',{}).get(key)!=metadata[key]
                    for key in ('name','namespace','labels','annotations'))):raise OSErrorCode('CONFLICT')
        return current

    async def create(self,job):
        metadata=job.get('metadata',{})
        self._name(metadata.get('name'))
        if (job.get('apiVersion')!='batch/v1' or job.get('kind')!='Job' or metadata.get('namespace')!=self.namespace
                or metadata.get('labels',{}).get('agentic-os.installation')!=str(self.installation_id)):
            raise OSErrorCode('DENIED')
        return await self._request('POST',self.jobs,value=job)

    async def job_pods(self,job):
        metadata=job['metadata'];self._name(metadata['name'])
        uid=str(UUID(metadata['uid']))
        result=await self._request('GET',self.pods,parameters={'labelSelector':'batch.kubernetes.io/controller-uid='+uid,'limit':'4'})
        if (result is None or result.get('kind')!='PodList' or type(result.get('items')) is not list
                or len(result['items'])>4 or result.get('metadata',{}).get('continue')):raise OSErrorCode('UNAVAILABLE')
        return result['items']

    async def retire_terminal(self,job):
        metadata=job['metadata'];name=self._name(metadata['name']);uid=str(UUID(metadata['uid']))
        conditions=job.get('status',{}).get('conditions',[])
        if (metadata.get('namespace')!=self.namespace
                or metadata.get('labels',{}).get('agentic-os.installation')!=str(self.installation_id)
                or job.get('status',{}).get('active',0)!=0
                or not any(item.get('type') in {'Complete','Failed'} and item.get('status')=='True' for item in conditions)):
            raise OSErrorCode('DENIED')
        return await self._request('DELETE',self.jobs+'/'+name,value=dict(apiVersion='v1',kind='DeleteOptions',
            preconditions=dict(uid=uid),propagationPolicy='Foreground'))

    @asynccontextmanager
    async def attach(self,pod):
        metadata=pod['metadata'];name=self._name(metadata['name'])
        if (metadata.get('namespace')!=self.namespace
                or metadata.get('labels',{}).get('agentic-os.installation')!=str(self.installation_id)):
            raise OSErrorCode('DENIED')
        headers=await self._headers();self.client.cookies.clear()
        try:
            async with aconnect_ws(self.origin+self.pods+'/'+name+'/attach',client=self.client,
                    params={'container':'sdk','stdin':'true','stdout':'true','stderr':'true','tty':'false'},headers=headers,
                    subprotocols=[PROTOCOL],max_message_size_bytes=8193,queue_size=4,
                    keepalive_ping_interval_seconds=20,keepalive_ping_timeout_seconds=5) as stream:
                if (stream.subprotocol!=PROTOCOL or 'set-cookie' in stream.response.headers
                        or stream.response.headers.get('content-encoding','identity')!='identity'):
                    raise OSErrorCode('DENIED')
                yield stream
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None

    async def close(self):await self.client.aclose()
