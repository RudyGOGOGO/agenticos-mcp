"""Validated workload identity fragments for the existing EKS service roles.

These fragments provision nothing. Full image/node/network/storage manifests
and real API/RBAC/rotation qualification remain deployment requirements.
"""
import re
from uuid import UUID

from .workload import NAME


def workload_identity(installation_id,namespace,accounts):
    if (type(installation_id) is not str or str(UUID(installation_id))!=installation_id
            or type(namespace) is not str or len(namespace)>63 or re.fullmatch(NAME,namespace) is None
            or type(accounts) is not dict or set(accounts)!={'core','native','worker'}
            or any(type(name) is not str or len(name)>63 or re.fullmatch(NAME,name) is None for name in accounts.values())
            or len(set(accounts.values()))!=3):raise ValueError('Explicit installation, namespace and distinct role accounts required')
    audience='urn:agentic-os:'+installation_id+':private-rpc'
    role='aos-'+UUID(installation_id).hex+'-workload-review'
    resources=[dict(apiVersion='v1',kind='ServiceAccount',metadata=dict(name=name,namespace=namespace,
        labels={'agentic-os.installation':installation_id,'agentic-os.role':kind}),automountServiceAccountToken=False)
        for kind,name in accounts.items()]
    resources.extend([
        dict(apiVersion='rbac.authorization.k8s.io/v1',kind='ClusterRole',metadata=dict(name=role),
            rules=[dict(apiGroups=['authentication.k8s.io'],resources=['tokenreviews'],verbs=['create'])]),
        dict(apiVersion='rbac.authorization.k8s.io/v1',kind='ClusterRoleBinding',metadata=dict(name=role),
            roleRef=dict(apiGroup='rbac.authorization.k8s.io',kind='ClusterRole',name=role),
            subjects=[dict(kind='ServiceAccount',name=accounts[kind],namespace=namespace) for kind in ('core','native')])])
    patches={}
    for kind,name in accounts.items():
        token=dict(path='token',expirationSeconds=3600)
        if kind=='worker':token['audience']=audience
        sources=[dict(serviceAccountToken=token)]
        if kind!='worker':sources.append(dict(configMap=dict(name='kube-root-ca.crt',items=[dict(key='ca.crt',path='ca.crt')])) )
        patches[kind]=dict(serviceAccountName=name,automountServiceAccountToken=False,
            securityContext=dict(fsGroup=1000,fsGroupChangePolicy='OnRootMismatch'),
            volumes=[dict(name='aos-workload',projected=dict(defaultMode=0o440,sources=sources))])
    return dict(version=1,audience=audience,
        resources=dict(apiVersion='v1',kind='List',items=resources),podSpecs=patches,
        containerMount=dict(name='aos-workload',mountPath='/var/run/agentic-os/workload',readOnly=True))


def aws_workload_identity(installation_id,namespace,accounts,*,account,region,issuer_id,additional_workers=()):
    """Add separate STS projections and exact IAM trust inputs; provision nothing."""
    from agentic_os.adapters.aws.workload import role_arn
    value=workload_identity(installation_id,namespace,accounts)
    if (type(additional_workers) not in {list,tuple} or len(additional_workers)>63
            or any(type(name) is not str or len(name)>63 or re.fullmatch(NAME,name) is None
                or name in accounts.values() for name in additional_workers)
            or len(set(additional_workers))!=len(additional_workers)):
        raise ValueError('Explicit distinct additional worker accounts required')
    # The locked Linux images use /run directly; /var/run is a symlink and
    # the rotating reader requires a canonical configured mount root.
    value['containerMount']['mountPath']='/run/agentic-os/workload'
    role_arn(UUID(installation_id),account,'core')
    if (type(region) is not str or re.fullmatch(r'[a-z]{2}(?:-[a-z]+)+-[0-9]+',region) is None
            or region.startswith(('cn-','us-gov-','us-iso'))
            or type(issuer_id) is not str or re.fullmatch(r'[A-Za-z0-9]{32,64}',issuer_id) is None):
        raise ValueError('Explicit EKS OIDC issuer required')
    issuer='oidc.eks.'+region+'.amazonaws.com/id/'+issuer_id
    provider='arn:aws:iam::'+account+':oidc-provider/'+issuer
    identity={}
    for kind,name in accounts.items():
        arn=role_arn(UUID(installation_id),account,kind)
        value['podSpecs'][kind]['volumes'].append(dict(name='aos-aws-workload',projected=dict(defaultMode=0o440,
            sources=[dict(serviceAccountToken=dict(path='token',expirationSeconds=3600,audience='sts.amazonaws.com'))])))
        identity[kind]=dict(roleArn=arn,region=region,tokenRoot='/run/agentic-os/aws-workload',
            trustPolicy=dict(Version='2012-10-17',Statement=[dict(Effect='Allow',
                Principal=dict(Federated=provider),Action='sts:AssumeRoleWithWebIdentity',
                Condition=dict(StringEquals={issuer+':aud':'sts.amazonaws.com',
                    issuer+':sub':'system:serviceaccount:'+namespace+':'+name}))]))
    value['aws']=identity
    if additional_workers:
        value['additionalWorkerPodSpecs']={name:dict(value['podSpecs']['worker'],serviceAccountName=name)
            for name in additional_workers}
        value['resources']['items'].extend(dict(apiVersion='v1',kind='ServiceAccount',metadata=dict(
            name=name,namespace=namespace,labels={'agentic-os.installation':installation_id,'agentic-os.role':'worker'}),
            automountServiceAccountToken=False) for name in additional_workers)
        # One functional AWS worker role, with an explicit closed set of
        # principals. Private RPC still maps each current SA UID to one app.
        identity['worker']['trustPolicy']['Statement'][0]['Condition']['StringEquals'][issuer+':sub']=[
            'system:serviceaccount:'+namespace+':'+name for name in (accounts['worker'],*additional_workers)]
    value['awsContainerMount']=dict(name='aos-aws-workload',mountPath='/run/agentic-os/aws-workload',readOnly=True)
    return value


def native_role_resources(document):
    """Render only the explicitly configured single-model native deployment.

    This pure operator function provisions nothing. Existing prepared private
    PVCs, attested native node/owner, network policy enforcement, signed control
    release and real AWS qualification are independent prerequisites.
    """
    from copy import deepcopy
    import hashlib
    from pathlib import PurePosixPath
    from agentic_os.adapters.configured_installation import closed
    from agentic_os.contracts.canonical import canonical_bytes
    from agentic_os.production.native_service import configuration
    try:
        value=deepcopy(document)
        closed(value,{'schema','installation_id','namespace','account','region','issuer_id','accounts','images',
            'configurations','configuration_claims','installation_claim','native_home','native_node'})
        if value['schema']!='agent-eks-native-role-deployment/1':raise ValueError()
        installation=value['installation_id'];namespace=value['namespace'];ident=UUID(installation)
        selected={role:configuration(raw) for role,raw in value['configurations'].items()}
        assignments=selected['core']['workload']['assignments']
        worker_prefix='system:serviceaccount:'+namespace+':'
        worker_names={name.removeprefix(worker_prefix) for name in assignments}
        if (not 1<=len(assignments)<=64 or any(not name.startswith(worker_prefix) for name in assignments)
                or value['accounts']['worker'] not in worker_names
                or worker_names & {value['accounts']['core'],value['accounts']['native']}
                or len({item['application_id'] for item in assignments.values()})!=len(assignments)
                or len({item['uid'] for item in assignments.values()})!=len(assignments)):
            raise ValueError()
        identity=aws_workload_identity(installation,namespace,value['accounts'],account=value['account'],
            region=value['region'],issuer_id=value['issuer_id'],
            additional_workers=sorted(worker_names-{value['accounts']['worker']}))
        closed(value['images'],{'core','native','sdk'})
        prefix=value['account']+'.dkr.ecr.'+value['region']+'.amazonaws.com/agentic-os/'+installation+'/'
        for role,image in value['images'].items():
            if type(image) is not str or re.fullmatch(re.escape(prefix+role)+r'@sha256:[a-f0-9]{64}',image) is None:raise ValueError()
        closed(value['configurations'],{'core','native'});closed(value['configuration_claims'],{'core','native'})
        def name(value):
            if type(value) is not str or len(value)>63 or re.fullmatch(NAME,value) is None:raise ValueError()
            return value
        name(value['installation_claim'])
        if len(set([value['installation_claim'],*value['configuration_claims'].values()]))!=3:raise ValueError()
        for claim in value['configuration_claims'].values():name(claim)
        node_name=value['native_node']
        if (type(node_name) is not str or len(node_name)>253
                or any(len(part)>63 or re.fullmatch(NAME,part) is None for part in node_name.split('.'))):raise ValueError()
        home=PurePosixPath(value['native_home'])
        expected=PurePosixPath('/srv/agentic-os')/installation/'native'
        if str(home)!=value['native_home'] or home!=expected:raise ValueError()
        root=str(PurePosixPath(selected['core']['installation']['manifest']).parent)
        if root not in {'/run/agentic-os/installation','/mnt/agentic-os/installation'}:raise ValueError()

        for role,config in selected.items():
            backend=config['installation']
            if (config['role']!=role or backend['provider']!='aws-eks' or backend['manifest']!=root+'/manifest.json'
                    or backend['aws']['account']!=value['account'] or backend['aws']['region']!=value['region']
                    or backend['aws']['role']!=role or backend['aws']['token_root']!=identity['aws'][role]['tokenRoot']
                    or config['listen']!={'host':'0.0.0.0','port':8443}
                    or config['workload']['kind']!='kubernetes-tokenreview'
                    or config['workload']['audience']!=identity['audience']
                    or set(config['workload']['assignments'])!=set(assignments)
                    or config['workload']['reviewer_root']!=identity['containerMount']['mountPath']
                    or config['catalog']['host']['installationId']!=installation):raise ValueError()
            # Configuration/CA/key files come from the operator-prepared
            # private claim, not Kubernetes atomic-writer symlink paths.
            paths=[config['catalog']['cursor_key_file'],backend['aws']['postgres']['ca'],config['workload']['ca'],
                config['tls']['certificate_file'],config['tls']['key_file']]
            if any(not any(PurePosixPath(path).is_relative_to(base) for base in
                    ('/run/agentic-os/config',root+'/config')) for path in paths):raise ValueError()
        core,native=selected['core'],selected['native']
        if core['installation']['aws'].get('private_files')!=native['installation']['aws'].get('private_files'):
            raise ValueError()
        if (core['installation']['aws'].get('private_files')=='aws-shared-private65534/1'
                and native['installation']['aws'].get('control_binding')!=core['installation']):raise ValueError()
        for field in ('os_origin','catalog','readers','history','workload'):
            if core[field]!=native[field]:raise ValueError()
        if (core['native']['profile']!=native['native']['profile'] or native['native']['sandbox']!=dict(
                kind='firecracker',home=str(home),capacity_root=str(home.parent/'capacity'))):raise ValueError()
        # The immutable native runtime/profile is already validated by the
        # configured service against the actual node before acquiring a lease.
        labels={'agentic-os.installation':installation}
        resources=[dict(apiVersion='v1',kind='Namespace',metadata=dict(name=namespace,labels={
            'agentic-os.installation':installation,'pod-security.kubernetes.io/enforce':'privileged',
            'pod-security.kubernetes.io/audit':'restricted','pod-security.kubernetes.io/warn':'restricted'}))]+deepcopy(identity['resources']['items'])
        services={};pins={}
        for role in ('core','native'):
            workload='aos-'+ident.hex+'-'+role
            role_labels=labels|{'agentic-os.role':role}
            pins[role]=hashlib.sha256(canonical_bytes(selected[role])).hexdigest()
            shared=selected[role]['installation']['aws'].get('private_files')=='aws-shared-private65534/1'
            # Group0 reads the root-owned0440 projected tokens. No fsGroup
            # mutation may widen private claim modes; data access uses UID.
            security=(dict(runAsUser=65534,runAsGroup=0,runAsNonRoot=True) if role=='core' and shared
                else dict(runAsUser=0,runAsGroup=0,runAsNonRoot=False))
            container_security=(dict(privileged=True) if role=='native' else
                dict(allowPrivilegeEscalation=False,readOnlyRootFilesystem=True,capabilities=dict(drop=['ALL']),
                    seccompProfile=dict(type='RuntimeDefault')))
            volumes=deepcopy(identity['podSpecs'][role]['volumes'])+[
                dict(name='installation',persistentVolumeClaim=dict(claimName=value['installation_claim'])),
                dict(name='configuration',persistentVolumeClaim=dict(claimName=value['configuration_claims'][role],readOnly=True)),
                dict(name='temporary',emptyDir=dict(medium='Memory',sizeLimit='64Mi'))]
            mounts=[identity['containerMount'],identity['awsContainerMount'],
                dict(name='installation',mountPath=root),dict(name='configuration',mountPath='/run/agentic-os/config',readOnly=True),
                dict(name='temporary',mountPath='/tmp')]
            node={'kubernetes.io/arch':'arm64','kubernetes.io/os':'linux'}
            pod=dict(serviceAccountName=value['accounts'][role],automountServiceAccountToken=False,
                securityContext=security,hostNetwork=False,hostPID=False,hostIPC=False,nodeSelector=node,
                volumes=volumes,containers=[dict(name=role,image=value['images'][role],imagePullPolicy='IfNotPresent',
                    command=['agentic-os'],args=['agent-native-serve','--service-role',role,'--role-config',
                        '/run/agentic-os/config/role.json','--role-config-sha256',pins[role]],
                    securityContext=container_security,ports=[dict(name='private-rpc',containerPort=8443,protocol='TCP')],
                    volumeMounts=deepcopy(mounts),resources=dict(requests=dict(cpu='1',memory='1Gi'),limits=dict(cpu='2',memory='2Gi')))])
            if role=='native':
                pod['nodeName']=node_name
                pod['nodeSelector']['agentic-os.native.installation']=installation
                pod['tolerations']=[dict(key='agentic-os.native',operator='Equal',value=installation,effect='NoSchedule')]
                volumes.extend([dict(name='native-owner',hostPath=dict(path=str(home),type='Directory')),
                    dict(name='native-capacity',hostPath=dict(path=str(home.parent/'capacity'),type='Directory')),
                    dict(name='kvm',hostPath=dict(path='/dev/kvm',type='CharDevice')),
                    dict(name='cgroup',hostPath=dict(path='/sys/fs/cgroup',type='Directory'))])
                pod['containers'][0]['volumeMounts'].extend([dict(name='native-owner',mountPath=str(home)),
                    dict(name='native-capacity',mountPath=str(home.parent/'capacity')),
                    dict(name='kvm',mountPath='/dev/kvm'),dict(name='cgroup',mountPath='/sys/fs/cgroup')])
            # One exact node and one controller for this installation. A
            # replicated/DaemonSet service could route an unfinished attempt
            # to an unrelated host ledger and duplicate a physical placement.
            spec=dict(replicas=1,selector=dict(matchLabels=role_labels),strategy=dict(type='Recreate'),
                template=dict(metadata=dict(labels=role_labels),spec=pod));kind='Deployment'
            if role=='core' and 'stores' in core['installation']['aws']:
                # A pathname Unix socket on EFS cannot connect different hosts.
                # Keep the supported embedding process and private IPC in this
                # exact Pod; durable model/keys/artifacts remain on the claim.
                # No second public server, workflow engine or runtime balance.
                pod['shareProcessNamespace']=True
                pod['volumes'].append(dict(name='embedding-ipc',emptyDir=dict(medium='Memory',sizeLimit='16Mi')))
                ipc=dict(name='embedding-ipc',mountPath=root+'/embed')
                pod['containers'][0]['volumeMounts'].append(ipc)
                pod['initContainers']=[dict(name='private-embedding-ipc',image=value['images']['core'],
                    command=['python','-I','-B','-c','import os,sys; os.chmod(sys.argv[1],0o700)'],
                    args=[root+'/embed'],securityContext=deepcopy(container_security),volumeMounts=[ipc])]
                if shared:
                    init=pod['initContainers'][0]
                    init['command'][-1]=('import pathlib,sys; from agentic_os.adapters.embedding.rpc import prepare_shared_ipc; '
                        'prepare_shared_ipc(pathlib.Path(sys.argv[1]))')
                    init['securityContext'].update(runAsUser=0,runAsGroup=0,runAsNonRoot=False,
                        capabilities=dict(drop=['ALL'],add=['CHOWN']))
                pod['initContainers'].append(dict(name='embedding',image=value['images']['core'],restartPolicy='Always',
                    command=['python','-I','-B','-m','agentic_os.production.embedding_service'],
                    args=['--manifest',root+'/manifest.json','--operator-key',root+'/operator.key'],
                    startupProbe=dict(exec_={'command':['python','-I','-B','-c',
                        'import pathlib,sys; sys.exit(0 if pathlib.Path(sys.argv[1]).is_socket() else 1)',root+'/embed/s']},
                        periodSeconds=1,failureThreshold=60),
                    securityContext=deepcopy(container_security),volumeMounts=[deepcopy(mount) for mount in
                        pod['containers'][0]['volumeMounts'] if mount['name'] in {'installation','temporary','embedding-ipc'}],
                    resources=dict(requests=dict(cpu='250m',memory='256Mi'),limits=dict(cpu='2',memory='768Mi'))))
                probe=pod['initContainers'][-1]['startupProbe'];probe['exec']=probe.pop('exec_')
            resources.append(dict(apiVersion='apps/v1',kind=kind,metadata=dict(name=workload,namespace=namespace,labels=role_labels),spec=spec))
            resources.append(dict(apiVersion='v1',kind='Service',metadata=dict(name=workload,namespace=namespace,labels=role_labels),
                spec=dict(type='ClusterIP',selector=role_labels,ports=[dict(name='private-rpc',port=8443,targetPort='private-rpc',protocol='TCP')])))
            # No public ingress, load balancer, host networking or node port.
            resources.append(dict(apiVersion='networking.k8s.io/v1',kind='NetworkPolicy',
                metadata=dict(name=workload,namespace=namespace),spec=dict(podSelector=dict(matchLabels=role_labels),
                    policyTypes=['Ingress','Egress'],ingress=[dict(from_=[dict(podSelector=dict(matchLabels=labels|{'agentic-os.role':'worker'}))],
                        ports=[dict(protocol='TCP',port=8443)])],egress=[dict(ports=[dict(protocol='UDP',port=53),dict(protocol='TCP',port=53)]),
                        dict(to=[dict(ipBlock=dict(cidr='0.0.0.0/0',**{'except':['169.254.0.0/16']})),
                            dict(ipBlock=dict(cidr='::/0',**{'except':['fe80::/10','fd00:ec2::254/128']}))],
                            ports=[dict(protocol='TCP',port=port) for port in sorted(role_ports(selected[role]))])])) )
            # Python reserves "from"; emit the actual Kubernetes field.
            resources[-1]['spec']['ingress'][0]['from']=resources[-1]['spec']['ingress'][0].pop('from_')
            services[role]='https://'+workload+'.'+namespace+'.svc:8443'
        return dict(schema='agent-eks-native-role-plan/1',resources=dict(apiVersion='v1',kind='List',items=resources),
            iamTrust=identity['aws'],configurationSHA256=pins,privateOrigins=services,
            nativeNodeRequirements=dict(name=node_name,installation=installation,home=str(home),kvm='/dev/kvm',cgroup='/sys/fs/cgroup',
                capacityRoot=str(home.parent/'capacity'),
                quiescenceRequiredBeforeNodeOrOwnerReplacement=True),
            sdkRPCTrust='The assigned worker rpcTLS must pin the private service CA and validate these service DNS names',
            sdkImage=value['images']['sdk'],sdkWorkloadIdentity=identity['podSpecs']['worker'],
            sdkApplicationWorkloadIdentities={item['application_id']:(identity['podSpecs']['worker']
                if name==worker_prefix+value['accounts']['worker'] else identity['additionalWorkerPodSpecs'][name.removeprefix(worker_prefix)])
                for name,item in assignments.items()},
            sdkMounts=[identity['containerMount'],identity['awsContainerMount']],
            qualification='Configuration artifacts only; prepared storage/node/keys, actual image/service/platform and AWS/Cloud qualification remain required',
            productionAdmissionEnabled=False)
    except Exception:raise ValueError('Invalid explicit EKS native role deployment') from None


def role_ports(config):
    from urllib.parse import urlsplit
    from agentic_os.production.native_service import catalog_hosts
    scopes=catalog_hosts(config['catalog'])
    for reader in config['readers']:
        scopes.extend([reader['profile']['read']['host'],reader['policy'],reader['observation'],reader['observation_policy']])
    scopes.extend({'url':entry['policy']['origin']} for entry in config.get('preparations',[]))
    if 'proactivity' in config:
        settings=config['proactivity']
        policies=settings['read_policies'].values() if 'read_policies' in settings else [settings['read_policy']]
        scopes.extend({'url':policy['origin']} for policy in policies)
    return {443,config['installation']['aws']['postgres']['port'],urlsplit(config['workload']['api_origin']).port or 443}|{urlsplit(scope['url']).port or 443 for scope in scopes}


def assigned_worker_job(document):
    """Plan one original assigned worker; Kubernetes retries grant no work.

    Core/Temporal still own admission, immutable start, current controls and
    execution. The private PVC supplies the existing configuration/start files;
    neither secret bytes nor task text appear in Kubernetes objects or logs.
    """
    from copy import deepcopy
    from agentic_os.adapters.configured_installation import closed
    from agentic_os.contracts.validation import validate_contract
    from agentic_os.identity.context import utcnow,timestamp
    try:
        value=deepcopy(document);closed(value,{'schema','deployment','context','assignment_claim'})
        if value['schema']!='agent-eks-assigned-native-worker/1':raise ValueError()
        deployment=value['deployment'];plan=native_role_resources(deployment);context=value['context']
        validate_contract('AgentTaskContext',context)
        claim=value['assignment_claim']
        if (type(claim) is not str or len(claim)>63 or re.fullmatch(NAME,claim) is None
                or claim in {deployment['installation_claim'],*deployment['configuration_claims'].values()}):raise ValueError()
        assignments=deployment['configurations']['core']['workload']['assignments']
        assignment=next(item for item in assignments.values()
            if item['application_id']==context['subject']['applicationId'])
        if (context['subject']['installationId']!=deployment['installation_id']
                or context['subject']['applicationId']!=assignment['application_id']
                or context['model']['digest']!=assignment['model_digest']):raise ValueError()
        remaining=int((timestamp(context['authorizationHorizon'])-utcnow()).total_seconds())
        if not 1<=remaining<=2**31-1:raise ValueError()
        installation=UUID(deployment['installation_id']);task=UUID(context['taskId'])
        name='aos-'+installation.hex[:12]+'-sdk-'+task.hex
        labels={'agentic-os.installation':str(installation),'agentic-os.role':'worker','agentic-os.task':str(task)}
        pod=deepcopy(plan['sdkApplicationWorkloadIdentities'][context['subject']['applicationId']])
        pod.update(restartPolicy='Never',hostNetwork=False,hostPID=False,hostIPC=False,
            nodeSelector={'kubernetes.io/arch':'arm64','kubernetes.io/os':'linux'},
            securityContext=dict(runAsUser=65534,runAsGroup=1000,runAsNonRoot=True,fsGroup=1000,fsGroupChangePolicy='OnRootMismatch'))
        if deployment['configurations']['core']['installation']['aws'].get('private_files')=='aws-shared-private65534/1':
            pod['securityContext']=dict(runAsUser=65534,runAsGroup=0,runAsNonRoot=True)
        pod['volumes'].extend([dict(name='assignment',persistentVolumeClaim=dict(claimName=claim,readOnly=True)),
            dict(name='temporary',emptyDir=dict(medium='Memory',sizeLimit='64Mi'))])
        pod['containers']=[dict(name='sdk',image=deployment['images']['sdk'],imagePullPolicy='IfNotPresent',
            command=['python','-I','-B','-m','agentic_os_agent_worker.task_service'],
            args=['--configuration','/run/agentic-os/config/assigned.json','--start-file','/run/agentic-os/config/start.json'],
            securityContext=dict(allowPrivilegeEscalation=False,readOnlyRootFilesystem=True,capabilities=dict(drop=['ALL']),
                seccompProfile=dict(type='RuntimeDefault')),
            env=[dict(name=key,value=item) for key,item in dict(HOME='/tmp',TMPDIR='/tmp',
                PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',OPENAI_AGENTS_DISABLE_TRACING='1',AGNO_TELEMETRY='false').items()],
            volumeMounts=deepcopy(plan['sdkMounts'])+[dict(name='assignment',mountPath='/run/agentic-os/config',readOnly=True),
                dict(name='temporary',mountPath='/tmp')],
            resources=dict(requests=dict(cpu='1',memory='1Gi'),limits=dict(cpu='2',memory='2Gi')))]
        from agentic_os.production.planning_scope import HARNESS_PREFIX
        if context['harness']['ref'].startswith(HARNESS_PREFIX):
            # One Pod/SA owns this workflow, with two separately reviewed
            # audience tokens. Provider credentials and encrypted histories
            # remain in the immutable private worker claim, never the Job.
            workload=deployment['configurations']['core']['workload']
            principal=next(name for name,item in workload['assignments'].items()
                if item['application_id']==context['subject']['applicationId'])
            planner=workload['planner'];private=planner['assignments'][principal]
            policies=deployment['configurations']['core'].get('knowledge',{}).get('policies',[])
            selected=[policy['knowledge'] for policy in policies if policy['knowledge']['applicationId']==assignment['application_id']
                and policy['knowledge']['harness']==context['harness']]
            if (len(selected)!=1 or selected[0]['planning']['publicModel']!=context['model']
                    or selected[0]['planning']['plannerModel']['digest']!=private['model_digest']
                    or selected[0]['planning']['plannerMeterDigest']!=private['meter_digest']):raise ValueError()
            pod['volumes'].append(dict(name='aos-planner-workload',projected=dict(defaultMode=0o440,
                sources=[dict(serviceAccountToken=dict(path='token',expirationSeconds=3600,audience=planner['audience']))])))
            pod['containers'][0]['volumeMounts'].append(dict(name='aos-planner-workload',
                mountPath='/run/agentic-os/planner-workload',readOnly=True))
        job=dict(apiVersion='batch/v1',kind='Job',metadata=dict(name=name,namespace=deployment['namespace'],labels=labels,
            annotations={'agentic-os.original-root':context['rootId'],'agentic-os.original-horizon':context['authorizationHorizon']}),
            spec=dict(backoffLimit=0,activeDeadlineSeconds=remaining,template=dict(metadata=dict(labels=labels),spec=pod)))
        policy=dict(apiVersion='networking.k8s.io/v1',kind='NetworkPolicy',metadata=dict(name=name,namespace=deployment['namespace']),
            spec=dict(podSelector=dict(matchLabels=labels),policyTypes=['Ingress','Egress'],ingress=[],
                egress=[dict(ports=[dict(protocol='UDP',port=53),dict(protocol='TCP',port=53)]),
                    dict(to=[dict(podSelector=dict(matchLabels={'agentic-os.installation':str(installation),'agentic-os.role':role}))
                        for role in ('core','native')],ports=[dict(protocol='TCP',port=8443)]),
                    dict(to=[dict(ipBlock=dict(cidr='0.0.0.0/0',**{'except':['169.254.0.0/16']})),
                        dict(ipBlock=dict(cidr='::/0',**{'except':['fe80::/10','fd00:ec2::254/128']}))],
                        ports=[dict(protocol='TCP',port=443),dict(protocol='TCP',port=7233)])]))
        return dict(schema='agent-eks-assigned-native-worker-plan/1',resources=dict(apiVersion='v1',kind='List',items=[job,policy]),
            originalRootId=context['rootId'],originalAuthorizationHorizon=context['authorizationHorizon'],
            productionAdmissionEnabled=False,qualification='One worker placement configuration only; original Core/Temporal authority and UNKNOWN holds unchanged. Actual image/platform/Cloud and complete deployment qualification remain open.')
    except Exception:raise ValueError('Invalid original EKS worker assignment') from None


def assigned_worker_stdio_job(document):
    """Use the installed worker's existing stdin/EOF entry over attach v5.

    The pre-provisioned worker-only claim contains private configuration. Core
    receives only its reviewed hash and sends the original start ephemerally;
    no task payload, history key or provider secret enters a Kubernetes object.
    """
    from copy import deepcopy
    from agentic_os.adapters.configured_installation import closed
    try:
        value=deepcopy(document)
        closed(value,{'schema','deployment','context','configuration_claim','configuration_sha256','input_digest'})
        if value['schema']!='agent-eks-assigned-stdio-worker/1':raise ValueError()
        for key in ('configuration_sha256','input_digest'):
            if type(value[key]) is not str or re.fullmatch('[a-f0-9]{64}',value[key]) is None:raise ValueError()
        plan=assigned_worker_job(dict(schema='agent-eks-assigned-native-worker/1',deployment=value['deployment'],
            context=value['context'],assignment_claim=value['configuration_claim']))
        job=plan['resources']['items'][0];pod=job['spec']['template'];container=pod['spec']['containers'][0]
        container.update(stdin=True,stdinOnce=True,tty=False,
            args=['--configuration','/run/agentic-os/config/assigned.json','--configuration-sha256',value['configuration_sha256']])
        pins={'agentic-os.configuration-sha256':value['configuration_sha256'],'agentic-os.input-digest':value['input_digest']}
        job['metadata']['annotations'].update(pins)
        pod['metadata']['annotations']=dict(job['metadata']['annotations'])
        policy=plan['resources']['items'][1]
        policy['metadata']['labels']=dict(job['metadata']['labels'])
        policy['metadata']['annotations']=dict(job['metadata']['annotations'])
        plan['schema']='agent-eks-assigned-stdio-worker-plan/1'
        plan['streamProtocol']='v5.channel.k8s.io'
        return plan
    except Exception:raise ValueError('Invalid original EKS stdin worker assignment') from None


def prepare_native_role_configurations(document,destination):
    """Write exact private role bytes after validating the whole deployment.

    Existing output is never adopted or overwritten. A partial failed prepare
    is not a ready bundle; plan.json is written last. No service is stopped and
    no native ownership, SQL connection or cloud resource is acquired.
    """
    from pathlib import Path
    from agentic_os.adapters.configured_installation import canonical_file
    from agentic_os.adapters.local.files import private_directory,private_write
    from agentic_os.contracts.canonical import canonical_bytes
    plan=native_role_resources(document)
    destination=canonical_file(str(destination))
    if destination.exists() or destination.is_symlink():raise ValueError('New private configuration destination required')
    raw={role:canonical_bytes(document['configurations'][role]) for role in ('core','native')}
    private_directory(destination)
    for role,content in raw.items():
        directory=destination/role;private_directory(directory);private_write(directory/'role.json',content)
    private_write(destination/'plan.json',canonical_bytes(plan))
    return plan|dict(configurationRoot=str(destination))


def public_role_resources(document):
    """Render the same Core as a public service; provision no AWS resources.

    An explicit ALB controller ingress is added to the existing private native
    role plan. Network-policy CIDRs are reviewed ALB subnet ranges, not client
    identity. Current DPoP/Host authority still gates every public operation.
    """
    from copy import deepcopy
    import hashlib
    import ipaddress
    from urllib.parse import urlsplit
    from agentic_os.adapters.configured_installation import closed
    from agentic_os.contracts.canonical import canonical_bytes
    from agentic_os.production.public_service import configuration
    try:
        closed(document,{'schema','service','ingress'}|({'privacy_journal_claim'} if 'privacy_journal_claim' in document else set()))
        if document['schema']!='agent-eks-public-role-deployment/1':raise ValueError()
        service=configuration(document['service']);worker=service['worker']
        if worker['kind']!='eks-assigned':raise ValueError()
        deployment=worker['deployment'];plan=native_role_resources(deployment)
        ingress=deepcopy(document['ingress']);closed(ingress,{'scheme','certificate_arn','subnets','subnet_cidrs','client_cidrs'})
        if (ingress['scheme'] not in {'internal','internet-facing'}
                or type(ingress['certificate_arn']) is not str
                or re.fullmatch('arn:aws:acm:'+re.escape(deployment['region'])+':'+deployment['account']+
                    r':certificate/[a-f0-9-]{36}',ingress['certificate_arn']) is None):raise ValueError()
        certificate=ingress['certificate_arn'].rsplit('/',1)[1]
        if str(UUID(certificate))!=certificate:raise ValueError()
        if (type(ingress['subnets']) is not list or not 2<=len(ingress['subnets'])<=8
                or len(set(ingress['subnets']))!=len(ingress['subnets'])
                or any(type(item) is not str or re.fullmatch(r'subnet-(?:[a-f0-9]{8}|[a-f0-9]{17})',item) is None for item in ingress['subnets'])):raise ValueError()
        for key in ('subnet_cidrs','client_cidrs'):
            values=ingress[key]
            if type(values) is not list or not 1<=len(values)<=16 or len(set(values))!=len(values):raise ValueError()
            for item in values:
                network=ipaddress.ip_network(item,strict=True)
                if str(network)!=item or network.version!=4 or key=='subnet_cidrs' and (not network.is_private or network.prefixlen<16):raise ValueError()
        origin=urlsplit(service['core']['os_origin'])
        if origin.scheme!='https' or origin.port not in (None,443):raise ValueError()
        pin=hashlib.sha256(canonical_bytes(service)).hexdigest();namespace=deployment['namespace']
        name='aos-'+UUID(deployment['installation_id']).hex+'-core'
        items=plan['resources']['items']
        core=next(item for item in items if item['kind']=='Deployment' and item['metadata']['name']==name)
        core['spec']['template']['metadata']['annotations']={'agentic-os.configuration-sha256':pin}
        core['spec']['template']['spec']['containers'][0]['args']=['agent-public-serve','--role-config',
            '/run/agentic-os/config/role.json','--role-config-sha256',pin]
        private_context=service['core'].get('knowledge',service['core'].get('memory'))
        if private_context is not None:
            claim=document.get('privacy_journal_claim')
            reserved={deployment['installation_claim'],*deployment['configuration_claims'].values()}
            reserved.update(binding['claim'] for binding in worker.get('configurations',{}).values())
            if 'configuration_claim' in worker:reserved.add(worker['configuration_claim'])
            if (type(claim) is not str or len(claim)>63 or re.fullmatch(NAME,claim) is None
                    or claim in reserved or private_context['journal_root']!='/run/agentic-os/privacy-journal'):raise ValueError()
            pod=core['spec']['template']['spec']
            pod['volumes'].append(dict(name='privacy-journal',persistentVolumeClaim=dict(claimName=claim)))
            pod['containers'][0]['volumeMounts'].append(dict(name='privacy-journal',mountPath=private_context['journal_root']))
        elif 'privacy_journal_claim' in document:raise ValueError()
        policy=next(item for item in items if item['kind']=='NetworkPolicy' and item['metadata']['name']==name)
        policy['spec']['ingress'].append({'from':[dict(ipBlock=dict(cidr=item)) for item in ingress['subnet_cidrs']],
            'ports':[dict(protocol='TCP',port=8443)]})
        policy['spec']['egress'][-1]['ports'].append(dict(protocol='TCP',port=7233))
        from agentic_os.production.public_service import applications_for,review_bindings
        if applications_for(service,'agent-reviewed-change-journey/1'):
            ports={item['port'] for item in policy['spec']['egress'][-1]['ports']}
            ports.update(urlsplit(settings['repair_policy']['origin']).port or 443
                for settings in review_bindings(service).values() if 'repair_policy' in settings)
            policy['spec']['egress'][-1]['ports']=[dict(protocol='TCP',port=port) for port in sorted(ports)]
        role=name+'-assignments'
        items.extend([
            dict(apiVersion='rbac.authorization.k8s.io/v1',kind='Role',metadata=dict(name=role,namespace=namespace),rules=[
                dict(apiGroups=['batch'],resources=['jobs'],verbs=['get','create','delete']),
                dict(apiGroups=[''],resources=['pods'],verbs=['get','list']),
                dict(apiGroups=[''],resources=['pods/attach'],verbs=['get','create']),
                dict(apiGroups=['networking.k8s.io'],resources=['networkpolicies'],verbs=['get','create'])]),
            dict(apiVersion='rbac.authorization.k8s.io/v1',kind='RoleBinding',metadata=dict(name=role,namespace=namespace),
                roleRef=dict(apiGroup='rbac.authorization.k8s.io',kind='Role',name=role),
                subjects=[dict(kind='ServiceAccount',name=deployment['accounts']['core'],namespace=namespace)])])
        prefix='alb.ingress.kubernetes.io/'
        annotations={prefix+key:value for key,value in {
            'scheme':ingress['scheme'],'target-type':'ip','backend-protocol':'HTTPS','backend-protocol-version':'HTTP1',
            'listen-ports':'[{"HTTPS":443}]','certificate-arn':ingress['certificate_arn'],
            'ssl-policy':'ELBSecurityPolicy-TLS13-1-2-2021-06','subnets':','.join(ingress['subnets']),
            'inbound-cidrs':','.join(ingress['client_cidrs']),'healthcheck-protocol':'HTTPS','healthcheck-path':'/os/readiness',
            'success-codes':'200'}.items()}
        path=dict(path='/',pathType='Prefix',backend=dict(service=dict(name=name,port=dict(number=8443))))
        rule=dict(host=origin.hostname,http=dict(paths=[path]))
        items.append(dict(apiVersion='networking.k8s.io/v1',kind='Ingress',metadata=dict(name=name,namespace=namespace,
            annotations=annotations),spec=dict(ingressClassName='alb',rules=[rule])))
        plan.update(schema='agent-eks-public-role-plan/1',configurationSHA256=plan['configurationSHA256']|dict(core=pin),
            publicOrigin=service['core']['os_origin'],
            qualification='Rendered configuration only. Applying creates billable infrastructure and requires separate authorization. ALB/CNI policy enforcement, prepared immutable private worker configuration, Cloud credentials/retention and full AWS qualification remain required.')
        return plan
    except Exception:raise ValueError('Invalid explicit EKS public role deployment') from None


def prepare_public_role_configurations(document,destination):
    """Validate everything before creating a new private, input-pinned bundle."""
    from agentic_os.adapters.configured_installation import canonical_file
    from agentic_os.adapters.local.files import private_directory,private_write
    from agentic_os.contracts.canonical import canonical_bytes
    plan=public_role_resources(document);destination=canonical_file(str(destination))
    if destination.exists() or destination.is_symlink():raise ValueError('New private configuration destination required')
    raw=dict(core=canonical_bytes(document['service']),native=canonical_bytes(document['service']['worker']['deployment']['configurations']['native']))
    private_directory(destination)
    for role,content in raw.items():
        directory=destination/role;private_directory(directory);private_write(directory/'role.json',content)
    private_write(destination/'plan.json',canonical_bytes(plan))
    return plan|dict(configurationRoot=str(destination))


def native_preparation_resources(profile,*,image,node,namespace,claim,service_account,profile_sha256):
    from agentic_os.adapters.sandbox.firecracker import checked_profile
    profile=checked_profile(profile);ident=profile['installationId']
    if re.fullmatch('[a-f0-9]{64}',profile_sha256) is None:raise ValueError('Exact private profile hash required')
    if re.fullmatch(r'[0-9]{12}\.dkr\.ecr\.[a-z0-9-]+\.amazonaws\.com/agentic-os/'+ident+r'/native@sha256:[a-f0-9]{64}',image) is None:
        raise ValueError('Exact installation native image required')
    if (len(node)>253 or any(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',part) is None for part in node.split('.'))
            or any(re.fullmatch(r'[a-z][a-z0-9-]{0,62}',part) is None for part in (namespace,claim,service_account))):
        raise ValueError('Exact reviewed node/namespace/claim/account required')
    name='aos-native-prepare-'+ident.replace('-','')[:16]
    labels={'agentic-os.installation':ident,'agentic-os.role':'native-preparation'}
    home='/srv/agentic-os/'+ident
    mount=dict(name='native-owner',mountPath='/srv/agentic-os')
    security=dict(runAsUser=0,runAsGroup=0,runAsNonRoot=False,privileged=True,readOnlyRootFilesystem=True)
    initialize=("import pathlib,stat; from agentic_os.adapters.local.files import check_private; "
        "p=pathlib.Path('/srv/agentic-os'); s=p.lstat(); "
        "assert stat.S_ISDIR(s.st_mode) and s.st_uid==0 and p.resolve()==p; "
        "p.chmod(0o700) if not list(p.iterdir()) else None; check_private(p,directory=True)")
    pod=dict(nodeName=node,nodeSelector={'kubernetes.io/arch':'arm64','kubernetes.io/os':'linux',
        'agentic-os.native.installation':ident},tolerations=[dict(key='agentic-os.native',operator='Equal',value=ident,effect='NoSchedule')],
        serviceAccountName=service_account,automountServiceAccountToken=False,restartPolicy='Never',
        hostNetwork=False,hostPID=False,hostIPC=False,
        initContainers=[dict(name='fresh-native-parent',image=image,command=['python','-I','-B','-c',initialize],
            securityContext=security,volumeMounts=[mount])],
        containers=[dict(name='prepare',image=image,command=['python','-I','-B','-m','agentic_os.adapters.sandbox.firecracker_operator'],
            args=['--root',home+'/native','--profile','/run/agentic-os/native-input/profile.json',
                '--profile-sha256',profile_sha256,'--artifacts','/run/agentic-os/native-input/artifacts','--capacity-root',home+'/capacity'],
            securityContext=security,resources=dict(requests=dict(cpu='1',memory='512Mi'),limits=dict(cpu='2',memory='2Gi')),
            volumeMounts=[mount,dict(name='artifacts',mountPath='/run/agentic-os/native-input',readOnly=True),
                dict(name='kvm',mountPath='/dev/kvm'),dict(name='cgroup',mountPath='/sys/fs/cgroup')])],
        volumes=[dict(name='native-owner',hostPath=dict(path='/srv/agentic-os',type='DirectoryOrCreate')),
            dict(name='artifacts',persistentVolumeClaim=dict(claimName=claim,readOnly=True)),
            dict(name='kvm',hostPath=dict(path='/dev/kvm',type='CharDevice')),
            dict(name='cgroup',hostPath=dict(path='/sys/fs/cgroup',type='Directory'))])
    job=dict(apiVersion='batch/v1',kind='Job',metadata=dict(name=name,namespace=namespace,labels=labels),
        spec=dict(backoffLimit=0,activeDeadlineSeconds=600,template=dict(metadata=dict(labels=labels),spec=pod)))
    policy=dict(apiVersion='networking.k8s.io/v1',kind='NetworkPolicy',metadata=dict(name=name,namespace=namespace),
        spec=dict(podSelector=dict(matchLabels=labels),policyTypes=['Ingress','Egress'],ingress=[],egress=[]))
    return dict(apiVersion='v1',kind='List',items=[job,policy])
