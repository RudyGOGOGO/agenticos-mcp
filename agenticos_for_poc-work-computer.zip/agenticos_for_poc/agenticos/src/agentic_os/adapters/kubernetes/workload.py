"""Live Pod-bound workload authentication through Kubernetes TokenReview v1.

The configured API server verifies signature, audience and bound-object life.
No successful review is cached. Its identity selects only a server-owned model
assignment; the existing kernel still checks admission and current authority.
"""
import asyncio
from dataclasses import dataclass
import re
import ssl
from types import MappingProxyType
from urllib.parse import urlsplit
from uuid import UUID

import httpx

from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.errors import OSErrorCode
from agentic_os.production.workload_auth import ModelWorkerAssignment

REVIEW_PATH='/apis/authentication.k8s.io/v1/tokenreviews'
POD_UID='authentication.kubernetes.io/pod-uid'
POD_NAME='authentication.kubernetes.io/pod-name'
NAME=r'[a-z0-9](?:[a-z0-9-]*[a-z0-9])?'


@dataclass(frozen=True)
class ServiceAccountAssignment:
    uid:str
    workload:ModelWorkerAssignment

    def __post_init__(self):
        if (type(self.uid) is not str or str(UUID(self.uid))!=self.uid
                or type(self.workload) is not ModelWorkerAssignment):
            raise ValueError('Explicit service account identity and workload assignment required')


class PurposeTokenReviewWorkload:
    """Route an audience hint to one fresh review, never to model authority.

    The public and planner tokens have distinct reviewed audiences. The API
    server still verifies the chosen token, current Pod and exact SA UID; only
    its server-owned assignment supplies the model/meter. No fallback or cached
    successful review crosses the purpose boundary.
    """
    def __init__(self,public,planner):
        if (type(public) is not TokenReviewWorkload or type(planner) is not TokenReviewWorkload
                or public.audience==planner.audience):raise ValueError('Separate workload audiences required')
        self.verifiers=MappingProxyType({public.audience:public,planner.audience:planner})

    async def close(self):
        public,planner=self.verifiers.values()
        try:await public.close()
        finally:await planner.close()

    async def authenticate(self,token):
        import jwt
        try:
            if type(token) is not str or not 1<=len(token)<=8192:raise ValueError()
            hint=jwt.decode(token,options={'verify_signature':False,'verify_aud':False})
            audience=hint.get('aud')
            if type(audience) is not str or audience not in self.verifiers:raise ValueError()
            selected=self.verifiers[audience]
        except Exception:raise OSErrorCode('UNAUTHENTICATED') from None
        return await selected.authenticate(token)


class TokenReviewWorkload:
    def __init__(self,*,api_origin,audience,assignments,reviewer_token_provider,tls_context,network_transport=None):
        try:
            parsed=urlsplit(api_origin)
            if (type(api_origin) is not str or parsed.scheme!='https' or not parsed.hostname
                    or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment
                    or any(c in api_origin for c in ('\\','%','\n','\r','\t'))
                    or parsed.port is not None and not 1<=parsed.port<=65535
                    or type(audience) is not str or not 1<=len(audience)<=256 or audience.isspace()
                    or not callable(reviewer_token_provider) or type(assignments) is not dict or not 1<=len(assignments)<=64
                    or not isinstance(tls_context,ssl.SSLContext) or not tls_context.check_hostname
                    or tls_context.verify_mode!=ssl.CERT_REQUIRED):raise ValueError()
            for username,binding in assignments.items():
                parts=username.split(':')
                if (len(parts)!=4 or parts[:2]!=['system','serviceaccount']
                        or any(len(part)>63 or re.fullmatch(NAME,part) is None for part in parts[2:])
                        or type(binding) is not ServiceAccountAssignment):raise ValueError()
        except Exception:raise ValueError('Explicit TLS Kubernetes workload configuration required') from None
        self.api_origin,self.audience=api_origin,audience
        self.assignments=MappingProxyType(dict(assignments));self.reviewer_token_provider=reviewer_token_provider
        self.bulkhead=asyncio.Semaphore(4)
        self.client=httpx.AsyncClient(verify=tls_context,trust_env=False,follow_redirects=False,timeout=3,
            limits=httpx.Limits(max_connections=4,max_keepalive_connections=4),
            transport=network_transport or httpx.AsyncHTTPTransport(verify=tls_context,retries=0))

    async def close(self):await self.client.aclose()

    async def authenticate(self,token):
        if type(token) is not str or not 1<=len(token)<=8192:raise OSErrorCode('UNAUTHENTICATED')
        request=dict(apiVersion='authentication.k8s.io/v1',kind='TokenReview',
            spec=dict(token=token,audiences=[self.audience]))
        try:
            async with asyncio.timeout(3):
                async with self.bulkhead:
                    reviewer=await self.reviewer_token_provider()
                    if type(reviewer) is not str or not 1<=len(reviewer)<=8192:raise ValueError()
                    async with self.client.stream('POST',self.api_origin+REVIEW_PATH,content=canonical_bytes(request),
                            headers={'Authorization':'Bearer '+reviewer,'Content-Type':'application/json','Accept-Encoding':'identity'}) as response:
                        if (response.status_code not in {200,201}
                                or not response.headers.get('content-type','').startswith('application/json')
                                or response.headers.get('content-encoding','identity')!='identity'):raise ValueError()
                        raw=bytearray()
                        async for chunk in response.aiter_bytes():
                            if len(raw)+len(chunk)>65536:raise ValueError()
                            raw.extend(chunk)
            value=parse_canonical_json(bytes(raw))
            if (type(value) is not dict or value.get('apiVersion')!='authentication.k8s.io/v1'
                    or value.get('kind')!='TokenReview' or type(value.get('status')) is not dict):raise ValueError()
            status=value['status']
            if status.get('error'):raise ValueError()
            if status.get('authenticated') is not True:raise OSErrorCode('UNAUTHENTICATED')
            if status.get('audiences')!=[self.audience]:raise OSErrorCode('UNAUTHENTICATED')
            user=status.get('user')
            if type(user) is not dict:raise OSErrorCode('UNAUTHENTICATED')
            binding=self.assignments.get(user.get('username'))
            if binding is None or user.get('uid')!=binding.uid:raise OSErrorCode('UNAUTHENTICATED')
            extra=user.get('extra');pod_uid=extra.get(POD_UID) if type(extra) is dict else None
            pod_name=extra.get(POD_NAME) if type(extra) is dict else None
            if (type(pod_uid) is not list or len(pod_uid)!=1 or type(pod_uid[0]) is not str
                    or str(UUID(pod_uid[0]))!=pod_uid[0] or type(pod_name) is not list or len(pod_name)!=1
                    or type(pod_name[0]) is not str or not 1<=len(pod_name[0])<=253
                    or any(re.fullmatch(NAME,part) is None or len(part)>63 for part in pod_name[0].split('.'))):
                raise OSErrorCode('UNAUTHENTICATED')
            return binding.workload
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None
