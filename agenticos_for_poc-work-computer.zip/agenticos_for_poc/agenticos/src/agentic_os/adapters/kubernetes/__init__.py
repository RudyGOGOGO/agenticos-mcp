"""Explicit Kubernetes deployment adapters; never selected by local startup."""
