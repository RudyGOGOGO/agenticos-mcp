"""Bounded OIDC code/S256 exchange for an explicitly mapped owner.

Authentication facts are not approvals. The durable review service must still
bind the original challenge, current owner, exact command, deadline and decision.
No discovery, issuer-selected key URL, refresh, HTTP retry or token persistence.
"""
import asyncio
import base64
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime,timezone
import hashlib
import hmac
import re
from urllib.parse import urlencode,quote_plus
from uuid import UUID

import httpx
import jwt

from agentic_os.adapters.http.endpoint import reviewed_http_endpoint
from agentic_os.adapters.http.tls import LOCAL_HTTP_TLS_CONTEXT
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.errors import OSErrorCode

SCHEMA='oidc-step-up-client/1'
TOKEN=re.compile(r'[A-Za-z0-9_-]{32,128}')
VERIFIER=re.compile(r'[A-Za-z0-9._~-]{43,128}')


def _text(value,maximum):
    return type(value) is str and 1<=len(value.encode())<=maximum and all(ord(c)>=32 and ord(c)!=127 for c in value)


def configuration(document):
    """Private role configuration only; creates no registration or authority."""
    try:
        value=deepcopy(document)
        if (type(value) is not dict or set(value)!={'schema','installation_id','application_id','network','issuer',
                'authorization_endpoint','token_endpoint','redirect_uri','client_id','credential_ref','required_acr','required_amr','keys'}
                or value['schema']!=SCHEMA):raise ValueError()
        for key in ('installation_id','application_id'):
            if type(value[key]) is not str or str(UUID(value[key]))!=value[key]:raise ValueError()
        for key in ('issuer','authorization_endpoint','token_endpoint','redirect_uri'):
            reviewed_http_endpoint(value[key],value['network'])
        if (type(value['client_id']) is not str or re.fullmatch(r'[A-Za-z0-9._-]{1,256}',value['client_id']) is None
                or not _text(value['required_acr'],256) or value['required_acr']=='0'
                or value['credential_ref'] is not None and (type(value['credential_ref']) is not str
                    or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}',value['credential_ref']) is None)
                or type(value['required_amr']) is not list or not 1<=len(value['required_amr'])<=8
                or any(not _text(item,128) for item in value['required_amr'])
                or len(set(value['required_amr']))!=len(value['required_amr'])
                or type(value['keys']) is not list or not 1<=len(value['keys'])<=16):raise ValueError()
        seen=set()
        for key in value['keys']:
            if (type(key) is not dict or not {'kty','kid','n','e'}<=set(key)<= {'kty','kid','n','e','alg','use','key_ops'}
                    or key['kty']!='RSA' or key.get('alg','RS256')!='RS256' or key.get('use','sig')!='sig'
                    or key.get('key_ops',['verify'])!=['verify']
                    or not _text(key['kid'],128) or key['kid'] in seen):raise ValueError()
            public=jwt.PyJWK.from_dict(key,algorithm='RS256').key
            if not 2048<=public.key_size<=4096 or public.public_numbers().e!=65537:raise ValueError()
            seen.add(key['kid'])
        # Bounded reviewed metadata, without a secret, token or discovery URL.
        if len(canonical_bytes(value))>32768:raise ValueError()
        return value
    except Exception:
        raise OSErrorCode('PROFILE_DISABLED') from None


@dataclass(frozen=True)
class OwnerAuthentication:
    issuer:str
    subject:str
    authenticated_at:datetime
    acr:str
    amr:tuple[str,...]
    expires_at:datetime


class OIDCStepUpClient:
    def __init__(self,document,credential=None,*,owned_manifest=None):
        self.value=configuration(document)
        value=self.value
        if value['network']=='owned-local-http/1':
            from agentic_os.adapters.local.ownership import load_manifest
            try:
                manifest=load_manifest(owned_manifest)
                if manifest['installationId']!=value['installation_id']:raise ValueError()
            except Exception:raise OSErrorCode('PROFILE_DISABLED') from None
        elif owned_manifest is not None:raise OSErrorCode('PROFILE_DISABLED')
        if ((value['credential_ref'] is None)!=(credential is None)
                or credential is not None and not _text(credential,1024)):
            raise OSErrorCode('PROFILE_DISABLED')
        self.credential=credential
        self.keys={key['kid']:jwt.PyJWK.from_dict(key,algorithm='RS256').key for key in value['keys']}

    def authorization_url(self,*,state,nonce,verifier):
        if (type(state) is not str or TOKEN.fullmatch(state) is None or type(nonce) is not str or TOKEN.fullmatch(nonce) is None
                or type(verifier) is not str or VERIFIER.fullmatch(verifier) is None):raise OSErrorCode('INVALID')
        value=self.value
        challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode('ascii')).digest()).rstrip(b'=').decode('ascii')
        query=dict(response_type='code',client_id=value['client_id'],redirect_uri=value['redirect_uri'],scope='openid',
            state=state,nonce=nonce,code_challenge=challenge,code_challenge_method='S256',max_age='0',prompt='login',
            acr_values=value['required_acr'])
        return value['authorization_endpoint']+'?'+urlencode(query)

    @staticmethod
    def _segment(value):
        if not value or re.fullmatch(r'[A-Za-z0-9_-]+',value) is None:raise ValueError()
        raw=base64.urlsafe_b64decode(value+'='*((-len(value))%4))
        if base64.urlsafe_b64encode(raw).rstrip(b'=').decode()!=value:raise ValueError()
        return parse_canonical_json(raw)

    def _identity(self,token,*,access_token,nonce,expected_subject,authenticated_after,expires_at):
        try:
            if not _text(token,16384):raise ValueError()
            header,payload,signature=token.split('.')
            head=self._segment(header);claims=self._segment(payload)
            if (type(head) is not dict or not {'alg','kid'}<=set(head)<={'alg','kid','typ'}
                    or head['alg']!='RS256' or head.get('typ','JWT')!='JWT' or head['kid'] not in self.keys
                    or type(claims) is not dict or re.fullmatch(r'[A-Za-z0-9_-]+',signature) is None):raise ValueError()
            verified=jwt.decode(token,self.keys[head['kid']],algorithms=['RS256'],audience=self.value['client_id'],
                issuer=self.value['issuer'],leeway=1,options=dict(require=['iss','aud','sub','exp','iat','auth_time','nonce','acr','amr'],strict_aud=True))
            now=datetime.now(timezone.utc)
            if (verified!=claims or not _text(claims['sub'],255) or not hmac.compare_digest(claims['sub'].encode(),expected_subject.encode())
                    or type(claims['nonce']) is not str or not hmac.compare_digest(claims['nonce'],nonce)
                    or claims.get('azp',self.value['client_id'])!=self.value['client_id']
                    or any(type(claims[key]) is not int for key in ('exp','iat','auth_time'))
                    or claims['acr']!=self.value['required_acr']
                    or type(claims['amr']) is not list or not 1<=len(claims['amr'])<=16
                    or any(not _text(item,128) for item in claims['amr'])
                    or len(set(claims['amr']))!=len(claims['amr'])
                    or not set(self.value['required_amr'])<=set(claims['amr'])
                    or not authenticated_after.timestamp()-1<=claims['auth_time']<=claims['iat']<=now.timestamp()+1
                    or claims['exp']<=now.timestamp() or not now<expires_at):raise ValueError()
            if 'at_hash' in claims:
                expected=base64.urlsafe_b64encode(hashlib.sha256(access_token.encode('ascii')).digest()[:16]).rstrip(b'=').decode('ascii')
                if type(claims['at_hash']) is not str or not hmac.compare_digest(claims['at_hash'],expected):raise ValueError()
            return OwnerAuthentication(self.value['issuer'],claims['sub'],datetime.fromtimestamp(claims['auth_time'],timezone.utc),
                claims['acr'],tuple(claims['amr']),min(expires_at,datetime.fromtimestamp(claims['exp'],timezone.utc)))
        except Exception:raise OSErrorCode('DENIED') from None

    async def exchange(self,*,code,verifier,nonce,expected_subject,authenticated_after,expires_at):
        """One original code exchange, bounded by the durable caller's horizon.

        The caller supplies an issuer/sub mapping and original saved flow times,
        never identity or a renewed deadline from browser/model/provider input.
        """
        if (not _text(code,2048) or type(verifier) is not str or VERIFIER.fullmatch(verifier) is None
                or type(nonce) is not str or TOKEN.fullmatch(nonce) is None or not _text(expected_subject,255)
                or type(authenticated_after) is not datetime or type(expires_at) is not datetime
                or authenticated_after.tzinfo is None or expires_at.tzinfo is None):raise OSErrorCode('INVALID')
        now=datetime.now(timezone.utc)
        remaining=(expires_at-now).total_seconds()
        if (remaining<=0 or authenticated_after>now or not 0<(expires_at-authenticated_after).total_seconds()<=60):
            raise OSErrorCode('DENIED')
        value=self.value;timeout=min(3,remaining)
        data=dict(grant_type='authorization_code',code=code,
            redirect_uri=value['redirect_uri'],code_verifier=verifier)
        if self.credential is None:data['client_id']=value['client_id']
        try:
            async with asyncio.timeout(timeout):
                # RFC6749 section2.3.1 applies form encoding before HTTP Basic.
                auth=None if self.credential is None else httpx.BasicAuth(
                    quote_plus(value['client_id'],safe=''),quote_plus(self.credential,safe=''))
                async with httpx.AsyncClient(verify=LOCAL_HTTP_TLS_CONTEXT,trust_env=False,follow_redirects=False,timeout=timeout) as client:
                    async with client.stream('POST',value['token_endpoint'],data=data,auth=auth,
                            headers={'Accept':'application/json','Accept-Encoding':'identity'}) as response:
                        if response.status_code in {400,401,403}:raise OSErrorCode('DENIED')
                        if (response.status_code!=200 or response.headers.get('content-type','').split(';')[0]!='application/json'
                                or response.headers.get('content-encoding','identity')!='identity'):raise OSErrorCode('UNAVAILABLE')
                        raw=bytearray()
                        async for chunk in response.aiter_bytes():
                            raw.extend(chunk)
                            if len(raw)>65536:raise OSErrorCode('UNAVAILABLE')
            result=parse_canonical_json(bytes(raw))
            if (type(result) is not dict or result.get('token_type')!='Bearer' or 'id_token' not in result
                    or not _text(result.get('access_token'),16384)
                    or type(result.get('expires_in')) is not int or not 1<=result['expires_in']<=86400):
                raise OSErrorCode('UNAVAILABLE')
            return self._identity(result['id_token'],access_token=result['access_token'],nonce=nonce,expected_subject=expected_subject,
                authenticated_after=authenticated_after,expires_at=expires_at)
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None
