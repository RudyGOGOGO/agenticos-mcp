"""Operator-selected separate assurance adapters; not model-callable approval."""
