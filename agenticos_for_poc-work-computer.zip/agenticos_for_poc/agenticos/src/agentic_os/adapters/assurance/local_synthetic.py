"""Explicit owned local-synthetic adapter; not production step-up assurance."""

import asyncio
import copy
import hashlib
import hmac
import re
from datetime import timedelta
from pathlib import Path

from agentic_os.adapters.http.client import RemoteJSON
from agentic_os.adapters.local.files import private_read, OwnershipError
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.contracts.canonical import digest, canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import timestamp, utcnow
from agentic_os.effects.assurance import binding_digest, check_binding


class AssuranceJSON(RemoteJSON):
    """Separate, fixed controller endpoints; never host resource/tool routes.

    The host client's default allowlist is unchanged. This adapter has its own
    fixed allowlist; no constructor or request may supply or expand it.
    """

    allowed_routes = frozenset({"/challenges", "/assertions/verify"})


class LocalSyntheticAssurance:
    """Fixed operator-selected endpoint; no model/user-supplied URL or key.

    Its explicit fixture profile is not a production identity/step-up guarantee.
    The explicit authenticated fixture binding must be provisioned beforehand.
    No endpoint, credential, production profile or implicit seed is accepted.
    """

    profile_ref = "local-synthetic-assurance/1"

    def __init__(self, manifest: Path, *, local_synthetic=False):
        if (
            local_synthetic is not True
            or not isinstance(manifest, Path)
            or not manifest.is_absolute()
        ):
            raise OSErrorCode("PROFILE_DISABLED")
        self.manifest = manifest
        self.binding = self._owned_binding()
        self.binding_ref = "assurance/" + digest(
            "verification",
            {
                key: self.binding[key]
                for key in (
                    "profileRef",
                    "installationId",
                    "runId",
                    "origin",
                    "fixtureConfigDigest",
                )
            },
        )
        self.client = AssuranceJSON(
            self.binding["origin"],
            self.binding["controllerKey"],
            timeout=3,
            max_bytes=16384,
        )

    def _owned_binding(self):
        try:
            manifest = load_manifest(self.manifest)
            if manifest["profile"] != "test":
                raise ValueError()
            root = Path(manifest["root"])
            envelope = parse_canonical_json(
                private_read(root / "assurance-service.json", 16384)
            )
            if type(envelope) is not dict or set(envelope) != {"binding", "signature"}:
                raise ValueError()
            value = envelope["binding"]
            fields = {
                "version",
                "profileRef",
                "installationId",
                "runId",
                "origin",
                "port",
                "controllerKey",
                "fixtureConfigDigest",
            }
            if type(value) is not dict or set(value) != fields:
                raise ValueError()
            key = private_read(root / "owner.key", 32)
            expected = hmac.digest(
                key, b"assurance-service/1\0" + canonical_bytes(value), "sha256"
            ).hex()
            if (
                len(key) != 32
                or type(envelope["signature"]) is not str
                or not hmac.compare_digest(expected, envelope["signature"])
            ):
                raise ValueError()
            if (
                type(value["version"]) is not int
                or value["version"] != 1
                or value["profileRef"] != self.profile_ref
                or value["installationId"] != manifest["installationId"]
                or value["runId"] != manifest["runId"]
                or type(value["port"]) is not int
                or not 1024 <= value["port"] <= 65535
                or value["origin"] != f"http://127.0.0.1:{value['port']}"
                or type(value["controllerKey"]) is not str
                or re.fullmatch(r"[A-Za-z0-9_-]{43,128}", value["controllerKey"])
                is None
                or type(value["fixtureConfigDigest"]) is not str
                or re.fullmatch(r"[a-f0-9]{64}", value["fixtureConfigDigest"]) is None
            ):
                raise ValueError()
            directory = root / "synthetic-assurance"
            if directory.resolve() != directory:
                raise ValueError()
            from agentic_os.adapters.local.files import check_private

            check_private(directory, directory=True)
            config_bytes = private_read(directory / "config.json", 16384)
            config = parse_canonical_json(config_bytes)
            if (
                hashlib.sha256(config_bytes).hexdigest() != value["fixtureConfigDigest"]
                or config["fixture"] != "owned-local-synthetic-assurance"
                or config["profileRef"] != value["profileRef"]
                or config["installationId"] != value["installationId"]
                or config["runId"] != value["runId"]
                or config["port"] != value["port"]
                or config["controllerKey"] != value["controllerKey"]
            ):
                raise ValueError()
            return copy.deepcopy(value)
        except (OSError, OwnershipError, ValueError, TypeError, KeyError):
            raise OSErrorCode("PROFILE_DISABLED") from None

    def require_configured_subject(self,subject):
        """Startup selection only; this supplies no owner fact or approval."""
        validate_contract('SubjectRef',subject)
        binding=self._owned_binding()
        root=Path(load_manifest(self.manifest)['root'])
        config=parse_canonical_json(private_read(root/'synthetic-assurance/config.json',16384))
        if (subject['installationId']!=binding['installationId']
                or type(config.get('owners')) is not list
                or sum(owner.get('subject')==subject for owner in config['owners'] if type(owner) is dict)!=1):
            raise OSErrorCode('PROFILE_DISABLED')

    async def current(self):
        if await asyncio.to_thread(self._owned_binding) != self.binding:
            raise OSErrorCode("DENIED")

    async def register(self, binding):
        await self.current()
        check_binding(binding)
        self.check_provider(binding)
        value = await self.client.post("/challenges", binding, "AssuranceRegistration")
        if (
            value["challengeId"] != binding["challengeId"]
            or value["bindingDigest"] != binding_digest(binding)
            or value["expiresAt"] != binding["expiresAt"]
        ):
            raise OSErrorCode("DENIED")
        await self.current()
        check_binding(binding)
        return value

    async def verify(self, claim):
        await self.current()
        validate_contract("AssuranceClaim", claim)
        check_binding(claim["binding"])
        self.check_provider(claim["binding"])
        value = await self.client.post(
            "/assertions/verify", claim, "AssuranceAttestation"
        )
        self.check_attestation(claim, value)
        await self.current()
        self.check_attestation(claim, value)
        return value

    def check_attestation(self, claim, value):
        check_binding(claim["binding"])
        binding = claim["binding"]
        if (
            value["subject"] != binding["subject"]
            or value["sessionId"] != binding["sessionId"]
            or value["challengeId"] != binding["challengeId"]
            or value["bindingDigest"] != binding_digest(binding)
            or any(
                value[k] != claim[k]
                for k in ("assertionRef", "commandId", "commandDigest", "decision")
            )
            or value["assuranceRef"] != binding["requiredAssurance"]
            or not utcnow() - timedelta(seconds=5)
            <= timestamp(value["observedAt"])
            <= utcnow() + timedelta(seconds=1)
            or not utcnow()
            < timestamp(value["expiresAt"])
            <= timestamp(binding["expiresAt"])
        ):
            raise OSErrorCode("DENIED")

    def check_provider(self, binding):
        if (
            binding["assuranceProfile"] != self.profile_ref
            or binding["assuranceProviderRef"] != self.binding_ref
            or binding["subject"]["installationId"] != self.binding["installationId"]
        ):
            raise OSErrorCode("DENIED")
