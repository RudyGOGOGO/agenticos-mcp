"""Reviewed OS-owned adapters; host implementations stay remote."""
