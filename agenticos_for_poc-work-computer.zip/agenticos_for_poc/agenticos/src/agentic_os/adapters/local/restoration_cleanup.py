"""Actual held vector, SDK and exact derived-file erasure; no runtime grant."""
import asyncio
import time
from contextlib import contextmanager
from uuid import UUID

from agentic_os.adapters.pgvector import RetrievalStore, SCOPE
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from .artifacts import LocalKeys
from .erasing_artifacts import ErasingLocalArtifacts
from .recovery_operator import connect_owned
from .restoration_binding import load_restoration
from .recovery_sdk import restored_sdk
from .files import OwnershipError
from .operator import verify_operator


class _HeldVectorErasure(RetrievalStore):
    """Reuse the qualified monotonic seal inside one bounded owner transaction."""
    def __init__(self, path, admitted):
        self.manifest, self.admitted = path, admitted
        self.active = None

    def assert_held(self):
        if load_restoration(self.manifest) != self.admitted:
            raise OwnershipError('Held restoration changed during vector erasure')

    @contextmanager
    def transaction(self, subject):
        validate_contract('SubjectRef', subject)
        if subject['installationId'] != self.admitted['installationId']:
            raise OSErrorCode('DENIED')
        self.assert_held()
        if self.active is not None:
            selected, db = self.active
            if selected != subject:
                raise OSErrorCode('DENIED')
            yield db
            return
        with connect_owned(self.manifest, component='retrieval', role='migrator') as db:
            db.execute("SET LOCAL lock_timeout='2s'")
            db.execute("SET LOCAL statement_timeout='3s'")
            from agentic_os.contracts.canonical import canonical_bytes
            db.execute("SELECT set_config('agentic.owner_scope',%s,true)",
                (canonical_bytes(subject).decode(),))
            yield db
            self.assert_held()

    def erase(self, subject, entries):
        if type(entries) not in {list, tuple} or len(entries) > 4096:
            raise OSErrorCode('CAPACITY')
        if len({v['id'] for v in entries}) != len(entries):
            raise OSErrorCode('CONFLICT')
        deadline = time.monotonic()+10
        with self.transaction(subject) as db:
            self.active = (subject, db)
            try:
                for entry in entries:
                    if time.monotonic()>=deadline:
                        raise OSErrorCode('UNAVAILABLE')
                    self.seal(subject, UUID(entry['id']), minimum_version=entry['minimumVersion'], forgotten=entry['forgotten'])
                for entry in entries:
                    args = dict(subject, entry=UUID(entry['id']), minimum=entry['minimumVersion'])
                    fence = db.execute('SELECT minimum_version,forgotten FROM personal_knowledge_fences WHERE '
                        +SCOPE+' AND entry_id=%(entry)s', args).fetchone()
                    if (fence is None or fence[0] < entry['minimumVersion']
                            or entry['forgotten'] and fence[1] is not True):
                        raise OSErrorCode('UNAVAILABLE')
                    if db.execute('SELECT 1 FROM personal_knowledge_vectors WHERE '+SCOPE+
                            ' AND entry_id=%(entry)s AND (entry_version<%(minimum)s OR %(forgotten)s) LIMIT 1',
                            args|dict(forgotten=fence[1])).fetchone():
                        raise OSErrorCode('UNAVAILABLE')
            finally:
                self.active = None
        return dict(sealedEntries=len(entries), remainingVectors=0)


class RestorationPrivacyCleanup:
    """Only plans selected by the authenticated operator reach this adapter."""
    def __init__(self, path, token, admitted, *, expected_generation):
        self.path, self.admitted, self.token = path, admitted, token
        verify_operator(path, token)
        if (type(expected_generation) is not int or admitted['generation'] != expected_generation
                or load_restoration(path) != admitted):
            raise OwnershipError('Held restoration changed')
        self.sdk = restored_sdk(path)
        self.vectors = _HeldVectorErasure(path, admitted)
        self.artifacts = ErasingLocalArtifacts(path.parent/'artifacts', LocalKeys(path.parent/'keys'))

    async def erase(self, subject, *, entries, artifacts):
        verify_operator(self.path, self.token)
        validate_contract('SubjectRef', subject)
        if subject['installationId'] != self.admitted['installationId']:
            raise OSErrorCode('DENIED')
        if len(artifacts) > 4096:
            raise OSErrorCode('CAPACITY')
        # No control/vector transaction or journal lock spans process cleanup.
        async with asyncio.timeout(20):
            sdk = await self.sdk.cancel_owner(subject)
            if sdk['pending']:
                raise OSErrorCode('UNAVAILABLE')
            vector = await asyncio.to_thread(self.vectors.erase, subject, entries)
            files = []
            for artifact in artifacts:
                files.append(await asyncio.to_thread(self.artifacts.purge, subject, artifact['id'],
                    purpose='artifact', expected_ciphertext_digest=artifact['ciphertextDigest']))
            snapshot = self.sdk.owner_snapshot(subject)
            if snapshot['leases'] or snapshot['queue'] or snapshot['unboundWork']:
                raise OSErrorCode('UNAVAILABLE')
            if load_restoration(self.path) != self.admitted:
                raise OwnershipError('Held restoration changed during cleanup')
            return dict(profile='restoration-privacy-cleanup/1', sdk=sdk, vectors=vector,
                files=files, complete=True)
