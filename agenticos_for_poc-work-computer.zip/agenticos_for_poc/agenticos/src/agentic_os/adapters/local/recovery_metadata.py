"""Authenticated relocation metadata; never adopts an old operator or password."""
from pathlib import Path
import re
from uuid import UUID

from agentic_os.contracts.canonical import canonical_bytes,CanonicalError
from .files import OwnershipError, check_private
from .ownership import load_manifest
from .resources import canonical_path, read_signed

PROFILE = 'recovery-relocation/3'
CLOUD_PROFILE = 'recovery-relocation/4'
CLOUD_TEMPORAL_PROFILE = 'cloud-temporal-lineage/1'
SELF_HOSTED_TEMPORAL_PROFILE = 'self-hosted-temporal-lineage/1'
LINEAGE_PROFILE = 'recovery-relocation/2'
LEGACY_PROFILE = 'recovery-relocation/1'
FILE = 'recovery-metadata/bindings.json'
FIELDS = {'profile', 'installationId', 'sourceRunId', 'knowledgeKeys', 'publicKnowledge', 'temporal'}
SOURCE_FILE='cloud-source.json'
SOURCE_PROFILE='parked-cloud-source/1'
SELF_HOSTED_SOURCE_PROFILE='parked-self-hosted-source/1'
SERVICE_FIELDS={'namespace','namespaceId','retentionDays','endpoint','serverCASha256'}


def cloud_source_selected(path):
    marker=Path(path).parent/SOURCE_FILE
    return marker.exists() or marker.is_symlink()


def cloud_source_binding(path):
    """Original Cloud selection survives failed copies and local fallback attempts."""
    from agentic_os.adapters.temporal.connection import namespace_identity
    path=Path(path);manifest=load_manifest(path)
    try:value=read_signed(path.parent/SOURCE_FILE,path.parent/'owner.key',maximum=8192)
    except CanonicalError:raise OwnershipError('Original Cloud source binding unavailable') from None
    if (type(value) is not dict or set(value)!={'profile','installationId','runId','sourceGeneration','service'}
            or value['profile'] not in {SOURCE_PROFILE,SELF_HOSTED_SOURCE_PROFILE} or any(value[k]!=manifest[k] for k in ('installationId','runId'))
            or type(value['sourceGeneration']) is not int or not 1<=value['sourceGeneration']<=2**53-1
            or type(value['service']) is not dict or set(value['service'])!=SERVICE_FIELDS):
        raise OwnershipError('Original Cloud source binding differs')
    service=value['service'];cloud=namespace_identity(service,self_hosted=value['profile']==SELF_HOSTED_SOURCE_PROFILE)
    if (service['endpoint']!=cloud.host or type(service['serverCASha256']) is not str
            or re.fullmatch('[a-f0-9]{64}',service['serverCASha256']) is None):
        raise OwnershipError('Original Cloud source service differs')
    return value


def check_cloud_held_capture(path,capture):
    from agentic_os.adapters.aws.temporal import checked_history_capture
    from .restoration_binding import load_restoration,relocation_metadata
    from .recovery_runtime_checkpoint import runtime_checkpoint
    checked_history_capture(capture);manifest=load_manifest(path);admitted=load_restoration(path)
    original=relocation_metadata(path)
    if (capture['profile'] not in {'temporal-cloud-held-history-inspection/1','temporal-self-hosted-held-history-inspection/1'}
            or original['profile']!=CLOUD_PROFILE
            or capture['installationId']!=manifest['installationId'] or capture['sourceRunId']!=manifest['runId']
            or capture['sourceGeneration']!=admitted['generation']
            or capture['originalRunId']!=original['temporal']['data']['runId']
            or any(capture[k]!=original['temporal'][k] for k in SERVICE_FIELDS)
            or not set(original['temporal']['requiredWorkflows'])<=set(capture['requiredWorkflows'])
            or capture['runtimeCheckpoint']!=runtime_checkpoint(path)):
        raise OwnershipError('Held Cloud source capture differs')
    return capture


def check_cloud_source_capture(path,capture):
    from agentic_os.adapters.aws.temporal import checked_history_capture
    from . import recovery_gate as gate
    checked_history_capture(capture);manifest=load_manifest(path);current=gate.state(path)
    if (capture['profile'] not in {'temporal-cloud-history-inspection/1','temporal-self-hosted-history-inspection/1'} or current['mode']!='PARKED'
            or capture['sourceGeneration']!=current['generation']
            or capture['installationId']!=manifest['installationId'] or capture['sourceRunId']!=manifest['runId']):
        raise OwnershipError('Original Cloud source capture differs')
    service={k:capture[k] for k in SERVICE_FIELDS}
    if cloud_source_selected(path):
        prior=cloud_source_binding(path)
        if prior['service']!=service or prior['sourceGeneration']>current['generation']:
            raise OwnershipError('Original Cloud source selection changed')
    return dict(profile=SELF_HOSTED_SOURCE_PROFILE if capture['profile'].startswith('temporal-self-hosted-') else SOURCE_PROFILE,installationId=manifest['installationId'],runId=manifest['runId'],
        sourceGeneration=current['generation'],service=service)


def bind_cloud_source(path,capture):
    """Caller holds the authenticated parked snapshot gate; this grants no lane."""
    from .resources import write_signed
    value=check_cloud_source_capture(path,capture)
    if not cloud_source_selected(path):write_signed(Path(path).parent/SOURCE_FILE,value,Path(path).parent/'owner.key')
    return cloud_source_binding(path)


def source_metadata(path, *, held=False, cloud_capture=None,installation=None):
    manifest = load_manifest(path)
    root = Path(path).parent
    if cloud_capture is None and cloud_source_selected(path):
        raise OwnershipError('Explicit original Cloud source snapshot required')
    value = dict(profile=PROFILE, installationId=manifest['installationId'],
        sourceRunId=manifest['runId'], knowledgeKeys=False, publicKnowledge=False, temporal=None)
    key_binding = root/'knowledge-key-binding.json'
    if key_binding.exists() or key_binding.is_symlink():
        if manifest['profile']=='aws-eks/1':
            from agentic_os.adapters.aws.bootstrap import private_knowledge_keys
            private_knowledge_keys(path)
        else:
            expected = dict(profile='OSProtectedKnowledgeKeys/1', installationId=manifest['installationId'],
                runId=manifest['runId'], container=manifest['postgres']['container'],
                root=str(canonical_path(root/'protected-knowledge')), purpose='planner.read/1')
            if read_signed(key_binding, root/'owner.key') != expected:
                raise OwnershipError('Original protected knowledge binding differs')
        from .artifacts import LocalKeys
        check_private(root/'protected-knowledge', directory=True)
        LocalKeys(root/'protected-knowledge/keys').active()
        value['knowledgeKeys'] = True
    elif (root/'protected-knowledge').exists() and not held:
        raise OwnershipError('Selected protected knowledge binding unavailable')
    public_binding = root/'knowledge-public-credential.json'
    if public_binding.exists() or public_binding.is_symlink():
        from agentic_os.knowledge.access import expected
        binding = read_signed(public_binding, root/'owner.key')
        shape = expected(manifest)
        if (type(binding) is not dict or set(binding) != set(shape)|{'password'}
                or any(binding[k] != v for k, v in shape.items())
                or type(binding['password']) is not str
                or re.fullmatch('[a-f0-9]{48}', binding['password']) is None
                or not value['knowledgeKeys']):
            raise OwnershipError('Original public knowledge purpose differs')
        value['publicKnowledge'] = True
    if cloud_capture is None and ((root/'recovery-snapshot.json').exists() or (root/'recovery-snapshot.json').is_symlink()):
        from .restoration_binding import relocation_metadata
        if relocation_metadata(path)['profile']==CLOUD_PROFILE:
            raise OwnershipError('Explicit Cloud held snapshot inspection required')
    if cloud_capture is not None:
        from agentic_os.adapters.aws.temporal import checked_history_capture,original_history
        from . import recovery_gate as gate
        from .recovery_runtime_checkpoint import runtime_checkpoint
        checked_history_capture(cloud_capture)
        if held:
            check_cloud_held_capture(path,cloud_capture)
        else:check_cloud_source_capture(path,cloud_capture)
        if (not held and any((root/name).exists() or (root/name).is_symlink() for name in
                ('temporal-service.json','recovery-snapshot.json','temporal-lineage.json'))
                or cloud_capture['installationId']!=manifest['installationId']
                or cloud_capture['sourceRunId']!=manifest['runId']
                or cloud_capture['sourceGeneration']!=gate.state(path)['generation']
                or gate.state(path)['mode']!=('BLOCKED' if held else 'PARKED')
                or cloud_capture['runtimeCheckpoint']!=(runtime_checkpoint(path) if installation is None else runtime_checkpoint(path,installation=installation))):
            raise OwnershipError('Original Cloud source capture differs')
        value['profile']=CLOUD_PROFILE;value['temporal']=original_history(cloud_capture)
    elif (root/'temporal-service.json').exists() or (root/'temporal-service.json').is_symlink():
        from .temporal import inspect_service
        binding, service = inspect_service(path, require_running=False)
        if service['State']['Running']:
            raise OwnershipError('Temporal writers must stop before snapshot')
        restored = root/'recovery-temporal.json'
        from .recovery_lineage import FILE as LINEAGE_FILE,load_lineage,namespace_id
        lineage=root/LINEAGE_FILE
        if lineage.exists() or lineage.is_symlink():
            original=load_lineage(path,binding)['original']
            if namespace_id(path,original['namespace'])!=original['namespaceId']:
                raise OwnershipError('Original namespace identifier changed')
            if held:
                from .restoration_binding import load_restoration
                from .recovery_temporal import _shape,_checked_record,_admitted_workflows
                admitted=load_restoration(path)
                shape=_shape(manifest,admitted,original,binding.get('networkSubnets'))
                shape['requiredWorkflows']=_admitted_workflows(path,manifest)
                if _checked_record(path,shape)['state']!='INSPECTED':
                    raise OwnershipError('Relocated Temporal history is not verified')
            value['temporal']=original
        elif restored.exists() or restored.is_symlink():
            # Physical service ownership follows the current run. Logical
            # history identity remains the authenticated original namespace,
            # including a second snapshot of a relocated held installation.
            from .restoration_binding import load_restoration,relocation_metadata
            from .recovery_temporal import _shape,_checked_record,_service_digest,_admitted_workflows
            admitted=load_restoration(path)
            original=relocation_metadata(path)['temporal']
            if original is None:raise OwnershipError('Original Temporal lineage unavailable')
            shape=_shape(manifest,admitted,original,binding.get('networkSubnets'),legacy=True)
            shape['requiredWorkflows']=_admitted_workflows(path,manifest)
            record=_checked_record(path,shape)
            if record['state']!='INSPECTED' or record['serviceDigest']!=_service_digest(binding):
                raise OwnershipError('Relocated Temporal history is not verified')
            value['temporal']=record['original']
            # Older authenticated held inspections remain readable. Their
            # namespace UUID was not pinned and cannot acquire that claim now.
            value['profile']=LINEAGE_PROFILE
        elif (root/'recovery-snapshot.json').exists() or (root/'recovery-snapshot.json').is_symlink():
            raise OwnershipError('Restored Temporal service requires authenticated lineage')
        else:
            value['temporal'] = dict(namespace=binding['namespace'],
                data=dict(installationId=manifest['installationId'], runId=manifest['runId']),
                taskQueue='os-admission-'+manifest['runId'],
                namespaceId=namespace_id(path,binding['namespace'],allow_absent=True))
    checked_metadata(value, manifest['installationId'], manifest['runId'])
    return value


def checked_metadata(value, installation, source_run):
    if (type(value) is not dict or set(value) != FIELDS or type(value['profile']) is not str
            or value['profile'] not in {PROFILE,LINEAGE_PROFILE,LEGACY_PROFILE,CLOUD_PROFILE}
            or value['installationId'] != installation or value['sourceRunId'] != source_run
            or any(type(value[k]) is not bool for k in ('knowledgeKeys', 'publicKnowledge'))
            or (value['publicKnowledge'] and not value['knowledgeKeys'])):
        raise OwnershipError('Recovery relocation metadata unavailable')
    temporal = value['temporal']
    if value['profile']==CLOUD_PROFILE:
        checked_cloud_temporal(temporal,installation)
        return value
    if temporal is not None:
        checked_temporal(temporal,installation,with_id=value['profile']==PROFILE)
        logical_run=source_run if value['profile']==LEGACY_PROFILE else temporal['data']['runId']
        if temporal['data']['runId']!=logical_run:
            raise OwnershipError('Original Temporal namespace differs')
    return value


def checked_temporal(temporal,installation,*,with_id=True,require_id=False):
    fields={'namespace','data','taskQueue'}|({'namespaceId'} if with_id else set())
    if (type(temporal) is not dict or set(temporal)!=fields
            or type(temporal['data']) is not dict or set(temporal['data'])!={'installationId','runId'}
            or type(temporal['data']['runId']) is not str
            or re.fullmatch('[a-f0-9]{12}',temporal['data']['runId']) is None):
        raise OwnershipError('Original Temporal namespace differs')
    run=temporal['data']['runId']
    if (temporal['namespace']!='os-'+run or temporal['taskQueue']!='os-admission-'+run
            or temporal['data']['installationId']!=installation):
        raise OwnershipError('Original Temporal namespace differs')
    if with_id:
        ident=temporal['namespaceId']
        try:
            if ident is None and not require_id:return temporal
            if type(ident) is not str or str(UUID(ident))!=ident:raise ValueError()
        except Exception:raise OwnershipError('Original namespace identifier differs') from None
    return temporal


def checked_cloud_temporal(value,installation):
    from agentic_os.adapters.temporal.connection import namespace_identity
    from .artifacts import checked_id
    from .recovery_temporal import checked_catalog
    fields={'profile','namespace','namespaceId','retentionDays','endpoint','serverCASha256',
        'data','taskQueue','requiredWorkflows','catalog'}
    if (type(value) is not dict or set(value)!=fields or value['profile'] not in {CLOUD_TEMPORAL_PROFILE,SELF_HOSTED_TEMPORAL_PROFILE}
            or type(value['data']) is not dict or set(value['data'])!={'installationId','runId'}
            or value['data']['installationId']!=installation or type(value['data']['runId']) is not str
            or re.fullmatch('[a-f0-9]{12}',value['data']['runId']) is None
            or type(value['serverCASha256']) is not str or re.fullmatch('[a-f0-9]{64}',value['serverCASha256']) is None):
        raise OwnershipError('Original Cloud lineage differs')
    checked_id(installation)
    cloud=namespace_identity(value,self_hosted=value['profile']==SELF_HOSTED_TEMPORAL_PROFILE)
    if (value['endpoint']!=cloud.host or value['taskQueue']!='os-admission-'+value['data']['runId']
            or type(value['requiredWorkflows']) is not list or len(value['requiredWorkflows'])>128
            or any(type(v) is not str for v in value['requiredWorkflows'])
            or sorted(set(value['requiredWorkflows']))!=value['requiredWorkflows']):
        raise OwnershipError('Original Cloud lineage differs')
    checked_catalog(value['catalog'],value,installation)
    runs={(row['workflowId'],row['runId']) for row in value['catalog']}
    if any((row['workflowId'],row['firstRunId']) not in runs for row in value['catalog']):
        raise OwnershipError('Original Cloud first history is missing')
    if not set(value['requiredWorkflows'])<={row['workflowId'] for row in value['catalog']}:
        raise OwnershipError('Original Cloud admitted history is missing')
    return value


def metadata_bytes(path, *, held=False, cloud_capture=None,installation=None):
    if installation is None:return canonical_bytes(source_metadata(path,held=held,cloud_capture=cloud_capture))
    return canonical_bytes(source_metadata(path,held=held,cloud_capture=cloud_capture,installation=installation))
