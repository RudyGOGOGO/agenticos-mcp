"""Owned local-synthetic Temporal service; never a host, model or sandbox endpoint.

Original schemas are migrated separately. No auto-setup, cloud endpoint, inherited
credentials or second workflow engine. Service records are owner-authenticated.
"""
import hashlib,hmac,json,os,time
from uuid import uuid4
from importlib.resources import files
from pathlib import Path
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from .files import OwnershipError,private_read,private_write,private_directory
from .ownership import load_manifest
from .docker import DockerControl
from .temporal_networks import checked_subnets,available_subnets,assert_ipam

COMPONENT='temporal'
MEMORY=1536*1024**2
FIELDS={'version','installationId','runId','component','network','container','image','imageId','port','configDigest','namespace'}


def load_binding(path):
    manifest=load_manifest(path);root=path.parent
    envelope=parse_canonical_json(private_read(root/'temporal-service.json'))
    if type(envelope) is not dict or set(envelope)!={'binding','signature'}:
        raise OwnershipError('Invalid Temporal service envelope')
    value=envelope['binding'];key=private_read(root/'owner.key',32)
    expected_fields=FIELDS if type(value) is dict and value.get('version')==1 else FIELDS|{'networkSubnets'}
    if (type(value) is not dict or set(value)!=expected_fields
            or type(value['version']) is not int or value['version'] not in {1,2}
            or type(envelope['signature']) is not str
            or not hmac.compare_digest(envelope['signature'],hmac.digest(key,canonical_bytes(value),'sha256').hex())
            or value['installationId']!=manifest['installationId'] or value['runId']!=manifest['runId']
            or value['component']!=COMPONENT or value['network']!=manifest['project']+'-temporal-network'
            or value['container']!=manifest['project']+'-temporal'
            or value['namespace']!='os-'+manifest['runId']
            or type(value['port']) is not int or not 0<=value['port']<=65535):
        raise OwnershipError('Foreign Temporal service binding')
    if value['version']==2:checked_subnets(value['networkSubnets'])
    profile=json.loads(files('agentic_os').joinpath('deploy/profiles/local-synthetic.json').read_text())
    if value['image']!=profile['components']['TEMPORAL_IMAGE']['reference']:
        raise OwnershipError('Temporal image profile changed')
    config=private_read(root/'temporal-config/server.json')
    if hashlib.sha256(config).hexdigest()!=value['configDigest']:
        raise OwnershipError('Temporal configuration changed')
    return value


def save_binding(path,value):
    key=private_read(path.parent/'owner.key',32)
    private_write(path.parent/'temporal-service.json',canonical_bytes({'binding':value,
        'signature':hmac.digest(key,canonical_bytes(value),'sha256').hex()}),replace=True)
    load_binding(path)


def labels(manifest):
    return {'io.agentic-os.installation':manifest['installationId'],'io.agentic-os.run':manifest['runId'],
            'io.agentic-os.component':COMPONENT}


def unstarted_network_setup(binding,obj):
    """Only a tracked, never-started container can finish initial attachment."""
    state=obj['State']
    return (binding['port']==0 and state.get('Status')=='created'
        and state.get('Running') is False and not state.get('Paused') and not state.get('Restarting')
        and state.get('StartedAt')=='0001-01-01T00:00:00Z'
        and set(obj['NetworkSettings']['Networks'])=={binding['network']})


def inspect_service(path,*,require_running=True,starting=False,recovered_profile=False,incomplete_setup=False):
    from .recovery_ready import restored
    from .recovery_gate import state
    if restored(path) and state(path)['mode']=='READY' and recovered_profile is not True:
        # Frozen clients expect a physical run namespace. A restored runtime
        # must explicitly select its current logical-lineage factory instead.
        raise OwnershipError('Explicit restored workflow profile required')
    manifest=load_manifest(path);binding=load_binding(path);docker=DockerControl(manifest)
    docker.inspect_owned(manifest,require_running=require_running)
    network=json.loads(docker.command('network','inspect',binding['network']))[0]
    expected=labels(manifest)
    if (not network['Internal'] or network['Driver']!='bridge'
            or any(network.get('Labels',{}).get(k)!=v for k,v in expected.items())):
        raise OwnershipError('Foreign Temporal service network')
    pg=json.loads(docker.command('inspect',manifest['postgres']['container']))[0]
    pg_id=pg['Id'];obj=json.loads(docker.command('inspect',binding['container']))[0]
    if any(obj['Config'].get('Labels',{}).get(k)!=v for k,v in expected.items()):
        raise OwnershipError('Foreign Temporal service container')
    peers=set(network.get('Containers',{}))
    allowed={pg_id,obj['Id']}
    if (not peers<=allowed
            or pg_id not in peers and (require_running or pg['State']['Running'] or obj['State']['Running'])
            or obj['State']['Running'] and peers!=allowed):
        raise OwnershipError('Unexpected service network peer')
    image=json.loads(docker.command('image','inspect',binding['image']))[0]
    config=obj['HostConfig'];mounts=obj['Mounts']
    source=str(path.parent/'temporal-config');allowed={source,'/host_mnt'+source}
    rpc_network=binding['network']+'-rpc'
    rpc=json.loads(docker.command('network','inspect',rpc_network))[0]
    if binding['version']==2:
        assert_ipam(network,binding['networkSubnets']['private'])
        assert_ipam(rpc,binding['networkSubnets']['rpc'])
    if (rpc['Internal'] or rpc['Driver']!='bridge'
            or any(rpc.get('Labels',{}).get(k)!=v for k,v in expected.items())
            or not set(rpc.get('Containers',{}))<={obj['Id']}
            or (obj['State']['Running'] and set(rpc.get('Containers',{}))!={obj['Id']})):
        raise OwnershipError('Unqualified Temporal RPC network')
    if (obj['Image']!=binding['imageId'] or image['Id']!=binding['imageId']
            or config['Privileged'] or config.get('CapAdd') or config.get('CapDrop')!=['ALL']
            or config['Memory']!=MEMORY or config['PidsLimit']!=256 or not config['ReadonlyRootfs']
            or config.get('SecurityOpt')!=['no-new-privileges:true']
            or obj['Config']['User']!=f'{os.getuid()}:{os.getgid()}'
            or (set(obj['NetworkSettings']['Networks'])!={binding['network'],rpc_network}
                and not (incomplete_setup is True and starting is True and require_running is False
                    and unstarted_network_setup(binding,obj)))
            or len(mounts)!=1 or mounts[0]['Type']!='bind' or mounts[0]['Source'] not in allowed
            or mounts[0]['Destination']!='/run/os-config' or mounts[0]['RW']):
        raise OwnershipError('Unqualified Temporal service privileges or mounts')
    if require_running and not obj['State']['Running']:
        raise OwnershipError('Owned Temporal service unavailable')
    ports=obj['NetworkSettings']['Ports']
    if obj['State']['Running'] and not (starting and binding['port']==0) and ports!={'7233/tcp':[{'HostIp':'127.0.0.1','HostPort':str(binding['port'])}]}:
        raise OwnershipError('Temporal service endpoint changed')
    if config['PortBindings'].keys()!={'7233/tcp'} or config['PortBindings']['7233/tcp'][0]['HostIp']!='127.0.0.1':
        raise OwnershipError('Unqualified Temporal published endpoint')
    if obj['Config']['Cmd']!=['--config-file','/run/os-config/server.json','--allow-no-auth','start']:
        raise OwnershipError('Unexpected Temporal service command')
    expected_environment={item.split('=',1)[0]:item.split('=',1)[1] for item in image['Config'].get('Env',[])}
    expected_environment.update(USER='agentic-os',HOME='/tmp')
    actual_environment={item.split('=',1)[0]:item.split('=',1)[1] for item in obj['Config'].get('Env',[])}
    if (actual_environment!=expected_environment
            or config.get('Tmpfs')!={'/tmp':'rw,nosuid,nodev,noexec,size=67108864'}
            or obj['Config'].get('Entrypoint')!=['temporal-server']):
        raise OwnershipError('Unqualified Temporal execution environment')
    return binding,obj


def server_configuration(manifest):
    def store(component,plugin):
        value=manifest['databases'][component]
        return {'sql':{'pluginName':plugin,'databaseName':value['name'],'connectAddr':'os-postgres:5432',
            'connectProtocol':'tcp','user':value['runtime'],'password':value['runtimePassword'],
            'maxConns':4,'maxIdleConns':2,'maxConnLifetime':'1m'}}
    def rpc(grpc,membership):return {'rpc':{'grpcPort':grpc,'membershipPort':membership,'bindOnIP':'0.0.0.0'}}
    return {'log':{'stdout':True,'level':'error'},'persistence':{'defaultStore':'default','visibilityStore':'visibility',
        'numHistoryShards':4,'datastores':{'default':store('temporal','postgres12'),
        'visibility':store('visibility','postgres12_pgx')}},
        'global':{'membership':{'maxJoinDuration':'30s','broadcastAddress':'127.0.0.1'}},
        'services':{'frontend':rpc(7233,6933),'history':rpc(7234,6934),'matching':rpc(7235,6935),'worker':rpc(7239,6939)},
        'clusterMetadata':{'enableGlobalNamespace':False,'failoverVersionIncrement':10,'masterClusterName':'active',
            'currentClusterName':'active','clusterInformation':{'active':{'enabled':True,'initialFailoverVersion':1,
            'rpcName':'frontend','rpcAddress':'127.0.0.1:7233'}}},
        'dcRedirectionPolicy':{'policy':'noop'},'archival':{'history':{'state':'disabled'},'visibility':{'state':'disabled'}},
        'namespaceDefaults':{'archival':{'history':{'state':'disabled'},'visibility':{'state':'disabled'}}}}


def provision(path, *, network_subnets=None):
    from .target import validate_target
    manifest=validate_target(path)
    return _provision_owned(path,manifest,network_subnets=network_subnets)


def _provision_owned(path,manifest,*,network_subnets=None):
    # Private implementation also used inside an authenticated held operator
    # scope. Public provisioning retains its ordinary runtime gate above.
    root=path.parent;docker=DockerControl(manifest)
    marker=root/'temporal-service.json'
    if marker.exists():
        value,obj=inspect_service(path,require_running=False,starting=True,recovered_profile=True,incomplete_setup=True)
        if network_subnets is not None and checked_subnets(network_subnets)!=value.get('networkSubnets'):
            raise OwnershipError('Existing Temporal network selection cannot change')
        if unstarted_network_setup(value,obj):finish_network_setup(path)
        return value
    if network_subnets is not None:network_subnets=available_subnets(docker,network_subnets)
    directory=root/'temporal-config';private_directory(directory)
    content=canonical_bytes(server_configuration(manifest));private_write(directory/'server.json',content)
    profile=json.loads(files('agentic_os').joinpath('deploy/profiles/local-synthetic.json').read_text())
    image=profile['components']['TEMPORAL_IMAGE']['reference']
    try:image_info=json.loads(docker.command('image','inspect',image))[0]
    except OwnershipError:
        docker.command('pull',image,timeout=300);image_info=json.loads(docker.command('image','inspect',image))[0]
    value={'version':1,'installationId':manifest['installationId'],'runId':manifest['runId'],'component':COMPONENT,
        'network':manifest['project']+'-temporal-network','container':manifest['project']+'-temporal','image':image,
        'imageId':image_info['Id'],'port':0,'configDigest':hashlib.sha256(content).hexdigest(),'namespace':'os-'+manifest['runId']}
    if network_subnets is not None:value.update(version=2,networkSubnets=network_subnets)
    # Never adopt a preexisting network/container, even with a matching name.
    for kind,name in [('network',value['network']),('network',value['network']+'-rpc'),('container',value['container'])]:
        try:docker.command(kind,'inspect',name)
        except OwnershipError:pass
        else:raise OwnershipError('Service resource name already exists')
    args=[]
    for k,v in labels(manifest).items():args+=['--label',k+'='+v]
    private_address=['--subnet',network_subnets['private']] if network_subnets else []
    rpc_address=['--subnet',network_subnets['rpc']] if network_subnets else []
    docker.command('network','create','--internal',*private_address,*args,value['network'])
    docker.command('network','create',*rpc_address,*args,value['network']+'-rpc')
    save_binding(path,value)
    docker.command('network','connect','--alias','os-postgres',value['network'],manifest['postgres']['container'])
    create_container(path,value,args)
    return value


def create_container(path,value,args=None):
    manifest=load_manifest(path);docker=DockerControl(manifest)
    if args is None:
        args=[]
        for k,v in labels(manifest).items():args+=['--label',k+'='+v]
    directory=path.parent/'temporal-config'
    docker.command('create','--name',value['container'],'--network',value['network'],*args,
        '--user',f'{os.getuid()}:{os.getgid()}','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges:true',
        '--env','USER=agentic-os','--env','HOME=/tmp',
        '--tmpfs','/tmp:rw,nosuid,nodev,noexec,size=67108864',
        '--memory',str(MEMORY),'--pids-limit','256','--publish','127.0.0.1::7233',
        '--mount',f'type=bind,source={directory},target=/run/os-config,readonly',
        '--entrypoint','temporal-server',value['image'],'--config-file','/run/os-config/server.json','--allow-no-auth','start')
    finish_network_setup(path)


def finish_network_setup(path):
    # Inspect all original image/config/security/network ownership first. An
    # interrupted connect is never blindly retried or treated as activation.
    value,obj=inspect_service(path,require_running=False,starting=True,recovered_profile=True,incomplete_setup=True)
    if not unstarted_network_setup(value,obj):return value
    docker=DockerControl(load_manifest(path))
    try:docker.command('network','connect',value['network']+'-rpc',obj['Id'])
    except OwnershipError as error:
        # A lost ACK may already have attached it. Only a complete independent
        # attestation can establish success; absence keeps the operation failed.
        try:inspect_service(path,require_running=False,starting=True,recovered_profile=True)
        except OwnershipError:raise error
    else:inspect_service(path,require_running=False,starting=True,recovered_profile=True)
    return value


def repair_failed_start(path):
    """Only a never-admitted failed stateless container; preserve all database data."""
    value,obj=inspect_service(path,require_running=False,recovered_profile=True)
    if value['port']!=0 or obj['State']['Running'] or obj['State']['Status']!='exited' or obj['State']['ExitCode']==0:
        raise OwnershipError('Only an unadmitted failed Temporal startup can be repaired')
    docker=DockerControl(load_manifest(path))
    # Private failure evidence retained before replacing this exact owned container.
    private_write(path.parent/f'temporal-failed-start-{uuid4()}.log',docker.command('logs',obj['Id']).encode())
    docker.command('rm',obj['Id'])
    content=canonical_bytes(server_configuration(load_manifest(path)))
    private_write(path.parent/'temporal-config/server.json',content,replace=True)
    value['configDigest']=hashlib.sha256(content).hexdigest();save_binding(path,value)
    create_container(path,value)
    return value


def start(path, *, network_subnets=None):
    value=provision(path,network_subnets=network_subnets)
    return _start_owned(path,value)


def _start_owned(path,value):
    manifest=load_manifest(path);docker=DockerControl(manifest)
    obj=json.loads(docker.command('inspect',value['container']))[0]
    if not obj['State']['Running']:docker.command('start',value['container'])
    deadline=time.monotonic()+15
    while True:
        obj=json.loads(docker.command('inspect',value['container']))[0]
        ports=obj['NetworkSettings']['Ports'].get('7233/tcp')
        if ports and len(ports)==1 and ports[0]['HostIp']=='127.0.0.1':break
        if not obj['State']['Running'] or time.monotonic()>deadline:
            raise OwnershipError('Started Temporal endpoint unavailable')
        time.sleep(.2)
    value['port']=int(ports[0]['HostPort']);save_binding(path,value)
    inspect_service(path,recovered_profile=True)
    return value


def stop(path):
    value,obj=inspect_service(path,require_running=False,recovered_profile=True)
    if obj['State']['Running']:DockerControl(load_manifest(path)).command('stop','--time','10',value['container'])
