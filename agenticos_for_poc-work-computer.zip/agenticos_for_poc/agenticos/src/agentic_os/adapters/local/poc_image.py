"""Owned local POC storage-image pin; legacy and deployed defaults stay unchanged.

A new builder verifies the fixed recipe, exact vector library bytes and PostgreSQL
version before recording the actual local image ID. This is an artifact binding,
not a readiness certificate or authority to adopt any existing installation.
"""
import hashlib
import json
from importlib.resources import files
from pathlib import Path
import re
from .files import OwnershipError
from .images import RDS_COMPATIBILITY_IMAGE
from .resources import read_signed, write_signed

NAME='poc-storage-image.json'
SCHEMA='owned-poc-storage-image/1'


def lock():
    return json.loads(files('agentic_os').joinpath('deploy/profiles/rds-compatibility-image.json').read_bytes())


def verify_and_bind(manifest, image):
    from .docker import DockerControl
    if manifest['profile']!='poc-rds-exact/1' or manifest['postgres'] is not None:
        raise OwnershipError('New empty local POC image binding required')
    expected=lock()
    recipe=files('agentic_os').joinpath('deploy/profiles/Dockerfile.rds-compatibility').read_bytes()
    if hashlib.sha256(recipe).hexdigest()!=expected['recipeSHA256'] or not re.fullmatch(r'sha256:[0-9a-f]{64}',image):
        raise OwnershipError('Exact packaged POC recipe/image required')
    docker=DockerControl(manifest)
    actual=json.loads(docker.command('image','inspect',image))[0]
    if actual['Id']!=image or actual.get('Architecture')!='arm64':
        raise OwnershipError('Pinned ARM64 POC image required')
    # No database, network, host mount, privilege or credentials in this probe.
    result=docker.command('run','--rm','--pull=never','--network=none','--read-only',
        '--cap-drop=ALL','--security-opt=no-new-privileges:true','--user','65534:65534',
        '--entrypoint','/bin/sh',image,'-c',
        'postgres --version; sha256sum /usr/lib/postgresql/16/lib/vector.so')
    lines=result.splitlines()
    if len(lines)!=2 or not lines[0].startswith('postgres (PostgreSQL) 16.15') or lines[1].split()[0]!=expected['vectorLibrarySHA256']:
        raise OwnershipError('POC storage binary/version verification failed')
    value=dict(schema=SCHEMA,installationId=manifest['installationId'],runId=manifest['runId'],
        image=image,recipeSHA256=expected['recipeSHA256'],vectorLibrarySHA256=expected['vectorLibrarySHA256'])
    write_signed(Path(manifest['root'])/NAME,value,Path(manifest['root'])/'owner.key')
    return image


def selected(manifest):
    path=Path(manifest['root'])/NAME
    if not path.exists():return RDS_COMPATIBILITY_IMAGE
    value=read_signed(path,path.parent/'owner.key');expected=lock()
    if (manifest['profile']!='poc-rds-exact/1' or set(value)!={'schema','installationId','runId','image','recipeSHA256','vectorLibrarySHA256'}
            or value['schema']!=SCHEMA or any(value[k]!=manifest[k] for k in ('installationId','runId'))
            or value['recipeSHA256']!=expected['recipeSHA256'] or value['vectorLibrarySHA256']!=expected['vectorLibrarySHA256']
            or re.fullmatch(r'sha256:[0-9a-f]{64}',value['image'] or '') is None):
        raise OwnershipError('Owned POC image binding differs')
    return value['image']
