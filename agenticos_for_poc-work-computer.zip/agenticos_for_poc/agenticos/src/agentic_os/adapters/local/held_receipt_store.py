"""Narrow ORM port for original admitted receipt metadata only."""
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime
from uuid import UUID

from sqlalchemy import and_,create_engine,inspect,select,text
from sqlalchemy.orm import Session,load_only
from sqlalchemy.pool import NullPool
from sqlalchemy.sql.elements import ColumnClause,TextClause
from sqlalchemy.sql.functions import FunctionElement
from sqlalchemy.sql.selectable import Select
from sqlalchemy.sql import visitors

from agentic_os.adapters.local.files import OwnershipError
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.resources import file_lock
from agentic_os.adapters.local.restoration_binding import load_restoration
from agentic_os.adapters.local.recovery_operator import connect_owned
from agentic_os.adapters.postgres.models import (BudgetRoot,Conversation,ExecutionGrant,
    InputReviewedContinuation,InputReviewedEffectAttemptBinding,InputReviewedReceiptProjection,
    InputReviewedReceiptSegment,InputReviewDecisionRecord,PublicEvent,RegisteredResourceSchema,
    Registration,ReviewedEffectProvider,Segment,Task,TaskControl,WorkAttempt)
from agentic_os.errors import OSErrorCode
from agentic_os.contracts.canonical import digest
from agentic_os.identity.context import iso
from agentic_os.identity.service import scoped

MODELS=frozenset({BudgetRoot,Conversation,ExecutionGrant,InputReviewedContinuation,
    InputReviewedEffectAttemptBinding,InputReviewedReceiptProjection,InputReviewedReceiptSegment,
    InputReviewDecisionRecord,PublicEvent,RegisteredResourceSchema,Registration,
    ReviewedEffectProvider,Segment,Task,TaskControl,WorkAttempt})
MUTABLE={BudgetRoot:frozenset({'state','version'}),Task:frozenset({'state','version'}),
    Conversation:frozenset({'version','next_sequence'})}
APPEND=frozenset({InputReviewedReceiptProjection,InputReviewedReceiptSegment,PublicEvent,Segment})
LIMITS=frozenset({"SET LOCAL lock_timeout='2s'","SET LOCAL statement_timeout='3s'"})


def metadata(row,*,exclude=()):
    def value(v):return iso(v) if isinstance(v,datetime) else str(v) if isinstance(v,UUID) else deepcopy(v)
    return {col.key:value(getattr(row,col.key)) for col in inspect(type(row)).columns if col.key not in exclude}


def accounting_digest(attempt,root):
    return digest('verification',dict(attempt=metadata(attempt),root=metadata(root,exclude={'version','state'})))


def history_digest(segment,events):
    return digest('verification',dict(segment=metadata(segment),events=[metadata(row) for row in events]))


class ReceiptRows:
    def __init__(self,rows):self.__rows=tuple(rows)
    def __iter__(self):return iter(self.__rows)


class ReceiptSession:
    """No engine, raw SQL, protected source, secret or accounting mutation port."""
    models=MODELS
    mutable=MUTABLE
    append=APPEND
    def __init__(self,session,capsule,*,readonly=False):
        if type(readonly) is not bool:raise OSErrorCode('PROFILE_DISABLED')
        self.__session=session;self.__capsule=deepcopy(capsule);self.__readonly=readonly

    def _condition(self,model):
        c=self.__capsule;h=c['handle'];s=h['subject']
        if model in {Registration,RegisteredResourceSchema,ReviewedEffectProvider}:
            version='revision' if model is Registration else 'registration_revision'
            values=[model.installation_id==UUID(s['installationId']),model.application_id==UUID(s['applicationId']),
                getattr(model,version)==c['registrationRevision']]
            if model is not Registration:values.append(model.capability_ref==c['capabilityRef'])
            return values
        values=list(scoped(model,s))
        field,ident={
            WorkAttempt:('id',h['id']),Task:('id',h['taskId']),TaskControl:('task_id',h['taskId']),
            BudgetRoot:('id',h['rootId']),Conversation:('id',c['conversationId']),
            ExecutionGrant:('id',c['grantId']),InputReviewedContinuation:('id',c['continuationId']),
            InputReviewedEffectAttemptBinding:('id',c['bindingId']),
            InputReviewDecisionRecord:('id',c['decisionId']),
            Segment:('task_id',h['taskId']),
            InputReviewedReceiptProjection:('binding_id',c['bindingId']),
            InputReviewedReceiptSegment:('binding_id',c['bindingId']),
            PublicEvent:('conversation_id',c['conversationId'])}[model]
        values.append(getattr(model,field)==UUID(ident))
        if model is PublicEvent:
            segments=select(Segment.id).where(*scoped(Segment,s),Segment.task_id==UUID(h['taskId']))
            values.append(PublicEvent.segment_id.in_(segments))
        return values

    def _query(self,statement):
        if not isinstance(statement,Select):raise OSErrorCode('PROFILE_DISABLED')
        entities={d.get('entity') for d in statement.column_descriptions}
        if len(entities)!=1 or not entities<=self.models:raise OSErrorCode('PROFILE_DISABLED')
        model=next(iter(entities))
        if statement.get_final_froms()!=[model.__table__]:raise OSErrorCode('PROFILE_DISABLED')
        for node in visitors.iterate(statement):
            if isinstance(node,TextClause) or isinstance(node,ColumnClause) and node.is_literal:
                raise OSErrorCode('PROFILE_DISABLED')
            if isinstance(node,FunctionElement) and not(model is Segment and node.name=='max'):
                raise OSErrorCode('PROFILE_DISABLED')
            if (model is InputReviewDecisionRecord and getattr(node,'__visit_name__',None)=='column'
                    and node.key in {'artifact_id','ciphertext_digest'}):
                raise OSErrorCode('PROFILE_DISABLED')
            if getattr(node,'__visit_name__',None)=='table' and node._deannotate() is not model.__table__:
                raise OSErrorCode('PROFILE_DISABLED')
        if statement._having_criteria or statement._group_by_clauses or statement._distinct or statement._offset_clause is not None:
            raise OSErrorCode('PROFILE_DISABLED')
        result=statement.where(*self._condition(model)).limit(129)
        if self.__readonly:
            # Original capture runs in an actual READ ONLY transaction. The
            # genuine binding inspector requests locks, but cannot publish or
            # alter any source row in this selection-only port.
            result=select(*(d['expr'] for d in statement.column_descriptions)).where(
                *statement._where_criteria,*self._condition(model)).order_by(
                *statement._order_by_clauses).limit(129)
            if statement._execution_options.get('populate_existing') is True:
                result=result.execution_options(populate_existing=True)
        if len(statement.column_descriptions)==1 and statement.column_descriptions[0]['expr'] is model:
            # Decision ciphertext and artifact pointers are unnecessary for
            # truthful late receipt publication. Lazy fetching is forbidden.
            columns=[getattr(model,col.key) for col in inspect(model).columns
                if not(model is InputReviewDecisionRecord and col.key in {'artifact_id','ciphertext_digest'})]
            result=result.options(load_only(*columns,raiseload=True))
        return result

    def scalars(self,statement):
        query=self._query(statement)
        rows=list(self.__session.scalars(query))
        if len(rows)>128:raise OSErrorCode('CAPACITY')
        return ReceiptRows(rows)

    def scalar(self,statement):
        rows=list(self.scalars(statement))
        return rows[0] if rows else None

    def get(self,model,ident):
        if model not in self.models:raise OSErrorCode('PROFILE_DISABLED')
        keys=list(inspect(model).primary_key)
        values=ident if isinstance(ident,tuple) else (ident,)
        if len(keys)!=len(values):raise OSErrorCode('DENIED')
        return self.scalar(select(model).where(*(getattr(model,k.key)==v for k,v in zip(keys,values))))

    def execute(self,statement,*args,**kwargs):
        if args or kwargs or not isinstance(statement,TextClause) or statement.text not in LIMITS:
            raise OSErrorCode('PROFILE_DISABLED')
        self.__session.execute(statement)

    def verify_capsule(self):
        c=self.__capsule;h=c['handle']
        # This fixed internal proof cannot be parameterized by the receipt
        # caller. Keep the public single-model port narrow, and reread every
        # original row before and after each transaction, including retained
        # ORM instances. The extra row detects the original 128-event bound.
        rows=list(self.__session.execute(select(WorkAttempt,BudgetRoot,Segment,PublicEvent).select_from(WorkAttempt)
            .join(BudgetRoot,and_(*self._condition(BudgetRoot)))
            .join(Segment,and_(*self._condition(Segment),Segment.id==UUID(h['segmentId'])))
            .outerjoin(PublicEvent,and_(*scoped(PublicEvent,h['subject']),
                PublicEvent.conversation_id==UUID(c['conversationId']),PublicEvent.segment_id==Segment.id))
            .where(*self._condition(WorkAttempt)).order_by(PublicEvent.sequence).limit(129)
            .execution_options(populate_existing=True)))
        if len(rows)>128:raise OSErrorCode('CAPACITY')
        if not rows:raise OwnershipError('Original receipt accounting or history changed')
        attempt,root,segment,_=rows[0]
        events=[row[3] for row in rows if row[3] is not None]
        if (attempt.state!='UNKNOWN'
                or root.state!='QUARANTINED' or accounting_digest(attempt,root)!=c['accountingDigest']
                or history_digest(segment,events)!=c['originalHistoryDigest']):
            raise OwnershipError('Original receipt accounting or history changed')

    def add(self,row):
        if self.__readonly or type(row) not in self.append:raise OSErrorCode('PROFILE_DISABLED')
        self.__session.add(row)

    def flush(self):
        s=self.__session;c=self.__capsule;h=c['handle'];subject=h['subject']
        if self.__readonly:
            if s.new or s.dirty or s.deleted:raise OSErrorCode('PROFILE_DISABLED')
            return
        if s.deleted:raise OSErrorCode('PROFILE_DISABLED')
        for row in s.dirty:
            allowed=self.mutable.get(type(row),frozenset())
            changed={a.key for a in inspect(row).attrs if a.history.has_changes()}
            if not changed<=allowed:raise OSErrorCode('PROFILE_DISABLED')
            for field in changed & {'version','next_sequence'}:
                history=inspect(row).attrs[field].history
                if (len(history.deleted)!=1 or type(getattr(row,field)) is not int
                        or not 1<=getattr(row,field)-history.deleted[0]<=(3 if field=='next_sequence' else 2)):
                    raise OSErrorCode('DENIED')
            if type(row) is BudgetRoot and row.state!='QUARANTINED':raise OSErrorCode('DENIED')
            if type(row) is Task and row.state not in {'QUARANTINED','RECONCILING'}:raise OSErrorCode('DENIED')
        for row in s.new:
            if type(row) not in self.append:raise OSErrorCode('PROFILE_DISABLED')
            actual={k:str(getattr(row,{'installationId':'installation_id','applicationId':'application_id',
                'tenantId':'tenant_id','subjectId':'subject_id'}[k])) for k in subject}
            if actual!=subject:raise OSErrorCode('DENIED')
            if isinstance(row,(InputReviewedReceiptProjection,InputReviewedReceiptSegment)) and row.binding_id!=UUID(c['bindingId']):
                raise OSErrorCode('DENIED')
            if isinstance(row,(Segment,InputReviewedReceiptSegment)) and row.task_id!=UUID(h['taskId']):raise OSErrorCode('DENIED')
            if isinstance(row,Segment) and row.state!='FINISHED':raise OSErrorCode('DENIED')
            if isinstance(row,PublicEvent) and row.conversation_id!=UUID(c['conversationId']):raise OSErrorCode('DENIED')
        s.flush()


class HeldReceiptStore:
    """One exact admitted capsule per finite held operator transaction."""
    def __init__(self,path,token,admitted,capsule,authenticate):
        self.__path=path;self.__token=token;self.__admitted=deepcopy(admitted)
        self.__capsule=deepcopy(capsule);self.__authenticate=authenticate
        self.__engine=create_engine('postgresql+psycopg://',poolclass=NullPool,
            creator=lambda:connect_owned(path,role='migrator'))

    def _held(self):
        verify_operator(self.__path,self.__token)
        if load_restoration(self.__path)!=self.__admitted:raise OwnershipError('Held receipt restoration changed')
        self.__authenticate()

    @contextmanager
    def transaction(self):
        with file_lock(self.__path.parent/'recovery-gate.lock',timeout=2,shared=True):
            self._held()
            with Session(self.__engine,autoflush=False,expire_on_commit=False) as session:
                with session.begin():
                    session.execute(text("SET LOCAL lock_timeout='2s'"))
                    session.execute(text("SET LOCAL statement_timeout='3s'"))
                    port=ReceiptSession(session,self.__capsule)
                    port.verify_capsule()
                    yield port
                    port.flush();port.verify_capsule();self._held()

    def close(self):self.__engine.dispose()
