"""Fresh manifest-owned PostgreSQL provisioning. No automatic host discovery/seeding."""
import json
from pathlib import Path
import time

import psycopg
from psycopg import sql

from agentic_os.contracts.canonical import canonical_bytes
from .docker import DockerControl
from .files import OwnershipError, private_write
from .ownership import create_root, save_manifest, load_manifest, COMPONENTS

from .images import PG_IMAGE


def install_postgres(root: Path, docker_endpoint: str, *, installation_id: str | None = None,
                     disposition="active-retained",capacity_source=None,rds_compatibility=False,profile='test',poc_image=None) -> Path:
    from .capacity import Capacity, GiB, docker_headroom
    from .build_cache import cache_root, admission_root
    from .retention import hold, fixture_lease, provisioned
    from .resources import canonical_path
    canonical_path(root)
    from .ownership import POC_PROFILE
    if profile not in {'test',POC_PROFILE} or profile==POC_PROFILE and not rds_compatibility or poc_image is not None and profile!=POC_PROFILE:
        raise OwnershipError('Explicit exact POC installation profile required')
    if type(rds_compatibility) is not bool:raise OwnershipError('Explicit RDS rehearsal selection required')
    if root.exists():
        raise OwnershipError("Installation requires a new directory")
    capacity = Capacity(admission_root(cache_root(root)))
    capacity_image=PG_IMAGE
    if capacity_source is not None:
        source=load_manifest(capacity_source)
        if source['profile']==POC_PROFILE:
            from .images import RDS_COMPATIBILITY_IMAGE
            from .poc_image import selected
            capacity_image=selected(source)
    docker_free = (docker_headroom(docker_endpoint,PG_IMAGE) if capacity_source is None
        else docker_headroom(docker_endpoint,capacity_image,owned_source=capacity_source))
    with capacity.reserve(2 * GiB, purpose="installation", docker_free=docker_free, docker_peak=GiB):
        manifest = create_root(root, docker_endpoint=docker_endpoint, installation_id=installation_id,
                               disposition=disposition,profile=profile)
        path = root / "manifest.json"
        try:
            with fixture_lease(path):
                if poc_image is not None:
                    from .poc_image import verify_and_bind
                    verify_and_bind(manifest,poc_image)
                if rds_compatibility:_provision_postgres(manifest,rds_compatibility=True)
                else:_provision_postgres(manifest)
                provisioned(path)
        except BaseException:
            hold(path)
            raise
        return path


def _provision_postgres(manifest,*,rds_compatibility=False) -> Path:
    root = Path(manifest["root"])
    docker = DockerControl(manifest)
    if type(rds_compatibility) is not bool:raise OwnershipError('Explicit RDS rehearsal selection required')
    from .images import RDS_COMPATIBILITY_IMAGE
    from .poc_image import selected
    selected_image=selected(manifest) if rds_compatibility else PG_IMAGE
    # Digest-pinned pull is explicit installation; ordinary startup never downloads.
    try:
        image = json.loads(docker.command("image", "inspect", selected_image))[0]
    except OwnershipError:
        if rds_compatibility:raise OwnershipError('Pinned local RDS qualification image must be explicitly built first')
        docker.command("pull", selected_image, timeout=300)
        image = json.loads(docker.command("image", "inspect", selected_image))[0]
    labels = ["io.agentic-os.installation=" + manifest["installationId"],
              "io.agentic-os.run=" + manifest["runId"], "io.agentic-os.component=postgres"]
    label_args = [argument for label in labels for argument in ["--label", label]]
    volume = manifest["project"] + "-postgres"
    docker.command("volume", "create", *label_args, volume)
    private_write(root / "bootstrap-password", manifest["bootstrapPassword"].encode())
    container = docker.command("run", "-d", "--name", manifest["project"] + "-postgres",
        *label_args, "--memory", "1g", "--pids-limit", "128", "--security-opt", "no-new-privileges:true",
        "-p", "127.0.0.1::5432", "--mount", f"type=volume,source={volume},target=/var/lib/postgresql/data",
        "--mount", f"type=bind,source={root / 'bootstrap-password'},target=/run/os-bootstrap-password,readonly",
        "-e", "POSTGRES_USER=aos_bootstrap", "-e", "POSTGRES_DB=postgres",
        "-e", "POSTGRES_PASSWORD_FILE=/run/os-bootstrap-password", selected_image)
    obj = json.loads(docker.command("inspect", container))[0]
    port = int(obj["NetworkSettings"]["Ports"]["5432/tcp"][0]["HostPort"])
    manifest["postgres"] = {"container": container, "volume": volume, "image": selected_image,
                            "imageId": image["Id"], "host": "127.0.0.1", "port": port}
    save_manifest(root, manifest)
    docker.inspect_owned(manifest)
    deadline = time.monotonic() + 45
    while True:
        try:
            connection = psycopg.connect(host="127.0.0.1", port=port, dbname="postgres",
                user="aos_bootstrap", password=manifest["bootstrapPassword"], connect_timeout=1,
                autocommit=True)
            break
        except psycopg.OperationalError:
            if time.monotonic() >= deadline:
                raise OwnershipError("Owned PostgreSQL startup deadline exceeded") from None
            time.sleep(0.2)
    with connection as db:
        if db.execute("SHOW server_version").fetchone()[0].split()[0] != "16.15":
            raise OwnershipError("Unqualified PostgreSQL server version")
        for component in manifest['databases']:
            definition = manifest["databases"][component]
            for kind in ["migrator", "runtime"]:
                role = definition[kind]
                password = definition[kind + "Password"]
                db.execute(sql.SQL("CREATE ROLE {} LOGIN PASSWORD {} NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT").format(
                    sql.Identifier(role), sql.Literal(password)))
            db.execute(sql.SQL("CREATE DATABASE {} OWNER {}").format(
                sql.Identifier(definition["name"]), sql.Identifier(definition["migrator"])))
            db.execute(sql.SQL("REVOKE ALL ON DATABASE {} FROM PUBLIC").format(sql.Identifier(definition["name"])))
            db.execute(sql.SQL("GRANT CONNECT ON DATABASE {} TO {}, {}").format(
                sql.Identifier(definition["name"]), sql.Identifier(definition["migrator"]), sql.Identifier(definition["runtime"])))
        db.execute("REVOKE CONNECT ON DATABASE postgres FROM PUBLIC")
    for component in manifest['databases']:
        definition = manifest["databases"][component]
        with psycopg.connect(host="127.0.0.1", port=port, dbname=definition["name"],
                user="aos_bootstrap", password=manifest["bootstrapPassword"], autocommit=True) as db:
            db.execute("REVOKE ALL ON SCHEMA public FROM PUBLIC")
            db.execute(sql.SQL("GRANT USAGE,CREATE ON SCHEMA public TO {}").format(sql.Identifier(definition["migrator"])))
            db.execute(sql.SQL("GRANT USAGE ON SCHEMA public TO {}").format(sql.Identifier(definition["runtime"])))
            if component in {"retrieval", "knowledge"}:
                db.execute("CREATE EXTENSION vector")
                if db.execute("SELECT extversion FROM pg_extension WHERE extname='vector'").fetchone()[0] != ('0.8.2' if rds_compatibility else '0.8.7'):
                    raise OwnershipError("Unqualified pgvector extension")
            db.execute(sql.SQL("ALTER DEFAULT PRIVILEGES FOR ROLE {} IN SCHEMA public GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO {}").format(
                sql.Identifier(definition["migrator"]), sql.Identifier(definition["runtime"])))
    return root / "manifest.json"


def stop_owned(path: Path) -> None:
    from .retention import fixture_lease
    with fixture_lease(path):
        _stop_owned(path)


def _stop_owned(path: Path) -> None:
    manifest = load_manifest(path)
    docker = DockerControl(manifest)
    docker.inspect_owned(manifest)
    # Preserve volume/evidence. A later explicit erasure command owns data removal.
    docker.command("stop", "--time", "10", manifest["postgres"]["container"])
