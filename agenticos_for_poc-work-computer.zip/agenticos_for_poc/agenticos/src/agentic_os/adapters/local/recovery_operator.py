"""Short explicit operator scopes on an authenticated held restoration."""
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

from .files import OwnershipError
from .operator import verify_operator
from .resources import file_lock
from .restoration_binding import load_restoration
from .target import validate_target as _local_target,connect_owned as _local_connect
from .ownership import load_manifest

_configured=ContextVar('held_recovery_operator',default=None)


def _scope(path):
    path=Path(path);selected=_configured.get()
    if selected is None or selected['path']!=path:
        raise OwnershipError('Explicit authenticated managed recovery operator scope required')
    if selected.get('maintenanceCommand') is not None:
        from .recovery_maintenance import verify_maintenance_operator
        verify_maintenance_operator(path,selected['token'],selected['maintenanceCommand'])
    else:verify_operator(path,selected['token'])
    if selected.get('keyGeneration') is not None:
        admitted=_key_archive(path,selected['keyGeneration'])
    elif selected.get('maintenanceCommand') is not None:
        from .recovery_maintenance import operator_archive
        admitted=operator_archive(path,selected['maintenanceCommand'])
    else:admitted=load_restoration(path)
    if admitted!=selected['admitted']:
        raise OwnershipError('Managed recovery operator binding changed')
    return selected


def _key_archive(path,generation):
    """Authenticated current metadata remains inspectable after key loss."""
    from .recovery_ready import _release_metadata,admitted_archive
    if load_manifest(Path(path))['profile']!='aws-eks/1':raise OwnershipError('Explicit managed key installation required')
    if type(generation) is not int or generation<1:raise OwnershipError('Exact managed key generation required')
    value=_release_metadata(path)
    if value['generation']!=generation:raise OwnershipError('Managed key generation changed')
    return admitted_archive(path)


def verify_key_operator(path,token,generation):
    identity=verify_operator(Path(path),token)
    if load_manifest(Path(path))['profile']!='aws-eks/1':return identity
    selected=_scope(path)
    if (selected.get('keyGeneration')!=generation or selected['token']!=token
            or selected['operator'](token)!=selected['operatorIdentity']):
        raise OwnershipError('Current scoped managed key operator required')
    return selected['operatorIdentity']


@contextmanager
def configured_operator(path,token,document,*,maintenance_command=None,key_generation=None):
    """Bind existing recovery functions to exact held provider ports.

    Context propagates to their bounded worker threads. It grants no ordinary
    runtime port, and every connection rechecks the original held binding.
    """
    from agentic_os.adapters.aws import managed_restore,storage,temporal
    path=Path(path)
    if maintenance_command is not None:
        from .recovery_maintenance import verify_maintenance_operator
        verify_maintenance_operator(path,token,maintenance_command)
    else:verify_operator(path,token)
    from . import recovery_gate
    from .recovery_ready import certificate,admitted_archive
    if key_generation is not None and maintenance_command is not None:raise OwnershipError('One explicit managed operator purpose required')
    if key_generation is not None:
        admitted=_key_archive(path,key_generation);ready=None
    elif maintenance_command is not None:
        from .recovery_maintenance import operator_archive
        admitted=operator_archive(path,maintenance_command);ready=None
    else:
        ready=certificate(path) if recovery_gate.state(path)['mode']=='READY' else None
        admitted=admitted_archive(path) if ready is not None else load_restoration(path)
    record=managed_restore._record(path)
    from .recovery_maintenance import cloud_configuration
    if document not in (cloud_configuration(path),cloud_configuration(path,command=maintenance_command)) or _configured.get() is not None:
        raise OwnershipError('Exact un-nested managed recovery configuration required')
    cloud=temporal.load_operator_configuration(Path(document['cloud_configuration']))
    options={} if key_generation is None else dict(key_generation=key_generation)
    with storage.configured_storage(document['stores']) as (stores,operator),temporal.configured_operator_connection(cloud,**options) as connection:
        identity=operator(token);connection.installation.verify_operator(token)
        selected=dict(path=path,token=token,admitted=admitted,document=document,stores=stores,
            operator=operator,installation=connection.installation,connection=connection,maintenanceCommand=maintenance_command,
            keyGeneration=key_generation,operatorIdentity=identity)
        context=_configured.set(selected)
        try:
            if ready is None:_scope(path)
            elif certificate(path)!=ready or admitted_archive(path)!=admitted:
                raise OwnershipError('Managed release acknowledgement changed')
            yield connection
            if key_generation is not None:_scope(path)
            elif recovery_gate.state(path)['mode']=='READY':
                certificate(path)
                if admitted_archive(path)!=admitted:raise OwnershipError('Managed release archive changed')
            else:_scope(path)
            if operator(token)!=identity:raise OwnershipError('Managed recovery credential changed')
        finally:_configured.reset(context)


def configured_cloud_document(path):
    """Only an active authenticated operator can select pending transport."""
    if _configured.get() is None:return None
    selected=_scope(Path(path))
    from .recovery_maintenance import cloud_configuration
    return cloud_configuration(Path(path),command=selected.get('maintenanceCommand'))


def validate_target(path,*,component='control',role='runtime'):
    if load_manifest(Path(path))['profile']!='aws-eks/1':return _local_target(path,component=component,role=role)
    if role!='migrator' or component not in {'control','retrieval','knowledge'}:
        raise OwnershipError('Managed held operator component/role differs')
    selected=_scope(path)
    if selected.get('keyGeneration') is not None:raise OwnershipError('Key inspection cannot grant SQL operator access')
    return load_manifest(Path(path))


def connect_owned(path,*,component='control',role='runtime',autocommit=False):
    """Existing held SQL only; local behavior retains its independent guard."""
    if load_manifest(Path(path))['profile']!='aws-eks/1':
        return _local_connect(path,component=component,role=role,autocommit=autocommit)
    validate_target(path,component=component,role=role);selected=_scope(path)
    from agentic_os.adapters.aws.storage import check_control_namespace,check_component_namespace
    selected['operator'](selected['token'])
    db=selected['stores'][component].connect()
    try:
        if component=='control':check_control_namespace(db,selected['stores'][component].installation_id)
        else:check_component_namespace(db,selected['stores'][component].installation_id,component)
        _scope(path);db.rollback()
        if autocommit:db.autocommit=True
        return db
    except BaseException:db.close();raise


def migrate(path,*,component='control',check_only=False,diagnostic_stream=None):
    if load_manifest(Path(path))['profile']!='aws-eks/1':
        from agentic_os.adapters.postgres.migrate import migrate as local
        return local(path,component=component,check_only=check_only,diagnostic_stream=diagnostic_stream)
    if not check_only:raise OwnershipError('Managed recovery cannot apply schema changes')
    selected=_scope(path)
    from agentic_os.adapters.aws.storage import prepare_component
    check=selected['operator'].checkpoint(selected['token'])
    return prepare_component(selected['stores'][component],expected_head=selected['document']['stores']['expected_heads'][component],
        check_only=True,operator_check=check,file_check=lambda:_scope(path))


def installation(path):
    if load_manifest(Path(path))['profile']!='aws-eks/1':return None
    return _scope(path)['installation']


@contextmanager
def held_operator(path, token, *, expected_generation):
    path = Path(path)
    verify_operator(path, token)
    with file_lock(path.parent/'recovery-gate.lock', timeout=2):
        binding = load_restoration(path)
        if (type(expected_generation) is not int
                or binding['generation'] != expected_generation):
            raise OwnershipError('Held restoration generation differs')
        manifest = validate_target(path, role='migrator')
        yield manifest, binding
        verify_operator(path, token)
        if load_restoration(path) != binding:
            raise OwnershipError('Held restoration changed during operator work')
