"""Operator-owned local lifecycle; partial availability never means agent readiness."""
import json
from copy import deepcopy
import os
from pathlib import Path
import platform
import subprocess
import tempfile
import time

from .artifacts import LocalKeys
from .components import migrate_components
from .docker import DockerControl
from .files import OwnershipError, private_write
from .installer import install_postgres
from .ownership import load_manifest, save_manifest, validate_docker_endpoint, COMPONENTS
from .target import connect_owned, validate_target
from .operator import issue_bootstrap
from agentic_os.adapters.postgres.migrate import migration_head


def preflight(docker_endpoint: str) -> dict:
    validate_docker_endpoint(docker_endpoint)
    if (platform.system(),platform.machine())!=('Darwin','arm64'):
        raise OwnershipError('Full local foundation installer qualified only for Darwin arm64')
    with tempfile.TemporaryDirectory(prefix='aos-preflight-') as scratch:
        env={'PATH':os.environ.get('PATH','/usr/bin:/bin'),'HOME':scratch,'DOCKER_CONFIG':scratch,
             'DOCKER_HOST':docker_endpoint}
        result=subprocess.run(['docker','info','--format','{{json .}}'],env=env,capture_output=True,text=True,timeout=10)
        if result.returncode:
            raise OwnershipError('Explicit local Docker runtime unavailable')
        info=json.loads(result.stdout)
        if info['NCPU']<2 or info['MemTotal']<4*1024**3:
            raise OwnershipError('Foundation requires at least two CPUs and 4 GiB Docker memory')
        return {'placement':'darwin-arm64/local-synthetic','dockerVersion':info['ServerVersion'],
                'cpuCount':info['NCPU'],'memoryMiB':info['MemTotal']//1024**2,'hostRequired':False}


def plan(root: Path, docker_endpoint: str,*,capacity_source=None) -> dict:
    if not root.is_absolute() or root.exists() or root.is_symlink():
        raise OwnershipError('Plan requires a new explicit installation directory')
    from .capacity import Capacity, GiB, docker_headroom
    from .build_cache import cache_root, admission_root
    from .installer import PG_IMAGE
    free=(docker_headroom(docker_endpoint,PG_IMAGE) if capacity_source is None
        else docker_headroom(docker_endpoint,PG_IMAGE,owned_source=capacity_source))
    capacity=Capacity(admission_root(cache_root(root))).preview(4*GiB,docker_free=free,docker_peak=GiB)
    if not capacity['admitted']:
        raise OwnershipError('Insufficient installation capacity')
    return {'version':1,'profile':'local-synthetic','preflight':preflight(docker_endpoint),'capacity':capacity,
            'root':str(root.resolve()),'components':list(COMPONENTS),'ownedVolumes':['postgres'],
            'publishedPorts':'one allocated loopback PostgreSQL port','enabledLanes':[],
            'migrations':[migration_head(),migration_head('retrieval'),'Temporal original','Core original'],
            'recovery':'quiescent foundation only; live-task/privacy recovery is a later gate'}


def install(root: Path, docker_endpoint: str, *, disposition="active-retained",capacity_source=None) -> Path:
    selected={} if capacity_source is None else dict(capacity_source=capacity_source)
    preview=plan(root,docker_endpoint,**selected)
    from .capacity import Capacity, GiB
    from .build_cache import cache_root, admission_root
    capacity=Capacity(admission_root(cache_root(root)))
    with capacity.reserve(4*GiB,purpose='installation',
            docker_free=preview['capacity']['dockerFreeBytes'],docker_peak=GiB):
        return _install(root,docker_endpoint,disposition=disposition,**selected)


def _install(root: Path, docker_endpoint: str, *, disposition,capacity_source=None) -> Path:
    path=install_postgres(root,docker_endpoint,disposition=disposition,
        **({} if capacity_source is None else dict(capacity_source=capacity_source)))
    root=path.parent
    try:
        from .retention import fixture_lease
        with fixture_lease(path):
            versions=migrate_components(path)
            LocalKeys(root/'keys').rotate()
            issue_bootstrap(path)
            private_write(root/'installed.json',json.dumps({'version':1,'phase':'G01',
                'componentVersions':versions,'enabledLanes':[]},sort_keys=True).encode())
    except BaseException:
        from .retention import hold
        hold(path)
        private_write(root/'install-blocked',b'Installation incomplete; no runtime activation; evidence/resources preserved',replace=True)
        raise
    return path


def readiness(path: Path) -> dict:
    # No database names, keys, error strings or private content in this projection.
    status={component:'unavailable' for component in COMPONENTS}
    try:
        manifest=validate_target(path)
        if (Path(manifest['root'])/'restore-blocked').exists() or (Path(manifest['root'])/'install-blocked').exists():
            return {'status':'blocked','components':status,'enabledLanes':[]}
        for component in COMPONENTS:
            with connect_owned(path,component=component) as db:
                if component in {'control','retrieval','knowledge'}:
                    revision=db.execute('SELECT version_num FROM alembic_version').fetchone()[0]
                    expected=migration_head(component)
                    ready=revision==expected
                elif component in {'temporal','visibility'}:
                    ready=db.execute('SELECT curr_version FROM schema_version').fetchone()[0]==(
                        '1.19' if component=='temporal' else '1.14')
                else:
                    ready=db.execute('SELECT max(version_id) FROM agents_api_schema_version WHERE is_applied').fetchone()[0]==91
                status[component]='ready' if ready else 'incompatible'
        return {'status':'storage-ready' if all(value=='ready' for value in status.values()) else 'degraded',
                'components':status,'enabledLanes':[]}
    except Exception:
        return {'status':'unavailable','components':status,'enabledLanes':[]}


def start_storage(path: Path):
    from .retention import fixture_lease
    with fixture_lease(path):
        return _start_storage(path)


def _start_storage(path: Path):
    manifest=load_manifest(path); docker=DockerControl(manifest)
    if manifest['postgres'] is None:raise OwnershipError('PostgreSQL has not been provisioned')
    obj=json.loads(docker.command('inspect',manifest['postgres']['container']))[0]
    if obj['State']['Running']:
        # An external Engine restart can publish a new ephemeral port before
        # this operator is called. Treat that observation as untrusted: the
        # unchanged complete ownership guard must accept the exact candidate
        # before updating signed metadata or connecting to the database.
        ports=obj['NetworkSettings'].get('Ports',{})
        if (set(ports)!={'5432/tcp'} or len(ports['5432/tcp'])!=1
                or ports['5432/tcp'][0]['HostIp']!='127.0.0.1'):
            raise OwnershipError('Started component endpoint unqualified')
        raw=ports['5432/tcp'][0]['HostPort']
        if (type(raw) is not str or not raw.isascii() or not raw.isdecimal()
                or not 1<=int(raw)<=65535 or str(int(raw))!=raw):
            raise OwnershipError('Started component port unqualified')
        candidate=deepcopy(manifest);candidate['postgres']['port']=int(raw)
        obj=docker.inspect_owned(candidate)
        if candidate['postgres']['port']!=manifest['postgres']['port']:
            save_manifest(path.parent,candidate);manifest=candidate
    else:obj=docker.inspect_owned(manifest,require_running=False)
    if not obj['State']['Running']:
        docker.command('start',manifest['postgres']['container'])
        obj=json.loads(docker.command('inspect',manifest['postgres']['container']))[0]
        ports=obj['NetworkSettings']['Ports']
        if set(ports)!={'5432/tcp'} or ports['5432/tcp'][0]['HostIp']!='127.0.0.1':
            raise OwnershipError('Started component endpoint unqualified')
        manifest['postgres']['port']=int(ports['5432/tcp'][0]['HostPort'])
        save_manifest(path.parent,manifest)
    deadline=time.monotonic()+30
    while True:
        try:
            with connect_owned(path):
                break
        except Exception:
            if time.monotonic()>deadline:
                raise OwnershipError('Owned storage readiness deadline exceeded') from None
            time.sleep(.2)
    from .retention import refresh_postgres_endpoint
    refresh_postgres_endpoint(path)
    return readiness(path)
