"""Exact admitted production receipt metadata; no execution or private payloads."""
from contextlib import contextmanager
from copy import deepcopy
from uuid import UUID

from sqlalchemy import create_engine,func,select,text
from sqlalchemy.orm import Session
from sqlalchemy.pool import NullPool

from agentic_os.adapters.postgres.models import (Admission,AgentEffectReceipt,AgentReviewDecision,
    AgentReviewRecord,AgentToolAcceptance,AgentToolCall,AgentToolProfile,AgentWriteConflictBinding,
    AgentWriteConflictClaim,AgentWriteConflictPolicyRecord,AgentWriteConflictRoot,BudgetRoot,Conversation,
    PublicEvent,RegisteredResourceSchema,Registration,ReviewedEffectProvider,Segment,Task,TaskControl,WorkAttempt)
from agentic_os.contracts.canonical import digest
from agentic_os.errors import OSErrorCode
from agentic_os.identity.service import scoped
from .files import OwnershipError
from .held_receipt_store import ReceiptSession,accounting_digest,history_digest,metadata
from .resources import file_lock
from .target import connect_owned


def call_metadata_columns():
    return (AgentToolCall.request['record']['profile']['digest'].as_string(),
        AgentToolCall.request['record']['capability']['ref'].as_string())


def conflict_digest(binding,claims):
    return digest('verification',dict(binding=metadata(binding,exclude={'state','version','released_at','receipt_id'}),
        claims=[metadata(row,exclude={'state'}) for row in sorted(claims,key=lambda row:str(row.id))]))


class ProductionReceiptSession(ReceiptSession):
    models=frozenset({Admission,AgentEffectReceipt,AgentReviewDecision,AgentReviewRecord,AgentToolAcceptance,
        AgentToolCall,AgentToolProfile,AgentWriteConflictBinding,AgentWriteConflictClaim,AgentWriteConflictPolicyRecord,
        AgentWriteConflictRoot,BudgetRoot,Conversation,PublicEvent,RegisteredResourceSchema,Registration,
        ReviewedEffectProvider,Segment,Task,TaskControl,WorkAttempt})
    mutable={BudgetRoot:frozenset({'state','version'}),Task:frozenset({'state','version'}),
        Conversation:frozenset({'version'}),
        AgentWriteConflictBinding:frozenset({'state','version','released_at','receipt_id'}),
        AgentWriteConflictClaim:frozenset({'state'})}
    append=frozenset({AgentEffectReceipt})

    def __init__(self,session,capsule,*,readonly=False):
        super().__init__(session,capsule,readonly=True if capsule['handle'].get('state')=='RESERVED' else readonly)
        self._capsule=deepcopy(capsule)

    def _condition(self,model):
        c=self._capsule;h=c['handle'];s=h['subject'];conflict=c['conflict']
        if model in {Registration,RegisteredResourceSchema,ReviewedEffectProvider}:
            version='revision' if model is Registration else 'registration_revision'
            values=[model.installation_id==UUID(s['installationId']),model.application_id==UUID(s['applicationId']),
                getattr(model,version)==c['registrationRevision']]
            if model is not Registration:values.append(model.capability_ref==c['capabilityRef'])
            return values
        if model is AgentToolProfile:
            return [model.installation_id==UUID(s['installationId']),model.application_id==UUID(s['applicationId']),
                model.policy_digest==c['toolProfileDigest']]
        if model is AgentWriteConflictPolicyRecord:
            if conflict is None:raise OSErrorCode('PROFILE_DISABLED')
            return [model.installation_id==UUID(s['installationId']),model.application_id==UUID(s['applicationId']),
                model.policy_digest==conflict['policyDigest']]
        if model in {AgentWriteConflictRoot,AgentWriteConflictBinding,AgentWriteConflictClaim} and conflict is None:
            raise OSErrorCode('PROFILE_DISABLED')
        field,ident={WorkAttempt:('id',h['id']),BudgetRoot:('id',h['rootId']),Task:('id',h['taskId']),
            TaskControl:('task_id',h['taskId']),Conversation:('id',c['conversationId']),
            Admission:('id',c['admissionId']),AgentReviewDecision:('id',c['decisionId']),
            AgentReviewRecord:('id',c['reviewId']),AgentToolAcceptance:('id',c['preparationId']),
            AgentToolCall:('id',c['callId']),Segment:('task_id',h['taskId']),PublicEvent:('segment_id',h['segmentId']),
            AgentEffectReceipt:('binding_id',h['id']),AgentWriteConflictRoot:('root_id',h['rootId']),
            AgentWriteConflictBinding:('decision_id',c['decisionId']),
            AgentWriteConflictClaim:('binding_id',conflict['bindingId'] if conflict else h['id'])}[model]
        return [*scoped(model,s),getattr(model,field)==UUID(ident)]

    def _query(self,statement):
        from sqlalchemy.sql.selectable import Select
        if not isinstance(statement,Select):raise OSErrorCode('PROFILE_DISABLED')
        # The existing observer uses only the current database time. No other
        # unscoped function, table, expression or arbitrary SQL is exposed.
        if statement.compare(select(func.clock_timestamp())):return statement
        descriptions=statement.column_descriptions
        if any(row.get('entity') is AgentToolCall for row in descriptions):
            if (len(descriptions)!=1 or not callable(getattr(descriptions[0]['expr'],'compare',None))
                    or not any(descriptions[0]['expr'].compare(column)
                    for column in call_metadata_columns())):raise OSErrorCode('PROFILE_DISABLED')
            # This lookup is built by the shared grant reader. Conditions may
            # reference only scoped IDs; they cannot probe private arguments.
            from sqlalchemy.sql import visitors
            allowed={'id','installation_id','application_id','tenant_id','subject_id'}
            if any(getattr(node,'__visit_name__',None)=='column' and getattr(node,'key',None) not in allowed
                    for clause in statement._where_criteria for node in visitors.iterate(clause)):
                raise OSErrorCode('PROFILE_DISABLED')
        return super()._query(statement)

    def verify_capsule(self):
        c=self._capsule;h=c['handle'];attempt=self.get(WorkAttempt,UUID(h['id']));root=self.get(BudgetRoot,UUID(h['rootId']))
        segment=self.get(Segment,UUID(h['segmentId']))
        events=list(self.scalars(select(PublicEvent).where(PublicEvent.segment_id==UUID(h['segmentId']))
            .order_by(PublicEvent.sequence)))
        if (attempt is None or root is None or segment is None or h['state'] not in {'RESERVED','RUNNING','UNKNOWN'}
                or attempt.state!=h['state']
                or attempt.kind!='agent.effect' or root.profile_ref!='agent-production/1'
                or accounting_digest(attempt,root)!=c['accountingDigest']
                or history_digest(segment,events)!=c['originalHistoryDigest']):
            raise OwnershipError('Original production receipt accounting or history changed')
        decision=self.get(AgentReviewDecision,UUID(c['decisionId']));review=self.get(AgentReviewRecord,UUID(c['reviewId']))
        if (decision is None or review is None or decision.digest!=c['decisionDigest'] or review.digest!=c['reviewDigest']
                or str(attempt.invocation_id)!=c['decisionId'] or attempt.request_digest!=c['reservationDigest']):
            raise OwnershipError('Original production decision changed')
        from agentic_os.production.reviewed_effect import ProductionEffectAuthority
        _,grant=ProductionEffectAuthority.load_metadata(self,h['subject'],UUID(c['decisionId']),allow_inactive=True)
        if grant['grantDigest']!=c['grantDigest']:raise OwnershipError('Original production grant changed')
        if c['conflict'] is not None:
            binding=self.get(AgentWriteConflictBinding,UUID(c['conflict']['bindingId']))
            claims=list(self.scalars(select(AgentWriteConflictClaim).where(AgentWriteConflictClaim.binding_id==binding.id))) if binding else []
            if binding is None or conflict_digest(binding,claims)!=c['conflict']['immutableDigest']:
                raise OwnershipError('Original production conflict binding changed')

    def add(self,row):
        c=self._capsule;h=c['handle']
        if (type(row) is not AgentEffectReceipt or str(row.binding_id)!=h['id']
                or str(row.invocation_id)!=c['decisionId'] or row.provider_binding_digest!=c['providerBindingDigest']):
            raise OSErrorCode('PROFILE_DISABLED')
        super().add(row)

    def flush(self,objects=None):
        if objects is not None and (type(objects) is not list or any(type(row) is not AgentWriteConflictBinding for row in objects)):
            raise OSErrorCode('PROFILE_DISABLED')
        # Always verify every dirty row, even when the existing ledger requests
        # a subset flush. WorkAttempt/balance/deadline changes stay forbidden.
        super().flush()


class ProductionReceiptStore:
    """One authenticated capsule, only short transactions, no private artifacts."""
    session_type=ProductionReceiptSession
    def __init__(self,path,capsule,authenticate,*,readonly=False):
        self.path,self.capsule=path,deepcopy(capsule);self._authenticate=authenticate
        self._readonly=True if capsule['handle'].get('state')=='RESERVED' else readonly
        self._closed=False
        def connect():
            db=connect_owned(path,role='migrator');db.rollback();return db
        self._engine=create_engine('postgresql+psycopg://',poolclass=NullPool,creator=connect)

    @contextmanager
    def transaction(self):
        with file_lock(self.path.parent/'recovery-gate.lock',timeout=2,shared=True):
            if self._closed:raise OwnershipError('Production receipt store is closed')
            self._authenticate()
            with Session(self._engine,autoflush=False,expire_on_commit=False) as db:
                with db.begin():
                    if self._readonly:db.execute(text('SET TRANSACTION READ ONLY'))
                    db.execute(text("SET LOCAL lock_timeout='2s'"));db.execute(text("SET LOCAL statement_timeout='3s'"))
                    port=self.session_type(db,self.capsule,readonly=self._readonly)
                    port.verify_capsule();yield port
                    port.flush();port.verify_capsule();self._authenticate()

    def close(self):self._closed=True;self._engine.dispose()
