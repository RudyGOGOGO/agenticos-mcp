"""New-target authentication of the archive admitted by its installation operator."""
import hashlib
from pathlib import Path

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from .files import OwnershipError, private_read
from .ownership import load_manifest
from .resources import read_signed, write_signed
from . import recovery_gate as gate

PROFILE = 'held-restoration/1'
MANAGED_PROFILE = 'held-managed-restoration/1'
FIELDS = {'profile', 'installationId', 'runId', 'container', 'generation',
    'receiptDigest', 'receipt', 'materialDigests'}
MANAGED_FIELDS = FIELDS-{'container'}|{'managedTarget'}


def placement(path=None,*,manifest=None):
    """Physical identity without inventing Docker metadata for managed stores."""
    manifest=load_manifest(Path(path)) if manifest is None else manifest
    if manifest.get('profile')=='aws-eks/1':
        path=Path(manifest['root'])/'manifest.json' if path is None else Path(path)
        from agentic_os.adapters.aws.managed_restore import target_binding
        return dict(managedTarget=target_binding(path))
    if manifest.get('postgres') is None:raise OwnershipError('Owned restoration placement unavailable')
    return dict(container=manifest['postgres']['container'])


def placed_fields(fields,path,*,manifest=None):
    return set(fields)-{'container'}|set(placement(path,manifest=manifest))


def publish_restoration(path, receipt, generation, material,*,managed_target=None):
    manifest = load_manifest(path)
    if (manifest['profile']=='aws-eks/1')!=(managed_target is not None):
        raise OwnershipError('Explicit matching restoration placement required')
    value = dict(profile=MANAGED_PROFILE if managed_target is not None else PROFILE,
        installationId=manifest['installationId'], runId=manifest['runId'],
        **(dict(managedTarget=managed_target) if managed_target is not None else dict(container=manifest['postgres']['container'])),generation=generation,
        receiptDigest=hashlib.sha256(canonical_bytes(receipt)).hexdigest(), receipt=receipt,
        materialDigests={name: hashlib.sha256(content).hexdigest() for name, content in material.items()})
    write_signed(Path(path).parent/'recovery-snapshot.json', value, Path(path).parent/'owner.key')
    return load_restoration(path)


def load_restoration(path):
    path = Path(path)
    manifest = load_manifest(path)
    value = read_signed(path.parent/'recovery-snapshot.json', path.parent/'owner.key', maximum=2*1024**2)
    current = gate.state(path)
    managed=manifest['profile']=='aws-eks/1'
    if (type(value) is not dict or set(value) != (MANAGED_FIELDS if managed else FIELDS)
            or value['profile'] != (MANAGED_PROFILE if managed else PROFILE)
            or any(value[k] != manifest[k] for k in ('installationId', 'runId'))
            or not managed and value['container'] != manifest['postgres']['container']
            or type(value['generation']) is not int or value['generation'] != current['generation']
            or current['mode'] != 'BLOCKED' or type(value['receipt']) is not dict
            or value['receipt'].get('installationId') != manifest['installationId']
            or value['receiptDigest'] != hashlib.sha256(canonical_bytes(value['receipt'])).hexdigest()
            or type(value['materialDigests']) is not dict):
        raise OwnershipError('Held restoration binding unavailable')
    if managed:
        from agentic_os.adapters.aws.managed_restore import assert_restoration
        assert_restoration(path,value)
    return value


def relocation_metadata(path):
    from .recovery_metadata import FILE, checked_metadata
    value = load_restoration(path)
    raw = private_read(Path(path).parent/FILE, 128*1024)
    if value['materialDigests'].get(FILE) != hashlib.sha256(raw).hexdigest():
        raise OwnershipError('Restored relocation metadata changed')
    receipt = value['receipt']
    return checked_metadata(parse_canonical_json(raw), receipt['installationId'], receipt['sourceRunId'])
