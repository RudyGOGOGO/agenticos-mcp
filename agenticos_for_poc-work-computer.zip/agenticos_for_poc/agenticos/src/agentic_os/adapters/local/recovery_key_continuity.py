"""authenticated root-key continuity; no request-time key adoption."""
import hashlib
from pathlib import Path

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from .artifacts import checked_id,LocalKeys
from .files import OwnershipError, private_read
from .resources import read_signed

FILE = 'recovery-key-continuity.json'
INTENT = 'recovery-key-rotation.json'
DIRECTORY = 'recovery-key-operations'
PROFILE = 'restored-root-key-continuity/1'
ROTATION = 'restored-root-key-rotation/1'
MANAGED_PROFILE = 'restored-managed-root-key-continuity/1'
MANAGED_ROTATION = 'restored-managed-root-key-rotation/1'
SUPPORTED_PROFILES = ('restored-root-key-continuity/1','restored-root-key-rotation/1',
    'restored-managed-root-key-continuity/1','restored-managed-root-key-rotation/1',
    'restored-knowledge-key-continuity/1','restored-knowledge-key-rotation/1',
    'restored-managed-knowledge-key-continuity/1','restored-managed-knowledge-key-rotation/1')
BINDING = ('installationId', 'runId', 'container', 'archiveDigest', 'receiptDigest')
FIELDS = {'profile', *BINDING, 'baseGeneration', 'baseCertificateDigest', 'baseActive', 'entries'}
ENTRY_FIELDS = {'commandId', 'keyId', 'keyDigest', 'previousActive', 'previousDigest'}
INTENT_FIELDS = {'profile', *BINDING, 'generation', 'certificateDigest', 'state', *ENTRY_FIELDS}


def binding_fields(base):
    return set(BINDING)-{'container'}|{'managedTarget'} if base.get('profile')=='certified-restored-managed-runtime/1' else set(BINDING)


def placed_fields(fields,base):return set(fields)-set(BINDING)|binding_fields(base)


def plane(purpose):
    if purpose=='history':return FILE,INTENT,DIRECTORY,'keys'
    if purpose=='knowledge':return ('recovery-knowledge-key-continuity.json','recovery-knowledge-key-rotation.json',
        'recovery-knowledge-key-operations','protected-knowledge/keys')
    raise OwnershipError('Explicit restored key purpose required')


def profiles(base,purpose='history'):
    plane(purpose)
    if purpose=='knowledge':
        prefix='restored-managed' if 'managedTarget' in binding_fields(base) else 'restored'
        return prefix+'-knowledge-key-continuity/1',prefix+'-knowledge-key-rotation/1'
    return (MANAGED_PROFILE,MANAGED_ROTATION) if 'managedTarget' in binding_fields(base) else (PROFILE,ROTATION)


def sha(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def digest(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def _present(path):
    return path.exists() or path.is_symlink()


def _base(path, value):
    # Maintenance must provide authenticated bounded certificate ancestry.
    if value['generation'] == value['heldGeneration'] + 1:
        return value
    try:
        from .recovery_maintenance import original_release
    except ImportError:
        raise OwnershipError('Maintenance revalidation unavailable') from None
    return original_release(path, value)


def _binding(value, base):
    return all(value.get(k) == base[k] for k in binding_fields(base))


def _rotation(value, base, generation, certificate_digest, purpose='history'):
    if (type(value) is not dict or set(value) != placed_fields(INTENT_FIELDS,base)
            or value['profile'] != profiles(base,purpose)[1] or not _binding(value, base)
            or type(value['generation']) is not int or value['generation'] != generation
            or value['certificateDigest'] != certificate_digest
            or value['state'] not in {'PREPARED', 'COMPLETED'}
            or not digest(value['keyDigest']) or not digest(value['previousDigest'])):
        raise OwnershipError('Key rotation authority unavailable')
    for field in ('commandId', 'keyId', 'previousActive'):
        checked_id(value[field])
    return value


def original_keys(path,value,purpose='history'):
    plane(purpose)
    if purpose=='history':return dict(value['knownKeys'])
    from .recovery_ready import admitted_archive
    pins=admitted_archive(path)['materialDigests'];prefix='protected-knowledge/keys/'
    known={name[len(prefix):-4]:pin for name,pin in pins.items()
        if name.startswith(prefix) and name.endswith('.key') and '/' not in name[len(prefix):]}
    for ident,pin in known.items():
        checked_id(ident)
        if not digest(pin):raise OwnershipError('Original knowledge key pin unavailable')
    return known


def chain(path, value, purpose='history'):
    """Authenticate added pins only; retain the original six proofs unchanged."""
    path = Path(path); base = _base(path, value); root = path.parent
    file,_,_,_=plane(purpose);candidate = root / file
    known=original_keys(path,base,purpose)
    if not _present(candidate):
        return None, known
    result = read_signed(candidate, root / 'owner.key', maximum=32768)
    if (type(result) is not dict or set(result) != placed_fields(FIELDS,base) or result['profile'] != profiles(base,purpose)[0]
            or not _binding(result, base) or type(result['baseGeneration']) is not int
            or result['baseGeneration'] != base['generation']
            or result['baseCertificateDigest'] != sha(base)
            or type(result['entries']) is not list or not 1 <= len(result['entries']) <= 8):
        raise OwnershipError('Key continuity authority unavailable')
    checked_id(result['baseActive'])
    active = result['baseActive']; commands = set()
    if purpose=='knowledge':
        from .recovery_ready import admitted_archive
        pin=admitted_archive(path)['materialDigests'].get('protected-knowledge/keys/active.json')
        if sha(dict(id=active))!=pin:raise OwnershipError('Original knowledge selector differs')
    if active not in known:
        raise OwnershipError('Key continuity original selector differs')
    prior = None
    for index, entry in enumerate(result['entries']):
        if (type(entry) is not dict or set(entry) != ENTRY_FIELDS
                or not digest(entry['keyDigest']) or entry['previousDigest'] != sha(prior)
                or entry['previousActive'] != active):
            raise OwnershipError('Key continuity chain differs')
        checked_id(entry['keyId']); checked_id(entry['commandId'])
        if entry['keyId'] in known or entry['commandId'] in commands:
            raise OwnershipError('Key continuity repeats original authority')
        known[entry['keyId']] = entry['keyDigest']; active = entry['keyId']
        commands.add(entry['commandId'])
        prior = result | dict(entries=result['entries'][:index + 1])
    if len(known) > 128:
        raise OwnershipError('Key continuity envelope exceeded')
    return result, known


def pending(path, value, purpose='history'):
    _,intent,_,_=plane(purpose)
    root = Path(path).parent; candidate = root / intent
    if not _present(candidate):
        return None
    proof=read_signed(candidate, root / 'owner.key', maximum=32768)
    from .recovery_maintenance import release_ancestors
    ancestors=release_ancestors(path,value)
    if type(proof) is not dict or type(proof.get('generation')) is not int or proof['generation'] not in ancestors:
        raise OwnershipError('Key rotation release ancestry differs')
    if proof.get('state')=='PREPARED' and proof['generation']!=value['generation']:
        raise OwnershipError('Key rotation pending generation differs')
    return _rotation(proof,_base(path,value),proof['generation'],ancestors[proof['generation']],purpose)


def effective_keys(path, value, purpose='history'):
    """Internal metadata reader; caller must authenticate the current release."""
    continuity, known = chain(path, value,purpose); intent = pending(path, value,purpose)
    if intent is not None:
        if (intent['state'] != 'COMPLETED' or continuity is None
                or continuity['entries'][-1] != {k: intent[k] for k in ENTRY_FIELDS}):
            raise OwnershipError('Key rotation requires explicit completion')
    elif continuity is not None:
        raise OwnershipError('Key continuity completion is unavailable')
    root = Path(path).parent; directory = root / plane(purpose)[2]
    if _present(directory):
        # Every retained operation must be represented by its signed chain.
        expected = {e['commandId'] for e in continuity['entries']} if continuity else set()
        names = {p.name for p in directory.iterdir()}
        if names != expected:
            raise OwnershipError('Key operation inventory differs')
        for entry in continuity['entries'] if continuity else []:
            op = directory / entry['commandId']
            if {p.name for p in op.iterdir()} != {'intent.json', 'staged.key'}:
                raise OwnershipError('Key operation material inventory differs')
            proof = read_signed(op / 'intent.json', root / 'owner.key', maximum=32768)
            from .recovery_maintenance import release_ancestors
            ancestors=release_ancestors(path,value)
            base=_base(path,value)
            if (type(proof) is not dict or set(proof) != placed_fields(INTENT_FIELDS,base)
                    or proof['profile'] != profiles(base,purpose)[1] or not _binding(proof, base)
                    or proof['state'] != 'COMPLETED'
                    or {k: proof[k] for k in ENTRY_FIELDS} != entry
                    or type(proof['generation']) is not int or proof['generation'] not in ancestors
                    or proof['certificateDigest']!=ancestors[proof['generation']]):
                raise OwnershipError('Retained key operation authority differs')
    elif continuity is not None:
        raise OwnershipError('Retained key operations unavailable')
    return known


def selector(path, value, continuity=None, purpose='history'):
    """A rotation authenticates the new active selector as well as added pins."""
    if continuity is None:
        continuity, _ = chain(path, value,purpose)
    selected = parse_canonical_json(private_read(Path(path).parent / plane(purpose)[3] / 'active.json', 128))
    if (type(selected) is not dict or set(selected) != {'id'}
            or selected['id'] not in effective_keys(path, value,purpose)
            or continuity is not None and selected['id'] != continuity['entries'][-1]['keyId']):
        raise OwnershipError('Restored active key differs')
    if purpose=='knowledge' and continuity is None:
        from .recovery_ready import admitted_archive
        if sha(selected)!=admitted_archive(path)['materialDigests'].get('protected-knowledge/keys/active.json'):
            raise OwnershipError('Restored original knowledge selector differs')
    return selected['id']

class RestoredKnowledgeKeys(LocalKeys):
    """Fresh published purpose pins before key bytes; no adoption or repair."""
    def __init__(self,path):
        self.path=Path(path)
        super().__init__(self.path.parent/'protected-knowledge/keys')

    def _checked(self):
        from .recovery_ready import certificate
        from .recovery_key_continuity import effective_keys,selector
        from .recovery_history import pinned_keys
        value=certificate(self.path)
        known=effective_keys(self.path,value,'knowledge')
        selector(self.path,value,purpose='knowledge')
        return pinned_keys(self.directory,known)

    def active(self):
        from .resources import file_lock
        with file_lock(self.path.parent/'recovery-gate.lock',timeout=2,shared=True):return self._checked().active()

    def _key(self,ident):
        from .resources import file_lock
        with file_lock(self.path.parent/'recovery-gate.lock',timeout=2,shared=True):return self._checked()._key(ident)

    def rotate(self):
        raise OwnershipError('Restored knowledge keys require explicit authenticated key rotation')
