"""Fail-closed write boundary, checked before collection and again on connection."""
from pathlib import Path
import time
import psycopg

from .capacity_probe import CapacityProbeControl
from .files import OwnershipError
from .installer import PG_IMAGE
from .images import RDS_COMPATIBILITY_IMAGE
from .ownership import load_manifest, COMPONENTS, POC_PROFILE


def validate_target(path: Path, *, component: str = "control", role: str = "runtime") -> dict:
    if component not in COMPONENTS or role not in {"runtime", "migrator"}:
        raise OwnershipError("Unregistered component/role")
    manifest = load_manifest(path)
    if component not in manifest['databases']:
        raise OwnershipError('Component is absent from selected installation profile')
    if role == 'runtime':
        from .recovery_gate import assert_runtime
        assert_runtime(path)
    from .poc_image import selected
    image=selected(manifest) if manifest['profile']==POC_PROFILE else PG_IMAGE
    if manifest["postgres"] is None or manifest["postgres"]["image"] != image:
        raise OwnershipError("Target is not a qualified owned PostgreSQL profile")
    # Reuse the fixed Engine transport for the same fresh three-part ownership
    # proof. No CLI startup, cached metadata or capacity exec enters this path.
    CapacityProbeControl(manifest, deadline=time.monotonic()+60).inspect_owned(manifest)
    return manifest


def connect_owned(path: Path, *, component: str = "control", role: str = "runtime",
                  autocommit: bool = False):
    manifest = validate_target(path, component=component, role=role)
    database = manifest["databases"][component]
    connection = psycopg.connect(host="127.0.0.1", port=manifest["postgres"]["port"],
        user=database[role], password=database[role + "Password"], dbname=database["name"],
        connect_timeout=2, autocommit=autocommit)
    try:check_owned_connection(connection, database, role=role)
    except BaseException:
        connection.close();raise
    return connection


def check_owned_connection(connection, database, *, role):
    """Recheck the actual session identity and privileges, including pooled use."""
    user, name, version = connection.execute("SELECT current_user,current_database(),current_setting('server_version_num')").fetchone()
    if user != database[role] or name != database["name"] or version != "160015":
        raise OwnershipError("Connection does not match owned role/database/version")
    privileges = connection.execute("SELECT rolsuper,rolcreatedb,rolcreaterole,rolinherit,rolbypassrls FROM pg_roles WHERE rolname=current_user").fetchone()
    membership = connection.execute("SELECT count(*) FROM pg_auth_members WHERE member=(SELECT oid FROM pg_roles WHERE rolname=current_user)").fetchone()[0]
    if privileges != (False, False, False, False, False) or membership:
        raise OwnershipError("Component role has unqualified administrative privileges")
    if role == "runtime":
        permissions = connection.execute("SELECT has_schema_privilege(current_user,'public','CREATE'),has_database_privilege(current_user,current_database(),'CREATE'),has_database_privilege(current_user,current_database(),'TEMP')").fetchone()
        if permissions != (False, False, False):
            raise OwnershipError("Runtime role has unqualified schema/database privileges")
