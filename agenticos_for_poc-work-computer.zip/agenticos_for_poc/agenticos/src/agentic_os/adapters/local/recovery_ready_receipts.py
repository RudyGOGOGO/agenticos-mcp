"""Finite operator observation after Ready; no private runtime authority."""
import asyncio
import hashlib
from copy import deepcopy
from contextlib import asynccontextmanager
from pathlib import Path
from threading import Lock

from .files import OwnershipError,private_read,check_private
from .operator import verify_operator
from .recovery_ready import _release_metadata,admitted_archive
from agentic_os.contracts.canonical import parse_canonical_json
from agentic_os.errors import OSErrorCode

PROFILE='released-admitted-receipt-observation/1'
_capsule_lock=Lock()
_capsule_cache=None


async def _joined_thread(operation,*args,**kwargs):
    pending=asyncio.create_task(asyncio.to_thread(operation,*args,**kwargs))
    cancellation=None
    while not pending.done():
        try:await asyncio.shield(pending)
        except asyncio.CancelledError as exc:cancellation=exc
    return pending.result(),cancellation


@asynccontextmanager
async def _receipt_store(path,token,generation,attempt_id):
    from .certified_receipt_store import CertifiedReceiptStore
    # Signed archive and owned-target authentication perform blocking disk and
    # process operations. They must not stall unrelated finite native leases.
    store,cancellation=await _joined_thread(CertifiedReceiptStore,path,token,
        expected_generation=generation,attempt_id=attempt_id)
    try:
        if cancellation is not None:raise cancellation
        yield store
    finally:
        _,cancellation=await _joined_thread(store.close)
        if cancellation is not None:raise cancellation


def receipt_release(path,token,expected_generation):
    """Authenticate all original proofs without opening encryption planes.

    An expired execution certificate still proves a prior completed release.
    It cannot authorize new execution or decryption, but must not suppress a
    truthful original receipt. Each operation has its own20-second bound.
    Park, changed generation/code/proofs or unavailable operator evidence deny.
    """
    path=Path(path);verify_operator(path,token)
    if type(expected_generation) is not int:
        raise OwnershipError('Current receipt generation differs')
    value=_release_metadata(path)
    if value['generation']!=expected_generation:
        raise OwnershipError('Current receipt generation differs')
    return value


def _load_ready_capsules(path,token,expected_generation):
    path=Path(path);release=receipt_release(path,token,expected_generation)
    admitted=admitted_archive(path)
    from .recovery_receipts import FILE,checked_capsules,match_pending
    try:raw=private_read(path.parent/FILE,256*1024)
    except OSError:raise OwnershipError('Original receipt capsules unavailable') from None
    if admitted['materialDigests'].get(FILE)!=hashlib.sha256(raw).hexdigest():
        raise OwnershipError('Original receipt capsules changed')
    value=checked_capsules(parse_canonical_json(raw))
    if value['installationId']!=admitted['installationId'] or release['receiptDigest']!=admitted['receiptDigest']:
        raise OwnershipError('Current receipt archive differs')
    match_pending(value,admitted['receipt']['runtimeCheckpoint']['pendingEffects'])
    # Reauthenticate the signed generation and original proof inventory after
    # archive/capsule reads. This is metadata only, never an owner/worker grant.
    if receipt_release(path,token,expected_generation)!=release or admitted_archive(path)!=admitted:
        raise OwnershipError('Current receipt release changed')
    return dict(release=release,archive=admitted),value


def _receipt_inventory(path):
    from .recovery_ready import _proof_inventory
    from .recovery_receipts import FILE
    # This purpose never opens private encryption planes. Include every signed
    # release/maintenance resource plus operator and original capsule identity.
    rows=_proof_inventory(path,include_keys=False)
    extra=[]
    for name in ('operator-state.json',FILE):
        resource=path.parent/name
        try:
            check_private(resource.parent,directory=True);info=resource.lstat()
        except OSError:raise OwnershipError('Original receipt resources unavailable') from None
        import stat
        if not stat.S_ISREG(info.st_mode):raise OwnershipError('Original receipt resource differs')
        from agentic_os.distribution import read_regular, DistributionError
        try:content_digest=hashlib.sha256(read_regular(resource,256*1024)).hexdigest()
        except DistributionError:
            raise OwnershipError('Original receipt resource changed') from None
        extra.append((str(resource),info.st_dev,info.st_ino,info.st_uid,info.st_mode,
            info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns,content_digest))
    return rows+tuple(extra)


def load_ready_capsules(path,token,expected_generation):
    """Reuse validated metadata only while every current proof file agrees.

    A single bounded entry contains opaque admitted metadata, no key bytes or
    execution grant. Every use freshly authenticates operator and signed gate,
    checks current code and before/after file identities and actual contents.
    Any changed proof, capsule, target, key or maintenance name forces complete
    validation. SQL capsule/accounting and commit fences remain independent.
    """
    from . import recovery_gate as gate
    from .recovery_ready import release_digest
    from agentic_os.identity.context import timestamp,utcnow
    global _capsule_cache
    path=Path(path);verify_operator(path,token)
    if type(expected_generation) is not int:raise OwnershipError('Current receipt generation differs')
    current=gate.state(path);before=_receipt_inventory(path);cached=_capsule_cache
    if cached is None or cached[:3]!=(path,before,expected_generation):
        with _capsule_lock:
            cached=_capsule_cache
            if cached is None or cached[:3]!=(path,before,expected_generation):
                admitted,capsules=_load_ready_capsules(path,token,expected_generation)
                if _receipt_inventory(path)!=before:raise OwnershipError('Current receipt release changed')
                cached=(path,before,expected_generation,admitted,capsules)
                _capsule_cache=cached
    admitted,capsules=cached[3:];release=admitted['release']
    if (current['mode']!='READY' or current['generation']!=expected_generation
            or release['generation']!=expected_generation
            or release['releaseDigest']!=release_digest()
            or timestamp(release['issuedAt'])>utcnow()):
        raise OwnershipError('Current receipt release unavailable')
    verify_operator(path,token)
    if gate.state(path)!=current or _receipt_inventory(path)!=before:
        raise OwnershipError('Current receipt release changed')
    return deepcopy(admitted),deepcopy(capsules)


async def observe_ready_receipt(path,token,*,expected_generation,attempt_id):
    from . import production_recovery_receipts as production
    path=Path(path)
    try:
        async with asyncio.timeout(20):
            if (path.parent/production.FILE).exists() or (path.parent/production.FILE).is_symlink():
                loaded,cancelled=await _joined_thread(production.load_ready_capsules,path,token,expected_generation)
                if cancelled is not None:raise cancelled
                _,value=loaded
                if any(row['handle']['id']==attempt_id for row in value['effects']):
                    return await production.observe_ready_receipt(path,token,expected_generation=expected_generation,attempt_id=attempt_id)
            return await _observe(path,token,expected_generation,attempt_id)
    except TimeoutError:raise OSErrorCode('UNAVAILABLE') from None


async def _observe(path,token,generation,attempt_id):
    from .recovery_receipts import _ObserverRegistry
    from agentic_os.effects.input_execution_ledger import InputReviewedEffectLedger
    from agentic_os.effects.input_execution_observer import InputReviewedReceiptObserver
    from agentic_os.effects.input_receipt_authority import InputReceiptRecoveryAuthority
    from agentic_os.effects.input_receipt_presentation import InputReceiptPresentation
    from agentic_os.effects.registry import ResourceRegistry
    from agentic_os.effects.reviewed_provider import ReviewedProviderRegistry
    path=Path(path)
    async with _receipt_store(path,token,generation,attempt_id) as store:
        selected=store.capsule
        registry=_ObserverRegistry(path,store,selected)
        providers=ReviewedProviderRegistry(ResourceRegistry(registry))
        authority=InputReceiptRecoveryAuthority(store)
        observer=InputReviewedReceiptObserver(InputReviewedEffectLedger(authority),providers)
        projection,observation,segment=await InputReceiptPresentation(observer).observe(
            selected['handle'],provider_pins=dict(bindingDigest=selected['providerBindingDigest'],
                endpointDigest=selected['endpointDigest']))
        await asyncio.to_thread(store.authenticate)
        return dict(profile=PROFILE,state='OBSERVED',attemptId=attempt_id,status=observation['status'],
            projectionId=projection['id'],segmentId=segment,unknownUsageHeld=True,executionAuthorized=False)
