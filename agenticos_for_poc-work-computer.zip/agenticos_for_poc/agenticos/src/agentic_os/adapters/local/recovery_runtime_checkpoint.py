"""Public compatibility pins and opaque already admitted effect IDs."""
import hashlib
import ast
import json
import re
from importlib.resources import files

from agentic_os.contracts.canonical import canonical_bytes
from .files import OwnershipError
from .recovery_operator import connect_owned

MAX_ROWS = 4096
FIELDS = {'contracts', 'workflowPrograms', 'registrations', 'admittedDefinitions', 'pendingEffects'}
PRODUCTION_PROFILE='agent-coordinated-checkpoint/1'


def migration_pin(head):
    if type(head) is not str or re.fullmatch(r'os_pg_[0-9]{4}',head) is None:
        raise OwnershipError('Recovery control revision unavailable')
    path=files('agentic_os').joinpath('migrations/versions/'+head+'.py')
    if not path.is_file():raise OwnershipError('Recovery control revision is not packaged')
    return hashlib.sha256(path.read_bytes()).hexdigest()


def production_checkpoint(db,head):
    from agentic_os.adapters.postgres.migrate import migration_head
    from agentic_os.identity.context import iso
    if head!=migration_head():raise OwnershipError('Explicit current production control revision required')
    roots=db.execute("SELECT id,application_id,root_task_id,state,version,deadline FROM os_budget_roots "
        "WHERE accounting_format='agent-resources/1' ORDER BY id LIMIT 4097").fetchall()
    pending=db.execute("SELECT id,application_id,task_id,root_id,invocation_id,request_digest,kind,state,lease_until "
        "FROM os_work_attempts WHERE accounting_format='agent-resources/1' "
        "AND state IN ('RESERVED','RUNNING','UNKNOWN') ORDER BY id LIMIT 4097").fetchall()
    workloads=db.execute("SELECT w.root_id,w.application_id,w.task_id,w.parent_task_id FROM os_workload_bindings w "
        "JOIN os_budget_roots r ON r.installation_id=w.installation_id AND r.id=w.root_id "
        "WHERE r.accounting_format='agent-resources/1' ORDER BY w.root_id,w.task_id LIMIT 4097").fetchall()
    if any(len(rows)>MAX_ROWS for rows in (roots,pending,workloads)):
        raise OwnershipError('Production recovery checkpoint envelope exceeded')
    # Full row/balance/result fingerprints already belong to the component
    # watermarks. This adds only typed opaque identity/original deadline pins.
    return dict(profile=PRODUCTION_PROFILE,controlHead=head,controlMigrationSHA256=migration_pin(head),
        roots=[dict(rootId=str(i),applicationId=str(a),taskId=str(t),state=s,version=v,deadline=iso(d)) for i,a,t,s,v,d in roots],
        workloads=[dict(rootId=str(r),applicationId=str(a),taskId=str(t),parentTaskId=str(p) if p else None) for r,a,t,p in workloads],
        pendingWork=[dict(attemptId=str(i),applicationId=str(a),taskId=str(t),rootId=str(r),invocationId=str(v),
            requestDigest=d,kind=k,state=s,leaseUntil=iso(expiry)) for i,a,t,r,v,d,k,s,expiry in pending])


def release_programs(package=None):
    package = files('agentic_os') if package is None else package
    definitions = json.loads(package.joinpath('contracts/schema/contracts.json').read_text())['$defs']
    contracts = {name: hashlib.sha256(canonical_bytes(value)).hexdigest()
        for name, value in sorted(definitions.items())}
    programs = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(package.joinpath('adapters/temporal').iterdir(), key=lambda p: p.name)
        if p.name.endswith('.py') and p.name != '__init__.py'}
    def workflow_sources(directory, parts=()):
        for path in sorted(directory.iterdir(), key=lambda p: p.name):
            if path.is_dir():
                yield from workflow_sources(path, parts+(path.name,))
            elif path.name.endswith('.py'):
                raw = path.read_bytes()
                if b'@workflow.defn' not in raw: continue
                for node in ast.walk(ast.parse(raw)):
                    if not isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)): continue
                    for decorator in node.decorator_list:
                        call = decorator.func if isinstance(decorator, ast.Call) else decorator
                        if (isinstance(call, ast.Attribute) and call.attr == 'defn'
                                and isinstance(call.value, ast.Name) and call.value.id == 'workflow'):
                            yield '__'.join(parts+(path.name,)), raw
                            break
                    else: continue
                    break
    for name, raw in workflow_sources(package):
        if name in programs: raise OwnershipError('Workflow compatibility pin collision')
        programs[name] = hashlib.sha256(raw).hexdigest()
    return dict(contracts=contracts, workflowPrograms=programs)


def runtime_checkpoint(path, *, installation=None):
    if installation is not None:
        from pathlib import Path
        from agentic_os.adapters.installation import InstallationPorts
        if type(installation) is not InstallationPorts or Path(path)!=installation.root/'manifest.json':
            raise OwnershipError('Recovery checkpoint installation differs')
    value = release_programs()
    connection = connect_owned(path, role='migrator') if installation is None else installation.connect()
    with connection as db:
        db.rollback(); db.execute('SET TRANSACTION READ ONLY')
        db.execute("SET LOCAL lock_timeout='2s'")
        db.execute("SET LOCAL statement_timeout='3s'")
        head=db.execute('SELECT version_num FROM alembic_version').fetchone()
        if head is None:raise OwnershipError('Recovery control revision unavailable')
        registrations = db.execute('SELECT r.application_id,r.revision,r.generation,r.digest '
            'FROM os_registrations r JOIN os_applications a ON a.installation_id=r.installation_id '
            'AND a.id=r.application_id AND a.active ORDER BY r.application_id,r.revision LIMIT 4097').fetchall()
        definitions = db.execute('SELECT id,application_id,task_id,registration_revision, '
            "encode(sha256(convert_to(bot::text,'UTF8')),'hex') FROM os_admissions ORDER BY id LIMIT 4097").fetchall()
        pending = db.execute("SELECT id,application_id,task_id,root_id,invocation_id,request_digest,state "
            "FROM os_work_attempts WHERE kind IN ('effect','repair') "
            "AND state IN ('RESERVED','RUNNING','UNKNOWN') ORDER BY id LIMIT 4097").fetchall()
        if head[0]!='os_pg_0056':value['production']=production_checkpoint(db,head[0])
    if any(len(rows) > MAX_ROWS for rows in (registrations, definitions, pending)):
        raise OwnershipError('Runtime checkpoint envelope exceeded')
    value['registrations'] = [dict(applicationId=str(a), revision=r, generation=g, digest=d)
        for a, r, g, d in registrations]
    value['admittedDefinitions'] = [dict(admissionId=str(i), applicationId=str(a), taskId=str(t),
        registrationRevision=r, definitionDigest=d) for i, a, t, r, d in definitions]
    value['pendingEffects'] = [dict(attemptId=str(i), applicationId=str(a), taskId=str(t), rootId=str(r),
        invocationId=str(v), requestDigest=d, state=s) for i, a, t, r, v, d, s in pending]
    checked_runtime_checkpoint(value)
    return value


def _digest(value):
    return type(value) is str and re.fullmatch('[a-f0-9]{64}', value) is not None


def checked_runtime_checkpoint(value):
    from .artifacts import checked_id
    if type(value) is not dict or set(value) not in (FIELDS,FIELDS|{'production'}):
        raise OwnershipError('Runtime checkpoint unavailable')
    if 'production' in value:checked_production_checkpoint(value['production'])
    for group in ('contracts', 'workflowPrograms'):
        members = value[group]
        if type(members) is not dict or not members or len(members) > 1024:
            raise OwnershipError('Runtime compatibility pins unavailable')
        for name, pin in members.items():
            if (type(name) is not str or len(name) > 128 or not _digest(pin)
                    or re.fullmatch('[A-Za-z][A-Za-z0-9_]*(\\.py)?', name) is None):
                raise OwnershipError('Runtime compatibility pin unavailable')
    specs = {
        'registrations': ({'applicationId'}, {'revision', 'generation'}, {'digest'}, set()),
        'admittedDefinitions': ({'admissionId', 'applicationId', 'taskId'}, {'registrationRevision'},
            {'definitionDigest'}, set()),
        'pendingEffects': ({'attemptId', 'applicationId', 'taskId', 'rootId', 'invocationId'}, set(),
            {'requestDigest'}, {'state'}),
    }
    for group, (ids, integers, digests, states) in specs.items():
        records = value[group]
        if type(records) is not list or len(records) > MAX_ROWS:
            raise OwnershipError('Runtime checkpoint envelope unavailable')
        identities = set()
        for row in records:
            if type(row) is not dict or set(row) != ids | integers | digests | states:
                raise OwnershipError('Runtime checkpoint record unavailable')
            for key in ids: checked_id(row[key])
            if any(type(row[k]) is not int or not 1 <= row[k] <= 2**53-1 for k in integers):
                raise OwnershipError('Runtime checkpoint version unavailable')
            if any(not _digest(row[k]) for k in digests):
                raise OwnershipError('Runtime checkpoint digest unavailable')
            if states and (type(row['state']) is not str or row['state'] not in {'RESERVED', 'RUNNING', 'UNKNOWN'}):
                raise OwnershipError('Runtime checkpoint effect state unavailable')
            identity = (row['applicationId'], row['revision']) if group == 'registrations' else row[
                'admissionId' if group == 'admittedDefinitions' else 'attemptId']
            if identity in identities:
                raise OwnershipError('Duplicate runtime checkpoint')
            identities.add(identity)


def checked_production_checkpoint(value):
    from .artifacts import checked_id
    from agentic_os.identity.context import timestamp,iso
    from agentic_os.production.resources import KINDS
    from agentic_os.adapters.postgres.migrate import migration_head
    if (type(value) is not dict or set(value)!={'profile','controlHead','controlMigrationSHA256','roots','workloads','pendingWork'}
            or value['profile']!=PRODUCTION_PROFILE or value['controlHead']!=migration_head()
            or value['controlMigrationSHA256']!=migration_pin(value['controlHead'])):
        raise OwnershipError('Production recovery control pin unavailable')
    def rows(key,fields):
        values=value[key]
        if type(values) is not list or len(values)>MAX_ROWS:raise OwnershipError('Production recovery checkpoint envelope unavailable')
        for row in values:
            if type(row) is not dict or set(row)!=fields:raise OwnershipError('Production recovery checkpoint record unavailable')
        return values
    roots={};last='';tasks=set()
    for row in rows('roots',{'rootId','applicationId','taskId','state','version','deadline'}):
        for field in ('rootId','applicationId','taskId'):checked_id(row[field])
        if (row['rootId']<=last or type(row['state']) is not str or row['state'] not in {'ACTIVE','QUARANTINED','CLOSED'}
                or type(row['version']) is not int or not 1<=row['version']<=2**53-1
                or row['taskId'] in tasks or iso(timestamp(row['deadline']))!=row['deadline']):
            raise OwnershipError('Production recovery root identity unavailable')
        roots[row['rootId']]=(row['applicationId'],row['taskId']);tasks.add(row['taskId']);last=row['rootId']
    workloads={};last=None
    for row in rows('workloads',{'rootId','applicationId','taskId','parentTaskId'}):
        for field in ('rootId','applicationId','taskId'):checked_id(row[field])
        if row['parentTaskId'] is not None:checked_id(row['parentTaskId'])
        key=(row['rootId'],row['taskId']);root=roots.get(row['rootId'])
        if (root is None or root[0]!=row['applicationId'] or last is not None and key<=last
                or (row['parentTaskId'] is None)!=(row['taskId']==root[1])):
            raise OwnershipError('Production recovery workload binding unavailable')
        workloads[key]=row['parentTaskId'];last=key
    for root_id,(_,task_id) in roots.items():
        if (root_id,task_id) not in workloads:raise OwnershipError('Production recovery root binding absent')
    for key,parent in workloads.items():
        seen={key[1]}
        while parent is not None:
            if parent in seen or (key[0],parent) not in workloads:
                raise OwnershipError('Production recovery child ancestry unavailable')
            seen.add(parent);parent=workloads[(key[0],parent)]
    last=''
    for row in rows('pendingWork',{'attemptId','applicationId','taskId','rootId','invocationId',
            'requestDigest','kind','state','leaseUntil'}):
        for field in ('attemptId','applicationId','taskId','rootId','invocationId'):checked_id(row[field])
        if (row['attemptId']<=last or (row['rootId'],row['taskId']) not in workloads
                or roots[row['rootId']][0]!=row['applicationId']
                or not _digest(row['requestDigest']) or row['kind'] not in KINDS
                or type(row['state']) is not str or row['state'] not in {'RESERVED','RUNNING','UNKNOWN'}
                or iso(timestamp(row['leaseUntil']))!=row['leaseUntil']):
            raise OwnershipError('Production recovery pending identity unavailable')
        last=row['attemptId']


def checkpoint_head(value):
    checked_runtime_checkpoint(value)
    return value['production']['controlHead'] if 'production' in value else 'os_pg_0056'


def assert_release_compatible(value):
    checked_runtime_checkpoint(value)
    current = release_programs()
    for group in ('contracts', 'workflowPrograms'):
        if any(current[group].get(name) != pin for name, pin in value[group].items()):
            raise OwnershipError('Restored history requires its original compatible programs')
