"""Explicit installation-time digest verification; no runtime/ignored reference imports."""
import hashlib
from importlib.resources import files
import io
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import tarfile
import time
import urllib.request

from .files import OwnershipError, private_directory, private_read, private_write, check_private
from .ownership import load_manifest
from .build_cache import BuildCache, cache_root
from .resources import ensure_private

DRIVER = r'''package main
import (
 "context"
 "encoding/json"
 "os"
 "io"
 "time"
 "github.com/MiniMax-AI/OpenAgentCore/services/core/migrations"
)
func main() {
 var input struct {DSN string `json:"dsn"`}
 if json.NewDecoder(io.LimitReader(os.Stdin,65536)).Decode(&input)!=nil {os.Exit(2)}
 ctx,cancel:=context.WithTimeout(context.Background(),90*time.Second);defer cancel()
 if migrations.Apply(ctx,input.DSN)!=nil {os.Stderr.WriteString("Core migration failed\n");os.Exit(1)}
 os.Stdout.WriteString("Core migration complete\n")
}
'''


def download(entry: dict, destination: Path, maximum=100_000_000) -> bytes:
    if destination.exists():
        content = private_read(destination, maximum)
    else:
        with urllib.request.urlopen(entry['url'], timeout=60) as response:
            content = response.read(maximum + 1)
        if len(content) > maximum or hashlib.sha256(content).hexdigest() != entry['sha256']:
            raise OwnershipError('Installation archive digest/size mismatch')
        private_write(destination, content)
    if hashlib.sha256(content).hexdigest() != entry['sha256']:
        raise OwnershipError('Cached archive digest mismatch')
    return content


def extract(content: bytes, destination: Path):
    private_directory(destination)
    with tarfile.open(fileobj=io.BytesIO(content), mode='r:gz') as archive:
        entries = archive.getmembers()
        if len(entries) > 100000 or sum(member.size for member in entries) > 500_000_000:
            raise OwnershipError('Archive exceeds installation envelope')
        for member in entries:
            path = Path(member.name)
            if path.is_absolute() or '..' in path.parts or member.islnk() or member.issym() or not (member.isdir() or member.isfile()):
                raise OwnershipError('Unqualified archive path/type')
        archive.extractall(destination, filter='data')
    # The archive is verified data, but upstream mode bits are not our local
    # privacy policy. Build input copies are private and independently writable.
    for directory, children, names in os.walk(destination):
        for name in children + names:
            path = Path(directory) / name
            path.chmod(0o700 if path.is_dir() or path.stat().st_mode & 0o100 else 0o600)


def install_core_migrator(manifest_path: Path) -> dict:
    manifest = load_manifest(manifest_path)
    root = Path(manifest['root'])
    if (platform.system(), platform.machine()) != ('Darwin', 'arm64'):
        raise OwnershipError('Go installer placement unqualified; local Darwin arm64 profile only')
    lock = json.loads(files('agentic_os').joinpath('deploy/source-lock.json').read_text())
    dependency = root / 'dependencies'
    if not dependency.exists():
        private_directory(dependency)
    check_private(dependency, directory=True)
    marker = dependency / 'core-migrator.json'
    if marker.exists():
        result = json.loads(private_read(marker))
        executable = dependency / 'core-migrator'
        if (result.get('source') != lock['openagentcore']['sha256']
                or hashlib.sha256(private_read(executable, 100_000_000)).hexdigest() != result.get('binary')):
            raise OwnershipError('Core migrator provenance changed')
        return result
    specification = {"version": 1, "kind": "core-migrator", "source": lock['openagentcore'],
        "toolchain": lock['go-darwin-arm64'], "os": platform.system(), "arch": platform.machine(),
        "flags": ['-mod=readonly', '-trimpath', 'CGO_ENABLED=0', 'GOTOOLCHAIN=local'],
        "driver": hashlib.sha256(DRIVER.encode()).hexdigest()}
    cache = BuildCache(cache_root(root))
    with cache.acquire(specification, lambda payload, scratch: _build(lock, payload, scratch)) as cached:
        executable = cached['path'] / 'core-migrator'
        binary = private_read(executable, 100_000_000)
        private_write(dependency / 'core-migrator', binary, replace=True)
        (dependency / 'core-migrator').chmod(0o700)
        result = {'source': lock['openagentcore']['sha256'], 'commit': lock['openagentcore']['commit'],
                  'binary': hashlib.sha256(binary).hexdigest(), 'go': lock['go-darwin-arm64']['version'],
                  'cacheKey': cached['key'], 'cacheHit': cached['hit']}
    # The shared input is checked again on lease exit. A failed exit must never
    # leave a reusable provenance marker over a partially accepted private copy.
    private_write(marker, json.dumps(result, sort_keys=True).encode())
    return result


def _command(command, *, env, cwd, timeout):
    process = subprocess.Popen(command, env=env, cwd=cwd, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True, umask=0o077)
    try:
        stdout, stderr = process.communicate(timeout=timeout)
        if process.returncode or len(stdout) + len(stderr) > 2_000_000:
            raise OwnershipError('Pinned Core build command failed')
        return stdout
    except BaseException:
        _signal_group(process.pid, signal.SIGTERM)
        if process.poll() is None:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
        # Descendants may ignore TERM or outlive the leader. The owned process
        # group remains the teardown identity after its parent has exited.
        _signal_group(process.pid, signal.SIGKILL)
        if process.poll() is None:
            process.wait(timeout=5)
        deadline = time.monotonic() + 5
        while _live_group(process.pid):
            if time.monotonic() >= deadline:
                raise OwnershipError('Build child teardown could not be observed') from None
            time.sleep(.05)
        raise


def _live_group(group):
    result = subprocess.run(['ps', '-axo', 'pid=,pgid=,uid=,stat='],
                            capture_output=True, text=True, timeout=5)
    if result.returncode:
        raise OwnershipError('Build process inventory unavailable')
    for line in result.stdout.splitlines():
        fields = line.split()
        if len(fields) != 4:
            raise OwnershipError('Build process inventory invalid')
        if int(fields[1]) == group and not fields[3].startswith('Z'):
            if int(fields[2]) != os.getuid():
                raise OwnershipError('Build process group has foreign ownership')
            return True
    return False


def _signal_group(group, signal_number):
    try:
        os.killpg(group, signal_number)
    except ProcessLookupError:
        pass
    except PermissionError:
        # Darwin can report EPERM for a group that has just lost its last live
        # member. Only an independent process inventory can qualify that case.
        if _live_group(group):
            raise OwnershipError('Build child teardown refused') from None


def _build(lock, payload, scratch):
    for name, entry in [('source', lock['openagentcore']), ('go', lock['go-darwin-arm64'])]:
        content = download(entry, payload / (name + '.tgz'))
        extract(content, scratch / (name + '-unpacked'))
    source = scratch / 'source-unpacked' / ('OpenAgentCore-' + lock['openagentcore']['commit'])
    license_text = (source / 'LICENSE').read_text()
    if 'Permission is hereby granted' not in license_text or 'MiniMax-AI' not in license_text:
        raise OwnershipError('Unexpected upstream license')
    private_write(payload / 'LICENSE', license_text.encode())
    ensure_private(source / 'cmd')
    driver = source / 'cmd/os-migrate'
    ensure_private(driver)
    private_write(driver / 'main.go', DRIVER.encode())
    ensure_private(scratch / 'home')
    go = scratch / 'go-unpacked/go/bin/go'
    env = {'PATH': os.environ.get('PATH', '/usr/bin:/bin'), 'HOME': str(scratch / 'home'),
           'GOTOOLCHAIN': 'local', 'GOWORK': 'off', 'GOCACHE': str(scratch / 'go-cache'),
           'GOMODCACHE': str(scratch / 'go-modules'), 'GOPROXY': 'https://proxy.golang.org',
           'GOSUMDB': 'sum.golang.org', 'CGO_ENABLED': '0'}
    version = _command([str(go), 'version'], env=env, cwd=source, timeout=10)
    if lock['go-darwin-arm64']['version'] not in version.decode():
        raise OwnershipError('Go toolchain pin mismatch')
    _command([str(go), 'build', '-mod=readonly', '-trimpath', '-o',
              str(payload / 'core-migrator'), './cmd/os-migrate'], env=env, cwd=source, timeout=300)
    (payload / 'core-migrator').chmod(0o700)
