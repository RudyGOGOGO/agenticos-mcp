"""Raw old-run quarantine on a held copy, without a private converter.

An exact termination can append its truthful event, never rewrite a history
prefix, settle usage, change a deadline or authorize a new private workflow.
Ambiguous RPC acknowledgement leaves a signed pending operation for inspection.
"""
import asyncio
from datetime import timedelta
import hashlib
from pathlib import Path

from psycopg import sql
from temporalio.api.common.v1 import WorkflowExecution
from temporalio.api.workflowservice.v1 import (GetWorkflowExecutionHistoryRequest,
    TerminateWorkflowExecutionRequest)

from agentic_os.contracts.canonical import canonical_bytes
from .files import OwnershipError
from .operator import verify_operator
from .resources import file_lock, read_signed, write_signed
from .restoration_binding import load_restoration,placement,placed_fields
from .ownership import load_manifest
from .recovery_operator import connect_owned
from .temporal import inspect_service
from .recovery_lineage import load_lineage, service_digest
from .recovery_temporal import (_shape, _checked_record, _admitted_workflows,
    _raw_client, _inspect_history)

FILE = 'recovery-quarantine.json'
PROFILE = 'held-workflow-quarantine/1'
PRODUCTION_PROFILE='held-production-workflow-quarantine/1'
FIELDS = {'profile', 'installationId', 'runId', 'container', 'generation',
    'receiptDigest', 'serviceDigest', 'original', 'inspectionDigest',
    'originalCatalog', 'controlPins', 'state', 'catalog'}
PIN_TABLES = ('os_work_attempts', 'os_budget_roots', 'os_tasks', 'os_segments',
    'os_public_events', 'personal_learning_jobs', 'os_proactive_definitions')


def sha(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def pin_tables(*,production=False):
    if not production:return PIN_TABLES
    from agentic_os.adapters.postgres.models import Base
    return tuple(sorted(set(PIN_TABLES)|{'os_workload_bindings','os_admissions','os_dispatches',
        'os_task_controls','os_artifacts','os_source_inputs'}|
        {name for name in Base.metadata.tables if name.startswith('os_agent_')}))


def control_pins(path,*,production=False):
    """Opaque row fingerprints only; no private payload or accounting writes."""
    result = {}
    with connect_owned(path, role='migrator') as db:
        db.rollback(); db.execute('SET TRANSACTION READ ONLY')
        db.execute("SET LOCAL lock_timeout='2s'"); db.execute("SET LOCAL statement_timeout='3s'")
        for name in pin_tables(production=production):
            query = sql.SQL("SELECT count(*),encode(sha256(convert_to(COALESCE(jsonb_agg(b ORDER BY b::text),'[]'::jsonb)::text,'UTF8')),'hex') "
                'FROM (SELECT to_jsonb(t) b FROM public.{} t LIMIT 4097) selected').format(sql.Identifier(name))
            count, digest = db.execute(query).fetchone()
            if count > 4096:
                raise OwnershipError('Quarantine control envelope exceeded')
            result[name] = dict(rows=count, sha256=digest)
    return result


def held_inspection(path, token, generation, *, connection=None):
    verify_operator(path, token); admitted = load_restoration(path); manifest = load_manifest(path)
    if type(generation) is not int or admitted['generation'] != generation:
        raise OwnershipError('Quarantine held generation differs')
    from .coordinated_backup import CLOUD_PROFILE,MANAGED_PROFILE
    if admitted['receipt']['profile'] in {CLOUD_PROFILE,MANAGED_PROFILE} and connection is None:
        raise OwnershipError('Explicit original Cloud recovery connection required')
    if connection is None:binding, _ = inspect_service(path)
    else:
        from agentic_os.adapters.aws.temporal import recovery_binding
        from .restoration_binding import relocation_metadata
        binding=recovery_binding(connection,relocation_metadata(path)['temporal'])
        if connection.installation.root!=path.parent:raise OwnershipError('Cloud quarantine target differs')
    original = load_lineage(path, binding)['original']
    shape = _shape(manifest, admitted, original, binding.get('networkSubnets'))
    shape['requiredWorkflows'] = _admitted_workflows(path, manifest)
    inspected = _checked_record(path, shape)
    if inspected['state'] != 'INSPECTED' or inspected['serviceDigest'] != service_digest(binding):
        raise OwnershipError('Quarantine requires the original inspected service')
    return manifest, admitted, binding, inspected


def shape(manifest, admitted, binding, inspected):
    profile=PRODUCTION_PROFILE if 'production' in admitted['receipt']['runtimeCheckpoint'] else PROFILE
    return dict(profile=profile, installationId=manifest['installationId'], runId=manifest['runId'],
        **placement(manifest=manifest), generation=admitted['generation'],
        receiptDigest=admitted['receiptDigest'], serviceDigest=service_digest(binding),
        original=inspected['original'], inspectionDigest=sha(inspected), originalCatalog=inspected['catalog'])


def checked_record(path, expected):
    value = read_signed(path.parent/FILE, path.parent/'owner.key', maximum=2*1024**2)
    if (type(value) is not dict or set(value) != placed_fields(FIELDS,path)
            or any(value[k] != v or type(value[k]) is not type(v) for k,v in expected.items())
            or value['state'] not in {'PENDING','QUARANTINED'}
            or type(value['controlPins']) is not dict
            or set(value['controlPins']) != set(pin_tables(production=expected['profile']==PRODUCTION_PROFILE))
            or type(value['catalog']) is not list or len(value['catalog']) > 128):
        raise OwnershipError('Original quarantine operation differs')
    return value


async def prefix_digest(client, original, row):
    """Rehash the admitted prefix from raw protobuf bytes, never decoded input."""
    count = size = 0; token = b''; tokens = set(); digest = hashlib.sha256()
    while count < row['events']:
        response = await client.workflow_service.get_workflow_execution_history(GetWorkflowExecutionHistoryRequest(
            namespace=original['namespace'], execution=WorkflowExecution(workflow_id=row['workflowId'],run_id=row['runId']),
            maximum_page_size=64, next_page_token=token), timeout=timedelta(seconds=3))
        for event in response.history.events:
            if count >= row['events']:
                break
            count += 1; raw = event.SerializeToString(deterministic=True); size += len(raw)
            if event.event_id != count or size > 16*1024**2:
                raise OwnershipError('Original quarantine history prefix differs')
            digest.update(len(raw).to_bytes(8,'big')+raw)
        token = response.next_page_token
        if count == row['events']:
            break
        if not token or token in tokens or not response.history.events:
            raise OwnershipError('Original quarantine history prefix is incomplete')
        tokens.add(token)
    if count != row['events'] or digest.hexdigest() != row['historyDigest']:
        raise OwnershipError('Original quarantine history prefix differs')


def compatible_catalog(before, after):
    original = {(v['workflowId'],v['runId']):v for v in before}
    current = {(v['workflowId'],v['runId']):v for v in after}
    if len(current) != len(after) or original.keys() != current.keys():
        raise OwnershipError('Quarantine workflow catalog differs')
    for key, prior in original.items():
        actual = current[key]
        if (any(actual[k] != prior[k] for k in ('firstRunId','workflowType','taskQueue','executionTimeoutSeconds'))
                or actual['events'] < prior['events'] or actual['status'] == 1
                or prior['status'] != 1 and actual != prior):
            raise OwnershipError('Quarantine changed original workflow identity or closed history')


async def quarantine(path, token, *, expected_generation,connection=None):
    path = Path(path)
    transport={} if connection is None else dict(connection=connection)
    with file_lock(path.parent/'recovery-gate.lock', timeout=2):
        manifest, admitted, binding, inspected = held_inspection(path,token,expected_generation,**transport)
        expected = shape(manifest,admitted,binding,inspected)
        production=expected['profile']==PRODUCTION_PROFILE
        marker = path.parent/FILE
        if marker.exists() or marker.is_symlink():
            record = checked_record(path,expected)
        else:
            record = expected|dict(controlPins=control_pins(path,production=production),state='PENDING',catalog=[])
            write_signed(marker,record,path.parent/'owner.key')
        if control_pins(path,production=production) != record['controlPins']:
            raise OwnershipError('Original quarantine control state changed')
    # No SQL session or local gate lock spans a frontend RPC. Runtime stays
    # BLOCKED; each fixed terminate request identifies its exact original run.
    try:
        async with asyncio.timeout(20):
            client = await _raw_client(binding,record['original'],**transport)
            before = await _inspect_history(path,binding,record['original'],**transport)
            keys = {(v['workflowId'],v['runId']) for v in record['originalCatalog']}
            if {(v['workflowId'],v['runId']) for v in before} != keys:
                raise OwnershipError('Original quarantine catalog changed')
            for row in record['originalCatalog']:
                await prefix_digest(client,record['original'],row)
            for row in before:
                if row['status'] == 1:
                    # Do not retry this mutation after an ambiguous response.
                    # A subsequent operator call first inspects the exact run.
                    await client.workflow_service.terminate_workflow_execution(TerminateWorkflowExecutionRequest(
                        namespace=record['original']['namespace'],workflow_execution=WorkflowExecution(
                            workflow_id=row['workflowId'],run_id=row['runId']),
                        first_execution_run_id=row['firstRunId'],reason='recovery-quarantine',
                        identity='agentic-os-recovery'),timeout=timedelta(seconds=3))
            after = await _inspect_history(path,binding,record['original'],**transport)
            compatible_catalog(record['originalCatalog'],after)
            for row in record['originalCatalog']:
                await prefix_digest(client,record['original'],row)
    except TimeoutError:
        raise OwnershipError('Original quarantine exceeded its bounded deadline') from None
    with file_lock(path.parent/'recovery-gate.lock', timeout=2):
        _, current_admitted, current_binding, current_inspected = held_inspection(path,token,expected_generation,**transport)
        if (current_admitted != admitted or shape(manifest,current_admitted,current_binding,current_inspected) != expected
                or checked_record(path,expected) != record or control_pins(path,production=production) != record['controlPins']):
            raise OwnershipError('Held quarantine changed before publication')
        record['state'] = 'QUARANTINED'; record['catalog'] = after
        write_signed(marker,record,path.parent/'owner.key')
    return dict(profile=PROFILE,state='QUARANTINED',workflowRuns=len(after),
        originalHistoryPreserved=True,unknownUsageHeld=True,runtimeReady=False)
