"""Pinned trusted storage probe image, available before dependency bootstrap."""

PG_IMAGE = "pgvector/pgvector:0.8.7-pg16-bookworm@sha256:7b822b0aac60967beb1ea5e576b8602c94c300a157d187f385ae3e0da199b90a"

# Local SQL qualification only; never the ordinary local profile or an AWS image.
# Provenance/recipe is packaged under deploy/profiles/rds-compatibility-image.json.
RDS_COMPATIBILITY_IMAGE='sha256:8215edec862ad32ac1b66d6b50a1819e99c0de83d000e603c579d37c26a97ae7'
