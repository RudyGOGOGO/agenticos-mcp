"""Explicit relocation of authenticated knowledge material on a blocked copy.

The signed pending operation retains its fresh credential before SQL. An
ambiguous commit can only retry that exact credential and attest the role;
it never adopts a preexisting role or opens an ordinary runtime connection.
"""
from pathlib import Path
from io import StringIO
import re
import secrets
import psycopg

from .artifacts import LocalKeys, checked_id
from .files import OwnershipError, private_read
from .resources import canonical_path, read_signed, tree_inventory, write_signed
from .restoration_binding import relocation_metadata,placement,placed_fields
from .recovery_operator import held_operator

PROFILE = 'restored-knowledge-purposes/1'
MANAGED_PROFILE = 'restored-managed-knowledge-purposes/1'
FILE = 'recovery-knowledge.json'
FIELDS = {'profile', 'installationId', 'runId', 'container', 'generation',
    'receiptDigest', 'keyBinding', 'publicCredential', 'state'}


def key_binding(path, manifest):
    if manifest['profile']=='aws-eks/1':
        from agentic_os.adapters.aws.bootstrap import _knowledge_binding
        return _knowledge_binding(Path(path),manifest)
    return dict(profile='OSProtectedKnowledgeKeys/1', installationId=manifest['installationId'],
        runId=manifest['runId'], container=manifest['postgres']['container'],
        root=str(canonical_path(Path(path).parent/'protected-knowledge')), purpose='planner.read/1')


def assert_key_material(path, admitted):
    root = Path(path).parent/'protected-knowledge'
    expected = {name.removeprefix('protected-knowledge/'): pin
        for name, pin in admitted['materialDigests'].items() if name.startswith('protected-knowledge/')}
    inventory = tree_inventory(root, maximum=128*1024**2)['files']
    actual = {name: value['sha256'] for name, value in inventory.items() if 'sha256' in value}
    if not expected or actual != expected:
        raise OwnershipError('Restored knowledge material differs from the admitted snapshot')
    keys = LocalKeys(root/'keys')
    keys._key(keys.active())
    for name in actual:
        if name == 'publication.lock':
            if private_read(root/name, 1) != b'':
                raise OwnershipError('Restored knowledge lock differs')
        elif name == 'keys/active.json':
            continue
        elif name.startswith('keys/') and name.endswith('.key') and '/' not in name[5:]:
            keys._key(checked_id(name[5:-4]))
        else:
            raise OwnershipError('Unregistered knowledge material')


def _record_shape(path, manifest, admitted):
    return dict(profile=MANAGED_PROFILE if manifest['profile']=='aws-eks/1' else PROFILE, installationId=manifest['installationId'], runId=manifest['runId'],
        **placement(path,manifest=manifest), generation=admitted['generation'],
        receiptDigest=admitted['receiptDigest'], keyBinding=key_binding(path, manifest))


def _checked_record(path, manifest, admitted, metadata):
    from agentic_os.knowledge.access import expected
    record = read_signed(Path(path).parent/FILE, Path(path).parent/'owner.key', maximum=32768)
    shape = _record_shape(path, manifest, admitted)
    if (type(record) is not dict or set(record) != placed_fields(FIELDS,path,manifest=manifest)
            or any(record[k] != v for k, v in shape.items())
            or record['state'] not in {'PENDING', 'VERIFIED'}):
        raise OwnershipError('Restored knowledge operation differs')
    credential = record['publicCredential']
    if manifest['profile']=='aws-eks/1':
        if credential!=_managed_public(path,metadata):raise OwnershipError('Restored managed public purpose differs')
    elif metadata['publicKnowledge']:
        shape = expected(manifest)
        if (type(credential) is not dict or set(credential) != set(shape)|{'password'}
                or any(credential[k] != v for k, v in shape.items())
                or type(credential['password']) is not str
                or re.fullmatch('[a-f0-9]{48}', credential['password']) is None):
            raise OwnershipError('Restored public credential differs')
    elif credential is not None:
        raise OwnershipError('Unselected restored public purpose')
    return record


def _bootstrap(manifest):
    definition = manifest['databases']['knowledge']
    db = psycopg.connect(host='127.0.0.1', port=manifest['postgres']['port'], dbname=definition['name'],
        user='aos_bootstrap', password=manifest['bootstrapPassword'], connect_timeout=2)
    try:
        db.execute("SET LOCAL lock_timeout='2s'")
        db.execute("SET LOCAL statement_timeout='3s'")
        if db.execute("SELECT current_user,current_database(),current_setting('server_version_num')").fetchone() != (
                'aos_bootstrap', definition['name'], '160015'):
            raise OwnershipError('Restored bootstrap target differs')
        return db
    except BaseException:
        db.close()
        raise


def relocate_knowledge(path, token, *, expected_generation):
    path = Path(path)
    from .recovery_operator import migrate
    from agentic_os.knowledge.access import expected, _create_public_role, _connect_public_attested
    with held_operator(path, token, expected_generation=expected_generation) as (manifest, admitted):
        metadata = relocation_metadata(path)
        if manifest['profile']=='aws-eks/1':return _relocate_managed(path,manifest,admitted,metadata)
        if not metadata['knowledgeKeys']:
            raise OwnershipError('Snapshot did not authenticate a knowledge purpose')
        assert_key_material(path, admitted)
        migrate(path, component='knowledge', check_only=True, diagnostic_stream=StringIO())
        marker = path.parent/FILE
        if marker.exists() or marker.is_symlink():
            record = _checked_record(path, manifest, admitted, metadata)
        else:
            # Reject unknown target bindings and global roles before recording
            # any operation. A pg_dump database archive does not own roles.
            for name in ('knowledge-key-binding.json', 'knowledge-public-credential.json'):
                if (path.parent/name).exists() or (path.parent/name).is_symlink():
                    raise OwnershipError('Untracked knowledge purpose cannot be adopted')
            credential = None
            if metadata['publicKnowledge']:
                credential = expected(manifest)
                with _bootstrap(manifest) as db:
                    if db.execute('SELECT 1 FROM pg_roles WHERE rolname=%s', (credential['role'],)).fetchone():
                        raise OwnershipError('Untracked public role cannot be adopted')
                credential['password'] = secrets.token_hex(24)
            record = dict(_record_shape(path, manifest, admitted), publicCredential=credential, state='PENDING')
            write_signed(marker, record, path.parent/'owner.key')
        for name, value in (('knowledge-key-binding.json', record['keyBinding']),
                ('knowledge-public-credential.json', record['publicCredential'])):
            destination = path.parent/name
            if destination.exists() or destination.is_symlink():
                if value is None or read_signed(destination, path.parent/'owner.key') != value:
                    raise OwnershipError('Tracked knowledge purpose changed')
        credential = record['publicCredential']
        if credential is not None:
            with _bootstrap(manifest) as db:
                exists = db.execute('SELECT 1 FROM pg_roles WHERE rolname=%s', (credential['role'],)).fetchone()
                if not exists:
                    if record['state'] == 'VERIFIED':
                        raise OwnershipError('Verified restored public role disappeared')
                    _create_public_role(db, credential)
            # This authenticates only the metadata credential while the gate
            # remains blocked. No planner, worker or generic runtime is issued.
            connection = _connect_public_attested(manifest, credential)
            connection.close()
        assert_key_material(path, admitted)
        for name, value in (('knowledge-key-binding.json', record['keyBinding']),
                ('knowledge-public-credential.json', credential)):
            if value is not None:
                write_signed(path.parent/name, value, path.parent/'owner.key')
        record['state'] = 'VERIFIED'
        write_signed(marker, record, path.parent/'owner.key')
        return dict(profile=PROFILE, state='VERIFIED', knowledgeKeys=True,
            publicKnowledge=credential is not None, enabledLanes=[])


def _managed_public(path,metadata):
    if not metadata['publicKnowledge']:return None
    from agentic_os.adapters.aws.managed_restore import _record
    settings=_record(Path(path))['configuration']['stores']['installation']['aws']['stores']['knowledge_public']
    return dict(provider='aws-secrets-manager',pin=settings['password'],database=settings['database'],user=settings['user'])


def _relocate_managed(path,manifest,admitted,metadata):
    from .recovery_operator import migrate,installation
    if not metadata['knowledgeKeys']:raise OwnershipError('Original managed knowledge purpose required')
    assert_key_material(path,admitted);migrate(path,component='knowledge',check_only=True)
    marker=path.parent/FILE
    if marker.exists() or marker.is_symlink():record=_checked_record(path,manifest,admitted,metadata)
    else:
        if any((path.parent/name).exists() or (path.parent/name).is_symlink() for name in ('knowledge-key-binding.json','knowledge-public-credential.json')):
            raise OwnershipError('Untracked managed knowledge purpose cannot be adopted')
        record=dict(_record_shape(path,manifest,admitted),publicCredential=_managed_public(path,metadata),state='PENDING')
        write_signed(marker,record,path.parent/'owner.key')
    binding=path.parent/'knowledge-key-binding.json'
    if (binding.exists() or binding.is_symlink()) and read_signed(binding,path.parent/'owner.key')!=record['keyBinding']:
        raise OwnershipError('Tracked managed knowledge binding differs')
    if record['publicCredential'] is not None:
        # The target already has its separately provisioned immutable public
        # role. Reauthenticate that exact scoped read port; never mint a role.
        with installation(path).require_components(path).knowledge_public() as db:
            db.rollback();db.execute('SET TRANSACTION READ ONLY')
            db.execute("SET LOCAL lock_timeout='2s'");db.execute("SET LOCAL statement_timeout='3s'")
            if db.execute('SELECT 1').fetchone()!=(1,):raise OwnershipError('Managed public knowledge port unavailable')
    assert_key_material(path,admitted)
    write_signed(binding,record['keyBinding'],path.parent/'owner.key')
    record['state']='VERIFIED';write_signed(marker,record,path.parent/'owner.key')
    return dict(profile=MANAGED_PROFILE,state='VERIFIED',knowledgeKeys=True,publicKnowledge=record['publicCredential'] is not None,enabledLanes=[])
