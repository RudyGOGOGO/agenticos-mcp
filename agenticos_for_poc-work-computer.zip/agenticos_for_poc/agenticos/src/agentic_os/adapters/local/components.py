"""Original component migrators. No parallel OS schema for Temporal/Core."""
from importlib.resources import files
import json
from pathlib import Path
import subprocess
from urllib.parse import quote

from psycopg import sql
from .docker import DockerControl
from .files import OwnershipError, private_read, private_write
from .target import connect_owned, validate_target
from .dependencies import install_core_migrator
from agentic_os.adapters.postgres.migrate import migrate, metadata_permissions


def temporal_schema(path: Path, component: str):
    if component not in {'temporal', 'visibility'}:
        raise OwnershipError('Unknown Temporal component')
    manifest = validate_target(path, component=component, role='migrator')
    root = Path(manifest['root']); database = manifest['databases'][component]
    docker = DockerControl(manifest)
    profile = json.loads(files('agentic_os').joinpath('deploy/profiles/local-synthetic.json').read_text())
    image = profile['components']['TEMPORAL_TOOLS_IMAGE']['reference']
    try:
        docker.command('image', 'inspect', image)
    except OwnershipError:
        docker.command('pull', image, timeout=300)
    with connect_owned(path, component=component, role='migrator', autocommit=True) as db:
        db.execute('SELECT pg_advisory_lock(78109432)')
        db.execute(sql.SQL('ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE,SELECT ON SEQUENCES TO {}').format(
            sql.Identifier(database['runtime'])))
        exists = db.execute("SELECT to_regclass('public.schema_version')").fetchone()[0] is not None
        operations = [] if exists else [('setup', ['setup-schema', '-v', '0.0'])]
        folder = 'temporal' if component == 'temporal' else 'visibility'
        operations.append(('update', ['update-schema','-d','/etc/temporal/schema/postgresql/v12/'+folder+'/versioned']))
        for name, operation in operations:
            output = docker.command('run','--rm','-i','--network','container:'+manifest['postgres']['container'],
                '--cap-drop','ALL','--memory','512m','--pids-limit','64','--security-opt','no-new-privileges:true',
                '--label','io.agentic-os.installation='+manifest['installationId'],
                '--entrypoint','sh',image,'-c','read -r SQL_PASSWORD; export SQL_PASSWORD; exec temporal-sql-tool "$@"',
                '--','--plugin','postgres12','--ep','127.0.0.1','--port','5432',
                '--user',database['migrator'],'--db',database['name'],*operation,
                input=database['migratorPassword']+'\n', timeout=90)
            private_write(root / (component+'-'+name+'.log'), output.encode(), replace=True)
        version = db.execute('SELECT curr_version FROM schema_version').fetchone()[0]
        if not version or version == '0.0':
            raise OwnershipError('Temporal component schema incomplete')
    metadata_permissions(path, component)
    return version


def core_schema(path: Path):
    manifest = validate_target(path, component='core', role='migrator')
    evidence = install_core_migrator(path)
    root = Path(manifest['root']); database = manifest['databases']['core']
    executable = root / 'dependencies/core-migrator'
    # Verification is repeated before execution; native/model jobs never receive this binary/DSN.
    import hashlib
    if hashlib.sha256(private_read(executable,100_000_000)).hexdigest() != evidence['binary']:
        raise OwnershipError('Core migrator binary changed')
    dsn = 'postgresql://'+quote(database['migrator'],safe='')+':'+quote(database['migratorPassword'],safe='')
    dsn += '@127.0.0.1:'+str(manifest['postgres']['port'])+'/'+database['name']+'?sslmode=disable'
    result = subprocess.run([str(executable)], input=json.dumps({'dsn':dsn}).encode(),
        cwd=root, env={'HOME':str(root/'home'),'GOTOOLCHAIN':'local'}, capture_output=True, timeout=110)
    private_write(root / 'core-migration.log', result.stdout + result.stderr, replace=True)
    if result.returncode:
        raise OwnershipError('Original Core migration failed; private evidence retained')
    with connect_owned(path, component='core') as db:
        version = db.execute('SELECT max(version_id) FROM agents_api_schema_version WHERE is_applied').fetchone()[0]
    if not version:
        raise OwnershipError('Core component schema incomplete')
    metadata_permissions(path, 'core')
    return version


def migrate_components(path: Path, *, control_revision='head') -> dict:
    # Explicit initial revision also supports rehearsing the retained G01
    # foundation snapshot profile on a fresh target. No downgrade is performed.
    migrate(path,revision=control_revision)
    for component in ['retrieval','knowledge']:
        migrate(path, component=component)
    result = {component:temporal_schema(path,component) for component in ['temporal','visibility']}
    result['core'] = core_schema(path)
    return result
