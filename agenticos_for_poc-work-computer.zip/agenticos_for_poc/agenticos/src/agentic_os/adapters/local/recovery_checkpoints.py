"""Bounded independent privacy checkpoints held through component copies."""
from contextlib import contextmanager, ExitStack
from pathlib import Path

from agentic_os.memory.recovery_journal import ForgetRecoveryJournal
from agentic_os.memory.controls_journal import ControlsRecoveryJournal
from agentic_os.errors import OSErrorCode
from .files import OwnershipError, check_private
from .resources import canonical_path, file_lock, tree_inventory
from .recovery_operator import connect_owned

MAX_PROFILES = 128


def _assert_current_owners(path, deletion, controls, *, control_connect=None):
    """An original source must already reflect the surviving owner floors.

    This reads only scoped consent/watermark metadata under the held journal
    locks. It cannot initialize an absent owner or publish a restored read lane.
    """
    applications = sorted(deletion)
    if not applications:
        return
    connection=connect_owned(path,role='migrator') if control_connect is None else control_connect()
    with connection as db:
        db.execute("SET LOCAL lock_timeout='2s'")
        db.execute("SET LOCAL statement_timeout='3s'")
        rows = db.execute('SELECT s.id,s.installation_id,s.application_id,s.tenant_id,s.subject_id,'
            's.version,s.learning_epoch,s.recall_epoch,s.choice,o.journal_id,o.sequence,o.owner_epoch '
            'FROM personal_learning_settings s LEFT JOIN memory_recovery_owners o ON o.settings_id=s.id '
            'WHERE s.application_id=ANY(%s::uuid[]) ORDER BY s.id LIMIT 16385', (applications,)).fetchall()
        if len(rows) > MAX_PROFILES*128:
            raise OwnershipError('Owner checkpoint envelope exceeded')
        owner_counts = {}
        for _, installation, app, tenant, subject_id, revision, learning, recall, choice, jid, seq, epoch in rows:
            app = str(app)
            owner_counts[app] = owner_counts.get(app, 0)+1
            if owner_counts[app] > 128:
                raise OwnershipError('Owner checkpoint envelope exceeded')
            subject = dict(installationId=str(installation), applicationId=app, tenantId=tenant, subjectId=subject_id)
            journal, state = deletion[app]
            owner = state['owners'].get(journal.owner_mac(subject), journal.empty_owner())
            if ((str(jid),seq,epoch) if jid else (journal.journal_id,0,1)) != (
                    journal.journal_id,owner['sequence'],owner['ownerEpoch']):
                raise OwnershipError('Original deletion watermark is behind surviving intent')
            if learning <= owner['beforeLearningEpoch']:
                raise OwnershipError('Original learning epoch is behind surviving deletion')
            if app in controls:
                control, control_state = controls[app]
                confirmed = control_state['owners'].get(control.owner_mac(subject))
                current = dict(revision=revision, learningEpoch=learning, recallEpoch=recall, choice=choice)
                if confirmed is None or not control._compatible(current, confirmed['current']):
                    raise OwnershipError('Original consent is behind surviving controls')


def _external_root(path, value):
    if value is None:
        raise OwnershipError('Selected privacy checkpoint placement required')
    root = canonical_path(Path(value))
    installation = canonical_path(Path(path).parent)
    if root == installation or root.is_relative_to(installation):
        raise OwnershipError('Privacy journals must survive the snapshot rollback domain')
    tree_inventory(root, maximum=32*1024**2)
    return root


def profile_pins(path, *, control_connect=None):
    """Close metadata SQL before taking short local journal locks."""
    connection=connect_owned(path,role='migrator') if control_connect is None else control_connect()
    with connection as db:
        db.execute("SET LOCAL lock_timeout='2s'")
        db.execute("SET LOCAL statement_timeout='3s'")
        deletion = []
        controls = []
        if db.execute("SELECT to_regclass('public.memory_recovery_profiles')").fetchone()[0] is not None:
            deletion = db.execute('SELECT installation_id,application_id,journal_id,key_digest '
                'FROM memory_recovery_profiles ORDER BY application_id LIMIT 129').fetchall()
        if db.execute("SELECT to_regclass('public.memory_controls_recovery_profiles')").fetchone()[0] is not None:
            controls = db.execute('SELECT installation_id,application_id,journal_id,key_digest,deletion_journal_id '
                'FROM memory_controls_recovery_profiles ORDER BY application_id LIMIT 129').fetchall()
    if len(deletion) > MAX_PROFILES or len(controls) > MAX_PROFILES:
        raise OwnershipError('Privacy checkpoint envelope exceeded')
    deletion = [dict(installationId=str(i), applicationId=str(a), journalId=str(j), keyDigest=k)
        for i, a, j, k in deletion]
    controls = [dict(installationId=str(i), applicationId=str(a), journalId=str(j), keyDigest=k,
        deletionJournalId=str(d)) for i, a, j, k, d in controls]
    deleting = {p['applicationId']: p for p in deletion}
    if any(p['applicationId'] not in deleting
            or p['deletionJournalId'] != deleting[p['applicationId']]['journalId']
            or p['installationId'] != deleting[p['applicationId']]['installationId']
            or p['journalId'] == p['deletionJournalId']
            or p['keyDigest'] == deleting[p['applicationId']]['keyDigest'] for p in controls):
        raise OwnershipError('Independent privacy profile lineage differs')
    return deletion, controls


def _record(pin, state):
    return {k: pin[k] for k in ('applicationId', 'journalId', 'keyDigest')} | dict(sequence=state['sequence'])


@contextmanager
def snapshot_checkpoints(path, journal_root, controls_root=None, *, require_current=False,control_connect=None):
    """Consent -> deletion -> component SQL; no provider awaits or private content.

    Shared journal locks keep original surviving watermarks stable through the
    snapshot. They cannot acknowledge a command or make a held installation ready.
    """
    def current_pins():return profile_pins(path) if control_connect is None else profile_pins(path,control_connect=control_connect)
    pins=current_pins()
    deletion_root = _external_root(path, journal_root) if pins[0] else None
    consent_root = _external_root(path, controls_root if controls_root is not None
        else deletion_root/'controls') if pins[1] else None
    if consent_root is not None and consent_root == deletion_root:
        raise OwnershipError('Independent consent and deletion placement required')
    try:
        with ExitStack() as locks:
            consent, deletion = [], []
            consenting, deleting = {}, {}
            for pin in pins[1]:
                journal = ControlsRecoveryJournal(consent_root/pin['applicationId']/pin['journalId'],
                    pin['installationId'], pin['applicationId'], pin['journalId'],
                    expected_key_digest=pin['keyDigest'])
                locks.enter_context(journal._lock(shared=True))
                state = journal._checked_load()
                if any(r['state'] == 'PENDING' for o in state['owners'].values() for r in o['commands'].values()):
                    raise OwnershipError('Unapplied consent intent blocks snapshot')
                consent.append(_record(pin, state))
                consenting[pin['applicationId']] = (journal, state)
            for pin in pins[0]:
                directory = deletion_root/pin['applicationId']/pin['journalId']
                check_private(directory/'journal.lock')
                journal = ForgetRecoveryJournal(directory, pin['installationId'], pin['applicationId'],
                    pin['journalId'], expected_key_digest=pin['keyDigest'])
                locks.enter_context(file_lock(directory/'journal.lock', timeout=.1, shared=True))
                state = journal._checked_load()
                if any(r['state'] == 'PENDING' for o in state['owners'].values() for r in o['commands'].values()):
                    raise OwnershipError('Unapplied deletion intent blocks snapshot')
                deletion.append(_record(pin, state))
                deleting[pin['applicationId']] = (journal, state)
            if require_current:
                if control_connect is None:_assert_current_owners(path,deleting,consenting)
                else:_assert_current_owners(path,deleting,consenting,control_connect=control_connect)
            yield dict(journalCheckpoints=deletion, controlsCheckpoints=consent)
            for journal, prior in [*consenting.values(), *deleting.values()]:
                if journal._checked_load() != prior:
                    raise OwnershipError('Independent privacy material changed during snapshot')
            if current_pins() != pins:
                raise OwnershipError('Privacy profile lineage changed during snapshot')
    except OSErrorCode:
        raise OwnershipError('Independent privacy checkpoints unavailable') from None


def checked_records(records):
    """Canonical, bounded public opaque pins; never owner MAC or private values."""
    import re
    from .artifacts import checked_id
    if type(records) is not list or len(records) > MAX_PROFILES:
        raise OwnershipError('Privacy checkpoint unavailable')
    applications, journals = set(), set()
    for value in records:
        if (type(value) is not dict or set(value) != {'applicationId', 'journalId', 'keyDigest', 'sequence'}
                or type(value['keyDigest']) is not str or re.fullmatch('[a-f0-9]{64}', value['keyDigest']) is None
                or type(value['sequence']) is not int or not 0 <= value['sequence'] <= 2**53-1):
            raise OwnershipError('Privacy checkpoint unavailable')
        checked_id(value['applicationId']); checked_id(value['journalId'])
        if value['applicationId'] in applications or value['journalId'] in journals:
            raise OwnershipError('Duplicate privacy checkpoint')
        applications.add(value['applicationId']); journals.add(value['journalId'])
    if [p['applicationId'] for p in records] != sorted(applications):
        raise OwnershipError('Privacy checkpoint order differs')
