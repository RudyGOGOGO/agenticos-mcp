"""Operator-only service relocation and opaque history inspection while held.

No client, payload, worker, registration, start, signal or cancellation interface
escapes this scope. Restored history retains its original namespace and queues;
the new service has independently authenticated configuration and credentials.
"""
import asyncio
from datetime import timedelta
import hashlib
import time
from pathlib import Path

from temporalio.api.common.v1 import WorkflowExecution
from temporalio.api.workflowservice.v1 import (DescribeNamespaceRequest, DescribeWorkflowExecutionRequest,
    GetWorkflowExecutionHistoryRequest, ListWorkflowExecutionsRequest)
from temporalio.client import Client
from temporalio.service import RPCError

from .artifacts import checked_id
from .files import OwnershipError
from .resources import read_signed, write_signed
from .recovery_operator import held_operator
from .restoration_binding import relocation_metadata,placement,placed_fields
from .temporal import _provision_owned, _start_owned, inspect_service
from .temporal_networks import checked_subnets
from .recovery_lineage import namespace_id,publish_lineage,service_digest
from .recovery_metadata import checked_temporal

PROFILE = 'restored-temporal-inspection/3'
CLOUD_PROFILE = 'restored-cloud-temporal-inspection/1'
FILE = 'recovery-temporal.json'
FIELDS = {'profile', 'installationId', 'runId', 'container', 'generation', 'receiptDigest',
    'original', 'networkSubnets', 'initialStoresVerified', 'schemaRelocations', 'requiredWorkflows', 'serviceDigest', 'catalog', 'state'}
QUEUES = {'OSAdmissionTransport/1': 'os-admission-', 'OSTaskDriver/1': 'os-kernel-',
    'OSTaskMemoryDriver/1': 'os-memory-task-', 'OSNativeTaskDriver/1': 'os-native-task-',
    'OSTrustedTaskDriver/1': 'os-trusted-', 'OSTrustedTaskDriver/2': 'os-input-trusted-',
    'OSTrustedDelegatedTaskDriver/1': 'os-input-delegated-',
    'OSPersonalLearning/1': 'os-learning-', 'OSPersonalLearning/2': 'os-learning-',
    'OSPersonalLearning/3': 'os-learning-', 'OSPersonalLearning/4': 'os-learning-',
    'ScheduleDriverWorkflow/1': 'os-proactive-', 'ProactiveTaskWorkflow/1': 'os-proactive-',
    'OSAgentTaskDriver/1': None}


def original_queue(workflow,ident,logical_run,observed):
    if workflow=='OSAgentTaskDriver/1':
        parts=ident.split(':')
        if len(parts)!=4 or parts[0]!='os-agent':raise OwnershipError('Original Agent workflow identity differs')
        for part in parts[1:]:checked_id(part)
        if observed not in {ident+'/objective/1',ident+'/execution/1'}:
            raise OwnershipError('Original Agent workflow queue differs')
        return observed
    if ident.startswith('os-agent:') or workflow not in QUEUES:
        raise OwnershipError('Original workflow family differs')
    queue=QUEUES[workflow]+logical_run
    if workflow=='OSPersonalLearning/4':queue+='-classified-4'
    if observed!=queue:raise OwnershipError('Original workflow profile or queue differs')
    return queue


def production_workflow(checkpoint,ident):
    from .recovery_runtime_checkpoint import checked_runtime_checkpoint
    checked_runtime_checkpoint(checkpoint)
    parts=ident.split(':')
    if (len(parts)!=4 or parts[0]!='os-agent' or 'production' not in checkpoint
            or not any(row['applicationId']==parts[2] and row['taskId']==parts[3]
                for row in checkpoint['production']['workloads'])):
        raise OwnershipError('Original Agent workflow lacks its admitted production workload')


def _shape(manifest, admitted, original, network_subnets, *, legacy=False):
    from .recovery_metadata import CLOUD_TEMPORAL_PROFILE,SELF_HOSTED_TEMPORAL_PROFILE,checked_cloud_temporal
    if original.get('profile') in {CLOUD_TEMPORAL_PROFILE,SELF_HOSTED_TEMPORAL_PROFILE}:
        from .coordinated_backup import CLOUD_PROFILE as ARCHIVE_PROFILE,MANAGED_PROFILE,CLOUD_COMPONENTS,selected_components
        checked_cloud_temporal(original,manifest['installationId'])
        if (legacy or network_subnets is not None or admitted['receipt']['profile'] not in {ARCHIVE_PROFILE,MANAGED_PROFILE}
                or set(admitted['receipt']['components'])!=set(selected_components(admitted['receipt']['profile']))):
            raise OwnershipError('Cloud recovery cannot relocate local workflow databases')
        return dict(profile=CLOUD_PROFILE,installationId=manifest['installationId'],runId=manifest['runId'],
            **placement(manifest=manifest),generation=admitted['generation'],
            receiptDigest=admitted['receiptDigest'],original=original,networkSubnets=None,
            initialStoresVerified=True,schemaRelocations={})
    relocations = {}
    for component, version, minimum in (('temporal', '1.19', '1.0'), ('visibility', '1.14', '0.1')):
        rows = admitted['receipt']['components'][component]['after']['schemaVersions'].get('schema_version')
        if (type(rows) is not list or len(rows) != 1 or type(rows[0]) is not list or len(rows[0]) != 5
                or rows[0][0] != '0' or rows[0][1] != 'aos_'+admitted['receipt']['sourceRunId']+'_'+component
                or rows[0][3:] != [version, minimum]):
            raise OwnershipError('Original Temporal schema identity differs')
        after = list(rows[0]); after[1] = manifest['databases'][component]['name']
        relocations[component] = dict(before=rows[0], after=after)
    return dict(profile='restored-temporal-inspection/2' if legacy else PROFILE,
        installationId=manifest['installationId'], runId=manifest['runId'],
        container=manifest['postgres']['container'], generation=admitted['generation'],
        receiptDigest=admitted['receiptDigest'], original=original,
        networkSubnets=checked_subnets(network_subnets), initialStoresVerified=True, schemaRelocations=relocations)


def _admitted_workflows(path, manifest, *, installation=None):
    from .recovery_operator import connect_owned
    if installation is not None:
        from agentic_os.adapters.installation import InstallationPorts
        if (type(installation) is not InstallationPorts or Path(path)!=installation.root/'manifest.json'
                or str(installation.installation_id)!=manifest['installationId']):
            raise OwnershipError('Recovery history installation differs')
    connection = connect_owned(path, role='migrator') if installation is None else installation.connect()
    with connection as db:
        db.rollback(); db.execute('SET TRANSACTION READ ONLY')
        db.execute("SET LOCAL lock_timeout='2s'")
        db.execute("SET LOCAL statement_timeout='3s'")
        rows = db.execute("SELECT workflow_id FROM os_dispatches WHERE installation_id=%s "
            "AND state='DELIVERED' ORDER BY workflow_id LIMIT 129", (manifest['installationId'],)).fetchall()
        ids = {row[0] for row in rows}
        jobs = db.execute("SELECT application_id,id FROM personal_learning_jobs WHERE installation_id=%s "
            "AND (provider_started OR state='RUNNING') ORDER BY id LIMIT 129", (manifest['installationId'],)).fetchall()
        ids.update('os:'+manifest['installationId']+':'+str(app)+':'+str(ident) for app, ident in jobs)
        delegated = db.execute("SELECT workflow_id FROM os_input_delegation_dispatches WHERE installation_id=%s "
            "AND state='STARTED' ORDER BY workflow_id LIMIT 129", (manifest['installationId'],)).fetchall()
        ids.update(row[0] for row in delegated)
        proactive = db.execute("SELECT application_id,run_id FROM os_proactive_dispatches WHERE installation_id=%s "
            "AND state='STARTED' ORDER BY run_id LIMIT 129", (manifest['installationId'],)).fetchall()
        ids.update('os-proactive-task:'+manifest['installationId']+':'+str(app)+':'+str(ident) for app, ident in proactive)
    if len(ids) > 128 or any(len(group) > 128 for group in (rows, jobs, delegated, proactive)):
        raise OwnershipError('Admitted Temporal handles exceeded the bounded profile')
    return sorted(ids)


def _relocate_schema_labels(path, record):
    from .recovery_operator import connect_owned
    for component, plan in record['schemaRelocations'].items():
        with connect_owned(path, component=component, role='migrator') as db:
            db.execute("SET LOCAL lock_timeout='2s'")
            db.execute("SET LOCAL statement_timeout='3s'")
            owner = db.execute("SELECT pg_get_userbyid(relowner)=current_user FROM pg_class "
                "WHERE oid='public.schema_version'::regclass").fetchone()
            if owner != (True,): raise OwnershipError('Schema metadata is not owned by this migrator')
            rows = db.execute('SELECT * FROM schema_version FOR UPDATE').fetchall()
            current = [[str(v) for v in row] for row in rows]
            if current == [plan['before']]:
                if db.execute('UPDATE schema_version SET db_name=%s WHERE version_partition=0 AND db_name=%s',
                        (plan['after'][1], plan['before'][1])).rowcount != 1:
                    raise OwnershipError('Schema label relocation was not exact')
            elif current != [plan['after']]:
                raise OwnershipError('Tracked schema label changed')
            if [[str(v) for v in row] for row in db.execute('SELECT * FROM schema_version').fetchall()] != [plan['after']]:
                raise OwnershipError('Schema label relocation did not reconcile')


def _service_digest(binding):
    # A restart may replace only the independently inspected loopback port.
    return service_digest(binding)


def _checked_record(path, shape):
    value = read_signed(Path(path).parent/FILE, Path(path).parent/'owner.key', maximum=1024**2)
    if (type(value) is not dict or set(value) != placed_fields(FIELDS,path)
            or any(value[k] != v or type(value[k]) is not type(v) for k, v in shape.items())
            or value['state'] not in {'PENDING', 'INSPECTED'}
            or value['serviceDigest'] is not None and (type(value['serviceDigest']) is not str
                or len(value['serviceDigest']) != 64 or any(c not in '0123456789abcdef' for c in value['serviceDigest']))
            or type(value['catalog']) is not list or len(value['catalog']) > 128):
        raise OwnershipError('Restored Temporal operation differs')
    if value['state'] == 'INSPECTED' and value['serviceDigest'] is None:
        raise OwnershipError('Inspected Temporal service pin is absent')
    if value['profile']==CLOUD_PROFILE:
        from .recovery_metadata import checked_cloud_temporal
        checked_cloud_temporal(value['original'],value['installationId'])
    else:
        checked_temporal(value['original'],value['installationId'],
            with_id=value['profile']==PROFILE,require_id=value['profile']==PROFILE)
    checked_catalog(value['catalog'],value['original'],value['installationId'])
    return value


def checked_catalog(catalog,original,installation):
    if type(catalog) is not list or len(catalog)>128:
        raise OwnershipError('Restored Temporal catalog differs')
    catalog_fields = {'workflowId','runId','firstRunId','workflowType','taskQueue','status',
        'events','historyDigest','executionTimeoutSeconds'}
    seen = set()
    for item in catalog:
        if (type(item) is not dict or set(item) != catalog_fields
                or type(item['workflowType']) is not str or item['workflowType'] not in QUEUES or type(item['workflowId']) is not str
                or type(item['taskQueue']) is not str or type(item['status']) is not int
                or not 1 <= item['status'] <= 7 or type(item['events']) is not int or not 1 <= item['events'] <= 4096
                or type(item['executionTimeoutSeconds']) is not int or item['executionTimeoutSeconds'] < 0
                or type(item['historyDigest']) is not str or len(item['historyDigest']) != 64
                or any(c not in '0123456789abcdef' for c in item['historyDigest'])):
            raise OwnershipError('Restored Temporal catalog differs')
        checked_id(item['runId']); checked_id(item['firstRunId'])
        parts=item['workflowId'].split(':')
        if (len(parts)!=4 or parts[0] not in {'os','os-schedule','os-proactive-task','os-agent'}
                or parts[1]!=installation):raise OwnershipError('Original workflow installation differs')
        checked_id(parts[2]);checked_id(parts[3])
        original_queue(item['workflowType'],item['workflowId'],original['data']['runId'],item['taskQueue'])
        key = item['workflowId'], item['runId']
        if key in seen: raise OwnershipError('Restored Temporal catalog duplicates a run')
        seen.add(key)
    return catalog


CONNECT_SECONDS = 10
INSPECTION_SECONDS = 20


async def _raw_client(binding, original, *, connection=None):
    if connection is not None:
        from agentic_os.adapters.aws.temporal import recovery_binding
        if recovery_binding(connection,original)!=binding:
            raise OwnershipError('Original Cloud connection differs')
        try:return await asyncio.wait_for(connection.connect(),CONNECT_SECONDS)
        except TimeoutError:raise OwnershipError('Original Cloud workflow service unavailable') from None
    # A mapped port can precede Temporal frontend health. Retry only the
    # read-only SDK handshake within one finite deadline, without decoding
    # history or retaining any SQL session. Exhaustion keeps the target held.
    deadline = time.monotonic()+CONNECT_SECONDS
    while True:
        remaining = deadline-time.monotonic()
        if remaining <= 0:
            raise OwnershipError('Original workflow service unavailable')
        try:
            return await asyncio.wait_for(Client.connect('127.0.0.1:'+str(binding['port']),
                namespace=original['namespace']), min(2, remaining))
        except (RuntimeError, TimeoutError, RPCError):
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                raise OwnershipError('Original workflow service unavailable') from None
            await asyncio.sleep(min(.1, remaining))


async def verify_cloud_history_prefix(client,original,records):
    """Shared supported raw-prefix check for parked sources and held targets."""
    from .recovery_metadata import checked_cloud_temporal
    from .recovery_quarantine import prefix_digest
    checked_cloud_temporal(original,original['data']['installationId'])
    checked_catalog(records,original,original['data']['installationId'])
    actual={(row['workflowId'],row['runId']):row for row in records}
    for row in original['catalog']:
        current=actual.get((row['workflowId'],row['runId']))
        if current is None or (row['status']!=1 and current!=row):
            raise OwnershipError('Original Cloud history is missing or changed')
        await prefix_digest(client,original,row)


async def _inspect_history(path, binding, original, *, connection=None):
    # Only raw read RPCs are used. The SDK converter never decodes private
    # history, and the underlying service client is not returned to a caller.
    client = await _raw_client(binding, original,**({} if connection is None else dict(connection=connection)))
    namespace = await client.workflow_service.describe_namespace(
        DescribeNamespaceRequest(namespace=original['namespace']), timeout=timedelta(seconds=5))
    checked_id(namespace.namespace_info.id)
    if connection is not None:connection.cloud.verify(namespace)
    elif (namespace.namespace_info.id!=original['namespaceId']
                or namespace.namespace_info.name!=original['namespace']
                or dict(namespace.namespace_info.data) != original['data']):
            raise OwnershipError('Original namespace identity differs')
    from .recovery_ready import admitted_archive
    checkpoint = admitted_archive(path)['receipt']['runtimeCheckpoint']
    required=original['requiredWorkflows'] if connection is not None else ()
    records = await _history_catalog(client, binding, original, checkpoint,required=required)
    if connection is not None:
        await verify_cloud_history_prefix(client,original,records)
        response=await client.workflow_service.describe_namespace(DescribeNamespaceRequest(
            namespace=original['namespace']),timeout=timedelta(seconds=5))
        connection.cloud.verify(response)
        from agentic_os.adapters.aws.temporal import recovery_binding
        if recovery_binding(connection,original)!=binding:
            raise OwnershipError('Cloud service changed during inspection')
        return records
    # Verify the same owned service again after all network reads.
    current, _ = inspect_service(path)
    if _service_digest(current) != _service_digest(binding) or current['port'] != binding['port']:
        raise OwnershipError('Restored Temporal service changed during inspection')
    return records


async def _history_executions(client, namespace, required, links):
    token = b''; tokens = set(); listed = set(); runs=set(); count = 0
    while True:
        listing = await client.workflow_service.list_workflow_executions(ListWorkflowExecutionsRequest(
            namespace=namespace, page_size=32, next_page_token=token), timeout=timedelta(seconds=5))
        if not listing.executions and listing.next_page_token:
            raise OwnershipError('Temporal catalog cursor did not advance')
        for execution in listing.executions:
            count += 1
            if count > 128:raise OwnershipError('Temporal catalog exceeded its bounded profile')
            listed.add(execution.execution.workflow_id)
            runs.add((execution.execution.workflow_id,execution.execution.run_id))
            yield execution
        token = listing.next_page_token
        if not token:break
        if token in tokens or count >= 128:
            raise OwnershipError('Temporal catalog exceeded its bounded profile')
        tokens.add(token)
    for ident in sorted(set(required)-listed):
        count += 1
        if count > 128:raise OwnershipError('Temporal catalog exceeded its bounded profile')
        description = await client.workflow_service.describe_workflow_execution(DescribeWorkflowExecutionRequest(
            namespace=namespace, execution=WorkflowExecution(workflow_id=ident)), timeout=timedelta(seconds=5))
        if description.workflow_execution_info.execution.workflow_id != ident:
            raise OwnershipError('Admitted workflow identity differs')
        runs.add((ident,description.workflow_execution_info.execution.run_id))
        yield description.workflow_execution_info
    at=0
    while at<len(links):
        ident,run=links[at];at+=1
        if (ident,run) in runs:continue
        count+=1
        if count>128:raise OwnershipError('Temporal history lineage exceeded its bounded profile')
        response=await client.workflow_service.describe_workflow_execution(DescribeWorkflowExecutionRequest(
            namespace=namespace,execution=WorkflowExecution(workflow_id=ident,run_id=run)),timeout=timedelta(seconds=5))
        info=response.workflow_execution_info
        if info.execution.workflow_id!=ident or info.execution.run_id!=run:
            raise OwnershipError('Original workflow lineage differs')
        runs.add((ident,run));yield info


async def _history_catalog(client, binding, original, checkpoint, *, required=()):
    """Bounded opaque service reads shared by local and Cloud recovery.

    Visibility can lag admitted starts. Directly describe required workflow IDs
    missing from the listing; never infer their absence or create replacements.
    Callers authenticate the namespace and held generation before and after IO.
    """
    from .recovery_runtime_checkpoint import checked_runtime_checkpoint
    checked_runtime_checkpoint(checkpoint)
    if (type(required) not in {list,tuple} or len(required)>128
            or any(type(ident) is not str for ident in required) or len(set(required))!=len(required)):
        raise OwnershipError('Admitted workflow envelope differs')
    checked_id(binding['installationId'])
    if original['data']['installationId']!=binding['installationId']:
        raise OwnershipError('Original workflow installation differs')
    def identity(ident):
        parts=ident.split(':')
        if (len(parts)!=4 or parts[0] not in {'os','os-schedule','os-proactive-task','os-agent'}
                or parts[1]!=binding['installationId']):
            raise OwnershipError('Temporal catalog is outside the bounded owned profile')
        checked_id(parts[2]);checked_id(parts[3])
    for ident in required:identity(ident)
    records = []; seen = set(); total_events = total_bytes = 0; links=[]; parents={}; first_runs={}
    async for execution in _history_executions(client, original['namespace'], required,links):
        ident, run = execution.execution.workflow_id, execution.execution.run_id
        identity(ident);checked_id(run)
        if (ident, run) in seen or len(seen) >= 128:
            raise OwnershipError('Temporal catalog is outside the bounded owned profile')
        seen.add((ident, run))
        description = await client.workflow_service.describe_workflow_execution(DescribeWorkflowExecutionRequest(
            namespace=original['namespace'], execution=WorkflowExecution(workflow_id=ident, run_id=run)),
            timeout=timedelta(seconds=5))
        info, config = description.workflow_execution_info, description.execution_config
        if (info.execution.workflow_id!=ident or info.execution.run_id!=run
                or not 1<=int(info.status)<=7 or config.workflow_execution_timeout.seconds<0):
            raise OwnershipError('Original workflow description differs')
        workflow = info.type.name
        first = info.first_run_id or run;checked_id(first);first_runs[(ident,run)]=first
        links.append((ident,first))
        if workflow=='OSAgentTaskDriver/1':
            production_workflow(checkpoint,ident)
        queue=original_queue(workflow,ident,original['data']['runId'],config.task_queue.name)
        digest = hashlib.sha256(); count = 0; history_token = b''; history_tokens = set()
        while True:
            response = await client.workflow_service.get_workflow_execution_history(GetWorkflowExecutionHistoryRequest(
                namespace=original['namespace'], execution=WorkflowExecution(workflow_id=ident, run_id=run),
                maximum_page_size=64, next_page_token=history_token), timeout=timedelta(seconds=5))
            for event in response.history.events:
                count += 1; total_events += 1
                raw = event.SerializeToString(deterministic=True); total_bytes += len(raw)
                if count > 4096 or total_events > 16384 or total_bytes > 16*1024**2 or event.event_id != count:
                    raise OwnershipError('Temporal history exceeded its bounded profile')
                if count == 1:
                    if not event.HasField('workflow_execution_started_event_attributes'):
                        raise OwnershipError('Original workflow start is absent')
                    start = event.workflow_execution_started_event_attributes
                    if start.task_queue.name != queue or start.workflow_type.name != workflow:
                        raise OwnershipError('Original workflow start binding differs')
                    previous=start.continued_execution_run_id or None
                    if previous is not None:
                        checked_id(previous);links.append((ident,previous))
                    if start.first_execution_run_id and start.first_execution_run_id!=first:
                        raise OwnershipError('Original workflow first execution differs')
                    parents[(ident,run)]=previous
                digest.update(len(raw).to_bytes(8, 'big')+raw)
            history_token = response.next_page_token
            if not history_token: break
            if history_token in history_tokens or not response.history.events:
                raise OwnershipError('Temporal history cursor did not advance')
            history_tokens.add(history_token)
        if not count: raise OwnershipError('Original workflow history is absent')
        records.append(dict(workflowId=ident, runId=run, firstRunId=first, workflowType=workflow,
            taskQueue=queue, status=int(info.status), events=count, historyDigest=digest.hexdigest(),
            executionTimeoutSeconds=config.workflow_execution_timeout.seconds))
    if not set(required) <= {row['workflowId'] for row in records}:
        raise OwnershipError('Admitted workflow history is missing')
    for key,first in first_runs.items():
        current=key;visited=set()
        while current[1]!=first:
            if current in visited or current not in parents or parents[current] is None:
                raise OwnershipError('Original workflow history lineage is incomplete')
            visited.add(current);current=(current[0],parents[current])
            if first_runs.get(current)!=first:
                raise OwnershipError('Original workflow history lineage differs')
        if parents[current] is not None:
            raise OwnershipError('Original workflow first history differs')
    return sorted(records, key=lambda row: (row['workflowId'], row['runId']))


async def _available_history(path, binding, original, *, connection=None):
    # Restored persistence can become readable after the frontend handshake.
    # Retry only failed read RPCs, within one deadline. A successful attempt
    # must still validate the complete namespace, run, queue and history pins;
    # validation failures never become a retry or an accepted partial catalog.
    try:
        async with asyncio.timeout(INSPECTION_SECONDS):
            while True:
                try:
                    if connection is None:return await _inspect_history(path, binding, original)
                    return await _inspect_history(path, binding, original,connection=connection)
                except RPCError as error:
                    if connection is not None:
                        from temporalio.service import RPCStatusCode
                        if error.status not in {RPCStatusCode.UNAVAILABLE,RPCStatusCode.DEADLINE_EXCEEDED}:
                            raise OwnershipError('Original Cloud history unavailable; recovery remains held') from None
                    await asyncio.sleep(.1)
    except TimeoutError:
        raise OwnershipError('Original workflow history unavailable') from None


async def relocate_temporal(path, token, *, expected_generation, network_subnets=None,connection=None):
    path = Path(path)
    if connection is not None:
        return await _inspect_cloud_restoration(path,token,expected_generation=expected_generation,connection=connection,
            network_subnets=network_subnets)
    from .coordinated_backup import component_watermark
    with held_operator(path, token, expected_generation=expected_generation) as (manifest, admitted):
        original = relocation_metadata(path)['temporal']
        if original is None:
            raise OwnershipError('Snapshot did not authenticate a Temporal namespace')
        original=dict(original)
        if 'namespaceId' not in original:
            # Legacy snapshots can pin a UUID only while their original full
            # namespace table is still exactly the admitted archive. Existing
            # inspections without that pin cannot silently acquire one.
            if (path.parent/FILE).exists() or (path.parent/FILE).is_symlink():
                pinned=read_signed(path.parent/FILE,path.parent/'owner.key',maximum=1024**2)
                if (type(pinned) is not dict or pinned.get('profile')!=PROFILE
                        or type(pinned.get('original')) is not dict
                        or {k:v for k,v in pinned['original'].items() if k!='namespaceId'}!=original):
                    raise OwnershipError('Legacy inspected lineage lacks an original namespace pin')
                original['namespaceId']=pinned['original'].get('namespaceId')
            else:
                current=component_watermark(path,'temporal')
                expected=admitted['receipt']['components']['temporal']['after']
                if any(current[k]!=expected[k] for k in ('counts','rowDigests','schemaVersions')):
                    raise OwnershipError('Original namespace store changed before identification')
                original['namespaceId']=namespace_id(path,original['namespace'])
        checked_temporal(original,manifest['installationId'],require_id=True)
        if namespace_id(path,original['namespace'])!=original['namespaceId']:
            raise OwnershipError('Original namespace identifier changed')
        shape = _shape(manifest, admitted, original, network_subnets)
        shape['requiredWorkflows'] = _admitted_workflows(path, manifest)
        marker = path.parent/FILE
        if marker.exists() or marker.is_symlink():
            record = _checked_record(path, shape)
        else:
            service = path.parent/'temporal-service.json'
            if service.exists() or service.is_symlink():
                raise OwnershipError('Untracked Temporal service cannot be adopted')
            # No SQL connection survives the following service start or RPCs.
            for component in ('temporal', 'visibility'):
                current = component_watermark(path, component)
                expected = admitted['receipt']['components'][component]['after']
                if any(current[k] != expected[k] for k in ('counts','rowDigests','schemaVersions')):
                    raise OwnershipError('Original Temporal store differs from the admitted snapshot')
            record = dict(shape, serviceDigest=None, catalog=[], state='PENDING')
            write_signed(marker, record, path.parent/'owner.key')
        service = _provision_owned(path, manifest, network_subnets=network_subnets)
        if record['serviceDigest'] is not None and record['serviceDigest'] != _service_digest(service):
            raise OwnershipError('Tracked Temporal service configuration differs')
        record['serviceDigest'] = _service_digest(service)
        record['state'] = 'PENDING'
        write_signed(marker, record, path.parent/'owner.key')
        _relocate_schema_labels(path, record)
        binding = _start_owned(path, service)
        record['catalog'] = await _available_history(path, binding, original)
        if not set(record['requiredWorkflows']) <= {v['workflowId'] for v in record['catalog']}:
            raise OwnershipError('Admitted workflow history is missing')
        record['state'] = 'INSPECTED'
        write_signed(marker, record, path.parent/'owner.key')
        publish_lineage(path,record,binding)
        return dict(profile=PROFILE, state='INSPECTED', workflowRuns=len(record['catalog']),
            namespace=original['namespace'], historyEvents=sum(v['events'] for v in record['catalog']), enabledLanes=[])


async def _inspect_cloud_restoration(path,token,*,expected_generation,connection,network_subnets):
    from agentic_os.adapters.aws.temporal import recovery_binding
    with held_operator(path,token,expected_generation=expected_generation) as (manifest,admitted):
        original=relocation_metadata(path)['temporal'];binding=recovery_binding(connection,original)
        if connection.installation.root!=path.parent:
            raise OwnershipError('Cloud recovery target differs')
        shape=_shape(manifest,admitted,original,network_subnets)
        shape['requiredWorkflows']=_admitted_workflows(path,manifest)
        marker=path.parent/FILE
        if marker.exists() or marker.is_symlink():record=_checked_record(path,shape)
        else:record=dict(shape,serviceDigest=_service_digest(binding),catalog=[],state='PENDING')
        if record['serviceDigest']!=_service_digest(binding):
            raise OwnershipError('Tracked Cloud service configuration differs')
        record['state']='PENDING';write_signed(marker,record,path.parent/'owner.key')
    # RPCs neither hold a SQL session nor borrow a runtime Ready guard.
    catalog=await _available_history(path,binding,original,connection=connection)
    if not set(shape['requiredWorkflows'])<={row['workflowId'] for row in catalog}:
        raise OwnershipError('Admitted Cloud workflow history is missing')
    with held_operator(path,token,expected_generation=expected_generation) as (current,current_admitted):
        if (current!=manifest or current_admitted!=admitted or _checked_record(path,shape)!=record
                or _admitted_workflows(path,current)!=shape['requiredWorkflows']
                or recovery_binding(connection,original)!=binding):
            raise OwnershipError('Held Cloud inspection changed')
        record.update(state='INSPECTED',catalog=catalog)
        write_signed(marker,record,path.parent/'owner.key');publish_lineage(path,record,binding)
    return dict(profile=CLOUD_PROFILE,state='INSPECTED',workflowRuns=len(catalog),namespace=original['namespace'],
        historyEvents=sum(row['events'] for row in catalog),enabledLanes=[])
