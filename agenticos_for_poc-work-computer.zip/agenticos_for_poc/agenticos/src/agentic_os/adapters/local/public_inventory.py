"""One finite isolated worker for fresh public content digests, never authority."""
import atexit
import os
from pathlib import Path
import selectors
import subprocess
import sys
from textwrap import indent
from threading import Lock
import time

from .files import OwnershipError

_lock = Lock()
_worker = None


def _retire():
    global _worker
    worker, _worker = _worker, None
    if worker is None:
        return
    process = worker['process']
    # A fork inherits descriptors, not ownership of its parent's child.
    if worker['owner'] == os.getpid():
        if process.poll() is None:
            process.kill()
        process.wait()
    for stream in (process.stdin, process.stdout):
        stream.close()


def close():
    with _lock:
        _retire()


atexit.register(close)


def _start(package, program):
    # Only fixed already-loaded code and a public package path enter this
    # process. Each request contains its ordinal; no caller data enters it.
    script = 'def scan():\n' + indent(program, '    ') + '''
import select,sys,time
began=time.monotonic()
for ordinal in range(1,65):
    remaining=20-(time.monotonic()-began)
    if remaining<=0 or not select.select([sys.stdin],[],[],min(5,remaining))[0]:
        break
    if sys.stdin.buffer.readline(8)!=str(ordinal).encode()+b'\\n':
        sys.exit(1)
    sys.stdout.write(str(ordinal)+':')
    scan()
    sys.stdout.write('\\n');sys.stdout.flush()
'''
    process = subprocess.Popen([sys.executable, '-I', '-S', '-c', script, os.fspath(package)],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        env={}, cwd='/', close_fds=True, start_new_session=True, umask=0o077)
    try:
        os.set_blocking(process.stdin.fileno(), False)
        os.set_blocking(process.stdout.fileno(), False)
    except BaseException:
        process.kill()
        process.wait()
        process.stdin.close()
        process.stdout.close()
        raise
    return dict(package=package, program=program, process=process, count=0,
        owner=os.getpid(), began=time.monotonic(), last=time.monotonic())


def measure(package, program):
    """Perform a complete post-request scan within the original1.5-second bound.

    No completed fingerprint survives here. The child retires after64 scans,
    five idle seconds or20 total seconds; the parent retires it earlier at idle
    and lifetime boundaries. Every error kills and joins the owned child.
    """
    if not isinstance(package, Path):
        return None
    global _worker
    deadline = time.monotonic() + 1.5
    if not _lock.acquire(timeout=1.5):
        raise OwnershipError('Restoration program inventory deadline exceeded')
    try:
        now = time.monotonic()
        if _worker is not None and (_worker['owner'] != os.getpid()
                or _worker['package'] != package or _worker['program'] != program
                or _worker['process'].poll() is not None or _worker['count'] >= 64
                or now - _worker['began'] >= 18 or now - _worker['last'] >= 4):
            _retire()
        if _worker is None:
            _worker = _start(package, program)
        process = _worker['process']
        ordinal = _worker['count'] + 1
        request = str(ordinal).encode() + b'\n'
        if os.write(process.stdin.fileno(), request) != len(request):
            raise OwnershipError('Restoration program inventory unavailable')
        prefix = str(ordinal).encode() + b':'
        length = len(prefix) + 65
        result = bytearray()
        with selectors.DefaultSelector() as selected:
            selected.register(process.stdout, selectors.EVENT_READ)
            while len(result) < length:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not selected.select(remaining):
                    raise OwnershipError('Restoration program inventory deadline exceeded')
                block = os.read(process.stdout.fileno(), length + 1 - len(result))
                if not block:
                    try:
                        code = process.wait(timeout=max(.001, deadline - time.monotonic()))
                    except subprocess.TimeoutExpired:
                        raise OwnershipError('Restoration program inventory deadline exceeded') from None
                    errors = {2: 'Restoration program directory differs',
                        3: 'Restoration program is not a regular file',
                        4: 'Restoration program envelope exceeded'}
                    raise OwnershipError(errors.get(code, 'Restoration program inventory unavailable'))
                result.extend(block)
        digest = bytes(result[len(prefix):-1])
        if (len(result) != length or not result.startswith(prefix) or result[-1:] != b'\n'
                or len(digest) != 64 or any(c not in b'0123456789abcdef' for c in digest)):
            raise OwnershipError('Restoration program inventory unavailable')
        _worker['count'] = ordinal
        _worker['last'] = time.monotonic()
        if ordinal == 64:
            _retire()
        return os.fspath(package), digest.decode('ascii')
    except (OSError, ValueError):
        _retire()
        raise OwnershipError('Restoration program inventory unavailable') from None
    except BaseException:
        _retire()
        raise
    finally:
        _lock.release()
