"""Encrypted quiescent foundation snapshot into a fresh owned target.

This is G01 recovery, not the later live-task/privacy-journal recovery protocol.
Never restore into populated stores. Source remains unchanged and runtime lanes disabled.
"""
import base64
import hashlib
import hmac
from pathlib import Path
import secrets
from uuid import uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from .artifacts import checked_id
from .docker import DockerControl
from .files import OwnershipError, private_directory, private_read, private_write, check_private
from .ownership import COMPONENTS, load_manifest
from .target import validate_target, connect_owned
from .installer import install_postgres

MAXIMUM = 67108864
READ_SECRET = 'read -r PGPASSWORD; export PGPASSWORD; exec "$@"'


def tables(path: Path, component: str):
    with connect_owned(path, component=component) as db:
        names = db.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename").fetchall()
        # Identifiers originate only in the owned component schema, not user input.
        from psycopg import sql
        return {name: db.execute(sql.SQL('SELECT count(*) FROM {}').format(sql.Identifier(name))).fetchone()[0]
                for (name,) in names}


def require_quiescent(path: Path):
    with connect_owned(path) as db:
        revision = db.execute('SELECT version_num FROM alembic_version').fetchone()[0]
        if revision != 'os_pg_0002':
            raise OwnershipError('Foundation snapshot profile does not support this schema')
        if db.execute("SELECT count(*) FROM os_tasks WHERE state NOT IN ('COMPLETED','FAILED','CANCELLED','EXPIRED','QUARANTINED')").fetchone()[0]:
            raise OwnershipError('Active work requires the durable recovery profile')
        if db.execute("SELECT count(*) FROM os_dispatches WHERE state IN ('DUE','LEASED')").fetchone()[0]:
            raise OwnershipError('Outstanding dispatch blocks foundation snapshot')
    if tables(path,'core').get('sessions',0) or tables(path,'temporal').get('executions',0):
        raise OwnershipError('Component activity requires durable recovery watermarks')


def backup(path: Path) -> Path:
    manifest = validate_target(path)
    require_quiescent(path)
    docker = DockerControl(manifest); root = Path(manifest['root'])
    dumps = {}; counts = {}
    for component in COMPONENTS:
        validate_target(path, component=component, role='migrator')
        definition = manifest['databases'][component]
        content = docker.binary('exec','-i',manifest['postgres']['container'],'sh','-c',READ_SECRET,
            '--','pg_dump','--host','127.0.0.1','--username',definition['migrator'],'--dbname',definition['name'],
            '--format=custom','--no-owner','--no-acl','--no-comments', input=(definition['migratorPassword']+'\n').encode())
        dumps[component] = base64.b64encode(content).decode('ascii')
        counts[component] = tables(path,component)
    objects = {}
    for directory in ['keys','artifacts']:
        check_private(root/directory,directory=True)
        for file in sorted((root/directory).iterdir()):
            if directory == 'keys':
                if file.name != 'active.json':
                    checked_id(file.stem)
                    if file.suffix != '.key':
                        raise OwnershipError('Unknown key file')
            else:
                checked_id(file.stem)
                if file.suffix != '.json':
                    raise OwnershipError('Unknown artifact file')
            objects[directory+'/'+file.name] = base64.b64encode(private_read(file,1_500_000)).decode('ascii')
    payload = canonical_bytes({'version':1,'installationId':manifest['installationId'],
                               'components':dumps,'files':objects,'counts':counts})
    if len(payload)>MAXIMUM:
        raise OwnershipError('Snapshot exceeds local foundation envelope')
    ident=str(uuid4()); destination=root/'backups'/ident; private_directory(destination)
    key=AESGCM.generate_key(bit_length=256); nonce=secrets.token_bytes(12)
    binding={'version':1,'id':ident,'installationId':manifest['installationId'],
             'profile':'quiescent-foundation','counts':counts}
    encrypted=nonce+AESGCM(key).encrypt(nonce,payload,canonical_bytes(binding))
    receipt={**binding,'ciphertextDigest':hashlib.sha256(encrypted).hexdigest()}
    signature=hmac.digest(key,canonical_bytes(receipt),'sha256').hex()
    private_write(destination/'recovery.key',key)
    private_write(destination/'snapshot.bin',encrypted)
    private_write(destination/'receipt.json',canonical_bytes({'receipt':receipt,'signature':signature}))
    return destination


def read_backup(directory: Path) -> dict:
    if not directory.is_absolute():
        raise OwnershipError('Explicit private snapshot directory required')
    check_private(directory,directory=True); checked_id(directory.name)
    key=private_read(directory/'recovery.key',32)
    if len(key)!=32:
        raise OwnershipError('Recovery key unavailable')
    envelope=parse_canonical_json(private_read(directory/'receipt.json'))
    if type(envelope) is not dict or set(envelope)!={'receipt','signature'}:
        raise OwnershipError('Invalid snapshot receipt')
    receipt=envelope['receipt']
    if type(receipt) is not dict or set(receipt)!={'version','id','installationId','profile','counts','ciphertextDigest'}:
        raise OwnershipError('Invalid snapshot receipt fields')
    if type(envelope['signature']) is not str or not hmac.compare_digest(
            hmac.digest(key,canonical_bytes(receipt),'sha256').hex(),envelope['signature']):
        raise OwnershipError('Snapshot receipt authentication failed')
    if receipt['id']!=directory.name or receipt['profile']!='quiescent-foundation' or receipt['version']!=1:
        raise OwnershipError('Snapshot profile mismatch')
    encrypted=private_read(directory/'snapshot.bin',MAXIMUM+28)
    if hashlib.sha256(encrypted).hexdigest()!=receipt['ciphertextDigest']:
        raise OwnershipError('Snapshot corrupted')
    binding={key:value for key,value in receipt.items() if key!='ciphertextDigest'}
    try:
        payload=parse_canonical_json(AESGCM(key).decrypt(encrypted[:12],encrypted[12:],canonical_bytes(binding)))
    except Exception:
        raise OwnershipError('Snapshot authentication failed') from None
    if (type(payload) is not dict or set(payload)!={'version','installationId','components','files','counts'}
            or payload['version']!=1 or payload['installationId']!=receipt['installationId']
            or payload['counts']!=receipt['counts'] or set(payload['components'])!=set(COMPONENTS)):
        raise OwnershipError('Snapshot component binding mismatch')
    checked_id(payload['installationId'])
    return payload


def restore(directory: Path, *, target: Path):
    payload=read_backup(directory)
    manifest=validate_target(target,role='migrator')
    root=Path(manifest['root'])
    if manifest['installationId']!=payload['installationId']:
        raise OwnershipError('Snapshot belongs to a different logical installation')
    for component in COMPONENTS:
        if tables(target,component):
            raise OwnershipError('Restore requires fresh empty owned component databases')
    if list((root/'keys').iterdir()) or list((root/'artifacts').iterdir()):
        raise OwnershipError('Restore requires empty owned key/artifact stores')
    # Validate every file/dump before the first mutation; no path, link or redirect from archive.
    validated={}
    for name,value in payload['files'].items():
        parts=Path(name).parts
        if len(parts)!=2 or parts[0] not in {'keys','artifacts'} or str(Path(*parts))!=name:
            raise OwnershipError('Invalid restored object path')
        if parts[0]=='keys' and parts[1]=='active.json':
            pass
        else:
            checked_id(Path(parts[1]).stem)
            if Path(parts[1]).suffix!=('.key' if parts[0]=='keys' else '.json'):
                raise OwnershipError('Invalid restored object suffix')
        validated[name]=base64.b64decode(value,validate=True)
    dumps={name:base64.b64decode(value,validate=True) for name,value in payload['components'].items()}
    docker=DockerControl(manifest)
    try:
        for component,content in dumps.items():
            validate_target(target,component=component,role='migrator')
            definition=manifest['databases'][component]
            docker.binary('exec','-i',manifest['postgres']['container'],'sh','-c',READ_SECRET,
                '--','pg_restore','--host','127.0.0.1','--username',definition['migrator'],'--dbname',definition['name'],
                '--no-owner','--no-acl','--no-comments','--single-transaction','--exit-on-error',
                input=(definition['migratorPassword']+'\n').encode()+content)
            if tables(target,component)!=payload['counts'][component]:
                raise OwnershipError('Restored component counts failed reconciliation')
        for name,content in validated.items():
            private_write(root/name,content)
            if private_read(root/name,1_500_000)!=content:
                raise OwnershipError('Restored artifact/key reconciliation failed')
        from agentic_os.adapters.postgres.migrate import metadata_permissions
        for component in COMPONENTS:
            metadata_permissions(target,component)
    except Exception:
        private_write(root/'restore-blocked',b'Partial restore: no runtime activation; fresh target or operator repair required',replace=True)
        raise
    private_write(root/'restore-reconciled.json',canonical_bytes({'version':1,'profile':'quiescent-foundation',
        'snapshotId':directory.name,'counts':payload['counts']}))


def restore_fresh(directory: Path, root: Path, docker_endpoint: str) -> Path:
    from .capacity import Capacity, GiB, docker_headroom
    from .build_cache import cache_root, admission_root
    from .installer import PG_IMAGE
    with Capacity(admission_root(cache_root(root))).reserve(2*GiB,purpose='installation',
            docker_free=docker_headroom(docker_endpoint,PG_IMAGE),docker_peak=GiB):
        return _restore_fresh(directory,root,docker_endpoint)


def _restore_fresh(directory: Path, root: Path, docker_endpoint: str) -> Path:
    payload=read_backup(directory)
    target=install_postgres(root,docker_endpoint,installation_id=payload['installationId'],
                            disposition='recovery-hold')
    restore(directory,target=target)
    from .operator import issue_bootstrap
    issue_bootstrap(target)  # Old operator credentials are deliberately not restored.
    return target
