"""One-use local operator bootstrap. No personal-data or host-user authority."""
import fcntl
import hashlib
import hmac
import os
from pathlib import Path
import secrets
import time

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from .files import OwnershipError, check_private, private_read, private_write
from .ownership import load_manifest


def encoded_state(root: Path, record: dict):
    signature=hmac.digest(private_read(root/'owner.key',32),canonical_bytes(record),'sha256').hex()
    return canonical_bytes({'record':record,'signature':signature})


def write_state(root: Path, record: dict):
    private_write(root/'operator-state.json',encoded_state(root,record),replace=True)


def read_state(root: Path) -> dict:
    return checked_state(root,parse_canonical_json(private_read(root/'operator-state.json')))


def checked_state(root: Path, value: dict) -> dict:
    if type(value) is not dict or set(value)!={'record','signature'} or type(value['signature']) is not str:
        raise OwnershipError('Operator state malformed')
    expected=hmac.digest(private_read(root/'owner.key',32),canonical_bytes(value['record']),'sha256').hex()
    if not hmac.compare_digest(expected,value['signature']):
        raise OwnershipError('Operator state authentication failed')
    record=value['record']
    if (type(record) is not dict or set(record)!={'version','installationId','bootstrapDigest','expiresAt',
                                                'consumed','operatorDigest','generation'}
            or type(record['version']) is not int or record['version'] not in {1,2}
            or type(record['consumed']) is not bool or type(record['expiresAt']) is not int
            or type(record['generation']) is not int
            or record['version']==1 and record['generation']!=1
            or record['version']==2 and (not 2<=record['generation']<=2**53-1
                or load_manifest(root/'manifest.json')['profile']!='aws-eks/1')):
        raise OwnershipError('Operator state fields malformed')
    return record


def bound_digest(installation: str, token: bytes) -> str:
    if type(token) is not bytes or len(token)!=32:
        raise OwnershipError('Invalid operator credential')
    return hashlib.sha256(b'agentic-os.operator/1\0'+installation.encode()+b'\0'+token).hexdigest()


def issue_bootstrap(path: Path, *, now: int | None = None):
    manifest=load_manifest(path);root=path.parent
    if any((root/name).exists() for name in ['operator-bootstrap.key','operator.key','operator-state.json']):
        raise OwnershipError('Operator identity already initialized')
    token=secrets.token_bytes(32)
    private_write(root/'operator-bootstrap.key',token)
    write_state(root,{'version':1,'installationId':manifest['installationId'],
        'bootstrapDigest':bound_digest(manifest['installationId'],token),'expiresAt':(now if now is not None else int(time.time()))+1800,
        'consumed':False,'operatorDigest':None,'generation':1})


def consume_bootstrap(path: Path, token: bytes, *, now: int | None = None) -> Path:
    manifest=load_manifest(path);root=path.parent
    lock=root/'operator.lock'
    fd=os.open(lock,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
    try:
        check_private(lock)
        fcntl.flock(fd,fcntl.LOCK_EX)
        state=read_state(root)
        if (state['installationId']!=manifest['installationId'] or state['consumed']
                or state['expiresAt']<=(now if now is not None else int(time.time()))
                or not hmac.compare_digest(bound_digest(manifest['installationId'],token),state['bootstrapDigest'])):
            raise OwnershipError('Operator bootstrap expired, used or invalid')
        operator=secrets.token_bytes(32)
        private_write(root/'operator.key',operator)
        state.update(consumed=True,operatorDigest=bound_digest(manifest['installationId'],operator))
        write_state(root,state)
        return root/'operator.key'
    finally:
        os.close(fd)


def verify_operator(path: Path, token: bytes):
    manifest=load_manifest(path);state=read_state(path.parent)
    if (state['installationId']!=manifest['installationId'] or not state['consumed']
            or type(state['operatorDigest']) is not str
            or not hmac.compare_digest(bound_digest(manifest['installationId'],token),state['operatorDigest'])):
        raise OwnershipError('Local operator credential rejected')
    return {'installationId':manifest['installationId'],'principal':'installation-operator',
            'generation':state['generation'],'profile':'installation-file-operator/1'
                if manifest['profile']=='aws-eks/1' else 'local-synthetic'}
