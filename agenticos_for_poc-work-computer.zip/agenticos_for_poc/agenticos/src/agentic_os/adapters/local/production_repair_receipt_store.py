"""One exact admitted inverse's metadata-only recovery port."""
from copy import deepcopy
from uuid import UUID

from sqlalchemy import select

from agentic_os.adapters.postgres.models import (Admission,AgentEffectReceipt,AgentRepairRoot,BudgetRoot,
    PublicEvent,Registration,RegisteredResourceSchema,RepairAdmission,RepairApproval,RepairGrant,
    RepairPrepared,RepairReceiptProjection,RepairWorkBinding,ReviewedEffectProvider,Segment,Task,TaskControl,WorkAttempt)
from agentic_os.contracts.canonical import digest
from agentic_os.effects.reviewed_observer import ReviewedReceiptObserver
from agentic_os.errors import OSErrorCode
from agentic_os.identity.service import scoped
from agentic_os.production.accounting import _handle
from agentic_os.production.repair_roots import load_tx
from agentic_os.production.repair_state import ProductionRepairState
from .files import OwnershipError
from .held_receipt_store import ReceiptSession,accounting_digest,history_digest,metadata
from .production_receipt_store import ProductionReceiptStore


PROVIDER_FIELDS={'providerBindingDigest','observerCredentialRef','observerCredentialDigest','endpointDigest'}


def source_capsule(db,attempt_id):
    """Authenticate actual serialized work and immutable adjacent handoffs."""
    attempt=db.get(WorkAttempt,UUID(attempt_id))
    if attempt is None or attempt.kind!='agent.repair' or attempt.state not in {'RESERVED','RUNNING','UNKNOWN'}:
        raise OwnershipError('Original production repair unavailable')
    subject=dict(installationId=str(attempt.installation_id),applicationId=str(attempt.application_id),
        tenantId=attempt.tenant_id,subjectId=attempt.subject_id)
    binding,repair=ProductionRepairState.binding(db,attempt)
    root=db.get(BudgetRoot,attempt.root_id);parent=db.get(Task,repair.parent_task_id);child=db.get(Task,repair.task_id)
    admitted=db.get(Admission,root.admission_id) if root else None
    grant=db.get(RepairGrant,binding.grant_id) if binding.grant_id else None
    approval=db.get(RepairApproval,grant.approval_id) if grant else None
    prepared=db.get(RepairPrepared,approval.prepared_id) if approval else None
    original=db.get(AgentEffectReceipt,repair.production_projection_id)
    original_work=db.get(WorkAttempt,repair.production_binding_id)
    if (binding.phase!='effect' or root is None or root.profile_ref!='agent-production/1'
            or root.accounting_format!='agent-resources/1' or parent is None or child is None or admitted is None
            or parent.id!=root.root_task_id or admitted.task_id!=parent.id or child.budget_root_id!=root.id
            or parent.deadline!=root.deadline or child.deadline!=root.deadline or repair.expires_at!=root.deadline
            or grant is None or approval is None or prepared is None or approval.decision!='approve'
            or approval.admission_id!=repair.id or prepared.admission_id!=repair.id
            or grant.payload['authorization']!=dict(kind='review_decision',decision=approval.decision_ref)
            or original is None or original_work is None or original_work.task_id!=parent.id
            or original_work.root_id!=root.id or original_work.kind!='agent.effect'
            or original_work.state!='SETTLED' or original_work.actual is None or original.binding_id!=original_work.id
            or original.payload['status']!='COMMITTED' or ReviewedReceiptObserver.reference(subject,original)!=repair.production_original):
        raise OwnershipError('Original production repair binding differs')
    policy=load_tx(db,subject,root)
    segment=db.get(Segment,attempt.segment_id)
    events=list(db.scalars(select(PublicEvent).where(*scoped(PublicEvent,subject),
        PublicEvent.segment_id==attempt.segment_id).order_by(PublicEvent.sequence).limit(129)))
    segments=list(db.scalars(select(Segment).where(*scoped(Segment,subject),Segment.task_id==parent.id)
        .order_by(Segment.id).limit(129)))
    parent_events=list(db.scalars(select(PublicEvent).where(*scoped(PublicEvent,subject),
        PublicEvent.segment_id.in_([s.id for s in segments])).order_by(PublicEvent.sequence).limit(129)))
    if segment is None or segment.task_id!=child.id or max(len(segments),len(parent_events),len(events))>128:
        raise OwnershipError('Original production repair history unavailable')
    immutable=digest('verification',dict(repair=metadata(repair),binding=metadata(binding),grant=metadata(grant),
        approval=metadata(approval),prepared=metadata(prepared),parent=metadata(parent),
        child=metadata(child,exclude={'state','version'}),policy=policy,original=metadata(original)))
    return dict(kind='agent.repair',handle=_handle(subject,attempt),repairId=str(repair.id),bindingId=str(binding.id),
        grantId=str(grant.id),approvalId=str(approval.id),preparedId=str(prepared.id),parentTaskId=str(parent.id),invocationId=str(attempt.invocation_id),
        admissionId=str(admitted.id),conversationId=str(child.conversation_id),originalBindingId=str(original_work.id),
        originalProjectionId=str(original.id),capabilityRef=grant.payload['capabilityRef'],providerRef=grant.payload['providerRef'],
        registrationRevision=grant.payload['registrationRevision'],grantDigest=grant.grant_digest,
        reservationDigest=attempt.request_digest,rootPolicyDigest=digest('policy',policy),repairMetadataDigest=immutable,
        accountingDigest=accounting_digest(attempt,root),originalHistoryDigest=history_digest(segment,events),
        parentHistoryDigest=digest('verification',dict(segments=[metadata(s) for s in segments],events=[metadata(e) for e in parent_events])))


class ProductionRepairReceiptSession(ReceiptSession):
    models=frozenset({Admission,AgentEffectReceipt,AgentRepairRoot,BudgetRoot,PublicEvent,Registration,RegisteredResourceSchema,
        RepairAdmission,RepairApproval,RepairGrant,RepairPrepared,RepairReceiptProjection,RepairWorkBinding,
        ReviewedEffectProvider,Segment,Task,TaskControl,WorkAttempt})
    mutable={BudgetRoot:frozenset({'state','version'}),Task:frozenset({'state','version'})}
    append=frozenset({RepairReceiptProjection})

    def __init__(self,session,capsule,*,readonly=False):
        super().__init__(session,capsule,readonly=True if capsule['handle']['state']=='RESERVED' else readonly)
        self._capsule=deepcopy(capsule)

    def _condition(self,model):
        c=self._capsule;h=c['handle'];subject=h['subject']
        if model in {Registration,RegisteredResourceSchema,ReviewedEffectProvider}:
            version='revision' if model is Registration else 'registration_revision'
            values=[model.installation_id==UUID(subject['installationId']),model.application_id==UUID(subject['applicationId']),
                getattr(model,version)==c['registrationRevision']]
            if model is not Registration:values.append(model.capability_ref==c['capabilityRef'])
            return values
        if model is WorkAttempt:return [*scoped(model,subject),model.id.in_([UUID(h['id']),UUID(c['originalBindingId'])])]
        if model in {Task,TaskControl,Segment}:
            field='id' if model is Task else 'task_id'
            return [*scoped(model,subject),getattr(model,field).in_([UUID(h['taskId']),UUID(c['parentTaskId'])])]
        if model is PublicEvent:
            # ReceiptSession deliberately rejects subquery-table access. Pin
            # event selection to the two immutable segment inventories instead.
            ids=[s.id for s in self.scalars(select(Segment))]
            return [*scoped(model,subject),model.segment_id.in_(ids)]
        field,ident={BudgetRoot:('id',h['rootId']),Admission:('id',c['admissionId']),
            AgentRepairRoot:('root_id',h['rootId']),AgentEffectReceipt:('id',c['originalProjectionId']),
            RepairAdmission:('id',c['repairId']),RepairApproval:('id',c['approvalId']),RepairGrant:('id',c['grantId']),
            RepairPrepared:('id',c['preparedId']),RepairWorkBinding:('id',c['bindingId']),
            RepairReceiptProjection:('binding_id',c['bindingId'])}[model]
        return [*scoped(model,subject),getattr(model,field)==UUID(ident)]

    def verify_capsule(self):
        c=self._capsule
        if source_capsule(self,c['handle']['id'])!={k:v for k,v in c.items() if k not in PROVIDER_FIELDS}:
            raise OwnershipError('Original production repair metadata/accounting/history changed')

    def add(self,row):
        c=self._capsule
        if (type(row) is not RepairReceiptProjection or str(row.binding_id)!=c['bindingId']
                or row.provider_binding_digest!=c['providerBindingDigest']):raise OSErrorCode('PROFILE_DISABLED')
        super().add(row)


class ProductionRepairReceiptStore(ProductionReceiptStore):
    """Reuse signed authentication/short transactions with the repair scope."""
    session_type=ProductionRepairReceiptSession
