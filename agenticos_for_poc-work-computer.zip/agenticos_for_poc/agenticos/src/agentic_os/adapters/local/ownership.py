"""Authenticated local installation manifest, independent of any host checkout."""
import hashlib
import hmac
import os
from pathlib import Path
import re
import secrets
from uuid import UUID, uuid4

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from .files import OwnershipError, private_directory, private_read, private_write, check_private,private_owner

COMPONENTS = ("control", "retrieval", "knowledge", "temporal", "visibility", "core")
POC_PROFILE = 'poc-rds-exact/1'
POC_COMPONENTS = ('control', 'retrieval', 'knowledge')


def create_root(root: Path, *, docker_endpoint: str, profile: str = "test", installation_id: str | None = None,
                disposition: str = "active-retained") -> dict:
    from .retention import create_ledger, DISPOSITIONS
    if disposition not in DISPOSITIONS:
        raise OwnershipError("Unknown fixture disposition")
    if profile not in {"test",POC_PROFILE} or not root.is_absolute() or root.exists() or root.is_symlink():
        raise OwnershipError("Test installation requires a new explicit private directory")
    validate_docker_endpoint(docker_endpoint)
    if installation_id is not None:
        try:
            if type(installation_id) is not str or str(UUID(installation_id)) != installation_id:
                raise ValueError()
        except (ValueError, AttributeError, TypeError):
            raise OwnershipError("Invalid recovery installation identity") from None
    # Parent belongs to the caller; only this new leaf and its descendants are adopted.
    root = root.resolve()
    private_directory(root)
    for name in ["home", "docker-client", "keys", "artifacts", "backups"]:
        private_directory(root / name)
    private_write(root / "owner.key", secrets.token_bytes(32))
    ident = uuid4().hex[:12]
    installation_id=installation_id or str(uuid4())
    components=POC_COMPONENTS if profile==POC_PROFILE else COMPONENTS
    database_prefix=UUID(installation_id).hex if profile==POC_PROFILE else ident
    result = {"version": 1, "profile": profile, "ownerUid": os.getuid(), "root": str(root),
              "installationId": installation_id, "runId": ident, "project": "aos-" + ident,
              "dockerEndpoint": docker_endpoint, "postgres": None,
              "databases": {name: {"name": "aos_" + database_prefix + "_" + name,
                  "migrator": "aos_" + database_prefix + "_" + name + "_m",
                  "runtime": "aos_" + database_prefix + "_" + name + "_r",
                  "migratorPassword": secrets.token_hex(24), "runtimePassword": secrets.token_hex(24)}
                  for name in components}, "bootstrapPassword": secrets.token_hex(24)}
    save_manifest(root, result)
    create_ledger(root / "manifest.json", disposition)
    return result


def validate_docker_endpoint(endpoint: str) -> None:
    if not isinstance(endpoint, str) or not endpoint.startswith("unix:///"):
        raise OwnershipError("Only an explicit local Docker Unix socket is supported")
    path = Path(endpoint.removeprefix("unix://"))
    if not path.is_absolute() or ".." in path.parts:
        raise OwnershipError("Invalid local Docker socket")


def save_manifest(root: Path, value: dict) -> None:
    validate_manifest_shape(root, value)
    body = canonical_bytes(value)
    key = private_read(root / "owner.key", 32)
    if len(key) != 32:
        raise OwnershipError("Invalid ownership key")
    envelope = {"manifest": value, "signature": hmac.digest(key, body, "sha256").hex()}
    private_write(root / "manifest.json", canonical_bytes(envelope), replace=True)


def load_manifest(path: Path) -> dict:
    if path.name != "manifest.json" or not path.is_absolute():
        raise OwnershipError("Explicit owned manifest.json required")
    root = path.parent
    check_private(root, directory=True)
    envelope = parse_canonical_json(private_read(path))
    if type(envelope) is not dict or set(envelope) != {"manifest", "signature"}:
        raise OwnershipError("Malformed ownership envelope")
    key = private_read(root / "owner.key", 32)
    if len(key) != 32:
        raise OwnershipError("Invalid ownership key")
    expected = hmac.digest(key, canonical_bytes(envelope["manifest"]), "sha256").hex()
    if type(envelope["signature"]) is not str or not hmac.compare_digest(expected, envelope["signature"]):
        raise OwnershipError("Ownership manifest signature mismatch")
    validate_manifest_shape(root, envelope["manifest"])
    return envelope["manifest"]


def validate_manifest_shape(root: Path, value: dict) -> None:
    if type(value) is dict and value.get('version')==2:
        _validate_aws_identity(root,value)
        return
    required = {"version", "profile", "ownerUid", "root", "installationId", "runId", "project",
                "dockerEndpoint", "postgres", "databases", "bootstrapPassword"}
    if (type(value) is not dict or set(value) != required or type(value["version"]) is not int
            or value["version"] != 1 or value["profile"] not in {"test",POC_PROFILE}):
        raise OwnershipError("Unknown manifest profile or fields")
    check_private(root, directory=True)
    if (root.resolve() != root or value["root"] != str(root) or type(value["ownerUid"]) is not int
            or value["ownerUid"] != os.getuid()):
        raise OwnershipError("Foreign installation directory/owner")
    if not matches(r"[a-f0-9]{12}", value["runId"]) or value["project"] != "aos-" + value["runId"]:
        raise OwnershipError("Invalid installation resource prefix")
    try:
        UUID(value["installationId"])
    except (ValueError, TypeError, AttributeError):
        raise OwnershipError("Invalid installation identity") from None
    validate_docker_endpoint(value["dockerEndpoint"])
    components=POC_COMPONENTS if value['profile']==POC_PROFILE else COMPONENTS
    if type(value["databases"]) is not dict or set(value["databases"]) != set(components):
        raise OwnershipError("Unknown component database")
    for name, database in value["databases"].items():
        if type(database) is not dict or set(database) != {"name", "migrator", "runtime", "migratorPassword", "runtimePassword"}:
            raise OwnershipError("Unknown database fields")
        prefix = "aos_" + (UUID(value['installationId']).hex if value['profile']==POC_PROFILE else value["runId"]) + "_" + name
        if (database["name"] != prefix or database["migrator"] != prefix + "_m"
                or database["runtime"] != prefix + "_r"):
            raise OwnershipError("Foreign database/role")
        for field in ["migratorPassword", "runtimePassword"]:
            if not matches(r"[a-f0-9]{48}", database[field]):
                raise OwnershipError("Malformed component credential")
    if not matches(r"[a-f0-9]{48}", value["bootstrapPassword"]):
        raise OwnershipError("Malformed installation credential")
    if value["postgres"] is not None:
        postgres = value["postgres"]
        if type(postgres) is not dict or set(postgres) != {"container", "volume", "image", "imageId", "host", "port"}:
            raise OwnershipError("Unknown PostgreSQL binding")
        if (not matches(r"[a-f0-9]{64}", postgres["container"])
            or not matches(r"sha256:[a-f0-9]{64}", postgres["imageId"])
            or type(postgres["image"]) is not str
            or postgres["volume"] != value["project"] + "-postgres"
            or postgres["host"] != "127.0.0.1" or type(postgres["port"]) is not int
            or not 1024 <= postgres["port"] <= 65535):
            raise OwnershipError("Foreign or nonlocal PostgreSQL target")


def matches(pattern: str, value) -> bool:
    return type(value) is str and re.fullmatch(pattern, value) is not None


def _validate_aws_identity(root,value):
    """Signed provider identity, with no implied owned local storage."""
    fields={'version','profile','ownerUid','root','installationId','runId','project',
        'dockerEndpoint','postgres','databases'}
    if (set(value)!=fields or type(value['version']) is not int or value['version']!=2
            or value['profile']!='aws-eks/1' or value['dockerEndpoint'] is not None
            or value['postgres'] is not None or type(value['databases']) is not dict or value['databases']):
        raise OwnershipError('Unknown AWS installation identity or local resource adoption')
    check_private(root,directory=True)
    if (root.resolve()!=root or value['root']!=str(root) or type(value['ownerUid']) is not int
            or value['ownerUid']!=private_owner(root) or not matches('[a-f0-9]{12}',value['runId'])
            or value['project']!='aos-'+value['runId']):
        raise OwnershipError('Foreign AWS installation directory or identity')
    try:
        if type(value['installationId']) is not str or str(UUID(value['installationId']))!=value['installationId']:raise ValueError()
    except (ValueError,TypeError,AttributeError):raise OwnershipError('Invalid AWS installation identity') from None
