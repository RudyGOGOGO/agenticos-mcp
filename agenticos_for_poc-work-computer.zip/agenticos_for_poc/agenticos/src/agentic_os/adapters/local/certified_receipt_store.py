"""Current signed release port for original admitted receipt metadata only."""
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path

from sqlalchemy import create_engine,text
from sqlalchemy.orm import Session
from sqlalchemy.pool import QueuePool

from .files import OwnershipError
from .held_receipt_store import ReceiptSession
from .resources import file_lock
from .target import connect_owned,check_owned_connection
from .ownership import load_manifest


class CertifiedReceiptStore:
    """Construct authentication from the exact current operator-selected capsule.

    No arbitrary callback, private keys, source service or execution port is
    supplied by the caller. UNKNOWN accounting and closed history stay pinned.
    """
    def __init__(self,path,token,*,expected_generation,attempt_id):
        from .recovery_ready_receipts import load_ready_capsules
        self.__path=Path(path);self.__token=token;self.__generation=expected_generation
        self.__manifest=load_manifest(self.__path);self.__closed=False
        self.__admitted,self.__capsules=load_ready_capsules(self.__path,token,expected_generation)
        from .artifacts import checked_id
        from agentic_os.errors import OSErrorCode
        checked_id(attempt_id)
        selected=next((v for v in self.__capsules['effects'] if v['handle']['id']==attempt_id),None)
        if selected is None:raise OSErrorCode('DENIED')
        self.__capsule=deepcopy(selected)
        # One physical connection belongs only to this finite observation. Every
        # transaction still authenticates current release/capsules and actual
        # SQL identity/privileges; no session survives a provider await.
        self.__engine=create_engine('postgresql+psycopg://',poolclass=QueuePool,
            pool_size=1,max_overflow=0,pool_timeout=2,
            creator=lambda:connect_owned(self.__path,role='migrator'))

    @property
    def capsule(self):return deepcopy(self.__capsule)

    def authenticate(self):
        from .recovery_ready_receipts import load_ready_capsules
        if self.__closed or load_manifest(self.__path)!=self.__manifest:
            raise OwnershipError('Current original receipt target changed or closed')
        admitted,capsules=load_ready_capsules(self.__path,self.__token,self.__generation)
        if admitted!=self.__admitted or capsules!=self.__capsules:
            raise OwnershipError('Current original receipt selection changed')

    @contextmanager
    def transaction(self):
        with file_lock(self.__path.parent/'recovery-gate.lock',timeout=2,shared=True):
            self.authenticate()
            with Session(self.__engine,autoflush=False,expire_on_commit=False) as session:
                with session.begin():
                    session.execute(text("SET LOCAL lock_timeout='2s'"))
                    session.execute(text("SET LOCAL statement_timeout='3s'"))
                    self.__check_session(session)
                    port=ReceiptSession(session,self.__capsule)
                    port.verify_capsule()
                    yield port
                    port.flush();port.verify_capsule();self.authenticate()
                    self.__check_session(session)

    def __check_session(self,session):
        connection=session.connection()
        try:
            check_owned_connection(connection.connection.driver_connection,
                self.__manifest['databases']['control'],role='migrator')
        except OwnershipError:
            connection.invalidate();raise

    def close(self):
        self.__closed=True;self.__engine.dispose()
