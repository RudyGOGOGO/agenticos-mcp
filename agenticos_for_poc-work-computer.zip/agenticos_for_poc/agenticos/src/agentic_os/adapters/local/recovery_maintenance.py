"""Explicit parked revalidation with immutable certificate ancestry.

No original execution, accounting, deadline or privacy row plan is rewritten.
Raw workflow termination appends only a truthful terminal event. A selected
artifact may replace code only after Park; failure keeps the installation parked.
"""
import asyncio
from datetime import timedelta
from io import BytesIO,StringIO
from pathlib import Path
import zipfile

from temporalio.api.common.v1 import WorkflowExecution
from temporalio.api.workflowservice.v1 import TerminateWorkflowExecutionRequest

from agentic_os.contracts.canonical import canonical_bytes
from agentic_os.identity.context import utcnow,iso,timestamp
from . import recovery_gate as gate
from .artifacts import checked_id
from .files import OwnershipError,check_private,private_read,private_write
from .operator import verify_operator
from .resources import canonical_path,ensure_private,file_lock,read_signed,write_signed
from .recovery_key_continuity import BINDING,sha,digest

DIRECTORY='recovery-maintenance'
FILE='recovery-maintenance.json'
PROFILE='parked-runtime-maintenance/1'
RECERT='current-runtime-recertification/1'
MANAGED_PROFILE='parked-managed-runtime-maintenance/1'
MANAGED_RECERT='current-managed-runtime-recertification/1'
CLOUD_ROLLOVER='managed-cloud-transport/1'
SERVICE_ROLLOVER='managed-sql-service-credentials/1'
SERVICE_CONSUMERS='managed-selected-service-consumers/1'
OPERATOR_ROLLOVER='managed-operator-credential/1'
SUPPORTED_PROFILES=('parked-runtime-maintenance/1','parked-managed-runtime-maintenance/1','managed-cloud-transport/1','managed-sql-service-credentials/1','managed-selected-service-consumers/1','managed-operator-credential/1')
RETIREMENT=('retiredSessions','retiredChallenges','retiredExecutions')
INTENT_FIELDS={'profile',*BINDING,'commandId','priorGeneration','parkGeneration','nextGeneration',
    'priorCertificateDigest','priorGate','selectedArtifactDigest','selectedReleaseDigest',
    'privacy','catalogDigest','controlPins','retirement','serviceDigest','original','catalog','state'}
PROOF_FIELDS={'profile',*BINDING,'commandId','generation','priorCertificateDigest','certificateDigest',
    'intentDigest','privacyDigest','catalogDigest','controlPinsDigest','keyPinsDigest','catalog',
    'originalHistoryPreserved','unknownUsageHeld','deadlinesUnchanged'}


def _managed(path):
    from .ownership import load_manifest
    return load_manifest(Path(path))['profile']=='aws-eks/1'


def _fields(fields,path):
    if not _managed(path):return set(fields)
    from .restoration_binding import placed_fields
    return placed_fields(fields,Path(path))


def _intent_fields(path):
    return _fields(INTENT_FIELDS,path)|({'selectedContentDigest'} if _managed(path) else set())


def _profile(path):return MANAGED_PROFILE if _managed(path) else PROFILE


def _release_fields(path):
    from .recovery_ready import FIELDS
    return _fields(FIELDS,path)|({'contentDigest'} if _managed(path) else set())


def _reader_profiles(package,resource):
    import ast
    source=package.joinpath(resource).read_bytes()
    if len(source)>1024**2:raise OwnershipError('Selected maintenance reader exceeds bounds')
    try:
        declarations=[ast.literal_eval(node.value) for node in ast.parse(source).body if isinstance(node,ast.Assign)
            and any(isinstance(target,ast.Name) and target.id=='SUPPORTED_PROFILES' for target in node.targets)]
    except (ValueError,TypeError,SyntaxError):raise OwnershipError('Selected maintenance reader declaration malformed') from None
    if len(declarations)>1:raise OwnershipError('Selected maintenance reader declarations differ')
    supported=declarations[0] if declarations else ()
    if (type(supported) is not tuple or len(supported)>16
            or any(type(profile) is not str or not 1<=len(profile)<=128 for profile in supported)
            or len(set(supported))!=len(supported)):
        raise OwnershipError('Selected maintenance profiles unavailable')
    return supported


def _key_reader(path,selected):
    if not _managed(path):return
    from .recovery_key_continuity import plane
    required=set()
    for name in [name for purpose in ('history','knowledge') for name in plane(purpose)[:2]]:
        file=Path(path).parent/name
        if file.exists() or file.is_symlink():
            value=read_signed(file,Path(path).parent/'owner.key',maximum=32768)
            if type(value) is not dict or type(value.get('profile')) is not str:raise OwnershipError('Managed key reader profile unavailable')
            required.add(value['profile'])
    if not required<=set(selected.get('keyProfiles',())):
        raise OwnershipError('Selected artifact cannot read managed key continuity; use supported code or forward recovery')


def artifact_pin(artifact):
    """Hash an independent wheel and its public restoration/contract programs."""
    raw=private_read(canonical_path(Path(artifact)),64*1024**2)
    import hashlib
    with zipfile.ZipFile(BytesIO(raw)) as wheel:
        members=wheel.infolist();names=[v.filename for v in members]
        if (len(members)>4096 or len(names)!=len(set(names)) or sum(v.file_size for v in members)>128*1024**2
                or any(Path(n).is_absolute() or '..' in Path(n).parts for n in names)
                or any((v.external_attr>>16)&0o170000==0o120000 for v in members)):
            raise OwnershipError('Selected artifact inventory differs')
        package=zipfile.Path(wheel,'agentic_os/')
        from .recovery_ready import _release_digest
        from .recovery_runtime_checkpoint import release_programs
        from agentic_os.distribution import member_inventory
        content=sha(member_inventory({name.removeprefix('agentic_os/'):wheel.read(name) for name in names
            if name.startswith('agentic_os/') and not name.endswith('/') and not name.endswith('.pyc') and '/__pycache__/' not in name}))
        return dict(artifactDigest=hashlib.sha256(raw).hexdigest(),releaseDigest=_release_digest(package),
            programs=release_programs(package),contentDigest=content,
            supportedProfiles=_reader_profiles(package,'adapters/local/recovery_maintenance.py'),
            keyProfiles=_reader_profiles(package,'adapters/local/recovery_key_continuity.py'))


def _operation(path,command):
    checked_id(command);return Path(path).parent/DIRECTORY/command


def _intent(path,command):
    root=Path(path).parent;op=_operation(path,command)
    check_private(op,directory=True)
    value=read_signed(op/'intent.json',root/'owner.key',maximum=2*1024**2)
    selections={'cloudRollover','serviceRollover','operatorRollover'}&set(value) if type(value) is dict else set()
    if len(selections)>1:raise OwnershipError('One exact managed configuration selection required')
    selection=next(iter(selections),None)
    operator_fields={'operatorConfiguration'} if type(value) is dict and 'operatorConfiguration' in value else set()
    if (type(value) is not dict or set(value)!=_intent_fields(path)|selections|operator_fields or value['profile']!=_profile(path)
            or value['commandId']!=command or value['state'] not in {'PREPARING','PARKED'}
            or any(type(value[k]) is not int for k in ('priorGeneration','parkGeneration','nextGeneration'))
            or value['parkGeneration']!=value['priorGeneration']+1
            or value['nextGeneration']!=value['priorGeneration']+2
            or any(not digest(value[k]) for k in ('priorCertificateDigest','selectedArtifactDigest',
                'selectedReleaseDigest','catalogDigest','serviceDigest'))
            or type(value['priorGate']) is not dict or value['priorGate'].get('mode')!='READY'
            or value['priorGate'].get('generation')!=value['priorGeneration']
            or type(value['retirement']) is not dict or set(value['retirement'])!=set(RETIREMENT)):
        raise OwnershipError('Maintenance intent unavailable')
    if selection:
        if not _managed(path):raise OwnershipError('Configuration rollover requires managed placement')
        _configuration_selection(path,value[selection],selection,operators=value.get('operatorConfiguration'))
    if operator_fields:
        from agentic_os.adapters.aws.operator_rotation import checked_configuration
        if not _managed(path):raise OwnershipError('Operator configuration requires managed placement')
        checked_configuration(path,value['operatorConfiguration'])
    if selection=='operatorRollover':
        from agentic_os.adapters.aws.operator_rotation import intent_stage
        selected=value[selection]
        if value.get('operatorConfiguration')!=selected['configuration']:raise OwnershipError('Operator selection context differs')
        prior=read_signed(op/'prior-ready.json',root/'owner.key',maximum=1024**2)
        intent_stage(path,command,operator_intent(value),prior,prior_configuration=selected['previous'])
    if _managed(path) and not digest(value['selectedContentDigest']):raise OwnershipError('Selected managed content unavailable')
    from .recovery_ready import _identities
    for kind in RETIREMENT[:2]:_identities(value['retirement'][kind])
    _catalog_rows(value['catalog'])
    return value


def _cursor(path):
    root=Path(path).parent
    cursor=read_signed(root/FILE,root/'owner.key',maximum=32768)
    if type(cursor) is not dict or set(cursor)!={'profile','commandId'} or cursor['profile']!=_profile(path):
        raise OwnershipError('Maintenance selection unavailable')
    checked_id(cursor['commandId']);return cursor


def checked_maintenance_state(path,value):
    marker=Path(path).parent/FILE
    if marker.exists() or marker.is_symlink():
        intent=_intent(path,_cursor(path)['commandId'])
        if intent['nextGeneration']!=value['generation']:
            raise OwnershipError('Maintenance requires explicit publication')
        entries=_ancestry(path,value)
        operators=entries[-1][2].get('operatorConfiguration')
        if operators is not None:
            from agentic_os.adapters.aws import operator_rotation as credentials
            from .operator import bound_digest
            actual=credentials.state(path)
            if (actual!=operators['current'] or bound_digest(value['installationId'],private_read(Path(path).parent/'operator.key',32))
                    !=actual['record']['operatorDigest']):raise OwnershipError('Current restored operator authority differs')


def prior_for_maintenance(path,current,intent,published):
    root=Path(path).parent
    checked=_intent(path,_cursor(path)['commandId']);actual=gate.state(path)
    if (checked!=intent or current!=intent['priorGate'] or actual['mode']!='PARKED'
            or actual['generation']!=intent['parkGeneration']):
        raise OwnershipError('Maintenance prior metadata unavailable')
    op=_operation(path,intent['commandId'])
    prior=read_signed(op/'prior-ready.json',root/'owner.key',maximum=1024**2)
    if (type(prior) is not dict or sha(prior)!=intent['priorCertificateDigest']
            or any(prior.get(k)!=intent[k] for k in _fields(BINDING,path))):
        raise OwnershipError('Maintenance prior certificate differs')
    if published!=prior:
        if (published!=read_signed(op/'ready.json',root/'owner.key',maximum=1024**2)
                or published['generation']!=intent['nextGeneration']):
            raise OwnershipError('Maintenance pending publication differs')
        _ancestry(path,published)
    return prior


def _catalog_rows(rows):
    from .recovery_ready import _identities
    fields={'workflowId','runId','firstRunId','workflowType','taskQueue','status','events',
        'historyDigest','executionTimeoutSeconds'}
    if type(rows) is not list or len(rows)>128:
        raise OwnershipError('Maintenance workflow inventory unavailable')
    seen=set()
    for row in rows:
        if (type(row) is not dict or set(row)!=fields or not digest(row['historyDigest'])
                or any(type(row[k]) is not int for k in ('status','events','executionTimeoutSeconds'))
                or not 1<=row['events']<=4096 or not 1<=row['status']<=7
                or row['executionTimeoutSeconds']<0 or type(row['workflowId']) is not str
                or type(row['workflowType']) is not str or type(row['taskQueue']) is not str):
            raise OwnershipError('Maintenance workflow record unavailable')
        _identities(sorted(set((row['runId'],row['firstRunId']))))
        key=(row['workflowId'],row['runId'])
        if key in seen:raise OwnershipError('Maintenance workflow identity repeats')
        seen.add(key)


def _ancestry(path,value):
    """Closed signed ancestry is metadata only, never old execution authority."""
    from .recovery_ready import PROFILE as RELEASE_PROFILE,MANAGED_PROFILE as MANAGED_RELEASE,FILE as READY_FILE,_identities
    fields=_release_fields(path);binding=_fields(BINDING,path);managed=_managed(path)
    root=Path(path).parent;directory=root/DIRECTORY
    if not directory.exists():raise OwnershipError('Maintenance ancestry unavailable')
    check_private(directory,directory=True);members=list(directory.iterdir())
    if not 1<=len(members)<=8:raise OwnershipError('Maintenance ancestry envelope exceeded')
    entries=[]
    for member in members:
        checked_id(member.name);check_private(member,directory=True)
        if managed and not (member/'intent.json').exists():
            # An interrupted, authenticated credential stage grants no
            # publication. Exact metadata permits only its original resume;
            # ordinary certificate inventory still refuses incomplete work.
            from agentic_os.adapters.aws import operator_rotation as credentials
            partial=set(p.name for p in member.iterdir())
            if partial in (set(),{'prior-ready.json'}):
                if partial and read_signed(member/'prior-ready.json',root/'owner.key',maximum=1024**2)!=read_signed(root/READY_FILE,root/'owner.key',maximum=1024**2):
                    raise OwnershipError('Original interrupted maintenance release differs')
                continue
            if partial!={credentials.STAGE_FILE,'prior-ready.json'}:
                raise OwnershipError('Incomplete managed maintenance stage unavailable')
            staged=credentials.checked_stage(path,read_signed(member/credentials.STAGE_FILE,root/'owner.key',maximum=32768))
            prior=read_signed(member/'prior-ready.json',root/'owner.key',maximum=1024**2)
            if (staged['commandId']!=member.name or staged['priorGeneration']!=prior['generation']
                    or staged['priorCertificateDigest']!=sha(prior)
                    or read_signed(root/READY_FILE,root/'owner.key',maximum=1024**2)!=prior):
                raise OwnershipError('Original interrupted operator stage differs')
            continue
        intent=_intent(path,member.name)
        prior=read_signed(member/'prior-ready.json',root/'owner.key',maximum=1024**2)
        if (type(prior) is not dict or set(prior)!=fields or prior['profile']!=(MANAGED_RELEASE if managed else RELEASE_PROFILE)
                or any(prior[k]!=value[k] or intent[k]!=value[k] for k in binding)
                or prior['knownKeys']!=value['knownKeys'] or prior['proofs']!=value['proofs']
                or prior['heldGeneration']!=value['heldGeneration']
                or sha(prior)!=intent['priorCertificateDigest'] or prior['generation']!=intent['priorGeneration']):
            raise OwnershipError('Maintenance prior release differs')
        issued,expires=timestamp(prior['issuedAt']),timestamp(prior['expiresAt'])
        if not issued<expires<=issued+timedelta(hours=24):raise OwnershipError('Maintenance prior lifetime differs')
        for kind in RETIREMENT[:2]:_identities(prior[kind])
        proof_path=member/'proof.json'
        if not proof_path.exists():
            if intent['priorGeneration']<value['generation']:
                raise OwnershipError('Maintenance publication proof unavailable')
            continue  # A newly parked operation cannot certify any later generation.
        proof=read_signed(proof_path,root/'owner.key',maximum=2*1024**2)
        ready=read_signed(member/'ready.json',root/'owner.key',maximum=1024**2)
        if (type(proof) is not dict or set(proof)!=_fields(PROOF_FIELDS,path) or proof['profile']!=(MANAGED_RECERT if managed else RECERT)
                or any(proof[k]!=value[k] for k in binding) or proof['commandId']!=member.name
                or proof['generation']!=intent['nextGeneration'] or type(proof['generation']) is not int
                or proof['priorCertificateDigest']!=sha(prior) or proof['certificateDigest']!=sha(ready)
                or proof['intentDigest']!=sha(intent) or intent['state']!='PARKED'
                or proof['privacyDigest']!=sha(intent['privacy']) or proof['catalogDigest']!=intent['catalogDigest']
                or proof['controlPinsDigest']!=sha(intent['controlPins']) or not digest(proof['keyPinsDigest'])
                or any(proof[k] is not True for k in ('originalHistoryPreserved','unknownUsageHeld','deadlinesUnchanged'))
                or type(ready) is not dict or set(ready)!=fields
                or any(ready[k]!=prior[k] for k in fields-set(RETIREMENT)-{
                    'generation','releaseDigest','contentDigest','issuedAt','expiresAt'})
                or ready['generation']!=intent['nextGeneration']
                or ready['releaseDigest']!=intent['selectedReleaseDigest']
                or managed and (not digest(prior['contentDigest']) or ready['contentDigest']!=intent['selectedContentDigest'])):
            raise OwnershipError('Maintenance publication evidence differs')
        _catalog_rows(proof['catalog'])
        from .recovery_quarantine import compatible_catalog
        compatible_catalog(intent['catalog'],proof['catalog'])
        for kind in RETIREMENT:
            expected=set(prior[kind])|set(intent['retirement'][kind])
            if kind=='retiredExecutions':expected|={v['workflowId'] for v in intent['catalog']}
            if ready[kind]!=sorted(expected):raise OwnershipError('Maintenance retirement differs')
        issued,expires=timestamp(ready['issuedAt']),timestamp(ready['expiresAt'])
        if not issued<expires<=issued+timedelta(hours=24):raise OwnershipError('Maintenance lifetime differs')
        entries.append((prior,ready,intent,proof))
    entries.sort(key=lambda e:e[0]['generation'])
    applicable=[e for e in entries if e[1]['generation']<=value['generation']]
    if (not applicable or applicable[0][0]['generation']!=value['heldGeneration']+1
            or applicable[-1][1]!=value
            or any(a[1]!=b[0] for a,b in zip(applicable,applicable[1:]))):
        raise OwnershipError('Maintenance certificate chain unavailable')
    from agentic_os.adapters.aws import managed_restore
    if managed:
        configuration=managed_restore._record(Path(path))['configuration']
        operators=None
        for _,_,intent,_ in applicable:
            key=selection_key(intent)
            if key:
                selection=_configuration_selection(path,intent[key],key,operators=intent.get('operatorConfiguration'))
                if selection['before']!=configuration:raise OwnershipError('Cloud rollover configuration ancestry differs')
                configuration=selection['after']
                if key=='operatorRollover':
                    if selection['previous']!=operators:raise OwnershipError('Operator credential ancestry differs')
                    operators=selection['configuration']
            if intent.get('operatorConfiguration')!=operators:raise OwnershipError('Published operator context differs')
    return applicable


def selection_key(value):return next((name for name in ('cloudRollover','serviceRollover','operatorRollover') if name in value),None)


def _cloud_selection(path,value):return _configuration_selection(path,value,'cloudRollover')


def _configuration_selection(path,value,key,*,operators=None):
    from agentic_os.adapters.aws.managed_restore import checked_cloud_replacement,checked_service_replacement,checked_operator_replacement
    profile,check=(CLOUD_ROLLOVER,checked_cloud_replacement) if key=='cloudRollover' else (SERVICE_ROLLOVER,checked_service_replacement)
    operator=key=='operatorRollover'
    if operator:profile,check=OPERATOR_ROLLOVER,checked_operator_replacement
    fields={'profile','before','after','beforeCloudDigest','afterCloudDigest'}|({'configuration','previous','stage'} if operator else set())
    if (type(value) is not dict or set(value)!=fields
            or value['profile']!=profile):raise OwnershipError('Exact managed Cloud rollover selection required')
    if operator:
        check(Path(path),value['before'],value['after'],value['configuration'],previous=value['previous'],metadata_only=True)
        if (type(value['stage']) is not dict or set(value['stage'])!={'stageDigest','operatorDigest'}
                or any(not digest(pin) for pin in value['stage'].values())):raise OwnershipError('Operator stage pin unavailable')
    else:check(Path(path),value['before'],value['after'],operator_configuration=operators,
        **(dict(metadata_only=True) if key=='serviceRollover' else {}))
    from agentic_os.adapters.aws.temporal import load_operator_configuration
    for name in ('before','after'):
        cloud=load_operator_configuration(Path(value[name]['cloud_configuration']))
        if sha(cloud)!=value[name+'CloudDigest']:raise OwnershipError('Reviewed Cloud document content changed')
    return value


def cloud_configuration(path,*,command=None):
    """Published certificate ancestry selects current transport; no runtime grant."""
    from agentic_os.adapters.aws import managed_restore
    from .recovery_ready import FILE as READY_FILE
    path=Path(path);original=managed_restore._record(path)['configuration']
    if not (path.parent/READY_FILE).exists():return original
    ready=read_signed(path.parent/READY_FILE,path.parent/'owner.key',maximum=1024**2)
    selected=original
    if ready['generation']!=ready['heldGeneration']+1:
        for _,_,intent,_ in _ancestry(path,ready):
            key=selection_key(intent)
            if key:selected=intent[key]['after']
    if command is not None:
        op=_operation(path,command)
        if (op/'intent.json').exists():
            intent=_intent(path,command);current=gate.state(path)
            if current['mode']=='PARKED' and current['generation']==intent['parkGeneration'] and _cursor(path)['commandId']==command:
                key=selection_key(intent)
                if key:
                    selection=_configuration_selection(path,intent[key],key,operators=intent.get('operatorConfiguration'))
                    if selection['before']!=selected and not (
                            ready['generation']==intent['nextGeneration'] and selection['after']==selected):
                        raise OwnershipError('Pending Cloud configuration ancestry differs')
                    return selection['after']
    return selected


def operator_configuration(path):
    """Current signed operator continuity only; no credential or execution grant."""
    from .recovery_ready import FILE as READY_FILE
    path=Path(path);value=read_signed(path.parent/READY_FILE,path.parent/'owner.key',maximum=1024**2)
    if value['generation']==value['heldGeneration']+1:return None
    return _ancestry(path,value)[-1][2].get('operatorConfiguration')


def operator_intent(intent):
    selected=intent['operatorRollover']
    return intent|dict(configurationDigest=sha(selected['after']),operatorConfiguration=selected['configuration'],operatorRotation=selected['stage'])


def verify_maintenance_operator(path,token,command,*,replacement_only=False):
    """A staged token is confined to its original parked operator command."""
    path=Path(path)
    identity=None
    try:identity=verify_operator(path,token)
    except OwnershipError:
        if not _managed(path):raise
    if identity is not None and (not replacement_only or not _managed(path)):return identity
    try:intent=_intent(path,command)
    except (OSError,ValueError):raise OwnershipError('Current or exact staged operator credential required') from None
    state=gate.state(path)
    if 'operatorRollover' not in intent:
        return verify_operator(path,token)
    if state['mode']=='PARKED':
        if state['generation']!=intent['parkGeneration'] or _cursor(path)['commandId']!=command:
            raise OwnershipError('Original parked operator handoff required')
    elif state['mode']!='READY' or state['generation']!=intent['nextGeneration']:
        raise OwnershipError('Current operator handoff generation differs')
    from agentic_os.adapters.aws.operator_rotation import authorize
    authorize(path,token,operator_intent(intent),prior_configuration=intent['operatorRollover']['previous'])


def _configuration_reader(path,selected):
    if not _managed(path) or not (Path(path).parent/FILE).exists():return
    from .recovery_ready import FILE as READY_FILE
    value=read_signed(Path(path).parent/READY_FILE,Path(path).parent/'owner.key',maximum=1024**2)
    if value['generation']==value['heldGeneration']+1:return
    required={intent[key]['profile'] for _,_,intent,_ in _ancestry(path,value) if (key:=selection_key(intent))}
    if SERVICE_ROLLOVER in required:required.add(SERVICE_CONSUMERS)
    missing=required-set(selected.get('supportedProfiles',()))
    if missing:raise OwnershipError('Selected artifact cannot read managed '+('operator' if OPERATOR_ROLLOVER in missing else 'Cloud' if missing=={CLOUD_ROLLOVER} else 'service')+' rollover')


def original_release(path,value):return _ancestry(path,value)[0][0]


def release_ancestors(path,value):
    if value['generation']==value['heldGeneration']+1:return {value['generation']:sha(value)}
    entries=_ancestry(path,value)
    return {v['generation']:sha(v) for entry in entries for v in entry[:2]}


def checked_recertification(path,value,archive):
    entries=_ancestry(path,value)
    if any(entry[0]['archiveDigest']!=sha(archive) for entry in entries):
        raise OwnershipError('Maintenance archive ancestry differs')


def checked_rollout_metadata(path,value,current,intent):
    """Only exact selected code while actually parked can inspect old metadata."""
    from .recovery_ready import release_digest,FILE as READY_FILE
    cursor=_cursor(path)
    checked=_intent(path,cursor['commandId'])
    actual=gate.state(path)
    if (checked!=intent or actual['mode']!='PARKED' or actual['generation']!=intent['parkGeneration']
            or current!=intent['priorGate'] or sha(value)!=intent['priorCertificateDigest']
            or read_signed(_operation(path,intent['commandId'])/'prior-ready.json',Path(path).parent/'owner.key')!=value
            or intent['selectedReleaseDigest']!=release_digest()):
        raise OwnershipError('Selected compatible rollout metadata unavailable')
    if _managed(path):
        from agentic_os.adapters.aws.readiness import _runtime_content
        if intent['selectedContentDigest']!=_runtime_content():raise OwnershipError('Selected managed rollout content differs')


def operator_archive(path,command):
    """Exact maintenance metadata for a scoped operator, never a runtime grant."""
    checked_id(command)
    from .recovery_ready import certificate,admitted_archive,_release_metadata
    current=gate.state(path)
    if current['mode']=='READY':
        op=_operation(path,command)
        from agentic_os.adapters.aws.operator_rotation import STAGE_FILE
        if op.exists() and not (op/'intent.json').exists() and set(p.name for p in op.iterdir())<={STAGE_FILE,'prior-ready.json'}:
            _release_metadata(path)  # Exact staged resume; not a runtime certificate.
        else:certificate(path)
    elif current['mode']=='PARKED':
        if _cursor(path)['commandId']!=command:raise OwnershipError('Managed maintenance command differs')
        intent=_intent(path,command)
        if current['generation']!=intent['parkGeneration']:raise OwnershipError('Managed maintenance generation differs')
        _release_metadata(path,current=intent['priorGate'],maintenance=intent)
    else:raise OwnershipError('Managed maintenance requires an exact Ready or parked operation')
    return admitted_archive(path)


def _catalog(path,archive):
    from .recovery_operator import migrate,connect_owned
    from .coordinated_backup import component_watermark,selected_components
    from .recovery_runtime_checkpoint import assert_release_compatible
    from .restoration_binding import relocation_metadata
    assert_release_compatible(archive['receipt']['runtimeCheckpoint'])
    from .recovery_temporal import FILE as TEMPORAL_FILE
    inspected=read_signed(Path(path).parent/TEMPORAL_FILE,Path(path).parent/'owner.key',maximum=2*1024**2)
    versions={}
    for component in sorted(selected_components(archive['receipt']['profile'])):
        if component in {'control','retrieval','knowledge'}:
            migrate(path,component=component,check_only=True,diagnostic_stream=StringIO())
        options={} if not _managed(path) else dict(connect=lambda component=component:connect_owned(path,component=component,role='migrator'))
        actual=component_watermark(path,component,**options)['schemaVersions']
        expected=archive['receipt']['components'][component]['after']['schemaVersions']
        if component in {'temporal','visibility'}:
            plan=inspected['schemaRelocations'][component]
            if expected.get('schema_version')!=[plan['before']]:raise OwnershipError('Original schema lineage differs')
            expected=expected|dict(schema_version=[plan['after']])
        if actual!=expected:raise OwnershipError('Maintenance component schema differs')
        versions[component]=actual
    return sha(versions)


def _service(path,archive,connection):
    """Exact existing service lineage; never infer a local fallback for Cloud."""
    from .coordinated_backup import CLOUD_PROFILE,MANAGED_PROFILE as MANAGED_ARCHIVE
    from .recovery_lineage import load_lineage,FILE as LINEAGE_FILE
    cloud=archive['receipt']['profile'] in {CLOUD_PROFILE,MANAGED_ARCHIVE}
    if cloud!=(connection is not None):raise OwnershipError('Explicit matching maintenance transport required')
    if cloud:
        from agentic_os.adapters.aws.temporal import recovery_binding
        from agentic_os.adapters.temporal.connection import TemporalConnection
        if type(connection) is not TemporalConnection or connection.installation.root!=Path(path).parent:
            raise OwnershipError('Maintenance Cloud installation differs')
        value=read_signed(Path(path).parent/LINEAGE_FILE,Path(path).parent/'owner.key',maximum=128*1024)
        if type(value) is not dict or type(value.get('original')) is not dict:
            raise OwnershipError('Maintenance Cloud lineage unavailable')
        binding=recovery_binding(connection,value['original'])
    else:
        from .temporal import inspect_service
        binding,_=inspect_service(path,recovered_profile=True)
    lineage_binding=binding
    if cloud and _managed(path):
        # Original namespace/history lineage remains immutable across a reviewed
        # transport-only CA change. recovery_binding checked current authority.
        from agentic_os.adapters.aws.managed_restore import _record
        from agentic_os.adapters.aws import temporal as cloud_temporal
        original_cloud=cloud_temporal.load_operator_configuration(Path(_record(Path(path))['configuration']['cloud_configuration']))
        lineage_binding=binding|dict(serverCASha256=original_cloud['server_ca_sha256'])
    value=load_lineage(path,lineage_binding)
    if value['receiptDigest']!=archive['receiptDigest']:raise OwnershipError('Maintenance archive lineage differs')
    return binding,value['original']


def _keys(path,value,archive):
    from .recovery_key_continuity import effective_keys,selector
    from .recovery_history import pinned_keys
    known=effective_keys(path,value);pinned_keys(Path(path).parent/'keys',known);selector(path,value)
    kb=effective_keys(path,value,'knowledge')
    if kb:
        pinned_keys(Path(path).parent/'protected-knowledge/keys',kb)
        selector(path,value,purpose='knowledge')
    return sha(dict(root=known,knowledge=kb))


async def prepare(path,token,*,expected_generation,command_id,artifact,deletion_root,controls_root,connection=None,replacement=None,replacement_token=None):
    if replacement_token is not None:
        if replacement is None or not _managed(path) or connection is None:
            raise OwnershipError('Operator handoff requires reviewed managed configuration and transport')
        return await _prepare_operator(path,token,replacement_token,replacement,expected_generation=expected_generation,
            command_id=command_id,artifact=artifact,deletion_root=deletion_root,controls_root=controls_root,connection=connection)
    if replacement is None:
        return await _prepare(path,token,expected_generation=expected_generation,command_id=command_id,artifact=artifact,
            deletion_root=deletion_root,controls_root=controls_root,connection=connection)
    if not _managed(path) or connection is None:raise OwnershipError('Reviewed Cloud rollover requires managed operator transport')
    selected=artifact_pin(artifact)
    from agentic_os.adapters.aws import managed_restore,temporal
    current=cloud_configuration(Path(path));operators=operator_configuration(Path(path));service=replacement.get('stores')!=current['stores']
    profile,key,check=(SERVICE_ROLLOVER,'serviceRollover',managed_restore.checked_service_replacement) if service else (
        CLOUD_ROLLOVER,'cloudRollover',managed_restore.checked_cloud_replacement)
    required={profile,SERVICE_CONSUMERS} if service else {profile}
    if not required<=set(selected['supportedProfiles']):raise OwnershipError('Selected artifact cannot read managed configuration rollover')
    selection=dict(profile=profile,before=current,after=check(path,current,replacement,operator_configuration=operators),
        beforeCloudDigest=sha(temporal.load_operator_configuration(Path(current['cloud_configuration']))),
        afterCloudDigest=sha(temporal.load_operator_configuration(Path(replacement['cloud_configuration']))))
    if service:
        return await _prepare(path,token,expected_generation=expected_generation,command_id=command_id,artifact=artifact,
            deletion_root=deletion_root,controls_root=controls_root,connection=connection,cloud_selection=selection)
    with managed_restore.operator_cloud_replacement(path,token,current,replacement):
        cloud=temporal.load_operator_configuration(Path(replacement['cloud_configuration']))
        with temporal.configured_operator_connection(cloud) as proposed:
            return await _prepare(path,token,expected_generation=expected_generation,command_id=command_id,artifact=artifact,
                deletion_root=deletion_root,controls_root=controls_root,connection=proposed,cloud_selection=selection)


async def _prepare_operator(path,token,replacement_token,replacement,*,expected_generation,command_id,artifact,deletion_root,controls_root,connection):
    from agentic_os.adapters.aws import managed_restore,operator_rotation as credentials,storage,temporal
    from .recovery_ready import _release_metadata
    path=Path(path);verify_operator(path,token);checked_id(command_id)
    if type(replacement_token) is not bytes or len(replacement_token)!=32:
        raise OwnershipError('Exact replacement operator credential required')
    selected=artifact_pin(artifact)
    if OPERATOR_ROLLOVER not in selected['supportedProfiles']:raise OwnershipError('Selected artifact cannot read managed operator rollover')
    op=_operation(path,command_id)
    if (op/'intent.json').exists():
        intent=_intent(path,command_id);selection=intent.get('operatorRollover')
        if selection is None or selection['after']!=replacement:raise OwnershipError('Original operator selection differs')
        staged=credentials.checked_stage(path,read_signed(op/credentials.STAGE_FILE,path.parent/'owner.key',maximum=32768))
        import base64,hmac
        if not hmac.compare_digest(base64.b64decode(staged['raw'],validate=True),replacement_token):
            raise OwnershipError('Original staged replacement credential differs')
        return await _prepare(path,token,expected_generation=expected_generation,command_id=command_id,artifact=artifact,
            deletion_root=deletion_root,controls_root=controls_root,connection=connection,cloud_selection=selection)
    current=cloud_configuration(path);previous=operator_configuration(path);initial=gate.state(path)
    prior=_release_metadata(path)
    if type(expected_generation) is not int or prior['generation']!=expected_generation:
        raise OwnershipError('Original operator preparation generation differs')
    configured=credentials.next_configuration(path,credentials.state(path),replacement_token,previous)
    reviewed=managed_restore.checked_operator_replacement(path,current,replacement,configured,previous=previous)
    connection.installation.verify_operator(token)
    with storage.configured_storage(reviewed['stores']) as (_,proposed):proposed(replacement_token)
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        verify_operator(path,token)
        if gate.state(path)!=initial or _release_metadata(path)!=prior:
            raise OwnershipError('Operator preparation release changed')
        from .recovery_ready import FILE as READY_FILE
        ensure_private(path.parent/DIRECTORY)
        if not op.exists() and len(list((path.parent/DIRECTORY).iterdir()))>=8:raise OwnershipError('Maintenance envelope exhausted')
        ensure_private(op)
        raw=private_read(path.parent/READY_FILE,1024**2)
        if (op/'prior-ready.json').exists():
            if private_read(op/'prior-ready.json',1024**2)!=raw:raise OwnershipError('Original staged release differs')
        else:private_write(op/'prior-ready.json',raw)
        staged=credentials.stage(path,command_id,replacement_token,prior,sha(reviewed),credentials.state(path),configured)
    selection=dict(profile=OPERATOR_ROLLOVER,before=current,after=reviewed,previous=previous,configuration=configured,
        stage=credentials.pin(staged),beforeCloudDigest=sha(temporal.load_operator_configuration(Path(current['cloud_configuration']))),
        afterCloudDigest=sha(temporal.load_operator_configuration(Path(reviewed['cloud_configuration']))))
    return await _prepare(path,token,expected_generation=expected_generation,command_id=command_id,artifact=artifact,
        deletion_root=deletion_root,controls_root=controls_root,connection=connection,cloud_selection=selection)


async def _prepare(path,token,*,expected_generation,command_id,artifact,deletion_root,controls_root,connection=None,cloud_selection=None):
    path=Path(path);verify_operator(path,token);checked_id(command_id)
    selected=artifact_pin(artifact)
    if _managed(path) and MANAGED_PROFILE not in selected['supportedProfiles']:
        raise OwnershipError('Selected artifact cannot read managed maintenance; use supported code or forward recovery')
    _key_reader(path,selected)
    _configuration_reader(path,selected)
    from .recovery_ready import _release_metadata,admitted_archive,FILE as READY_FILE
    from .recovery_release import _retirement
    from .recovery_quarantine import control_pins
    from .recovery_checkpoints import snapshot_checkpoints
    from .recovery_lineage import service_digest
    from .recovery_temporal import _inspect_history,_available_history
    op=_operation(path,command_id);root=path.parent
    with file_lock(root/'recovery-gate.lock',timeout=2):
        if type(expected_generation) is not int:raise OwnershipError('Maintenance generation required')
        archive=admitted_archive(path)
        binding,original=_service(path,archive,connection)
        if (op/'intent.json').exists():
            intent=_intent(path,command_id)
            if ((intent.get(selection_key(intent)) if selection_key(intent) else None)!=cloud_selection or intent['priorGeneration']!=expected_generation
                    or intent['selectedArtifactDigest']!=selected['artifactDigest']
                    or intent['selectedReleaseDigest']!=selected['releaseDigest']
                    or _managed(path) and intent['selectedContentDigest']!=selected['contentDigest']):
                raise OwnershipError('Maintenance retry selection differs')
            current=gate.state(path)
            if (intent['state']=='PARKED' and current['mode']=='PARKED'
                    and current['generation']==intent['parkGeneration']):
                # This acknowledges only the exact completed preparation. It
                # grants no Ready authority or new current-data validation.
                # Release still rechecks every SQL/privacy/key/work pin with
                # the selected credentials, including after an external cutover.
                return _result(intent,'PARKED')
        else:
            prior_gate=gate.state(path);value=_release_metadata(path)
            if prior_gate['generation']!=expected_generation:raise OwnershipError('Maintenance generation differs')
            if op.exists():
                from agentic_os.adapters.aws.operator_rotation import STAGE_FILE
                if (cloud_selection is None or cloud_selection['profile']!=OPERATOR_ROLLOVER
                        or set(p.name for p in op.iterdir())-{STAGE_FILE,'prior-ready.json'}):
                    raise OwnershipError('Unknown unfinished maintenance material')
            _keys(path,value,archive)
            original_programs=archive['receipt']['runtimeCheckpoint']
            if any(any(selected['programs'][group].get(n)!=pin for n,pin in original_programs[group].items())
                    for group in ('contracts','workflowPrograms')):
                raise OwnershipError('Selected artifact changes original workflow semantics')
            ensure_private(root/DIRECTORY)
            count=len(list((root/DIRECTORY).iterdir()))
            if count>8 or count==8 and not op.exists():raise OwnershipError('Maintenance envelope exhausted')
            with snapshot_checkpoints(path,deletion_root,controls_root,require_current=True) as privacy:
                intent={k:value[k] for k in _fields(BINDING,path)}|dict(profile=_profile(path),commandId=command_id,
                    priorGeneration=value['generation'],parkGeneration=value['generation']+1,
                    nextGeneration=value['generation']+2,priorCertificateDigest=sha(value),priorGate=prior_gate,
                    selectedArtifactDigest=selected['artifactDigest'],selectedReleaseDigest=selected['releaseDigest'],
                    privacy=privacy,catalogDigest=_catalog(path,archive),controlPins=control_pins(path,
                        production='production' in archive['receipt']['runtimeCheckpoint']),
                    retirement=_retirement(path),serviceDigest=service_digest(binding),original=original,
                    catalog=[],state='PREPARING')
                if _managed(path):intent['selectedContentDigest']=selected['contentDigest']
                operators=operator_configuration(path) if _managed(path) else None
                if operators is not None:intent['operatorConfiguration']=operators
                if cloud_selection is not None:
                    key='operatorRollover' if cloud_selection['profile']==OPERATOR_ROLLOVER else 'serviceRollover' if cloud_selection['profile']==SERVICE_ROLLOVER else 'cloudRollover'
                    if key=='operatorRollover':intent['operatorConfiguration']=cloud_selection['configuration']
                    intent[key]=_configuration_selection(path,cloud_selection,key,operators=intent.get('operatorConfiguration'))
            ensure_private(op)
            prior_bytes=private_read(root/READY_FILE,1024**2)
            if (op/'prior-ready.json').exists():
                if private_read(op/'prior-ready.json',1024**2)!=prior_bytes:raise OwnershipError('Original staged release differs')
            else:private_write(op/'prior-ready.json',prior_bytes)
            write_signed(op/'intent.json',intent,root/'owner.key')
        write_signed(root/FILE,dict(profile=_profile(path),commandId=command_id),root/'owner.key')
        current=gate.state(path)
        if current==intent['priorGate']:current=gate._write(path,mode='PARKED',reason='operator-park')
        if current['mode']!='PARKED' or current['generation']!=intent['parkGeneration']:
            raise OwnershipError('Maintenance Park generation differs')
        if intent['state']=='PARKED':return _result(intent,'PARKED')
    async with asyncio.timeout(20):
        binding,original=_service(path,archive,connection)
        if original!=intent['original']:raise OwnershipError('Maintenance original workflow lineage differs')
        if service_digest(binding)!=intent['serviceDigest']:raise OwnershipError('Maintenance workflow service differs')
        catalog=await (_inspect_history(path,binding,intent['original']) if connection is None else
            _available_history(path,binding,intent['original'],connection=connection))
    with file_lock(root/'recovery-gate.lock',timeout=2):
        if (_intent(path,command_id)!=intent or gate.state(path)!=current
                or control_pins(path,production='production' in archive['receipt']['runtimeCheckpoint'])!=intent['controlPins']):
            raise OwnershipError('Maintenance changed during Park')
        intent=intent|dict(catalog=catalog,state='PARKED')
        write_signed(op/'intent.json',intent,root/'owner.key')
    return _result(intent,'PARKED')


def _result(intent,state):
    return dict(profile=intent['profile'],state=state,generation=intent['parkGeneration'] if state=='PARKED'
        else intent['nextGeneration'],unknownUsageHeld=True)


async def recertify(path,token,*,command_id,artifact,deletion_root,controls_root,valid_seconds=86400,
        connection=None,expected_generation=None):
    path=Path(path);checked_id(command_id);verify_maintenance_operator(path,token,command_id,replacement_only=True)
    if type(valid_seconds) is not int or not 5<=valid_seconds<=86400:
        raise OwnershipError('Finite maintenance lifetime required')
    intent=_intent(path,command_id);root=path.parent;op=_operation(path,command_id)
    if expected_generation is not None and (type(expected_generation) is not int or expected_generation!=intent['parkGeneration']):
        raise OwnershipError('Maintenance original parked generation differs')
    selected=artifact_pin(artifact)
    if _managed(path) and MANAGED_PROFILE not in selected['supportedProfiles']:
        raise OwnershipError('Selected artifact cannot read managed maintenance; use supported code or forward recovery')
    _key_reader(path,selected)
    _configuration_reader(path,selected)
    from .recovery_ready import _release_metadata,admitted_archive,release_digest,FILE as READY_FILE,certificate
    from .recovery_quarantine import control_pins,compatible_catalog,prefix_digest
    from .recovery_checkpoints import snapshot_checkpoints
    from .recovery_temporal import _raw_client,_inspect_history,_available_history
    from .recovery_lineage import service_digest
    if (intent['state']!='PARKED' or selected['artifactDigest']!=intent['selectedArtifactDigest']
            or selected['releaseDigest']!=intent['selectedReleaseDigest'] or release_digest()!=selected['releaseDigest']):
        raise OwnershipError('Selected compatible maintenance artifact differs')
    if _managed(path):
        from agentic_os.adapters.aws.readiness import _runtime_content
        if selected['contentDigest']!=intent['selectedContentDigest'] or _runtime_content()!=intent['selectedContentDigest']:
            raise OwnershipError('Selected compatible managed content differs')
    current=gate.state(path)
    archive=admitted_archive(path)
    binding,original=_service(path,archive,connection)
    if original!=intent['original'] or service_digest(binding)!=intent['serviceDigest']:
        raise OwnershipError('Maintenance workflow service differs')
    if current['mode']=='READY':
        if certificate(path)!=read_signed(op/'ready.json',root/'owner.key',maximum=1024**2):
            raise OwnershipError('Maintenance retry release differs')
        return _result(intent,'READY')
    if current['mode']!='PARKED' or current['generation']!=intent['parkGeneration']:
        raise OwnershipError('Maintenance parked generation differs')
    # The narrowly authenticated prior metadata permits integrity checks only.
    prior=_release_metadata(path,current=intent['priorGate'],maintenance=intent)
    if sha(prior)!=intent['priorCertificateDigest']:raise OwnershipError('Maintenance prior certificate differs')
    if 'operatorRollover' in intent:
        if connection is None:raise OwnershipError('Managed operator transport required')
        connection.installation.verify_operator(token)
        with file_lock(root/'recovery-gate.lock',timeout=2):
            if gate.state(path)!=current:raise OwnershipError('Operator handoff generation changed')
            from agentic_os.adapters.aws.operator_rotation import apply
            apply(path,token,operator_intent(intent),prior_configuration=intent['operatorRollover']['previous'])
    async with asyncio.timeout(20):
        transport_args={} if connection is None else dict(connection=connection)
        client=await _raw_client(binding,intent['original'],**transport_args)
        inspect=_inspect_history if connection is None else _available_history
        before=await inspect(path,binding,intent['original'],**transport_args)
        if {(v['workflowId'],v['runId']) for v in before}!={(v['workflowId'],v['runId']) for v in intent['catalog']}:
            raise OwnershipError('Maintenance raw workflow catalog changed')
        for row in intent['catalog']:await prefix_digest(client,intent['original'],row)
        for row in before:
            if row['status']==1:
                await client.workflow_service.terminate_workflow_execution(TerminateWorkflowExecutionRequest(
                    namespace=intent['original']['namespace'],workflow_execution=WorkflowExecution(
                        workflow_id=row['workflowId'],run_id=row['runId']),first_execution_run_id=row['firstRunId'],
                    reason='operator-maintenance',identity='agentic-os-recovery'),timeout=timedelta(seconds=3))
        after=await inspect(path,binding,intent['original'],**transport_args)
        compatible_catalog(intent['catalog'],after)
        for row in intent['catalog']:await prefix_digest(client,intent['original'],row)
    with file_lock(root/'recovery-gate.lock',timeout=2):
        verify_operator(path,token)
        if (gate.state(path)!=current or _intent(path,command_id)!=intent
                or _release_metadata(path,current=intent['priorGate'],maintenance=intent)!=prior
                or control_pins(path,production='production' in archive['receipt']['runtimeCheckpoint'])!=intent['controlPins']):
            raise OwnershipError('Maintenance state changed before publication')
        with snapshot_checkpoints(path,deletion_root,controls_root,require_current=True) as privacy:
            catalog_digest=_catalog(path,archive)
            if privacy!=intent['privacy'] or catalog_digest!=intent['catalogDigest']:
                raise OwnershipError('Current privacy or catalog differs')
            keys=_keys(path,prior,archive)
            retired={k:sorted(set(prior[k])|set(intent['retirement'][k])|
                ({v['workflowId'] for v in intent['catalog']} if k=='retiredExecutions' else set())) for k in RETIREMENT}
            now=utcnow();ready=prior|dict(generation=intent['nextGeneration'],releaseDigest=selected['releaseDigest'],
                issuedAt=iso(now),expiresAt=iso(now+timedelta(seconds=valid_seconds)),**retired)
            if _managed(path):ready['contentDigest']=selected['contentDigest']
            if (op/'ready.json').exists():
                existing=read_signed(op/'ready.json',root/'owner.key',maximum=1024**2)
                if (any(existing[k]!=ready[k] for k in ready if k not in {'issuedAt','expiresAt'})
                        or timestamp(existing['expiresAt'])<=now):raise OwnershipError('Pending maintenance certificate differs or expired')
                ready=existing
            else:write_signed(op/'ready.json',ready,root/'owner.key')
            proof={k:ready[k] for k in _fields(BINDING,path)}|dict(profile=MANAGED_RECERT if _managed(path) else RECERT,commandId=command_id,
                generation=ready['generation'],priorCertificateDigest=sha(prior),certificateDigest=sha(ready),
                intentDigest=sha(intent),privacyDigest=sha(privacy),catalogDigest=catalog_digest,
                controlPinsDigest=sha(intent['controlPins']),keyPinsDigest=keys,catalog=after,
                originalHistoryPreserved=True,unknownUsageHeld=True,deadlinesUnchanged=True)
            if (op/'proof.json').exists():
                if read_signed(op/'proof.json',root/'owner.key',maximum=2*1024**2)!=proof:
                    raise OwnershipError('Pending maintenance publication differs')
            else:write_signed(op/'proof.json',proof,root/'owner.key')
            write_signed(root/READY_FILE,ready,root/'owner.key')
            published=gate._write(path,mode='READY',reason='verified')
            if published['generation']!=ready['generation']:raise OwnershipError('Maintenance release generation differs')
    certificate(path)
    return _result(intent,'READY')
