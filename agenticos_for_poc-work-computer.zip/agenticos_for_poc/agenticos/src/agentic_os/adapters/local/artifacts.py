"""Authenticated immutable owner-bound artifacts; no custom cryptography."""
import base64
import hashlib
from pathlib import Path
import secrets
from uuid import UUID, uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json, PURPOSES
from agentic_os.contracts.validation import validate_contract
from .files import OwnershipError, check_private, private_read, private_write


def checked_id(value: str) -> str:
    try:
        if str(UUID(value)) != value:
            raise ValueError()
    except (TypeError, ValueError, AttributeError):
        raise OwnershipError("Invalid opaque artifact/key reference") from None
    return value


class LocalKeys:
    def __init__(self, directory: Path):
        check_private(directory, directory=True)
        self.directory = directory

    def rotate(self) -> str:
        check_private(self.directory, directory=True)
        ident = str(uuid4())
        private_write(self.directory / (ident + ".key"), AESGCM.generate_key(bit_length=256))
        private_write(self.directory / "active.json", canonical_bytes({"id": ident}), replace=True)
        return ident

    def active(self) -> str:
        value = parse_canonical_json(private_read(self.directory / "active.json"))
        if set(value) != {"id"}:
            raise OwnershipError("Invalid active key metadata")
        return checked_id(value["id"])

    def _key(self, ident: str) -> bytes:
        check_private(self.directory, directory=True)
        key = private_read(self.directory / (checked_id(ident) + ".key"), 32)
        if len(key) != 32:
            raise OwnershipError("Invalid/missing encryption key")
        return key

    def encrypt(self, namespace: dict, purpose: str, content: bytes, *, artifact_id: str) -> dict:
        validate_contract("SubjectRef", namespace)
        if purpose not in PURPOSES or type(content) is not bytes or len(content) > 1048576:
            raise OwnershipError("Unqualified artifact purpose/type/size")
        ident = self.active(); nonce = secrets.token_bytes(12)
        binding = {"subject": namespace, "purpose": purpose, "artifactId": checked_id(artifact_id), "keyId": ident}
        ciphertext = AESGCM(self._key(ident)).encrypt(nonce, content, canonical_bytes(binding))
        return {"version": 1, "keyId": ident, "nonce": base64.b64encode(nonce).decode("ascii"),
                "ciphertext": base64.b64encode(ciphertext).decode("ascii")}

    def decrypt(self, namespace: dict, purpose: str, envelope: dict, *, artifact_id: str) -> bytes:
        validate_contract("SubjectRef", namespace)
        if (purpose not in PURPOSES or type(envelope) is not dict
                or set(envelope) != {"version", "keyId", "nonce", "ciphertext"}
                or type(envelope["version"]) is not int or envelope["version"] != 1):
            raise OwnershipError("Invalid encrypted artifact envelope")
        try:
            nonce = base64.b64decode(envelope["nonce"], validate=True)
            content = base64.b64decode(envelope["ciphertext"], validate=True)
            if len(nonce) != 12 or len(content) > 1048592:
                raise ValueError()
            binding = {"subject": namespace, "purpose": purpose, "artifactId": checked_id(artifact_id),
                       "keyId": envelope["keyId"]}
            return AESGCM(self._key(envelope["keyId"])).decrypt(nonce, content, canonical_bytes(binding))
        except (InvalidTag, ValueError, TypeError):
            raise OwnershipError("Artifact authentication failed") from None


class LocalArtifacts:
    def __init__(self, directory: Path, keys: LocalKeys):
        check_private(directory, directory=True)
        self.directory = directory
        self.keys = keys

    def create(self, namespace: dict, purpose: str, content: bytes) -> str:
        check_private(self.directory, directory=True)
        ident = str(uuid4())
        envelope = self.keys.encrypt(namespace, purpose, content, artifact_id=ident)
        private_write(self.directory / (ident + ".json"), canonical_bytes(envelope))
        return ident

    def read(self, namespace: dict, reference: str, *, purpose: str = "artifact") -> bytes:
        check_private(self.directory, directory=True)
        path = self.directory / (checked_id(reference) + ".json")
        try:
            envelope = parse_canonical_json(private_read(path, 1500000))
            return self.keys.decrypt(namespace, purpose, envelope, artifact_id=reference)
        except (OSError, ValueError):
            raise OwnershipError("Artifact unavailable or corrupt") from None

    def pin(self, reference: str) -> dict:
        """Ciphertext digest, no reversible low-entropy plaintext digest in audit."""
        check_private(self.directory, directory=True)
        content = private_read(self.directory / (checked_id(reference) + ".json"), 1500000)
        return {"reference": reference, "ciphertextDigest": hashlib.sha256(content).hexdigest()}

    def purge(self, namespace, reference, *, purpose="artifact", expected_ciphertext_digest):
        # The caller must establish the governed deletion barrier. Reuse the
        # existing authenticated marker and exact-pin concurrency checks.
        from .erasing_artifacts import ErasingLocalArtifacts
        return ErasingLocalArtifacts(self.directory, self.keys).purge(namespace, reference,
            purpose=purpose, expected_ciphertext_digest=expected_ciphertext_digest)
