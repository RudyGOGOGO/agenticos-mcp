"""Explicit restored task client: original logical namespace, fresh authority.

There is no namespace registration or adoption fallback. Physical resources
retain the target run identity while private history binds the original one.
"""
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from datetime import timedelta
import inspect
import re

from temporalio.api.workflowservice.v1 import DescribeNamespaceRequest
from temporalio.client import Client
from temporalio.converter import DataConverter

from agentic_os.adapters.temporal.driver import TaskTemporal
from agentic_os.adapters.temporal.memory import MemoryTaskTemporal
from agentic_os.adapters.temporal.native import NativeTaskTemporal
from agentic_os.adapters.temporal.privacy import SafeFailureConverter, SafeActivityInterceptor
from agentic_os.errors import OSErrorCode
from .artifacts import LocalKeys
from .recovery_gate import assert_runtime
from .recovery_history import ProtectedHistoryCodec, RuntimeHistoryAuthority
from .recovery_lineage import load_lineage, service_digest
from .recovery_ready import certificate, restored
from .temporal import inspect_service


class _RecoveredConnection:
    def __init__(self, manifest, runtime):
        super().__init__(manifest)
        if runtime.manifest != manifest:
            raise OSErrorCode('DENIED')
        self.runtime = runtime

    async def connect(self, *, register=False):
        if register or not restored(self.manifest):
            raise OSErrorCode('PROFILE_DISABLED')
        assert_runtime(self.manifest)
        release = certificate(self.manifest)
        physical, _ = await asyncio.to_thread(inspect_service, self.manifest, recovered_profile=True)
        lineage = await asyncio.to_thread(load_lineage, self.manifest, physical)
        if lineage['receiptDigest'] != release['receiptDigest']:
            raise OSErrorCode('DENIED')
        original = lineage['original']
        raw = await asyncio.wait_for(Client.connect('127.0.0.1:'+str(physical['port']),
            namespace=original['namespace']), 10)
        if not await asyncio.wait_for(raw.service_client.check_health(), 5):
            raise OSErrorCode('UNAVAILABLE')
        namespace = await raw.workflow_service.describe_namespace(
            DescribeNamespaceRequest(namespace=original['namespace']), timeout=timedelta(seconds=5))
        if (namespace.namespace_info.id != original['namespaceId']
                or namespace.namespace_info.name != original['namespace']
                or dict(namespace.namespace_info.data) != original['data']):
            raise OSErrorCode('DENIED')
        current, _ = await asyncio.to_thread(inspect_service, self.manifest, recovered_profile=True)
        if (service_digest(current) != service_digest(physical) or current['port'] != physical['port']
                or certificate(self.manifest) != release):
            raise OSErrorCode('DENIED')
        assert_runtime(self.manifest)
        self.keys = LocalKeys(self.manifest.parent/'keys')
        # Construction does not read active.json or encryption key bytes.
        self.history_authority = RuntimeHistoryAuthority(self.runtime, original['namespace'])
        converter = DataConverter(payload_codec=ProtectedHistoryCodec(self.keys, original['namespace'],
            release['installationId'], self.history_authority), failure_converter_class=SafeFailureConverter)
        self.binding = dict(physical, namespace=original['namespace'], runId=original['data']['runId'])
        self.physical_binding = physical
        self.client = Client(raw.service_client, namespace=original['namespace'], data_converter=converter)
        return self


class RecoveredTaskTemporal(_RecoveredConnection, TaskTemporal):
    pass


class RecoveredMemoryTaskTemporal(_RecoveredConnection, MemoryTaskTemporal):
    pass


class RecoveredNativeTaskTemporal(_RecoveredConnection, NativeTaskTemporal):
    pass


async def task_temporal(manifest, runtime, *, profile='kernel'):
    profiles = {'kernel':(TaskTemporal, RecoveredTaskTemporal),
        'memory':(MemoryTaskTemporal, RecoveredMemoryTaskTemporal),
        'native':(NativeTaskTemporal, RecoveredNativeTaskTemporal)}
    if profile not in profiles:
        raise OSErrorCode('PROFILE_DISABLED')
    legacy, recovered = profiles[profile]
    return await (recovered(manifest, runtime) if restored(manifest) else legacy(manifest)).connect()


@asynccontextmanager
async def private_worker(temporal, keys, *, task_queue, workflows, activities=()):
    if type(temporal) not in {RecoveredTaskTemporal, RecoveredMemoryTaskTemporal, RecoveredNativeTaskTemporal}:
        if restored(temporal.manifest):
            raise OSErrorCode('PROFILE_DISABLED')
        from agentic_os.adapters.temporal.privacy import private_worker as legacy_worker
        async with legacy_worker(temporal, keys, task_queue=task_queue, workflows=workflows, activities=activities) as worker:
            yield worker
        return
    from temporalio.worker import Worker
    if (task_queue != temporal.task_queue or keys is not temporal.keys
            or not re.fullmatch(r'os-(kernel|memory-task)-[a-z0-9-]{8,80}', task_queue)
            or any(not inspect.iscoroutinefunction(fn) for fn in activities)
            or type(temporal.client.data_converter.payload_codec) is not ProtectedHistoryCodec
            or temporal.client.data_converter.payload_codec.authority is not temporal.history_authority):
        raise OSErrorCode('PROFILE_DISABLED')
    assert_runtime(temporal.manifest)
    with ThreadPoolExecutor(max_workers=8, thread_name_prefix='os-restored-workflow') as pool:
        async with Worker(temporal.client, task_queue=task_queue, workflows=workflows, activities=activities,
            workflow_task_executor=pool, interceptors=[SafeActivityInterceptor()], identity='os-restored-worker',
            max_concurrent_workflow_tasks=8, max_concurrent_activities=8, max_cached_workflows=64,
            graceful_shutdown_timeout=timedelta(seconds=3)) as worker:
            yield worker
