"""Signed fixture dispositions and preview-first retirement of owned resources.

Legacy installations have no ledger and are retained. Only a newly declared
disposable synthetic fixture can retire its stopped PostgreSQL through Docker.
Keys, artifacts, backups, manifests and evidence are never filesystem-reaped.
"""
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import time

from agentic_os.contracts.canonical import canonical_bytes
from .docker import DockerControl
from .files import OwnershipError
from .ownership import load_manifest
from .resources import (active_process_paths, canonical_path, file_lock,
                        read_signed, write_signed, tree_inventory)

DISPOSITIONS = {"disposable-synthetic", "recovery-hold", "active-retained"}


def create_ledger(path: Path, disposition="active-retained"):
    manifest = load_manifest(path)
    if (disposition not in DISPOSITIONS or (path.parent / "retention.json").exists()
            or manifest['postgres'] is not None
            or any(any((path.parent / name).iterdir()) for name in ('keys', 'artifacts', 'backups'))):
        raise OwnershipError("Invalid or existing fixture disposition")
    value = {"version": 1, "installationId": manifest["installationId"], "runId": manifest["runId"],
             "root": manifest["root"], "disposition": disposition, "generation": 1,
             "state": "retained", "holds": ["installation-incomplete"],
             "createdAt": int(time.time()), "resources": None}
    _save(path, value)


def _save(path, value):
    write_signed(path.parent / "retention.json", value, path.parent / "owner.key")


def ledger(path: Path):
    manifest = load_manifest(path)
    if not (path.parent / "retention.json").exists():
        raise OwnershipError("Historical fixture is retained without disposition")
    value = read_signed(path.parent / "retention.json", path.parent / "owner.key")
    if (set(value) != {"version", "installationId", "runId", "root", "disposition", "generation",
                       "state", "holds", "createdAt", "resources"}
            or value["version"] != 1 or value["disposition"] not in DISPOSITIONS
            or any(value[key] != manifest[key] for key in ("installationId", "runId", "root"))
            or type(value["generation"]) is not int or value["generation"] < 1
            or value["state"] not in {"retained", "retiring", "retired"}
            or type(value["holds"]) is not list
            or any(hold not in {"installation-incomplete", "operation-failed", "recovery-dependent"}
                   for hold in value["holds"])):
        raise OwnershipError("Fixture retention identity or fields changed")
    return value


@contextmanager
def fixture_lease(path: Path):
    load_manifest(path)
    with file_lock(path.parent / "fixture.lock", shared=True):
        if (path.parent / "retention.json").exists() and ledger(path)["state"] != "retained":
            raise OwnershipError("Fixture is retiring or retired")
        yield


def provisioned(path: Path):
    with file_lock(path.parent / "retention.lock"):
        value = ledger(path)
        if value['resources'] is not None or value['holds'] != ['installation-incomplete'] or value['state'] != 'retained':
            raise OwnershipError('Fixture disposition is not a fresh provisioning record')
        value["resources"] = load_manifest(path)["postgres"]
        value["holds"] = [] if value["disposition"] != "recovery-hold" else ["recovery-dependent"]
        value["generation"] += 1
        _save(path, value)


def hold(path: Path):
    with file_lock(path.parent / "retention.lock"):
        value = ledger(path)
        value["holds"] = sorted(set(value["holds"]) | {"operation-failed"})
        value["generation"] += 1
        _save(path, value)


def refresh_postgres_endpoint(path: Path):
    """Update a verified running resource's volatile loopback port only.

    Creation authority and immutable container/volume/image identity survive
    restart. This cannot adopt another resource, clear a hold or retire data.
    The caller holds the fixture lease throughout the storage restart.
    """
    if not (path.parent / 'retention.json').exists():
        return  # Historical installations retain their original disposition.
    with file_lock(path.parent / 'retention.lock'):
        value, manifest = ledger(path), load_manifest(path)
        original, current = value['resources'], manifest['postgres']
        if (value['state'] != 'retained' or type(original) is not dict or current is None
                or set(original) != set(current) or type(original.get('port')) is not int
                or not 1 <= original['port'] <= 65535):
            raise OwnershipError('Endpoint refresh requires an original retained resource')
        if ({k:v for k,v in original.items() if k != 'port'} !=
                {k:v for k,v in current.items() if k != 'port'}):
            raise OwnershipError('Endpoint refresh cannot change resource identity')
        if original == current:
            return
        # Live Engine inspection independently proves labels, image, volume,
        # privileges and the exact published loopback endpoint in the manifest.
        DockerControl(manifest).inspect_owned(manifest)
        value['resources'] = dict(current)
        value['generation'] += 1
        _save(path, value)


def inventory(path: Path):
    """Read-only retention/accounting; absent legacy dispositions stay retained."""
    manifest = load_manifest(path)
    value = ledger(path) if (path.parent / 'retention.json').exists() else None
    local = tree_inventory(path.parent)
    volume_bytes = None
    if manifest['postgres'] is not None and (value is None or value['state'] != 'retired'):
        docker = DockerControl(manifest)
        docker.inspect_owned(manifest, require_running=False)
        volume_bytes = docker.volume_usage(manifest['postgres']['volume'])
    return {'version': 1, 'installationId': manifest['installationId'], 'runId': manifest['runId'],
            'disposition': value['disposition'] if value else 'historical-retained',
            'state': value['state'] if value else 'retained', 'holds': value['holds'] if value else ['legacy-review-required'],
            'retainedLocalBytes': local['bytes'], 'retainedAllocatedBytes': local['allocatedBytes'],
            'providerVolumeBytes': volume_bytes}


def _preview(path):
    canonical_path(path)
    manifest, value = load_manifest(path), ledger(path)
    if value["state"] == "retired":
        raise OwnershipError("Fixture already retired")
    if value["disposition"] != "disposable-synthetic" or value["holds"]:
        raise OwnershipError("Fixture has a retention or recovery hold")
    if value["resources"] != manifest["postgres"] or manifest["postgres"] is None:
        raise OwnershipError("Retirement resources differ from creation ledger")
    # Unqualified component lifecycles and any backup/artifact recovery linkage
    # stay held. This PostgreSQL-only reaper cannot guess their dependencies.
    for name in ("temporal-service.json", "restore-blocked", "install-blocked", "restore-reconciled.json"):
        if (path.parent / name).exists():
            raise OwnershipError("Fixture has an unresolved component/recovery dependency")
    for name in ("backups", "artifacts"):
        if any((path.parent / name).iterdir()):
            raise OwnershipError("Fixture has protected recovery material")
    local = tree_inventory(path.parent)
    docker = DockerControl(manifest)
    binding = manifest["postgres"]
    containers = docker.command("ps", "-aq", "--no-trunc", "--filter", "id=" + binding["container"]).splitlines()
    if containers not in ([], [binding["container"]]):
        raise OwnershipError("Unexpected container inventory")
    volumes = docker.command("volume", "ls", "-q", "--filter", "name=" + binding["volume"]).splitlines()
    volume_present = binding["volume"] in volumes
    if value["state"] != "retiring" and (not containers or not volume_present):
        raise OwnershipError("Missing fixture resource without retirement intent")
    if containers:
        obj = docker.inspect_owned(manifest, require_running=False)
        if obj["State"]["Running"] or obj["State"].get("Paused") or obj["State"].get("Restarting"):
            raise OwnershipError("Fixture has an active container")
    active_process_paths(path.parent, readonly_provider_mount=path.parent / 'bootstrap-password'
                         if containers or value['state'] == 'retiring' else None)
    # No other container, including stopped/foreign consumers, can share this volume.
    attached = docker.command("ps", "-aq", "--filter", "volume=" + manifest["postgres"]["volume"]).splitlines()
    if (containers and (len(attached) != 1 or not binding["container"].startswith(attached[0]))
            or not containers and attached):
        raise OwnershipError("Volume has foreign or unknown consumers")
    if volume_present:
        volume = json.loads(docker.command("volume", "inspect", binding["volume"]))[0]
        labels = {"io.agentic-os.installation": manifest["installationId"],
                  "io.agentic-os.run": manifest["runId"], "io.agentic-os.component": "postgres"}
        if (volume.get("Driver") != "local" or volume.get("Options")
                or any(volume.get("Labels", {}).get(k) != v for k, v in labels.items())):
            raise OwnershipError("Unqualified volume ownership/driver/options")
    body = {"version": 1, "installationId": manifest["installationId"], "runId": manifest["runId"],
            "generation": value["generation"], "container": binding["container"],
            "containerPresent": bool(containers), "volumePresent": volume_present,
            "providerVolumeBytes": docker.volume_usage(binding['volume']) if volume_present else 0,
            "volume": manifest["postgres"]["volume"], "retainedLocalBytes": local["bytes"],
            "retainedAllocatedBytes": local["allocatedBytes"], "state": value["state"],
            "preserved": ["keys", "artifacts", "backups", "manifest", "evidence"]}
    body["previewDigest"] = hashlib.sha256(canonical_bytes(body)).hexdigest()
    return body


def preview(path: Path):
    with file_lock(path.parent / "fixture.lock", timeout=0):
        with file_lock(path.parent / "retention.lock"):
            return _preview(path)


def execute(path: Path, *, preview_digest: str):
    with file_lock(path.parent / "fixture.lock", timeout=0):
        with file_lock(path.parent / "retention.lock"):
            plan = _preview(path)
            if plan["previewDigest"] != preview_digest:
                raise OwnershipError("Retirement preview is stale")
            value, manifest = ledger(path), load_manifest(path)
            value["state"] = "retiring"
            value["generation"] += 1
            _save(path, value)
            docker = DockerControl(manifest)
            # No force. Docker independently refuses a running container or an
            # in-use volume. On failure keep the signed retiring state/evidence.
            if plan["containerPresent"]:
                docker.command("container", "rm", manifest["postgres"]["container"])
            if plan["volumePresent"]:
                docker.command("volume", "rm", manifest["postgres"]["volume"])
            value["state"] = "retired"
            value["generation"] += 1
            _save(path, value)
            return {"state": "retired", "preservedLocalBytes": plan["retainedLocalBytes"]}
