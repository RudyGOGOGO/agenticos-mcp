"""Conservative disk admission; crash reservations remain visible until reviewed."""
from contextlib import contextmanager
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
from uuid import uuid4

from .files import OwnershipError
from .resources import ensure_private, file_lock, initialize_key, read_signed, write_signed

GiB = 1024**3
DEFAULT_FLOOR = 20 * GiB


def owned_docker_headroom(path):
    """Fresh backing-store measurement in an attested owned OS container.

    The fixed unprivileged df command reads root and the owned data filesystem;
    their minimum covers both growth locations. It accesses no database,
    password file, host resource or network. Nothing is cached or estimated.
    The separate isolated probe remains available before a container exists.
    """
    from .ownership import load_manifest
    from .images import PG_IMAGE
    from .images import RDS_COMPATIBILITY_IMAGE
    from .ownership import POC_PROFILE
    from .capacity_probe import CapacityProbeControl
    deadline = time.monotonic() + 20
    manifest = load_manifest(Path(path))
    from .poc_image import selected
    image=selected(manifest) if manifest['profile']==POC_PROFILE else PG_IMAGE
    if manifest['postgres'] is None or manifest['postgres']['image'] != image:
        raise OwnershipError('Owned capacity image is unqualified')
    control = CapacityProbeControl(manifest, deadline=deadline)
    obj = control.inspect_owned(manifest)
    ident = obj.get('Id')
    if (type(ident) is not str or len(ident) != 64
            or any(c not in '0123456789abcdef' for c in ident)):
        raise OwnershipError('Owned capacity container identity unavailable')
    raw = control.command('exec', '--user', '65534:65534', ident,
        'df', '-Pk', '/', '/var/lib/postgresql/data')
    try:
        rows = [line.split() for line in raw.splitlines()[1:]]
        if (len(rows) != 2 or [row[-1] for row in rows] != ['/', '/var/lib/postgresql/data']
                or any(len(row) != 6 or not 0 <= int(row[3]) <= int(row[1]) for row in rows)
                or time.monotonic() >= deadline):
            raise ValueError()
        return min(int(row[3]) for row in rows) * 1024
    except (ValueError, IndexError):
        raise OwnershipError('Owned capacity probe returned invalid evidence') from None


def docker_headroom(endpoint, image, *, owned_source=None):
    """Measure Docker's backing filesystem separately, with no host/DB mounts.

    The pinned probe image must already be present. No implicit pull, global
    prune or inference from host APFS free space is allowed.
    """
    from .ownership import validate_docker_endpoint
    validate_docker_endpoint(endpoint)
    if owned_source is not None:
        from .ownership import load_manifest
        if not isinstance(owned_source,Path):raise OwnershipError('Explicit owned capacity source required')
        manifest=load_manifest(owned_source)
        if (manifest['dockerEndpoint']!=endpoint or manifest['postgres'] is None
                or manifest['postgres']['image']!=image):
            raise OwnershipError('Capacity source differs from the selected Docker runtime/image')
        return owned_docker_headroom(owned_source)
    with tempfile.TemporaryDirectory(prefix="aos-capacity-") as scratch:
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": scratch,
               "DOCKER_CONFIG": scratch, "DOCKER_HOST": endpoint}
        deadline = time.monotonic() + 20
        # This probe has no data mounts, network or business-effect transport.
        # One recognized transport retry still requires a fresh valid result
        # within the original deadline; missing evidence never admits growth.
        for attempt in range(2):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise OwnershipError("Docker capacity probe exceeded bounded deadline")
            try:
                result = subprocess.run(["docker", "run", "--rm", "--pull=never", "--network=none",
                    "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges:true",
                    "--memory=32m", "--pids-limit=16", "--user=65534:65534", "--entrypoint=df",
                    image, "-Pk", "/"], env=env, capture_output=True, text=True, timeout=remaining)
            except subprocess.TimeoutExpired:
                raise OwnershipError("Docker capacity probe exceeded bounded deadline") from None
            except OSError:
                raise OwnershipError("Docker capacity probe CLI unavailable") from None
            if time.monotonic() >= deadline:
                raise OwnershipError("Docker capacity probe exceeded bounded deadline")
            if not result.returncode:
                break
            from .docker import _failure_category
            category = _failure_category(result.stderr)
            if category == "operation-rejected" or attempt == 1:
                raise OwnershipError("Docker capacity probe unavailable: " + category)
            if deadline - time.monotonic() <= .05:
                raise OwnershipError("Docker capacity probe exceeded bounded deadline")
            time.sleep(.05)
        try:
            fields = result.stdout.splitlines()[-1].split()
            free = int(fields[3]) * 1024
            if free < 0 or len(fields) != 6:
                raise ValueError()
            return free
        except (ValueError, IndexError):
            raise OwnershipError("Docker capacity probe returned invalid evidence") from None


class Capacity:
    def __init__(self, root: Path, *, floor=DEFAULT_FLOOR):
        if type(floor) is not int or floor < 0:
            raise OwnershipError("Invalid capacity floor")
        initialize_key(root, allowed_entries={'leases', 'capacity.json', 'capacity.lock'})
        self.root, self.floor = root, floor
        ensure_private(root / "leases")

    def _read(self):
        path = self.root / "capacity.json"
        if not path.exists():
            return {}
        value = read_signed(path, self.root / "resource.key")
        if value.get("version") != 1 or type(value.get("reservations")) is not dict:
            raise OwnershipError("Invalid capacity inventory")
        records = value["reservations"]
        if set(value) != {"version", "reservations"} or len(records) > 1024:
            raise OwnershipError("Invalid capacity inventory")
        for ident, record in records.items():
            if (type(ident) is not str or len(ident) != 32 or any(c not in "0123456789abcdef" for c in ident)
                    or type(record) is not dict
                    or set(record) not in ({"pid", "purpose", "peakBytes", "dockerPeakBytes", "createdAt"},
                        {"pid", "purpose", "peakBytes", "dockerPeakBytes", "createdAt", "resourceKey"})
                    or record["purpose"] not in {"verification", "installation", "build", "artifact", "native"}
                    or any(type(record[k]) is not int or record[k] < 0
                           for k in ("pid", "peakBytes", "dockerPeakBytes", "createdAt"))):
                raise OwnershipError("Invalid capacity reservation")
            if "resourceKey" in record and (type(record["resourceKey"]) is not str
                    or len(record["resourceKey"]) != 64
                    or any(c not in "0123456789abcdef" for c in record["resourceKey"])):
                raise OwnershipError("Invalid capacity resource identity")
        return records

    def _save(self, records):
        write_signed(self.root / "capacity.json", {"version": 1, "reservations": records},
                     self.root / "resource.key")

    def _snapshot(self, records, peak, docker_free, docker_peak):
        if any(type(value) is not int or value < 0 for value in (peak, docker_peak)):
            raise OwnershipError("Invalid estimated peak growth")
        if docker_peak and (type(docker_free) is not int or docker_free < 0):
            raise OwnershipError("Docker storage headroom is unknown")
        free = shutil.disk_usage(self.root).free
        reserved = sum(record["peakBytes"] for record in records.values())
        docker_reserved = sum(record["dockerPeakBytes"] for record in records.values())
        return {"hostFreeBytes": free, "floorBytes": self.floor, "reservedPeakBytes": reserved,
                "estimatedPeakBytes": peak, "dockerFreeBytes": docker_free,
                "dockerReservedPeakBytes": docker_reserved, "dockerEstimatedPeakBytes": docker_peak,
                "admitted": free - reserved - peak >= self.floor and (
                    not docker_peak or docker_free - docker_reserved - docker_peak >= self.floor),
                "reservations": records}

    def preview(self, peak, *, docker_free=None, docker_peak=0):
        with file_lock(self.root / "capacity.lock"):
            return self._snapshot(self._read(), peak, docker_free, docker_peak)

    @contextmanager
    def reserve(self, peak, *, purpose, docker_free=None, docker_peak=0, resource_key=None):
        if purpose not in {"verification", "installation", "build", "artifact", "native"}:
            raise OwnershipError("Unknown capacity purpose")
        if resource_key is not None and (type(resource_key) is not str or len(resource_key) != 64
                or any(c not in "0123456789abcdef" for c in resource_key)):
            raise OwnershipError("Invalid capacity resource identity")
        ident = uuid4().hex
        lease = self.root / "leases" / ident
        retained = False
        # Lock survives through allocation and cleanup; a killed process leaves
        # its signed reservation behind, never silently assumed cleaned up.
        try:
            with file_lock(lease):
                with file_lock(self.root / "capacity.lock"):
                    records = self._read()
                    snapshot = self._snapshot(records, peak, docker_free, docker_peak)
                    if not snapshot["admitted"]:
                        raise OwnershipError("Insufficient capacity after reserved estimated peak")
                    if len(records) >= 1024:
                        raise OwnershipError("Capacity recovery-hold limit exceeded")
                    records[ident] = {"pid": os.getpid(), "purpose": purpose, "peakBytes": peak,
                                      "dockerPeakBytes": docker_peak, "createdAt": int(time.time())}
                    if resource_key is not None:
                        records[ident]["resourceKey"] = resource_key
                    self._save(records)
                    retained = True
                yield snapshot
                with file_lock(self.root / "capacity.lock"):
                    records = self._read()
                    records.pop(ident)
                    self._save(records)
                    retained = False
        finally:
            # Never unlink a live lock. Unique successful leases have no future
            # reference; failed/killed work keeps both its record and lock inode.
            if not retained:
                lease.unlink(missing_ok=True)

    def release_reviewed(self, ident, *, expected):
        """Explicit accounting resolution, never deletes a path or a resource."""
        if len(ident) != 32 or any(char not in "0123456789abcdef" for char in ident):
            raise OwnershipError("Invalid reservation identity")
        with file_lock(self.root / "leases" / ident, timeout=0):
            with file_lock(self.root / "capacity.lock"):
                records = self._read()
                if records.get(ident) != expected:
                    raise OwnershipError("Capacity review is stale")
                records.pop(ident)
                self._save(records)
        (self.root / "leases" / ident).unlink(missing_ok=True)
