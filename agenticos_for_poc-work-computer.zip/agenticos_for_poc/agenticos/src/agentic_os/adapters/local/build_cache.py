"""Digest-keyed verified inputs/artifacts; builders never receive a shared tree."""
from contextlib import contextmanager
import hashlib
import os
from pathlib import Path
import time
from uuid import uuid4

from agentic_os.contracts.canonical import canonical_bytes
from .capacity import Capacity, GiB
from .files import OwnershipError, private_directory, private_write
from .resources import (ensure_private, file_lock, initialize_key, read_signed,
                        write_signed, tree_inventory, remove_staging, active_process_paths, staging_usage)


def cache_root(installation_root: Path) -> Path:
    # Explicit operator override supports a shared cache across independent
    # installs. No home-directory scan or historical fixture adoption.
    return Path(os.environ.get("AGENTIC_OS_BUILD_CACHE", str(installation_root.parent / ".agentic-os-cache")))


def admission_root(cache: Path) -> Path:
    return Path(os.environ.get("AGENTIC_OS_CAPACITY_ROOT", str(cache.parent / ".agentic-os-capacity")))


class BuildCache:
    def __init__(self, root: Path, *, maximum=2 * GiB, floor=20 * GiB, capacity_root=None):
        if type(maximum) is not int or maximum <= 0:
            raise OwnershipError("Invalid cache limit")
        initialize_key(root, allowed_entries={'entries', 'locks', 'staging', 'references', 'publication.lock'})
        self.root, self.maximum = root, maximum
        self.capacity = Capacity(capacity_root or admission_root(root), floor=floor)
        for name in ("entries", "locks", "staging", "references"):
            ensure_private(root / name)

    def _verify(self, entry: Path, key, specification):
        metadata = read_signed(entry / "manifest.json", self.root / "resource.key")
        inventory = tree_inventory(entry / "payload", maximum=self.maximum, immutable=True)
        # Filesystems may finalize physical block allocation after publication.
        # Keep its current measurement for capacity reporting; content identity
        # remains exact file paths, sizes, digests, modes and ownership checks.
        expected=metadata.get('inventory',{})
        stable=lambda value:{k:v for k,v in value.items() if k!='allocatedBytes'}
        if (metadata.get("version") != 1 or metadata.get("key") != key
                or hashlib.sha256(canonical_bytes(specification)).hexdigest() != key
                or metadata.get("specification") != specification
                or not isinstance(expected,dict) or stable(expected) != stable(inventory)):
            raise OwnershipError("Immutable cache content or provenance changed")
        return inventory

    def inventory(self):
        entries = {}
        for entry in sorted((self.root / "entries").iterdir()):
            if len(entry.name) != 64 or any(c not in "0123456789abcdef" for c in entry.name):
                raise OwnershipError("Unknown cache entry")
            metadata = read_signed(entry / "manifest.json", self.root / "resource.key")
            entries[entry.name] = self._verify(entry, entry.name, metadata["specification"])
        stages = {stage.name: staging_usage(stage, maximum=self.maximum + 8_000_000)
                  for stage in (self.root / "staging").iterdir()}
        return {"entries": entries, "staging": stages,
                "bytes": sum(item["bytes"] for item in [*entries.values(), *stages.values()])
                    + sum((self.root / "entries" / key / "manifest.json").stat().st_size for key in entries)}

    def _retirement_preview(self, key):
        if type(key) is not str or len(key) != 64 or any(c not in "0123456789abcdef" for c in key):
            raise OwnershipError("Invalid immutable cache identity")
        entry = self.root / "entries" / key
        metadata = read_signed(entry / "manifest.json", self.root / "resource.key")
        inventory = self._verify(entry, key, metadata["specification"])
        for reference in (self.root / "references").iterdir():
            if read_signed(reference, self.root / "resource.key").get("key") == key:
                raise OwnershipError("Cache has a live or unresolved reference")
        if any(record.get("resourceKey") == key
               for record in self.capacity.preview(0)["reservations"].values()):
            raise OwnershipError("Cache has an unresolved build reservation")
        active_process_paths(entry)
        body = {"version": 1, "key": key, "inventory": inventory,
                "manifestDigest": hashlib.sha256(canonical_bytes(metadata)).hexdigest()}
        body["previewDigest"] = hashlib.sha256(canonical_bytes(body)).hexdigest()
        return body

    def retirement_preview(self, key):
        self._checked_key(key)
        # No mutation of a held immutable input, including another process's use.
        with file_lock(self.root / "locks" / key, timeout=0):
            with file_lock(self.root / "publication.lock"):
                return self._retirement_preview(key)

    def retire(self, key, *, preview_digest):
        self._checked_key(key)
        with file_lock(self.root / "locks" / key, timeout=0):
            with file_lock(self.root / "publication.lock"):
                plan = self._retirement_preview(key)
                if plan["previewDigest"] != preview_digest:
                    raise OwnershipError("Cache retirement preview is stale")
                remove_staging(self.root / "entries" / key)
                return {"state": "retired", "key": key, "removedBytes": plan["inventory"]["bytes"]}

    @staticmethod
    def _checked_key(key):
        if type(key) is not str or len(key) != 64 or any(c not in "0123456789abcdef" for c in key):
            raise OwnershipError("Invalid immutable cache identity")

    @contextmanager
    def acquire(self, specification: dict, builder, *, peak=2 * GiB):
        key = hashlib.sha256(canonical_bytes(specification)).hexdigest()
        entry = self.root / "entries" / key
        # Holding the same per-key lock across verify/use prevents publication,
        # eviction or another installer from replacing an input during copying.
        with file_lock(self.root / "locks" / key, timeout=360):
            hit = entry.exists()
            if not hit:
                with self.capacity.reserve(peak, purpose="build", resource_key=key):
                    stage = self.root / "staging" / uuid4().hex
                    private_directory(stage)
                    private_directory(stage / "payload")
                    private_directory(stage / "scratch")
                    try:
                        builder(stage / "payload", stage / "scratch")
                        remove_staging(stage / "scratch")
                        # Validate first, then make every published inode readonly.
                        tree_inventory(stage / "payload", maximum=self.maximum)
                        for directory, children, names in os.walk(stage / "payload"):
                            for name in children + names:
                                path = Path(directory) / name
                                path.chmod(0o500 if path.is_dir() or path.stat().st_mode & 0o100 else 0o400)
                        (stage / "payload").chmod(0o500)
                        inventory = tree_inventory(stage / "payload", maximum=self.maximum, immutable=True)
                        write_signed(stage / "manifest.json", {"version": 1, "key": key,
                            "specification": specification, "inventory": inventory}, self.root / "resource.key")
                        # Independent keys can build concurrently; publication
                        # serializes the total-size check and the atomic rename.
                        with file_lock(self.root / "publication.lock"):
                            if self.inventory()["bytes"] > self.maximum:
                                raise OwnershipError("Cache limit exceeded; explicit review required")
                            os.rename(stage, entry)
                            fd = os.open(entry.parent, os.O_RDONLY)
                            try:
                                os.fsync(fd)
                            finally:
                                os.close(fd)
                    finally:
                        with file_lock(self.root / 'publication.lock'):
                            if stage.exists():
                                remove_staging(stage)
            self._verify(entry, key, specification)
            reference = self.root / "references" / uuid4().hex
            write_signed(reference, {"key": key, "pid": os.getpid(), "createdAt": int(time.time())},
                         self.root / "resource.key")
            try:
                yield {"key": key, "hit": hit, "path": entry / "payload"}
                self._verify(entry, key, specification)
            finally:
                reference.unlink()
