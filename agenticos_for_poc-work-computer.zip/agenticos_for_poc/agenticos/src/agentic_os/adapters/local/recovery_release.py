"""Actual held-to-Ready release, retaining every archived authority retirement.

Every proof is computed from current owned services/material, never supplied by
the caller. Provider/RPC work finishes before short journal/SQL publication
guards. UNKNOWN usage and original accounting stay held after release.
"""
import asyncio
from datetime import timedelta
import hashlib
from io import StringIO
from pathlib import Path
from uuid import UUID

from psycopg import sql

from .recovery_operator import migrate
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.identity.context import utcnow, iso, timestamp
from agentic_os.memory.restoration_sql import KEYS, RELATIONS, limits
from . import recovery_gate as gate
from .coordinated_backup import FILE_ROOTS, MAX_FILES
from .files import OwnershipError, private_read
from .operator import verify_operator
from .ownership import load_manifest, COMPONENTS
from .resources import ensure_private, file_lock, read_signed, tree_inventory, write_signed
from .restoration_binding import load_restoration, relocation_metadata,placement
from .restoration_privacy import load_intent, checkpoints, changes
from .recovery_checkpoints import _assert_current_owners
from .recovery_ready import PROFILE,MANAGED_PROFILE,FILE,PROOFS,certificate,release_digest


def sha(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _privacy(path, intent, admitted, deleting, consenting):
    from .restoration_privacy import EMPTY_PROFILE,empty_evidence
    if intent['profile']==EMPTY_PROFILE:
        if deleting or consenting:raise OwnershipError('Empty privacy evidence contains owner journals')
        return empty_evidence(path,intent,admitted)
    from .recovery_operator import connect_owned
    journals = {kind:{app:sha(state) for app,(_,state) in selected.items()}
        for kind,selected in (('deletion',deleting),('controls',consenting))}
    if journals != intent['journalDigests']:
        raise OwnershipError('Surviving privacy changed after cleanup')
    _assert_current_owners(path, deleting, consenting)
    try:
        complete = read_signed(path.parent/'privacy-restoration'/(intent['id']+'-complete.json'),
            path.parent/'owner.key', maximum=65536)
    except OSError:
        raise OwnershipError('Actual privacy completion is unavailable') from None
    digests = []
    with connect_owned(path, role='migrator') as db:
        limits(db)
        authority = db.execute('SELECT run_id,generation,receipt_digest,owner_count,row_count '
            'FROM os_restoration_authorities WHERE id=%s', (UUID(intent['id']),)).fetchone()
        if authority != (intent['runId'],intent['generation'],intent['backupReceiptDigest'],
                len(intent['owners']),intent['rowCount']):
            raise OwnershipError('Actual privacy authority is incomplete')
        for owner in intent['owners']:
            row = db.execute('SELECT cleanup_digest FROM os_scope_restoration_receipts '
                'WHERE id=%s AND authority_id=%s', (UUID(owner['receipt']['id']),UUID(intent['id']))).fetchone()
            if row is None:
                raise OwnershipError('Actual privacy receipt is incomplete')
            digests.append(row[0])
            actual = db.execute('SELECT relation_name,row_id,before_digest,after_digest,patch '
                'FROM os_restoration_row_plans WHERE receipt_id=%s', (UUID(owner['receipt']['id']),)).fetchall()
            expected = {(v.relation,str(v.row_id)):(v.before_digest,v.after_digest,v.patch) for v in changes(owner)}
            if {(r,str(i)):(b,a,p) for r,i,b,a,p in actual} != expected:
                raise OwnershipError('Actual privacy row plans differ')
            for change in changes(owner):
                if change.relation not in RELATIONS:
                    raise OwnershipError('Unknown privacy row plan')
                query = sql.SQL("SELECT encode(sha256(convert_to(to_jsonb(t)::text,'UTF8')),'hex') "
                    'FROM public.{} t WHERE {}=%s AND installation_id=%s AND application_id=%s '
                    'AND tenant_id=%s AND subject_id=%s').format(sql.Identifier(change.relation),
                        sql.Identifier(KEYS.get(change.relation,'id')))
                if db.execute(query, (change.row_id,*change.scope)).fetchone() != (change.after_digest,):
                    raise OwnershipError('Actual privacy post-state differs')
    if (type(complete) is not dict or set(complete) != {'profile','intentDigest','cleanupDigests','committedAt'}
            or complete['profile'] != intent['profile'] or complete['intentDigest'] != sha(intent)
            or complete['cleanupDigests'] != digests):
        raise OwnershipError('Actual privacy completion differs')
    from .recovery_sdk import restored_sdk
    sdk = restored_sdk(path)
    from .recovery_operator import connect_owned
    from agentic_os.adapters.pgvector import SCOPE
    for owner in intent['owners']:
        state = sdk.owner_snapshot(owner['subject'])
        if state['leases'] or state['queue'] or state['unboundWork']:
            raise OwnershipError('Surviving SDK cleanup is incomplete')
        with connect_owned(path, component='retrieval', role='migrator') as db:
            limits(db)
            db.execute("SELECT set_config('agentic.owner_scope',%s,true)",
                (canonical_bytes(owner['subject']).decode(),))
            for entry in owner['entries']:
                args = dict(owner['subject'],entry=UUID(entry['id']),minimum=entry['minimumVersion'])
                fence = db.execute('SELECT minimum_version,forgotten FROM personal_knowledge_fences WHERE '+SCOPE+
                    ' AND entry_id=%(entry)s', args).fetchone()
                if not fence or fence[0] < entry['minimumVersion'] or entry['forgotten'] and not fence[1]:
                    raise OwnershipError('Actual vector deletion fence is incomplete')
                if db.execute('SELECT 1 FROM personal_knowledge_vectors WHERE '+SCOPE+
                        ' AND entry_id=%(entry)s AND (entry_version<%(minimum)s OR %(forgotten)s) LIMIT 1',
                        args|dict(forgotten=fence[1])).fetchone():
                    raise OwnershipError('Old vector remains after cleanup')
    return dict(profiles=len(deleting),owners=len(intent['owners']),authorityId=intent['id'],
        intentDigest=sha(intent),journalsDigest=sha(journals))


def _materials(path, admitted, intent):
    # Operator-authorized integrity/erasure inspection. Request-time history
    # key access remains behind its separate current owner purpose guard.
    expected = admitted['materialDigests']; actual = {}
    for name in sorted(FILE_ROOTS):
        directory = path.parent/name
        if directory.exists() or directory.is_symlink():
            inventory = tree_inventory(directory, maximum=MAX_FILES)
            actual.update({name+'/'+relative:value['sha256'] for relative,value in inventory['files'].items()
                if 'sha256' in value})
    erasures = {f"artifacts/{artifact['id']}.json":(owner['subject'],artifact)
        for owner in intent['owners'] for artifact in owner['artifacts']}
    extras = set(actual)-set(expected)
    if extras - ({'artifacts/purge.lock'} if erasures else set()) or set(expected)-set(actual):
        raise OwnershipError('Restored material inventory differs')
    for name,pin in expected.items():
        if actual[name] == pin:
            if name in erasures:
                raise OwnershipError('Forgotten artifact retained original ciphertext')
            continue
        if name not in erasures:
            raise OwnershipError('Original material changed without an erasure proof')
        from .artifacts import LocalArtifacts,LocalKeys
        subject,artifact = erasures[name]
        value = LocalArtifacts(path.parent/'artifacts',LocalKeys(path.parent/'keys')).read(subject,
            artifact['id'],purpose='artifact')
        if value != canonical_bytes(dict(profile='OSDerivedArtifactErasure/1',
                sourceCiphertextDigest=artifact['ciphertextDigest'])):
            raise OwnershipError('Actual derived erasure marker differs')
    keys = {name.removeprefix('keys/')[:-4]:pin for name,pin in expected.items()
        if name.startswith('keys/') and name.endswith('.key') and '/' not in name[5:]}
    if not 1 <= len(keys) <= 128:
        raise OwnershipError('Known restored key envelope unavailable')
    from .recovery_history import pinned_keys
    pinned_keys(path.parent/'keys', keys)
    return keys,dict(archiveMaterialDigest=sha(expected),currentMaterialDigest=sha(actual),
        erasedArtifacts=len(erasures),knownKeysDigest=sha(keys))


def _retirement(path,*,production=False):
    from .recovery_operator import connect_owned
    result = dict(retiredSessions=[],retiredChallenges=[],retiredExecutions=[])
    with connect_owned(path,role='migrator') as db:
        db.rollback();db.execute('SET TRANSACTION READ ONLY');limits(db)
        for field,table in (('retiredSessions','os_interactive_sessions'),('retiredChallenges','os_embed_challenges')):
            query=sql.SQL('SELECT id FROM public.{} ORDER BY id LIMIT 4097').format(sql.Identifier(table))
            rows=db.execute(query).fetchall()
            if len(rows)>4096:raise OwnershipError('Retired identity envelope exceeded')
            result[field]=sorted(str(row[0]) for row in rows)
        installation=load_manifest(path)['installationId']
        executions=set()
        for prefix,table in (('os','os_tasks'),('os','personal_learning_jobs'),
                ('os-schedule','os_proactive_definitions'),('os-proactive-task','os_proactive_runs')):
            rows=db.execute(sql.SQL('SELECT installation_id,application_id,id FROM public.{} '
                'ORDER BY id LIMIT 4097').format(sql.Identifier(table))).fetchall()
            if len(rows)>4096 or any(str(i)!=installation for i,_,_ in rows):
                raise OwnershipError('Retired execution envelope exceeded')
            executions.update(':'.join((prefix,str(i),str(a),str(t))) for i,a,t in rows)
        if production:
            rows=db.execute("SELECT t.installation_id,t.application_id,t.id FROM os_tasks t "
                "JOIN os_budget_roots r ON r.installation_id=t.installation_id AND r.id=t.budget_root_id "
                "WHERE r.accounting_format='agent-resources/1' ORDER BY t.id LIMIT 4097").fetchall()
            if len(rows)>4096 or any(str(i)!=installation for i,_,_ in rows):
                raise OwnershipError('Retired Agent execution envelope exceeded')
            executions.update(':'.join(('os-agent',str(i),str(a),str(t))) for i,a,t in rows)
        if len(executions)>4096:raise OwnershipError('Retired execution envelope exceeded')
        result['retiredExecutions']=sorted(executions)
    return result


def _catalog(path, admitted, token, *, connection=None):
    from .recovery_runtime_checkpoint import assert_release_compatible, runtime_checkpoint,checkpoint_head
    assert_release_compatible(admitted['receipt']['runtimeCheckpoint'])
    from .coordinated_backup import component_watermark
    from .recovery_quarantine import held_inspection
    _,current,_,inspected=held_inspection(path,token,admitted['generation'],**({} if connection is None else dict(connection=connection)))
    if current!=admitted:
        raise OwnershipError('Release catalog lineage changed')
    versions={}
    from .coordinated_backup import selected_components
    components=selected_components(admitted['receipt']['profile'])
    for component in components:
        if component in {'control','retrieval','knowledge'}:
            migrate(path,component=component,check_only=True,diagnostic_stream=StringIO())
        options={}
        if load_manifest(path)['profile']=='aws-eks/1':
            from .recovery_operator import connect_owned
            options['connect']=lambda component=component:connect_owned(path,component=component,role='migrator')
        versions[component]=component_watermark(path,component,**options)['schemaVersions']
        expected=admitted['receipt']['components'][component]['after']['schemaVersions']
        if component in {'temporal','visibility'}:
            plan=inspected['schemaRelocations'][component]
            if expected.get('schema_version')!=[plan['before']]:
                raise OwnershipError('Original workflow schema relocation differs')
            expected=expected|dict(schema_version=[plan['after']])
        if versions[component]!=expected:
            raise OwnershipError('Original component schema differs')
    from .recovery_operator import connect_owned
    with connect_owned(path,role='migrator') as db:
        limits(db);head=db.execute('SELECT version_num FROM alembic_version').fetchone()
    if head != (checkpoint_head(admitted['receipt']['runtimeCheckpoint']),):
        raise OwnershipError('Explicit restored control head required')
    return dict(controlHead=head[0],components=sorted(components),digest=sha(
        dict(versions=versions,current=runtime_checkpoint(path))))


async def _receipts(path,token,generation,admitted):
    from . import production_recovery_receipts as production
    original=production.pending_effects(admitted['receipt']['runtimeCheckpoint'])
    states=[]
    if original:
        _,capsules=production.load_capsules(path,token,generation)
        for effect in capsules['effects']:
            result=await production.observe_receipt(path,token,expected_generation=generation,attempt_id=effect['handle']['id'])
            if result['unknownUsageHeld'] is not True or result['runtimeReady'] is not False or result['executionAuthorized'] is not False:
                raise OwnershipError('Original production receipt observation changed authority/accounting')
            states.append(result)
    elif (path.parent/production.FILE).exists() or (path.parent/production.FILE).is_symlink():
        raise OwnershipError('Untracked original production receipt capsules')
    pending=admitted['receipt']['runtimeCheckpoint']['pendingEffects']
    from .recovery_receipts import FILE as CAPSULE_FILE,load_capsules,observe_receipt
    if not pending:
        if (path.parent/CAPSULE_FILE).exists() or (path.parent/CAPSULE_FILE).is_symlink():
            raise OwnershipError('Untracked original receipt capsules')
    else:
        _,capsules=load_capsules(path,token,generation)
        for effect in capsules['effects']:
            result=await observe_receipt(path,token,expected_generation=generation,attempt_id=effect['handle']['id'])
            if result['unknownUsageHeld'] is not True or result['runtimeReady'] is not False:
                raise OwnershipError('Original receipt observation changed accounting')
            states.append(result)
    not_started=sum(row['state']=='NOT_STARTED' for row in states)
    result=dict(admittedEffects=len(pending)+len(original),observedEffects=len(states)-not_started,
        statesDigest=sha(states),unknownUsageHeld=True)
    if not_started:result['notStartedEffects']=not_started
    return result


async def release_restoration(path,token,*,expected_generation,privacy_intent,deletion_root,controls_root,
        valid_seconds=86400,connection=None):
    """Reconcile actual proofs, then publish the sole current Ready generation."""
    path=Path(path);verify_operator(path,token)
    if type(valid_seconds) is not int or not 5<=valid_seconds<=86400:
        raise OwnershipError('Explicit finite release lifetime required')
    if gate.state(path)['mode']=='READY':
        value=certificate(path)
        privacy=read_signed(path.parent/'recovery-release/privacy.json',path.parent/'owner.key')
        if (type(expected_generation) is not int or value['heldGeneration']!=expected_generation
                or privacy['evidence']['authorityId']!=privacy_intent):
            raise OwnershipError('Ready release generation differs')
        return dict(profile=value['profile'],state='READY',generation=value['generation'],
            retiredExecutions=len(value['retiredExecutions']),unknownUsageHeld=True)
    intent,admitted=load_intent(path,token,privacy_intent)
    if type(expected_generation) is not int or admitted['generation']!=expected_generation:
        raise OwnershipError('Release held generation differs')
    metadata=relocation_metadata(path)
    if metadata['temporal'] is None:
        raise OwnershipError('Original workflow namespace is required')
    from .recovery_metadata import CLOUD_PROFILE as CLOUD_METADATA
    if (metadata['profile']==CLOUD_METADATA)!=(connection is not None):
        raise OwnershipError('Explicit matching recovery transport required')
    if connection is not None:
        from agentic_os.adapters.aws.temporal import recovery_binding
        recovery_binding(connection,metadata['temporal'])
        if connection.installation.root!=path.parent:raise OwnershipError('Cloud release installation differs')
    def privacy_preflight():
        with checkpoints(path,admitted,deletion_root,controls_root) as (_,deleting,consenting):
            _privacy(path,intent,admitted,deleting,consenting)
    await asyncio.to_thread(privacy_preflight)
    # All provider/service awaits precede publication locks and SQL sessions.
    async with asyncio.timeout(60):
        if metadata['knowledgeKeys']:
            from .recovery_knowledge import relocate_knowledge,FILE as KNOWLEDGE_FILE
            result=await asyncio.to_thread(relocate_knowledge,path,token,expected_generation=expected_generation)
            knowledge_record=read_signed(path.parent/KNOWLEDGE_FILE,path.parent/'owner.key')
            knowledge=dict(selected=result['knowledgeKeys'],publicPurpose=result['publicKnowledge'],
                relocationDigest=sha(knowledge_record))
        else:
            if any((path.parent/name).exists() or (path.parent/name).is_symlink() for name in
                    ('protected-knowledge','knowledge-key-binding.json','knowledge-public-credential.json')):
                raise OwnershipError('Unselected restored knowledge material')
            knowledge=dict(selected=False,publicPurpose=False,relocationDigest=sha(None))
        receipts=await _receipts(path,token,expected_generation,admitted)
        from .recovery_quarantine import quarantine,FILE as QUARANTINE_FILE,control_pins
        await quarantine(path,token,expected_generation=expected_generation,**({} if connection is None else dict(connection=connection)))
    record=read_signed(path.parent/QUARANTINE_FILE,path.parent/'owner.key',maximum=2*1024**2)
    temporal=dict(namespaceId=record['original']['namespaceId'],lineageDigest=sha(record['original']),
        quarantineDigest=sha(record),workflowRuns=len(record['catalog']),originalHistoryPreserved=True)
    catalog=await asyncio.to_thread(_catalog,path,admitted,token,**({} if connection is None else dict(connection=connection)))
    manifest=load_manifest(path);now=utcnow()
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        verify_operator(path,token)
        if load_restoration(path)!=admitted or gate.state(path)['generation']!=expected_generation:
            raise OwnershipError('Release held state changed')
        if (read_signed(path.parent/QUARANTINE_FILE,path.parent/'owner.key',maximum=2*1024**2)!=record
                or control_pins(path,production='production' in admitted['receipt']['runtimeCheckpoint'])!=record['controlPins']):
            raise OwnershipError('Release quarantine changed')
        def publish_ready():
            # Final profile/journal checks still use the held operator ports.
            # Publish only afterwards, while the same journal/gate locks remain.
            current=gate._write(path,mode='READY',reason='verified')
            if current['generation']!=body['generation']:
                raise OwnershipError('Ready generation differed')
        with checkpoints(path,admitted,deletion_root,controls_root,on_verified=publish_ready) as (pins,deleting,consenting):
            privacy=_privacy(path,intent,admitted,deleting,consenting)
            keys,materials=_materials(path,admitted,intent)
            retirement=_retirement(path,production='production' in admitted['receipt']['runtimeCheckpoint'])
            body=dict(profile=MANAGED_PROFILE if manifest['profile']=='aws-eks/1' else PROFILE,installationId=manifest['installationId'],runId=manifest['runId'],
                **placement(path),generation=expected_generation+1,
                heldGeneration=expected_generation,archiveDigest=sha(admitted),receiptDigest=admitted['receiptDigest'],
                releaseDigest=release_digest(),issuedAt=iso(now),expiresAt=iso(now+timedelta(seconds=valid_seconds)),
                knownKeys=keys,proofs={},**retirement)
            if manifest['profile']=='aws-eks/1':
                from agentic_os.adapters.aws.readiness import _runtime_content
                body['contentDigest']=_runtime_content()
            evidence=dict(privacy=privacy,receipts=receipts,temporal=temporal,knowledge=knowledge,
                materials=materials,catalog=catalog)
            ensure_private(path.parent/'recovery-release')
            for kind in sorted(PROOFS):
                proof={k:body[k] for k in ({'installationId','runId','heldGeneration','receiptDigest'}|set(placement(path)))}
                proof.update(profile='restored-managed-release-proof/1' if manifest['profile']=='aws-eks/1' else 'restored-release-proof/1',kind=kind,complete=True,evidence=evidence[kind])
                destination=path.parent/'recovery-release'/(kind+'.json')
                if destination.exists() or destination.is_symlink():
                    if read_signed(destination,path.parent/'owner.key',maximum=128*1024)!=proof:
                        raise OwnershipError('Pending release proof changed')
                else:write_signed(destination,proof,path.parent/'owner.key')
                body['proofs'][kind]=sha(proof)
            marker=path.parent/FILE
            if marker.exists() or marker.is_symlink():
                prior=read_signed(marker,path.parent/'owner.key',maximum=1024**2)
                if (type(prior) is not dict or set(prior)!=set(body)
                        or any(prior[k]!=body[k] for k in body if k not in {'issuedAt','expiresAt'})
                        or timestamp(prior['expiresAt'])<=now):
                    raise OwnershipError('Pending release certificate changed or expired')
                body=prior
            else:write_signed(marker,body,path.parent/'owner.key')
            # Certificate-first failure remains BLOCKED. The locked checkpoint
            # exit authenticates the final profiles/journals before publication.
    value=certificate(path)
    return dict(profile=value['profile'],state='READY',generation=value['generation'],
        retiredExecutions=len(value['retiredExecutions']),unknownUsageHeld=True)
