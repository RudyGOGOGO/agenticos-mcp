"""Bounded, encrypted component snapshots with independent recovery material.

Components have separate clocks/watermarks. This never asserts an atomic global
snapshot. Restoration publishes a held installation; access requires a separate
current-controls/receipt reconciliation, including the surviving journal.
"""
import hashlib
import hmac
from pathlib import Path
import secrets
import time
import re
from contextlib import contextmanager
from uuid import uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from psycopg import sql

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from .artifacts import checked_id
from .backup import READ_SECRET
from .docker import DockerControl, DockerOperationError
from .files import OwnershipError, private_directory, private_read, private_write, check_private
from .operator import verify_operator
from .ownership import COMPONENTS
from .resources import canonical_path, file_lock, tree_inventory
from .target import connect_owned, validate_target
from . import recovery_gate as gate

PROFILE = 'coordinated-recovery/2'
CLOUD_PROFILE = 'coordinated-cloud-recovery/1'
MANAGED_PROFILE = 'coordinated-managed-recovery/1'
CLOUD_COMPONENTS = tuple(name for name in COMPONENTS if name not in {'temporal','visibility'})
LEGACY_PROFILE = 'coordinated-recovery/1'
MAX_COMPONENT = 64*1024**2
MAX_FILES = 128*1024**2
MAX_DATABASES = 1024**3
MAX_MATERIAL_FILES = 4096
FILE_ROOTS = {'keys', 'artifacts', 'credentials', 'protected-knowledge', 'recovery-metadata'}
RECEIPT_FIELDS = {'version', 'profile', 'id', 'installationId', 'sourceRunId',
    'startedAtNs', 'completedAtNs', 'components', 'files', 'journalCheckpoints'}
LEGACY_FIELDS = set(RECEIPT_FIELDS)
RECEIPT_FIELDS |= {'controlsCheckpoints', 'sourceGate', 'runtimeCheckpoint'}


def selected_components(profile):
    if type(profile) is not str:raise OwnershipError('Recovery component profile unavailable')
    if profile==MANAGED_PROFILE:return ('control','retrieval','knowledge')
    if profile==CLOUD_PROFILE:return CLOUD_COMPONENTS
    if profile in {PROFILE,LEGACY_PROFILE}:return COMPONENTS
    raise OwnershipError('Recovery component profile unavailable')


def failure_diagnostic(stage, component, error):
    """Fixed failure metadata; exception text/commands/private rows stay out."""
    if stage not in {'runtime-checkpoint', 'component-dump', 'component-watermark',
            'protected-material', 'final-reconciliation'} or component not in {*COMPONENTS, None}:
        raise OwnershipError('Unknown recovery diagnostic stage')
    category = 'operation-unavailable'
    if isinstance(error, DockerOperationError) and error.category in {
            'deadline-exceeded', 'cli-unavailable', 'transport-eof', 'transport-reset',
            'transport-unavailable', 'operation-rejected', 'output-envelope-exceeded'}:
        category = error.category
    return dict(profile='recovery-failure/1', status='failed', stage=stage,
        component=component, category=category)


def component_watermark(path,component,*,connect=None):
    connection=connect_owned(path,component=component,role='migrator') if connect is None else connect()
    with connection as db:
        db.rollback();db.execute('SET TRANSACTION READ ONLY')
        db.execute("SET LOCAL lock_timeout='2s'")
        db.execute("SET LOCAL statement_timeout='3s'")
        names = [row[0] for row in db.execute(
            "SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename")]
        counts = {name: db.execute(sql.SQL('SELECT count(*) FROM {}').format(sql.Identifier(name))).fetchone()[0]
            for name in names}
        fingerprints = {}
        for name in names:
            if counts[name] > 1_000_000:
                raise OwnershipError('Component row envelope exceeded')
            digest = hashlib.sha256()
            with db.cursor(name='snapshot_fingerprint') as cursor:
                cursor.execute(sql.SQL('SELECT to_jsonb(t)::text FROM {} t ORDER BY to_jsonb(t)::text').format(sql.Identifier(name)))
                for (row,) in cursor:
                    encoded = row.encode()
                    if len(encoded) > MAX_COMPONENT:
                        raise OwnershipError('Component row envelope exceeded')
                    digest.update(len(encoded).to_bytes(8, 'big')+encoded)
            fingerprints[name] = digest.hexdigest()
        versions = {}
        for name in ('alembic_version', 'schema_version', 'agents_api_schema_version'):
            if name in names:
                versions[name] = [[str(value) for value in row] for row in db.execute(
                    sql.SQL('SELECT * FROM {} ORDER BY 1').format(sql.Identifier(name))).fetchall()]
        lsn, transaction, size = db.execute('SELECT pg_current_wal_lsn()::text, '
            'txid_current_snapshot()::text, pg_database_size(current_database())').fetchone()
    return dict(observedAtNs=str(time.time_ns()), walLsn=lsn, transactionSnapshot=transaction,
        counts=counts, rowDigests=fingerprints, schemaVersions=versions, databaseBytes=size)


@contextmanager
def _admission(path, *, capacity_root, restoring):
    from .build_cache import cache_root, admission_root
    from .capacity import Capacity, GiB, docker_headroom
    from .ownership import load_manifest
    root = canonical_path(path.parent)
    ledger = canonical_path(Path(capacity_root) if capacity_root is not None
        else admission_root(cache_root(root)))
    # A ledger on a different volume cannot admit growth in this installation.
    parent = ledger
    while not parent.exists():
        parent = parent.parent
    if parent.stat().st_dev != root.stat().st_dev:
        raise OwnershipError('Recovery capacity ledger must share the installation volume')
    capacity = Capacity(ledger)
    manifest = load_manifest(path)
    # The bounded profile allows at most1GiB of source database storage. The
    # restore estimate includes database expansion, indexes and retained WAL;
    # this remains an estimated peak, not a filesystem allocation guarantee.
    remote=manifest['profile']=='aws-eks/1'
    docker_free=None if remote else docker_headroom(manifest['dockerEndpoint'],manifest['postgres']['image'])
    with capacity.reserve(GiB,purpose='installation' if restoring else 'artifact',
            docker_free=docker_free,docker_peak=0 if remote else 3*GiB if restoring else GiB):
        yield


def surviving_checkpoints(path, journal_root, controls_root=None):
    from .recovery_checkpoints import snapshot_checkpoints
    with snapshot_checkpoints(path, journal_root, controls_root) as checkpoints:
        return checkpoints


def _encrypt(key, content, binding):
    nonce = secrets.token_bytes(12)
    return nonce+AESGCM(key).encrypt(nonce, content, canonical_bytes(binding))


def _decrypt(key, content, binding):
    try:
        return AESGCM(key).decrypt(content[:12], content[12:], canonical_bytes(binding))
    except Exception:
        raise OwnershipError('Recovery payload authentication failed') from None


def _binding(ident, installation, kind, *, profile=PROFILE):
    return dict(profile=profile, snapshotId=ident, installationId=installation, component=kind)


def _clock(value):
    return type(value) is str and re.fullmatch(r'[1-9][0-9]{0,19}', value) is not None


def _digest(value):
    return type(value) is str and re.fullmatch(r'[a-f0-9]{64}', value) is not None


def _watermark(value):
    if (type(value) is not dict or set(value) != {'observedAtNs', 'walLsn', 'transactionSnapshot',
            'counts', 'rowDigests', 'schemaVersions', 'databaseBytes'} or not _clock(value['observedAtNs'])
            or type(value['databaseBytes']) is not int or not 0 <= value['databaseBytes'] <= MAX_DATABASES
            or type(value['walLsn']) is not str or re.fullmatch(r'[0-9A-F]+/[0-9A-F]+', value['walLsn']) is None
            or type(value['transactionSnapshot']) is not str
            or re.fullmatch(r'[0-9]+:[0-9]+:([0-9]+(,[0-9]+)*)?', value['transactionSnapshot']) is None
            or type(value['counts']) is not dict or type(value['rowDigests']) is not dict
            or set(value['counts']) != set(value['rowDigests']) or len(value['counts']) > 512
            or type(value['schemaVersions']) is not dict):
        raise OwnershipError('Component watermark unavailable')
    for name, count in value['counts'].items():
        if (re.fullmatch(r'[a-z_][a-z0-9_]{0,62}', name) is None
                or type(count) is not int or not 0 <= count <= 1_000_000 or not _digest(value['rowDigests'][name])):
            raise OwnershipError('Component watermark unavailable')
    if set(value['schemaVersions']) - {'alembic_version', 'schema_version', 'agents_api_schema_version'}:
        raise OwnershipError('Component schema watermark unavailable')
    for rows in value['schemaVersions'].values():
        if (type(rows) is not list or len(rows) > 128
                or any(type(row) is not list or len(row) > 16
                    or any(type(v) is not str or len(v) > 256 for v in row) for row in rows)):
            raise OwnershipError('Component schema watermark unavailable')


def _files(root, *, metadata=None):
    files = {}
    total = 0
    for name in sorted(FILE_ROOTS):
        directory = root/name
        if not directory.exists():
            continue
        inventory = tree_inventory(directory, maximum=MAX_FILES)
        total += inventory['bytes']
        if total > MAX_FILES:
            raise OwnershipError('Snapshot material envelope exceeded')
        for relative, record in inventory['files'].items():
            if 'sha256' in record:
                content = private_read(directory/relative, MAX_FILES)
                if hashlib.sha256(content).hexdigest() != record['sha256']:
                    raise OwnershipError('Snapshot material changed')
                # Encode only inside the authenticated encrypted material payload.
                import base64
                files[name+'/'+relative] = base64.b64encode(content).decode('ascii')
                if len(files) >= MAX_MATERIAL_FILES:
                    raise OwnershipError('Snapshot material file envelope exceeded')
    if metadata is not None:
        import base64
        from .recovery_metadata import FILE
        files[FILE] = base64.b64encode(metadata).decode('ascii')
    return files


def _validated_material(content):
    import base64
    from agentic_os.contracts.canonical import CanonicalError
    try:
        files = parse_canonical_json(content)
        if type(files) is not dict or len(files) > MAX_MATERIAL_FILES:
            raise OwnershipError('Recovery material unavailable')
        validated, total = {}, 0
        for name, value in files.items():
            if type(name) is not str or type(value) is not str:
                raise OwnershipError('Recovery material unavailable')
            relative = Path(name)
            if (relative.is_absolute() or '..' in relative.parts or len(relative.parts) < 2
                    or relative.parts[0] not in FILE_ROOTS or relative.as_posix() != name):
                raise OwnershipError('Recovery material path refused')
            validated[name] = base64.b64decode(value, validate=True)
            total += len(validated[name])
            if total > MAX_FILES:
                raise OwnershipError('Recovery material envelope exceeded')
        return validated
    except (CanonicalError, ValueError, TypeError):
        raise OwnershipError('Recovery material unavailable') from None


def snapshot(path, token, *, recovery_key, journal_root, controls_root=None, capacity_root=None):
    path = Path(path)
    verify_operator(path, token)
    from .recovery_metadata import cloud_source_selected
    if cloud_source_selected(path):raise OwnershipError('Explicit original Cloud source snapshot required')
    with _admission(path, capacity_root=capacity_root, restoring=False):
        return _snapshot(path, token, recovery_key=recovery_key, journal_root=journal_root, controls_root=controls_root)


async def snapshot_cloud(path,token,*,connection,recovery_key,journal_root,controls_root=None,capacity_root=None,expected_generation=None):
    """Owned OS-store snapshot; Cloud persistence stays at its original service."""
    from agentic_os.adapters.temporal.connection import TemporalConnection
    from agentic_os.adapters.aws.temporal import inspect_parked_history
    from .host_credentials import FileCredentials
    path=Path(path);verify_operator(path,token)
    if type(connection) is not TemporalConnection or connection.installation.root!=path.parent:
        raise OwnershipError('Cloud recovery installation differs')
    if type(connection.installation.credentials) is not FileCredentials:
        raise OwnershipError('Configured remote OS stores require their own snapshot adapter')
    generation=gate.state(path)['generation']
    if expected_generation is not None and (type(expected_generation) is not int or expected_generation!=generation):
        raise OwnershipError('Original Cloud source generation differs')
    with _admission(path,capacity_root=capacity_root,restoring=False):
        capture=await inspect_parked_history(connection,token,expected_generation=generation)
        return _snapshot(path,token,recovery_key=recovery_key,journal_root=journal_root,
            controls_root=controls_root,cloud_capture=capture)


def _snapshot(path, token, *, recovery_key, journal_root, controls_root=None, held=False,cloud_capture=None):
    path = Path(path)
    verify_operator(path, token)
    recovery_key = canonical_path(Path(recovery_key))
    if recovery_key.is_relative_to(path.parent):
        raise OwnershipError('Recovery key must have independent protected placement')
    if recovery_key.exists() or recovery_key.is_symlink():
        raise OwnershipError('New independent recovery key required')
    manifest = validate_target(path, role='migrator')
    docker = DockerControl(manifest)
    profile=CLOUD_PROFILE if cloud_capture is not None else PROFILE
    components=selected_components(profile)
    with file_lock(path.parent/'recovery-gate.lock', timeout=2):
        if not gate.selected(path):
            raise OwnershipError('Explicit operator hold required before snapshot')
        source_gate = gate.state(path)
        if source_gate['mode'] != ('BLOCKED' if held else 'PARKED'):
            raise OwnershipError('Explicit operator hold required before snapshot')
        # All component runtime roles must be idle/stopped. Temporal/Core writers
        # do not participate in the OS file lock and must be stopped separately.
        for component in components:
            with connect_owned(path, component=component, role='migrator') as db:
                active = db.execute('SELECT count(*) FROM pg_stat_activity '
                    'WHERE datname=current_database() AND pid<>pg_backend_pid() '
                    ).fetchone()[0]
                if active:
                    raise OwnershipError('Component activity blocks parked snapshot')
        from .recovery_checkpoints import snapshot_checkpoints
        destination = None
        try:
            with snapshot_checkpoints(path, journal_root, controls_root, require_current=not held) as checkpoints:
                before_all = {component: component_watermark(path, component) for component in components}
                if sum(value['databaseBytes'] for value in before_all.values()) > MAX_DATABASES:
                    raise OwnershipError('Snapshot database storage envelope exceeded')
                from .recovery_metadata import metadata_bytes
                material_metadata = metadata_bytes(path, held=held,cloud_capture=cloud_capture)
                if cloud_capture is not None and not held:
                    from .recovery_metadata import bind_cloud_source
                    bind_cloud_source(path,cloud_capture)
                key = AESGCM.generate_key(bit_length=256)
                ident = str(uuid4())
                destination = path.parent/'backups'/ident
                private_directory(destination)
                private_write(recovery_key, key)
                from .recovery_runtime_checkpoint import runtime_checkpoint
                stage, selected_component = 'runtime-checkpoint', None
                try:
                    receipt = dict(version=3 if profile==CLOUD_PROFILE else 2, profile=profile, id=ident,
                        installationId=manifest['installationId'], sourceRunId=manifest['runId'],
                        startedAtNs=str(time.time_ns()), completedAtNs='0', components={}, files={},
                        sourceGate=dict(generation=source_gate['generation'], mode=source_gate['mode']),
                        runtimeCheckpoint=runtime_checkpoint(path), **checkpoints)
                    if cloud_capture is not None and cloud_capture['runtimeCheckpoint']!=receipt['runtimeCheckpoint']:
                        raise OwnershipError('Cloud source control checkpoint changed')
                    for component in components:
                        stage, selected_component = 'component-dump', component
                        before = before_all[component]
                        definition = manifest['databases'][component]
                        content = docker.binary('exec', '-i', manifest['postgres']['container'], 'sh', '-c', READ_SECRET,
                            '--', 'pg_dump', '--host', '127.0.0.1', '--username', definition['migrator'],
                            '--dbname', definition['name'], '--format=custom', '--no-owner', '--no-acl', '--no-comments',
                            input=(definition['migratorPassword']+'\n').encode(), max_bytes=MAX_COMPONENT)
                        stage = 'component-watermark'
                        after = component_watermark(path, component)
                        if any(before[k] != after[k] for k in ('counts', 'rowDigests', 'schemaVersions')):
                            raise OwnershipError('Component changed during snapshot')
                        encrypted = _encrypt(key, content, _binding(ident, manifest['installationId'], component,profile=profile))
                        private_write(destination/(component+'.bin'), encrypted)
                        receipt['components'][component] = dict(before=before, after=after,
                            ciphertextDigest=hashlib.sha256(encrypted).hexdigest(), plaintextBytes=len(content))
                    stage, selected_component = 'protected-material', None
                    content = canonical_bytes(_files(path.parent, metadata=material_metadata))
                    if len(content) > 2*MAX_FILES:
                        raise OwnershipError('Encoded material envelope exceeded')
                    encrypted = _encrypt(key, content, _binding(ident, manifest['installationId'], 'files',profile=profile))
                    private_write(destination/'files.bin', encrypted)
                    receipt['files'] = dict(ciphertextDigest=hashlib.sha256(encrypted).hexdigest(), plaintextBytes=len(content))
                    if metadata_bytes(path, held=held,cloud_capture=cloud_capture) != material_metadata:
                        raise OwnershipError('Relocation metadata changed during snapshot')
                    stage = 'final-reconciliation'
                    for component in components:
                        selected_component = component
                        after = component_watermark(path, component)
                        before = before_all[component]
                        if any(before[k] != after[k] for k in ('counts', 'rowDigests', 'schemaVersions')):
                            raise OwnershipError('Component changed during coordinated snapshot')
                        receipt['components'][component]['after'] = after
                    if sum(record['after']['databaseBytes'] for record in receipt['components'].values()) > MAX_DATABASES:
                        raise OwnershipError('Snapshot database storage envelope exceeded')
                    if runtime_checkpoint(path) != receipt['runtimeCheckpoint']:
                        raise OwnershipError('Runtime checkpoint changed during snapshot')
                    if canonical_bytes(_files(path.parent, metadata=material_metadata)) != content:
                        raise OwnershipError('Protected material changed during snapshot')
                    receipt['completedAtNs'] = str(time.time_ns())
                    if len(canonical_bytes(receipt)) > 1024**2:
                        raise OwnershipError('Recovery receipt envelope exceeded')
                    private_write(destination/'receipt.json', canonical_bytes(dict(receipt=receipt,
                        signature=hmac.digest(key, canonical_bytes(receipt), 'sha256').hex())))
                except BaseException as error:
                    private_write(destination/'failure.json', canonical_bytes(
                        failure_diagnostic(stage, selected_component, error)))
                    private_write(destination/'snapshot-blocked', b'Incomplete snapshot; retained for operator diagnosis')
                    raise
                return destination
        except BaseException:
            if destination is not None and not (destination/'snapshot-blocked').exists():
                private_write(destination/'snapshot-blocked', b'Incomplete snapshot; retained for operator diagnosis')
            raise


def read_snapshot(directory, recovery_key):
    directory, recovery_key = canonical_path(Path(directory)), canonical_path(Path(recovery_key))
    check_private(directory, directory=True)
    checked_id(directory.name)
    if (directory/'snapshot-blocked').exists() or (directory/'snapshot-blocked').is_symlink():
        raise OwnershipError('Incomplete snapshot refused')
    if recovery_key.is_relative_to(directory):
        raise OwnershipError('Recovery material is not independently placed')
    key = private_read(recovery_key, 32)
    if len(key) != 32:
        raise OwnershipError('Recovery key unavailable')
    value = parse_canonical_json(private_read(directory/'receipt.json', 2*1024**2))
    if type(value) is not dict or set(value) != {'receipt', 'signature'}:
        raise OwnershipError('Recovery receipt unavailable')
    receipt = value['receipt']
    if (type(receipt) is not dict or set(receipt) != (LEGACY_FIELDS if receipt.get('profile') == LEGACY_PROFILE else RECEIPT_FIELDS)
            or type(value['signature']) is not str
            or not hmac.compare_digest(value['signature'], hmac.digest(key, canonical_bytes(receipt), 'sha256').hex())
            or type(receipt['version']) is not int or type(receipt['profile']) is not str
            or (receipt['profile'], receipt['version']) not in {(LEGACY_PROFILE, 1), (PROFILE, 2),(CLOUD_PROFILE,3)} or receipt['id'] != directory.name
            or type(receipt['components']) is not dict or set(receipt['components']) != set(selected_components(receipt['profile']))):
        raise OwnershipError('Recovery receipt authentication failed')
    checked_id(receipt['installationId'])
    if (not _clock(receipt['startedAtNs']) or not _clock(receipt['completedAtNs'])
            or int(receipt['startedAtNs']) > int(receipt['completedAtNs'])):
        raise OwnershipError('Recovery clocks unavailable')
    if (type(receipt['sourceRunId']) is not str or re.fullmatch(r'[a-f0-9]{12}', receipt['sourceRunId']) is None
            or type(receipt['journalCheckpoints']) is not list or len(receipt['journalCheckpoints']) > 128):
        raise OwnershipError('Recovery checkpoint unavailable')
    applications = set()
    for record in receipt['journalCheckpoints']:
        if (type(record) is not dict or set(record) != {'applicationId', 'journalId', 'keyDigest', 'sequence'}
                or not _digest(record['keyDigest']) or type(record['sequence']) is not int
                or not 0 <= record['sequence'] <= 2**53-1):
            raise OwnershipError('Recovery checkpoint unavailable')
        checked_id(record['applicationId']); checked_id(record['journalId'])
        if record['applicationId'] in applications:
            raise OwnershipError('Duplicate recovery checkpoint')
        applications.add(record['applicationId'])
    if receipt['profile'] in {PROFILE,CLOUD_PROFILE}:
        from .recovery_checkpoints import checked_records
        from .recovery_runtime_checkpoint import checked_runtime_checkpoint
        checked_records(receipt['journalCheckpoints']); checked_records(receipt['controlsCheckpoints'])
        source_gate = receipt['sourceGate']
        if (type(source_gate) is not dict or set(source_gate) != {'generation', 'mode'}
                or type(source_gate['generation']) is not int or not 1 <= source_gate['generation'] <= 2**53-1
                or type(source_gate['mode']) is not str or source_gate['mode'] not in {'PARKED', 'BLOCKED'}):
            raise OwnershipError('Original source hold unavailable')
        checked_runtime_checkpoint(receipt['runtimeCheckpoint'])
        deleting = {p['applicationId']: p for p in receipt['journalCheckpoints']}
        if any(p['applicationId'] not in deleting or p['journalId'] == deleting[p['applicationId']]['journalId']
                or p['keyDigest'] == deleting[p['applicationId']]['keyDigest'] for p in receipt['controlsCheckpoints']):
            raise OwnershipError('Independent privacy checkpoint lineage differs')
    result = {}
    for name in (*selected_components(receipt['profile']), 'files'):

        record = receipt['files'] if name == 'files' else receipt['components'][name]
        if (type(record) is not dict or set(record) != ({'ciphertextDigest', 'plaintextBytes'} if name == 'files'
                else {'ciphertextDigest', 'plaintextBytes', 'before', 'after'})
                or not _digest(record['ciphertextDigest']) or type(record['plaintextBytes']) is not int
                or not 0 <= record['plaintextBytes'] <= (2*MAX_FILES if name == 'files' else MAX_COMPONENT)):
            raise OwnershipError('Recovery component metadata unavailable')
        if name != 'files':
            for field in ('before', 'after'):
                _watermark(record[field])
            if (int(record['before']['observedAtNs']) > int(record['after']['observedAtNs'])
                    or any(record['before'][k] != record['after'][k] for k in ('counts', 'rowDigests', 'schemaVersions'))):
                raise OwnershipError('Recovery component watermark changed')
        content = private_read(directory/(name+'.bin'), (2*MAX_FILES if name == 'files' else MAX_COMPONENT)+28)
        if hashlib.sha256(content).hexdigest() != record['ciphertextDigest']:
            raise OwnershipError('Recovery component corrupted')
        result[name] = _decrypt(key, content, _binding(receipt['id'], receipt['installationId'], name, profile=receipt['profile']))
        if len(result[name]) != record['plaintextBytes']:
            raise OwnershipError('Recovery component size changed')
    if any(sum(record[field]['databaseBytes'] for record in receipt['components'].values()) > MAX_DATABASES
            for field in ('before', 'after')):
        raise OwnershipError('Recovery database storage envelope exceeded')
    material = _validated_material(result['files'])
    if receipt['profile'] in {PROFILE,CLOUD_PROFILE}:
        from .recovery_metadata import FILE, checked_metadata,CLOUD_PROFILE as CLOUD_METADATA
        if FILE not in material:
            raise OwnershipError('Selected relocation metadata missing')
        metadata=checked_metadata(parse_canonical_json(material[FILE]), receipt['installationId'], receipt['sourceRunId'])
        if (metadata['profile']==CLOUD_METADATA)!=(receipt['profile']==CLOUD_PROFILE):
            raise OwnershipError('Recovery metadata and component profiles differ')
    return receipt, result


def restore_into_empty(directory, recovery_key, *, target, token, capacity_root=None):
    target = Path(target)
    verify_operator(target, token)
    with _admission(target, capacity_root=capacity_root, restoring=True):
        return _restore_into_empty(directory, recovery_key, target=target, token=token)


def _restore_into_empty(directory, recovery_key, *, target, token):
    verify_operator(Path(target), token)
    receipt, payload = read_snapshot(directory, recovery_key)
    target = Path(target)
    manifest = validate_target(target, role='migrator')
    if manifest['installationId'] != receipt['installationId']:
        raise OwnershipError('Recovery installation differs')
    for component in COMPONENTS:
        if component_watermark(target, component)['counts']:
            raise OwnershipError('Recovery requires empty component stores')
    for name in FILE_ROOTS:
        if (target.parent/name).exists() and list((target.parent/name).iterdir()):
            raise OwnershipError('Recovery requires empty material stores')
    validated = _validated_material(payload['files'])
    from .recovery_metadata import FILE, checked_metadata
    if receipt['profile'] in {PROFILE,CLOUD_PROFILE}:
        if FILE not in validated:
            raise OwnershipError('Selected relocation metadata missing')
        checked_metadata(parse_canonical_json(validated[FILE]), receipt['installationId'], receipt['sourceRunId'])
    docker = DockerControl(manifest)
    with file_lock(target.parent/'recovery-gate.lock', timeout=2):
        gate._write(target, mode='RESTORING', reason='restore')
        try:
            for component in selected_components(receipt['profile']):
                definition = manifest['databases'][component]
                docker.binary('exec', '-i', manifest['postgres']['container'], 'sh', '-c', READ_SECRET,
                    '--', 'pg_restore', '--host', '127.0.0.1', '--username', definition['migrator'],
                    '--dbname', definition['name'], '--no-owner', '--no-acl', '--no-comments',
                    '--single-transaction', '--exit-on-error', input=(definition['migratorPassword']+'\n').encode()+payload[component])
                restored = component_watermark(target, component)
                before = receipt['components'][component]['before']
                if any(restored[k] != before[k] for k in ('counts', 'rowDigests', 'schemaVersions')):
                    raise OwnershipError('Restored component reconciliation failed')
            for name, content in validated.items():
                destination = target.parent/name
                for parent in reversed(destination.parents):
                    if parent.is_relative_to(target.parent) and not parent.exists():
                        private_directory(parent)
                private_write(destination, content)
            from agentic_os.adapters.postgres.migrate import metadata_permissions
            for component in selected_components(receipt['profile']):
                metadata_permissions(target, component)
            from .restoration_binding import publish_restoration
            blocked = gate._write(target, mode='BLOCKED', reason='reconciliation-required')
            publish_restoration(target, receipt, blocked['generation'], validated)
        except BaseException:
            gate._write(target, mode='BLOCKED', reason='reconciliation-required')
            raise
    return dict(profile=receipt['profile'], state='BLOCKED', enabledLanes=[], snapshotId=receipt['id'])



def held_snapshot(path, token, *, recovery_key, journal_root, controls_root=None, capacity_root=None):
    """Protect an already blocked copy without changing its held generation."""
    path = Path(path)
    verify_operator(path, token)
    with _admission(path, capacity_root=capacity_root, restoring=False):
        return _snapshot(path, token, recovery_key=recovery_key, journal_root=journal_root,
            controls_root=controls_root, held=True)


async def held_snapshot_cloud(path,token,*,connection,recovery_key,journal_root,controls_root=None,
        capacity_root=None,expected_generation):
    """Resnapshot only the held owned OS stores, retaining original Cloud history."""
    from agentic_os.adapters.temporal.connection import TemporalConnection
    from agentic_os.adapters.aws.temporal import inspect_held_history
    from .host_credentials import FileCredentials
    from .recovery_operator import held_operator
    path=Path(path);verify_operator(path,token)
    if (type(connection) is not TemporalConnection or connection.installation.root!=path.parent
            or type(connection.installation.credentials) is not FileCredentials):
        raise OwnershipError('Explicit owned Cloud recovery installation required')
    with held_operator(path,token,expected_generation=expected_generation):pass
    with _admission(path,capacity_root=capacity_root,restoring=False):
        capture=await inspect_held_history(connection,token,expected_generation=expected_generation)
        return _snapshot(path,token,recovery_key=recovery_key,journal_root=journal_root,
            controls_root=controls_root,held=True,cloud_capture=capture)


def resume_original_source(path, token, *, directory, recovery_key, journal_root,
        controls_root=None, expected_generation):
    """Verify the exact original parked source; no restored-target READY path."""
    path = Path(path)
    verify_operator(path, token)
    from .recovery_metadata import cloud_source_selected
    if cloud_source_selected(path):raise OwnershipError('Original Cloud source remains parked; local resume unavailable')
    receipt, payload = read_snapshot(directory, recovery_key)
    manifest = validate_target(path, role='migrator')
    if (receipt['profile'] != PROFILE or receipt['sourceGate']['mode'] != 'PARKED'
            or receipt['installationId'] != manifest['installationId'] or receipt['sourceRunId'] != manifest['runId']
            or type(expected_generation) is not int or expected_generation != receipt['sourceGate']['generation']
            or (path.parent/'recovery-snapshot.json').exists() or (path.parent/'recovery-snapshot.json').is_symlink()):
        raise OwnershipError('Exact original source snapshot required')
    from .recovery_checkpoints import snapshot_checkpoints
    from .recovery_runtime_checkpoint import runtime_checkpoint
    with file_lock(path.parent/'recovery-gate.lock', timeout=2):
        current = gate.state(path)
        if current['mode'] != 'PARKED' or current['generation'] != expected_generation:
            raise OwnershipError('Original source generation differs')
        with snapshot_checkpoints(path, journal_root, controls_root, require_current=True) as checkpoints:
            if any(receipt[k] != v for k, v in checkpoints.items()):
                raise OwnershipError('Original surviving controls changed')
            for component in COMPONENTS:
                observed = component_watermark(path, component)
                expected = receipt['components'][component]['after']
                if any(observed[k] != expected[k] for k in ('counts', 'rowDigests', 'schemaVersions')):
                    raise OwnershipError('Original source component changed')
            from .recovery_metadata import metadata_bytes
            if canonical_bytes(_files(path.parent, metadata=metadata_bytes(path))) != payload['files']:
                raise OwnershipError('Original source protected material changed')
            if runtime_checkpoint(path) != receipt['runtimeCheckpoint']:
                raise OwnershipError('Original source runtime checkpoint changed')
        return gate._write(path, mode='READY', reason='verified')
