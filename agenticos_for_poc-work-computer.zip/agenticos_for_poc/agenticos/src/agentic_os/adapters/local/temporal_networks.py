"""Explicit small owned subnets; no daemon reconfiguration or network adoption."""
import ipaddress
import json
import time

from .files import OwnershipError

PRIVATE = tuple(ipaddress.ip_network(value) for value in
                ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16'))


def checked_subnets(value):
    if type(value) is not dict or set(value) != {'private', 'rpc'}:
        raise OwnershipError('Explicit Temporal subnet pair required')
    networks = []
    try:
        for name in ('private', 'rpc'):
            if type(value[name]) is not str:
                raise ValueError()
            network = ipaddress.ip_network(value[name], strict=True)
            if (network.version != 4 or network.prefixlen != 29
                    or str(network) != value[name]
                    or not any(network.subnet_of(pool) for pool in PRIVATE)):
                raise ValueError()
            networks.append(network)
        if networks[0].overlaps(networks[1]):
            raise ValueError()
    except ValueError:
        raise OwnershipError('Temporal requires two distinct canonical private /29 subnets') from None
    return dict(value)


def network_inventory(docker):
    """Read complete bounded metadata; never adopt or mutate resources."""
    deadline=time.monotonic()+20
    metadata=getattr(docker,'network_metadata',None)
    if callable(metadata):
        # GET /networks is the complete unfiltered Engine inventory. Reuse its
        # existing bounded transport instead of starting a CLI for every page.
        records=metadata(deadline=deadline)
        if (type(records) is not list or len(records)>2048
                or any(type(row) is not dict for row in records)):
            raise OwnershipError('Docker network inventory exceeds the bounded profile')
        identities=[row.get('Id')for row in records]
        if (any(type(item) is not str or len(item)!=64
                or any(c not in '0123456789abcdef'for c in item)for item in identities)
                or len(set(identities))!=len(identities)):
            raise OwnershipError('Docker network inventory identity changed')
        return _network_addresses(records,deadline)
    return _command_inventory(docker,deadline)


def _command_inventory(docker,deadline):
    """Retain the existing command-port adapter and its exact page validation."""
    identities = docker.command('network', 'ls', '--quiet', '--no-trunc',timeout=5).splitlines()
    # Retained verification networks can exceed1024 without being active.
    # Bound the complete read to2048 identities/128 per page and20 seconds;
    # never truncate the inventory or infer that later addresses are free.
    if (len(identities) > 2048 or len(set(identities)) != len(identities)
            or any(len(item) != 64 or any(c not in '0123456789abcdef' for c in item)
                   for item in identities)):
        raise OwnershipError('Docker network inventory exceeds the bounded profile')
    records = []
    for offset in range(0, len(identities), 128):
        page = identities[offset:offset+128]
        remaining=deadline-time.monotonic()
        if remaining<=0:raise OwnershipError('Docker network inventory exceeded its deadline')
        try:inspected = json.loads(docker.command('network', 'inspect', *page,timeout=min(5,remaining)))
        except ValueError:
            raise OwnershipError('Docker network inventory identity changed') from None
        if (type(inspected) is not list or len(inspected) != len(page)
                or any(type(row) is not dict for row in inspected)
                or {row.get('Id') for row in inspected} != set(page)):
            raise OwnershipError('Docker network inventory identity changed')
        records.extend(inspected)
    return _network_addresses(records,deadline)


def _network_addresses(records,deadline):
    if time.monotonic()>=deadline:raise OwnershipError('Docker network inventory exceeded its deadline')
    networks = []
    try:
        for record in records:
            for configuration in record['IPAM']['Config'] or []:
                networks.append(ipaddress.ip_network(configuration['Subnet'], strict=True))
    except (KeyError, TypeError, ValueError):
        raise OwnershipError('Docker network address inventory is unqualified') from None
    return networks


def available_subnets(docker, value):
    """Reject existing allocations before any creation; Docker also checks races."""
    value = checked_subnets(value)
    proposed = [ipaddress.ip_network(subnet) for subnet in value.values()]
    if any(network.version == 4 and any(network.overlaps(item) for item in proposed)
            for network in network_inventory(docker)):
        raise OwnershipError('Explicit Temporal subnet overlaps an existing network')
    return value


def assert_ipam(record, subnet):
    network = ipaddress.ip_network(subnet)
    expected = {'Subnet': subnet, 'Gateway': str(network.network_address + 1)}
    if (record.get('EnableIPv6') is not False
            or record.get('IPAM', {}).get('Driver') != 'default'
            or record['IPAM'].get('Options') not in (None, {})
            # Engine versions serialize an unset allocation range either by
            # omission or an empty string. Both mean the complete exact subnet;
            # a narrowed range or any other extra configuration remains refused.
            or record['IPAM'].get('Config') not in ([expected], [expected | {'IPRange': ''}])):
        raise OwnershipError('Owned Temporal network address profile changed')
