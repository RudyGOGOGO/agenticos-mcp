"""Authenticated local erasure after an exact governed derivative barrier."""
import hashlib,hmac
from agentic_os.adapters.local.artifacts import LocalArtifacts,checked_id
from agentic_os.adapters.local.files import OwnershipError,check_private,private_read,private_write
from agentic_os.adapters.local.resources import file_lock
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json


class ErasingLocalArtifacts(LocalArtifacts):
    def purge(self,namespace,reference,*,purpose='artifact',expected_ciphertext_digest):
        """Called only after an exact governed derivative deletion barrier.

        Keep an authenticated minimal marker for idempotent cleanup. Original
        ciphertext pins become unusable; no accepted host evidence is selected
        implicitly. The service still owns current journal/context fences.
        """
        checked_id(reference);check_private(self.directory,directory=True)
        digest=expected_ciphertext_digest
        if (type(digest) is not str or len(digest)!=64 or any(v not in '0123456789abcdef' for v in digest)):
            raise OwnershipError('Invalid artifact erasure pin')
        path=self.directory/(reference+'.json')
        with file_lock(self.directory/'purge.lock',timeout=.1):
            check_private(path);before=path.lstat()
            if before.st_nlink!=1:raise OwnershipError('Artifact erasure ownership is uncertain')
            raw=private_read(path,1500000)
            current=hashlib.sha256(raw).hexdigest()
            envelope=parse_canonical_json(raw)
            # Authentication checks namespace, exact artifact UUID and purpose,
            # without returning forgotten content to the caller.
            content=self.keys.decrypt(namespace,purpose,envelope,artifact_id=reference)
            marker=dict(profile='OSDerivedArtifactErasure/1',sourceCiphertextDigest=digest)
            if not hmac.compare_digest(current,digest):
                if content!=canonical_bytes(marker):raise OwnershipError('Artifact erasure pin changed')
                return dict(reference=reference,erased=True,ciphertextDigest=current)
            after=path.lstat()
            if (before.st_dev,before.st_ino,before.st_nlink)!=(after.st_dev,after.st_ino,after.st_nlink):
                raise OwnershipError('Artifact changed during erasure')
            erased=canonical_bytes(self.keys.encrypt(namespace,purpose,canonical_bytes(marker),artifact_id=reference))
            private_write(path,erased,replace=True)
            return dict(reference=reference,erased=True,ciphertextDigest=hashlib.sha256(erased).hexdigest())
