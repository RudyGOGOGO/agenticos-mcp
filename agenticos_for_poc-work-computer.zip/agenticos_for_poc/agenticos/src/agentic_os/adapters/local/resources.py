"""Private local resource primitives. No database or historical-path adoption."""
from contextlib import contextmanager, nullcontext
import fcntl
import hashlib
import hmac
import os
from pathlib import Path
import secrets
import shutil
import stat
import subprocess
import time

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from .files import OwnershipError, check_private, private_directory, private_read, private_write,private_owner,private_lock_open


def canonical_path(path: Path) -> Path:
    if not path.is_absolute() or path.resolve() != path or path.is_symlink():
        raise OwnershipError("Resource path must be absolute, canonical and not a symlink")
    return path


def ensure_private(path: Path):
    canonical_path(path)
    try:
        private_directory(path)
    except FileExistsError:
        check_private(path, directory=True)


@contextmanager
def file_lock(path: Path, *, timeout=30, shared=False):
    canonical_path(path)
    check_private(path.parent, directory=True)
    fd = private_lock_open(path)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != private_owner(path) or info.st_mode & 0o077 or info.st_nlink != 1:
            raise OwnershipError("Unsafe resource lock")
        deadline = time.monotonic() + timeout
        mode = fcntl.LOCK_SH if shared else fcntl.LOCK_EX
        while True:
            try:
                fcntl.flock(fd, mode | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise OwnershipError("Resource has an active lease") from None
                time.sleep(.05)
        yield
    finally:
        os.close(fd)


def initialize_key(root: Path, *, allowed_entries):
    ensure_private(root)
    key = root / 'resource.key'
    def validate_contents():
        names = {item.name for item in root.iterdir()}
        if names - (set(allowed_entries) | {'resource.key', 'initialize.lock'}):
            raise OwnershipError('Unknown resource-root content; adoption refused')
        if not key.exists() and names - {'initialize.lock'}:
            raise OwnershipError('Existing resource data has no ownership key')
    # Refuse an unknown existing root before creating even an initialization
    # lock. Revalidate under that lock to handle concurrent fresh constructors.
    if not key.exists():
        validate_contents()
    with file_lock(root / "initialize.lock"):
        validate_contents()
        if not key.exists():
            private_write(key, secrets.token_bytes(32))
        if len(private_read(key, 32)) != 32:
            raise OwnershipError("Invalid resource key")


def write_signed(path: Path, value: dict, key: Path, *, lock_timeout=30):
    # A constructor must not mistake a live atomic ledger write for unknown
    # root data. Resource signing shares initialization's short root lock;
    # existing fixture ownership keys retain their separate locking protocol.
    with file_lock(key.parent / 'initialize.lock', timeout=lock_timeout) if key.name == 'resource.key' else nullcontext():
        payload = canonical_bytes(value)
        signature = hmac.digest(private_read(key, 32), payload, "sha256").hex()
        private_write(path, canonical_bytes({"value": value, "signature": signature}), replace=True)


def read_signed(path: Path, key: Path, *, maximum=8_000_000):
    envelope = parse_canonical_json(private_read(path, maximum))
    if type(envelope) is not dict or set(envelope) != {"value", "signature"}:
        raise OwnershipError("Invalid resource envelope")
    signature = hmac.digest(private_read(key, 32), canonical_bytes(envelope["value"]), "sha256").hex()
    if type(envelope["signature"]) is not str or not hmac.compare_digest(signature, envelope["signature"]):
        raise OwnershipError("Resource signature changed")
    return envelope["value"]


def tree_inventory(root: Path, *, maximum=2 * 1024**3, immutable=False):
    """Reject links, device files, foreign owners and changes during hashing."""
    canonical_path(root)
    check_private(root, directory=True)
    records = {}
    total = allocated = 0
    for directory, children, names in os.walk(root, followlinks=False):
        for name in sorted(children + names):
            path = Path(directory) / name
            info = path.lstat()
            if (info.st_uid != private_owner(path) or stat.S_ISLNK(info.st_mode)
                    or not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode))
                    or info.st_mode & 0o077 or immutable and info.st_mode & 0o222):
                raise OwnershipError("Unsafe resource tree")
            if stat.S_ISREG(info.st_mode) and info.st_nlink != 1:
                raise OwnershipError("Shared writable inode is not an immutable input")
            relative = path.relative_to(root).as_posix()
            if len(records) >= 100_000:
                raise OwnershipError("Resource file-count limit exceeded")
            record = {"mode": stat.S_IMODE(info.st_mode), "size": info.st_size if path.is_file() else 0}
            if stat.S_ISREG(info.st_mode):
                total += info.st_size
                allocated += info.st_blocks * 512
                if total > maximum:
                    raise OwnershipError("Resource byte limit exceeded")
                hasher = hashlib.sha256()
                fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                with os.fdopen(fd, "rb") as source:
                    for block in iter(lambda: source.read(1024 * 1024), b""):
                        hasher.update(block)
                    after = os.fstat(source.fileno())
                if (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) != (
                        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
                    raise OwnershipError("Resource changed during verification")
                record["sha256"] = hasher.hexdigest()
            records[relative] = record
    return {"files": records, "bytes": total, "allocatedBytes": allocated}


def remove_staging(path: Path):
    """Only for exact private staging trees created by the caller, never DB roots."""
    canonical_path(path)
    check_private(path, directory=True)
    # Go's module cache explicitly applies readonly modes including public-read
    # bits. The private staging root contains it; validate owner/types/links
    # before making only directories writable for removal.
    for directory, children, names in os.walk(path, followlinks=False):
        for name in children + names:
            info = (Path(directory) / name).lstat()
            if (info.st_uid != private_owner(Path(directory)/name) or not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode))
                    or stat.S_ISREG(info.st_mode) and info.st_nlink != 1):
                raise OwnershipError("Unsafe staging tree; recovery hold required")
    for directory, children, _ in os.walk(path):
        Path(directory).chmod(0o700)
        for name in children:
            (Path(directory) / name).chmod(0o700)
    shutil.rmtree(path)


def staging_usage(path: Path, *, maximum):
    """Account mutable unpublished work without asserting an immutable digest."""
    canonical_path(path)
    check_private(path, directory=True)
    total = allocated = count = 0
    for directory, children, names in os.walk(path, followlinks=False):
        for name in children + names:
            child = Path(directory) / name
            try:
                info = child.lstat()
            except FileNotFoundError:
                # A concurrent trusted builder can finish/remove its temporary
                # file. Its declared peak remains reserved independently.
                continue
            count += 1
            if (info.st_uid != private_owner(child) or not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode))
                    or stat.S_ISREG(info.st_mode) and info.st_nlink != 1):
                raise OwnershipError('Unsafe unpublished build tree')
            if stat.S_ISREG(info.st_mode):
                total += info.st_size
                allocated += info.st_blocks * 512
            if total > maximum or count > 100_000:
                raise OwnershipError('Unpublished build envelope exceeded')
    return {'bytes': total, 'allocatedBytes': allocated, 'files': count, 'status': 'unpublished'}


def active_process_paths(root: Path, *, readonly_provider_mount=None):
    if readonly_provider_mount is not None and readonly_provider_mount != root / 'bootstrap-password':
        raise OwnershipError('Unknown provider mount exception')
    result = subprocess.run(["/usr/sbin/lsof", "-nP", "-Fpfatn"], capture_output=True,
                            text=True, timeout=30)
    if result.returncode not in (0, 1) or result.stderr.strip():
        raise OwnershipError("Unable to establish process ownership")
    pid = fd = access = kind = None
    for line in result.stdout.splitlines():
        if line.startswith("p"):
            pid = line[1:]
        elif line.startswith('f'):
            fd, access, kind = line[1:], None, None
        elif line.startswith('a'):
            access = line[1:]
        elif line.startswith('t'):
            kind = line[1:]
        if line.startswith("n") and pid != str(os.getpid()):
            name = line[1:]
            if name == str(root) or name.startswith(str(root) + "/"):
                # Docker Desktop's VM retains a readonly bootstrap bind even
                # after its owned container stops. The caller must first prove
                # the exact stopped container/mount. These retained host files
                # are never deleted by provider retirement.
                if (readonly_provider_mount is not None and access == 'r' and fd and fd.isdigit()
                        and (kind == 'REG' and name == str(readonly_provider_mount)
                             or kind == 'DIR' and name == str(root))):
                    process = subprocess.run(['ps', '-p', pid, '-o', 'comm='],
                                             capture_output=True, text=True, timeout=5)
                    expected = ('/System/Library/Frameworks/Virtualization.framework/Versions/A/XPCServices/'
                        'com.apple.Virtualization.VirtualMachine.xpc/Contents/MacOS/com.apple.Virtualization.VirtualMachine')
                    if process.returncode == 0 and process.stdout.strip() == expected:
                        continue
                raise OwnershipError("Resource has an active process")
