"""Explicit bounded encrypted operator diagnostics; no ordinary traceback log."""
from pathlib import Path
import time,traceback
from uuid import uuid4

from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from .artifacts import LocalKeys,checked_id
from .files import OwnershipError
from .operator import verify_operator
from .ownership import load_manifest
from .resources import ensure_private,file_lock,read_signed,write_signed,tree_inventory

PROFILE='operator-diagnostic/1'
DIRECTORY='privileged-diagnostics'
RETENTION=7*24*60*60
MAX_RECORDS=128
MAX_BYTES=65536


def subject(manifest):
    return dict(installationId=manifest['installationId'],
        applicationId='00000000-0000-0000-0000-000000000000',tenantId='installation-operator',subjectId='diagnostics/1')


def record_failure(path,token,error,*,now=None):
    """Only explicit operator callers can persist a privileged exception.

    A failed diagnostic write does not change the refused operation. Missing
    keys are never recreated. Records are capped and cannot displace old files.
    """
    path=Path(path);verify_operator(path,token);manifest=load_manifest(path)
    keys=LocalKeys(path.parent/'keys');keys._key(keys.active())
    root=path.parent/DIRECTORY;ensure_private(root)
    created=int(time.time()) if now is None else now
    if type(created) is not int or created<0:raise OwnershipError('Diagnostic clock unavailable')
    with file_lock(root/'diagnostics.lock',timeout=2):
        inventory=tree_inventory(root,maximum=MAX_RECORDS*MAX_BYTES*2)
        if sum(name.endswith('.json') for name in inventory['files'])>=MAX_RECORDS:
            raise OwnershipError('Operator diagnostic retention capacity reached')
        ident=str(uuid4())
        destination=root/(ident+'.json')
        if destination.exists() or destination.is_symlink():
            raise OwnershipError('Operator diagnostic identity already retained')
        # Do not capture frame locals. Even exception text remains encrypted.
        detail=''.join(traceback.format_exception(type(error),error,error.__traceback__))
        raw=canonical_bytes(dict(profile=PROFILE,id=ident,traceback=detail[:12000]))
        if len(raw)>MAX_BYTES:raise OwnershipError('Operator diagnostic exceeded its bound')
        value=dict(profile=PROFILE,id=ident,installationId=manifest['installationId'],runId=manifest['runId'],
            createdAt=created,expiresAt=created+RETENTION,
            envelope=keys.encrypt(subject(manifest),'verification',raw,artifact_id=ident))
        write_signed(destination,value,path.parent/'owner.key')
    verify_operator(path,token)
    return ident


def read_diagnostic(path,token,ident,*,now=None):
    """Private operator-only library access, never an owner/HTTP endpoint."""
    path=Path(path);verify_operator(path,token);manifest=load_manifest(path);checked_id(ident)
    value=read_signed(path.parent/DIRECTORY/(ident+'.json'),path.parent/'owner.key',maximum=MAX_BYTES*2)
    current=int(time.time()) if now is None else now
    if (type(current) is not int or type(value) is not dict
            or set(value)!={'profile','id','installationId','runId','createdAt','expiresAt','envelope'}
            or value['profile']!=PROFILE or value['id']!=ident
            or any(value[k]!=manifest[k] for k in ('installationId','runId'))
            or type(value['createdAt']) is not int or value['createdAt']<0
            or type(value['expiresAt']) is not int or value['expiresAt']!=value['createdAt']+RETENTION
            or not value['createdAt']<=current<value['expiresAt']):
        raise OwnershipError('Operator diagnostic unavailable or expired')
    raw=LocalKeys(path.parent/'keys').decrypt(subject(manifest),'verification',value['envelope'],artifact_id=ident)
    result=parse_canonical_json(raw)
    if (type(result) is not dict or set(result)!={'profile','id','traceback'}
            or result['profile']!=PROFILE or result['id']!=ident
            or type(result['traceback']) is not str or len(result['traceback'])>12000):
        raise OwnershipError('Operator diagnostic unavailable')
    verify_operator(path,token)
    return result
