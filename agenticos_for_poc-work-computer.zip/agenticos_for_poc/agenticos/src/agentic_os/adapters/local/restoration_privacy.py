"""Authenticated two-phase privacy restoration, with no readiness transition.

Preparation stores only bounded metadata, row digests and erasure patches.
SDK/vector/file cleanup closes before the final control transaction. The final
commit requires the same held generation, surviving journals and scope rows.
Historical owner commands and pending acknowledgements are never rewritten.
"""
from contextlib import contextmanager, ExitStack
import hashlib
from io import StringIO
from pathlib import Path
from uuid import UUID, uuid4

from psycopg import sql

from agentic_os.contracts.canonical import canonical_bytes
from agentic_os.errors import OSErrorCode
from agentic_os.memory.controls_journal import ControlsRecoveryJournal
from agentic_os.memory.recovery_journal import ForgetRecoveryJournal
from agentic_os.memory.restoration_plan import AllForgetPlan, IndividualForgetPlan, floor
from agentic_os.memory.restoration_sql import RowChange, MAX_ROWS, SCOPE, preview, limits, insert, apply
from agentic_os.adapters.postgres.restoration_models import RELATIONS
from .recovery_operator import migrate
from .files import OwnershipError
from .operator import verify_operator
from .ownership import load_manifest
from .recovery_operator import connect_owned
from .resources import canonical_path, file_lock, read_signed, write_signed, ensure_private
from .recovery_checkpoints import profile_pins, _external_root
from .restoration_binding import load_restoration
from .restoration_cleanup import RestorationPrivacyCleanup

PROFILE = 'held-privacy-restoration/1'
EMPTY_PROFILE = 'held-empty-managed-privacy/1'
INTENT_FIELDS = {'profile', 'id', 'installationId', 'runId', 'generation', 'backupReceiptDigest',
    'profiles', 'journalDigests', 'owners', 'rowCount', 'createdAt'}
SETTINGS = ('id', *SCOPE, 'version', 'learning_epoch', 'recall_epoch', 'context_revision',
    'index_generation', 'choice')
INVENTORY = (*RELATIONS, 'os_tasks', 'os_work_attempts', 'os_budget_roots', 'os_accepted_results', 'os_artifacts')


def sha(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def held(path, token, expected_generation):
    verify_operator(path, token)
    admitted = load_restoration(path)
    if type(expected_generation) is not int or admitted['generation'] != expected_generation:
        raise OwnershipError('Held privacy generation differs')
    return admitted


def scope_rows(db, table, columns, scope):
    query = sql.SQL('SELECT {} FROM public.{} WHERE {}').format(
        sql.SQL(',').join(map(sql.Identifier, columns)), sql.Identifier(table),
        sql.SQL(' AND ').join(sql.SQL('{}=%s').format(sql.Identifier(c)) for c in SCOPE))
    return [dict(zip(columns, row)) for row in db.execute(query, scope)]


def scope_inventory(db, scope):
    result = {}
    for table in INVENTORY:
        query = sql.SQL("SELECT count(*),encode(sha256(convert_to(COALESCE(jsonb_agg(b ORDER BY b::text),'[]'::jsonb)::text,'UTF8')),'hex') "
            'FROM (SELECT to_jsonb(t) b FROM public.{} t WHERE {} LIMIT %s) selected').format(
                sql.Identifier(table), sql.SQL(' AND ').join(sql.SQL('{}=%s').format(sql.Identifier(c)) for c in SCOPE))
        count, digest = db.execute(query, (*scope, MAX_ROWS+1)).fetchone()
        if count > MAX_ROWS:
            raise OSErrorCode('CAPACITY')
        result[table] = dict(rows=count, sha256=digest)
    return result


@contextmanager
def checkpoints(path, admitted, deletion_root, controls_root, *, on_verified=None):
    """Metadata SQL closes before consent -> deletion shared journal locks."""
    if on_verified is not None and not callable(on_verified):
        raise OwnershipError('Explicit locked checkpoint publication required')
    pins = profile_pins(path)
    archived = admitted['receipt']
    for actual, field in zip(pins, ('journalCheckpoints', 'controlsCheckpoints')):
        expected = archived.get(field)
        if type(expected) is not list or [{k:p[k] for k in ('applicationId','journalId','keyDigest')}
                for p in actual] != [{k:p[k] for k in ('applicationId','journalId','keyDigest')} for p in expected]:
            raise OwnershipError('Archived privacy profiles differ')
    deletion_root = _external_root(path, deletion_root) if pins[0] else None
    controls_root = _external_root(path, controls_root) if pins[1] else None
    if pins[0] and controls_root == deletion_root:
        raise OwnershipError('Independent consent and deletion roots required')
    if {p['applicationId'] for p in pins[0]} != {p['applicationId'] for p in pins[1]}:
        raise OSErrorCode('PROFILE_DISABLED')
    with ExitStack() as locks:
        deleting, consenting = {}, {}
        for pin in pins[1]:
            journal = ControlsRecoveryJournal(controls_root/pin['applicationId']/pin['journalId'],
                pin['installationId'], pin['applicationId'], pin['journalId'], expected_key_digest=pin['keyDigest'])
            locks.enter_context(journal._lock(shared=True))
            state = journal._checked_load()
            if any(v['state']=='PENDING' for owner in state['owners'].values() for v in owner['commands'].values()):
                raise OSErrorCode('UNAVAILABLE')
            consenting[pin['applicationId']] = (journal, state)
        for pin in pins[0]:
            journal = ForgetRecoveryJournal(deletion_root/pin['applicationId']/pin['journalId'],
                pin['installationId'], pin['applicationId'], pin['journalId'], expected_key_digest=pin['keyDigest'])
            locks.enter_context(file_lock(journal.root/'journal.lock', timeout=.1, shared=True))
            deleting[pin['applicationId']] = (journal, journal._checked_load())
        yield pins, deleting, consenting
        if profile_pins(path) != pins or any(j._checked_load()!=state for j,state in [*deleting.values(),*consenting.values()]):
            raise OwnershipError('Privacy profiles or journals changed')
        if on_verified is not None:on_verified()


def owner_state(settings, deleting, consenting):
    iid, aid, tenant, owner = (settings[k] for k in SCOPE)
    subject = dict(installationId=str(iid), applicationId=str(aid), tenantId=tenant, subjectId=owner)
    deletion, state = deleting[str(aid)]
    controls, control_state = consenting[str(aid)]
    owner_mac, control_mac = deletion.owner_mac(subject), controls.owner_mac(subject)
    deleted = state['owners'].get(owner_mac, deletion.empty_owner())
    controlled = control_state['owners'].get(control_mac)
    if controlled is None or any(v['request']['settingsId']!=str(settings['id']) for v in deleted['commands'].values()):
        raise OSErrorCode('UNAVAILABLE')
    return subject, deletion, deleted, owner_mac, controls, controlled, control_mac


def serialize(change):
    return dict(relation=change.relation, rowId=str(change.row_id), receiptId=str(change.receipt_id),
        beforeDigest=change.before_digest, afterDigest=change.after_digest, patch=change.patch)


def changes(owner):
    subject = owner['subject']
    scope = (UUID(subject['installationId']), UUID(subject['applicationId']), subject['tenantId'], subject['subjectId'])
    return [RowChange(v['relation'], UUID(v['rowId']), UUID(v['receiptId']), scope,
        v['beforeDigest'], v['afterDigest'], v['patch']) for v in owner['changes']]


def prepare_privacy(path, token, *, expected_generation, deletion_root, controls_root):
    path = Path(path)
    admitted = held(path, token, expected_generation)
    migrate(path, check_only=True, diagnostic_stream=StringIO())
    if load_manifest(path)['profile']=='aws-eks/1' and profile_pins(path)==([],[]):
        return _prepare_empty(path,token,admitted)
    # SDK authentication is read-only here; missing material is never created.
    from .recovery_sdk import restored_sdk
    restored_sdk(path)
    manifest = load_manifest(path)
    intent_id = uuid4()
    owners, total = [], 0
    with file_lock(path.parent/'recovery-gate.lock', timeout=2):
        if held(path, token, expected_generation) != admitted:
            raise OSErrorCode('CONFLICT')
        with checkpoints(path, admitted, deletion_root, controls_root) as (pins, deleting, consenting):
            journal_digests = {kind:{app:sha(state) for app,(_,state) in selected.items()}
                for kind,selected in (('deletion',deleting),('controls',consenting))}
            with connect_owned(path, role='migrator') as db:
                limits(db)
                # The database validates these timestamps at commit. Docker's
                # clock may briefly lag the host during recovery; use the
                # actual server clock without relaxing the future-date guard.
                created = db.execute('SELECT clock_timestamp()').fetchone()[0]
                query = sql.SQL('SELECT {} FROM personal_learning_settings WHERE application_id=ANY(%s::uuid[]) ORDER BY id LIMIT 129').format(sql.SQL(',').join(map(sql.Identifier, SETTINGS)))
                settings = [dict(zip(SETTINGS,row)) for row in db.execute(query,([UUID(v) for v in deleting],))]
                if not 1 <= len(settings) <= 128:
                    raise OSErrorCode('CAPACITY')
                covered = dict(deletion={app:set() for app in deleting}, controls={app:set() for app in consenting})
                for setting in settings:
                    subject, deletion, deleted, mac, controls, controlled, cmac = owner_state(setting, deleting, consenting)
                    app = subject['applicationId']
                    covered['deletion'][app].add(mac); covered['controls'][app].add(cmac)
                    scope = tuple(setting[k] for k in SCOPE)
                    prior_owner = scope_rows(db, 'memory_recovery_owners', ('settings_id','journal_id','sequence','owner_epoch'), scope)
                    if (len(prior_owner)!=1 or prior_owner[0]['settings_id']!=setting['id']
                            or str(prior_owner[0]['journal_id'])!=deletion.journal_id
                            or prior_owner[0]['sequence']>deleted['sequence'] or prior_owner[0]['owner_epoch']>deleted['ownerEpoch']):
                        raise OSErrorCode('UNAVAILABLE')
                    receipt_id = uuid4()
                    erase = prior_owner[0]['sequence'] < deleted['sequence']
                    if erase:
                        planner = AllForgetPlan if deleted['beforeLearningEpoch']>=setting['learning_epoch'] else IndividualForgetPlan
                        plan = planner(db, scope, receipt_id, settings=setting,
                            deletion=deleted, controls=controlled, now=created).build()
                        row_changes, settings_floor = plan.changes, plan.floor
                        entries, artifacts = plan.entries, plan.artifacts
                    else:
                        settings_floor = floor(setting, deleted, controlled)
                        row_changes = [preview(db,'personal_learning_settings',setting['id'],receipt_id,scope,
                            settings_floor|dict(updated_at=created.isoformat())),
                            preview(db,'memory_recovery_owners',setting['id'],receipt_id,scope,
                                dict(sequence=deleted['sequence'],owner_epoch=deleted['ownerEpoch'],updated_at=created.isoformat()))]
                        entries, artifacts = [], []
                    total += len(row_changes)
                    if total > MAX_ROWS:
                        raise OSErrorCode('CAPACITY')
                    receipt = dict(id=str(receipt_id), settings_id=str(setting['id']),
                        deletion_journal_id=deletion.journal_id, deletion_key_digest=deletion.expected_key_digest,
                        deletion_owner_mac=mac, deletion_sequence=deleted['sequence'], owner_epoch=deleted['ownerEpoch'],
                        before_learning_epoch=deleted['beforeLearningEpoch'], deletion_state_digest=sha(deleted),
                        controls_journal_id=controls.journal_id, controls_key_digest=controls.expected_key_digest,
                        controls_owner_mac=cmac, controls_sequence=controlled['sequence'], controls_state_digest=sha(controlled),
                        controls_pending=False, settings_version=settings_floor['version'],
                        learning_epoch=settings_floor['learning_epoch'], recall_epoch=settings_floor['recall_epoch'],
                        context_revision=settings_floor['context_revision'], index_generation=settings_floor['index_generation'],
                        choice=settings_floor['choice'], row_count=len(row_changes), created_at=created.isoformat())
                    owners.append(dict(subject=subject, erase=erase, receipt=receipt, entries=entries,
                        artifacts=artifacts, inventory=scope_inventory(db,scope), changes=list(map(serialize,row_changes))))
                for kind,selected in (('deletion',deleting),('controls',consenting)):
                    if any(set(state['owners'])-covered[kind][app] for app,(_,state) in selected.items()):
                        raise OSErrorCode('UNAVAILABLE')
            intent = dict(profile=PROFILE,id=str(intent_id),installationId=manifest['installationId'],runId=manifest['runId'],
                generation=expected_generation,backupReceiptDigest=admitted['receiptDigest'],profiles=list(pins),
                journalDigests=journal_digests,owners=owners,rowCount=total,createdAt=created.isoformat())
            if len(canonical_bytes(intent)) > 8*1024**2:
                raise OSErrorCode('CAPACITY')
            ensure_private(path.parent/'privacy-restoration')
            write_signed(path.parent/'privacy-restoration'/(str(intent_id)+'.json'),intent,path.parent/'owner.key',lock_timeout=.1)
    return dict(profile=PROFILE,intentId=str(intent_id),owners=len(owners),rowPlans=total,state='PREPARED')


def load_intent(path, token, intent_id):
    path = Path(path)
    if type(intent_id) is not str or str(UUID(intent_id)) != intent_id:
        raise OSErrorCode('INVALID')
    value = read_signed(path.parent/'privacy-restoration'/(intent_id+'.json'),path.parent/'owner.key',maximum=16*1024**2)
    if type(value) is dict and value.get('profile')==EMPTY_PROFILE:
        return _load_empty(path,token,intent_id,value)
    if (type(value) is not dict or set(value)!=INTENT_FIELDS or value['profile']!=PROFILE or value['id']!=intent_id
            or not 1<=len(value['owners'])<=128 or not 1<=value['rowCount']<=MAX_ROWS
            or value['rowCount']!=sum(len(v['changes']) for v in value['owners'])):
        raise OwnershipError('Privacy intent is unavailable')
    admitted = held(path, token, value['generation'])
    if (value['installationId'],value['runId'],value['backupReceiptDigest']) != (
            admitted['installationId'],admitted['runId'],admitted['receiptDigest']):
        raise OwnershipError('Privacy intent belongs to another restoration')
    return value, admitted


async def finish_privacy(path, token, intent_id, *, deletion_root, controls_root):
    path = Path(path)
    intent, admitted = load_intent(path, token, intent_id)
    if intent['profile']==EMPTY_PROFILE:return _finish_empty(path,token,intent,admitted)
    migrate(path, check_only=True, diagnostic_stream=StringIO())
    completed = path.parent/'privacy-restoration'/(intent_id+'-complete.json')
    with connect_owned(path,role='migrator') as db:
        limits(db)
        actual = db.execute('SELECT run_id,generation,receipt_digest,owner_count,row_count '
            'FROM os_restoration_authorities WHERE id=%s',(UUID(intent_id),)).fetchone()
        cleanup_digests = []
        if actual is not None:
            if actual != (intent['runId'],intent['generation'],intent['backupReceiptDigest'],len(intent['owners']),intent['rowCount']):
                raise OSErrorCode('CONFLICT')
            for owner in intent['owners']:
                selected = db.execute('SELECT cleanup_digest FROM os_scope_restoration_receipts '
                    'WHERE id=%s AND authority_id=%s',(UUID(owner['receipt']['id']),UUID(intent_id))).fetchone()
                plans = db.execute('SELECT relation_name,row_id,before_digest,after_digest,patch '
                    'FROM os_restoration_row_plans WHERE receipt_id=%s',(UUID(owner['receipt']['id']),)).fetchall()
                expected = {(v['relation'],v['rowId']):(v['beforeDigest'],v['afterDigest'],v['patch']) for v in owner['changes']}
                if selected is None or {(r,str(i)):(b,a,p) for r,i,b,a,p in plans} != expected:
                    raise OSErrorCode('CONFLICT')
                cleanup_digests.append(selected[0])
    if actual is not None:
        if completed.exists() or completed.is_symlink():
            prior = read_signed(completed,path.parent/'owner.key')
            if prior.get('intentDigest')!=sha(intent) or prior.get('cleanupDigests')!=cleanup_digests:
                raise OSErrorCode('CONFLICT')
        else:
            # The SQL commit is authoritative even when its local completion
            # acknowledgement was lost. Never repeat cleanup or insert again.
            write_signed(completed,dict(profile=PROFILE,intentDigest=sha(intent),cleanupDigests=cleanup_digests,
                committedAt=intent['createdAt']),path.parent/'owner.key',lock_timeout=.1)
        return dict(profile=PROFILE,intentId=intent_id,owners=len(intent['owners']),rowPlans=intent['rowCount'],state='COMMITTED',runtimeReady=False)
    if completed.exists() or completed.is_symlink():
        raise OSErrorCode('CONFLICT')
    cleanup = RestorationPrivacyCleanup(path,token,admitted,expected_generation=intent['generation'])
    results = []
    for owner in intent['owners']:
        results.append(await cleanup.erase(owner['subject'],entries=owner['entries'],artifacts=owner['artifacts'])
            if owner['erase'] else dict(profile='restored-consent-floor/1',complete=True))
    # Every network/process/file await has finished before these short locks.
    with file_lock(path.parent/'recovery-gate.lock', timeout=2):
        if held(path,token,intent['generation'])!=admitted:
            raise OSErrorCode('CONFLICT')
        with checkpoints(path,admitted,deletion_root,controls_root) as (pins,deleting,consenting):
            current = {kind:{app:sha(state) for app,(_,state) in selected.items()}
                for kind,selected in (('deletion',deleting),('controls',consenting))}
            if list(pins)!=intent['profiles'] or current!=intent['journalDigests']:
                raise OSErrorCode('CONFLICT')
            with connect_owned(path,role='migrator') as db:
                limits(db)
                all_changes = [change for owner in intent['owners'] for change in changes(owner)]
                if any(scope_inventory(db,changes(owner)[0].scope)!=owner['inventory'] for owner in intent['owners']):
                    raise OSErrorCode('CONFLICT')
                transaction_id, role = db.execute('SELECT txid_current(),current_user').fetchone()
                now = db.execute('SELECT clock_timestamp()').fetchone()[0]
                insert(db,'os_restoration_authorities',dict(id=UUID(intent_id),installation_id=UUID(intent['installationId']),
                    run_id=intent['runId'],generation=intent['generation'],receipt_digest=intent['backupReceiptDigest'],
                    transaction_id=transaction_id,operator_role=role,owner_count=len(intent['owners']),row_count=len(all_changes),created_at=now))
                for owner,result in zip(intent['owners'],results):
                    subject = owner['subject']
                    scope = (UUID(subject['installationId']),UUID(subject['applicationId']),subject['tenantId'],subject['subjectId'])
                    receipt = owner['receipt']|dict(authority_id=UUID(intent_id),cleanup_digest=sha(result))
                    for field in ('id','settings_id','deletion_journal_id','controls_journal_id'):
                        receipt[field]=UUID(receipt[field])
                    insert(db,'os_scope_restoration_receipts',dict(zip(SCOPE,scope))|receipt)
                apply(db,all_changes)
                db.execute('SET CONSTRAINTS ALL IMMEDIATE')
                if held(path,token,intent['generation'])!=admitted:
                    raise OSErrorCode('CONFLICT')
                db.commit()
            write_signed(completed,dict(profile=PROFILE,intentDigest=sha(intent),cleanupDigests=[sha(v) for v in results],
                committedAt=now.isoformat()),path.parent/'owner.key',lock_timeout=.1)
    return dict(profile=PROFILE,intentId=intent_id,owners=len(intent['owners']),rowPlans=intent['rowCount'],state='COMMITTED',runtimeReady=False)


def _empty_capture(admitted):
    from .coordinated_backup import MANAGED_PROFILE
    receipt=admitted['receipt']
    if (receipt['profile']!=MANAGED_PROFILE or receipt['journalCheckpoints'] or receipt['controlsCheckpoints']
            or 'recovery-metadata/memory-sdk.json' in admitted['materialDigests']):
        raise OwnershipError('Explicit managed archive without privacy profiles or SDK selection required')
    from agentic_os.adapters.postgres.models import Base
    names=sorted(name for name in Base.metadata.tables if name.startswith((
        'personal_','memory_','classified_','task_memory_','task_knowledge_','owner_memory_')))
    counts=[receipt['components']['control']['before']['counts'].get(name) for name in names]
    counts.extend(receipt['components']['retrieval']['before']['counts'].get(name)
        for name in ('personal_knowledge_fences','personal_knowledge_vectors'))
    if not 1<=len(names)<=128 or any(type(count) is not int or count!=0 for count in counts):
        raise OwnershipError('Original managed archive contains private owner state')
    return names


def _empty_inventory(path,admitted):
    names=_empty_capture(admitted)
    if profile_pins(path)!=([],[]):raise OwnershipError('Current managed privacy profiles are not empty')
    result={}
    for component,tables in [('control',names),('retrieval',['personal_knowledge_fences','personal_knowledge_vectors'])]:
        with connect_owned(path,component=component,role='migrator') as db:
            db.rollback();db.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');limits(db)
            counts={name:db.execute(sql.SQL('SELECT count(*) FROM public.{}').format(sql.Identifier(name))).fetchone()[0] for name in tables}
        if any(type(count) is not int or count!=0 for count in counts.values()):
            raise OwnershipError('Managed empty privacy qualification found owner data')
        result[component]=counts
    return result


def _prepare_empty(path,token,admitted):
    """No synthetic SQL authority/owner; frozen populated constraints stay intact."""
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        if held(path,token,admitted['generation'])!=admitted:raise OSErrorCode('CONFLICT')
        inventory=_empty_inventory(path,admitted)
        with connect_owned(path,role='migrator') as db:
            db.rollback();db.execute('SET TRANSACTION READ ONLY');limits(db)
            now=db.execute('SELECT clock_timestamp()').fetchone()[0]
        intent_id=str(uuid4());manifest=load_manifest(path)
        value=dict(profile=EMPTY_PROFILE,id=intent_id,installationId=manifest['installationId'],runId=manifest['runId'],
            generation=admitted['generation'],backupReceiptDigest=admitted['receiptDigest'],profiles=[[],[]],
            journalDigests=dict(deletion={},controls={}),owners=[],rowCount=0,createdAt=now.isoformat(),emptyInventory=inventory)
        ensure_private(path.parent/'privacy-restoration');write_signed(path.parent/'privacy-restoration'/(intent_id+'.json'),value,path.parent/'owner.key')
    return dict(profile=EMPTY_PROFILE,intentId=intent_id,owners=0,rowPlans=0,state='PREPARED',runtimeReady=False)


def _load_empty(path,token,intent_id,value):
    if (set(value)!=INTENT_FIELDS|{'emptyInventory'} or value['id']!=intent_id or value['owners']!=[]
            or type(value['rowCount']) is not int or value['rowCount']!=0 or value['profiles']!=[[],[]]
            or value['journalDigests']!=dict(deletion={},controls={}) or type(value['emptyInventory']) is not dict):
        raise OwnershipError('Empty managed privacy intent unavailable')
    admitted=held(path,token,value['generation']);_empty_capture(admitted)
    if (value['installationId'],value['runId'],value['backupReceiptDigest'])!=(admitted['installationId'],admitted['runId'],admitted['receiptDigest']):
        raise OwnershipError('Empty managed privacy lineage differs')
    return value,admitted


def _finish_empty(path,token,intent,admitted):
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        if held(path,token,intent['generation'])!=admitted or _empty_inventory(path,admitted)!=intent['emptyInventory']:
            raise OSErrorCode('CONFLICT')
        file=path.parent/'privacy-restoration'/(intent['id']+'-complete.json')
        value=dict(profile=EMPTY_PROFILE,intentDigest=sha(intent),cleanupDigests=[],committedAt=intent['createdAt'])
        if file.exists() or file.is_symlink():
            if read_signed(file,path.parent/'owner.key')!=value:raise OSErrorCode('CONFLICT')
        else:write_signed(file,value,path.parent/'owner.key')
    return dict(profile=EMPTY_PROFILE,intentId=intent['id'],owners=0,rowPlans=0,state='COMMITTED',runtimeReady=False)


def empty_evidence(path,intent,admitted):
    """Current absence and exact completion, never a fabricated populated receipt."""
    file=path.parent/'privacy-restoration'/(intent['id']+'-complete.json')
    if (intent['profile']!=EMPTY_PROFILE or _empty_inventory(path,admitted)!=intent['emptyInventory']
            or read_signed(file,path.parent/'owner.key')!=dict(profile=EMPTY_PROFILE,intentDigest=sha(intent),cleanupDigests=[],committedAt=intent['createdAt'])):
        raise OwnershipError('Empty managed privacy completion unavailable')
    return dict(profiles=0,owners=0,authorityId=intent['id'],intentDigest=sha(intent),journalsDigest=sha(intent['journalDigests']))
