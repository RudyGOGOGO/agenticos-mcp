"""Signed-archive selection of minimal original production receipt metadata."""
import asyncio
from copy import deepcopy
import hashlib
from pathlib import Path
import re
from uuid import UUID

from sqlalchemy import create_engine,select,text
from sqlalchemy.orm import Session
from sqlalchemy.pool import NullPool

from agentic_os.adapters.postgres.models import (Admission,AgentEffectReceipt,AgentReviewDecision,AgentReviewRecord,AgentToolAcceptance,
    AgentToolCall,AgentWriteConflictBinding,AgentWriteConflictClaim,AgentWriteConflictRoot,
    BudgetRoot,PublicEvent,Segment,Task,WorkAttempt)
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.effects.registry import ResourceRegistry
from agentic_os.effects.reviewed_observer import ReviewedReceiptObserver
from agentic_os.effects.reviewed_provider import ReviewedProviderRegistry
from agentic_os.errors import OSErrorCode
from agentic_os.production.accounting import _handle
from agentic_os.production.reviewed_effect import (ProductionEffectAuthority,ProductionReceiptAuthority,
    ProductionReviewedEffectLedger)
from agentic_os.production.write_conflict_keys import HARNESS as SERIALIZED_HARNESS
from .artifacts import checked_id
from .files import OwnershipError,private_read,private_write
from .held_receipt_store import accounting_digest,history_digest
from .operator import verify_operator
from .original_receipt_store import original_source
from .ownership import load_manifest
from .production_receipt_store import ProductionReceiptSession,ProductionReceiptStore,conflict_digest
from .recovery_receipts import _ObserverRegistry
from .recovery_runtime_checkpoint import runtime_checkpoint
from .resources import ensure_private,file_lock
from .restoration_binding import load_restoration
from .recovery_operator import connect_owned

FILE='recovery-metadata/production-receipts.json'
PROFILE='admitted-production-receipt-capsules/1'
RUNNING_PROFILE='admitted-production-receipt-capsules/2'
RESERVED_PROFILE='admitted-production-receipt-capsules/3'
REPAIR_PROFILE='admitted-production-receipt-capsules/4'
FIELDS={'profile','installationId','sourceRunId','effects'}
EFFECT_FIELDS={'handle','decisionId','reviewId','preparationId','callId','admissionId','conversationId',
    'toolProfileDigest','capabilityRef','providerRef','registrationRevision','decisionDigest','reviewDigest',
    'grantDigest','reservationDigest','providerBindingDigest','observerCredentialRef','observerCredentialDigest',
    'endpointDigest','accountingDigest','originalHistoryDigest','conflict'}
DIGESTS={key for key in EFFECT_FIELDS if key.endswith('Digest')}
IDS={'decisionId','reviewId','preparationId','callId','admissionId','conversationId'}
REPAIR_IDS={'repairId','bindingId','grantId','approvalId','preparedId','parentTaskId',
    'admissionId','conversationId','originalBindingId','originalProjectionId','invocationId'}
REPAIR_DIGESTS={'grantDigest','reservationDigest','rootPolicyDigest','repairMetadataDigest','accountingDigest',
    'originalHistoryDigest','parentHistoryDigest','providerBindingDigest','observerCredentialDigest','endpointDigest'}
REPAIR_FIELDS=REPAIR_IDS|REPAIR_DIGESTS|{'kind','handle','registrationRevision','capabilityRef','providerRef','observerCredentialRef'}


def is_repair(c):return c.get('kind')=='agent.repair'


def pending_effects(checkpoint):
    production=checkpoint.get('production')
    if production is None:return []
    pending=[row for row in production['pendingWork'] if row['kind'] in {'agent.effect','agent.repair'}]
    if any(row['state'] not in {'RESERVED','RUNNING','UNKNOWN'} for row in pending):
        raise OwnershipError('Original production pending state unavailable')
    return pending


def checked_capsules(value):
    if (type(value) is not dict or set(value)!=FIELDS or value['profile'] not in {PROFILE,RUNNING_PROFILE,RESERVED_PROFILE,REPAIR_PROFILE}
            or type(value['sourceRunId']) is not str or re.fullmatch('[a-f0-9]{12}',value['sourceRunId']) is None
            or type(value['effects']) is not list or not 1<=len(value['effects'])<=128):
        raise OwnershipError('Production receipt capsules unavailable')
    checked_id(value['installationId']);seen=set()
    for c in value['effects']:
        if type(c) is not dict:raise OwnershipError('Production receipt capsule differs')
        repair=value['profile']==REPAIR_PROFILE and is_repair(c)
        fields=REPAIR_FIELDS if repair else EFFECT_FIELDS|({'kind'} if value['profile']==REPAIR_PROFILE else set())
        if set(c)!=fields or 'kind' in c and c['kind']!=('agent.repair' if repair else 'agent.effect'):
            raise OwnershipError('Production receipt capsule differs')
        validate_contract('AttemptHandle',c['handle']);h=c['handle']
        for key in REPAIR_IDS if repair else IDS:checked_id(c[key])
        states=({'UNKNOWN'} if value['profile']==PROFILE else {'RUNNING','UNKNOWN'}
            if value['profile']==RUNNING_PROFILE else {'RESERVED','RUNNING','UNKNOWN'})
        if (h['state'] not in states or h['subject']['installationId']!=value['installationId'] or h['id'] in seen
                or type(c['registrationRevision']) is not int or not 1<=c['registrationRevision']<=2**53-1
                or any(type(c[key]) is not str or re.fullmatch('[a-f0-9]{64}',c[key]) is None for key in (REPAIR_DIGESTS if repair else DIGESTS))
                or any(type(c[key]) is not str or not 1<=len(c[key])<=256 for key in
                    ('capabilityRef','providerRef','observerCredentialRef'))):
            raise OwnershipError('Production receipt capsule differs')
        if repair and (h['taskId']==c['parentTaskId'] or h['id']==c['originalBindingId']):
            raise OwnershipError('Production inverse must retain separate original identity')
        conflict=None if repair else c['conflict']
        if conflict is not None:
            if (type(conflict) is not dict or set(conflict)!={'policyDigest','bindingId','immutableDigest'}
                    or any(type(conflict[key]) is not str or re.fullmatch('[a-f0-9]{64}',conflict[key]) is None
                        for key in ('policyDigest','immutableDigest'))):raise OwnershipError('Production conflict capsule differs')
            checked_id(conflict['bindingId'])
        seen.add(h['id'])
    if value['profile']==REPAIR_PROFILE and not any(is_repair(c) for c in value['effects']):
        raise OwnershipError('Production repair capsule selection unavailable')
    return value


def match_pending(value,pending):
    expected=[dict(attemptId=c['handle']['id'],applicationId=c['handle']['subject']['applicationId'],
        taskId=c['handle']['taskId'],rootId=c['handle']['rootId'],invocationId=c['invocationId'] if is_repair(c) else c['decisionId'],
        requestDigest=c['reservationDigest'],kind='agent.repair' if is_repair(c) else 'agent.effect',state=c['handle']['state'],leaseUntil=c['handle']['leaseUntil'])
        for c in value['effects']]
    if sorted(pending,key=lambda row:row['attemptId'])!=sorted(expected,key=lambda row:row['attemptId']):
        raise OwnershipError('Snapshot production effects differ from admitted capsules')


def _engine(path):
    def connect():
        db=connect_owned(path,role='migrator');db.rollback();return db
    return create_engine('postgresql+psycopg://',poolclass=NullPool,creator=connect)


def source_capsule(db,attempt_id):
    """Only immutable control metadata: no artifact/session/key service exists."""
    row=db.get(WorkAttempt,UUID(attempt_id))
    if row is None or row.kind!='agent.effect' or row.state not in {'RESERVED','RUNNING','UNKNOWN'}:raise OwnershipError('Original production effect unavailable')
    subject=dict(installationId=str(row.installation_id),applicationId=str(row.application_id),tenantId=row.tenant_id,subjectId=row.subject_id)
    _,grant=ProductionReviewedEffectLedger.binding_metadata(db,row)
    decision=db.get(AgentReviewDecision,row.invocation_id);review=db.get(AgentReviewRecord,decision.review_id)
    accepted=db.get(AgentToolAcceptance,review.preparation_id);root=db.get(BudgetRoot,row.root_id)
    task=db.get(Task,row.task_id);admission=db.get(Admission,root.admission_id);segment=db.get(Segment,row.segment_id)
    events=list(db.scalars(select(PublicEvent).where(PublicEvent.segment_id==row.segment_id).order_by(PublicEvent.sequence)))
    if root.profile_ref!='agent-production/1' or segment is None:raise OwnershipError('Original production receipt scope differs')
    profile_digest=db.scalar(select(AgentToolCall.request['record']['profile']['digest'].as_string()).where(AgentToolCall.id==accepted.call_id))
    conflict=None
    if admission.context['harness']['ref']==SERIALIZED_HARNESS:
        binding=db.scalar(select(AgentWriteConflictBinding).where(AgentWriteConflictBinding.attempt_id==row.id))
        original=db.get(AgentWriteConflictRoot,binding.root_binding_id) if binding else None
        if original is None:raise OwnershipError('Original production write binding unavailable')
        claims=list(db.scalars(select(AgentWriteConflictClaim).where(AgentWriteConflictClaim.binding_id==binding.id)))
        conflict=dict(policyDigest=original.policy_digest,bindingId=str(binding.id),immutableDigest=conflict_digest(binding,claims))
    return dict(handle=_handle(subject,row),decisionId=str(decision.id),reviewId=str(review.id),
        preparationId=str(accepted.id),callId=str(accepted.call_id),admissionId=str(admission.id),conversationId=str(task.conversation_id),
        toolProfileDigest=profile_digest,capabilityRef=grant['capabilityRef'],providerRef=grant['providerRef'],
        registrationRevision=grant['registrationRevision'],decisionDigest=decision.digest,reviewDigest=review.digest,
        grantDigest=grant['grantDigest'],reservationDigest=row.request_digest,accountingDigest=accounting_digest(row,root),
        originalHistoryDigest=history_digest(segment,events),conflict=conflict)


def select_original_receipts(path,token):
    path=Path(path);original_source(path,token);manifest=load_manifest(path)
    pending=pending_effects(runtime_checkpoint(path))
    if not pending:
        if (path.parent/FILE).exists() or (path.parent/FILE).is_symlink():raise OwnershipError('Untracked production receipt capsules')
        return dict(profile=PROFILE,admittedEffects=0,selected=False)
    engine=_engine(path);effects=[]
    try:
        with Session(engine,autoflush=False,expire_on_commit=False) as db:
            with db.begin():
                db.execute(text('SET TRANSACTION READ ONLY'));db.execute(text("SET LOCAL lock_timeout='2s'"));db.execute(text("SET LOCAL statement_timeout='3s'"))
                from .production_repair_receipt_store import source_capsule as repair_capsule
                effects=[(repair_capsule if row['kind']=='agent.repair' else source_capsule)(db,row['attemptId']) for row in pending]
        # This existing registry resolves only the original observer credential;
        # it performs no Host call and cannot supply an execute credential.
        from agentic_os.adapters.postgres.store import ControlStore
        from agentic_os.registry.service import Registry
        store=ControlStore(path)
        try:
            providers=ReviewedProviderRegistry(ResourceRegistry(Registry(path,store)))
            for c in effects:
                selected=providers.original(c['handle']['subject'],c['registrationRevision'],c['capabilityRef'],c['providerRef'],purpose='observe')
                c.update(providerBindingDigest=selected['binding']['bindingDigest'],
                    observerCredentialRef=selected['binding']['observerCredentialRef'],
                    observerCredentialDigest=hashlib.sha256(selected['observerCredential'].encode('ascii')).hexdigest(),
                    endpointDigest=hashlib.sha256(selected['endpoint'].encode()).hexdigest())
        finally:store.close()
        profile=(REPAIR_PROFILE if any(is_repair(c) for c in effects) else RESERVED_PROFILE if any(c['handle']['state']=='RESERVED' for c in effects) else
            RUNNING_PROFILE if any(c['handle']['state']=='RUNNING' for c in effects) else PROFILE)
        if profile==REPAIR_PROFILE:
            for c in effects:
                if not is_repair(c):c['kind']='agent.effect'
        value=dict(profile=profile,installationId=manifest['installationId'],sourceRunId=manifest['runId'],effects=effects)
        checked_capsules(value);raw=canonical_bytes(value)
        if len(raw)>512*1024:raise OSErrorCode('CAPACITY')
        with file_lock(path.parent/'recovery-gate.lock',timeout=2):
            original_source(path,token);match_pending(value,pending_effects(runtime_checkpoint(path)))
            with Session(engine,autoflush=False,expire_on_commit=False) as db:
                with db.begin():
                    db.execute(text('SET TRANSACTION READ ONLY'));db.execute(text("SET LOCAL lock_timeout='2s'"));db.execute(text("SET LOCAL statement_timeout='3s'"))
                    for c in effects:
                        from .production_repair_receipt_store import ProductionRepairReceiptSession
                        port=(ProductionRepairReceiptSession if is_repair(c) else ProductionReceiptSession)(db,c,readonly=True)
                        port.verify_capsule();port.flush()
            destination=path.parent/FILE;ensure_private(destination.parent)
            if destination.exists() or destination.is_symlink():
                if private_read(destination,512*1024)!=raw:raise OwnershipError('Original production receipt selection changed')
            else:private_write(destination,raw)
        return dict(profile=profile,admittedEffects=len(effects),selected=True)
    finally:engine.dispose()


def _archive_capsules(path,admitted):
    try:raw=private_read(path.parent/FILE,512*1024)
    except OSError:raise OwnershipError('Archived production receipt capsules unavailable') from None
    if admitted['materialDigests'].get(FILE)!=hashlib.sha256(raw).hexdigest():raise OwnershipError('Archived production receipt capsules changed')
    value=checked_capsules(parse_canonical_json(raw))
    if value['installationId']!=admitted['installationId']:raise OwnershipError('Production receipt installation differs')
    match_pending(value,pending_effects(admitted['receipt']['runtimeCheckpoint']))
    return value


def load_capsules(path,token,generation):
    path=Path(path);verify_operator(path,token);admitted=load_restoration(path)
    if type(generation) is not int or admitted['generation']!=generation:raise OwnershipError('Production receipt generation differs')
    return admitted,_archive_capsules(path,admitted)


def load_ready_capsules(path,token,generation):
    from .recovery_ready_receipts import receipt_release
    from .recovery_ready import admitted_archive
    path=Path(path);release=receipt_release(path,token,generation);admitted=admitted_archive(path)
    value=_archive_capsules(path,admitted)
    if receipt_release(path,token,generation)!=release or admitted_archive(path)!=admitted:
        raise OwnershipError('Current production receipt release changed')
    return dict(release=release,archive=admitted),value


async def observe_receipt(path,token,*,expected_generation,attempt_id):
    return await _bounded_observe(path,token,expected_generation,attempt_id,ready=False)


async def observe_ready_receipt(path,token,*,expected_generation,attempt_id):
    return await _bounded_observe(path,token,expected_generation,attempt_id,ready=True)


async def _bounded_observe(path,token,generation,attempt_id,*,ready):
    try:
        async with asyncio.timeout(20):return await _observe(path,token,generation,attempt_id,ready=ready)
    except TimeoutError:raise OSErrorCode('UNAVAILABLE') from None


def _open_store(path,token,generation,attempt_id,ready):
    path=Path(path);checked_id(attempt_id);load=load_ready_capsules if ready else load_capsules
    admitted,value=load(path,token,generation)
    c=next((row for row in value['effects'] if row['handle']['id']==attempt_id),None)
    if c is None:raise OSErrorCode('DENIED')
    def authenticate():
        if load(path,token,generation)!=(admitted,value):raise OwnershipError('Production receipt selection changed')
    from .production_repair_receipt_store import ProductionRepairReceiptStore
    return (ProductionRepairReceiptStore if is_repair(c) else ProductionReceiptStore)(path,c,authenticate),c,authenticate


def reserved_status(store,*,ready):
    """Authenticated saved begin-journal fact, explicitly no Host receipt."""
    c=store.capsule
    if c['handle']['state']!='RESERVED':raise OSErrorCode('PROFILE_DISABLED')
    with store.transaction() as db:
        from agentic_os.adapters.postgres.models import RepairReceiptProjection
        query=(select(RepairReceiptProjection).where(RepairReceiptProjection.binding_id==UUID(c['bindingId'])) if is_repair(c)
            else select(AgentEffectReceipt).where(AgentEffectReceipt.binding_id==UUID(c['handle']['id'])))
        if db.scalar(query.limit(1)) is not None:
            raise OwnershipError('Unstarted effect has a contradictory receipt')
    return dict(profile=REPAIR_PROFILE if is_repair(c) else RESERVED_PROFILE,state='NOT_STARTED',attemptId=c['handle']['id'],
        status='NOT_SENT',projectionId=None,originalAttemptState='RESERVED',
        unknownUsageHeld=True,runtimeReady=ready,executionAuthorized=False)


async def _observe(path,token,generation,attempt_id,*,ready):
    from .recovery_ready_receipts import _joined_thread
    opened,cancelled=await _joined_thread(_open_store,path,token,generation,attempt_id,ready)
    store,c,authenticate=opened
    try:
        if cancelled is not None:raise cancelled
        if c['handle']['state']=='RESERVED':
            # The atomic begin journal precedes every Host dispatch. A saved
            # never-begun reservation has no Host outcome to fabricate/observe.
            result,cancelled=await _joined_thread(lambda:reserved_status(store,ready=ready))
            if cancelled is not None:raise cancelled
            await asyncio.to_thread(authenticate)
            return result
        registry=_ObserverRegistry(path,store,c);providers=ReviewedProviderRegistry(ResourceRegistry(registry))
        if is_repair(c):
            from agentic_os.effects.repair_execution import RepairReceiptObserver
            from agentic_os.production.repair_receipt import ProductionRepairReceiptAuthority
            from agentic_os.adapters.postgres.models import RepairReceiptProjection
            observation=await RepairReceiptObserver(ProductionRepairReceiptAuthority(store,providers)).observe(c['handle'],
                provider_pins=dict(bindingDigest=c['providerBindingDigest'],endpointDigest=c['endpointDigest']))
            def projection():
                with store.transaction() as db:
                    row=db.scalar(select(RepairReceiptProjection).where(RepairReceiptProjection.binding_id==UUID(c['bindingId']))
                        .order_by(RepairReceiptProjection.ordinal.desc()).limit(1))
                    if row is None or row.payload['status']!=observation['status']:raise OwnershipError('Original inverse receipt differs')
                    return str(row.id)
            ident,cancelled=await _joined_thread(projection)
            if cancelled is not None:raise cancelled
            await asyncio.to_thread(authenticate)
            return dict(profile=REPAIR_PROFILE,state='OBSERVED',attemptId=attempt_id,status=observation['status'],
                projectionId=ident,unknownUsageHeld=True,runtimeReady=ready,executionAuthorized=False)
        observer=ReviewedReceiptObserver(ProductionReviewedEffectLedger(ProductionReceiptAuthority(store)),providers)
        async with asyncio.timeout(20):
            reference,observation=await observer.observe(c['handle'],provider_pins=dict(
                bindingDigest=c['providerBindingDigest'],endpointDigest=c['endpointDigest']))
            if reference['providerBindingDigest']!=c['providerBindingDigest']:raise OwnershipError('Original production provider changed')
            await asyncio.to_thread(authenticate)
            profile=RUNNING_PROFILE if c['handle']['state']=='RUNNING' else PROFILE
            return dict(profile=profile,state='OBSERVED',attemptId=attempt_id,status=observation['status'],
                projectionId=reference['id'],unknownUsageHeld=True,runtimeReady=ready,executionAuthorized=False)
    finally:
        _,cancelled=await _joined_thread(store.close)
        if cancelled is not None:raise cancelled
