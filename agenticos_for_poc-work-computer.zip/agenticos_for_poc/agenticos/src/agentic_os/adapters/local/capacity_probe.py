"""Fixed read-only capacity command through the owned local Docker Engine.

The existing complete container/image/volume attestation remains authoritative.
Engine API1.51 removes CLI process startup from this short measurement, without
introducing cached headroom, arbitrary exec, shell, mounts or network access.
"""
import http.client
import errno
import json
import socket
import time
from urllib.parse import quote

from .docker import DockerControl
from .files import OwnershipError

API = '/v1.51'
COMMAND = ('df', '-Pk', '/', '/var/lib/postgresql/data')


def identifier(value):
    if (type(value) is not str or len(value) != 64
            or any(c not in '0123456789abcdef' for c in value)):
        raise OwnershipError('Owned capacity Engine identity unavailable')
    return value


def stdout(raw):
    """Validate every non-TTY multiplexed frame; never accept plaintext fallback."""
    if type(raw) is not bytes or not 1 <= len(raw) <= 16384:
        raise OwnershipError('Owned capacity stream unavailable')
    pos = 0; result = b''; frames = 0
    while pos < len(raw):
        header = raw[pos:pos+8]; frames += 1
        if (len(header) != 8 or header[:4] != b'\x01\0\0\0' or frames > 64):
            raise OwnershipError('Owned capacity stream unavailable')
        size = int.from_bytes(header[4:8], 'big')
        if size == 0 or pos+8+size > len(raw):
            raise OwnershipError('Owned capacity stream unavailable')
        result += raw[pos+8:pos+8+size]; pos += 8+size
    try: return result.decode('ascii')
    except UnicodeError: raise OwnershipError('Owned capacity stream unavailable') from None


class CapacityProbeControl(DockerControl):
    def __init__(self, manifest, *, deadline):
        super().__init__(manifest)
        self.deadline = deadline

    def _connect(self):
        # A refused Unix connect has established no connection and sent no HTTP
        # bytes. One fresh connection attempt can tolerate the observed local
        # Engine proxy refusal. Never replay a request after connect succeeds.
        for attempt in range(2):
            remaining = self.deadline-time.monotonic()
            if remaining <= 0:
                raise OwnershipError('Owned capacity probe exceeded bounded deadline')
            local = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                local.settimeout(remaining)
                local.connect(self.manifest['dockerEndpoint'].removeprefix('unix://'))
                return local
            except OSError as error:
                local.close()
                if error.errno != errno.ECONNREFUSED or attempt:
                    raise
                remaining = self.deadline-time.monotonic()
                if remaining <= 0:
                    raise OwnershipError('Owned capacity probe exceeded bounded deadline')
                time.sleep(min(.05, remaining))
            except BaseException:
                local.close()
                raise

    def _request(self, method, route, body=None, *, maximum=2*1024**2):
        connection = http.client.HTTPConnection('localhost')
        local = None
        try:
            local = self._connect()
            connection.sock = local
            connection.request(method, API+route,
                None if body is None else json.dumps(body).encode('ascii'),
                headers={'Content-Type':'application/json', 'Connection':'close'})
            response = connection.getresponse()
            if response.status not in {200,201}:
                raise OwnershipError('Owned capacity Engine request unavailable')
            parts = []; size = 0
            # HTTPResponse closes a Connection: close socket as soon as the
            # declared body is complete, including a nonempty final read1.
            # Do not touch that socket again after protocol completion.
            while not response.isclosed():
                remaining = self.deadline-time.monotonic()
                if remaining <= 0: raise OwnershipError('Owned capacity probe exceeded bounded deadline')
                local.settimeout(remaining)
                part = response.read1(min(65536, maximum+1-size))
                if not part: break
                parts.append(part); size += len(part)
                if size > maximum: raise OwnershipError('Owned capacity Engine envelope exceeded')
            if response.length not in (None, 0):
                raise OwnershipError('Owned capacity Engine transport unavailable')
            if time.monotonic() >= self.deadline:
                raise OwnershipError('Owned capacity probe exceeded bounded deadline')
            return b''.join(parts)
        except (OSError, http.client.HTTPException):
            raise OwnershipError('Owned capacity Engine transport unavailable') from None
        finally:
            connection.close()
            if local is not None: local.close()

    def _json(self, method, route, body=None):
        try:
            value = json.loads(self._request(method, route, body))
            if type(value) is not dict: raise ValueError()
            return value
        except (ValueError, UnicodeError):
            raise OwnershipError('Owned capacity Engine metadata unavailable') from None

    def command(self, *args, timeout=60, input=None):
        # inspect_owned invokes only these three metadata operations. It still
        # checks all original labels, image IDs, privilege, network, ports and
        # mount/volume ownership. No arbitrary Docker operation is supported.
        if input is not None: raise OwnershipError('Unregistered capacity operation')
        args = tuple(map(str,args))
        if len(args) == 2 and args[0] == 'inspect':
            route = '/containers/'+quote(args[1],safe='')+'/json'
        elif len(args) == 3 and args[:2] == ('image','inspect'):
            route = '/images/'+quote(args[2],safe='')+'/json'
        elif len(args) == 3 and args[:2] == ('volume','inspect'):
            route = '/volumes/'+quote(args[2],safe='')
        else:
            if len(args) != 8 or args[:3] != ('exec','--user','65534:65534') or args[4:] != COMMAND:
                raise OwnershipError('Unregistered capacity operation')
            container = identifier(args[3])
            value = self._json('POST','/containers/'+container+'/exec',dict(
                AttachStdin=False,AttachStdout=True,AttachStderr=True,Tty=False,
                Privileged=False,User='65534:65534',Cmd=list(COMMAND)))
            execution = identifier(value.get('Id'))
            # POST is never retried: an ambiguous command is retained by Engine
            # and no unavailable measurement admits a capacity reservation.
            raw = self._request('POST','/exec/'+execution+'/start',
                dict(Detach=False,Tty=False),maximum=16384)
            status = self._json('GET','/exec/'+execution+'/json')
            if (status.get('Running') is not False or type(status.get('ExitCode')) is not int
                    or status['ExitCode'] != 0 or status.get('ContainerID') != container):
                raise OwnershipError('Owned capacity command completion unavailable')
            return stdout(raw)
        return json.dumps([self._json('GET',route)])
