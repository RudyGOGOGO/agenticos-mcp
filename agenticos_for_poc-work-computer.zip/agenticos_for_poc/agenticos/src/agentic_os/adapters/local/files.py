"""Private no-follow files and atomic writes. No implicit adoption of existing data."""
import os
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
import secrets
import stat


class OwnershipError(RuntimeError):
    """Safe failure; no path content, credentials or submitted payload."""


_shared_owner=ContextVar('aws_shared_private_owner',default=None)
AWS_SHARED_FILES='aws-shared-private65534/1'


def private_owner(path: Path) -> int:
    """Only the explicit native installation subtree has a different owner."""
    root=_shared_owner.get()
    if root is not None and path.is_relative_to(root):
        if not path.is_absolute() or path.resolve()!=path:
            raise OwnershipError('Shared private resource path changed')
        return 65534
    return os.getuid()


def bind_private_files(operation):
    """Carry only the explicit file-owner policy into a pool worker.

    Do not copy caller authentication/context or retain a file/gate proof.
    Each invocation rechecks the root and every accessed file as usual.
    """
    root=_shared_owner.get()
    if root is None:return operation
    def call(*args,**kwargs):
        with aws_shared_private_files(root):return operation(*args,**kwargs)
    return call


@contextmanager
def aws_shared_private_files(root: Path):
    """Root native supervisor borrows an existing UID65534 private installation.

    No existing inode is repaired or adopted. Outside this exact canonical
    subtree the ordinary process-owner contract still applies. Authentication,
    signed manifest, current gate/locks and every per-open check remain required.
    """
    if (os.getuid() not in {0,65534} or os.geteuid()!=os.getuid()
            or not root.is_absolute() or root.resolve()!=root or root.is_symlink()
            or _shared_owner.get() not in (None,root)):
        raise OwnershipError('Explicit shared AWS private installation required')
    info=root.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid!=65534 or info.st_mode&0o077:
        raise OwnershipError('Shared AWS installation requires its original private owner')
    token=_shared_owner.set(root)
    try:yield
    finally:_shared_owner.reset(token)


def _new_file_owner(fd,path):
    expected=private_owner(path)
    if os.fstat(fd).st_uid!=expected:
        if os.getuid()!=0 or expected!=65534:raise OwnershipError('New private file has a foreign owner')
        # Only an O_EXCL-created inode reaches this helper. Never chown an
        # existing key/lock. EFS access-point writes already have this owner.
        os.fchown(fd,expected,expected)


def private_lock_open(path):
    try:fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_RDWR|os.O_NOFOLLOW,0o600)
    except FileExistsError:return os.open(path,os.O_RDWR|os.O_NOFOLLOW)
    try:_new_file_owner(fd,path)
    except BaseException:os.close(fd);raise
    return fd


def check_private(path: Path, *, directory: bool = False) -> None:
    info = path.lstat()
    expected = stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)
    if not expected or info.st_uid != private_owner(path) or info.st_mode & 0o077:
        raise OwnershipError("OS resource is not a private owned regular file/directory")


def private_directory(path: Path) -> None:
    path.mkdir(mode=0o700)
    expected=private_owner(path)
    if path.lstat().st_uid!=expected:
        if os.getuid()!=0 or expected!=65534:raise OwnershipError('New private directory has a foreign owner')
        os.chown(path,expected,expected,follow_symlinks=False)
    check_private(path, directory=True)


def private_read(path: Path, max_bytes: int = 1048576) -> bytes:
    check_private(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as handle:
        info = os.fstat(handle.fileno())
        if info.st_uid != private_owner(path) or info.st_mode & 0o077 or not stat.S_ISREG(info.st_mode):
            raise OwnershipError("Private file changed during open")
        value = handle.read(max_bytes + 1)
    if len(value) > max_bytes:
        raise OwnershipError("Private file exceeds resource envelope")
    return value


def private_write(path: Path, value: bytes, *, replace: bool = False) -> None:
    check_private(path.parent, directory=True)
    if not replace:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "wb") as handle:
            _new_file_owner(handle.fileno(),path)
            handle.write(value); handle.flush(); os.fsync(handle.fileno())
        return
    if path.exists() or path.is_symlink():
        check_private(path)
    temporary = path.parent / (".atomic-" + secrets.token_hex(8))
    try:
        private_write(temporary, value)
        os.replace(temporary, path)
        fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        temporary.unlink(missing_ok=True)
