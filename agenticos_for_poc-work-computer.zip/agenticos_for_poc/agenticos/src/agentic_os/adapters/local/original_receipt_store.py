"""Read-only original receipt metadata selection before operator Park."""
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from uuid import UUID
import hashlib

from sqlalchemy import create_engine,text
from sqlalchemy.orm import Session
from sqlalchemy.pool import NullPool

from agentic_os.adapters.local.files import OwnershipError,private_read
from agentic_os.adapters.local.held_receipt_store import ReceiptSession
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.resources import file_lock
from agentic_os.adapters.local.target import connect_owned
from agentic_os.adapters.local import recovery_gate as gate
from agentic_os.contracts.validation import validate_contract
from agentic_os.identity.context import iso
from agentic_os.registry.service import Registry


def original_source(path,token):
    verify_operator(path,token)
    if ((path.parent/'recovery-snapshot.json').exists()
            or (path.parent/'recovery-snapshot.json').is_symlink()
            or gate.selected(path) and gate.state(path)['mode']!='READY'):
        raise OwnershipError('Receipt selection requires the original ready source')


def source_attempt_ids(path,token):
    path=Path(path)
    with file_lock(path.parent/'recovery-gate.lock',timeout=2,shared=True):
        original_source(path,token)
        with connect_owned(path,role='migrator') as db:
            db.rollback()
            db.execute('SET TRANSACTION READ ONLY')
            db.execute("SET LOCAL lock_timeout='2s'")
            db.execute("SET LOCAL statement_timeout='3s'")
            rows=db.execute("SELECT id FROM os_work_attempts WHERE kind='effect' AND state='UNKNOWN' ORDER BY id LIMIT 129").fetchall()
    if not 1<=len(rows)<=128:
        raise OwnershipError('Original receipt selection envelope unavailable')
    return [str(row[0]) for row in rows]


def source_seed(path,token,attempt_id):
    from .artifacts import checked_id
    checked_id(attempt_id)
    original_source(path,token)
    with connect_owned(path,role='migrator') as db:
        db.rollback()
        db.execute('SET TRANSACTION READ ONLY')
        db.execute("SET LOCAL lock_timeout='2s'")
        db.execute("SET LOCAL statement_timeout='3s'")
        row=db.execute("SELECT a.installation_id,a.application_id,a.tenant_id,a.subject_id,a.id,"
            "a.task_id,a.segment_id,a.root_id,a.control_epoch,a.lease_token,a.lease_until,a.state,"
            "b.id,b.grant_id,b.continuation_id,b.decision_id,t.conversation_id,"
            "(g.payload->>'registrationRevision')::bigint,g.payload->>'capabilityRef',"
            "p.observer_credential_ref FROM os_work_attempts a "
            "JOIN os_input_reviewed_effect_attempts b ON "
            "(b.installation_id,b.application_id,b.tenant_id,b.subject_id,b.attempt_id)="
            "(a.installation_id,a.application_id,a.tenant_id,a.subject_id,a.id) "
            "JOIN os_tasks t ON (t.installation_id,t.application_id,t.tenant_id,t.subject_id,t.id)="
            "(a.installation_id,a.application_id,a.tenant_id,a.subject_id,a.task_id) "
            "JOIN os_execution_grants g ON (g.installation_id,g.application_id,g.tenant_id,g.subject_id,g.id)="
            "(a.installation_id,a.application_id,a.tenant_id,a.subject_id,b.grant_id) "
            "JOIN os_reviewed_effect_providers p ON (p.installation_id,p.application_id,p.registration_revision,p.capability_ref)="
            "(a.installation_id,a.application_id,(g.payload->>'registrationRevision')::bigint,g.payload->>'capabilityRef') "
            "WHERE a.id=%s AND a.kind='effect' AND a.state='UNKNOWN' LIMIT 2",(UUID(attempt_id),)).fetchall()
    if len(row)!=1:raise OwnershipError('Original admitted receipt metadata unavailable')
    r=row[0]
    subject=dict(installationId=str(r[0]),applicationId=str(r[1]),tenantId=r[2],subjectId=r[3])
    handle=dict(subject=subject,id=str(r[4]),taskId=str(r[5]),segmentId=str(r[6]),rootId=str(r[7]),
        controlEpoch=r[8],leaseToken=str(r[9]),leaseUntil=iso(r[10]),state=r[11])
    validate_contract('AttemptHandle',handle)
    seed=dict(handle=handle,bindingId=str(r[12]),grantId=str(r[13]),continuationId=str(r[14]),
        decisionId=str(r[15]),conversationId=str(r[16]),registrationRevision=r[17],
        capabilityRef=r[18],observerCredentialRef=r[19])
    registry=Registry(path,None)
    credential=private_read(registry.credential_path(subject['applicationId'],seed['observerCredentialRef']),256)
    seed['observerCredentialDigest']=hashlib.sha256(credential).hexdigest()
    return seed


def verify_source_capsules(path,token,effects):
    """Caller holds the exclusive source gate through immutable publication.

    Fresh read-only accounting and closed-history pins prevent an earlier
    selection snapshot from hiding a changed original hold or public segment.
    """
    original_source(path,token)
    def connect():
        db=connect_owned(path,role='migrator');db.rollback()
        return db
    engine=create_engine('postgresql+psycopg://',poolclass=NullPool,creator=connect)
    try:
        with Session(engine,autoflush=False,expire_on_commit=False) as session:
            with session.begin():
                session.execute(text('SET TRANSACTION READ ONLY'))
                session.execute(text("SET LOCAL lock_timeout='2s'"))
                session.execute(text("SET LOCAL statement_timeout='3s'"))
                for capsule in effects:
                    port=ReceiptSession(session,capsule,readonly=True)
                    port.verify_capsule();port.flush()
        original_source(path,token)
    finally:engine.dispose()


class OriginalReceiptStore:
    """One stored UNKNOWN handle; PostgreSQL and the metadata port deny writes."""
    def __init__(self,path,token,attempt_id):
        self.__path=Path(path);self.__token=token
        with file_lock(self.__path.parent/'recovery-gate.lock',timeout=2,shared=True):
            self.__seed=source_seed(self.__path,token,attempt_id)
        def connect():
            db=connect_owned(self.__path,role='migrator');db.rollback()
            return db
        self.__engine=create_engine('postgresql+psycopg://',poolclass=NullPool,creator=connect)

    @property
    def seed(self):return deepcopy(self.__seed)

    @contextmanager
    def transaction(self):
        with file_lock(self.__path.parent/'recovery-gate.lock',timeout=2,shared=True):
            original_source(self.__path,self.__token)
            with Session(self.__engine,autoflush=False,expire_on_commit=False) as session:
                with session.begin():
                    session.execute(text('SET TRANSACTION READ ONLY'))
                    session.execute(text("SET LOCAL lock_timeout='2s'"))
                    session.execute(text("SET LOCAL statement_timeout='3s'"))
                    port=ReceiptSession(session,self.__seed,readonly=True)
                    yield port
                    port.flush();original_source(self.__path,self.__token)

    def close(self):self.__engine.dispose()
