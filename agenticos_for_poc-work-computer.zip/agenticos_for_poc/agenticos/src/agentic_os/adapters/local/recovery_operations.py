"""bounded operator health and aggregate metrics, without private values."""
from pathlib import Path

from .files import OwnershipError
from .operator import verify_operator
from .ownership import COMPONENTS
from .target import connect_owned
from . import recovery_gate as gate

PROFILE = 'owned-recovery-operations/1'
QUERIES = {
    'unknownWork': "SELECT count(*) FROM os_work_attempts WHERE state='UNKNOWN'",
    'quarantinedRoots': "SELECT count(*) FROM os_budget_roots WHERE state='QUARANTINED'",
    'dueDispatches': "SELECT count(*) FROM os_dispatches WHERE state='DUE'",
    'leasedDispatches': "SELECT count(*) FROM os_dispatches WHERE state='LEASED'",
    'poisonDispatches': "SELECT count(*) FROM os_dispatches WHERE state='POISON'",
    'activeTasks': "SELECT count(*) FROM os_tasks WHERE state IN ('ACCEPTED','PLANNING','VALIDATING','RUNNING','WAITING_INPUT','WAITING_APPROVAL','RECONCILING')",
}


def _limits(db):
    db.rollback(); db.execute('SET TRANSACTION READ ONLY')
    db.execute("SET LOCAL lock_timeout='2s'")
    db.execute("SET LOCAL statement_timeout='3s'")


def health(path, token):
    path = Path(path); verify_operator(path, token)
    try:
        current = gate.health(path, token)
    except Exception:
        current = dict(state='BLOCKED', enabledLanes=[])
    stores = {}
    for component in sorted(COMPONENTS):
        try:
            with connect_owned(path, component=component, role='migrator') as db:
                _limits(db)
                if db.execute('SELECT 1').fetchone() != (1,):
                    raise OwnershipError('Owned health probe unavailable')
            stores[component] = 'AVAILABLE'
        except Exception:
            stores[component] = 'UNAVAILABLE'
    return dict(profile=PROFILE, state=current['state'], stores=stores,
        releaseReady=current['state'] == 'READY' and all(v == 'AVAILABLE' for v in stores.values()),
        unknownUsageHeld=True)


def metrics(path, token):
    path = Path(path); verify_operator(path, token)
    try:
        with connect_owned(path, role='migrator') as db:
            _limits(db)
            counts = {name: db.execute(query).fetchone()[0] for name, query in QUERIES.items()}
            if any(type(v) is not int or not 0 <= v <= 2**53 - 1 for v in counts.values()):
                raise OwnershipError('Owned aggregate metrics unavailable')
        return dict(profile=PROFILE, state='AVAILABLE', counts=counts, unknownUsageHeld=True)
    except Exception:
        return dict(profile=PROFILE, state='UNAVAILABLE', counts=None, unknownUsageHeld=True)


def key_integrity(path, token, *, expected_generation,purpose='history'):
    """Explicit private-key inspection; health never reads encryption bytes."""
    path = Path(path); verify_operator(path, token)
    from .recovery_key_operations import _current
    from .recovery_key_continuity import effective_keys, selector,plane
    from .recovery_history import pinned_keys
    from .resources import file_lock
    with file_lock(path.parent / 'recovery-gate.lock', timeout=2, shared=True):
        value = _current(path, token, expected_generation)
        known = effective_keys(path, value,purpose)
        pinned_keys(path.parent / plane(purpose)[3], known); selector(path, value,purpose=purpose)
        return dict(profile=PROFILE, state='VERIFIED', generation=value['generation'],
            knownKeys=len(known), unknownUsageHeld=True)
