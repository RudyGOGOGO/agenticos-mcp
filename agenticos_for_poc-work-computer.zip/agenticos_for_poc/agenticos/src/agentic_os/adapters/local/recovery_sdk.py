"""Explicit durable SDK selection; a restore never initializes missing work."""
import hashlib
import hmac
import re
from pathlib import Path

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.adapters.mem0.forget_lifecycle import ForgettableStageLifecycle
from .files import OwnershipError, check_private, private_read, private_write
from .operator import verify_operator
from .ownership import load_manifest
from .resources import canonical_path, file_lock
from .restoration_binding import load_restoration
from . import recovery_gate as gate

FILE = 'recovery-metadata/memory-sdk.json'
PROFILE = 'surviving-memory-sdk/1'
FIELDS = {'profile', 'installationId', 'sourceRunId', 'directory', 'keyDigest'}
ENTRIES = {'resource.key', 'initialize.lock', 'admission.lock', 'state.json', 'work'}


def checked_lifecycle(directory, key_digest):
    """Check all prior material before calling the legacy initializing constructor."""
    root = canonical_path(Path(directory))
    check_private(root, directory=True)
    if (type(key_digest) is not str or re.fullmatch('[a-f0-9]{64}', key_digest) is None
            or {p.name for p in root.iterdir()} != ENTRIES):
        raise OwnershipError('Selected SDK ownership is unavailable')
    for name in ENTRIES:
        check_private(root/name, directory=name == 'work')
    key = private_read(root/'resource.key', 32)
    if len(key) != 32 or not hmac.compare_digest(hashlib.sha256(key).hexdigest(), key_digest):
        raise OwnershipError('Selected SDK key changed')
    before = {n: private_read(root/n, 16384) for n in ENTRIES if n != 'work'}
    lifecycle = ForgettableStageLifecycle(root)
    if before != {n: private_read(root/n, 16384) for n in before}:
        raise OwnershipError('SDK construction changed prior material')
    return lifecycle


def provision_sdk_binding(path, token, directory):
    """Select an existing durable lifecycle before the source snapshot."""
    path = Path(path)
    verify_operator(path, token)
    manifest = load_manifest(path)
    root = canonical_path(Path(directory))
    if root == path.parent or root.is_relative_to(canonical_path(path.parent)):
        raise OwnershipError('SDK work must survive the installation rollback domain')
    key_digest = hashlib.sha256(private_read(root/'resource.key', 32)).hexdigest()
    checked_lifecycle(root, key_digest)
    with file_lock(path.parent/'recovery-gate.lock', timeout=2):
        if (path.parent/'recovery-snapshot.json').exists() or (gate.selected(path)
                and gate.state(path)['mode'] not in {'READY', 'PARKED'}):
            raise OwnershipError('Original SDK selection requires an original installation')
        target = path.parent/FILE
        if target.exists() or target.is_symlink():
            raise OwnershipError('An existing SDK selection cannot be replaced')
        from .resources import ensure_private
        ensure_private(target.parent)
        value = dict(profile=PROFILE, installationId=manifest['installationId'],
            sourceRunId=manifest['runId'], directory=str(root), keyDigest=key_digest)
        private_write(target, canonical_bytes(value))
        return dict(profile=PROFILE, selected=True)


def restored_sdk(path):
    """Authenticate the archived pin before accessing the surviving lifecycle."""
    path = Path(path)
    admitted = load_restoration(path)
    raw = private_read(path.parent/FILE, 16384)
    if admitted['materialDigests'].get(FILE) != hashlib.sha256(raw).hexdigest():
        raise OwnershipError('Archived SDK selection changed')
    value = parse_canonical_json(raw)
    if (type(value) is not dict or set(value) != FIELDS or value['profile'] != PROFILE
            or value['installationId'] != admitted['installationId']
            or type(value['sourceRunId']) is not str
            or re.fullmatch('[a-f0-9]{12}', value['sourceRunId']) is None
            or type(value['directory']) is not str):
        raise OwnershipError('Archived SDK selection is unavailable')
    root = canonical_path(Path(value['directory']))
    if root == path.parent or root.is_relative_to(canonical_path(path.parent)):
        raise OwnershipError('SDK placement entered the rollback domain')
    return checked_lifecycle(root, value['keyDigest'])
