"""Explicit reviewed OPA deployment into the owned installation."""
import hashlib,json,os,platform,secrets,subprocess
from importlib.resources import files
from pathlib import Path
from agentic_os.contracts.canonical import canonical_bytes,digest,parse_canonical_json
from .dependencies import download
from .files import OwnershipError,private_read,private_directory,private_write
from .ownership import load_manifest


def install_opa(manifest_path):
    manifest=load_manifest(manifest_path);root=Path(manifest['root'])
    placement={('Darwin','arm64'):'opa-darwin-arm64',('Linux','aarch64'):'opa-linux-arm64'}
    selected=placement.get((platform.system(),platform.machine()))
    if selected is None:
        raise OwnershipError('OPA local placement unqualified')
    lock=json.loads(files('agentic_os').joinpath('deploy/source-lock.json').read_text())[selected]
    directory=root/'dependencies'
    if not directory.exists():private_directory(directory)
    executable=directory/'opa';download(lock,executable,200_000_000);executable.chmod(0o700)
    result=subprocess.run([str(executable),'version'],capture_output=True,timeout=10,
        env={'PATH':'/usr/bin:/bin','HOME':str(root/'home')})
    if result.returncode or 'Version: '+lock['version'] not in result.stdout.decode().splitlines():
        raise OwnershipError('OPA version mismatch')
    return executable


def prepare_bundle(manifest_path):
    manifest=load_manifest(manifest_path);root=Path(manifest['root']);directory=root/'policy'
    if not directory.exists():private_directory(directory)
    policy=files('agentic_os').joinpath('policies/authority.rego').read_text()
    auth=files('agentic_os').joinpath('policies/operator_auth.rego').read_text()
    fingerprint=digest('policy',{'revision':1,'authority':policy,'operatorAuth':auth})
    marker=directory/'release.json'
    if marker.exists():
        record=json.loads(private_read(marker))
        if record['digest']!=fingerprint or record['revision']!=1:
            raise OwnershipError('Policy activation requires an explicit reviewed upgrade')
        if private_read(directory/'authority.rego').decode()!=policy or private_read(directory/'operator_auth.rego').decode()!=auth:
            raise OwnershipError('Policy release content changed')
        data=json.loads(private_read(directory/'data.json'))
        if data['profile']!={'revision':1,'digest':fingerprint}:
            raise OwnershipError('Policy provenance changed')
    else:
        data={'profile':{'revision':1,'digest':fingerprint},'operator':{'token':secrets.token_urlsafe(32)}}
        private_write(directory/'authority.rego',policy.encode());private_write(directory/'operator_auth.rego',auth.encode())
        private_write(directory/'data.json',canonical_bytes(data))
        record={'revision':1,'digest':fingerprint};private_write(marker,canonical_bytes(record))
    return directory,record,data['operator']['token']


def start_opa(manifest_path,port):
    if type(port) is not int or not 1024<=port<=65535:
        raise OwnershipError('OPA requires an explicit loopback port')
    executable=install_opa(manifest_path);directory,record,token=prepare_bundle(manifest_path)
    log=directory/'service.log'
    if not log.exists():private_write(log,b'')
    handle=open(log,'ab')
    process=subprocess.Popen([str(executable),'run','--server','--addr',f'127.0.0.1:{port}',
        '--authentication=token','--authorization=basic','--skip-version-check','--log-level=error',str(directory)],
        cwd=directory,env={'PATH':'/usr/bin:/bin','HOME':str(manifest_path.parent/'home')},stdout=handle,stderr=handle)
    handle.close()
    return process,record,token


def prepare_effect_bundle(manifest_path):
    """Separate pinned preparation profile; never edits the frozen read bundle."""
    manifest=load_manifest(manifest_path);root=Path(manifest['root']);directory=root/'effect-policy-2'
    if not directory.exists():private_directory(directory)
    policy=files('agentic_os').joinpath('policies/effect_preparation.rego').read_text()
    auth=files('agentic_os').joinpath('policies/operator_auth.rego').read_text()
    fingerprint=digest('policy',{'revision':2,'profile':'effect-preparation/1','authority':policy,'operatorAuth':auth})
    marker=directory/'release.json'
    if marker.exists():
        record=json.loads(private_read(marker))
        if record!={'revision':2,'digest':fingerprint}:
            raise OwnershipError('Effect policy requires an explicit reviewed upgrade')
        if private_read(directory/'authority.rego').decode()!=policy or private_read(directory/'operator_auth.rego').decode()!=auth:
            raise OwnershipError('Effect policy release content changed')
        data=json.loads(private_read(directory/'data.json'))
        if data['profile']!={'revision':2,'digest':fingerprint}:
            raise OwnershipError('Effect policy provenance changed')
    else:
        data={'profile':{'revision':2,'digest':fingerprint},'operator':{'token':secrets.token_urlsafe(32)}}
        private_write(directory/'authority.rego',policy.encode());private_write(directory/'operator_auth.rego',auth.encode())
        private_write(directory/'data.json',canonical_bytes(data))
        record={'revision':2,'digest':fingerprint};private_write(marker,canonical_bytes(record))
    return directory,record,data['operator']['token']


def start_effect_opa(manifest_path,port):
    if type(port) is not int or not 1024<=port<=65535:
        raise OwnershipError('OPA requires an explicit loopback port')
    executable=install_opa(manifest_path);directory,record,token=prepare_effect_bundle(manifest_path)
    log=directory/'service.log'
    if not log.exists():private_write(log,b'')
    with log.open('ab') as handle:
        process=subprocess.Popen([str(executable),'run','--server','--addr',f'127.0.0.1:{port}',
            '--authentication=token','--authorization=basic','--skip-version-check','--log-level=error',str(directory)],
            cwd=directory,env={'PATH':'/usr/bin:/bin','HOME':str(manifest_path.parent/'home')},stdout=handle,stderr=handle)
    return process,record,token


def prepare_oidc_preparation_bundle(manifest_path,*,configured=False):
    """Owned local copy of the production revision9 eligibility policy.

    This provisions neither an issuer nor owner mappings or effect authority.
    Production packaging uses the same immutable Rego and digest inputs.
    """
    manifest=load_manifest(manifest_path)
    if (type(configured) is not bool or manifest['profile']!=('aws-eks/1' if configured else 'test')):
        raise OwnershipError('Explicit owned OIDC policy placement required')
    directory=Path(manifest['root'])/'oidc-preparation-policy-9'
    policy=files('agentic_os').joinpath('policies/oidc_effect_preparation.rego').read_text()
    auth=files('agentic_os').joinpath('policies/operator_auth.rego').read_text()
    from agentic_os.adapters.opa.oidc_preparation import bundle_pin
    record=bundle_pin()
    marker=directory/'release.json'
    if directory.exists():
        data=parse_canonical_json(private_read(directory/'data.json',16384))
        if (parse_canonical_json(private_read(marker,16384))!=record
                or type(data) is not dict or set(data)!={'profile','operator'} or data['profile']!=record
                or type(data['operator']) is not dict or set(data['operator'])!={'token'}
                or type(data['operator']['token']) is not str or len(data['operator']['token'])!=43
                or private_read(directory/'authority.rego',65536).decode()!=policy
                or private_read(directory/'operator_auth.rego',65536).decode()!=auth):
            raise OwnershipError('OIDC policy requires explicit reviewed upgrade')
    else:
        private_directory(directory)
        data={'profile':record,'operator':{'token':secrets.token_urlsafe(32)}}
        private_write(directory/'authority.rego',policy.encode());private_write(directory/'operator_auth.rego',auth.encode())
        private_write(directory/'data.json',canonical_bytes(data));private_write(marker,canonical_bytes(record))
    return directory,record,data['operator']['token']


def start_oidc_preparation_opa(manifest_path,port):
    if type(port) is not int or not 1024<=port<=65535:raise OwnershipError('OPA requires explicit loopback port')
    executable=install_opa(manifest_path)
    directory,record,token=prepare_oidc_preparation_bundle(manifest_path)
    log=directory/'service.log'
    if not log.exists():private_write(log,b'')
    with log.open('ab') as handle:
        process=subprocess.Popen([str(executable),'run','--server','--addr',f'127.0.0.1:{port}',
            '--authentication=token','--authorization=basic','--skip-version-check','--log-level=error',str(directory)],
            cwd=directory,env={'PATH':'/usr/bin:/bin','HOME':str(manifest_path.parent/'home')},stdout=handle,stderr=handle)
    return process,record,token


# Separate owner-decision eligibility profile; no executable policy.
def prepare_review_bundle(manifest_path):
    """Separately pinned owner-decision eligibility; no executable policy."""
    manifest=load_manifest(manifest_path);root=Path(manifest['root'])
    directory=root/'effect-review-policy-3'
    if not directory.exists():private_directory(directory)
    policy=files('agentic_os').joinpath('policies/effect_review.rego').read_text()
    auth=files('agentic_os').joinpath('policies/review_operator_auth.rego').read_text()
    fingerprint=digest('policy',{'revision':3,'profile':'decision-eligibility/1','authority':policy,'operatorAuth':auth})
    marker=directory/'release.json'
    if marker.exists():
        record=parse_canonical_json(private_read(marker,16384))
        if record!={'revision':3,'digest':fingerprint}:
            raise OwnershipError('Decision policy requires explicit reviewed upgrade')
        if (private_read(directory/'authority.rego',65536).decode()!=policy
                or private_read(directory/'operator_auth.rego',65536).decode()!=auth):
            raise OwnershipError('Decision policy release content changed')
        data=parse_canonical_json(private_read(directory/'data.json',16384))
        if data['profile']!={'revision':3,'digest':fingerprint}:
            raise OwnershipError('Decision policy provenance changed')
    else:
        data={'profile':{'revision':3,'digest':fingerprint},'operator':{'token':secrets.token_urlsafe(32)}}
        private_write(directory/'authority.rego',policy.encode())
        private_write(directory/'operator_auth.rego',auth.encode())
        private_write(directory/'data.json',canonical_bytes(data))
        record={'revision':3,'digest':fingerprint};private_write(marker,canonical_bytes(record))
    return directory,record,data['operator']['token']


def start_review_opa(manifest_path,port):
    if type(port) is not int or not 1024<=port<=65535:
        raise OwnershipError('OPA requires explicit loopback port')
    executable=install_opa(manifest_path);directory,record,token=prepare_review_bundle(manifest_path)
    log=directory/'service.log'
    if not log.exists():private_write(log,b'')
    with log.open('ab') as handle:
        process=subprocess.Popen([str(executable),'run','--server','--addr',f'127.0.0.1:{port}',
            '--authentication=token','--authorization=basic','--skip-version-check','--log-level=error',str(directory)],
            cwd=directory,env={'PATH':'/usr/bin:/bin','HOME':str(manifest_path.parent/'home')},stdout=handle,stderr=handle)
    return process,record,token


def prepare_execution_bundle(manifest_path):
    """Explicit local-synthetic executable4 provision; no default activation.

    Eligibility3 is not a permit. This independently pinned release is bound
    into owned decisions/grants and must separately qualify at execution.
    """
    manifest = load_manifest(manifest_path)
    if manifest["profile"] != "test":
        raise OwnershipError("Executable policy requires owned synthetic target")
    directory = Path(manifest["root"]) / "effect-execution-policy-4"
    if not directory.exists():
        private_directory(directory)
    policy = files("agentic_os").joinpath("policies/effect_execution.rego").read_text()
    auth = files("agentic_os").joinpath("policies/execution_operator_auth.rego").read_text()
    fingerprint = digest("policy", {
        "revision": 4, "profile": "reviewed-execution/1",
        "authority": policy, "operatorAuth": auth,
    })
    record = {"revision": 4, "digest": fingerprint}
    marker = directory / "release.json"
    if marker.exists():
        data = parse_canonical_json(private_read(directory / "data.json", 16384))
        if (
            parse_canonical_json(private_read(marker, 16384)) != record
            or type(data) is not dict or set(data) != {"profile", "operator"}
            or data["profile"] != record
            or type(data["operator"]) is not dict
            or set(data["operator"]) != {"token"}
            or type(data["operator"]["token"]) is not str
            or private_read(directory / "authority.rego", 65536).decode() != policy
            or private_read(directory / "operator_auth.rego", 65536).decode() != auth
        ):
            raise OwnershipError("Execution policy requires explicit reviewed upgrade")
    else:
        data = {"profile": record, "operator": {"token": secrets.token_urlsafe(32)}}
        private_write(directory / "authority.rego", policy.encode())
        private_write(directory / "operator_auth.rego", auth.encode())
        private_write(directory / "data.json", canonical_bytes(data))
        private_write(marker, canonical_bytes(record))
    return directory, record, data["operator"]["token"]


def start_execution_opa(manifest_path, port):
    if type(port) is not int or not 1024 <= port <= 65535:
        raise OwnershipError("Execution policy requires explicit loopback port")
    executable = install_opa(manifest_path)
    directory, record, token = prepare_execution_bundle(manifest_path)
    log = directory / "service.log"
    if not log.exists():
        private_write(log, b"")
    with log.open("ab") as handle:
        process = subprocess.Popen([
            str(executable), "run", "--server", "--addr", f"127.0.0.1:{port}",
            "--authentication=token", "--authorization=basic", "--skip-version-check",
            "--log-level=error", str(directory),
        ], cwd=directory, env={"PATH": "/usr/bin:/bin", "HOME": str(manifest_path.parent / "home")},
            stdout=handle, stderr=handle)
    return process, record, token


def prepare_input_execution_bundle(manifest_path):
    """Explicit local-synthetic exact-input executable5 provision; no default activation.

    Eligibility3 is not a permit. This independently pinned release is bound
    into owned decisions/grants and must separately qualify at execution.
    """
    manifest = load_manifest(manifest_path)
    if manifest["profile"] != "test":
        raise OwnershipError("Exact-input executable policy requires owned synthetic target")
    directory = Path(manifest["root"]) / "input-effect-execution-policy-5"
    if not directory.exists():
        private_directory(directory)
    policy = files("agentic_os").joinpath("policies/input_effect_execution.rego").read_text()
    auth = files("agentic_os").joinpath("policies/input_execution_operator_auth.rego").read_text()
    fingerprint = digest("policy", {
        "revision": 5, "profile": "input-reviewed-execution/1",
        "authority": policy, "operatorAuth": auth,
    })
    record = {"revision": 5, "digest": fingerprint}
    marker = directory / "release.json"
    if marker.exists():
        data = parse_canonical_json(private_read(directory / "data.json", 16384))
        if (
            parse_canonical_json(private_read(marker, 16384)) != record
            or type(data) is not dict or set(data) != {"profile", "operator"}
            or data["profile"] != record
            or type(data["operator"]) is not dict
            or set(data["operator"]) != {"token"}
            or type(data["operator"]["token"]) is not str
            or private_read(directory / "authority.rego", 65536).decode() != policy
            or private_read(directory / "operator_auth.rego", 65536).decode() != auth
        ):
            raise OwnershipError("Execution policy requires explicit reviewed upgrade")
    else:
        data = {"profile": record, "operator": {"token": secrets.token_urlsafe(32)}}
        private_write(directory / "authority.rego", policy.encode())
        private_write(directory / "operator_auth.rego", auth.encode())
        private_write(directory / "data.json", canonical_bytes(data))
        private_write(marker, canonical_bytes(record))
    return directory, record, data["operator"]["token"]


def start_input_execution_opa(manifest_path, port):
    if type(port) is not int or not 1024 <= port <= 65535:
        raise OwnershipError("Execution policy requires explicit loopback port")
    executable = install_opa(manifest_path)
    directory, record, token = prepare_input_execution_bundle(manifest_path)
    log = directory / "service.log"
    if not log.exists():
        private_write(log, b"")
    with log.open("ab") as handle:
        process = subprocess.Popen([
            str(executable), "run", "--server", "--addr", f"127.0.0.1:{port}",
            "--authentication=token", "--authorization=basic", "--skip-version-check",
            "--log-level=error", str(directory),
        ], cwd=directory, env={"PATH": "/usr/bin:/bin", "HOME": str(manifest_path.parent / "home")},
            stdout=handle, stderr=handle)
    return process, record, token


def prepare_input_delegation_bundle(manifest_path):
    """Explicit local-synthetic exact-input delegated6 provision; no default activation.

    Eligibility3 is not a permit. This independently pinned release is bound
    into owned decisions/grants and must separately qualify at execution.
    """
    manifest = load_manifest(manifest_path)
    if manifest["profile"] != "test":
        raise OwnershipError("Exact-input executable policy requires owned synthetic target")
    directory = Path(manifest["root"]) / "input-delegated-execution-policy-6"
    if not directory.exists():
        private_directory(directory)
    policy = files("agentic_os").joinpath("policies/input_delegated_execution.rego").read_text()
    auth = files("agentic_os").joinpath("policies/input_delegation_operator_auth.rego").read_text()
    fingerprint = digest("policy", {
        "revision": 6, "profile": "input-delegated-execution/1",
        "authority": policy, "operatorAuth": auth,
    })
    record = {"revision": 6, "digest": fingerprint}
    marker = directory / "release.json"
    if marker.exists():
        data = parse_canonical_json(private_read(directory / "data.json", 16384))
        if (
            parse_canonical_json(private_read(marker, 16384)) != record
            or type(data) is not dict or set(data) != {"profile", "operator"}
            or data["profile"] != record
            or type(data["operator"]) is not dict
            or set(data["operator"]) != {"token"}
            or type(data["operator"]["token"]) is not str
            or private_read(directory / "authority.rego", 65536).decode() != policy
            or private_read(directory / "operator_auth.rego", 65536).decode() != auth
        ):
            raise OwnershipError("Execution policy requires explicit reviewed upgrade")
    else:
        data = {"profile": record, "operator": {"token": secrets.token_urlsafe(32)}}
        private_write(directory / "authority.rego", policy.encode())
        private_write(directory / "operator_auth.rego", auth.encode())
        private_write(directory / "data.json", canonical_bytes(data))
        private_write(marker, canonical_bytes(record))
    return directory, record, data["operator"]["token"]


def start_input_delegation_opa(manifest_path, port):
    if type(port) is not int or not 1024 <= port <= 65535:
        raise OwnershipError("Execution policy requires explicit loopback port")
    executable = install_opa(manifest_path)
    directory, record, token = prepare_input_delegation_bundle(manifest_path)
    log = directory / "service.log"
    if not log.exists():
        private_write(log, b"")
    with log.open("ab") as handle:
        process = subprocess.Popen([
            str(executable), "run", "--server", "--addr", f"127.0.0.1:{port}",
            "--authentication=token", "--authorization=basic", "--skip-version-check",
            "--log-level=error", str(directory),
        ], cwd=directory, env={"PATH": "/usr/bin:/bin", "HOME": str(manifest_path.parent / "home")},
            stdout=handle, stderr=handle)
    return process, record, token


def prepare_repair_bundle(manifest_path,*,production=False,oidc=False):
    """Explicit local-synthetic exact-input repair7 provision; no default activation.

    Eligibility3 is not a permit. This independently pinned release is bound
    into owned decisions/grants and must separately qualify at execution.
    """
    if type(production) is not bool or type(oidc) is not bool or oidc and not production:
        raise OwnershipError('Explicit repair profile required')
    manifest = load_manifest(manifest_path)
    if manifest["profile"] != "test":
        raise OwnershipError("Exact-input executable policy requires owned synthetic target")
    revision=11 if oidc else 8 if production else 7
    profile='agent-oidc-update-repair-execution/1' if oidc else 'agent-typed-update-repair-execution/1' if production else 'typed-update-repair-execution/1'
    directory = Path(manifest["root"]) / ('agent-oidc-update-repair-execution-policy-11' if oidc else 'agent-typed-update-repair-execution-policy-8' if production else "typed-update-repair-execution-policy-7")
    policy = files("agentic_os").joinpath('policies/agent_oidc_repair_execution.rego' if oidc else 'policies/agent_repair_execution.rego' if production else "policies/repair_execution.rego").read_text()
    auth = files("agentic_os").joinpath("policies/repair_operator_auth.rego").read_text()
    fingerprint = digest("policy", {
        "revision": revision, "profile": profile,
        "authority": policy, "operatorAuth": auth,
    })
    if not directory.exists():private_directory(directory)
    if production:
        # Explicitly selected production releases retain each exact pinned
        # body. Existing draft/release material is never overwritten or used
        # as the current policy when its input digest differs.
        directory=directory/fingerprint
        if not directory.exists():private_directory(directory)
    record = {"revision": revision, "digest": fingerprint}
    marker = directory / "release.json"
    if marker.exists():
        data = parse_canonical_json(private_read(directory / "data.json", 16384))
        if (
            parse_canonical_json(private_read(marker, 16384)) != record
            or type(data) is not dict or set(data) != {"profile", "operator"}
            or data["profile"] != record
            or type(data["operator"]) is not dict
            or set(data["operator"]) != {"token"}
            or type(data["operator"]["token"]) is not str
            or private_read(directory / "authority.rego", 65536).decode() != policy
            or private_read(directory / "operator_auth.rego", 65536).decode() != auth
        ):
            raise OwnershipError("Execution policy requires explicit reviewed upgrade")
    else:
        data = {"profile": record, "operator": {"token": secrets.token_urlsafe(32)}}
        private_write(directory / "authority.rego", policy.encode())
        private_write(directory / "operator_auth.rego", auth.encode())
        private_write(directory / "data.json", canonical_bytes(data))
        private_write(marker, canonical_bytes(record))
    return directory, record, data["operator"]["token"]


def start_repair_opa(manifest_path, port,*,production=False,oidc=False):
    if (type(production) is not bool or type(oidc) is not bool or oidc and not production
            or type(port) is not int or not 1024 <= port <= 65535):
        raise OwnershipError("Execution policy requires explicit loopback port")
    executable = install_opa(manifest_path)
    directory, record, token = (prepare_repair_bundle(manifest_path,production=True,oidc=oidc) if production else prepare_repair_bundle(manifest_path))
    log = directory / "service.log"
    if not log.exists():
        private_write(log, b"")
    with log.open("ab") as handle:
        process = subprocess.Popen([
            str(executable), "run", "--server", "--addr", f"127.0.0.1:{port}",
            "--authentication=token", "--authorization=basic", "--skip-version-check",
            "--log-level=error", str(directory),
        ], cwd=directory, env={"PATH": "/usr/bin:/bin", "HOME": str(manifest_path.parent / "home")},
            stdout=handle, stderr=handle)
    return process, record, token
