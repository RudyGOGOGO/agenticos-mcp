"""Current release evidence and retired identities for a restored runtime.

This reader cannot issue a release. Held operator ports keep their original
BLOCKED generation; a separately verified release must publish every proof.
Neither a signed READY gate nor an archived owner session grants current access.
"""
from datetime import timedelta
from concurrent.futures import Future, ThreadPoolExecutor, TimeoutError as FutureTimeout
from copy import deepcopy
import hashlib
import os
from pathlib import Path
import stat
import subprocess
import sys
from threading import Lock
import time

from agentic_os.contracts.canonical import canonical_bytes
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import utcnow, timestamp
from .artifacts import checked_id
from .files import OwnershipError, check_private
from .ownership import load_manifest
from .resources import read_signed
from . import public_inventory


_program_lock = Lock()
_program_cache = None
_program_layout = None
_program_probe_lock = Lock()
_program_probe = None
_program_probe_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='aos-public-inventory')
_certificate_lock = Lock()
_certificate_cache = None


def _program_inventory(package):
    """Join a fresh public content measurement after every member arrives.

    One metadata worker avoids competing stat loops. A group closes before its
    complete scan; later arrivals queue another fresh group. Completed results
    are never retained here. No signed/private authority enters this worker.
    """
    if not isinstance(package, Path):
        return None
    global _program_probe
    with _program_probe_lock:
        pending = _program_probe
        if pending is None:
            pending = [package, Future(), 1]
            _program_probe = pending
            try:_program_probe_executor.submit(_measure_program_group, pending)
            except RuntimeError:
                _program_probe = None
                raise OwnershipError('Restoration program inventory worker unavailable') from None
        elif pending[0] == package and pending[2] < 64:
            pending[2] += 1
        else:
            pending = None
    if pending is None:
        return _scan_program_inventory(package)
    try:return pending[1].result(timeout=2)
    except FutureTimeout:
        raise OwnershipError('Restoration program inventory deadline exceeded') from None


def _measure_program_group(pending):
    global _program_probe
    try:
        time.sleep(.001)
        # This runs only when earlier scans finish. Seal this group before any
        # metadata read, so every participant receives a post-arrival check.
        with _program_probe_lock:
            if _program_probe is pending:_program_probe = None
        result = _scan_program_inventory(pending[0])
    except BaseException as error:
        with _program_probe_lock:
            if _program_probe is pending:_program_probe = None
        pending[1].set_exception(error)
    else:
        pending[1].set_result(result)


# Execute only this already loaded, fixed public-inventory program. The child
# receives no environment, credentials, imports from the installation or open
# runtime descriptors. Its own GIL prevents stat loops from contending with
# current SQL/network work. There is at most one child in the normal worker.
_PROGRAM_SCAN = r"""
import hashlib,json,os,stat,sys
root=sys.argv[1]
def metadata(name,directory=False):
    info=os.lstat(name)
    if not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
        sys.exit(2 if directory else 3)
    return (name,info.st_dev,info.st_ino,info.st_uid,info.st_mode,info.st_nlink,
        info.st_size,info.st_mtime_ns,info.st_ctime_ns)
def content(name):
    before=metadata(name)
    fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        opened=os.fstat(fd)
        identity=lambda info:(name,info.st_dev,info.st_ino,info.st_uid,info.st_mode,
            info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns)
        if identity(opened)!=before or opened.st_size>8*1024**2:sys.exit(4)
        digest=hashlib.sha256();size=0
        while True:
            block=os.read(fd,1024**2)
            if not block:break
            size+=len(block)
            if size>8*1024**2:sys.exit(4)
            digest.update(block)
        if identity(os.fstat(fd))!=before or metadata(name)!=before:sys.exit(1)
        return before+(digest.hexdigest(),)
    finally:os.close(fd)
try:
    names=[];paths=[]
    metadata(root,True)
    for directory,children,files in os.walk(root,followlinks=False,onerror=lambda _:sys.exit(1)):
        names.append(directory)
        if len(names)>1024:sys.exit(4)
        for child in children:metadata(os.path.join(directory,child),True)
        paths.extend(os.path.join(directory,name) for name in files if name.endswith('.py'))
        if len(paths)>4095:sys.exit(4)
    names.sort();paths.sort();paths.append(os.path.join(root,'contracts/schema/contracts.json'))
    observed=[];total=0
    for name in paths:
        entry=content(name);total+=entry[6]
        if total>64*1024**2:sys.exit(4)
        observed.append(entry)
    value=(root,tuple(metadata(name,True) for name in names),tuple(observed))
    sys.stdout.write(hashlib.sha256(json.dumps(value,separators=(',',':'),ensure_ascii=True).encode()).hexdigest())
except OSError:sys.exit(1)
"""


def _scan_program_inventory(package):
    """Fresh complete public identity/content inventory in a finite child.

    Only a digest crosses back. Every request measures content even if a
    coarse filesystem repeats all timestamps; changed bytes require the
    original release validation. The worker receives no
    environment/private authority/descriptors and is killed/joined on error.
    """
    return public_inventory.measure(package, _PROGRAM_SCAN)


def _release_digest(package):
    """Pin the current restoration boundary in addition to frozen programs."""
    from .recovery_runtime_checkpoint import release_programs
    names = ('adapters/local/recovery_ready.py','adapters/local/public_inventory.py',
        'adapters/local/recovery_gate.py',
        'adapters/local/recovery_history.py','adapters/local/recovery_client.py',
        'adapters/local/recovery_release.py','adapters/local/temporal.py',
        'adapters/local/recovery_runtime_checkpoint.py','adapters/local/recovery_temporal.py',
        'adapters/aws/temporal.py','adapters/local/coordinated_backup.py',
        'adapters/local/recovery_metadata.py','adapters/local/recovery_lineage.py',
        'adapters/local/restoration_binding.py',
        'adapters/local/recovery_operator.py','adapters/aws/managed_restore.py',
        'adapters/aws/coordinated_recovery.py','adapters/aws/recovery.py','adapters/aws/bootstrap.py',
        'adapters/local/recovery_quarantine.py',
        'adapters/local/recovery_ready_receipts.py','adapters/local/certified_receipt_store.py',
        'adapters/local/recovery_key_continuity.py','adapters/local/recovery_key_operations.py',
        'adapters/local/recovery_operations.py',
        'adapters/local/recovery_maintenance.py',
        'adapters/local/recovery_receipts.py','adapters/local/held_receipt_store.py',
        'adapters/local/production_recovery_receipts.py','adapters/local/production_receipt_store.py',
        'adapters/local/production_repair_receipt_store.py','production/repair_receipt.py',
        'production/repair_state.py','production/repair_roots.py','production/repairs.py',
        'effects/repair_execution.py','effects/repair_contracts.py','effects/input_delegation_observer.py',
        'production/reviewed_effect.py','production/write_conflicts.py','production/write_conflict_policies.py',
        'effects/reviewed_observer.py','effects/reviewed_provider.py',
        'effects/input_receipt_authority.py',
        'distribution.py','adapters/sandbox/release.py',
        'adapters/postgres/store.py','identity/service.py','registry/service.py',
        'admission/service.py','control/dispatcher.py','api/runtime.py','production/private_state.py',
        'memory/recovery.py','memory/controls_recovery.py','memory/settings.py','memory/task_context.py',
        'memory/task_lifecycle.py','kernel/lifecycle.py','kernel/ledger.py',
        'adapters/sandbox/budgets.py','contracts/canonical.py','knowledge/service.py')
    value = release_programs(package) | dict(restorationPrograms={name:
        hashlib.sha256(package.joinpath(name).read_bytes()).hexdigest() for name in names})
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def release_digest():
    """Reuse code parsing only while the entire public program inventory agrees.

    Every call checks file identity, actual content and inventory names.
    Signed release, gate, journal and original private keys remain uncached.
    """
    from importlib.resources import files
    # Import before taking the inventory: a cold installed wheel legitimately
    # creates this module's bytecode cache. Validation must still reject any
    # program change after the inventory is captured.
    from . import recovery_runtime_checkpoint
    global _program_cache
    package = files('agentic_os')
    # Inventory reads are independent and every caller still performs them.
    # Serialize only a cache miss's byte validation/publication, avoiding a
    # process-wide queue for current receipt and native integrity checks.
    before = _program_inventory(package)
    cached = _program_cache
    if before is not None and cached is not None and cached[0] == before:
        return cached[1]
    with _program_lock:
        if before is not None and _program_cache is not None and _program_cache[0] == before:
            return _program_cache[1]
        result = _release_digest(package)
        if before is not None:
            if _program_inventory(package) != before:
                raise OwnershipError('Restoration programs changed during validation')
            _program_cache = before, result
        return result

FILE = 'recovery-ready.json'
PROFILE = 'certified-restored-runtime/1'
MANAGED_PROFILE = 'certified-restored-managed-runtime/1'
MARKERS = ('recovery-snapshot.json', FILE, 'recovery-release')
PROOFS = frozenset({'privacy', 'receipts', 'temporal', 'knowledge', 'materials', 'catalog'})
FIELDS = {'profile', 'installationId', 'runId', 'container', 'generation',
    'heldGeneration', 'archiveDigest', 'receiptDigest', 'releaseDigest',
    'issuedAt', 'expiresAt', 'retiredSessions', 'retiredChallenges',
    'retiredExecutions', 'knownKeys', 'proofs'}
PROOF_FIELDS = {'profile', 'kind', 'installationId', 'runId', 'container',
    'heldGeneration', 'receiptDigest', 'complete', 'evidence'}
EVIDENCE_FIELDS = {
    'privacy': {'profiles', 'owners', 'authorityId', 'intentDigest', 'journalsDigest'},
    'receipts': {'admittedEffects', 'observedEffects', 'statesDigest', 'unknownUsageHeld'},
    'temporal': {'namespaceId', 'lineageDigest', 'quarantineDigest', 'workflowRuns', 'originalHistoryPreserved'},
    'knowledge': {'selected', 'publicPurpose', 'relocationDigest'},
    'materials': {'archiveMaterialDigest', 'currentMaterialDigest', 'erasedArtifacts', 'knownKeysDigest'},
    'catalog': {'controlHead', 'components', 'digest'},
}


def restored(path):
    if path is None:
        return False
    root = Path(path).parent
    return any((root/name).exists() or (root/name).is_symlink() for name in MARKERS)


def _digest(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def _sha(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _count(value, maximum, minimum=0):
    return type(value) is int and minimum <= value <= maximum


def _evidence(kind, evidence, value, archive):
    """Closed proof shapes and immutable archive pins, without private hydration."""
    from .ownership import COMPONENTS
    fields=set(EVIDENCE_FIELDS[kind])
    if kind=='receipts' and type(evidence) is dict and 'notStartedEffects' in evidence:
        fields.add('notStartedEffects')
    if type(evidence) is not dict or set(evidence) != fields:
        raise OwnershipError('Restored release evidence unavailable')
    digests = {
        'privacy': ('intentDigest', 'journalsDigest'), 'receipts': ('statesDigest',),
        'temporal': ('lineageDigest', 'quarantineDigest'), 'knowledge': ('relocationDigest',),
        'materials': ('archiveMaterialDigest', 'currentMaterialDigest', 'knownKeysDigest'),
        'catalog': ('digest',),
    }
    valid = all(_digest(evidence[field]) for field in digests[kind])
    if kind == 'privacy':
        checked_id(evidence['authorityId'])
        empty=evidence['profiles']==0 and evidence['owners']==0
        if empty:
            from .restoration_privacy import _empty_capture
            _empty_capture(archive)
        valid = valid and _count(evidence['profiles'],128,0 if empty else 1) and _count(evidence['owners'],128,0 if empty else 1)
    elif kind == 'receipts':
        from .production_recovery_receipts import pending_effects
        checkpoint=archive['receipt']['runtimeCheckpoint']
        pending=checkpoint['pendingEffects']+pending_effects(checkpoint)
        not_started=sum(row.get('kind') in {'agent.effect','agent.repair'} and row['state']=='RESERVED' for row in pending)
        valid = (valid and _count(evidence['admittedEffects'], 4096)
            and _count(evidence['observedEffects'], 4096)
            and _count(evidence.get('notStartedEffects',0),4096)
            and ('notStartedEffects' in evidence)==bool(not_started)
            and evidence.get('notStartedEffects',0)==not_started
            and evidence['admittedEffects']==len(pending)
            and evidence['observedEffects']==len(pending)-not_started
            and evidence['unknownUsageHeld'] is True
            and (bool(pending) or evidence['statesDigest'] == _sha([])))
    elif kind == 'temporal':
        checked_id(evidence['namespaceId'])
        valid = valid and _count(evidence['workflowRuns'], 128) and evidence['originalHistoryPreserved'] is True
    elif kind == 'knowledge':
        valid = (valid and type(evidence['selected']) is bool and type(evidence['publicPurpose']) is bool
            and (evidence['selected'] or not evidence['publicPurpose'] and evidence['relocationDigest'] == _sha(None)))
    elif kind == 'materials':
        pins = archive['materialDigests']
        expected_keys = {name.removeprefix('keys/')[:-4]: pin for name, pin in pins.items()
            if name.startswith('keys/') and name.endswith('.key') and '/' not in name[5:]}
        artifacts = sum(name.startswith('artifacts/') and name.endswith('.json') for name in pins)
        valid = (valid and expected_keys == value['knownKeys']
            and evidence['archiveMaterialDigest'] == _sha(pins)
            and evidence['knownKeysDigest'] == _sha(value['knownKeys'])
            and _count(evidence['erasedArtifacts'], artifacts)
            and (evidence['erasedArtifacts'] != 0
                or evidence['currentMaterialDigest'] == evidence['archiveMaterialDigest']))
    elif kind == 'catalog':
        from .recovery_runtime_checkpoint import checkpoint_head
        from .coordinated_backup import selected_components
        valid = (valid and evidence['controlHead'] == checkpoint_head(archive['receipt']['runtimeCheckpoint'])
            and type(evidence['components']) is list and evidence['components'] == sorted(
                selected_components(archive['receipt'].get('profile','coordinated-recovery/2'))))
    if not valid:
        raise OwnershipError('Restored release evidence differs')


def _identities(values, *, maximum=4096):
    if (type(values) is not list or len(values) > maximum
            or any(type(value) is not str for value in values)
            or values != sorted(set(values))):
        raise OwnershipError('Restored retirement identities unavailable')
    for value in values:
        checked_id(value)


def admitted_archive(path):
    """Authenticate immutable archive lineage without relaxing held readers."""
    from .restoration_binding import FIELDS as ARCHIVE_FIELDS,PROFILE as ARCHIVE_PROFILE,MANAGED_PROFILE as MANAGED_ARCHIVE,placement,placed_fields
    path = Path(path); manifest = load_manifest(path)
    value = read_signed(path.parent/'recovery-snapshot.json', path.parent/'owner.key', maximum=2*1024**2)
    if (type(value) is not dict or set(value) != placed_fields(ARCHIVE_FIELDS,path,manifest=manifest) or value['profile'] != (MANAGED_ARCHIVE if manifest['profile']=='aws-eks/1' else ARCHIVE_PROFILE)
            or any(value[k] != manifest[k] for k in ('installationId', 'runId'))
            or any(value[k]!=v for k,v in placement(path,manifest=manifest).items())
            or type(value['generation']) is not int or not 1 <= value['generation'] <= 2**53-1
            or type(value['receipt']) is not dict
            or value['receipt'].get('installationId') != manifest['installationId']
            or value['receiptDigest'] != hashlib.sha256(canonical_bytes(value['receipt'])).hexdigest()
            or type(value['materialDigests']) is not dict
            or len(value['materialDigests']) > 4096
            or any(type(n) is not str or not _digest(pin) for n, pin in value['materialDigests'].items())):
        raise OwnershipError('Restored archive lineage unavailable')
    if manifest['profile']=='aws-eks/1':
        from agentic_os.adapters.aws.managed_restore import assert_restoration
        assert_restoration(path,value)
    from .recovery_runtime_checkpoint import checked_runtime_checkpoint
    checked_runtime_checkpoint(value['receipt'].get('runtimeCheckpoint'))
    return value


def _release_metadata(path, *, current=None, maintenance=None):
    """Authenticate original release metadata; grant no execution or key use."""
    from . import recovery_gate as gate
    path = Path(path); manifest = load_manifest(path)
    value = read_signed(path.parent/FILE, path.parent/'owner.key', maximum=1024**2)
    if maintenance is not None:
        from .recovery_maintenance import prior_for_maintenance
        value = prior_for_maintenance(path,current,maintenance,value)
    current = gate.state(path) if current is None else current
    archive = admitted_archive(path)
    from .restoration_binding import placement,placed_fields
    managed=manifest['profile']=='aws-eks/1'
    fields=placed_fields(FIELDS,path,manifest=manifest)|({'contentDigest'} if managed else set())
    if (type(value) is not dict or set(value) != fields or value['profile'] != (MANAGED_PROFILE if managed else PROFILE)
            or any(value[k] != manifest[k] for k in ('installationId', 'runId'))
            or any(value[k]!=v for k,v in placement(path,manifest=manifest).items())
            or type(value['generation']) is not int or current['mode'] != 'READY'
            or value['generation'] != current['generation']
            or type(value['heldGeneration']) is not int
            or value['heldGeneration'] != archive['generation']
            or value['generation'] <= value['heldGeneration']
            or value['receiptDigest'] != archive['receiptDigest']
            or value['archiveDigest'] != hashlib.sha256(canonical_bytes(archive)).hexdigest()):
        raise OwnershipError('Current restored release unavailable')
    content_changed=False
    if managed:
        from agentic_os.adapters.aws.readiness import _runtime_content
        if not _digest(value['contentDigest']):
            raise OwnershipError('Current managed runtime content differs')
        content_changed=value['contentDigest']!=_runtime_content()
    if content_changed or value['releaseDigest'] != release_digest():
        if maintenance is None:
            raise OwnershipError('Current restored release unavailable')
        from .recovery_maintenance import checked_rollout_metadata
        checked_rollout_metadata(path,value,current,maintenance)
    try:
        issued, expires = timestamp(value['issuedAt']), timestamp(value['expiresAt'])
        if not issued <= utcnow() or not issued < expires <= issued+timedelta(hours=24):
            raise ValueError()
    except (ValueError, TypeError, KeyError, AttributeError, OverflowError, OSErrorCode):
        raise OwnershipError('Current restored release expired or unavailable') from None
    for field in ('retiredSessions', 'retiredChallenges'):
        _identities(value[field])
    executions = value['retiredExecutions']
    if (type(executions) is not list or len(executions) > 4096
            or any(type(ident) is not str for ident in executions)
            or executions != sorted(set(executions))):
        raise OwnershipError('Restored execution retirement unavailable')
    for ident in executions:
        if type(ident) is not str:
            raise OwnershipError('Restored execution retirement unavailable')
        parts = ident.split(':')
        prefixes={'os','os-schedule','os-proactive-task'}
        if 'production' in archive['receipt']['runtimeCheckpoint']:prefixes.add('os-agent')
        if len(parts) != 4 or parts[0] not in prefixes or parts[1] != manifest['installationId']:
            raise OwnershipError('Restored execution retirement unavailable')
        for part in parts[1:]:
            checked_id(part)
    if (type(value['knownKeys']) is not dict or not 1 <= len(value['knownKeys']) <= 128
            or any(not _digest(pin) for pin in value['knownKeys'].values())
            or type(value['proofs']) is not dict or set(value['proofs']) != PROOFS
            or any(not _digest(pin) for pin in value['proofs'].values())):
        raise OwnershipError('Restored release material unavailable')
    for ident in value['knownKeys']:checked_id(ident)
    for kind in sorted(PROOFS):
        proof = read_signed(path.parent/'recovery-release'/(kind+'.json'), path.parent/'owner.key', maximum=128*1024)
        if (type(proof) is not dict or set(proof) != placed_fields(PROOF_FIELDS,path,manifest=manifest)
                or proof['profile'] != ('restored-managed-release-proof/1' if managed else 'restored-release-proof/1') or proof['kind'] != kind
                or any(proof[k] != value[k] for k in ({'installationId','runId','heldGeneration','receiptDigest'}|set(placement(path,manifest=manifest))))
                or proof['complete'] is not True or type(proof['evidence']) is not dict
                or hashlib.sha256(canonical_bytes(proof)).hexdigest() != value['proofs'][kind]):
            raise OwnershipError('Restored release proof unavailable')
        _evidence(kind, proof['evidence'], value, archive)
    if value['generation'] != value['heldGeneration']+1:
        try:
            from .recovery_maintenance import checked_recertification
        except ImportError:
            raise OwnershipError('Maintenance revalidation unavailable') from None
        checked_recertification(path, value, archive)
    if maintenance is None:
        from .recovery_maintenance import checked_maintenance_state
        checked_maintenance_state(path,value)
    return value


def _certificate(path, *, current=None):
    """Current finite runtime release and known private key availability."""
    value = _release_metadata(path, current=current)
    if timestamp(value['expiresAt']) <= utcnow():
        raise OwnershipError('Current restored release expired or unavailable')
    path = Path(path)
    from .recovery_key_continuity import effective_keys, selector
    from .recovery_history import _key_metadata
    known = effective_keys(path, value)
    _key_metadata(path.parent/'keys', known)
    selector(path, value)
    knowledge=effective_keys(path,value,'knowledge')
    if knowledge:
        _key_metadata(path.parent/'protected-knowledge/keys',knowledge)
        selector(path,value,purpose='knowledge')
    return value


def _proof_inventory(path, *, include_keys=True):
    """Identity/content inventory of signed proofs, plus private key names.

    No encryption key bytes are read. Rewrites with preserved mtime, chmod,
    replacement and added/removed key files invalidate a transaction snapshot.
    Content fingerprints cover signed metadata even on coarse-clock volumes.
    """
    root = Path(path).parent
    key_paths=[]
    if include_keys:
        directory = root/'keys'; check_private(directory, directory=True)
        members = list(directory.iterdir())
        if len(members) > 129:
            raise OwnershipError('Restored key inventory exceeded')
        key_paths=[directory,*members]
        knowledge=root/'protected-knowledge/keys'
        if knowledge.exists() or knowledge.is_symlink():
            check_private(knowledge,directory=True);members=list(knowledge.iterdir())
            if len(members)>129:raise OwnershipError('Restored knowledge key inventory exceeded')
            key_paths += [knowledge,*members]
    paths = [root/name for name in ('manifest.json', 'owner.key', 'recovery-gate.json',
        'recovery-snapshot.json', FILE, 'recovery-release')]
    paths += [root/'recovery-release'/(kind+'.json') for kind in sorted(PROOFS)]
    def configuration_paths(file,*,sql=False):
        from agentic_os.adapters.aws.temporal import load_operator_configuration
        cloud=load_operator_configuration(file)
        result=[file,Path(cloud['server_ca'])]
        if sql:
            aws=cloud['installation']['aws']
            result += [Path(value['ca']) for value in [aws['postgres'],*aws['stores'].values()]]
        return result
    from .recovery_key_continuity import plane
    for purpose in ('history','knowledge'):
        KEY_FILE,INTENT,DIRECTORY,_=plane(purpose)
        for name in (KEY_FILE, INTENT):
            candidate = root/name
            if candidate.exists() or candidate.is_symlink():paths.append(candidate)
        operations = root/DIRECTORY
        if operations.exists() or operations.is_symlink():
            check_private(operations, directory=True)
            children = list(operations.iterdir())
            if len(children)>8:raise OwnershipError('Key operation inventory exceeded')
            paths += [operations, *children]
            for child in children:
                check_private(child, directory=True)
                operation_members = list(child.iterdir())
                if len(operation_members)>2:raise OwnershipError('Key operation material inventory exceeded')
                paths += operation_members
    if (root/'recovery-managed-target.json').exists() or (root/'recovery-managed-target.json').is_symlink():
        paths += [root/'recovery-managed-target.json',root/'managed-recovery-root.json']
        record=read_signed(root/'recovery-managed-target.json',root/'owner.key',maximum=2*1024**2)
        try:paths += configuration_paths(Path(record['configuration']['cloud_configuration']),sql=True)
        except (KeyError,TypeError,AttributeError):
            raise OwnershipError('Managed configuration inventory unavailable') from None
    paths += key_paths
    from .recovery_maintenance import DIRECTORY as MAINTENANCE_DIRECTORY,FILE as MAINTENANCE_FILE
    cursor = root/MAINTENANCE_FILE
    if cursor.exists() or cursor.is_symlink():paths.append(cursor)
    maintenance = root/MAINTENANCE_DIRECTORY
    if maintenance.exists() or maintenance.is_symlink():
        check_private(maintenance,directory=True)
        operations = list(maintenance.iterdir())
        if len(operations)>8:raise OwnershipError('Maintenance inventory exceeded')
        paths += [maintenance,*operations]
        for operation in operations:
            checked_id(operation.name)
            check_private(operation,directory=True)
            material=list(operation.iterdir())
            from .recovery_maintenance import _profile
            # Fingerprint the authenticated inputs, not their entire semantic
            # ancestry on every inventory pass. A changed fingerprint forces
            # certificate() through the unchanged complete intent validator.
            selected=read_signed(operation/'intent.json',root/'owner.key',maximum=2*1024**2)
            if (type(selected) is not dict or selected.get('commandId')!=operation.name
                    or selected.get('profile')!=_profile(path)
                    or len({'cloudRollover','serviceRollover','operatorRollover'}&selected.keys())>1):
                raise OwnershipError('Maintenance inventory intent unavailable')
            allowed={'intent.json','prior-ready.json','ready.json','proof.json'}
            if 'operatorRollover' in selected:
                from agentic_os.adapters.aws.operator_rotation import STAGE_FILE
                allowed|={STAGE_FILE,'prior-operator.key'}
            if len(material)>len(allowed) or any(file.name not in allowed for file in material):
                raise OwnershipError('Maintenance material inventory exceeded')
            paths += material
            if 'operatorConfiguration' in selected:
                paths += [root/'operator.key',root/'operator-state.json']
            if 'operatorRollover' in selected:
                from agentic_os.adapters.aws.operator_rotation import STAGE_FILE
                paths.append(operation/STAGE_FILE)
                retained=operation/'prior-operator.key'
                if retained.exists() or retained.is_symlink():paths.append(retained)
            from .recovery_maintenance import selection_key
            key=selection_key(selected)
            if key:
                for kind in ('before','after'):
                    try:paths += configuration_paths(Path(selected[key][kind]['cloud_configuration']),
                        sql=key in {'serviceRollover','operatorRollover'})
                    except (KeyError,TypeError,AttributeError):
                        raise OwnershipError('Maintenance configuration inventory unavailable') from None

    result = []
    from agentic_os.distribution import read_regular, DistributionError
    for resource in sorted(paths):
        info = resource.lstat()
        if not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode)):
            raise OwnershipError('Restored release resource differs')
        content_digest=None
        if stat.S_ISREG(info.st_mode) and resource.parent not in (root/'keys',root/'protected-knowledge/keys'):
            try:content_digest=hashlib.sha256(read_regular(resource,2*1024**2)).hexdigest()
            except DistributionError:
                raise OwnershipError('Restored release resource changed') from None
        result.append((str(resource), info.st_dev, info.st_ino, info.st_uid,
            info.st_mode, info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns,content_digest))
    return tuple(result)


def certificate(path, *, current=None):
    """Current signed gate and unchanged authenticated release metadata.

    A single bounded cache contains typed metadata only, never signing-key or
    encryption-key bytes, plaintext, owner controls or execution grants. A new
    file identity/name/mode/size/content change invalidates every cached proof. Gate
    signature, release/program pin and finite expiry are checked on every call.
    """
    from . import recovery_gate as gate
    global _certificate_cache
    path = Path(path)
    with _certificate_lock:
        actual = gate.state(path)
        if current is not None and current != actual:
            raise OwnershipError('Current restored release changed')
        before = _proof_inventory(path)
        cached = _certificate_cache
        if cached is not None and cached[0] == path and cached[1] == before:
            value = cached[2]
            if (actual['mode'] != 'READY' or actual['generation'] != value['generation']
                    or value['releaseDigest'] != release_digest()
                    or not timestamp(value['issuedAt']) <= utcnow() < timestamp(value['expiresAt'])):
                raise OwnershipError('Current restored release unavailable')
        else:
            value = _certificate(path, current=actual)
        if value['profile']==MANAGED_PROFILE:
            from agentic_os.adapters.aws.readiness import _runtime_content
            if value['contentDigest']!=_runtime_content():raise OwnershipError('Current managed runtime content differs')
        if _proof_inventory(path) != before:
            raise OwnershipError('Current restored release changed')
        _certificate_cache = path, before, value
        return deepcopy(value)


class TransactionRelease:
    """One authenticated release during a short, gate-locked SQL transaction.

    Each use rechecks file identity/content and finite expiry. The store
    performs full certificate/program verification again before SQL COMMIT.
    Owner controls, journal guards and original deadlines are never cached.
    """
    def __init__(self, path, *, binding_verify=None, temporal_verify=None):
        if ((binding_verify is None)!=(temporal_verify is None)
                or binding_verify is not None and not all(callable(check) for check in (binding_verify,temporal_verify))):
            raise OwnershipError('Complete configured release checks required')
        self.path = Path(path)
        self.__binding_verify,self.__temporal_verify=binding_verify,temporal_verify
        if self.__binding_verify is not None:self.__binding_verify()
        before = _proof_inventory(self.path)
        self.__release = certificate(self.path)
        self.__inventory = _proof_inventory(self.path)
        if before != self.__inventory:
            raise OwnershipError('Restored release changed during verification')

    def current(self):
        if self.__binding_verify is not None:self.__binding_verify()
        if (timestamp(self.__release['expiresAt']) <= utcnow()
                or _proof_inventory(self.path) != self.__inventory):
            raise OwnershipError('Restored transaction release changed')
        return deepcopy(self.__release)

    def verify(self):
        value = self.current()
        if certificate(self.path) != value:
            raise OwnershipError('Restored transaction release changed')
        self.current()

    def verify_temporal(self, connection):
        self.current()
        if self.__temporal_verify is not None:self.__temporal_verify(connection)


def _database_certificate(db, path):
    proof = db.info.get('recovery_release')
    if proof is None:
        return certificate(path)
    if type(proof) is not TransactionRelease or proof.path != Path(path):
        raise OwnershipError('Restored transaction release unavailable')
    return proof.current()


def deny_retired(path, kind, ident, *, code='DENIED'):
    if not restored(path):
        return
    field = {'session':'retiredSessions', 'challenge':'retiredChallenges', 'execution':'retiredExecutions'}.get(kind)
    if field is None:
        raise OSErrorCode('PROFILE_DISABLED')
    value = certificate(path)
    if str(ident) in value[field]:
        raise OSErrorCode(code)


def owner_guard(db, ident):
    path = getattr(db, 'info', {}).get('recovery_manifest')
    if restored(path) and str(ident) in _database_certificate(db, path)['retiredSessions']:
        raise OSErrorCode('DENIED')


def challenge_guard(db, ident):
    path = getattr(db, 'info', {}).get('recovery_manifest')
    if restored(path) and str(ident) in _database_certificate(db, path)['retiredChallenges']:
        raise OSErrorCode('UNAUTHENTICATED')
