"""Explicit operator parking; a restored process cannot silently reopen a lane.

The gate is outside SQL, signed by the owned installation and checked again by
each control transaction. Historical installations without a selected gate keep
their original profile. A present but unreadable gate always fails closed.
"""
from contextlib import contextmanager
from pathlib import Path
import time

from .files import OwnershipError
from .operator import verify_operator
from .ownership import load_manifest
from .resources import file_lock, read_signed, write_signed

MODES = {'READY', 'PARKED', 'RESTORING', 'BLOCKED'}
REASONS = {'operator-park', 'snapshot', 'restore', 'reconciliation-required', 'verified'}
FIELDS = {'version', 'installationId', 'runId', 'generation', 'mode', 'reason', 'changedAt'}


def selected(path):
    from .recovery_ready import MARKERS
    from .recovery_metadata import SOURCE_FILE
    root = Path(path).parent
    return any((root/name).exists() or (root/name).is_symlink()
        for name in ('recovery-gate.json', SOURCE_FILE, *MARKERS))


def state(path):
    manifest = load_manifest(Path(path))
    value = read_signed(Path(path).parent / 'recovery-gate.json', Path(path).parent / 'owner.key')
    if (type(value) is not dict or set(value) != FIELDS or type(value['version']) is not int
            or value['version'] != 1 or any(value[k] != manifest[k] for k in ('installationId', 'runId'))
            or type(value['generation']) is not int or not 1 <= value['generation'] <= 2**53-1
            or type(value['changedAt']) is not int or value['changedAt'] < 0
            or value['mode'] not in MODES or value['reason'] not in REASONS):
        raise OwnershipError('Recovery gate binding unavailable')
    return value


def assert_runtime(path):
    if load_manifest(Path(path))['profile']=='aws-eks/1':
        raise OwnershipError('Explicit qualified AWS runtime proof required')
    from .recovery_metadata import cloud_source_selected
    if cloud_source_selected(path):raise OwnershipError('Original Cloud source remains parked')
    if selected(path):
        current = state(path)
        if current['mode'] != 'READY':
            raise OwnershipError('Recovery reconciliation required')
        from .recovery_ready import restored, certificate
        if restored(path):
            certificate(path, current=current)


@contextmanager
def runtime_guard(path):
    # Always lock, including the transition from an unselected installation.
    # This is held only for a short SQL transaction, never a provider await.
    with file_lock(Path(path).parent / 'recovery-gate.lock', timeout=2, shared=True):
        if load_manifest(Path(path))['profile']=='aws-eks/1':
            raise OwnershipError('Explicit qualified AWS runtime proof required')
        from .recovery_ready import restored, TransactionRelease
        if restored(path):
            proof = TransactionRelease(path)
        else:
            assert_runtime(path)
            proof = None
        yield proof
        if proof is not None:
            proof.current()


def _write(path, *, mode, reason):
    if mode not in MODES or reason not in REASONS:
        raise OwnershipError('Unregistered recovery transition')
    manifest = load_manifest(Path(path))
    prior = state(path) if selected(path) else None
    value = dict(version=1, installationId=manifest['installationId'], runId=manifest['runId'],
        generation=prior['generation']+1 if prior else 1, mode=mode, reason=reason, changedAt=int(time.time()))
    if value['generation'] > 2**53-1:
        raise OwnershipError('Recovery generation exhausted')
    write_signed(Path(path).parent / 'recovery-gate.json', value, Path(path).parent / 'owner.key')
    return value


def park(path, token):
    verify_operator(Path(path), token)
    with file_lock(Path(path).parent / 'recovery-gate.lock', timeout=2):
        if selected(path) and state(path)['mode'] in {'RESTORING', 'BLOCKED'}:
            raise OwnershipError('Restore requires explicit reconciliation')
        return _write(path, mode='PARKED', reason='operator-park')


def health(path, token):
    verify_operator(Path(path), token)
    if not selected(path):
        return dict(profile='legacy', state='unselected', enabledLanes=[])
    value = state(path)
    if value['mode'] == 'READY':
        try:
            assert_runtime(path)
        except (OwnershipError, OSError, ValueError):
            return dict(profile='coordinated-recovery/1', state='BLOCKED',
                generation=value['generation'], reason='reconciliation-required', enabledLanes=[])
    return dict(profile='coordinated-recovery/1', state=value['mode'],
        generation=value['generation'], reason=value['reason'], enabledLanes=[])


def resume_idle(path, token, *, expected_generation):
    """Resume only an original parked, unregistered health installation.

    Restored installations and installations with any task/host history require
    the full recovery protocol. Empty counts cannot stand in for host receipts.
    """
    verify_operator(Path(path), token)
    from .recovery_metadata import cloud_source_selected
    if cloud_source_selected(path):raise OwnershipError('Original Cloud source remains parked')
    from .target import connect_owned
    from .recovery_ready import restored
    with file_lock(Path(path).parent/'recovery-gate.lock', timeout=2):
        value = state(path)
        if (value['mode'] != 'PARKED' or type(expected_generation) is not int
                or value['generation'] != expected_generation
                or restored(path)):
            raise OwnershipError('Original idle profile is not resumable')
        with connect_owned(Path(path), role='migrator') as db:
            db.execute("SET LOCAL lock_timeout='2s'")
            db.execute("SET LOCAL statement_timeout='3s'")
            for table in ('os_applications', 'os_tasks', 'os_dispatches'):
                if db.execute('SELECT count(*) FROM '+table).fetchone()[0]:
                    raise OwnershipError('Registered history requires full reconciliation')
        return _write(path, mode='READY', reason='verified')
