"""Scoped immutable Host credentials for an explicit filesystem installation."""
import hashlib
import hmac
from uuid import UUID

from .files import OwnershipError,check_private,private_read,private_write
from .resources import canonical_path,ensure_private


class FileCredentials:
    def __init__(self,root):
        self.root=canonical_path(root)
        check_private(root if root.exists() else root.parent,directory=True)

    def path(self,application,reference):
        canonical_path(self.root)
        application=str(UUID(str(application)))
        if type(reference) is not str or not reference:raise OwnershipError('Invalid credential reference')
        return self.root/hashlib.sha256((application+'\0'+reference).encode()).hexdigest()

    def get(self,application,reference):
        return private_read(self.path(application,reference),256).decode('ascii')

    def put(self,application,reference,secret):
        if type(secret) is not str or not 32<=len(secret)<=256 or not secret.isascii():
            raise OwnershipError('Invalid Host credential')
        path=self.path(application,reference)
        ensure_private(self.root)
        if path.exists():
            if not hmac.compare_digest(private_read(path).decode(),secret):raise OwnershipError('Credential rotation requires a new reference')
        else:private_write(path,secret.encode())
