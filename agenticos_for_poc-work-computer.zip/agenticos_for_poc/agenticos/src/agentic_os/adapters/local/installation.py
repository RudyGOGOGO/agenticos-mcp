"""Delegate the owned local profile through the same explicit backend ports.

Every connection and transaction retains its original target/recovery guards.
This factory performs no seed, migration, dependency setup or cloud discovery.
"""
from pathlib import Path
from uuid import UUID

from agentic_os.adapters.installation import InstallationPorts,ComponentPorts
from .artifacts import LocalArtifacts,LocalKeys
from .host_credentials import FileCredentials
from .files import OwnershipError
from .operator import verify_operator
from .ownership import load_manifest
from .recovery_gate import runtime_guard
from .target import connect_owned


def owned_installation_ports(manifest):
    manifest=Path(manifest);value=load_manifest(manifest);root=Path(value['root'])
    if value['profile']!='test':raise OwnershipError('Explicit owned-local installation profile required')
    from agentic_os.adapters.embedding.rpc import EmbeddingClient
    from agentic_os.knowledge.access import connect_public,knowledge_keys
    components=ComponentPorts(installation_id=UUID(value['installationId']),
        retrieval=lambda:connect_owned(manifest,component='retrieval'),
        knowledge=lambda:connect_owned(manifest,component='knowledge'),
        knowledge_public=lambda:connect_public(manifest),
        knowledge_operator=lambda:connect_owned(manifest,component='knowledge',role='migrator'),
        knowledge_keys=lambda:knowledge_keys(manifest),embedding=lambda:EmbeddingClient(manifest))
    return InstallationPorts(installation_id=UUID(value['installationId']),root=root,
        connect=lambda:connect_owned(manifest),transaction_guard=lambda:runtime_guard(manifest),
        operator=lambda token:verify_operator(manifest,token),credentials=FileCredentials(root/'credentials'),
        artifacts=LocalArtifacts(root/'artifacts',LocalKeys(root/'keys')),components=components)
