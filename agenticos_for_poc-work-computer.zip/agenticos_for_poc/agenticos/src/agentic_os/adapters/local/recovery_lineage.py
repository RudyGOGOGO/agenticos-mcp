"""Immutable logical workflow identity, independent of a readiness generation.

This record authenticates lineage only. It never opens a runtime lane or makes
an old operator inspection a current reconciliation certificate.
"""
import hashlib
from pathlib import Path
from uuid import UUID

from agentic_os.contracts.canonical import canonical_bytes
from .files import OwnershipError
from .ownership import load_manifest
from .resources import read_signed, write_signed
from .restoration_binding import placement,placed_fields

FILE = 'temporal-lineage.json'
PROFILE = 'restored-temporal-lineage/1'
CLOUD_PROFILE = 'restored-cloud-temporal-lineage/1'
FIELDS = {'profile','installationId','runId','container','receiptDigest','serviceDigest','original'}


def namespace_id(path, name, *, allow_absent=False):
    from .target import connect_owned
    with connect_owned(Path(path), component='temporal', role='migrator') as db:
        db.execute("SET LOCAL lock_timeout='2s'")
        db.execute("SET LOCAL statement_timeout='3s'")
        if db.execute("SELECT pg_get_userbyid(relowner)=current_user FROM pg_class "
                "WHERE oid='public.namespaces'::regclass").fetchone() != (True,):
            raise OwnershipError('Original namespace table ownership differs')
        rows = db.execute('SELECT id FROM namespaces WHERE name=%s LIMIT 2', (name,)).fetchall()
    if not rows and allow_absent:return None
    if len(rows) != 1 or not isinstance(rows[0][0], (bytes, memoryview)) or len(rows[0][0]) != 16:
        raise OwnershipError('Original namespace identifier unavailable')
    return str(UUID(bytes=bytes(rows[0][0])))


def service_digest(binding):
    return hashlib.sha256(canonical_bytes({k:v for k,v in binding.items() if k!='port'})).hexdigest()


def load_lineage(path, binding):
    path=Path(path);manifest=load_manifest(path)
    value=read_signed(path.parent/FILE,path.parent/'owner.key',maximum=128*1024)
    expected_profile=CLOUD_PROFILE if binding.get('profile') in {'cloud-temporal-recovery-service/1','self-hosted-temporal-recovery-service/1'} else PROFILE
    if (type(value) is not dict or set(value)!=placed_fields(FIELDS,path,manifest=manifest) or value['profile']!=expected_profile
            or any(value[k]!=manifest[k] for k in ('installationId','runId'))
            or any(value[k]!=v for k,v in placement(path,manifest=manifest).items())
            or value['serviceDigest']!=service_digest(binding)
            or type(value['receiptDigest']) is not str or len(value['receiptDigest'])!=64
            or any(c not in '0123456789abcdef' for c in value['receiptDigest'])):
        raise OwnershipError('Original workflow lineage differs')
    from .recovery_metadata import checked_temporal,checked_cloud_temporal
    if expected_profile==CLOUD_PROFILE:checked_cloud_temporal(value['original'],manifest['installationId'])
    else:checked_temporal(value['original'],manifest['installationId'],require_id=True)
    return value


def publish_lineage(path, record, binding):
    path=Path(path);manifest=load_manifest(path)
    profile=CLOUD_PROFILE if binding.get('profile') in {'cloud-temporal-recovery-service/1','self-hosted-temporal-recovery-service/1'} else PROFILE
    value={k:record[k] for k in placed_fields(FIELDS,path,manifest=manifest)-{'profile'}}|dict(profile=profile)
    if value['serviceDigest']!=service_digest(binding) or record['state']!='INSPECTED':
        raise OwnershipError('Original workflow inspection is incomplete')
    marker=path.parent/FILE
    if marker.exists() or marker.is_symlink():
        if load_lineage(path,binding)!=value:raise OwnershipError('Immutable workflow lineage changed')
    else:write_signed(marker,value,path.parent/'owner.key')
    return load_lineage(path,binding)
