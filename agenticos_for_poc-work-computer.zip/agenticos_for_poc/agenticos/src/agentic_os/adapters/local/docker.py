"""Bounded Docker control for an owned installation; never exposed to cognition."""
import json
import os
from pathlib import Path
import subprocess
import time

from .files import OwnershipError, private_write, check_private


class DockerOperationError(OwnershipError):
    """Fixed diagnostics only; never retain raw stderr, arguments or secrets."""

    def __init__(self, category, returncode=None, *, reason=None):
        self.category = category
        self.returncode = returncode
        self.reason = reason
        super().__init__("Owned Docker operation failed: " + category
            + (" (" + reason + ")" if reason else ""))


def _inspection(args):
    # The complete inventory begins with one fixed read-only identity listing.
    # No filters, formatting, abbreviated IDs or caller-supplied options qualify.
    if args == ("network", "ls", "--quiet", "--no-trunc"):
        return True
    # Complete network inventories use bounded pages of exact daemon IDs.
    # A failed read may return only part of a page; discard it and let the
    # inventory caller validate every identity in the successful replacement.
    # Match network_inventory's existing128-identity page, including its
    # final partial page. Larger or malformed requests still never repeat.
    if 4 <= len(args) <= 130 and args[:2] == ("network", "inspect"):
        identities = args[2:]
        return len(set(identities)) == len(identities) and all(
            len(ident) == 64 and all(c in "0123456789abcdef" for c in ident)
            for ident in identities
        )
    return (
        len(args) == 2 and args[0] == "inspect"
        or len(args) == 3 and args[0] in {"image", "network", "volume", "container"}
        and args[1] == "inspect"
    ) and not args[-1].startswith("-")


def _failure_category(stderr):
    value = stderr.lower()
    if "unexpected eof" in value or value.strip().endswith(": eof"):
        return "transport-eof"
    if "connection reset by peer" in value:
        return "transport-reset"
    if "cannot connect to the docker daemon" in value or "connection refused" in value:
        return "transport-unavailable"
    return "operation-rejected"


def _failure_reason(stderr):
    # Fixed diagnostic vocabulary only; unknown errors still fail without
    # retry. Never disclose raw daemon text, private names or CLI arguments.
    value = stderr[:8192].lower()
    for reason, phrases in (
        ('object-unavailable', ('no such image', 'no such container', 'no such network', 'no such volume')),
        ('permission-denied', ('permission denied', 'access is denied')),
        ('resource-exhausted', ('resource temporarily unavailable', 'too many open files', 'no space left on device', 'cannot allocate memory')),
        ('storage-io', ('input/output error', 'read-only file system')),
        ('daemon-internal', ('500 internal server error', '502 bad gateway', '503 service unavailable')),
        ('transport-interrupted', ('broken pipe', 'context canceled', 'context cancelled', 'context deadline exceeded')),
    ):
        if any(phrase in value for phrase in phrases):return reason
    return 'unclassified'


class DockerControl:
    def __init__(self, manifest: dict):
        self.manifest = manifest
        self.root = Path(manifest["root"])
        check_private(self.root, directory=True)
        client = self.root / "docker-client"
        check_private(client, directory=True)
        if not (client / "config.json").exists():
            private_write(client / "config.json", b'{"auths":{}}')
        self.environment = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "HOME": str(self.root / "home"), "DOCKER_CONFIG": str(client),
            "DOCKER_HOST": manifest["dockerEndpoint"]}

    def network_metadata(self, *, deadline):
        """One complete bounded read through the existing fixed Engine transport.

        The inventory consumer still validates every identity and address.
        No cache, filter, resource mutation or new network authority is supplied.
        """
        from .capacity_probe import CapacityProbeControl
        control=CapacityProbeControl(self.manifest,deadline=deadline)
        try:return json.loads(control._request('GET','/networks'))
        except (ValueError,UnicodeError):
            raise OwnershipError('Docker network inventory identity changed') from None

    def command(self, *args, timeout=60, input=None) -> str:
        args = tuple(map(str, args))
        deadline = time.monotonic() + timeout
        # Only exact metadata reads may repeat a proven transport failure.
        # The caller must still validate the entire successful ownership result.
        attempts = 2 if input is None and _inspection(args) else 1
        for attempt in range(attempts):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise DockerOperationError("deadline-exceeded")
            try:
                result = subprocess.run(["docker", *args], env=self.environment,
                    cwd=self.root, capture_output=True, text=True,
                    timeout=remaining, input=input)
            except subprocess.TimeoutExpired:
                raise DockerOperationError("deadline-exceeded") from None
            except OSError:
                raise DockerOperationError("cli-unavailable") from None
            if not result.returncode:
                return result.stdout.strip()
            category = _failure_category(result.stderr)
            if category == "operation-rejected" or attempt + 1 == attempts:
                raise DockerOperationError(category, result.returncode, reason=_failure_reason(result.stderr))
            remaining = deadline - time.monotonic()
            if remaining <= .05:
                raise DockerOperationError("deadline-exceeded")
            time.sleep(.05)

    def binary(self, *args, input: bytes, timeout=90, max_bytes=67108864) -> bytes:
        # A restore may already have written data when transport fails. Never
        # repeat a binary operation; report only fixed, credential-free evidence.
        try:
            result = subprocess.run(["docker", *map(str, args)], env=self.environment,
                cwd=self.root, capture_output=True, timeout=timeout, input=input)
        except subprocess.TimeoutExpired:
            raise DockerOperationError("deadline-exceeded") from None
        except OSError:
            raise DockerOperationError("cli-unavailable") from None
        if result.returncode:
            category = _failure_category(result.stderr[:8192].decode("utf-8", "replace"))
            raise DockerOperationError(category, result.returncode)
        if len(result.stdout) > max_bytes:
            raise DockerOperationError("output-envelope-exceeded")
        return result.stdout

    def volume_usage(self, volume: str) -> int:
        """Bounded exact owned-volume metadata; no unrelated daemon-wide scan."""
        from .volume_accounting import measure_owned_volume
        return measure_owned_volume(self, volume)

    def inspect_owned(self, manifest: dict, *, require_running: bool = True) -> dict:
        binding = manifest["postgres"]
        if binding is None:
            raise OwnershipError("PostgreSQL installation has not been provisioned")
        obj = json.loads(self.command("inspect", binding["container"]))[0]
        labels = obj["Config"].get("Labels", {})
        expected = {"io.agentic-os.installation": manifest["installationId"],
                    "io.agentic-os.run": manifest["runId"], "io.agentic-os.component": "postgres"}
        if any(labels.get(key) != value for key, value in expected.items()):
            raise OwnershipError("Foreign PostgreSQL container")
        image = json.loads(self.command("image", "inspect", binding["image"]))[0]
        if obj["Image"] != binding["imageId"] or image["Id"] != binding["imageId"]:
            raise OwnershipError("Pinned component image changed")
        config = obj["HostConfig"]
        if (config["Privileged"] or config.get("CapAdd") or config["NetworkMode"] == "host"
                or config["Memory"] != 1073741824 or config["PidsLimit"] != 128
                or config.get("SecurityOpt") != ["no-new-privileges:true"]):
            raise OwnershipError("Unqualified component privileges/network")
        networks=set(obj['NetworkSettings'].get('Networks',{}))
        allowed={'bridge'}
        if (self.root/'temporal-service.json').exists():
            from .temporal import load_binding
            allowed.add(load_binding(self.root/'manifest.json')['network'])
        if networks!=allowed:
            raise OwnershipError('Unqualified PostgreSQL network attachment')
        ports = obj["NetworkSettings"].get("Ports", {})
        if obj["State"]["Running"] and (set(ports) != {"5432/tcp"} or ports["5432/tcp"] != [
            {"HostIp": "127.0.0.1", "HostPort": str(binding["port"])}]):
            raise OwnershipError("PostgreSQL endpoint does not match owned container")
        if not obj["State"]["Running"] and require_running:
            raise OwnershipError("Owned PostgreSQL is unavailable")
        published = config.get("PortBindings", {})
        if (set(published) != {"5432/tcp"} or len(published["5432/tcp"]) != 1
                or published["5432/tcp"][0]["HostIp"] != "127.0.0.1"):
            raise OwnershipError("Component has an unqualified published endpoint")
        password_path = str(self.root / "bootstrap-password")
        allowed_sources = {password_path, "/host_mnt" + password_path}
        mounts = obj["Mounts"]
        if len(mounts) != 2:
            raise OwnershipError("Unqualified component filesystem mounts")
        for mount in mounts:
            if mount["Type"] == "volume":
                if mount.get("Name") != binding["volume"] or mount["Destination"] != "/var/lib/postgresql/data":
                    raise OwnershipError("Foreign PostgreSQL volume")
            elif (mount["Type"] != "bind" or mount["Source"] not in allowed_sources
                  or mount["Destination"] != "/run/os-bootstrap-password" or mount["RW"]):
                raise OwnershipError("Unqualified component bind mount")
        volume = json.loads(self.command("volume", "inspect", binding["volume"]))[0]
        if any(volume.get("Labels", {}).get(key) != value for key, value in expected.items()):
            raise OwnershipError("Foreign volume ownership")
        return obj
