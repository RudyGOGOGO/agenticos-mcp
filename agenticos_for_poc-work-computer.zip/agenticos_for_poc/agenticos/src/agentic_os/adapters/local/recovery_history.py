"""Current execution authority before restored history key access.

The retained codec and workflow programs keep their original bytes. This
explicit restored profile carries its guard through SDK context copies. Host
checks finish with SQL closed; local controls remain locked through key use.
"""
import asyncio
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import timedelta
import hashlib
import hmac
from uuid import UUID

from sqlalchemy import select
from temporalio.converter import WorkflowSerializationContext, ActivitySerializationContext

from agentic_os.adapters.postgres.models import (Task, TaskControl, BudgetRoot,
    Admission, TaskMemoryBinding, TaskMemoryErasure)
from agentic_os.adapters.temporal.privacy import HistoryCodec, HistoryUnavailable
from agentic_os.admission.service import guarded_owner, stored_principal
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import utcnow, fresh, subject_ref
from agentic_os.identity.service import scoped
from .artifacts import checked_id, LocalKeys, LocalArtifacts
from .files import OwnershipError, check_private, private_read
from .resources import file_lock
from .recovery_ready import certificate, admitted_archive


class ProtectedHistoryCodec(HistoryCodec):
    def __init__(self, keys, namespace, installation_id, authority, context=None):
        super().__init__(keys, namespace, installation_id, context)
        self.authority = authority

    def with_context(self, context):
        return ProtectedHistoryCodec(self.keys, self.namespace, self.installation_id,
            self.authority, context)

    def _operate(self, payloads, permit, operation):
        try:
            with self.authority.guard(self.context, permit) as keys:
                codec = HistoryCodec(keys, self.namespace, self.installation_id, self.context)
                return getattr(codec, operation)(payloads)
        except Exception:
            raise HistoryUnavailable() from None

    def _encode(self, payloads):
        # A synchronous bypass has no fresh HostBridge proof.
        raise HistoryUnavailable()

    def _decode(self, payloads):
        raise HistoryUnavailable()

    async def _authorized(self, payloads, operation):
        try:
            permit = await self.authority.prepare(self.context)
            return await asyncio.to_thread(self._operate, payloads, permit, operation)
        except Exception:
            raise HistoryUnavailable() from None

    async def encode(self, payloads):
        return await self._authorized(payloads, '_encode')

    async def decode(self, payloads):
        return await self._authorized(payloads, '_decode')


class _PinnedKeys(LocalKeys):
    """Operation-local checked bytes; no second active-pointer/key-file read."""
    def __init__(self, active, keys):
        self._active, self._keys = active, keys

    def active(self):
        return self._active

    def _key(self, ident):
        try:
            return self._keys[checked_id(ident)]
        except KeyError:
            raise OwnershipError('History key was not admitted') from None


def _key_metadata(directory, expected):
    """Check all required key-file availability before any private bytes."""
    check_private(directory, directory=True)
    if type(expected) is not dict or not 1 <= len(expected) <= 128:
        raise OwnershipError('Restored known key inventory unavailable')
    for ident in expected:checked_id(ident)
    names = {path.name for path in directory.iterdir()}
    if names != {'active.json'} | {ident+'.key' for ident in expected}:
        raise OwnershipError('Restored key inventory differs')
    for name in sorted(names):
        path = directory/name; check_private(path); info = path.lstat()
        if info.st_nlink != 1 or (not 1 <= info.st_size <= 128 if name == 'active.json' else info.st_size != 32):
            raise OwnershipError('Restored known key file unavailable')


def pinned_keys(directory, expected):
    # Call only after current authorization. Unknown/missing keys are never
    # adopted, created or selected as a request-time repair.
    _key_metadata(directory, expected)
    active = parse_canonical_json(private_read(directory/'active.json', 128))
    if type(active) is not dict or set(active) != {'id'} or active['id'] not in expected:
        raise OwnershipError('Restored active key differs')
    keys = {}
    for ident, pin in expected.items():
        checked_id(ident)
        raw = private_read(directory/(ident+'.key'), 32)
        if len(raw) != 32 or hashlib.sha256(raw).hexdigest() != pin:
            raise OwnershipError('Restored known key differs')
        keys[ident] = raw
    return _PinnedKeys(active['id'], keys)


@dataclass(frozen=True)
class _Permit:
    authority: object
    workflow_id: str
    certificate_digest: str
    actor: object
    metadata_digest: str
    host_state: dict
    checked_at: object


class RuntimeHistoryAuthority:
    """Current task history purpose; this grants no task/effect execution."""
    def __init__(self, runtime, namespace):
        from agentic_os.api.runtime import IdentityRuntime
        if type(runtime) is not IdentityRuntime:
            raise OSErrorCode('PROFILE_DISABLED')
        self.runtime, self.path, self.namespace = runtime, runtime.manifest, namespace

    def _identity(self, context):
        if (not isinstance(context, (WorkflowSerializationContext, ActivitySerializationContext))
                or context.namespace != self.namespace):
            raise OSErrorCode('DENIED')
        parts = context.workflow_id.split(':')
        if len(parts) != 4 or parts[0] != 'os':
            raise OSErrorCode('PROFILE_DISABLED')
        for part in parts[1:]:
            checked_id(part)
        value = certificate(self.path)
        if parts[1] != value['installationId'] or context.workflow_id in value['retiredExecutions']:
            raise OSErrorCode('DENIED')
        return parts, value

    @staticmethod
    def _root_allowed(root, task):
        # Encoding the truthful final Activity/result can follow the SQL
        # close of a settled root. This permits history only, never execution.
        return bool(root.deadline > utcnow() and (root.state == 'ACTIVE'
            or root.state == 'CLOSED' and task.state in {'COMPLETED','FAILED'}))

    def _metadata(self, db, parts, actor=None):
        runtime = self.runtime
        if runtime.admission is None or runtime.admission.budgets is None:
            raise OSErrorCode('PROFILE_DISABLED')
        admission = db.scalar(select(Admission).where(
            Admission.installation_id == UUID(parts[1]), Admission.application_id == UUID(parts[2]),
            Admission.task_id == UUID(parts[3])))
        if admission is None:
            raise OSErrorCode('DENIED')
        current = stored_principal(admission.authority)
        if actor is not None and current != actor:
            raise OSErrorCode('CONFLICT')
        actor = current
        # Journal guards precede identity locks. They do not open private
        # encryption keys and survive the actual SQL commit.
        memory = runtime.task_memory
        binding = db.scalar(select(TaskMemoryBinding).where(*scoped(TaskMemoryBinding, actor.subject),
            TaskMemoryBinding.task_id == UUID(parts[3])))
        if binding is not None:
            if memory is None:
                raise OSErrorCode('PROFILE_DISABLED')
            from agentic_os.memory.recovery import guard_memory
            guard_memory(db, actor.subject, memory.settings.recovery)
        task = db.scalar(select(Task).where(*scoped(Task, actor.subject), Task.id == UUID(parts[3]))
            .execution_options(populate_existing=True))
        root = db.scalar(select(BudgetRoot).where(*scoped(BudgetRoot, actor.subject),
            BudgetRoot.id == task.budget_root_id)) if task else None
        if (not task or not root or subject_ref(admission) != actor.subject
                or root.admission_id != admission.id or root.profile_ref != runtime.admission.budgets.guard_profile
                or not self._root_allowed(root, task) or min(root.deadline, task.deadline) <= utcnow()
                or task.state in {'CANCELLED','EXPIRED','QUARANTINED'}):
            raise OSErrorCode('DENIED')
        ids = sorted({task.id, root.root_task_id})
        controls = list(db.scalars(select(TaskControl).where(*scoped(TaskControl, actor.subject),
            TaskControl.task_id.in_(ids)).order_by(TaskControl.task_id).with_for_update()
            .execution_options(populate_existing=True)))
        if len(controls) != len(ids) or any(row.state != 'ACTIVE' for row in controls):
            raise OSErrorCode('DENIED')
        guarded_owner(db, actor, registration_revision=admission.registration_revision)
        task = db.scalar(select(Task).where(*scoped(Task, actor.subject), Task.id == task.id)
            .with_for_update().execution_options(populate_existing=True))
        if (task.deadline <= utcnow()
                or task.state in {'CANCELLED','EXPIRED','QUARANTINED'}):
            raise OSErrorCode('DENIED')
        root = db.scalar(select(BudgetRoot).where(*scoped(BudgetRoot, actor.subject), BudgetRoot.id == root.id)
            .with_for_update().execution_options(populate_existing=True))
        if not self._root_allowed(root, task):
            raise OSErrorCode('DENIED')
        memory_metadata = None
        if binding is not None:
            from agentic_os.memory.task_context import epoch_values, BOUND_EPOCHS
            settings = memory.settings.locked(db, actor)
            if (binding.deadline <= utcnow() or binding.session_id != actor.session_id
                    or epoch_values(settings) != epoch_values(binding, BOUND_EPOCHS)
                    or binding.journal_sequence != memory.journal_sequence(db, actor)
                    or db.scalar(select(TaskMemoryErasure.id).where(*scoped(TaskMemoryErasure, actor.subject),
                        TaskMemoryErasure.binding_id == binding.id))):
                raise OSErrorCode('DENIED')
            protected = memory.knowledge_binding(db, actor, binding)
            if protected is not None:
                self._knowledge_metadata(db, actor, protected)
            memory_metadata = dict(id=str(binding.id), epochs=list(epoch_values(binding, BOUND_EPOCHS)),
                journalSequence=binding.journal_sequence, protected=protected)
        value = dict(admissionDigest=admission.digest, authority=admission.authority,
            taskId=str(task.id), deadline=task.deadline.isoformat(), rootId=str(root.id),
            rootDeadline=root.deadline.isoformat(), controls=[dict(id=str(row.task_id), epoch=row.epoch) for row in controls],
            memory=memory_metadata)
        return actor, hashlib.sha256(canonical_bytes(value)).hexdigest(), binding

    def _knowledge_metadata(self, db, actor, binding):
        """Current purpose/revisions before the later protected-key MAC check."""
        from agentic_os.knowledge.service import scope_of, KB_SCOPE
        from agentic_os.identity.context import timestamp
        from agentic_os.contracts.validation import validate_contract
        validate_contract('KnowledgePlannerBinding', binding)
        knowledge = self.runtime.protected_knowledge
        value = binding['value']; scope = scope_of(actor.subject)
        if (knowledge is None or value['scope'] != scope
                or value['validUntil'] is not None and timestamp(value['validUntil']) <= utcnow()):
            raise OSErrorCode('DENIED')
        marker = str(knowledge.root)
        held = db.info.setdefault('protected_knowledge_guards', set())
        if marker not in held:
            db.info['resource_guards'].enter_context(file_lock(knowledge.root/'publication.lock', timeout=.1, shared=True))
            held.add(marker)
        with knowledge.transaction(scope, 'planner.read/1') as connection:
            for ref in value['references']:
                args = dict(scope, chunk=UUID(ref['chunkId']), revision=UUID(ref['revisionId']),
                    document=UUID(ref['documentId']), version=ref['revision'], generation=UUID(ref['generationId']),
                    layer=ref['layer'], pin=ref['ciphertextDigest'])
                row = connection.execute('SELECT 1 FROM knowledge_chunks c JOIN knowledge_revisions r ON r.id=c.revision_id '
                    'JOIN knowledge_documents d ON d.active_revision_id=r.id WHERE c.'+KB_SCOPE.replace(' AND ', ' AND c.')+
                    " AND c.id=%(chunk)s AND c.ciphertext_digest=%(pin)s AND r.id=%(revision)s AND r.revision=%(version)s "
                    "AND d.id=%(document)s AND r.layer=%(layer)s AND r.generation_id=%(generation)s AND d.state='ACTIVE' "
                    "AND r.purposes @> '[\"planner.read/1\"]'::jsonb AND r.valid_from<=clock_timestamp() "
                    'AND (r.valid_until IS NULL OR r.valid_until>clock_timestamp())', args).fetchone()
                if row != (1,):
                    raise OSErrorCode('DENIED')

    def _snapshot(self, context):
        parts, value = self._identity(context)
        with self.runtime.store.transaction() as db:
            actor, pin, _ = self._metadata(db, parts)
        return actor, pin, hashlib.sha256(canonical_bytes(value)).hexdigest()

    async def prepare(self, context):
        async with asyncio.timeout(10):
            actor, pin, release_pin = await asyncio.to_thread(self._snapshot, context)
            await asyncio.to_thread(self.runtime.registry.assert_principal, actor)
            bridge = await asyncio.to_thread(self.runtime.bridges.for_application, actor.subject['applicationId'])
            state = await bridge.session(actor.subject, actor.host_session_ref, actor.session_generation)
            fresh(state, subject=actor.subject)
            if state['policyGeneration'] != actor.policy_generation:
                raise OSErrorCode('DENIED')
            permit = _Permit(self, context.workflow_id, release_pin, actor, pin, state, utcnow())
            await self._refresh_sources(context, permit)
            return permit

    @contextmanager
    def _scope(self, context, permit):
        if (type(permit) is not _Permit or permit.authority is not self or permit.workflow_id != context.workflow_id
                or not utcnow()-timedelta(seconds=5) <= permit.checked_at <= utcnow()):
            raise OSErrorCode('DENIED')
        parts, value = self._identity(context)
        if hashlib.sha256(canonical_bytes(value)).hexdigest() != permit.certificate_digest:
            raise OSErrorCode('DENIED')
        fresh(permit.host_state, subject=permit.actor.subject)
        with self.runtime.store.transaction() as db:
            _, locked_value = self._identity(context)
            if hashlib.sha256(canonical_bytes(locked_value)).hexdigest() != permit.certificate_digest:
                raise OSErrorCode('DENIED')
            _, pin, binding = self._metadata(db, parts, permit.actor)
            if pin != permit.metadata_digest:
                raise OSErrorCode('CONFLICT')
            # All current owner/control/consent/KB metadata guards have passed.
            # Only now may private keys be opened and retained for this batch.
            knowledge_keys = None
            if binding is not None:
                memory = self.runtime.task_memory
                if memory.knowledge_binding(db, permit.actor, binding) is not None:
                    from .recovery_key_continuity import effective_keys,selector
                    expected=effective_keys(self.path,value,'knowledge')
                    selector(self.path,value,purpose='knowledge')
                    if not expected:
                        raise OSErrorCode('UNAVAILABLE')
                    knowledge_keys = self.path.parent/'protected-knowledge/keys', expected
            from .recovery_key_continuity import effective_keys
            current_keys = effective_keys(self.path, value)
            _key_metadata(self.path.parent/'keys', current_keys)
            if knowledge_keys is not None:_key_metadata(*knowledge_keys)
            keys = pinned_keys(self.path.parent/'keys', current_keys)
            if knowledge_keys is not None:pinned_keys(*knowledge_keys)
            fresh(permit.host_state, subject=permit.actor.subject)
            yield db, keys, binding
            fresh(permit.host_state, subject=permit.actor.subject)

    @contextmanager
    def guard(self, context, permit):
        with self._scope(context, permit) as (db, keys, binding):
            if binding is not None:
                self.runtime.task_memory.check_tx(db, permit.actor,
                    context.workflow_id.split(':')[3], executing=True)
            yield keys

    @staticmethod
    def _mac(keys, ident, purpose, value):
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        key = HKDF(algorithm=hashes.SHA256(), length=32, salt=None,
            info=purpose).derive(keys._key(str(ident)))
        return hmac.new(key, canonical_bytes(value), hashlib.sha256).hexdigest()

    def _sources(self, context, permit):
        from agentic_os.adapters.postgres.models import TaskMemoryReference as Reference
        with self._scope(context, permit) as (db, keys, binding):
            if binding is None:
                return []
            memory = self.runtime.task_memory
            refs = list(db.scalars(select(Reference).where(*scoped(Reference, permit.actor.subject),
                Reference.binding_id == binding.id).order_by(Reference.ordinal).limit(9)))
            if len(refs) > 8 or len(refs) != binding.reference_count:
                raise OSErrorCode('UNAVAILABLE')
            serialized = [memory.reference(row) for row in refs]
            pin = self._mac(keys, binding.mac_key_id, b'agentic-os.task-memory/1',
                dict(subject=permit.actor.subject, payload=memory.record(binding, serialized)))
            if not hmac.compare_digest(pin, binding.binding_mac):
                raise OSErrorCode('UNAVAILABLE')
            if not refs:
                return []
            return memory.index.knowledge.validity.references(permit.actor.subject,
                'knowledge', [row.entry_id for row in refs])

    def _source_material(self, context, permit, ident):
        from agentic_os.adapters.postgres.models import PersonalLearningSource as Source, PersonalLearningSourceOrigin as Origin
        from agentic_os.memory.selected import local_origin
        with self._scope(context, permit) as (db, keys, binding):
            source = db.scalar(select(Source).where(*scoped(Source, permit.actor.subject),
                Source.id == ident).with_for_update())
            if (binding is None or source is None or source.kind != 'accepted-outcome/1'
                    or source.state != 'AVAILABLE' or source.expires_at <= utcnow()
                    or not local_origin(db, source)):
                return None
            origin = db.scalar(select(Origin).where(*scoped(Origin, permit.actor.subject), Origin.source_id == ident))
            artifacts = LocalArtifacts(self.path.parent/'artifacts', keys)
            if artifacts.pin(str(origin.artifact_id))['ciphertextDigest'] != origin.ciphertext_digest:
                raise OSErrorCode('UNAVAILABLE')
            payload = parse_canonical_json(artifacts.read(permit.actor.subject, str(origin.artifact_id)))
            validity = self.runtime.task_memory.index.knowledge.validity
            return dict(sourceId=str(ident), artifactId=str(origin.artifact_id),
                ciphertextDigest=origin.ciphertext_digest, macKeyId=str(source.mac_key_id),
                sourceRequest=validity.request(permit.actor.subject, payload))

    def _source_record(self, context, permit, ident, material, snapshot, value):
        from agentic_os.adapters.postgres.models import PersonalLearningSource as Source, PersonalLearningSourceOrigin as Origin
        from agentic_os.identity.context import timestamp
        with self._scope(context, permit) as (db, keys, binding):
            fresh(value, subject=permit.actor.subject)
            versions = snapshot[0]
            if not value['active'] or value['policyGeneration'] != versions.policy_generation:
                raise OSErrorCode('DENIED')
            source = db.scalar(select(Source).where(*scoped(Source, permit.actor.subject),
                Source.id == ident).with_for_update())
            origin = db.scalar(select(Origin).where(*scoped(Origin, permit.actor.subject), Origin.source_id == ident))
            if (binding is None or not source or not origin or str(origin.artifact_id) != material['artifactId']
                    or origin.ciphertext_digest != material['ciphertextDigest']
                    or str(source.mac_key_id) != material['macKeyId']):
                raise OSErrorCode('DENIED')
            mac = self._mac(keys, material['macKeyId'], b'agentic-os.personal-source-observation/1',
                dict(subject=permit.actor.subject, artifactId=material['artifactId'],
                    ciphertextDigest=material['ciphertextDigest'], requestDigest=value['requestDigest']))
            observation = dict(artifact_id=UUID(material['artifactId']), ciphertext_digest=material['ciphertextDigest'],
                request_digest=mac, application_revision=versions.application_revision,
                application_generation=versions.application_generation, subject_generation=versions.subject_generation,
                policy_generation=versions.policy_generation, active=value['active'],
                checked_at=timestamp(value['checkedAt']), valid_until=timestamp(value['validUntil']))
            self.runtime.task_memory.index.knowledge.validity.record(db, permit.actor.subject, source, observation)

    async def _refresh_sources(self, context, permit):
        from agentic_os.adapters.http.personal_sources import RemotePersonalSource
        ids = await asyncio.to_thread(self._sources, context, permit)
        if not ids:
            return
        validity = self.runtime.task_memory.index.knowledge.validity
        for ident in ids:
            material = await asyncio.to_thread(self._source_material, context, permit, ident)
            if material is None:
                continue
            snapshot = await asyncio.to_thread(validity._snapshot, permit.actor.subject)
            value = await RemotePersonalSource(snapshot[1], snapshot[2]).check(material['sourceRequest'])
            await asyncio.to_thread(validity._unchanged, permit.actor.subject, snapshot)
            await asyncio.to_thread(self._source_record, context, permit, ident, material, snapshot, value)
