"""Authenticated original opaque handles and held receipt-only observation."""
import asyncio
from copy import deepcopy
import hashlib
import re
from pathlib import Path
from uuid import UUID

from sqlalchemy import select

from agentic_os.adapters.local.files import OwnershipError,private_read,private_write
from agentic_os.adapters.local.held_receipt_store import HeldReceiptStore,accounting_digest,history_digest
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.resources import ensure_private,file_lock
from agentic_os.adapters.local.restoration_binding import load_restoration
from agentic_os.adapters.local.recovery_runtime_checkpoint import runtime_checkpoint
from agentic_os.adapters.local import recovery_gate as gate
from agentic_os.adapters.postgres.models import Conversation,Task,Segment,PublicEvent
from agentic_os.contracts.canonical import canonical_bytes,digest,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.effects.input_execution_ledger import InputReviewedEffectLedger
from agentic_os.effects.input_execution_observer import InputReviewedReceiptObserver
from agentic_os.effects.input_receipt_authority import InputReceiptRecoveryAuthority
from agentic_os.effects.input_receipt_presentation import InputReceiptPresentation
from agentic_os.effects.registry import ResourceRegistry
from agentic_os.effects.reviewed_provider import ReviewedProviderRegistry
from agentic_os.errors import OSErrorCode
from agentic_os.identity.service import scoped
from agentic_os.registry.service import Registry

FILE='recovery-metadata/receipts.json'
PROFILE='admitted-receipt-capsules/1'
FIELDS={'profile','installationId','sourceRunId','effects'}
EFFECT_FIELDS={'handle','bindingId','grantId','continuationId','decisionId','conversationId',
    'registrationRevision','capabilityRef','providerRef','invocationId','reservationDigest',
    'grantDigest','providerBindingDigest','observerCredentialRef','observerCredentialDigest',
    'endpointDigest','accountingDigest','originalHistoryDigest'}
DIGESTS={k for k in EFFECT_FIELDS if k.endswith('Digest')}
IDS={'bindingId','grantId','continuationId','decisionId','conversationId','invocationId'}


def _capture_effect(observer,handle):
    validate_contract('AttemptHandle',handle)
    with observer.store.transaction() as db:
        attempt,binding,grant,root=observer._admitted(db,handle)
        task=db.get(Task,UUID(handle['taskId']));conversation=db.get(Conversation,task.conversation_id)
        segment=db.get(Segment,UUID(handle['segmentId']))
        events=list(db.scalars(select(PublicEvent).where(*scoped(PublicEvent,handle['subject']),
            PublicEvent.segment_id==UUID(handle['segmentId'])).order_by(PublicEvent.sequence)))
        if attempt.state!='UNKNOWN' or root.state!='QUARANTINED' or segment is None or segment.state!='FINISHED':
            raise OSErrorCode('PROFILE_DISABLED')
        _,phase=InputReceiptPresentation.closed_reviewed(events,task.id,binding.decision_id,binding.visibility_generation)
        if phase!='unknown':raise OSErrorCode('PROFILE_DISABLED')
        item=dict(handle=deepcopy(handle),bindingId=str(binding.id),grantId=str(binding.grant_id),
            continuationId=str(binding.continuation_id),decisionId=str(binding.decision_id),
            conversationId=str(conversation.id),registrationRevision=grant['registrationRevision'],
            capabilityRef=grant['capabilityRef'],providerRef=grant['providerRef'],invocationId=str(attempt.invocation_id),
            reservationDigest=attempt.request_digest,grantDigest=grant['grantDigest'],
            accountingDigest=accounting_digest(attempt,root),originalHistoryDigest=history_digest(segment,events))
    original=observer.providers.original(handle['subject'],item['registrationRevision'],item['capabilityRef'],item['providerRef'],purpose='observe')
    binding=original['binding'];registry=observer.providers.registry
    credential=private_read(registry.credential_path(handle['subject']['applicationId'],binding['observerCredentialRef']),256)
    item.update(providerBindingDigest=binding['bindingDigest'],observerCredentialRef=binding['observerCredentialRef'],
        observerCredentialDigest=hashlib.sha256(credential).hexdigest(),endpointDigest=hashlib.sha256(original['endpoint'].encode()).hexdigest())
    return item


def capture_receipts(path,token,observer,handles):
    """Capture all actual UNKNOWN handles from an existing genuine observer."""
    path=Path(path);verify_operator(path,token)
    if type(observer) is not InputReviewedReceiptObserver or observer.providers.registry.manifest!=path:
        raise OSErrorCode('PROFILE_DISABLED')
    if type(handles) is not list or not 1<=len(handles)<=128:raise OSErrorCode('CAPACITY')
    return _publish_receipts(path,token,[_capture_effect(observer,handle) for handle in handles])


def _publish_receipts(path,token,effects):
    verify_operator(path,token);manifest=load_manifest(path)
    value=dict(profile=PROFILE,installationId=manifest['installationId'],sourceRunId=manifest['runId'],
        effects=sorted(effects,key=lambda e:e['handle']['id']))
    checked_capsules(value)
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        from .original_receipt_store import original_source,verify_source_capsules
        original_source(path,token)
        pending=runtime_checkpoint(path)['pendingEffects']
        match_pending(value,pending)
        destination=path.parent/FILE
        if destination.exists() or destination.is_symlink():raise OwnershipError('Original receipt selection already exists')
        raw=canonical_bytes(value)
        if len(raw)>256*1024:raise OSErrorCode('CAPACITY')
        verify_source_capsules(path,token,effects)
        ensure_private(destination.parent);private_write(destination,raw)
    return dict(profile=PROFILE,admittedEffects=len(effects),selected=True)



def select_original_receipts(path,token):
    """Operator selection uses stored metadata and original observer keys only.

    Every handle is read from actual SQL, then validated by the maintained
    immutable ledger/closed-history inspector in a separate READ ONLY port.
    No full runtime, controller, owner session or artifact service is created.
    """
    from .original_receipt_store import OriginalReceiptStore,source_attempt_ids
    from . import production_recovery_receipts as production
    path=Path(path);effects=[]
    selected=None
    if production.pending_effects(runtime_checkpoint(path)):
        selected=production.select_original_receipts(path,token)
        if not runtime_checkpoint(path)['pendingEffects']:return selected
    for ident in source_attempt_ids(path,token):
        store=OriginalReceiptStore(path,token,ident)
        try:
            seed=store.seed;registry=_ObserverRegistry(path,store,seed)
            providers=ReviewedProviderRegistry(ResourceRegistry(registry))
            authority=InputReceiptRecoveryAuthority(store)
            observer=InputReviewedReceiptObserver(InputReviewedEffectLedger(authority),providers)
            item=_capture_effect(observer,seed['handle'])
            if any(item[k]!=seed[k] for k in seed):
                raise OwnershipError('Original receipt selection changed')
            effects.append(item)
        finally:store.close()
    result=_publish_receipts(path,token,effects)
    if selected is not None:
        return dict(profile='admitted-receipt-selection/1',families=[PROFILE,selected['profile']],
            admittedEffects=result['admittedEffects']+selected['admittedEffects'],selected=True)
    return result


def checked_capsules(value):
    if (type(value) is not dict or set(value)!=FIELDS or value['profile']!=PROFILE
            or type(value['sourceRunId']) is not str or re.fullmatch('[a-f0-9]{12}',value['sourceRunId']) is None
            or type(value['effects']) is not list or not 1<=len(value['effects'])<=128):
        raise OwnershipError('Admitted receipt capsules unavailable')
    from agentic_os.adapters.local.artifacts import checked_id
    checked_id(value['installationId']);seen=set()
    for item in value['effects']:
        if type(item) is not dict or set(item)!=EFFECT_FIELDS:raise OwnershipError('Admitted receipt capsule differs')
        validate_contract('AttemptHandle',item['handle']);handle=item['handle']
        for key in IDS:checked_id(item[key])
        if (handle['subject']['installationId']!=value['installationId'] or handle['id'] in seen
                or type(item['registrationRevision']) is not int or not 1<=item['registrationRevision']<=2**53-1
                or any(type(item[k]) is not str or re.fullmatch('[a-f0-9]{64}',item[k]) is None for k in DIGESTS)
                or any(type(item[k]) is not str or not 1<=len(item[k])<=256
                    for k in ('capabilityRef','providerRef','observerCredentialRef'))):
            raise OwnershipError('Admitted receipt capsule differs')
        seen.add(handle['id'])
    return value


def match_pending(value,pending):
    expected=[dict(attemptId=e['handle']['id'],applicationId=e['handle']['subject']['applicationId'],
        taskId=e['handle']['taskId'],rootId=e['handle']['rootId'],invocationId=e['invocationId'],
        requestDigest=e['reservationDigest'],state='UNKNOWN') for e in value['effects']]
    if sorted(pending,key=lambda e:e['attemptId'])!=expected:
        raise OwnershipError('Snapshot pending effects differ from admitted receipt capsules')


def load_capsules(path,token,expected_generation):
    path=Path(path);verify_operator(path,token);admitted=load_restoration(path)
    if type(expected_generation) is not int or admitted['generation']!=expected_generation:
        raise OwnershipError('Held receipt generation differs')
    try:raw=private_read(path.parent/FILE,256*1024)
    except OSError:raise OwnershipError('Archived receipt capsules unavailable') from None
    if admitted['materialDigests'].get(FILE)!=hashlib.sha256(raw).hexdigest():
        raise OwnershipError('Archived receipt capsules changed')
    value=checked_capsules(parse_canonical_json(raw))
    if value['installationId']!=admitted['installationId']:raise OwnershipError('Receipt capsule installation differs')
    match_pending(value,admitted['receipt']['runtimeCheckpoint']['pendingEffects'])
    return admitted,value


class _ObserverRegistry(Registry):
    def __init__(self,path,store,capsule):
        super().__init__(path,store);self.__capsule=deepcopy(capsule)

    def credential(self,app,ref):
        c=self.__capsule
        if str(app)!=c['handle']['subject']['applicationId'] or ref!=c['observerCredentialRef']:
            raise OSErrorCode('PROFILE_DISABLED')
        raw=private_read(self.credential_path(app,ref),256)
        if hashlib.sha256(raw).hexdigest()!=c['observerCredentialDigest']:
            raise OwnershipError('Original observer credential changed')
        try:return raw.decode('ascii')
        except UnicodeError:raise OSErrorCode('UNAVAILABLE') from None


async def observe_receipt(path,token,*,expected_generation,attempt_id):
    """Only the archived opaque ID selects a genuine original observer call."""
    from . import production_recovery_receipts as production
    path=Path(path)
    try:
        async with asyncio.timeout(20):
            if (path.parent/production.FILE).exists() or (path.parent/production.FILE).is_symlink():
                from .recovery_ready_receipts import _joined_thread
                loaded,cancelled=await _joined_thread(production.load_capsules,path,token,expected_generation)
                if cancelled is not None:raise cancelled
                _,value=loaded
                if any(row['handle']['id']==attempt_id for row in value['effects']):
                    return await production.observe_receipt(path,token,expected_generation=expected_generation,attempt_id=attempt_id)
            return await _observe_receipt(path,token,expected_generation=expected_generation,attempt_id=attempt_id)
    except TimeoutError:
        raise OSErrorCode('UNAVAILABLE') from None


async def _observe_receipt(path,token,*,expected_generation,attempt_id):
    from .artifacts import checked_id
    checked_id(attempt_id)
    path=Path(path);admitted,value=load_capsules(path,token,expected_generation)
    selected=next((e for e in value['effects'] if e['handle']['id']==attempt_id),None)
    if selected is None:raise OSErrorCode('DENIED')
    def authenticate():
        current_admitted,current=load_capsules(path,token,expected_generation)
        if current_admitted!=admitted or current!=value:raise OwnershipError('Held receipt selection changed')
    store=HeldReceiptStore(path,token,admitted,selected,authenticate)
    try:
        registry=_ObserverRegistry(path,store,selected)
        providers=ReviewedProviderRegistry(ResourceRegistry(registry))
        authority=InputReceiptRecoveryAuthority(store);ledger=InputReviewedEffectLedger(authority)
        observer=InputReviewedReceiptObserver(ledger,providers)
        # Check the original provider binding/endpoint without exposing either
        # a generic bridge or an execution credential to the recovery caller.
        original=await asyncio.to_thread(providers.original,selected['handle']['subject'],
            selected['registrationRevision'],selected['capabilityRef'],selected['providerRef'],purpose='observe')
        if (original['binding']['bindingDigest']!=selected['providerBindingDigest']
                or hashlib.sha256(original['endpoint'].encode()).hexdigest()!=selected['endpointDigest']):
            raise OwnershipError('Original receipt provider changed')
        projection,observation,segment=await InputReceiptPresentation(observer).observe(selected['handle'])
        authenticate()
        return dict(profile=PROFILE,state='OBSERVED',attemptId=attempt_id,status=observation['status'],
            projectionId=projection['id'],segmentId=segment,unknownUsageHeld=True,runtimeReady=False)
    finally:store.close()
