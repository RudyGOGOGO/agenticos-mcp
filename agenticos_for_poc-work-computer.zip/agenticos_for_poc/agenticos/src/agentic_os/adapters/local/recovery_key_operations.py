"""explicit operator rotation and independently encrypted key recovery."""
import base64
import hashlib
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.identity.context import utcnow, timestamp
from . import recovery_gate as gate
from .artifacts import checked_id
from .files import OwnershipError, check_private, private_read, private_write
from .operator import verify_operator
from .resources import canonical_path, ensure_private, file_lock, read_signed, write_signed
from .recovery_ready import _release_metadata
from .recovery_history import pinned_keys, _key_metadata
from .recovery_key_continuity import (FILE, INTENT, DIRECTORY, PROFILE, ROTATION,
    BINDING, ENTRY_FIELDS, chain, effective_keys, pending, selector, sha, _base, _rotation,
    binding_fields,placed_fields,profiles,plane)


def _authority(path,token,generation):
    from .recovery_operator import verify_key_operator
    return verify_key_operator(path,token,generation)


def _current(path, token, generation):
    verify_operator(path, token)
    if type(generation) is not int:
        raise OwnershipError('Current key generation required')
    value = _release_metadata(path)
    if value['generation'] != generation:
        raise OwnershipError('Current key generation differs')
    _authority(path,token,generation)
    return value


def _result(value, continuity, state, purpose):
    return dict(profile=profiles(value,purpose)[1], state=state, generation=value['generation'],
        rotations=len(continuity['entries']), unknownUsageHeld=True)


def rotate(path, token, *, expected_generation, command_id,purpose='history'):
    path = Path(path); verify_operator(path, token); checked_id(command_id)
    file,intent,directory,key_directory=plane(purpose)
    with file_lock(path.parent / 'recovery-gate.lock', timeout=2):
        value = _current(path, token, expected_generation)
        if timestamp(value['expiresAt']) <= utcnow():
            raise OwnershipError('Current finite key rotation authority expired')
        continuity, known = chain(path, value,purpose); current = pending(path, value,purpose)
        operation_root = path.parent / directory
        old = next((e for e in continuity['entries'] if e['commandId'] == command_id), None) if continuity else None
        if old is not None and current is not None and current['state'] == 'COMPLETED':
            effective_keys(path, value,purpose); _key_metadata(path.parent / key_directory, known)
            selector(path, value, continuity,purpose)
            return _result(value, continuity, 'COMPLETED',purpose)
        if current is not None and current['state'] == 'PREPARED':
            if current['commandId'] != command_id:
                raise OwnershipError('Different key rotation is pending')
        else:
            effective_keys(path, value,purpose); keys = pinned_keys(path.parent / key_directory, known)
            active = selector(path, value, continuity,purpose)
            if continuity is not None and len(continuity['entries']) >= 8 or len(known) >= 128:
                raise OwnershipError('Key rotation envelope exhausted')
            from uuid import uuid4
            raw = AESGCM.generate_key(bit_length=256); ident = str(uuid4())
            base = _base(path, value)
            current = {k: base[k] for k in binding_fields(base)} | dict(profile=profiles(base,purpose)[1],
                generation=value['generation'], certificateDigest=sha(value), state='PREPARED',
                commandId=command_id, keyId=ident, keyDigest=hashlib.sha256(raw).hexdigest(),
                previousActive=active, previousDigest=sha(continuity))
            # Publishing the intent disables runtime before any live-key mutation.
            # A crash before staging stays unavailable; it never regenerates a key.
            ensure_private(operation_root)
            op = operation_root / command_id
            if op.exists() or op.is_symlink():
                raise OwnershipError('Unknown key operation material exists')
            _authority(path,token,expected_generation)
            write_signed(path.parent / intent, current, path.parent / 'owner.key')
            ensure_private(op)
            write_signed(op / 'intent.json', current, path.parent / 'owner.key')
            private_write(op / 'staged.key', raw)
            del keys, raw
        op = operation_root / command_id
        # A publish-before-ack interruption may already have added this exact last entry.
        committed = old is not None
        if committed:
            if continuity['entries'][-1] != {k: current[k] for k in ENTRY_FIELDS}:
                raise OwnershipError('Pending rotation is not the final exact entry')
            continuity = (continuity | dict(entries=continuity['entries'][:-1])) if len(continuity['entries']) > 1 else None
            known.pop(current['keyId'])
        staged_proof = read_signed(op / 'intent.json', path.parent / 'owner.key', maximum=32768)
        if (staged_proof not in (current, current | dict(state='COMPLETED'))
                or current['previousDigest'] != sha(continuity)):
            raise OwnershipError('Pending rotation checkpoint differs')
        raw = private_read(op / 'staged.key', 32)
        if len(raw) != 32 or hashlib.sha256(raw).hexdigest() != current['keyDigest']:
            raise OwnershipError('Pending rotation original key unavailable')
        live=path.parent/key_directory
        _authority(path,token,expected_generation)
        apply_key_rotation(live,known,current['previousActive'],current['keyId'],raw)
        base = _base(path, value)
        new = continuity or ({k: base[k] for k in binding_fields(base)} | dict(profile=profiles(base,purpose)[0],
            baseGeneration=base['generation'], baseCertificateDigest=sha(base),
            baseActive=current['previousActive'], entries=[]))
        new = new | dict(entries=new['entries'] + [{k: current[k] for k in ENTRY_FIELDS}])
        _authority(path,token,expected_generation)
        write_signed(path.parent / file, new, path.parent / 'owner.key')
        complete = current | dict(state='COMPLETED')
        write_signed(op / 'intent.json', complete, path.parent / 'owner.key')
        write_signed(path.parent / intent, complete, path.parent / 'owner.key')
        effective_keys(path, value,purpose); pinned_keys(live, known | {current['keyId']: current['keyDigest']})
        _authority(path,token,expected_generation)
        return _result(value, new, 'COMPLETED',purpose)


BACKUP = 'independent-restored-key-backup/1'
MANAGED_BACKUP = 'independent-restored-managed-key-backup/1'
BACKUP_FIELDS = {'profile', *BINDING, 'generation', 'certificateDigest',
    'continuityDigest', 'knownKeys', 'active', 'nonce', 'ciphertext'}


def _backup_profile(value,purpose):
    plane(purpose)
    if purpose=='knowledge':return profiles(value,purpose)[0].replace('continuity','backup')
    return MANAGED_BACKUP if 'managedTarget' in binding_fields(value) else BACKUP


def apply_key_rotation(live, known, previous, key_id, raw):
    """Shared exact staged-key mutation; caller owns the exclusive recovery guard."""
    live=canonical_path(Path(live));check_private(live,directory=True)
    checked_id(previous);checked_id(key_id)
    if (type(known) is not dict or not 1<=len(known)<128 or previous not in known or key_id in known
            or type(raw) is not bytes or len(raw)!=32):raise OwnershipError('Exact bounded original rotation required')
    expected={'active.json'}|{checked_id(k)+'.key' for k in known}|{key_id+'.key'}
    if {p.name for p in live.iterdir()}-expected:raise OwnershipError('Unknown key material prevents rotation')
    for ident,pin in known.items():
        content=private_read(live/(ident+'.key'),32)
        if len(content)!=32 or hashlib.sha256(content).hexdigest()!=pin:raise OwnershipError('Original key material changed')
    active=parse_canonical_json(private_read(live/'active.json',128))
    if type(active) is not dict or set(active)!={'id'} or active['id'] not in {previous,key_id}:
        raise OwnershipError('Pending rotation selector changed')
    target=live/(key_id+'.key')
    if target.exists() or target.is_symlink():
        if private_read(target,32)!=raw:raise OwnershipError('Pending rotation key differs')
    else:private_write(target,raw)
    private_write(live/'active.json',canonical_bytes({'id':key_id}),replace=True)


def _external(path, destination, recovery_key):
    root = canonical_path(Path(path).parent)
    destination = canonical_path(Path(destination)); recovery_key = canonical_path(Path(recovery_key))
    if (destination.is_relative_to(root) or recovery_key.is_relative_to(root)
            or destination == recovery_key):
        raise OwnershipError('Independent key protection placement required')
    check_private(destination.parent, directory=True); check_private(recovery_key.parent, directory=True)
    return destination, recovery_key


def protect_keys(path, metadata, plain, recovery_key):
    """Shared bounded independent encryption; authority metadata is caller-owned."""
    if type(metadata) is not dict or type(plain) is not bytes or len(plain)>65536:
        raise OwnershipError('Independent key protection envelope exceeded')
    recovery_key=Path(recovery_key)
    if not recovery_key.exists():private_write(recovery_key,AESGCM.generate_key(bit_length=256))
    protection=private_read(recovery_key,32)
    if len(protection)!=32:raise OwnershipError('Independent recovery key unavailable')
    import secrets,hmac
    nonce=secrets.token_bytes(12)
    encrypted=AESGCM(protection).encrypt(nonce,plain,canonical_bytes(metadata))
    payload=metadata|dict(nonce=base64.b64encode(nonce).decode('ascii'),ciphertext=base64.b64encode(encrypted).decode('ascii'))
    signature=hmac.digest(private_read(Path(path).parent/'owner.key',32),canonical_bytes(payload),'sha256').hex()
    return dict(value=payload,signature=signature)


def unprotect_keys(metadata, selected, recovery_key, *, maximum=32768):
    """Caller authenticates the signed envelope and exact authority first."""
    try:
        if (type(maximum) is not int or maximum not in {32768,65552}
                or type(selected) is not dict or set(selected)!=set(metadata)|{'nonce','ciphertext'}
                or any(selected[k]!=v for k,v in metadata.items())):raise ValueError()
        nonce=base64.b64decode(selected['nonce'],validate=True);encrypted=base64.b64decode(selected['ciphertext'],validate=True)
        if len(nonce)!=12 or len(encrypted)>maximum:raise ValueError()
        protection=private_read(Path(recovery_key),32)
        if len(protection)!=32:raise ValueError()
        return AESGCM(protection).decrypt(nonce,encrypted,canonical_bytes(metadata))
    except (InvalidTag,ValueError,TypeError,OSError):raise OwnershipError('Independent key protection unavailable') from None


def check_repair_inventory(live,names):
    live=canonical_path(Path(live))
    if live.exists() or live.is_symlink():
        check_private(live,directory=True)
        if {p.name for p in live.iterdir()}-set(names):raise OwnershipError('Unknown existing keys prevent recovery')
        for file in live.iterdir():
            check_private(file)
            if file.lstat().st_nlink!=1:raise OwnershipError('Shared existing key prevents recovery')
            private_read(file,128)


def check_key_repair(live, contents, preserved):
    """Validate the whole exact repair before creating or changing any file."""
    live=canonical_path(Path(live));preserved=canonical_path(Path(preserved))
    try:check_private(live.parent,directory=True)
    except OSError:raise OwnershipError('Original key ownership directory unavailable') from None
    if type(contents) is not dict or not 1<=len(contents)<=129:raise OwnershipError('Exact bounded private key files required')
    for name,raw in contents.items():
        if (type(name) is not str or Path(name).name!=name or name in {'.','..'}
                or type(raw) is not bytes or len(raw)>128):raise OwnershipError('Exact private key file required')
    check_repair_inventory(live,contents);check_repair_inventory(preserved,contents)
    for name,raw in contents.items():
        target=live/name;retained=preserved/name
        if (target.exists() and private_read(target,128)!=raw
                and (retained.exists() or retained.is_symlink())):
            raise OwnershipError('Different corrupt original is already preserved')


def repair_key_files(live, contents, preserved):
    """Exact file repair; keep every differing original and support write retry."""
    live=Path(live);preserved=Path(preserved);check_key_repair(live,contents,preserved)
    if not live.exists():ensure_private(live)
    ensure_private(preserved.parent);ensure_private(preserved)
    for name,raw in contents.items():
        target=live/name
        if target.exists() or target.is_symlink():
            check_private(target);original=private_read(target,128)
            if original==raw:continue
            retained=preserved/name
            if retained.exists() or retained.is_symlink():raise OwnershipError('Different corrupt original is already preserved')
            target.rename(retained)
        private_write(target,raw)


def backup(path, token, *, expected_generation, destination, recovery_key,purpose='history'):
    path = Path(path); verify_operator(path, token)
    _,_,_,key_directory=plane(purpose)
    destination, recovery_key = _external(path, destination, recovery_key)
    if destination.exists() or destination.is_symlink():
        raise OwnershipError('Independent key backup already exists')
    with file_lock(path.parent / 'recovery-gate.lock', timeout=2, shared=True):
        value = _current(path, token, expected_generation)
        continuity, _ = chain(path, value,purpose); known = effective_keys(path, value,purpose)
        keys = pinned_keys(path.parent / key_directory, known); active = selector(path, value, continuity,purpose)
        metadata = {k: value[k] for k in binding_fields(value)} | dict(profile=_backup_profile(value,purpose),
            generation=value['generation'], certificateDigest=sha(value),
            continuityDigest=sha(continuity), knownKeys=known, active=active)
        plain = canonical_bytes({ident: base64.b64encode(keys._key(ident)).decode('ascii') for ident in known})
        # Immutable output; retries never replace an independent backup.
        if destination.exists() or destination.is_symlink():raise OwnershipError('Independent key backup already exists')
        _authority(path,token,expected_generation)
        private_write(destination,canonical_bytes(protect_keys(path,metadata,plain,recovery_key)))
        _authority(path,token,expected_generation)
        return dict(profile=_backup_profile(value,purpose), state='PROTECTED', keys=len(known), generation=value['generation'])


def recover(path, token, *, expected_generation, backup_path, recovery_key, command_id,purpose='history'):
    path = Path(path); verify_operator(path, token); checked_id(command_id)
    file,intent,directory,key_directory=plane(purpose)
    backup_path, recovery_key = _external(path, backup_path, recovery_key)
    with file_lock(path.parent / 'recovery-gate.lock', timeout=2):
        value = _current(path, token, expected_generation)
        continuity, _ = chain(path, value,purpose); known = effective_keys(path, value,purpose)
        selected = read_signed(backup_path, path.parent / 'owner.key', maximum=65536)
        if (type(selected) is not dict or set(selected) != placed_fields(BACKUP_FIELDS,value) or selected['profile'] != _backup_profile(value,purpose)
                or any(selected[k] != value[k] for k in binding_fields(value))
                or type(selected['generation']) is not int or selected['generation'] != value['generation']
                or selected['certificateDigest'] != sha(value) or selected['continuityDigest'] != sha(continuity)
                or selected['knownKeys'] != known or selected['active'] not in known
                or continuity is not None and selected['active'] != continuity['entries'][-1]['keyId']):
            raise OwnershipError('Independent key recovery authority differs')
        try:
            metadata = {k:v for k,v in selected.items() if k not in {'nonce','ciphertext'}}
            plain=unprotect_keys(metadata,selected,recovery_key)
            decoded = parse_canonical_json(plain)
            if type(decoded) is not dict or set(decoded) != set(known):
                raise ValueError()
            restored = {k: base64.b64decode(v, validate=True) for k, v in decoded.items()}
            if any(len(raw) != 32 or hashlib.sha256(raw).hexdigest() != known[k] for k, raw in restored.items()):
                raise ValueError()
        except (InvalidTag, ValueError, TypeError):
            raise OwnershipError('Independent key protection unavailable') from None
        live = path.parent / key_directory
        contents={k+'.key':v for k,v in restored.items()}|{'active.json':canonical_bytes({'id':selected['active']})}
        _authority(path,token,expected_generation)
        repair_key_files(live,contents,path.parent/('recovery-key-repair' if purpose=='history' else 'recovery-knowledge-key-repair')/command_id)
        pinned_keys(live, known); selector(path, value, continuity,purpose)
        _authority(path,token,expected_generation)
        return dict(profile=_backup_profile(value,purpose), state='RECOVERED', keys=len(known),
            generation=value['generation'], unknownUsageHeld=True)
