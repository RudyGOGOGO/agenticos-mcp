"""Explicit local ownership, artifact and key providers."""
