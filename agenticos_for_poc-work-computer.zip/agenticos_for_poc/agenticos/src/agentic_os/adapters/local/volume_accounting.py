"""One read-only owned-volume walk, with observed bounded helper teardown."""
import json
import re
import time
from uuid import uuid4

from .docker import DockerControl
from .files import OwnershipError
from .images import PG_IMAGE

DATA = '/var/lib/postgresql/data'
# Match Moby docker-v29.4.1 daemon/internal/directory/directory_unix.go:
# apparent non-directory bytes, deduplicated by inode, without following links.
# Pipe failure rejects an incomplete walk. No names or file content are emitted.
PROGRAM = ("find " + DATA + " -xdev ! -type d -printf '%i %s\\n' | "
    "awk '!seen[$1]++ {s+=$2} END {printf \"%.0f\\n\",s}'")


class _BoundedControl(DockerControl):
    def __init__(self, manifest, deadline):
        super().__init__(manifest)
        self.deadline, self.cleaning = deadline, False

    def command(self, *args, timeout=60, input=None):
        remaining = self.deadline - time.monotonic() - (0 if self.cleaning else 3)
        if remaining <= 0:
            raise OwnershipError('Owned volume accounting deadline exceeded')
        return super().command(*args, timeout=min(timeout, remaining), input=input)


def _inspect_helper(control, name, binding, labels):
    obj = json.loads(control.command('inspect', name))[0]
    cfg, host, mounts = obj['Config'], obj['HostConfig'], obj['Mounts']
    if (obj['Name'] != '/' + name or obj['Image'] != binding['imageId']
            or any(cfg.get('Labels', {}).get(k) != v for k, v in labels.items())
            or cfg['User'] != 'postgres' or cfg['Entrypoint'] != ['/bin/bash']
            or cfg['Cmd'] != ['-euo', 'pipefail', '-c', PROGRAM]
            or not host['ReadonlyRootfs'] or host['NetworkMode'] != 'none'
            or host['Privileged'] or host.get('CapAdd') or host['CapDrop'] != ['ALL']
            or host['SecurityOpt'] != ['no-new-privileges:true']
            or host.get('PidMode') not in {'', 'private'} or host.get('IpcMode') != 'private'
            or host.get('UTSMode') not in {'', 'private'} or host.get('CgroupnsMode') != 'private'
            or host.get('Devices') or host.get('DeviceRequests')
            or host['Memory'] != 64 * 1024**2 or host['PidsLimit'] != 16
            or host['NanoCpus'] != 250_000_000 or len(mounts) != 1
            or mounts[0]['Type'] != 'volume' or mounts[0]['Name'] != binding['volume']
            or mounts[0]['Destination'] != DATA or mounts[0]['RW']):
        raise OwnershipError('Owned volume metadata helper binding unavailable')
    return obj


def measure_owned_volume(original, volume):
    manifest, binding = original.manifest, original.manifest['postgres']
    if binding is None or volume != binding['volume'] or binding['image'] != PG_IMAGE:
        raise OwnershipError('Only the exact owned PostgreSQL volume can be measured')
    control = _BoundedControl(manifest, time.monotonic() + 20)
    control.inspect_owned(manifest, require_running=False)
    info = json.loads(control.command('volume', 'inspect', volume))[0]
    expected = {'io.agentic-os.installation': manifest['installationId'],
        'io.agentic-os.run': manifest['runId'], 'io.agentic-os.component': 'postgres'}
    if (info['Name'] != volume or info['Driver'] != 'local' or info.get('Options')
            or any(info.get('Labels', {}).get(k) != v for k, v in expected.items())):
        raise OwnershipError('Owned volume identity or driver unavailable')
    image = json.loads(control.command('image', 'inspect', binding['imageId']))[0]
    if image['Id'] != binding['imageId'] or set(image['Config'].get('Volumes', {})) != {DATA}:
        raise OwnershipError('Unqualified volume metadata image')
    name = 'aos-volume-metadata-' + uuid4().hex
    labels = expected | {'io.agentic-os.component': 'volume-metadata',
        'io.agentic-os.volume-usage': name}
    label_args = [v for k, value in labels.items() for v in ['--label', k + '=' + value]]
    attempted = False
    try:
        attempted = True
        ident = control.command('create', '--pull=never', '--name', name, '--network=none',
            '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges:true',
            '--memory=64m', '--pids-limit=16', '--cpus=.25', '--user=postgres',
            '--mount', 'type=volume,source=' + volume + ',target=' + DATA + ',readonly',
            '--entrypoint=/bin/bash', *label_args, binding['imageId'], '-euo', 'pipefail', '-c', PROGRAM)
        if re.fullmatch('[0-9a-f]{64}', ident) is None:
            raise OwnershipError('Owned volume helper creation unavailable')
        if _inspect_helper(control, name, binding, labels)['Id'] != ident:
            raise OwnershipError('Owned volume helper creation changed')
        raw = control.command('start', '-a', ident)
        obj = _inspect_helper(control, name, binding, labels)
        if (obj['State']['Running'] or obj['State']['ExitCode'] != 0
                or re.fullmatch('[0-9]{1,16}', raw) is None or int(raw) >= 2**53):
            raise OwnershipError('Owned volume accounting unavailable')
        result = int(raw)
    except (ValueError, KeyError, TypeError, IndexError):
        raise OwnershipError('Owned volume accounting unavailable') from None
    finally:
        if attempted:
            control.cleaning = True
            # Even creation-ACK loss requires fresh exact ownership before
            # cleanup. Missing/foreign/unconfirmed cleanup remains a failure.
            obj = _inspect_helper(control, name, binding, labels)
            if obj['State']['Running']:
                control.command('stop', '--time', '1', obj['Id'])
                obj = _inspect_helper(control, name, binding, labels)
            if obj['State']['Running']:
                raise OwnershipError('Owned volume metadata teardown unavailable')
            control.command('container', 'rm', obj['Id'])
            # No volume removal option: only this attested helper is removed.
    if time.monotonic() >= control.deadline:
        raise OwnershipError('Owned volume accounting deadline exceeded')
    return result
