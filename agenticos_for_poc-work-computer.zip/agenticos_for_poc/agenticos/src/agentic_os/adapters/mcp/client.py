"""Pinned real MCP SDK transport. Never accept endpoints/tool names from a model."""
import asyncio
import httpx2
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client
from agentic_os.adapters.http.endpoint import reviewed_http_endpoint
from agentic_os.adapters.http.circuit import AvailabilityCircuit
from agentic_os.adapters.http.tls import reviewed_tls_context
from agentic_os.contracts.canonical import canonical_bytes
from agentic_os.errors import OSErrorCode


class BoundedStream(httpx2.AsyncByteStream):
    def __init__(self,stream,maximum):self.stream=stream;self.maximum=maximum
    async def __aiter__(self):
        size=0
        async for chunk in self.stream:
            size+=len(chunk)
            if size>self.maximum:
                raise OSErrorCode('UNAVAILABLE')
            yield chunk
    async def aclose(self):await self.stream.aclose()


class RegisteredTransport(httpx2.AsyncBaseTransport):
    def __init__(self,endpoint,maximum,*,network='owned-local-http/1',ca_file=None,ca_sha256=None,keepalive_connections=0):
        if type(keepalive_connections) is not int or keepalive_connections not in {0,2}:
            raise ValueError('Bounded invocation transport reuse required')
        self.endpoint=reviewed_http_endpoint(endpoint,network);self.maximum=maximum
        self.transport=httpx2.AsyncHTTPTransport(verify=reviewed_tls_context(network,ca_file=ca_file,ca_sha256=ca_sha256),
            retries=0,trust_env=False,limits=httpx2.Limits(max_connections=2,max_keepalive_connections=keepalive_connections))
    async def handle_async_request(self,request):
        if str(request.url)!=self.endpoint or request.method not in {'POST','GET','DELETE'}:
            raise OSErrorCode('DENIED')
        response=await self.transport.handle_async_request(request)
        if 300<=response.status_code<400:
            await response.aclose();raise OSErrorCode('DENIED')
        if response.headers.get('content-encoding','identity')!='identity':
            await response.aclose();raise OSErrorCode('UNAVAILABLE')
        length=response.headers.get('content-length')
        if length and (not length.isdigit() or int(length)>self.maximum):
            await response.aclose();raise OSErrorCode('UNAVAILABLE')
        response.stream=BoundedStream(response.stream,self.maximum)
        return response
    async def aclose(self):await self.transport.aclose()


class RegisteredMCP:
    def __init__(self,endpoint,*,timeout_ms=3000,maximum=1048576,network='owned-local-http/1',ca_file=None,ca_sha256=None):
        self.endpoint=reviewed_http_endpoint(endpoint,network);self.network=network
        self.timeout=min(timeout_ms/1000,45);self.maximum=min(maximum,1048576)
        self.trust=dict(ca_file=ca_file,ca_sha256=ca_sha256)
        reviewed_tls_context(network,**self.trust)
        self.bulkhead=asyncio.Semaphore(4)
        self.circuit=AvailabilityCircuit()

    async def request(self,token,*,tool=None,arguments=None):
        try:
            async with asyncio.timeout(self.timeout) as deadline:
                async with self.bulkhead:
                    with self.circuit.call(timed_out=deadline.expired):
                        transport=RegisteredTransport(self.endpoint,self.maximum,network=self.network,**self.trust)
                        async with httpx2.AsyncClient(transport=transport,trust_env=False,follow_redirects=False,
                                timeout=self.timeout,headers={'Authorization':'Bearer '+token,'Accept-Encoding':'identity'}) as http:
                            async with streamable_http_client(self.endpoint,http_client=http,terminate_on_close=False) as streams:
                                async with ClientSession(*streams[:2],read_timeout_seconds=self.timeout) as session:
                                    initialized=await session.initialize()
                                    if initialized.protocol_version!='2025-11-25':
                                        raise OSErrorCode('PROFILE_DISABLED')
                                    if tool is None:
                                        result=await session.list_tools()
                                        if result.next_cursor is not None or len(result.tools)>64:
                                            raise OSErrorCode('UNAVAILABLE')
                                        return [{'name':item.name,'inputSchema':item.input_schema} for item in result.tools]
                                    result=await session.call_tool(tool,arguments,read_timeout_seconds=self.timeout)
                                    if result.is_error or result.structured_content is None:
                                        raise OSErrorCode('UNAVAILABLE')
                                    value=result.structured_content
                                    if len(canonical_bytes(value))>self.maximum:
                                        raise OSErrorCode('UNAVAILABLE')
                                    return value
        except OSErrorCode:
            raise
        except Exception:
            # SDK exceptions may include URLs, tokens or raw tool data. Keep them
            # out of the public error, normal logging and accepted conversation.
            raise OSErrorCode('UNAVAILABLE') from None
