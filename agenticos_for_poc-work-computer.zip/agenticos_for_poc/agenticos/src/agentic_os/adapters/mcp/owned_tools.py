"""Closed canonical tool catalogs and public-safe real SDK server handlers."""
import asyncio
from copy import deepcopy
from uuid import uuid4

from mcp.server.lowlevel import Server
from mcp.types import CallToolResult, ListToolsResult, TextContent, Tool
from starlette.requests import Request
from starlette.responses import JSONResponse

from agentic_os.contracts.canonical import canonical_bytes
from agentic_os.contracts.validation import ContractViolation, schema_registry, validate_contract
from agentic_os.errors import OSErrorCode

EMPTY=dict(type='object',properties={},required=[],additionalProperties=False)


def tool_schema(contract):
    if contract is None:return deepcopy(EMPTY)
    definitions=schema_registry()['$defs'];result=deepcopy(definitions[contract]);needed={}
    def visit(value):
        if isinstance(value,dict):
            reference=value.get('$ref')
            if reference:
                if not reference.startswith('#/$defs/'):raise OSErrorCode('PROFILE_DISABLED')
                name=reference.removeprefix('#/$defs/')
                if name not in needed:
                    needed[name]=deepcopy(definitions[name]);visit(needed[name])
            for key,item in value.items():
                if key!='$ref':visit(item)
        elif isinstance(value,list):
            for item in value:visit(item)
    visit(result)
    if needed:result['$defs']=needed
    return result


class CanonicalTools:
    def __init__(self,name,tools,invoke):
        self.tools=tools;self.invoke=invoke;self.active=0
        self.server=Server(name,version='1.0.0',on_list_tools=self.list_tools,on_call_tool=self.call_tool)
        self.app=self.server.streamable_http_app(streamable_http_path='/os/memory/mcp',
            stateless_http=True,json_response=True,max_request_body_size=65536)

    async def list_tools(self,ctx,params):
        if params and params.cursor:raise OSErrorCode('INVALID')
        return ListToolsResult(tools=[Tool(name=name,description=description,input_schema=tool_schema(contract))
            for name,(contract,description) in self.tools.items()])

    async def call_tool(self,ctx,params):
        try:
            if params.name not in self.tools:raise OSErrorCode('DENIED')
            value=params.arguments or {};contract=self.tools[params.name][0]
            if contract is None:
                if value!={}:raise OSErrorCode('INVALID')
            else:validate_contract(contract,value)
            if self.active>=8:raise OSErrorCode('CAPACITY')
            self.active+=1
            try:
                async with asyncio.timeout(60):
                    result=await self.invoke(ctx.request.scope['agentic_os_principal'],params.name,value)
            finally:self.active-=1
            if len(canonical_bytes(result))>1048576:raise OSErrorCode('CAPACITY')
            return CallToolResult(content=[TextContent(type='text',text=canonical_bytes(result).decode())],structured_content=result)
        except ContractViolation:error=OSErrorCode('INVALID')
        except OSErrorCode as exc:error=exc
        except Exception:error=OSErrorCode('UNAVAILABLE')
        value=error.public(uuid4())
        return CallToolResult(content=[TextContent(type='text',text=canonical_bytes(value).decode())],
            structured_content=value,is_error=True)


class AuthenticatedTools:
    def __init__(self,app,authenticate):self.app,self.authenticate=app,authenticate
    async def __call__(self,scope,receive,send):
        if scope['type']!='http':return await self.app(scope,receive,send)
        try:
            request=Request(scope,receive)
            if request.query_params or request.method!='POST':raise OSErrorCode('INVALID')
            principal=await self.authenticate(request)
            scope=dict(scope,agentic_os_principal=principal)
        except OSErrorCode as exc:
            return await JSONResponse(exc.public(uuid4()),status_code=exc.STATUS[exc.code])(scope,receive,send)
        except Exception:
            error=OSErrorCode('UNAVAILABLE')
            return await JSONResponse(error.public(uuid4()),status_code=503)(scope,receive,send)
        await self.app(scope,receive,send)
