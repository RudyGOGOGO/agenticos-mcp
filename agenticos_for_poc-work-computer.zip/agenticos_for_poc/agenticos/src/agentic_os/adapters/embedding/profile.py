"""One explicitly installed offline English profile; no startup downloads."""
import hashlib
import os
from pathlib import Path
import stat

from agentic_os.adapters.local.capacity import Capacity, GiB
from agentic_os.adapters.local.files import (OwnershipError, check_private,
    private_directory, private_read, private_write)
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.errors import OSErrorCode

PROFILE = "minilm-english-onnx/1"
DIRECTORY = "embedding-minilm-english-onnx-1"
FILES = {
    "config.json": (612, "953f9c0d463486b10a6871cc2fd59f223b2c70184f49815e7efbcab5d8908b41"),
    "tokenizer.json": (466247, "be50c3628f2bf5bb5e3a7f17b1f74611b2561a3a27eeab05e5aa30f411572037"),
    "onnx/model.onnx": (90405214, "6fd5d72fe4589f189f8ebc006442dbb529bb7ce38f8082112682524616046452"),
}
PACKAGES = {"onnxruntime": "1.30.0", "tokenizers": "0.23.2", "numpy": "2.5.3"}
DEFINITION = dict(profileRef=PROFILE, modelRef="sentence-transformers/all-MiniLM-L6-v2",
    modelRevision="1110a243fdf4706b3f48f1d95db1a4f5529b4d41", licenseRef="Apache-2.0",
    language="en", dimensions=384, queryTemplate="{text}", documentTemplate="{text}",
    maximumTokens=256, pooling="attention-mask-mean", normalization="L2",
    packages=PACKAGES, files={name: dict(bytes=size, sha256=sha) for name, (size, sha) in FILES.items()})
MAX_FRAME, MAX_RSS = 1048576, 536870912
FAILURE_STAGES = frozenset({"limits", "packages", "request", "artifacts", "imports",
    "session", "inference", "reply"})
FAILURE_CLASSES = frozenset({"OSErrorCode", "ImportError", "ModuleNotFoundError",
    "PermissionError", "RuntimeError", "ValueError", "TypeError", "MemoryError",
    "OSError", "SystemExit", "Other"})


def artifact_bytes(root, name, *, private=False):
    """Verify opened bytes, including every parent and the final no-follow file."""
    root = Path(root)
    if not root.is_absolute() or root.resolve() != root or root.is_symlink():
        raise OwnershipError("Model source must be an explicit canonical directory")
    if private:
        check_private(root, directory=True)
    for part in Path(name).parents:
        parent = root / part
        if parent.is_symlink() or not parent.is_dir():
            raise OwnershipError("Model artifact parent changed")
        if private:
            check_private(parent, directory=True)
    size, sha = FILES[name]
    fd = os.open(root / name, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as handle:
        before = os.fstat(handle.fileno())
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_size != size or private and before.st_mode & 0o077):
            raise OwnershipError("Model artifact ownership or size changed")
        data = handle.read(size + 1)
        after = os.fstat(handle.fileno())
    if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) !=
        (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or len(data) != size or hashlib.sha256(data).hexdigest() != sha):
        raise OwnershipError("Model artifact bytes do not match the pinned profile")
    return data


def install_profile(manifest, source, operator_token, *, capacity_root):
    """Operator imports reviewed local public bytes into a new private directory."""
    manifest, source = Path(manifest), Path(source)
    verify_operator(manifest, operator_token)
    root = manifest.parent / DIRECTORY
    if root.exists() or root.is_symlink():
        raise OwnershipError("Embedding profile already exists; no adoption or overwrite")
    # Verify all inputs before creating the destination. No network/model runs.
    values = {name: artifact_bytes(source, name) for name in FILES}
    with Capacity(Path(capacity_root)).reserve(GiB, purpose="installation"):
        private_directory(root)
        private_directory(root / "onnx")
        for name, data in values.items():
            private_write(root / name, data)
        private_write(root / "profile.json", canonical_bytes(DEFINITION))
        load_profile(root)
    return root


def load_profile(root):
    root = Path(root)
    if not root.is_absolute() or root.resolve() != root:
        raise OSErrorCode("PROFILE_DISABLED")
    try:
        check_private(root, directory=True)
        if parse_canonical_json(private_read(root / "profile.json")) != DEFINITION:
            raise OwnershipError("Embedding definition changed")
        if {p.name for p in root.iterdir()} != {"config.json", "tokenizer.json", "onnx", "profile.json"}:
            raise OwnershipError("Unknown embedding artifact")
        if {p.name for p in (root / "onnx").iterdir()} != {"model.onnx"}:
            raise OwnershipError("Unknown embedding artifact")
        for name in FILES:
            check_private(root / name)
        check_private(root / "onnx", directory=True)
    except (OSError, ValueError, OwnershipError):
        raise OSErrorCode("PROFILE_DISABLED") from None
    return root


def checked_request(value):
    if (type(value) is not dict or set(value) != {"profileRef", "language", "purpose", "texts"}
            or value["profileRef"] != PROFILE or value["language"] != "en"
            or type(value["purpose"]) is not str or value["purpose"] not in {"query", "document"}):
        raise OSErrorCode("INVALID")
    texts = value["texts"]
    if (type(texts) is not list or not 1 <= len(texts) <= 32
            or any(type(t) is not str or not t.strip() or len(t) > 4000 for t in texts)
            or sum(len(t) for t in texts) > 128000):
        raise OSErrorCode("INVALID")
    try:
        frame = canonical_bytes(value)
    except ValueError:
        raise OSErrorCode("INVALID") from None
    if len(frame) + 1 > MAX_FRAME:
        raise OSErrorCode("CAPACITY")
    return frame + b"\n"
