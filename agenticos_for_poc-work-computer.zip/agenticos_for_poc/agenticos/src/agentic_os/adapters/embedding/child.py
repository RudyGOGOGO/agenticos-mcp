"""Disposable pinned CPU model process. No SQL, provider or host credentials."""
import importlib.metadata
import json
import logging
import os
from pathlib import Path
import resource
import socket
import sys

from agentic_os.adapters.embedding.profile import (PROFILE, PACKAGES, MAX_FRAME,
    MAX_RSS, FAILURE_CLASSES, artifact_bytes, checked_request, load_profile)
from agentic_os.adapters.local.files import check_private
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.errors import OSErrorCode


def main():
    output = os.fdopen(os.dup(sys.stdout.fileno()), "wb", buffering=0)
    # Library notices can contain paths. Only the separate bounded frame is IPC.
    with open(os.devnull, "w") as null:
        os.dup2(null.fileno(), sys.stdout.fileno())
        os.dup2(null.fileno(), sys.stderr.fileno())
        stage = "limits"
        try:
            os.umask(0o077)
            check_private(Path.cwd(), directory=True)
            if Path(os.environ["HOME"]) != Path.cwd():
                raise OSErrorCode("PROFILE_DISABLED")
            # The POSIX native uploader initializes at import, before the API
            # can suppress events. Parent sets this in the minimal launch env.
            if os.environ.get("ORT_DISABLE_TELEMETRY") != "1":
                raise OSErrorCode("PROFILE_DISABLED")
            resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
            resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_FRAME, MAX_FRAME))
            logging.disable(logging.CRITICAL)
            attempts = [0]
            def deny(*args, **kwargs):
                attempts[0] += 1
                raise OSErrorCode("DENIED")
            # Qualified Python model defense; native sandboxing belongs to G06.
            socket.create_connection = deny
            socket.socket.connect = deny
            socket.socket.connect_ex = deny
            socket.getaddrinfo = deny
            os.environ.update(HF_HUB_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1",
                              TOKENIZERS_PARALLELISM="false")
            stage = "packages"
            if any(importlib.metadata.version(n) != v for n, v in PACKAGES.items()):
                raise OSErrorCode("PROFILE_DISABLED")
            stage = "request"
            raw = sys.stdin.buffer.readline(MAX_FRAME + 2)
            if not raw.endswith(b"\n") or len(raw) > MAX_FRAME:
                raise OSErrorCode("INVALID")
            request = parse_canonical_json(raw)
            checked_request(request)
            stage = "artifacts"
            root = load_profile(Path(sys.argv[1]))
            model = artifact_bytes(root, "onnx/model.onnx", private=True)
            tokenizer = artifact_bytes(root, "tokenizer.json", private=True)
            # Public pinned model configuration contains floating-point tuning
            # values. It is verified artifact data, separate from canonical IPC.
            config = json.loads(artifact_bytes(root, "config.json", private=True))
            if config["hidden_size"] != 384:
                raise OSErrorCode("PROFILE_DISABLED")
            stage = "imports"
            import numpy as np
            import onnxruntime as ort
            ort.disable_telemetry_events()
            from tokenizers import Tokenizer
            tok = Tokenizer.from_str(tokenizer.decode())
            tok.enable_truncation(max_length=256)
            tok.enable_padding()
            options = ort.SessionOptions()
            options.intra_op_num_threads = options.inter_op_num_threads = 1
            options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
            options.log_severity_level = 4
            stage = "session"
            session = ort.InferenceSession(model, sess_options=options, providers=["CPUExecutionProvider"])
            session.disable_fallback()
            stage = "inference"
            pieces = []
            # Maximum-size32 inputs exceeded512MiB as one tensor. Actual bounded
            # microbatches preserve the same masked mean/identity templates.
            for start in range(0, len(request["texts"]), 4):
                encoded = tok.encode_batch(request["texts"][start:start + 4])
                inputs = {"input_ids": np.array([e.ids for e in encoded], dtype=np.int64),
                    "attention_mask": np.array([e.attention_mask for e in encoded], dtype=np.int64),
                    "token_type_ids": np.array([e.type_ids for e in encoded], dtype=np.int64)}
                hidden = session.run(None, {v.name: inputs[v.name] for v in session.get_inputs()})[0]
                mask = inputs["attention_mask"][..., None]
                batch = (hidden * mask).sum(axis=1) / mask.sum(axis=1)
                batch /= np.linalg.norm(batch, axis=1, keepdims=True)
                pieces.append(batch)
                del hidden, mask, inputs, encoded, batch
            vectors = np.concatenate(pieces, axis=0)
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if sys.platform == "darwin" else 1024)
            if (vectors.shape != (len(request["texts"]), 384) or not np.isfinite(vectors).all()
                    or not np.allclose(np.linalg.norm(vectors, axis=1), 1, atol=0.000001)
                    or peak > MAX_RSS or attempts[0]):
                raise OSErrorCode("CAPACITY")
            stage = "reply"
            value = dict(profileRef=PROFILE, dimensions=384,
                vectors=[[format(float(v), ".9f") for v in row] for row in vectors],
                peakRssBytes=int(peak), networkAttempts=0,
                cpuMillis=int((resource.getrusage(resource.RUSAGE_SELF).ru_utime +
                    resource.getrusage(resource.RUSAGE_SELF).ru_stime) * 1000))
            frame = canonical_bytes(value) + b"\n"
            if len(frame) > MAX_FRAME:
                raise OSErrorCode("CAPACITY")
            output.write(frame)
        except BaseException as error:
            code = error.code if isinstance(error, OSErrorCode) else "UNAVAILABLE"
            # Only fixed categories cross IPC. No exception message, traceback,
            # path, private frame or library notice is retained.
            name = type(error).__name__
            output.write(canonical_bytes(dict(error=code, stage=stage,
                errorClass=name if name in FAILURE_CLASSES else "Other")) + b"\n")
            raise SystemExit(1) from None
    output.close()


if __name__ == "__main__":
    main()
