"""One private offline model service shared by APIs and durable publishers.

The fixed owned Unix socket carries bounded private frames. It discovers no
host/provider credentials. Normal startup neither installs nor starts it.
"""
import asyncio
import os
from pathlib import Path
import signal
import stat

from agentic_os.adapters.embedding.boundary import EmbeddingBoundary, EmbeddingFailure, checked_reply
from agentic_os.adapters.embedding.profile import DIRECTORY, PROFILE, MAX_FRAME, checked_request, load_profile
from agentic_os.adapters.local.files import OwnershipError, check_private
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.resources import file_lock, initialize_key, read_signed, write_signed
from agentic_os.adapters.local.target import validate_target
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.errors import OSErrorCode

RUNTIME="embed"
SOCKET="s"


def prepare_shared_ipc(path):
    """Explicit init-only ownership of a new Pod-local shared-owner mount.

    A retained correctly owned directory is left byte-for-byte unchanged;
    the existing service validates its signed contents/socket on restart.
    No populated foreign directory, key or recovery gate is repaired.
    """
    if os.getuid()!=0 or os.geteuid()!=0 or not path.is_absolute() or path.resolve()!=path:
        raise OwnershipError('Explicit root-owned ephemeral IPC preparation required')
    info=path.lstat()
    if not stat.S_ISDIR(info.st_mode):raise OwnershipError('Private IPC mount is not a directory')
    if info.st_uid==65534:
        if info.st_mode&0o077:raise OwnershipError('Retained private IPC permissions differ')
        return
    if info.st_uid!=0 or any(path.iterdir()):raise OwnershipError('Foreign or populated IPC mount refused')
    path.chmod(0o700);os.chown(path,65534,65534,follow_symlinks=False)


def socket_identity(path):
    info=path.lstat()
    if not stat.S_ISSOCK(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077:
        raise OwnershipError("Embedding service socket ownership changed")
    return dict(device=info.st_dev,inode=info.st_ino)


def binding(root):
    value=read_signed(root/'service.json',root/'resource.key',maximum=8192)
    if (type(value) is not dict or set(value)!={'version','installationId','profileRef','pid','socket','state'}
            or value['version']!=1 or type(value['version']) is not int
            or value['profileRef']!=PROFILE or type(value['pid']) is not int or value['pid']<=0
            or value['state'] not in {'RUNNING','STOPPED'} or type(value['socket']) is not dict
            or set(value['socket'])!={'device','inode'}
            or any(type(n) is not int or n<0 for n in value['socket'].values())):
        raise OSErrorCode('UNAVAILABLE')
    return value


class EmbeddingClient:
    def __init__(self,manifest):
        self.manifest=Path(manifest)
        self.installation=load_manifest(self.manifest)['installationId']
        self.root=self.manifest.parent/RUNTIME
        if len(os.fsencode(self.root/SOCKET))>100:raise OSErrorCode('PROFILE_DISABLED')
        load_profile(self.manifest.parent/DIRECTORY)

    async def embed(self,texts,*,purpose,language='en',profile_ref=PROFILE):
        frame=checked_request(dict(profileRef=profile_ref,language=language,purpose=purpose,texts=texts))
        writer=None
        try:
            check_private(self.root,directory=True)
            record=binding(self.root)
            if (record['installationId']!=self.installation or record['state']!='RUNNING'
                    or socket_identity(self.root/SOCKET)!=record['socket']):
                raise OSErrorCode('UNAVAILABLE')
            async with asyncio.timeout(50):
                reader,writer=await asyncio.wait_for(asyncio.open_unix_connection(
                    self.root/SOCKET,limit=MAX_FRAME+2),2)
                writer.write(frame);await asyncio.wait_for(writer.drain(),2)
                raw=await reader.readline()
                if len(raw)>MAX_FRAME or not raw.endswith(b'\n') or await reader.read(1):
                    raise OSErrorCode('UNAVAILABLE')
                return checked_reply(raw,len(texts))
        except OSErrorCode:
            raise
        except Exception:
            raise OSErrorCode('UNAVAILABLE') from None
        finally:
            if writer is not None:
                writer.close()
                try:await asyncio.wait_for(writer.wait_closed(),1)
                except Exception:pass


async def serve(manifest,stop=None):
    manifest=Path(manifest);owned=validate_target(manifest)
    await _serve_bound(manifest,owned,stop)


async def _serve_bound(manifest,owned,stop=None,*,current=None):
    """Shared private listener after the explicit provider's ownership check."""
    if load_manifest(manifest)!=owned:raise OwnershipError('Embedding installation differs')
    if current is not None:current()
    model=load_profile(manifest.parent/DIRECTORY)
    root=manifest.parent/RUNTIME
    if len(os.fsencode(root/SOCKET))>100:raise OSErrorCode('PROFILE_DISABLED')
    initialize_key(root,allowed_entries={'service.lock',SOCKET,'service.json'})
    own_signals=stop is None
    stop=stop or asyncio.Event()
    loop=asyncio.get_running_loop()
    clients=set();record=None;worker=None;server=None
    with file_lock(root/'service.lock',timeout=0):
        # No adoption of unknown sockets. A signed exact inode plus death of
        # its recorded owner is required to retire a previous listener.
        previous=binding(root) if (root/'service.json').exists() else None
        if previous is not None and previous['installationId']!=owned['installationId']:
            raise OSErrorCode('UNAVAILABLE')
        if (root/SOCKET).exists() or (root/SOCKET).is_symlink():
            if previous is None:raise OSErrorCode('UNAVAILABLE')
            if previous['installationId']!=owned['installationId'] or socket_identity(root/SOCKET)!=previous['socket']:
                raise OSErrorCode('UNAVAILABLE')
            try:os.kill(previous['pid'],0)
            except ProcessLookupError:pass
            else:raise OSErrorCode('UNAVAILABLE')
            (root/SOCKET).unlink()
        elif previous is not None and previous['state']=='RUNNING':
            try:os.kill(previous['pid'],0)
            except ProcessLookupError:pass
            else:raise OSErrorCode('UNAVAILABLE')
        worker=await EmbeddingBoundary.open(manifest.parent/'embedding-processes',model)
        async def connection(reader,writer):
            task=asyncio.current_task()
            if len(clients)>=16:
                writer.write(canonical_bytes(dict(error='CAPACITY'))+b'\n')
                writer.close()
                return
            clients.add(task);inference=disconnect=None
            try:
                raw=await asyncio.wait_for(reader.readline(),3)
                if len(raw)>MAX_FRAME or not raw.endswith(b'\n'):
                    raise OSErrorCode('INVALID')
                value=parse_canonical_json(raw);checked_request(value)
                if current is not None:current()
                inference=asyncio.create_task(worker.embed(value['texts'],purpose=value['purpose'],
                    language=value['language'],profile_ref=value['profileRef']))
                # Clients keep their request stream open until the reply.
                # Disconnect/extra input cancels and joins the actual child.
                disconnect=asyncio.create_task(reader.read(1))
                done,_=await asyncio.wait((inference,disconnect),return_when=asyncio.FIRST_COMPLETED)
                if disconnect in done:
                    raise OSErrorCode('INVALID')
                result=await inference
                if current is not None:current()
                reply=dict(profileRef=PROFILE,dimensions=384,
                    vectors=[[format(v,'.9f') for v in row] for row in result.vectors],
                    peakRssBytes=result.peak_rss_bytes,networkAttempts=0,cpuMillis=result.cpu_millis)
                writer.write(canonical_bytes(reply)+b'\n');await asyncio.wait_for(writer.drain(),2)
            except Exception as error:
                code=error.code if isinstance(error,OSErrorCode) else 'UNAVAILABLE'
                try:
                    failure=dict(error=code)
                    if isinstance(error,EmbeddingFailure):
                        failure.update(stage=error.stage,errorClass=error.error_class)
                    writer.write(canonical_bytes(failure)+b'\n')
                    await asyncio.wait_for(writer.drain(),1)
                except Exception:pass
            finally:
                for child in (inference,disconnect):
                    if child is not None:child.cancel()
                await asyncio.gather(*(v for v in (inference,disconnect) if v is not None),return_exceptions=True)
                writer.close()
                try:await asyncio.wait_for(writer.wait_closed(),1)
                except Exception:pass
                clients.discard(task)
        try:
            if own_signals:
                for signum in (signal.SIGINT,signal.SIGTERM):loop.add_signal_handler(signum,stop.set)
            server=await asyncio.start_unix_server(connection,root/SOCKET,limit=MAX_FRAME+2,
                backlog=16,start_serving=False)
            os.chmod(root/SOCKET,0o600)
            record=dict(version=1,installationId=owned['installationId'],profileRef=PROFILE,pid=os.getpid(),
                socket=socket_identity(root/SOCKET),state='RUNNING')
            write_signed(root/'service.json',record,root/'resource.key')
            await server.start_serving()
            await stop.wait()
        finally:
            if server is not None:
                server.close();await server.wait_closed()
            pending=list(clients)
            for task in pending:task.cancel()
            await asyncio.gather(*pending,return_exceptions=True)
            await worker.close()
            if record is not None:
                if socket_identity(root/SOCKET)!=record['socket']:
                    raise OSErrorCode('UNAVAILABLE')
                (root/SOCKET).unlink()
                record['state']='STOPPED'
                write_signed(root/'service.json',record,root/'resource.key')
            if own_signals:
                for signum in (signal.SIGINT,signal.SIGTERM):loop.remove_signal_handler(signum)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description='Explicit owned offline embedding service')
    parser.add_argument('--manifest',type=Path,required=True)
    args=parser.parse_args()
    try:asyncio.run(serve(args.manifest))
    except Exception:parser.exit(2,'Owned offline embedding service unavailable; private resources retained\n')
