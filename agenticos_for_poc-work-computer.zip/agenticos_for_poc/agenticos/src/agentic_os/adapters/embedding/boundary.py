"""Finite offline CPU processes with persistent opaque teardown holds.

One worker owner per private root. No SQL connection, provider credential or
private text is stored in the process journal. Unknown cleanup consumes a slot.
"""
import asyncio
from collections import deque
from dataclasses import dataclass
import math
import os
from pathlib import Path
import re
import shutil
import signal
import sys
import threading
import time
from uuid import uuid4

from agentic_os.adapters.embedding.profile import (PROFILE, MAX_FRAME, MAX_RSS,
    FAILURE_CLASSES, FAILURE_STAGES, checked_request, load_profile)
from agentic_os.adapters.local.files import check_private, private_directory
from agentic_os.adapters.local.resources import initialize_key, file_lock, read_signed, write_signed
from agentic_os.contracts.canonical import parse_canonical_json
from agentic_os.errors import OSErrorCode

MODULE = "agentic_os.adapters.embedding.child"


@dataclass(frozen=True)
class Embeddings:
    vectors: tuple
    peak_rss_bytes: int
    cpu_millis: int


class EmbeddingFailure(OSErrorCode):
    def __init__(self, code, stage, error_class):
        if (type(stage) is not str or stage not in FAILURE_STAGES
                or type(error_class) is not str or error_class not in FAILURE_CLASSES):
            raise OSErrorCode("UNAVAILABLE")
        super().__init__(code)
        self.stage, self.error_class = stage, error_class

    def __str__(self):
        return self.code+" (stage="+self.stage+", class="+self.error_class+")"


def checked_reply(raw, count):
    try:
        if len(raw) > MAX_FRAME or not raw.endswith(b"\n"):
            raise ValueError()
        value = parse_canonical_json(raw)
        if type(value) is dict and set(value) == {"error", "stage", "errorClass"}:
            if (type(value["error"]) is not str or value["error"] not in
                    {"CAPACITY", "INVALID", "UNAVAILABLE", "DENIED", "PROFILE_DISABLED"}
                    or type(value["stage"]) is not str or value["stage"] not in FAILURE_STAGES
                    or type(value["errorClass"]) is not str or value["errorClass"] not in FAILURE_CLASSES):
                raise ValueError()
            raise EmbeddingFailure(value["error"], value["stage"], value["errorClass"])
        if type(value) is dict and set(value) == {"error"}:
            if value["error"] in {"CAPACITY", "INVALID", "UNAVAILABLE", "DENIED", "PROFILE_DISABLED"}:
                raise OSErrorCode(value["error"])
            raise ValueError()
        if (type(value) is not dict or set(value) != {"profileRef", "dimensions", "vectors",
                "peakRssBytes", "networkAttempts", "cpuMillis"}
                or value["profileRef"] != PROFILE or value["dimensions"] != 384
                or type(value["networkAttempts"]) is not int or value["networkAttempts"] != 0
                or type(value["peakRssBytes"]) is not int or not 0 < value["peakRssBytes"] <= MAX_RSS
                or type(value["cpuMillis"]) is not int or not 0 <= value["cpuMillis"] <= 10000
                or type(value["vectors"]) is not list or len(value["vectors"]) != count):
            raise ValueError()
        vectors = []
        for row in value["vectors"]:
            if (type(row) is not list or len(row) != 384
                    or any(type(v) is not str or re.fullmatch(r"-?(?:0|1)\.[0-9]{9}", v) is None for v in row)):
                raise ValueError()
            vector = tuple(float(v) for v in row)
            if (not all(math.isfinite(v) and -1 <= v <= 1 for v in vector)
                    or abs(sum(v * v for v in vector) - 1) > 0.00001):
                raise ValueError()
            vectors.append(vector)
        return Embeddings(tuple(vectors), value["peakRssBytes"], value["cpuMillis"])
    except (ValueError, KeyError, TypeError):
        raise OSErrorCode("UNAVAILABLE") from None


class EmbeddingBoundary:
    ACTIVE, QUEUED, QUEUE_SECONDS, WALL_SECONDS = 2, 14, 10, 30

    def __init__(self, root, model_root):
        self.root, self.model = Path(root), load_profile(model_root)
        self.ps = shutil.which("ps")
        if self.ps is None:
            raise OSErrorCode("PROFILE_DISABLED")
        initialize_key(self.root, allowed_entries={"owner.lock", "state.json", "work", "retained"})
        self.owner_lock = file_lock(self.root / "owner.lock", timeout=0)
        self.owner_lock.__enter__()
        try:
            if not (self.root / "work").exists():
                private_directory(self.root / "work")
            check_private(self.root / "work", directory=True)
            self.leases = self._load()
            self.guard = threading.Lock()
            self.queue, self.running = deque(), {}
            self.active = set(self.leases)
            self.closing, self.ready = False, False
        except BaseException:
            self.owner_lock.__exit__(None, None, None)
            raise

    @classmethod
    async def open(cls, root, model_root):
        worker = cls(root, model_root)
        try:
            await worker._recover()
            worker.ready = True
            return worker
        except BaseException:
            worker.owner_lock.__exit__(None, None, None)
            raise

    def _load(self):
        path = self.root / "state.json"
        if not path.exists():
            if list((self.root / "work").iterdir()):
                raise OSErrorCode("UNAVAILABLE")
            return {}
        value = read_signed(path, self.root / "resource.key", maximum=8192)
        if (type(value) is not dict or set(value) != {"version", "leases"}
                or type(value["version"]) is not int or value["version"] != 1 or type(value["leases"]) is not dict
                or len(value["leases"]) > self.ACTIVE):
            raise OSErrorCode("UNAVAILABLE")
        for cookie, record in value["leases"].items():
            if (type(cookie) is not str or len(cookie) != 32 or any(c not in "0123456789abcdef" for c in cookie)
                    or type(record) is not dict or set(record) != {"state", "pid", "startIdentity"}
                    or record["state"] not in {"STARTING", "RUNNING", "HELD"}
                    or type(record["pid"]) is not int or record["pid"] < 0
                    or record["startIdentity"] is not None and
                        (type(record["startIdentity"]) is not str or len(record["startIdentity"]) > 128)):
                raise OSErrorCode("UNAVAILABLE")
        names = {p.name for p in (self.root / "work").iterdir()}
        if names - set(value["leases"]):
            raise OSErrorCode("UNAVAILABLE")
        return value["leases"]

    def _persist(self):
        write_signed(self.root / "state.json", dict(version=1, leases=self.leases), self.root / "resource.key")

    async def _probe(self, pid, fields):
        process = await asyncio.create_subprocess_exec(self.ps, "-o", fields, "-p", str(pid),
            env={"LC_ALL": "C"}, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL, limit=8194)
        try:
            raw, _ = await asyncio.wait_for(process.communicate(), 1)
            if len(raw) > 8192:
                raise OSErrorCode("UNAVAILABLE")
            return raw.decode("utf8").strip()
        finally:
            if process.returncode is None:
                process.kill()
                await process.wait()

    async def _identity(self, pid, cookie):
        stamp = await self._probe(pid, "lstart=,pgid=")
        command = await self._probe(pid, "command=")
        if not stamp and not command:
            return None
        # Cookie is passed only in argv; private text is exclusively pipe input.
        if (not stamp or not command or command.split()[-1] != cookie
                or "-I -m " + MODULE + " " not in command
                or str(self.model) not in command or stamp.split()[-1] != str(pid)):
            raise OSErrorCode("UNAVAILABLE")
        return stamp

    @staticmethod
    def _group_exists(pid):
        try:
            os.killpg(pid, 0)
            return True
        except ProcessLookupError:
            return False

    async def _recover(self):
        for cookie, record in list(self.leases.items()):
            if record["pid"] == 0 or record["startIdentity"] is None:
                # The pre-fork/ACK gap has no proof of a process identity. Keep
                # the opaque work and slot; never assume that no child exists.
                continue
            try:
                current = await self._identity(record["pid"], cookie)
                if current is not None and current != record["startIdentity"]:
                    continue
                if current is not None:
                    os.killpg(record["pid"], signal.SIGKILL)
                deadline = time.monotonic() + 3
                while self._group_exists(record["pid"]) and time.monotonic() < deadline:
                    await asyncio.sleep(0.05)
                if self._group_exists(record["pid"]):
                    continue
                self._remove_work(cookie)
                self.leases.pop(cookie)
                self.active.discard(cookie)
                self._persist()
            except (OSError, OSErrorCode):
                # Foreign/reused PID or unreadable evidence is a retained hold.
                continue

    def _remove_work(self, cookie):
        path = self.root / "work" / cookie
        if path.is_symlink():
            raise OSErrorCode("UNAVAILABLE")
        if not path.exists():
            return
        check_private(path, directory=True)
        # Qualified child writes no files. Unknown material is never removed.
        if list(path.iterdir()):
            raise OSErrorCode("UNAVAILABLE")
        path.rmdir()

    def snapshot(self):
        with self.guard:
            return dict(active=len(self.running), held=len(self.active) - len(self.running), queued=len(self.queue))

    async def _acquire(self, cookie):
        with self.guard:
            if not self.ready or self.closing:
                raise OSErrorCode("UNAVAILABLE")
            if len(self.queue) >= self.QUEUED:
                raise OSErrorCode("CAPACITY")
            self.queue.append(cookie)
        deadline = time.monotonic() + self.QUEUE_SECONDS
        try:
            while True:
                with self.guard:
                    if self.closing:
                        raise OSErrorCode("UNAVAILABLE")
                    if self.queue[0] == cookie and len(self.active) < self.ACTIVE:
                        self.queue.popleft()
                        self.active.add(cookie)
                        self.running[cookie] = asyncio.current_task()
                        return
                if time.monotonic() >= deadline:
                    raise OSErrorCode("CAPACITY")
                await asyncio.sleep(0.01)
        finally:
            with self.guard:
                if cookie in self.queue:
                    self.queue.remove(cookie)

    def _command(self, cookie):
        return [sys.executable, "-I", "-m", MODULE, str(self.model), cookie]

    async def _rss(self, process):
        peak = 0
        while process.returncode is None:
            raw = await self._probe(process.pid, "rss=")
            if raw:
                peak = max(peak, int(raw) * 1024)
                if peak > MAX_RSS:
                    raise OSErrorCode("CAPACITY")
            await asyncio.sleep(0.05)
        return peak

    async def _stop(self, process, cookie):
        if process is None:
            # Cancellation can occur after fork but before Python acknowledges
            # the child. A durable STARTING record is an uncertain process,
            # even though no private frame has been sent. Retain its slot.
            return cookie not in self.leases
        async with asyncio.timeout(3):
            for action in (signal.SIGTERM, signal.SIGKILL):
                current = await self._identity(process.pid, cookie)
                if current is None:
                    if self._group_exists(process.pid):
                        return False
                    await asyncio.wait_for(process.wait(), 1)
                    return True
                if current != self.leases[cookie]["startIdentity"]:
                    return False
                os.killpg(process.pid, action)
                try:
                    await asyncio.wait_for(process.wait(), 1)
                except TimeoutError:
                    pass
                if not self._group_exists(process.pid) and process.returncode is not None:
                    return True
            # Reaping the leader does not prove descendants have left its
            # group. Join the observed group absence within this same budget.
            while self._group_exists(process.pid):
                await asyncio.sleep(0.05)
            return process.returncode is not None
        return False

    async def _exchange(self, process, frame):
        process.stdin.write(frame)
        await process.stdin.drain()
        process.stdin.close()
        raw = await process.stdout.readline()
        if len(raw) > MAX_FRAME or not raw.endswith(b"\n") or await process.stdout.read(1):
            raise OSErrorCode("UNAVAILABLE")
        await asyncio.wait_for(process.wait(), 2)
        return raw

    async def embed(self, texts, *, purpose, language="en", profile_ref=PROFILE):
        frame = checked_request(dict(profileRef=profile_ref, language=language, purpose=purpose, texts=texts))
        cookie = uuid4().hex
        await self._acquire(cookie)
        process = monitor = exchange = None
        clean = False
        try:
            work = self.root / "work" / cookie
            private_directory(work)
            self.leases[cookie] = dict(state="STARTING", pid=0, startIdentity=None)
            self._persist()
            async with asyncio.timeout(self.WALL_SECONDS):
                process = await asyncio.create_subprocess_exec(*self._command(cookie), cwd=work,
                    env=dict(HOME=str(work), PYTHONNOUSERSITE="1", OPENBLAS_NUM_THREADS="1",
                        OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", TOKENIZERS_PARALLELISM="false",
                        ORT_DISABLE_TELEMETRY="1"),
                    stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.DEVNULL, start_new_session=True, limit=MAX_FRAME + 2)
                identity = await self._identity(process.pid, cookie)
                if identity is None:
                    raise OSErrorCode("UNAVAILABLE")
                self.leases[cookie] = dict(state="RUNNING", pid=process.pid, startIdentity=identity)
                self._persist()  # No private frame is sent before durable PID ACK.
                exchange = asyncio.create_task(self._exchange(process, frame))
                monitor = asyncio.create_task(self._rss(process))
                done, _ = await asyncio.wait((exchange, monitor), return_when=asyncio.FIRST_COMPLETED)
                if monitor in done:
                    await monitor
                raw = await exchange
                result = checked_reply(raw, len(texts))
                if process.returncode != 0:
                    raise OSErrorCode("UNAVAILABLE")
                return result
        except TimeoutError:
            raise OSErrorCode("UNAVAILABLE") from None
        except OSErrorCode:
            raise
        except Exception:
            raise OSErrorCode("UNAVAILABLE") from None
        finally:
            async def cleanup():
                nonlocal clean
                try:
                    for task in (exchange, monitor):
                        if task is not None:
                            task.cancel()
                    await asyncio.gather(*(t for t in (exchange, monitor) if t is not None),
                        return_exceptions=True)
                    clean = await self._stop(process, cookie)
                    if clean:
                        self._remove_work(cookie)
                        self.leases.pop(cookie, None)
                    elif cookie in self.leases:
                        self.leases[cookie]["state"] = "HELD"
                    self._persist()
                except Exception:
                    clean = False
                    if cookie in self.leases:
                        self.leases[cookie]["state"] = "HELD"
                        self._persist()
                finally:
                    with self.guard:
                        self.running.pop(cookie, None)
                        if clean:
                            self.active.discard(cookie)
            settle = asyncio.create_task(cleanup())
            try:
                await asyncio.shield(settle)
            except asyncio.CancelledError:
                await settle
                raise
            if not clean:
                raise OSErrorCode("UNAVAILABLE")

    async def close(self):
        with self.guard:
            self.closing = True
            tasks = [t for t in self.running.values() if t is not asyncio.current_task()]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.owner_lock.__exit__(None, None, None)
