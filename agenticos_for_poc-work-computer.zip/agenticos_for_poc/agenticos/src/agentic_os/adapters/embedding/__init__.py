"""Explicit operator-installed offline CPU embeddings; no startup inference."""
