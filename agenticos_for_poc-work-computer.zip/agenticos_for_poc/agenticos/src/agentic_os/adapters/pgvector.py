"""Bounded owned projection candidates. Canonical hydration authorizes disclosure.

This store has only retrieval-component credentials. It cannot query control,
host records, or the separately protected knowledge database.
"""
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import math
import re
from uuid import UUID

from psycopg import Error
from psycopg_pool import PoolTimeout, TooManyRequests
from agentic_os.adapters.postgres.pool import owned_pool
from agentic_os.adapters.local.recovery_gate import runtime_guard

from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode

PROFILE = "minilm-english-onnx/1"
KEYWORD_PROFILE = "keyword-fts/1"
LANES = frozenset({"preference", "episodic", "semantic", "procedural"})
OWNER = ("installationId", "applicationId", "tenantId", "subjectId")
SCOPE = "installation_id=%(installationId)s AND application_id=%(applicationId)s AND tenant_id=%(tenantId)s AND subject_id=%(subjectId)s"


def vector_frame(values):
    if (type(values) not in {tuple, list} or len(values) != 384
            or any(type(v) not in {int, float} or not -1 <= v <= 1 or not math.isfinite(v) for v in values)
            or abs(sum(v*v for v in values)-1) > .00001):
        raise OSErrorCode("INVALID")
    return "[" + ",".join(format(v, ".9f") for v in values) + "]"


def selector(subject, generation, lanes, contexts, profile_ref):
    validate_contract("SubjectRef", subject)
    if (type(generation) is not int or not 1 <= generation <= 2**53-1
            or type(profile_ref) is not str or profile_ref not in {PROFILE,KEYWORD_PROFILE} or type(lanes) not in {tuple, list}
            or not 1 <= len(lanes) <= 4 or any(type(v) is not str or v not in LANES for v in lanes)
            or len(set(lanes)) != len(lanes)
            or type(contexts) not in {tuple, list} or not 1 <= len(contexts) <= 2
            or any(type(v) is not str or not re.fullmatch(r"general/1|context/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/1", v) for v in contexts)
            or len(set(contexts)) != len(contexts)):
        raise OSErrorCode("INVALID")
    return dict(subject, generation=generation, lanes=list(lanes), contexts=list(contexts), profile=profile_ref)


@dataclass(frozen=True)
class Projection:
    id: UUID
    entry_id: UUID
    revision_id: UUID
    entry_version: int
    generation: int
    lane: str
    context_ref: str

    def __post_init__(self):
        if (any(type(v) is not UUID for v in (self.id,self.entry_id,self.revision_id))
                or any(type(v) is not int or not 1<=v<=2**53-1 for v in (self.entry_version,self.generation))
                or type(self.lane) is not str or self.lane not in LANES
                or type(self.context_ref) is not str or not re.fullmatch(
                    r"general/1|context/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/1",self.context_ref)):
            raise OSErrorCode("INVALID")


def rows_from(cursor):
    names=[v.name for v in cursor.description]
    return [dict(zip(names,row)) for row in cursor.fetchall()]


class RetrievalStore:
    MAX_CORPUS = 2000
    profile_ref=PROFILE

    def __init__(self, manifest,*,installation_ports=None,profile_ref=PROFILE):
        if type(profile_ref) is not str or profile_ref not in {PROFILE,KEYWORD_PROFILE}:raise OSErrorCode('PROFILE_DISABLED')
        self.profile_ref=profile_ref
        self.manifest=manifest
        self.modes=frozenset({'exact','ann','lexical','hybrid'})
        self.guard=lambda:runtime_guard(manifest)
        if installation_ports is None:self.pool=owned_pool(manifest,component="retrieval")
        else:
            from agentic_os.adapters.postgres.pool import configured_pool
            components=installation_ports.require_components(manifest)
            self.modes=components.retrieval_modes
            self.pool=configured_pool(components.retrieval,max_size=4)
            self.guard=installation_ports.transaction_guard
        if profile_ref==KEYWORD_PROFILE:self.modes=self.modes&{'lexical'}

    @contextmanager
    def transaction(self, subject):
        validate_contract("SubjectRef", subject)
        try:
            with self.guard() as proof:
                if proof is not None:proof.verify()
                with self.pool.connection(timeout=2) as connection, connection.transaction():
                    connection.execute("SET LOCAL lock_timeout='2s'")
                    connection.execute("SET LOCAL statement_timeout='3s'")
                    from agentic_os.contracts.canonical import canonical_bytes
                    connection.execute("SELECT set_config('agentic.owner_scope',%s,true)",
                        (canonical_bytes(subject).decode(),))
                    yield connection
                    if proof is not None:proof.verify()
        except (PoolTimeout, TooManyRequests):
            raise OSErrorCode("CAPACITY") from None
        except Error:
            raise OSErrorCode("UNAVAILABLE") from None

    def publish(self, subject, projection, vector, content):
        if not isinstance(projection, Projection) or type(content) is not str or not 1 <= len(content) <= 1000:
            raise OSErrorCode("INVALID")
        args=selector(subject, projection.generation, [projection.lane], [projection.context_ref], self.profile_ref)
        if type(projection.entry_version) is not int or not 1 <= projection.entry_version <= 2**53-1:
            raise OSErrorCode("INVALID")
        if self.profile_ref==KEYWORD_PROFILE and vector is not None:raise OSErrorCode('INVALID')
        args.update(id=projection.id,entry=projection.entry_id,revision=projection.revision_id,
            version=projection.entry_version,lane=projection.lane,context=projection.context_ref,
            vector=None if self.profile_ref==KEYWORD_PROFILE else vector_frame(vector),content=content)
        with self.transaction(subject) as db:
            # All publication and purge operations share this scoped advisory
            # lock. The immutable store registry grants no UPDATE privilege.
            # Cross-store CAS remains the
            # canonical publisher's job; this write is not readiness proof.
            db.execute("SELECT pg_advisory_xact_lock(60501,hashtext(current_setting('agentic.owner_scope')))")
            barrier=db.execute("SELECT minimum_version,forgotten FROM personal_knowledge_fences WHERE "+SCOPE+
                " AND entry_id=%(entry)s",args).fetchone()
            if barrier is not None and (barrier[1] or projection.entry_version<barrier[0]):
                raise OSErrorCode("CONFLICT")
            count=db.execute("SELECT count(*) FROM personal_knowledge_vectors WHERE "+SCOPE,args).fetchone()[0]
            if count >= self.MAX_CORPUS and not db.execute("SELECT 1 FROM personal_knowledge_vectors WHERE id=%(id)s",args).fetchone():
                raise OSErrorCode("CAPACITY")
            db.execute("""INSERT INTO personal_knowledge_vectors
                (id,installation_id,application_id,tenant_id,subject_id,entry_id,revision_id,entry_version,
                 index_generation,profile_ref,lane,context_ref,embedding,lexemes)
                VALUES (%(id)s,%(installationId)s,%(applicationId)s,%(tenantId)s,%(subjectId)s,%(entry)s,%(revision)s,%(version)s,
                 %(generation)s,%(profile)s,%(lane)s,%(context)s,CAST(%(vector)s AS vector(384)),to_tsvector('english',%(content)s))
                ON CONFLICT (id) DO NOTHING""",args)
            exact=db.execute("""SELECT 1 FROM personal_knowledge_vectors WHERE """+SCOPE+"""
                AND id=%(id)s AND entry_id=%(entry)s AND revision_id=%(revision)s AND entry_version=%(version)s
                AND index_generation=%(generation)s AND profile_ref=%(profile)s AND lane=%(lane)s AND context_ref=%(context)s
                AND embedding IS NOT DISTINCT FROM CAST(%(vector)s AS vector(384)) AND lexemes=to_tsvector('english',%(content)s)""",args).fetchone()
            if exact != (1,):
                raise OSErrorCode("CONFLICT")

    def seal(self, subject, entry_id, *, minimum_version, forgotten):
        """Commit a monotonic barrier and derivative erasure in one store transaction.

        Permanent entry forgetting cannot be reversed. A source/correction barrier
        blocks only older entry versions; a fresh approved revision can be indexed.
        Canonical consent and revision eligibility remain the caller's responsibility.
        """
        validate_contract("SubjectRef",subject)
        if (type(entry_id) is not UUID or type(minimum_version) is not int
                or not 1 <= minimum_version <= 2**53-1 or type(forgotten) is not bool):
            raise OSErrorCode("INVALID")
        args=dict(subject,entry=entry_id,minimum=minimum_version,forgotten=forgotten,
                  now=datetime.now(timezone.utc))
        with self.transaction(subject) as db:
            db.execute("SELECT pg_advisory_xact_lock(60501,hashtext(current_setting('agentic.owner_scope')))")
            db.execute("""INSERT INTO personal_knowledge_fences
                (installation_id,application_id,tenant_id,subject_id,entry_id,
                 minimum_version,forgotten,created_at,updated_at)
                VALUES (%(installationId)s,%(applicationId)s,%(tenantId)s,%(subjectId)s,
                        %(entry)s,%(minimum)s,%(forgotten)s,%(now)s,%(now)s)
                ON CONFLICT (installation_id,application_id,tenant_id,subject_id,entry_id)
                DO UPDATE SET minimum_version=GREATEST(personal_knowledge_fences.minimum_version,EXCLUDED.minimum_version),
                    forgotten=personal_knowledge_fences.forgotten OR EXCLUDED.forgotten,
                    updated_at=GREATEST(personal_knowledge_fences.updated_at,EXCLUDED.updated_at)""",args)
            db.execute("""DELETE FROM personal_knowledge_vectors v WHERE """+SCOPE+"""
                AND entry_id=%(entry)s AND EXISTS (SELECT 1 FROM personal_knowledge_fences f
                    WHERE f.installation_id=v.installation_id AND f.application_id=v.application_id
                      AND f.tenant_id=v.tenant_id AND f.subject_id=v.subject_id AND f.entry_id=v.entry_id
                      AND (f.forgotten OR v.entry_version<f.minimum_version))""",args)

    def purge(self, subject, entry_id):
        """Permanent forgetting, including refusal of every later projection write."""
        self.seal(subject,entry_id,minimum_version=1,forgotten=True)

    def discard(self, subject, projection_id):
        """Remove only this stale/abandoned projection after failed control CAS."""
        validate_contract("SubjectRef",subject)
        if type(projection_id) is not UUID:
            raise OSErrorCode("INVALID")
        with self.transaction(subject) as db:
            db.execute("DELETE FROM personal_knowledge_vectors WHERE "+SCOPE+" AND id=%(id)s",dict(subject,id=projection_id))

    def retire_older(self, subject, projection):
        """Bounded single-entry cleanup after the canonical pointer is ready."""
        if not isinstance(projection,Projection):
            raise OSErrorCode("INVALID")
        args=selector(subject,projection.generation,[projection.lane],[projection.context_ref],self.profile_ref)
        args.update(entry=projection.entry_id,version=projection.entry_version,id=projection.id)
        with self.transaction(subject) as db:
            db.execute("DELETE FROM personal_knowledge_vectors WHERE "+SCOPE+
                " AND entry_id=%(entry)s AND id<>%(id)s AND (index_generation<%(generation)s OR (index_generation=%(generation)s AND entry_version<%(version)s))",args)

    def candidates(self, subject, *, generation, lanes, contexts, vector=None, query=None,
                   eligible_ids, mode="exact", profile_ref=None, top_k=5, qualified_ann=False, qualified_hybrid=False):
        profile_ref=self.profile_ref if profile_ref is None else profile_ref
        args=selector(subject,generation,lanes,contexts,profile_ref)
        if profile_ref!=self.profile_ref:raise OSErrorCode('PROFILE_DISABLED')
        # Personal callers snapshot at most64 current approved projections in
        # control. Eligibility is applied before any exact/ANN/FTS ranking;
        # the same scope is rechecked during canonical hydration afterwards.
        if (type(eligible_ids) not in {tuple,list} or len(eligible_ids)>64
                or any(type(v) is not UUID for v in eligible_ids)
                or len(set(eligible_ids))!=len(eligible_ids)):
            raise OSErrorCode("INVALID")
        args["eligible"]=list(eligible_ids)
        if type(top_k) is not int or not 1 <= top_k <= 32 or type(mode) is not str or mode not in {"exact","ann","lexical","hybrid"}:
            raise OSErrorCode("INVALID")
        if type(qualified_ann) is not bool or type(qualified_hybrid) is not bool:
            raise OSErrorCode("INVALID")
        if mode == "ann" and not qualified_ann or mode == "hybrid" and not qualified_hybrid:
            raise OSErrorCode("PROFILE_DISABLED")
        if mode not in self.modes:raise OSErrorCode('PROFILE_DISABLED')
        if mode in {"exact","ann","hybrid"}:
            args["vector"]=vector_frame(vector)
        if mode in {"lexical","hybrid"}:
            if type(query) is not str or not query.strip() or len(query)>1000:
                raise OSErrorCode("INVALID")
            args["query"]=query
        args["top"]=top_k
        scope=SCOPE+" AND index_generation=%(generation)s AND profile_ref=%(profile)s AND lane=ANY(%(lanes)s) AND context_ref=ANY(%(contexts)s) AND id=ANY(%(eligible)s)"
        scope+=""" AND NOT EXISTS (SELECT 1 FROM personal_knowledge_fences f
            WHERE f.installation_id=personal_knowledge_vectors.installation_id
              AND f.application_id=personal_knowledge_vectors.application_id
              AND f.tenant_id=personal_knowledge_vectors.tenant_id
              AND f.subject_id=personal_knowledge_vectors.subject_id
              AND f.entry_id=personal_knowledge_vectors.entry_id
              AND (f.forgotten OR personal_knowledge_vectors.entry_version<f.minimum_version))"""
        columns="id,entry_id,revision_id,entry_version,index_generation,profile_ref,lane,context_ref"
        # Disjunctive stemming is fixed before scoring this implementation.
        # The parser creates escaped lexemes; caller text is never SQL syntax.
        lexical_query="replace(plainto_tsquery('english',%(query)s)::text,' & ',' | ')::tsquery"
        with self.transaction(subject) as db:
            if mode == "ann":
                db.execute("SET LOCAL hnsw.ef_search=40")
                db.execute("SET LOCAL hnsw.iterative_scan='strict_order'")
                db.execute("SET LOCAL hnsw.max_scan_tuples=20000")
                rows=rows_from(db.execute("SELECT "+columns+" FROM personal_knowledge_vectors WHERE "+scope+
                    " ORDER BY embedding <=> CAST(%(vector)s AS vector(384)) LIMIT %(top)s",args))
                if len(rows)>=top_k:
                    return [dict(v) for v in rows]
                # An underfilled approximate scan may use exact search in the
                # same permitted scope. No broader lane/owner/generation retry.
                mode="exact"
            if mode == "exact":
                sql="WITH eligible AS MATERIALIZED (SELECT * FROM personal_knowledge_vectors WHERE "+scope+") SELECT "+columns+" FROM eligible ORDER BY embedding <=> CAST(%(vector)s AS vector(384)),id LIMIT %(top)s"
            elif mode == "lexical":
                sql="WITH eligible AS MATERIALIZED (SELECT * FROM personal_knowledge_vectors WHERE "+scope+") SELECT "+columns+" FROM eligible WHERE lexemes @@ "+lexical_query+" ORDER BY ts_rank_cd(lexemes,"+lexical_query+") DESC,id LIMIT %(top)s"
            else:
                sql="WITH eligible AS MATERIALIZED (SELECT * FROM personal_knowledge_vectors WHERE "+scope+"), semantic AS (SELECT id,row_number() OVER (ORDER BY embedding <=> CAST(%(vector)s AS vector(384)),id) n FROM eligible), lexical AS (SELECT id,row_number() OVER (ORDER BY ts_rank_cd(lexemes,"+lexical_query+") DESC,id) n FROM eligible WHERE lexemes @@ "+lexical_query+"), ranked AS (SELECT e.*,1.0/(60+s.n)+COALESCE(1.0/(60+l.n),0) score FROM eligible e JOIN semantic s USING(id) LEFT JOIN lexical l USING(id)) SELECT "+columns+" FROM ranked ORDER BY score DESC,id LIMIT %(top)s"
            return rows_from(db.execute(sql,args))

    def close(self):
        self.pool.close(timeout=3)
