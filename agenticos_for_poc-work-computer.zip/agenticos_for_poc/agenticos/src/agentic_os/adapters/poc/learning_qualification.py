"""Observe original canonical learning jobs against the existing API ledger.

This operator report has no task, job, consent, balance or replay authority.
Only reservations created by this running qualifier can transition here.
"""
import asyncio
from copy import deepcopy
from pathlib import Path
from uuid import UUID

from sqlalchemy import select,func

from agentic_os.adapters.local.files import private_write
from agentic_os.adapters.postgres.models import LearningJob
from agentic_os.contracts.canonical import canonical_bytes,digest
from agentic_os.identity.context import iso,namespace


class LearningQualification:
    def __init__(self,allowance,store,report):
        self.allowance,self.store,self.report=allowance,store,Path(report)
        if self.report.exists():raise ValueError('Retain the prior original learning observation')
        self.rows={};self.lock=asyncio.Lock();self.stage=None;self.save()

    def save(self):
        private_write(self.report,canonical_bytes(dict(schema='poc-original-learning-job-observation/1',
            authority='Qualification observation only; canonical jobs and existing cumulative ledger own state',
            jobs=list(self.rows.values()))),replace=self.report.exists())

    def context(self,binding):
        with self.store.transaction() as db:
            job=db.get(LearningJob,UUID(binding['jobId']))
            if (job is None or namespace(binding['subject'])!={k:getattr(job,k) for k in namespace(binding['subject'])}
                    or str(job.lease_id)!=binding['leaseId'] or job.state!='RUNNING' or job.provider_started
                    or job.lease_until<=db.scalar(select(func.clock_timestamp()))):
                raise ValueError('Exact current unstarted canonical learning job required')
            value=dict(subject=deepcopy(binding['subject']),jobId=str(job.id),leaseId=str(job.lease_id),
                profile=job.profile_ref,promptRef=job.prompt_ref,expiresAt=iso(job.expires_at),
                leaseUntil=iso(job.lease_until),budget=deepcopy(job.budget))
        return self.allowance.learning_context(value)

    async def reserve(self,binding,meter):
        async with self.lock:
            if binding['jobId'] in self.rows:raise ValueError('No second provider binding for the original learning job')
            context=await asyncio.to_thread(self.context,binding)
            ident=await asyncio.to_thread(self.allowance.reserve_learning_job,'poc-family-learning/'+context['jobId'],meter,context)
            self.rows[context['jobId']]=dict(id=ident,context=context,meter=deepcopy(meter),state='RESERVED',providerObservations=[])
            self.save();return context

    async def observe(self,record):
        async with self.lock:
            row=self.rows.get(record['context']['jobId'])
            if (row is None or row['context']!=record['context'] or row['state']!='RESERVED'
                    or record['meterDigest']!=digest('policy',row['meter']) or len(row['providerObservations'])>=2):
                raise ValueError('Exact original learning observation required')
            row['providerObservations'].append(deepcopy(record));self.save()

    def accounting(self,row):
        context=row['context']
        with self.store.transaction() as db:
            job=db.get(LearningJob,UUID(context['jobId']))
            if job is None:raise ValueError('Original canonical learning job missing')
            original=dict(subject=deepcopy(context['subject']),jobId=str(job.id),leaseId=str(job.lease_id),
                profile=job.profile_ref,promptRef=job.prompt_ref,expiresAt=iso(job.expires_at),
                leaseUntil=iso(job.lease_until),budget=deepcopy(job.budget))
            if (original!=context or namespace(context['subject'])!={k:getattr(job,k) for k in namespace(context['subject'])}):
                raise ValueError('Original canonical learning identity or horizon changed')
            result=dict(state=job.state,providerStarted=job.provider_started,usage=deepcopy(job.usage),
                leaseUntil=original['leaseUntil'],expiresAt=original['expiresAt'],
                leaseExpired=job.lease_until<=db.scalar(select(func.clock_timestamp())))
        snapshot=self.stage.lifecycle.owner_snapshot(context['subject']) if self.stage is not None else None
        result['physicalStopped']=bool(snapshot is not None and not snapshot['unboundWork'] and not any(
            v.get('jobId')==context['jobId'] for v in [*snapshot['leases'].values(),*snapshot['queue']]))
        known=[v for v in row['providerObservations'] if v['state']=='KNOWN' and v.get('usage')==result['usage']
            and v.get('providerUsageRef') and v.get('context')==context and v['meterDigest']==digest('policy',row['meter'])]
        result['providerUsageRef']=known[0]['providerUsageRef'] if len(known)==1 else None
        result['allProviderUsageKnown']=bool(len(known)==1 if result['providerStarted'] else
            result['usage'] is None and not row['providerObservations'])
        return result

    async def settle(self,*,closing=False):
        async with self.lock:
            for row in self.rows.values():
                if row['state']!='RESERVED':continue
                accounting=await asyncio.to_thread(self.accounting,row)
                ready=(accounting['state'] in {'SUCCEEDED','FAILED','CANCELLED'}
                    and accounting['leaseExpired'] and accounting['physicalStopped'])
                if not closing and not ready:continue
                row['state']=await asyncio.to_thread(self.allowance.finish_learning_job,row['id'],
                    context=row['context'],accounting=accounting,meter=row['meter'])
                row['observedAccounting']=accounting;self.save()
