"""Reuse the original owner-input family for a missing read referent."""
import asyncio
from uuid import UUID,uuid5
from sqlalchemy import select

from agentic_os.adapters.postgres.models import AgentPayloadWrite
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.errors import OSErrorCode
from agentic_os.production.goals import ReadGoals
from agentic_os.production.owner_input import OwnerInputService
from agentic_os.production.owner_read_context import HARNESS,current,model_input
from .family_reads import ContextualFamilyReadGoals


class ContextQuestionSources(ContextualFamilyReadGoals):
    async def _validate_planner_source(self,actor,context,accepted):
        self._profile(context)
        _,graph=await self.observations.read(actor,context,accepted['result'],include_sources=True)
        initial=[value for reference,value in graph if reference['payload']['schemaRef']=='AgentProviderResponse'
            and value['identity']['parentOperationId'] is None]
        if len(initial)!=1:raise OSErrorCode('DENIED')
        await asyncio.to_thread(self._discovery_sources,actor,context,accepted,graph)
        await asyncio.to_thread(ReadGoals._planner_source,self,actor,context,initial[0])
        await asyncio.to_thread(self._planner_prefix,actor,context,accepted)


class ContextualReadOwnerInput(OwnerInputService):
    harness_ref=HARNESS
    field=dict(field='owner-input/1',code='record-selection-required',
        safeMessage='Which record do you mean? Tell me its name or reference.')

    def __init__(self,verified,capabilities):
        super().__init__(verified)
        self.base_goals=ContextQuestionSources(verified.observations,capabilities)
        self.base_goals.context_harness=verified.goals.context_harness
        self.base_goals.context_definition=verified.goals.context_definition
        self.base_goals.context_schema=verified.goals.context_schema
        self.base_goals.inputs=self

    def _context(self,actor,task_id):
        context,original=super()._context(actor,task_id)
        self.base_goals._profile(context)
        return context,original

    def _live(self,db,actor,context):
        self.base_goals._profile(context)
        return super()._live(db,actor,context)

    async def request(self,actor,context,planner):
        self.base_goals._profile(context)
        with self.store.transaction() as db:
            self.observations.fence(db,actor,context)
            if db.scalar(select(AgentPayloadWrite.id).where(
                    AgentPayloadWrite.id==uuid5(UUID(context['taskId']),'read-goal/1'))) is not None:
                raise OSErrorCode('CONFLICT')
        return await super().request(actor,context,planner)

    async def state(self,actor,context,operation_id):
        result=await super().state(actor,context,operation_id)
        if result['kind']=='answered':
            messages=parse_canonical_json(result['inputJson'])
            owner_context=await asyncio.to_thread(current,self.models,actor,context)
            result['inputJson']=canonical_bytes([*model_input(messages[0]['content'],owner_context,context,
                schema=self.base_goals.context_schema),messages[1]]).decode()
        return result
