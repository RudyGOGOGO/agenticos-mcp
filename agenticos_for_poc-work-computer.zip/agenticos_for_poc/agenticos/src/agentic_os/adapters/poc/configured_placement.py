"""Explicit one-Core A1 placement over the existing certified AWS ports."""
from pathlib import Path

from agentic_os.adapters.installation import InstallationPorts
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.postgres.profiles import RDS_EXACT
from agentic_os.errors import OSErrorCode


def configured_poc(runtime):
    from agentic_os.adapters.aws.backend import RDSControl
    ports=getattr(runtime.registry,'installation_ports',None)
    control=getattr(getattr(ports,'connect',None),'__self__',None)
    if (type(ports) is not InstallationPorts or runtime.store.installation_ports is not ports
            or runtime.registry.network!='web-pki/1' or Path(runtime.manifest)!=ports.root/'manifest.json'
            or load_manifest(runtime.manifest)['profile']!='aws-eks/1'
            or type(control) is not RDSControl or control.storage_profile!=RDS_EXACT
            or control.installation_id!=ports.installation_id or ports.components is None
            or ports.components.installation_id!=ports.installation_id
            or 'ann' in ports.components.retrieval_modes):
        raise OSErrorCode('PROFILE_DISABLED')
    return ports


def selected_poc(runtime,*,local_synthetic,configured):
    if type(local_synthetic) is not bool or type(configured) is not bool:return False
    if configured:
        if local_synthetic:return False
        configured_poc(runtime);return True
    from agentic_os.adapters.local.ownership import POC_PROFILE
    return (local_synthetic and runtime.registry.network=='owned-local-http/1'
        and load_manifest(runtime.manifest)['profile']==POC_PROFILE)
