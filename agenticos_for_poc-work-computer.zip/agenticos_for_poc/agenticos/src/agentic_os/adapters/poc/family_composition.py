"""Application metadata and existing journal wiring for VF integration."""
from copy import deepcopy
from datetime import timedelta
import json
import time

import jwt

from agentic_os.adapters.local.files import private_read
from agentic_os.contracts.canonical import digest
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import timestamp,iso,utcnow
from agentic_os.production.lookup_scope import harness_ref
from agentic_os.production.preparation_lane import HostPreparationLane
from .family_mapping import FamilyReadMapping
from .configuration import schema_json
from .verizon_host import VerizonHostBridge
from . import runtime_local as base


class FamilyHostBridge(VerizonHostBridge):
    def __init__(self,*,wire_namespace,**kwargs):
        super().__init__(**kwargs);self.wire_namespace=deepcopy(wire_namespace)

    def credential(self,subject,tool,until):
        control=self.control(subject)
        if tool not in control['tools']:raise OSErrorCode('DENIED')
        now=int(time.time());expiry=min(int(timestamp(until).timestamp()),now+60)
        if expiry<=now:raise OSErrorCode('DENIED')
        native={} if self.local_access is None else self.local_access.record.claims(subject)
        return jwt.encode(dict(iss='vf-poc-local',aud=['vf-mcp'],sub=subject['subjectId'],
            **self.wire_namespace,**native,tools=[tool],iat=now,exp=expiry),private_read(self.mcp_key_file,4096),algorithm='HS256')

    def authorized_document(self,mapping,document,control,arguments):
        return mapping.authorized(document,control,arguments)

    async def dispatch(self,action,body):
        if action=='scope':
            result=await super().dispatch(action,body);control=self.control(body['context']['subject'])
            result['capabilities'] += [pin for pin in body['capabilities'] if pin['ref'] in self.mappings
                and self.mappings[pin['ref']]['capability']==pin
                and self.mappings[pin['ref']]['mapping'].tool in control['tools']]
            return result
        if action in {'read','observe'}:
            value=body['read'] if action=='observe' else body
            binding=value['binding'];registered=self.mappings.get(binding['capability']['ref'])
            if registered is None:raise OSErrorCode('DENIED')
            arguments=base.parse_canonical_json(binding['argumentsJson'])
            control=self.control(binding['context']['subject'])
            if 'memberId' in arguments and arguments['memberId'] not in control['memberIds']:
                raise OSErrorCode('DENIED')
        return await super().dispatch(action,body)


def family_definition_ref(kind,model):
    # Keep every registered OpenAI definition unchanged. Claude receives its
    # own immutable namespace (including account-policy/model pin).
    suffix='' if model['provider']=='openai' else '-anthropic-'+digest('manifest',model)[:16]
    return 'poc-family-'+kind+suffix+'/1'


def live_profile(profile,meter,*,revision=1):
    from agentic_os.production.model_policy import validate_meter
    validate_meter(meter);profile=deepcopy(profile)
    profile['model']=deepcopy(meter['model']);profile['definition']['model']=base.version_pin(profile['model'])
    profile['definition']['id']=family_definition_ref('change',profile['model']);profile['definition']['revision']=revision
    profile['resources']['limits'].update(tokens=1000000,costMicros=500000,storageBytes=32*1048576)
    profile['definition']['resourcePolicy']['digest']=digest('policy',profile['resources'])
    profile['grantCeiling']=deepcopy(profile['resources']['limits'])
    validate_contract('AgentAdmissionProfile',profile)
    return profile


def validate_table_display_mapping(value):
    if 'table_display_mapping' not in value:return
    if (value['table_display_mapping']!='vf.units-labelled/1'
            or type(value['table_display_mapping']) is not str
            or value.get('change_clarification') is not True
            or value.get('profile_revision')!=2 or value.get('table_revision')!=3
            or type(value.get('read_revision')) is not int or value['read_revision']<4):
        raise ValueError('Explicit units-labelled mapping requires immutable clarification2/table3/read4 profiles')


def validate_owner_read_context(value):
    if (type(value.get('read_parallel_tools',False)) is not bool
            or value.get('read_parallel_tools') and value.get('read_goal_completion') is not True):
        raise ValueError('Independent read rounds require the additive goal-completion profile')
    if (type(value.get('read_goal_completion',False)) is not bool
            or value.get('read_goal_completion') and (value.get('owner_read_context') is not True
                or value.get('owner_read_context_version')!=2)):
        raise ValueError('Goal completion requires an explicit new coverage-context profile')
    if (type(value.get('owner_read_context',False)) is not bool
            or type(value.get('owner_read_context_version',1)) is not int
            or value.get('owner_read_context_version',1) not in (1,2)
            or 'owner_read_context_version' in value and value.get('owner_read_context') is not True
            or value.get('owner_read_context') and value.get('table_display_mapping')!='vf.units-labelled/1'):
        raise ValueError('Owner read context requires the explicit new immutable units-labelled read profile')


def lookup_profile(profile,capabilities,*,table_revision=2,display_mapping=None):
    if type(table_revision) is not int or table_revision not in {2,3}:raise ValueError('Explicit table completion revision required')
    profile=deepcopy(profile);profile['definition'].update(id=family_definition_ref('read',profile['model']))
    profile['capabilities'].update(id='poc-family-read-capabilities/1',allowedKinds=['read'])
    profile['definition']['capabilityPolicy']=base.version_pin(profile['capabilities'],'policy')
    profile['harness']['harness']=dict(ref=harness_ref(capabilities),revision=table_revision,
        digest=digest('manifest',dict(format='accepted-table-lookup/2' if table_revision==2 else 'goal-table-completion/3',
            harness=profile['harness'],capabilities=capabilities)))
    profile['definition']['harness']=deepcopy(profile['harness']['harness'])
    if display_mapping is not None:
        if display_mapping!='vf.units-labelled/1' or profile['definition']['revision']!=2 or table_revision!=3:
            raise ValueError('Units-labelled tables require a fresh read definition3 over immutable read2/table3')
        profile['definition']['revision']=3
    validate_contract('AgentAdmissionProfile',profile)
    return profile


PREPARATIONS={
    'CreateGeofence':('Prepare a new boundary alert only when current location details show no rule for this member. '
        'Lookup the requested member, list locations and read selected location details. resourceId=saved location id; '
        'expectedVersion=decimal string of location revision. Required fields savedLocationId,memberId,radiusMeters,notificationType. '
        'Absent radius/notification may be suggested as explicit owner-editable assumptions: 300 meters and BOTH. '
        'Do not create a duplicate. Coordinates are synthetic; this never promises live GPS or physical safety.'),
    'UpdateGeofence':('Prepare edits to an existing rule from current location details. resourceId is compact JSON '
        'with savedLocationId and geofenceId; expectedVersion=decimal string of rule revision. '
        'Only changed fields radiusMeters,notificationType,enabled are permitted. Keep exact current member/location identity.'),
    'CreateSavedLocation':('Prepare a new saved location. resourceId=saved-locations; expectedVersion=collection/1. '
        'Required fields name,latitude,longitude; address optional. Latitude/longitude use exact decimal strings from '
        'owner input or authorized source; never invent a location or geocode without a registered tool.'),
    'UpdateSavedLocation':('Prepare current saved location edits. resourceId=saved location id; expectedVersion=decimal '
        'string of location revision. Change only supplied name,latitude,longitude,address. Exact decimal strings '
        'for coordinates. Resolve current identifiers/revision through authorized list/details.'),
}


def preparation_capability(tool, *, revision=None):
    from agentic_os.production.capability_catalog import validate_registration
    if revision is None:revision=2 if tool in {'CreateGeofence','UpdateGeofence'} else 1
    if revision not in ({1,2,3,4} if tool=='CreateGeofence' else {1,2,3} if tool=='UpdateGeofence' else {1,3}):
        raise ValueError('Supported immutable preparation revision required')
    schema=json.loads(schema_json('AgentChangeArguments'));schema['description']=PREPARATIONS[tool]
    if revision==4:
        schema['description']=('Prepare a new boundary alert only when current selected location details show no rule for this member. '
            'Resolve an unknown member id with the authorized member lookup. If the request provides an exact location id, '
            'read that location directly; ListSavedLocations is only for resolving an unknown location id, not a prerequisite '
            'for an already identified location. Read current selected location details to verify its revision and rule state. '
            'resourceId=saved location id; expectedVersion=decimal string of current location revision. Required fields '
            'savedLocationId,memberId,radiusMeters,notificationType; enabled is optional. Explicit owner values and unambiguous '
            'mapped wording take precedence over defaults. ONLY absent radius/notification may use editable assumptions '
            '300 meters and BOTH. Do not create a duplicate rule or substitute an update when no target rule exists. '
            'Coordinates are synthetic; this never promises live GPS or physical safety.')
    if revision in {2,3,4} and tool in {'CreateGeofence','UpdateGeofence'}:
        schema['description']+=' notificationType must be exactly ENTER_ONLY (arrives), LEAVE_ONLY (leaves), or BOTH. Radius is an integer from 50 through 5000 meters; enabled is a boolean.'
    if revision in {3,4}:
        from agentic_os.production.change_arguments import continuation_schema
        schema=continuation_schema(schema)
    value=dict(id='vf.'+tool,revision=revision,kind='propose',purpose='assistant.manage',title='Prepare '+tool,
        description='Prepare '+tool+' from current authorized records. The reviewed parameter schema describes exact resource/version/field mapping and editable assumptions. Separate owner approval is required.',
        adapterRef='typed.prepare/1',scopePolicyRef='vf.current-owner',
        inputSchemaJson=json.dumps(schema,sort_keys=True,separators=(',',':')),outputSchemaJson=schema_json('AgentPreparedChange'),
        mcp=None,lifecycle='qualified')
    validate_registration(value);return value


def read_capability(tool,mapping,mcp_url,*,revision=1):
    from agentic_os.production.capability_catalog import validate_registration
    value=base.wrapped_capability(tool,mapping,mcp_url);value['purpose']='assistant.manage';value['revision']=revision
    guidance=((tool['description'] or tool['name'])+' Exact source resourceType='+mapping.resource_type+
        '; fields='+','.join(mapping.fields)+'. Source version fingerprint is not the product revision. '
        'History is a bounded recorded window; truncated is authoritative. Location details yield an explicit '
        'No boundary alerts row when empty. No live GPS or safety guarantee.')
    if tool['name']=='GetLastKnownLocation':
        guidance+=' Required derived-label support before binding a goal: ListSavedLocations and '
        guidance+='GetSavedLocationWithGeofences for EVERY returned location ID, even with no rules. '
        guidance+='Core derives Unknown or Near a saved place only from enabled rules for this member; no guessed label.'
    if tool['name']=='GetSavedLocationWithGeofences':
        guidance+=' When selecting this table, required output fields: name,address,memberDisplayName,radiusMeters,notificationType,enabled,updatedAt,ruleStatus.'
    schema=json.loads(value['inputSchemaJson']);schema['description']=guidance
    value['inputSchemaJson']=json.dumps(schema,sort_keys=True,separators=(',',':'))
    value['mcp']['binding']['inputSchemaJson']=value['inputSchemaJson']
    value['description']=tool['name']+' current authorized source. The reviewed parameter schema declares output fields, resource type and required supporting reads; do not invent source IDs or completeness.'
    if revision>=2:
        descriptions={
            'GetLastKnownLocation':'For its derived label, also read ListSavedLocations and GetSavedLocationWithGeofences for EACH returned ID, including places with zero alerts. Show recordedAt, coordinates and battery; Core derives the approximate label.',
            'ListSavedLocations':'List current saved places. For a derived label or all alert settings, fetch GetSavedLocationWithGeofences for EACH returned id, even geofenceCount=0. List counts do not substitute for accepted detail sources.',
            'GetSavedLocationWithGeofences':'Read current place and ALL alert rules. For a derived location label, read EVERY id returned by ListSavedLocations, including zero-alert places. Include the required display fields declared in the parameter schema.',
        }
        value['description']=descriptions.get(tool['name'],value['description'])
    if revision>=3:
        schema=json.loads(value['inputSchemaJson']);schema['$comment']='Trusted DTO mapping '+mapping.pin
        if tool['name']=='GetLocationHistory':
            schema['description']+=' For approximate point labels, first read ListSavedLocations and details for EVERY returned ID, including zero-alert places. Keep all returned points; from/to describe the original observation window, not a frozen current clock.'
            value['description']='Read the historical seven-day trail, not current status. Keep timestamps, coordinates, coverage and battery. For approximate labels also read ListSavedLocations and details for EVERY id. Use GetLastKnownLocation for latest status.'
        elif tool['name']=='GetLastKnownLocation':
            value['description']='Read latest recorded status, coordinates, battery and recordedAt. For the approximate label also read ListSavedLocations and details for EVERY returned id, even with zero alerts. History is a separate trail; it cannot replace latest status.'
        value['inputSchemaJson']=json.dumps(schema,sort_keys=True,separators=(',',':'))
        value['mcp']['binding']['inputSchemaJson']=value['inputSchemaJson']
    if revision>=4:
        schema=json.loads(value['inputSchemaJson'])
        dependencies=([dict(sourceCapabilityRef='vf.ListSavedLocations',sourceField='id',sourceArgumentsJson='{}',
            readCapabilityRef='vf.GetSavedLocationWithGeofences',argumentField='savedLocationId')]
            if tool['name'] in {'GetLastKnownLocation','GetLocationHistory'} else [])
        schema['$comment']=json.dumps(dict(schema='agent-read-guidance/1',mappingPin=mapping.pin,
            prerequisites=dependencies),sort_keys=True,separators=(',',':'))
        value['inputSchemaJson']=json.dumps(schema,sort_keys=True,separators=(',',':'))
        value['mcp']['binding']['inputSchemaJson']=value['inputSchemaJson']
    validate_registration(value);return value


def register_preparations(value,namespace,host,runtime,operator,requests,broker,registration):
    journals=[]
    versions=[(tool,revision) for tool in PREPARATIONS
        for revision in ((1,2,3,4) if tool=='CreateGeofence' else (1,2,3) if tool=='UpdateGeofence' else (1,3))]
    for tool,revision in versions:
        capability=preparation_capability(tool,revision=revision)
        cap=base.CapabilityRegistrations(runtime.registry).register(value['application_id'],capability,operator)
        if revision==4:
            # Additive metadata only. Keep exactly the previously current v3
            # scope for existing accepted work, never re-enable older v1/v2.
            previous=host.preparation_pins.get(cap['ref'])
            if previous!=base.version_pin(preparation_capability(tool,revision=3)):
                raise ValueError('Exact prior preparation metadata required')
            host.preparation_compatibility_pins[cap['ref']]=(previous,)
        host.preparation_pins[cap['ref']]=cap
        preparation=dict(id='vf.preparation.'+tool+'/1',revision=revision,capability=cap,**namespace,
            hostDefinitionRef=registration['bots'][0]['id'],providerRef='vf.mcp',outputContract='AgentPreparedChange/1',adapterRef='typed.prepare/1')
        combined=dict(preparation=preparation,execution=dict(id='vf.preparation-work.'+tool+'/1',revision=revision,
            preparationProfile=base.version_pin(preparation),usageProfile='host-preparation-elapsed/1',externalInference=False,
            requestTimeoutMs=28000,maxResultBytes=65536))
        base.ToolPolicies(runtime.registry).register(value['application_id'],combined,operator)
        journals.append(base.ToolJournal(HostPreparationLane(requests,broker,preparation),combined))
    return journals


def register_reads(value,namespace,host,runtime,operator,requests,host_profile,tokens,*,host_transport=None,mcp_trust=None):
    journals=[];observers={};caps=[]
    async def host_token(*_):return host.bridge_key
    async def read_token(*_):return tokens[1]
    async def observation_token(*_):return tokens[2]
    policy=base.POCReadPolicy({**host_profile,'network':'owned-local-http/1','url':'http://127.0.0.1:'+str(value['policy_ports'][1])+
        '/v1/data/agentic_os_agent_read/decision'},read_token)
    observation_policy=base.POCObservationPolicy({**host_profile,'network':'owned-local-http/1','url':'http://127.0.0.1:'+str(value['policy_ports'][2])+
        '/v1/data/agentic_os_agent_observe/decision'},observation_token)
    for tool in host.contracts.tools.values():
        if not tool['annotations']['readOnlyHint']:continue
        revision=value.get('read_revision',1)
        mapping=FamilyReadMapping(tool,observed_history_window=revision>=3)
        capability=read_capability(tool,mapping,value['mcp_url'],revision=revision)
        capability['mcp']['connection']['network']=host_profile['network']
        cap=base.CapabilityRegistrations(runtime.registry).register(value['application_id'],capability,operator)
        read=dict(id='vf.wrapped-read.'+tool['name']+'/1',revision=revision,capability=cap,providerRef='vf.mcp',
            outputContract='EvidencePage/1',host={**host_profile,'url':value['host_origin']+'/host-bridge/agent/v1/read'},policy=base.bundle())
        execution=dict(id='vf.wrapped-execution.'+tool['name']+'/1',revision=revision,readProfile=base.version_pin(read),
            usageProfile='host-read-elapsed/1',externalInference=False,requestTimeoutMs=15000,maxResultBytes=131072)
        combined=dict(read=read,execution=execution)
        base.ToolPolicies(runtime.registry).register(value['application_id'],combined,operator)
        authority=base.RemoteReadAuthority(read['host'],host_token,network_transport=None if host_transport is None else host_transport())
        journal=base.ToolJournal(base.POCReadLane(requests,authority,policy,read,mapping=mapping,mcp_trust=mcp_trust),combined)
        observer=base.RemoteReadObservation({**host_profile,'url':value['host_origin']+'/host-bridge/agent/v1/observe'},
            host_token,read,observation_policy,bundle=base.bundle(True),
            network_transport=None if host_transport is None else host_transport())
        observers[tuple(base.version_pin(execution)[key] for key in ('ref','revision','digest'))]=observer
        host.register(cap,mapping,base.version_pin(read));journals.append(journal);caps.append(cap)
    return journals,observers,caps
