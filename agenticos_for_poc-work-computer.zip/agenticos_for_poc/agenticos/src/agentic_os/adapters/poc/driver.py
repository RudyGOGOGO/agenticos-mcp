"""Bounded fixed SDK processes over the canonical production outbox.

The sole additional SQL record binds a process epoch to an existing task and
dispatch. It has no independent task state, balance or completion authority.
"""
import asyncio
from copy import deepcopy
from pathlib import Path
from uuid import UUID, uuid4

from sqlalchemy import select, func

from agentic_os.adapters.postgres.models import DirectExecution, Dispatch, Task
from agentic_os.contracts.canonical import canonical_bytes, digest, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import namespace
from agentic_os.production.accounting import _bounds
from agentic_os.production.execution import DIRECT_PROFILE


def child_result(value,context):
    if (set(value)!={'schema','control','modelCalls','toolCalls','continuations','environment'}
            or value['schema']!='agent-direct-child-result/1'
            or any(value['control'][key]!=context[key] for key in ('taskId','rootId'))
            or type(value['modelCalls']) is not int or not 1<=value['modelCalls']<=8
            or type(value['toolCalls']) is not int or not 0<=value['toolCalls']<=16
            or type(value['continuations']) is not int or not 0<=value['continuations']<=32
            or value['environment']!=dict(mcp='1.30.0',corePackageVisible=False,temporalDriverImported=False)):
        raise ValueError('Invalid fixed SDK observation')
    contract={'agent-read-control/1':'AgentReadControl',
        'agent-memory-read-control/1':'AgentMemoryReadControl'}.get(value['control'].get('profile'),'AgentWorkflowControl')
    validate_contract(contract,value['control'])
    return value


class DirectRunner:
    profile = DIRECT_PROFILE

    def __init__(self, store, registry, *, sdk_python, child_configuration, maximum=2,slots=None):
        from .slots import ProcessSlots
        sdk_python=Path(sdk_python)
        if (not sdk_python.is_absolute() or not sdk_python.is_file()
                or not (sdk_python.parent.parent/'pyvenv.cfg').is_file()
                or not callable(child_configuration) or maximum != 2 or slots is not None and type(slots) is not ProcessSlots):
            raise ValueError('Fixed separate SDK environment and credential composition required')
        self.store,self.registry=store,registry
        self.sdk_python,self.child_configuration=str(sdk_python),child_configuration
        self.maximum=maximum
        existing=getattr(registry,'_poc_process_slots',None)
        if slots is not None and existing is not None and existing is not slots:
            raise ValueError('One shared two-slot Core placement required')
        self.slots=slots if slots is not None else existing if existing is not None else ProcessSlots()
        registry._poc_process_slots=self.slots
        self.instance=uuid4()
        self.children={}
        self.controls={}
        self.channel_stats={}
        self._accepting=False
        self._launch_lock=asyncio.Lock()
        self._installation_lock=None

    @staticmethod
    def execution_id(launch):
        return 'os-direct:'+':'.join(str(UUID(launch[key])) for key in
            ('installationId','applicationId','taskId'))

    def ready(self):
        return self._accepting

    def recover_abandoned(self):
        # No model restart or dispatch retry follows an abandoned
        # process; its original accounting/uncertain effects remain untouched.
        from agentic_os.adapters.local.resources import file_lock
        if self._installation_lock is not None:
            raise OSErrorCode('CONFLICT')
        lock=file_lock(Path(self.store.manifest).parent/'direct-runner.lock',timeout=0)
        lock.__enter__()
        self._installation_lock=lock
        with self.store.transaction() as db:
            _bounds(db)
            rows=db.scalars(select(DirectExecution).where(
                DirectExecution.installation_id==self.registry.installation_id,
                DirectExecution.state.in_(['STARTING','RUNNING'])).with_for_update()).all()
            for row in rows:
                row.state='INTERRUPTED'
        self._accepting=True
        return len(rows)

    def _allocate(self, execution_id, payload, deadline_seconds):
        context=payload['start']['context']
        if (context['subject']['installationId']!=str(self.registry.installation_id)
                or self.execution_id(dict(**context['subject'],taskId=context['taskId']))!=execution_id):
            raise OSErrorCode('DENIED')
        fingerprint=digest('command',payload)
        with self.store.transaction() as db:
            _bounds(db)
            now=db.scalar(select(func.clock_timestamp()))
            row=db.scalar(select(Dispatch).where(Dispatch.task_id==UUID(context['taskId']),
                Dispatch.installation_id==self.registry.installation_id,
                Dispatch.workflow_profile==self.profile,Dispatch.workflow_id==execution_id).with_for_update())
            prior=db.scalar(select(DirectExecution).where(DirectExecution.task_id==UUID(context['taskId'])))
            if prior is not None:
                if prior.execution_id!=execution_id or prior.payload_digest!=fingerprint:
                    raise OSErrorCode('CONFLICT')
                return str(prior.id),None
            task=db.get(Task,UUID(context['taskId']))
            if (row is None or row.state!='LEASED' or row.lease_until<=now or task is None
                    or task.deadline<=now or deadline_seconds>(task.deadline-now).total_seconds()+1):
                raise OSErrorCode('DENIED')
            binding=DirectExecution(**namespace(context['subject']),id=uuid4(),task_id=task.id,
                dispatch_id=row.id,execution_id=execution_id,epoch=uuid4(),owner_instance=self.instance,
                payload_digest=fingerprint,state='STARTING',started_at=now,deadline=task.deadline)
            db.add(binding)
            return str(binding.id),str(binding.epoch)

    def _state(self, binding_id, state):
        with self.store.transaction() as db:
            _bounds(db)
            binding=db.scalar(select(DirectExecution).where(DirectExecution.id==UUID(binding_id),
                DirectExecution.installation_id==self.registry.installation_id,
                DirectExecution.owner_instance==self.instance).with_for_update())
            if binding is not None and binding.state=='INTERRUPTED':
                return False
            if binding is None or binding.state not in {'STARTING','RUNNING'}:
                raise OSErrorCode('DENIED')
            binding.state=state
            return True

    async def submit(self, execution_id, payload, *, deadline_seconds):
        if (not self.ready() or type(deadline_seconds) is not int or not 1<=deadline_seconds<=604800
                or payload.get('schema') not in {'agent-read-journey/1','agent-reviewed-change-journey/1',
                    'agent-contextual-lookup-read-journey/2','agent-contextual-lookup-read-journey/1','agent-lookup-read-journey/1','agent-discovered-read-journey/1','agent-capability-read-journey/1',
                    'agent-memory-read-journey/1','agent-memory-response-journey/1'}
                or payload.get('schema')=='agent-reviewed-change-journey/1'
                    and payload['start']['context']['harness']['ref']!='agent-sdk-reviewed-change/1'):
            raise OSErrorCode('PROFILE_DISABLED')
        async with self._launch_lock:
            if not self.ready() or len(self.children)>=self.maximum:
                raise OSErrorCode('CAPACITY')
            slot=await self.slots.acquire()
            try:binding_id,epoch=await asyncio.to_thread(self._allocate,execution_id,payload,deadline_seconds)
            except BaseException:
                await self.slots.release(slot)
                raise
            if epoch is None:
                # Idempotent transport delivery observes the original binding,
                # including INTERRUPTED. It never starts another SDK process.
                await self.slots.release(slot)
                return binding_id
            try:
                configuration=await self.child_configuration(deepcopy(payload),execution_id,epoch)
                raw=canonical_bytes(configuration)+b'\n'
                if len(raw)>1024*1024:
                    raise OSErrorCode('CAPACITY')
                await asyncio.to_thread(self._state,binding_id,'RUNNING')
                child=await asyncio.create_subprocess_exec(self.sdk_python,'-I','-m',
                    'agentic_os_agent_worker.direct_driver',stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,
                    env={'PATH':'/usr/bin:/bin','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1',
                        'OPENAI_AGENTS_DISABLE_TRACING':'1'},start_new_session=True,limit=16385)
                self.channel_stats[execution_id]=dict(statusFrames=0,resumeCommands=0)
                observer=asyncio.create_task(self._observe(execution_id,binding_id,child,raw,deadline_seconds,payload['start']['context'],slot))
                self.children[execution_id]=(binding_id,child,observer)
                return binding_id
            except BaseException:
                try:await asyncio.to_thread(self._state,binding_id,'INTERRUPTED')
                finally:await self.slots.release(slot)
                raise

    async def _exchange(self,execution_id,child,raw,context):
        async def frames():
            child.stdin.write(raw);await child.stdin.drain()
            result=None;count=0
            while line:=await child.stdout.readline():
                count+=1
                if count>128 or len(line)>16384 or not line.endswith(b'\n'):
                    raise ValueError('Bounded fixed SDK frame required')
                value=parse_canonical_json(line)
                if value.get('schema')=='agent-direct-status/1':
                    if result is not None or set(value)!={'schema','control'}:raise ValueError('Unexpected SDK status')
                    control=value['control'];validate_contract('AgentWorkflowControl',control)
                    if (any(control[key]!=context[key] for key in ('rootId','taskId'))
                            or control['status'] in {'claim','resume','stop','running'}):
                        raise ValueError('Foreign or executable SDK status')
                    self.controls[execution_id]=dict(sequence=count,control=deepcopy(control))
                    self.channel_stats[execution_id]['statusFrames']+=1
                    import logging
                    logging.getLogger(__name__).warning('Direct child wait observed: task=%s status=%s',context['taskId'],control['status'])
                elif result is None:
                    result=child_result(value,context)
                else:raise ValueError('Repeated SDK final result')
            return result
        async def diagnostic():
            value=bytearray()
            while chunk:=await child.stderr.read(1024):
                value.extend(chunk)
                if len(value)>8192:raise ValueError('Bounded SDK diagnostic required')
            return bytes(value)
        tasks=[asyncio.create_task(frames()),asyncio.create_task(diagnostic())]
        try:
            result,error=await asyncio.gather(*tasks)
            await child.wait()
            return result,error
        finally:
            for task in tasks:
                if not task.done():task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)

    @staticmethod
    async def _stop_child(child):
        if child.returncode is not None:return
        try:child.terminate()
        except ProcessLookupError:pass
        try:await asyncio.wait_for(child.wait(),5)
        except TimeoutError:
            try:child.kill()
            except ProcessLookupError:pass
            await child.wait()

    async def _observe(self, execution_id, binding_id, child, raw, deadline_seconds, context, slot):
        import logging
        result=None;error=b'';valid=False
        try:
            try:
                result,error=await asyncio.wait_for(self._exchange(execution_id,child,raw,context),deadline_seconds+1)
                valid=child.returncode==0 and not error and result is not None
            except Exception as failure:
                # Types only: transport exceptions can include private input.
                logging.getLogger(__name__).error('Fixed SDK channel failed: %s',type(failure).__name__)
            # EXITED is process observation only. Canonical publication/task
            # records, never stdout or this state, establish user completion.
            applied=await asyncio.to_thread(self._state,binding_id,'EXITED' if valid else 'INTERRUPTED')
            if not valid:await self._stop_child(child)
            if not valid:
                # Fixed trusted child diagnostics contain only exception types,
                # codes and source locations, never inputs or exception args.
                diagnostic=None
                if 0<len(error)<=8192:
                    try:
                        candidate=parse_canonical_json(error)
                        if (set(candidate)=={'schema','error','code','locations'}
                                and candidate['schema']=='agent-direct-diagnostic/1'):
                            diagnostic=candidate
                    except ValueError:pass
                logging.getLogger(__name__).error('Fixed SDK stopped without accepted process result: exit=%s diagnostic=%r',
                    child.returncode,diagnostic)
            if valid:
                from agentic_os.adapters.local.files import private_directory,private_write,check_private
                folder=Path(self.store.manifest).parent/'direct-observations'
                if not folder.exists():private_directory(folder)
                check_private(folder,directory=True)
                private_write(folder/(binding_id+'.json'),canonical_bytes(dict(schema='poc-process-observation/1',
                    executionId=execution_id,bindingId=binding_id,stateUpdateApplied=applied,processResult=result,
                    channel=deepcopy(self.channel_stats[execution_id]),
                    authority='process observation only; canonical task/publication records own completion')))
        except asyncio.CancelledError:
            await asyncio.to_thread(self._state,binding_id,'INTERRUPTED')
            await self._stop_child(child)
            raise
        finally:
            # Capacity is returned only after the physical child has exited,
            # including when a bookkeeping/database observation fails.
            await self._stop_child(child)
            if child.stdin is not None:child.stdin.close()
            self.controls.pop(execution_id,None)
            self.channel_stats.pop(execution_id,None)
            self.children.pop(execution_id,None)
            await self.slots.release(slot)

    async def status(self,context):
        execution_id=self.execution_id(dict(**context['subject'],taskId=context['taskId']))
        if execution_id not in self.children:raise OSErrorCode('NOT_FOUND')
        value=self.controls.get(execution_id)
        return deepcopy(value['control']) if value else dict(profile='agent-control/1',rootId=context['rootId'],
            taskId=context['taskId'],operationId=None,status='running',notBefore=None)

    def _terminal_children(self, executions):
        from agentic_os.presentation.service import TERMINAL
        with self.store.transaction() as db:
            _bounds(db)
            rows=db.execute(select(DirectExecution,Task).join(Task,Task.id==DirectExecution.task_id).where(
                DirectExecution.installation_id==self.registry.installation_id,
                DirectExecution.owner_instance==self.instance,
                DirectExecution.execution_id.in_(executions),DirectExecution.state.in_(['STARTING','RUNNING']),
                Task.state.in_(TERMINAL))).all()
            return [dict(bindingId=str(binding.id),executionId=binding.execution_id,
                control=dict(profile='agent-control/1',rootId=str(task.budget_root_id),taskId=str(task.id),
                    operationId=None,status='stop',notBefore=None)) for binding,task in rows]

    async def stop_terminal(self):
        """Join an original terminal task's child without changing accounting.

        A rejected review can close its Root before the waiting SDK makes its
        next private RPC. Terminal tasks are absent from controller.pending().
        The existing stop frame wakes that bounded wait; it grants no call or
        resume authority, including after expiry or with unresolved usage.
        """
        if not self.children:return 0
        selected=await asyncio.to_thread(self._terminal_children,tuple(self.children))
        stopped=0
        for value in selected:
            execution_id=value['executionId'];current=self.children.get(execution_id)
            if current is None or current[0]!=value['bindingId']:continue
            binding_id,child,observer=current
            validate_contract('AgentWorkflowControl',value['control'])
            try:
                if child.returncode is None and child.stdin is not None and not child.stdin.is_closing():
                    child.stdin.write(canonical_bytes(dict(schema='agent-direct-command/1',control=value['control']))+b'\n')
                    self.channel_stats[execution_id]['terminalStopCommands']=1
                    await asyncio.wait_for(child.stdin.drain(),.5)
                await asyncio.wait_for(asyncio.shield(observer),2)
            except (TimeoutError,BrokenPipeError,ConnectionResetError):
                # The original owned process is joined through the existing
                # physical cancellation path. No Root/work/UNKNOWN is settled.
                await self.cancel(execution_id)
            stopped+=1
        return stopped

    def _control_binding(self,binding_id,context):
        from agentic_os.adapters.postgres.models import TaskControl
        with self.store.transaction() as db:
            _bounds(db)
            row=db.get(DirectExecution,UUID(binding_id));task=db.get(Task,UUID(context['taskId']))
            control=db.scalar(select(TaskControl).where(TaskControl.task_id==task.id)) if task else None
            if (row is None or task is None or row.owner_instance!=self.instance or row.state!='RUNNING' or row.task_id!=task.id
                    or task.budget_root_id!=UUID(context['rootId'])
                    or str(row.installation_id)!=context['subject']['installationId']
                    or str(row.application_id)!=context['subject']['applicationId']
                    or row.tenant_id!=context['subject']['tenantId'] or row.subject_id!=context['subject']['subjectId']
                    or row.deadline!=task.deadline or task.deadline<=db.scalar(select(func.clock_timestamp()))
                    or control is None or control.state!='ACTIVE' or control.epoch!=context['controlEpoch']):
                raise OSErrorCode('DENIED')

    async def resume(self,context,operation_id):
        execution_id=self.execution_id(dict(**context['subject'],taskId=context['taskId']))
        child_entry=self.children.get(execution_id);pending=self.controls.get(execution_id)
        if (not self.ready() or child_entry is None or pending is None or pending['control']['operationId']!=operation_id
                or operation_id is None or pending['control']['status'] not in {
                    'waiting-reconciliation','waiting-resources','waiting-provider'}):raise OSErrorCode('DENIED')
        binding_id,child,_=child_entry
        await asyncio.to_thread(self._control_binding,binding_id,context)
        control=dict(profile='agent-control/1',rootId=context['rootId'],taskId=context['taskId'],operationId=operation_id,
            status='resume',notBefore=None)
        validate_contract('AgentWorkflowControl',control)
        child.stdin.write(canonical_bytes(dict(schema='agent-direct-command/1',control=control))+b'\n')
        self.channel_stats[execution_id]['resumeCommands']+=1
        await child.stdin.drain()
        if self.controls.get(execution_id)==pending:self.controls.pop(execution_id,None)

    async def inspect(self, execution_id):
        def read():
            with self.store.transaction() as db:
                _bounds(db)
                row=db.scalar(select(DirectExecution).where(
                    DirectExecution.installation_id==self.registry.installation_id,
                    DirectExecution.execution_id==execution_id))
                if row is None:
                    raise OSErrorCode('NOT_FOUND')
                return dict(executionId=row.execution_id,profile=self.profile,state=row.state,
                    bindingId=str(row.id),epoch=str(row.epoch))
        return await asyncio.to_thread(read)

    async def cancel(self, execution_id):
        value=self.children.get(execution_id)
        if value is None:
            await self.inspect(execution_id)
            return
        binding_id,child,observer=value
        await asyncio.to_thread(self._state,binding_id,'INTERRUPTED')
        await self._stop_child(child)
        try:
            await asyncio.wait_for(asyncio.shield(observer),5)
        except TimeoutError:
            if child.returncode is None:
                child.kill()
            await observer

    async def close(self):
        self._accepting=False
        try:
            await asyncio.gather(*(self.cancel(key) for key in tuple(self.children)))
        finally:
            if self._installation_lock is not None:
                self._installation_lock.__exit__(None,None,None)
                self._installation_lock=None
