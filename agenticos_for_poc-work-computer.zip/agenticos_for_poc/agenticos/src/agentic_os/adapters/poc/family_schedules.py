"""One finite scheduled VF read over the existing canonical proactive lane.

The public Java catalog stays unchanged. This application-owned DTO wrapper
performs one declared read, with the original delegation and current Host/OPA
checks before and after it. It creates no task, effect or completion journal.
"""
import asyncio
from copy import deepcopy
from datetime import timedelta
from uuid import uuid4

from agentic_os.contracts.canonical import digest
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import iso,utcnow
from agentic_os.scheduling.authority import ProactiveAuthority
from agentic_os.scheduling.catalog import WorkflowCatalog
from .family_composition import FamilyHostBridge
from .family_mapping import FamilyReadMapping

CAPABILITY='vf.scheduled.last-known/1'
BOT='vf.scheduled-reader/1'
TOOL='GetLastKnownLocation'
DESCRIPTOR=dict(id=CAPABILITY,revision=1,inputSchemaRef='ReadToolArguments',outputSchemaRef='EvidencePage',
    originRef='vf.mcp',kind='read',riskFloor='low',scopeResolverRef='vf.current-owner',timeoutMs=15000,
    guaranteeProfile='current-read/1')


def registration(bundle):
    value=deepcopy(bundle);value['application']['revision']+=1
    value['application']['lanes']=sorted(set(value['application']['lanes'])|{'durable-delegation','event-triggering'})
    value['capabilities'].append(dict(descriptor=deepcopy(DESCRIPTOR),connectorRef='vf.connector',toolName=TOOL,
        inputContract='ReadToolArguments',outputContract='EvidencePage'))
    value['connectors'][0]['capabilityRefs'].append(CAPABILITY)
    value['bots'].append(dict(id=BOT,revision=1,promptRef='vf.scheduled-recorded-status/1',modelProfile='deterministic/1',
        capabilityCeiling=[CAPABILITY],budget=dict(maxStages=1,maxChildren=0,maxTokens=1,maxToolCalls=1,
            maxNativeJobs=0,deadlineMs=120000),kbProfile='public/1',enabled=True))
    value['application']['catalogHash']=digest('manifest',[item['descriptor'] for item in value['capabilities']])
    value['application']['schemaHash']=digest('manifest',[bundle['application']['schemaHash'],'ReadToolArguments/1'])
    validate_contract('HostRegistration',value);return value


def project(mapping,document,subject,arguments):
    validate_contract('ReadToolArguments',arguments)
    if (mapping.tool!=TOOL or arguments['resourceType']!=mapping.resource_type
            or len(arguments['externalIds'])!=1 or not arguments['fieldNames']
            or not set(arguments['fieldNames'])<=set(mapping.fields)):
        raise OSErrorCode('DENIED')
    page=mapping.page(document,subject)
    if any(resource['externalId'] not in arguments['externalIds'] for resource in page['evidence']['resourceRefs']):
        raise OSErrorCode('DENIED')
    selected=set(arguments['fieldNames'])
    page['records']=[[field for field in row if field['name'] in selected] for row in page['records']]
    evidence=page['evidence'];evidence['publicFields']=[field for field in mapping.fields if field in selected]
    evidence['coreDigest']=digest('evidence',dict(evidence={k:v for k,v in evidence.items() if k!='coreDigest'},records=page['records']))
    validate_contract('EvidencePage',page);return page


class FamilyScheduledHost(FamilyHostBridge):
    def __init__(self,**options):
        super().__init__(**options)
        self.scheduled_mapping=FamilyReadMapping(self.contracts.tools[TOOL])

    async def dispatch(self,action,body):
        if action=='capabilities':
            result=await super().dispatch(action,body)
            if TOOL in self.control(body['subject'])['tools']:result['capabilities'].append(deepcopy(DESCRIPTOR))
            return result
        if body.get('capabilityRef')!=CAPABILITY:return await super().dispatch(action,body)
        subject=body['subject'];control=self.control(subject)
        if TOOL not in control['tools'] or body.get('purpose')!='assistant.read':raise OSErrorCode('DENIED')
        now=utcnow();until=iso(now+timedelta(seconds=15))
        if action=='authority/check':
            if body['delegationRef'] is not None:raise OSErrorCode('DENIED')
            return dict(id=str(uuid4()),subject=subject,active=True,policyGeneration=control['policyGeneration'],
                capabilityRefs=[CAPABILITY],resourceBounds=[dict(resourceType=self.scheduled_mapping.resource_type,
                    externalIds=control['memberIds'],fieldNames=list(self.scheduled_mapping.fields))],purpose='assistant.read',
                checkedAt=iso(now),validUntil=until,assuranceRef=self.authority_profile,delegationRef=None)
        if action=='credentials/issue':
            if body['endpointRef']!='vf.mcp':raise OSErrorCode('DENIED')
            return dict(accessToken=self.credential(subject,TOOL,until),audienceRef='vf.mcp',subject=subject,
                capabilityRef=CAPABILITY,expiresAt=until)
        raise OSErrorCode('NOT_FOUND')


class FamilyScheduleSource:
    def __init__(self,runtime,host):self.runtime,self.host,self.mapping=runtime,host,host.scheduled_mapping

    async def read(self,subject,configuration,authority,*,before_execute=None):
        arguments=configuration['arguments'];validate_contract('ReadToolArguments',arguments)
        if configuration['capabilityRef']!=CAPABILITY:raise OSErrorCode('PROFILE_DISABLED')
        # Validate the finite selection before any credential/provider access.
        if (arguments['resourceType']!=self.mapping.resource_type or len(arguments['externalIds'])!=1
                or not arguments['fieldNames'] or not set(arguments['fieldNames'])<=set(self.mapping.fields)):
            raise OSErrorCode('DENIED')
        bridge=await asyncio.to_thread(self.runtime.bridges.for_application,subject['applicationId'])
        credential=await bridge.credential(subject,'vf.mcp',CAPABILITY,'assistant.read',authority['id'])
        descriptors=await self.host.mcp.request(credential['accessToken'])
        if self.mapping.descriptor not in descriptors:raise OSErrorCode('PROFILE_DISABLED')
        if before_execute is not None:await before_execute()
        document=await self.host.mcp.request(credential['accessToken'],tool=TOOL,
            arguments=dict(memberId=arguments['externalIds'][0]))
        return project(self.mapping,document,subject,arguments)


class FamilyScheduleAuthority(ProactiveAuthority):
    def __init__(self,service,source):super().__init__(service);self.source=source

    async def read(self,principal,*,before_execute=None):
        application=principal.subject['applicationId']
        if application not in self.host_bulkheads:self.host_bulkheads[application]=asyncio.Semaphore(2)
        async with asyncio.timeout(15),self.host_bulkheads[application],self.bulkhead:
            admitted=await self.current(principal)
            configuration=admitted['material']['configuration']
            page=await self.source.read(principal.subject,configuration,admitted['authority'],before_execute=before_execute)
            self.validate_output(page,principal.subject,configuration['arguments'],admitted['binding']['capability'],admitted['authority'])
            await self.current(principal)
            return page


class FamilyScheduleCatalog(WorkflowCatalog):
    def __init__(self,runtime,source):
        super().__init__(runtime,workflow_refs={'registered-read/1'},event_sources=False);self.source=source

    async def verify(self,actor,configuration):
        binding=await asyncio.to_thread(self.binding,actor.subject,configuration)
        admitted=await self.runtime.broker.admit(actor,configuration['capabilityRef'],configuration['definitionRef'],
            arguments=configuration['arguments'],with_transport=False)
        page=await self.source.read(actor.subject,configuration,admitted[2])
        ProactiveAuthority.validate_output(page,actor.subject,configuration['arguments'],binding['capability'],admitted[2])
        await self.runtime.broker.admit(actor,configuration['capabilityRef'],configuration['definitionRef'],
            arguments=configuration['arguments'],with_transport=False)
        return binding,self.verification(binding,configuration)


def enable(runtime,host,*,demo=False,configured=False):
    driver=runtime.enable_direct_schedules(local_synthetic=not configured,configured=configured,demo=demo)
    source=FamilyScheduleSource(runtime,host);service=runtime.schedules
    service.catalog=FamilyScheduleCatalog(runtime,source);service.authority=FamilyScheduleAuthority(service,source)
    return driver
