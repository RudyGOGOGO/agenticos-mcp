"""Exact external arguments signed only from live production reviewed permits.

No transport retry, receipt, grant or task journal is introduced here. The
existing permit service authenticates the disjoint provider introspection
credential and rechecks current owner/source/approval/running work. Only its
current material can reach the private RSA signer.
"""
from copy import deepcopy
from decimal import Decimal,InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import time
from uuid import UUID

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey,RSAPublicKey
import jwt

from agentic_os.adapters.local.files import private_read
from agentic_os.contracts.canonical import digest,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.effects.reviewed_permit import ReviewedPermitService
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import timestamp
from .external_json import external_sha256,validate_external


TOOLS_SHA256='47769c9b308ed581c4e678fe569ad17e5b5a5ad0e9ac9cd4d984e0851225cf8e'
CONTEXT_SHA256='62a17d05838a7bc5b6ba9af41c2532a994192720180c141b25f14dfdf940f8e8'
UPDATES={'UpdateSavedLocation','UpdateGeofence'}
MUTATIONS=UPDATES|{'CreateSavedLocation','CreateGeofence'}


class EffectContracts:
    def __init__(self,root):
        root=Path(root)
        def read(name,expected):
            path=root/name
            if path.is_symlink() or not path.is_file() or path.stat().st_size>1024*1024:raise ValueError('Bounded committed contracts required')
            raw=path.read_bytes()
            if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Unreviewed external contract')
            return json.loads(raw)
        self.tools={value['name']:value for value in read('tools.json',TOOLS_SHA256)['tools']}
        self.context=read('effect-context.schema.json',CONTEXT_SHA256)


class EffectArguments:
    """Operator-pinned form mapping; no model may supply mapping authority.

    Field aliases support an application's existing registered form. Resource
    IDs come only from the approved canonical target. A geofence update uses
    an exact canonical JSON pair as its externalId, avoiding delimiter guesses.
    No defaults or unchanged fields are silently added.
    """
    def __init__(self,contracts,*,tool,capability_ref,provider_ref,resource_type,schema_digest,field_map):
        if (type(contracts) is not EffectContracts or tool not in MUTATIONS
                or any(type(value) is not str or not 1<=len(value)<=256 for value in (capability_ref,provider_ref,resource_type))
                or type(schema_digest) is not str or re.fullmatch('[a-f0-9]{64}',schema_digest) is None
                or type(field_map) is not dict or not 1<=len(field_map)<=64
                or any(type(key) is not str or type(value) is not str or not 1<=len(value)<=256 for key,value in field_map.items())
                or len(set(field_map.values()))!=len(field_map)):
            raise ValueError('Explicit reviewed effect mapping required')
        self.contracts,self.tool=contracts,tool
        self.capability_ref,self.provider_ref,self.resource_type=capability_ref,provider_ref,resource_type
        self.schema_digest,self.field_map=schema_digest,deepcopy(field_map)
        self.schema=deepcopy(contracts.tools[tool]['inputSchema'])
        ids={'savedLocationId'} if tool=='UpdateSavedLocation' else {'savedLocationId','geofenceId'} if tool=='UpdateGeofence' else set()
        if not set(field_map)<=set(self.schema['properties'])-ids:raise ValueError('Fields must match the public tool schema')

    def project(self,proposal,binding):
        validate_contract('Proposal',proposal)
        intent=proposal['intent'];targets=intent['targets']
        if (binding['capabilityRef']!=self.capability_ref or binding['providerRef']!=self.provider_ref
                or binding['schemaDigest']!=self.schema_digest or len(targets)!=1
                or proposal['expectedVersions']!=targets
                or targets[0]['resourceType']!=self.resource_type or targets[0]['providerId']!=self.provider_ref
                or intent['operation']!=('update' if self.tool in UPDATES else 'create')):
            raise OSErrorCode('DENIED')
        inverse={source:target for target,source in self.field_map.items()};arguments={}
        for field in intent['fields']:
            target=inverse.get(field['name'])
            if target is None or target in arguments:raise OSErrorCode('DENIED')
            value=field['value'];schema=self.schema['properties'][target]
            if schema.get('type')=='number' and type(value) is str:
                # Canonical form preparation must already normalize decimal
                # presentation. Signing cannot silently round owner values.
                try:
                    decimal=Decimal(value);number=float(decimal)
                    if Decimal(str(number))!=decimal:raise ValueError()
                    value=number
                except (ValueError,OverflowError,InvalidOperation):raise OSErrorCode('INVALID') from None
            arguments[target]=value
        resource=targets[0];revision=None
        if self.tool in UPDATES:
            version=resource['observedVersion']
            if re.fullmatch('[1-9][0-9]{0,15}',version) is None or int(version)>9007199254740991:raise OSErrorCode('DENIED')
            revision=int(version)
            if self.tool=='UpdateSavedLocation':arguments['savedLocationId']=resource['externalId']
            else:
                try:ids=parse_canonical_json(resource['externalId'])
                except ValueError:raise OSErrorCode('DENIED') from None
                if type(ids) is not dict or set(ids)!={'savedLocationId','geofenceId'}:raise OSErrorCode('DENIED')
                arguments.update(ids)
        validate_external(self.schema,arguments)
        return arguments,revision


class MCPBearerVerifier:
    """Pinned actual bearer verification, with explicit local/AWS selection."""
    def __init__(self,*,target,key,algorithm,issuer,key_id,core_namespace,wire_namespace):
        if (target not in {'local-synthetic','aws'} or algorithm not in {'HS256','RS256'}
                or target=='aws' and (algorithm!='RS256' or not key_id)
                or algorithm=='RS256' and (not isinstance(key,RSAPublicKey) or key.key_size<2048)
                or algorithm=='HS256' and (type(key) is not bytes or len(key)<32)
                or type(issuer) is not str or not 1<=len(issuer)<=256
                or key_id is not None and (type(key_id) is not str or not 1<=len(key_id)<=256)
                or set(core_namespace)!={'installationId','applicationId'}
                or any(str(UUID(value))!=value for value in core_namespace.values())
                or set(wire_namespace)!={'client_id','installation','application','environment'}
                or any(type(value) is not str or not 1<=len(value)<=256 for value in wire_namespace.values())
                or target=='aws' and (issuer=='vf-poc-local' or wire_namespace['environment']=='local')):
            raise ValueError('Approved explicit bearer trust and namespaces required')
        self.key,self.algorithm,self.issuer,self.key_id=key,algorithm,issuer,key_id
        self.core_namespace,self.wire_namespace=deepcopy(core_namespace),deepcopy(wire_namespace)

    def verify(self,token,subject,tool):
        if type(token) is not str or not 1<=len(token)<=16384:raise OSErrorCode('UNAUTHENTICATED')
        try:
            header=jwt.get_unverified_header(token)
            if (set(header)-{'alg','typ','kid'} or header.get('alg')!=self.algorithm
                    or header.get('typ')!='JWT' or header.get('kid')!=self.key_id):raise ValueError()
            value=jwt.decode(token,self.key,algorithms=[self.algorithm],issuer=self.issuer,audience='vf-mcp',
                options=dict(require=['iss','aud','sub','client_id','installation','application','environment','tools','iat','exp']))
            if (any(subject[key]!=expected for key,expected in self.core_namespace.items())
                    or value['sub']!=subject['subjectId'] or value['aud']!=['vf-mcp']
                    or any(value[key]!=expected for key,expected in self.wire_namespace.items())
                    or type(value['iat']) is not int or type(value['exp']) is not int or not 0<value['exp']-value['iat']<=900
                    or type(value['tools']) is not list or not 1<=len(value['tools'])<=9
                    or any(type(item) is not str for item in value['tools'])
                    or len(set(value['tools']))!=len(value['tools']) or tool not in value['tools']):raise ValueError()
            return {key:deepcopy(value[key]) for key in ('sub','client_id','installation','application','environment','exp')}
        except (jwt.PyJWTError,ValueError,TypeError,KeyError):raise OSErrorCode('DENIED') from None


class EffectContextSigner:
    def __init__(self,permits,contracts,*,mapping,bearer_verifier,key_file,issuer,key_id,local_access=None):
        if (type(permits) is not ReviewedPermitService or not permits.production or type(contracts) is not EffectContracts
                or type(mapping) is not EffectArguments or mapping.contracts is not contracts
                or type(bearer_verifier) is not MCPBearerVerifier
                or any(type(value) is not str or not 1<=len(value)<=256 for value in (issuer,key_id))):
            raise ValueError('Canonical production permit service and fixed trusted signer required')
        key=serialization.load_pem_private_key(private_read(Path(key_file),16384),password=None)
        if not isinstance(key,RSAPrivateKey) or key.key_size<2048:raise ValueError('Pinned RSA signing identity required')
        self.permits,self.contracts,self.mapping=permits,contracts,mapping
        self.bearer_verifier,self._key,self.issuer,self.key_id=bearer_verifier,key,issuer,key_id
        if local_access is not None:
            from .local_synthetic_access import LocalNativeAccess
            if type(local_access) is not LocalNativeAccess or bearer_verifier.algorithm!='HS256':
                raise ValueError('Explicit local-only native effect fence required')
        self.local_access=local_access

    async def sign(self,introspection_credential,request,*,bearer_token):
        # No arguments/grant/operation/key parameter exists for the model or
        # caller to substitute. All business identity comes from current SQL.
        status,material,binding=await self.permits._validated(introspection_credential,request)
        if material is None or binding is None:raise OSErrorCode('PROFILE_DISABLED')
        grant=material['grant'];proposal=material['proposal']
        if (grant['profileRef'] not in {'agent-reviewed-effect/1','agent-oidc-reviewed-effect/1'}
                or grant['proposalDigest']!=proposal['digest'] or digest('proposal',{key:value for key,value in proposal.items() if key!='digest'})!=proposal['digest']):
            raise OSErrorCode('DENIED')
        identity=self.bearer_verifier.verify(bearer_token,grant['subject'],self.mapping.tool)
        if self.local_access is not None:await self.local_access.check_effect(material['context'],bearer_token)
        arguments,revision=self.mapping.project(proposal,binding)
        now=int(time.time());until=min(identity.pop('exp'),int(timestamp(status['expiresAt']).timestamp()),
            int(timestamp(material['context']['authorizationHorizon']).timestamp()),now+300)
        if until<=now:raise OSErrorCode('DENIED')
        # UUIDs are the existing canonical business invocation. They remain
        # stable across observation/recovery and never come from model output.
        invocation=str(UUID(grant['invocationId']))
        claims=dict(schema='EffectCallContext/1',iss=self.issuer,aud=['vf-mcp'],**identity,
            operationId=invocation,idempotencyKey=invocation,tool=self.mapping.tool,
            descriptorRevision='vf-tools/1',mappingRevision='vf-api/1',argumentsSha256=external_sha256(arguments),
            expectedRevision=revision,iat=now,exp=until)
        validate_external(self.contracts.context,claims)
        token=jwt.encode(claims,self._key,algorithm='RS256',headers=dict(typ='agenticos-effect+jwt',kid=self.key_id))
        return dict(tool=self.mapping.tool,arguments=arguments,effect_context=token)
