"""Explicit finite initial direct POC release using the existing owner gate.

This profile cannot qualify Temporal, embedding, native or restored execution.
It creates no resources, workload, alternate journal or funding authority.
"""
import asyncio
from contextlib import contextmanager
from dataclasses import dataclass
from copy import deepcopy
from pathlib import Path
import re
import time
from types import SimpleNamespace

from agentic_os.adapters.aws import readiness
from agentic_os.adapters.configured_installation import closed,configured_installation
from agentic_os.adapters.local.files import OwnershipError,check_private,private_read
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.resources import file_lock,read_signed,write_signed
from agentic_os.adapters.local import recovery_gate as gate
from agentic_os.adapters.postgres.profiles import RDS_EXACT
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.production.execution import DIRECT_PROFILE

CONTROL='poc-direct-control/1'
CONFIGURATION='poc-direct-initial-readiness/1'
PROFILE='poc-direct-initial-control-release/1'
CHECKS={'schemas','runtimeRoles','privateMaterials','emptyInstallation'}
FEATURES=dict(execution=DIRECT_PROFILE,memory='structured-keyword',schedules='OSDuePoll/1',
    temporal=False,embedding=False,native=False)
FIELDS={'profile','installationId','runId','generation','installationDigest','releaseDigest',
    'materialsDigest','contentDigest','issuedAt','expiresAt','checks','features'}


def configuration(document):
    try:
        closed(document,{'schema','stores','release_seconds'})
        if document['schema']!=CONFIGURATION:raise ValueError()
        stores=readiness.storage.configuration(document['stores']);readiness.storage.plan(document['stores'])
        aws=stores['installation']['aws']
        if (aws.get('control_profile')!=CONTROL or aws['role']!='core'
                or aws.get('storage_profile')!=RDS_EXACT
                or any(stores['expected_heads'][name]!=readiness.storage.component_head(name,stores['installation'])
                    for name in readiness.storage.COMPONENTS)
                or type(document['release_seconds']) is not int or not 60<=document['release_seconds']<=86400):raise ValueError()
        if load_manifest(stores['installation']['manifest'])['profile']!='aws-eks/1':raise ValueError()
        return stores
    except Exception:raise OwnershipError('Explicit direct POC readiness configuration required') from None


def load_configuration(path):
    document=parse_canonical_json(private_read(path,65536));configuration(document);return document


def _fresh(path):
    # The same initial proof file is exclusive with all restored ancestry.
    if any((path.parent/name).exists() or (path.parent/name).is_symlink()
            for name in readiness.MARKERS):raise OwnershipError('Direct initial proof cannot replace restored recovery')


def certificate(path,digest):
    path=Path(path);manifest=load_manifest(path);_fresh(path)
    file=path.parent/readiness.FILE;check_private(file)
    if file.lstat().st_nlink!=1:raise OwnershipError('Direct proof has shared storage')
    value=read_signed(file,path.parent/'owner.key',maximum=65536)
    try:
        closed(value,FIELDS);now=int(time.time());current=gate.state(path)
        if (manifest['profile']!='aws-eks/1' or value['profile']!=PROFILE
                or value['installationId']!=manifest['installationId'] or value['runId']!=manifest['runId']
                or type(value['generation']) is not int or value['generation']!=2
                or current['mode']!='READY' or current['generation']!=value['generation']
                or type(digest) is not str or re.fullmatch('[a-f0-9]{64}',digest) is None
                or value['installationDigest']!=digest or canonical_bytes(value['features'])!=canonical_bytes(FEATURES)
                or type(value['issuedAt']) is not int or type(value['expiresAt']) is not int
                or not value['issuedAt']<=now<value['expiresAt']
                or not 60<=value['expiresAt']-value['issuedAt']<=86400
                or type(value['checks']) is not dict or set(value['checks'])!=CHECKS
                or any(v is not True for v in value['checks'].values())
                or value['releaseDigest']!=readiness.release_digest()
                or value['contentDigest']!=readiness._runtime_content()
                or value['materialsDigest']!=readiness._materials(path)):raise ValueError()
    except Exception:raise OwnershipError('Current direct POC control release unavailable') from None
    return value


class DirectTransactionRelease:
    def __init__(self,path,digest):
        self.path,self.digest=path,digest;self.original=certificate(path,digest)

    def verify(self):
        if certificate(self.path,self.digest)!=self.original:raise OwnershipError('Direct POC release changed')

    def verify_temporal(self,connection):
        raise OwnershipError('Direct POC proof cannot grant Temporal execution')


@dataclass(frozen=True)
class DirectControlRelease:
    manifest:Path
    digest:str

    def __post_init__(self):
        # Reuse the exact existing path/profile/digest validation, without
        # constructing a Cloud connection or selecting its runtime proof.
        readiness.InitialControlRelease(self.manifest,self.digest)

    @contextmanager
    def __call__(self):
        with file_lock(self.manifest.parent/'recovery-gate.lock',timeout=2,shared=True):
            proof=DirectTransactionRelease(self.manifest,self.digest)
            yield proof
            proof.verify()


async def qualify_initial(document,token,*,expected_generation):
    document=deepcopy(document)
    stores=configuration(document);path=stores['installation']['manifest']
    if type(expected_generation) is not int or expected_generation!=1:
        raise OwnershipError('Fresh parked initial generation required')
    def checkpoint():
        verify_operator(path,token)
        with file_lock(path.parent/'recovery-gate.lock',timeout=2):
            _fresh(path);current=gate.state(path)
            if (current['mode']!='PARKED' or current['generation']!=1
                    or (path.parent/readiness.FILE).exists() or (path.parent/readiness.FILE).is_symlink()):
                raise OwnershipError('Fresh initial direct installation required')
            for name in ('artifacts','backups'):
                check_private(path.parent/name,directory=True)
                if any((path.parent/name).iterdir()):raise OwnershipError('Initial installation contains private data')
            return current,readiness._materials(path)
    before=await asyncio.to_thread(checkpoint);content=await asyncio.to_thread(readiness._runtime_content)
    await asyncio.to_thread(readiness.storage.prepare_stores,document['stores'],token,
        expected_generation=1,check_only=True)
    await asyncio.to_thread(readiness._empty_owner_stores,document['stores'],token)
    with configured_installation(document['stores']['installation']) as installation:
        # Raw configured runtime roles are read-only for this operator check;
        # no ControlStore transaction or not-yet-issued proof is borrowed.
        await asyncio.to_thread(readiness._empty_runtime_stores,SimpleNamespace(installation=installation),token)
    await asyncio.to_thread(readiness._empty_owner_stores,document['stores'],token)
    if await asyncio.to_thread(checkpoint)!=before:raise OwnershipError('Initial direct readiness changed')
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        verify_operator(path,token);_fresh(path)
        if (gate.state(path)!=before[0] or readiness._materials(path)!=before[1]
                or (path.parent/readiness.FILE).exists() or (path.parent/readiness.FILE).is_symlink()
                or readiness._runtime_content()!=content):raise OwnershipError('Direct readiness changed before publication')
        now=int(time.time());manifest=load_manifest(path)
        value=dict(profile=PROFILE,installationId=manifest['installationId'],runId=manifest['runId'],generation=2,
            installationDigest=readiness.installation_digest(document['stores']['installation']),
            releaseDigest=readiness.release_digest(),materialsDigest=before[1],contentDigest=content,
            issuedAt=now,expiresAt=now+document['release_seconds'],checks={name:True for name in CHECKS},features=FEATURES)
        write_signed(path.parent/readiness.FILE,value,path.parent/'owner.key')
        gate._write(path,mode='READY',reason='verified');certificate(path,value['installationDigest'])
    return dict(profile=PROFILE,state='initial-direct-control-ready',controlReady=True,runtimeReady=False,
        enabledLanes=[],generation=2,expiresAt=value['expiresAt'],productionQualified=False)
