"""Installed, hash-bound POC entry; no source-tree or ambient mode discovery."""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import re
import platform
from importlib.resources import files

from agentic_os.adapters.local.files import private_read
from agentic_os.contracts.canonical import parse_canonical_json


def selected(path, expected_sha256):
    if (not isinstance(path, Path) or not path.is_absolute()
            or re.fullmatch('[a-f0-9]{64}', expected_sha256 or '') is None):
        raise ValueError('Explicit private configuration and SHA256 required')
    raw = private_read(path, 65536)
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ValueError('Selected configuration changed')
    value = parse_canonical_json(raw)
    if value.get('schema') == 'poc-local-runtime/1':
        from . import runtime_local as implementation
    elif value.get('schema') == 'poc-reviewed-runtime/1':
        from . import runtime_review as implementation
    elif value.get('schema') == 'poc-configured-family-runtime/1':
        from . import runtime_configured as implementation
    else:
        raise ValueError('Unselected POC runtime schema')
    return implementation.validate_configuration(value), implementation


def bundled_opa(manifest, binary, *, stage):
    """Seed only exact pinned bytes in an already owned private installation."""
    from agentic_os.distribution import read_regular
    from agentic_os.adapters.local.ownership import load_manifest
    from agentic_os.adapters.local.resources import ensure_private
    from agentic_os.adapters.local.files import private_write
    placement = {('Linux', 'aarch64'): 'opa-linux-arm64', ('Darwin', 'arm64'): 'opa-darwin-arm64'}
    key = placement.get((platform.system(), platform.machine()))
    if key is None or not binary.is_absolute():
        raise ValueError('Qualified explicit bundled policy placement required')
    lock = json.loads(files('agentic_os').joinpath('deploy/source-lock.json').read_bytes())[key]
    content = read_regular(binary, 200_000_000)
    if hashlib.sha256(content).hexdigest() != lock['sha256']:
        raise ValueError('Bundled policy binary differs from the existing source lock')
    if not stage:
        return
    owned = load_manifest(manifest)
    directory = Path(owned['root']) / 'dependencies'
    ensure_private(directory)
    destination = directory / 'opa'
    if destination.exists() or destination.is_symlink():
        if read_regular(destination, 200_000_000) != content:
            raise ValueError('Retained installation policy binary differs; no silent replacement')
    else:
        private_write(destination, content)
    destination.chmod(0o700)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--config-sha256', required=True)
    parser.add_argument('--check', action='store_true', help='Validate static selection without starting services')
    parser.add_argument('--bundled-opa', type=Path, help='Use only exact source-lock policy bytes; never replace different retained bytes')
    parser.add_argument('--qualification-controls',type=Path,help='Existing owner synthetic-data/API allowance selection; never creates a ledger')
    parser.add_argument('--allowance-report',type=Path,help='New protected observation of this qualifier original reservations')
    parser.add_argument('--capacity-root',type=Path,help='Existing protected allocation root')
    args = parser.parse_args()
    value, implementation = selected(args.config, args.config_sha256)
    if args.bundled_opa is not None:
        bundled_opa(Path(value['manifest']), args.bundled_opa, stage=not args.check)
    if args.check:
        print(json.dumps(dict(schema='poc-runtime-selection/1', state='configuration-validated',
            runtimeSchema=value['schema'], mode=value['mode'], target=value.get('target','local-synthetic'),
            readiness='Not established by static validation')))
        return
    if value['schema']=='poc-configured-family-runtime/1':
        if any(path is None or not path.is_absolute() for path in
                (args.qualification_controls,args.allowance_report,args.capacity_root)) or args.bundled_opa is None:
            raise ValueError('A1 requires existing explicit funding/capacity and bundled policy inputs')
        asyncio.run(implementation.serve(value,qualification_controls=args.qualification_controls,
            allowance_report=args.allowance_report,capacity_root=args.capacity_root))
        return
    from . import runtime_local
    options = (dict(composer=implementation.compose, policies=implementation.policies)
        if implementation is not runtime_local else {})
    asyncio.run(runtime_local.serve(value, **options))


if __name__ == '__main__':
    main()
