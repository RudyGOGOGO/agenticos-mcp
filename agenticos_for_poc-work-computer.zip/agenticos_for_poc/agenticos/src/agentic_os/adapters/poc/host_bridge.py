"""Local synthetic HostBridge and native bootstrap adapter over trusted tools.

This adapter owns no product tables. Local identity is explicit and cannot be
selected by AWS composition. Core sessions, tasks and effects remain canonical.
"""
from copy import deepcopy
from datetime import timedelta
import hmac
import json
import re
from pathlib import Path
import time
from uuid import uuid4

from fastapi import FastAPI,Request
from fastapi.responses import HTMLResponse,JSONResponse,Response
import httpx
import jwt

from agentic_os.adapters.local.files import private_read
from agentic_os.adapters.local.resources import read_signed,write_signed
from agentic_os.contracts.canonical import digest,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import iso,timestamp,utcnow
from .mcp import POCMCP


class LocalHostBridge:
    authority_profile='local-synthetic'
    # ConfiguredFamilyHost intentionally bypasses this local constructor.
    local_access=None
    native_ceremony=None
    def __init__(self, *, namespace, tenant, origin, os_origin, backend_url, embed_ref,
            bridge_key, controls_file, mcp_key_file, mcp_url, descriptors,session_file=None,session_run_id=None,
            local_access=None):
        self.namespace=deepcopy(namespace)
        self.tenant,self.origin,self.os_origin=tenant,origin,os_origin
        self.backend_url,self.embed_ref=backend_url,embed_ref
        self.bridge_key=bridge_key
        self.controls_file,self.mcp_key_file=Path(controls_file),Path(mcp_key_file)
        self.mcp=POCMCP(mcp_url)
        self.descriptors=deepcopy(descriptors)
        self.mappings={}
        self.sessions={}
        if local_access is not None:
            from .local_synthetic_access import LocalNativeAccess
            if type(local_access) is not LocalNativeAccess:raise ValueError('Explicit local native access adapter required')
        self.local_access=local_access
        self.native_ceremony=None
        if not origin.startswith('http://127.0.0.1:') or not os_origin.startswith('http://127.0.0.1:'):
            raise ValueError('This HostBridge is explicitly local synthetic only')
        self.session_file=Path(session_file) if session_file is not None else None
        self.session_binding=dict(schema='poc-local-host-sessions/1',namespace=deepcopy(namespace),tenant=tenant,
            runId=session_run_id,hostOrigin=origin,osOrigin=os_origin,backendURL=backend_url)
        if self.session_file is not None:
            from uuid import UUID
            if type(session_run_id) is not str or re.fullmatch('[a-f0-9]{12}',session_run_id) is None:
                raise ValueError('Exact local installation run identity required')
            if self.session_file.exists() or self.session_file.is_symlink():
                retained=read_signed(self.session_file,self.session_file.parent/'owner.key',maximum=131072)
                if set(retained)!={'binding','sessions'} or retained['binding']!=self.session_binding:
                    raise ValueError('Local Host session binding differs; never adopt a restored identity')
                if type(retained['sessions']) is not dict or len(retained['sessions'])>128:
                    raise ValueError('Bounded local Host sessions required')
                for reference,session in retained['sessions'].items():
                    UUID(reference);validate_contract('SubjectRef',session['subject'])
                    if (set(session) not in ({'subject','generation','issuedAt','expires'},
                            {'subject','generation','issuedAt','expires','native'})
                            or any(session['subject'][key]!=namespace[key] for key in namespace)
                            or session['subject']['tenantId']!=tenant
                            or type(session['generation']) is not int or session['generation']<1
                            or type(session['issuedAt']) is not int or type(session['expires']) is not int
                            or not 0<session['expires']-session['issuedAt']<=900):
                        raise ValueError('Invalid local Host session')
                    if 'native' in session:
                        native=session['native']
                        if (type(native) is not dict or set(native)!={'environmentId','sessionId','generation'}
                                or str(UUID(native['environmentId']))!=native['environmentId']
                                or str(UUID(native['sessionId']))!=native['sessionId']
                                or type(native['generation']) is not int or not 1<=native['generation']<=2**53-1):
                            raise ValueError('Invalid native Host binding')
                    if session['expires']>time.time():self.sessions[reference]=session

    def remember_session(self,reference,subject,generation,*,native=None):
        now=int(time.time())
        self.sessions={key:value for key,value in self.sessions.items() if value['expires']>now}
        if len(self.sessions)>=128:raise OSErrorCode('CAPACITY')
        session=dict(subject=deepcopy(subject),generation=generation,issuedAt=now,expires=now+900)
        if self.local_access is not None:
            self.local_access.record.require(subject,native)
            if native is None:raise OSErrorCode('DENIED')
            session['native']=deepcopy(native)
        self.sessions[reference]=session
        if self.session_file is not None:
            write_signed(self.session_file,dict(binding=self.session_binding,sessions=self.sessions),
                self.session_file.parent/'owner.key')

    def control(self,subject):
        if (subject.get('installationId')!=self.namespace['installationId']
                or subject.get('applicationId')!=self.namespace['applicationId']
                or subject.get('tenantId')!=self.tenant):raise OSErrorCode('DENIED')
        users=parse_canonical_json(private_read(self.controls_file,65536))['users']
        value=users.get(subject.get('subjectId'))
        if value is None or not value['active']:raise OSErrorCode('DENIED')
        return value

    def subject(self,user):
        return dict(**self.namespace,tenantId=self.tenant,subjectId=user)

    def register(self,capability,mapping,read_profile):
        self.mappings[capability['ref']]=dict(capability=deepcopy(capability),mapping=mapping,
            profile=deepcopy(read_profile))

    def authorized_document(self,mapping,document,control,arguments):
        return all(row[mapping.id_field] in control['memberIds'] for row in mapping.source(document))

    def credential(self,subject,tool,until):
        control=self.control(subject)
        if tool not in control['tools']:raise OSErrorCode('DENIED')
        key=private_read(self.mcp_key_file,4096)
        if len(key)<32:raise OSErrorCode('UNAUTHENTICATED')
        now=int(time.time());expiry=min(int(timestamp(until).timestamp()),now+60)
        if expiry<=now:raise OSErrorCode('DENIED')
        return jwt.encode(dict(iss='vf-poc-local',aud=['vf-mcp'],sub=subject['subjectId'],client_id='core-poc',
            installation='vf-poc',application='verizon-family',environment='local',tools=[tool],
            iat=now,exp=expiry),key,algorithm='HS256')

    def scoped(self,context,*,until=None):
        validate_contract('AgentTaskContext',context)
        control=self.control(context['subject'])
        if self.local_access is not None:
            # Source observation has fresh read-only authority independent of
            # the producer Root's execution horizon. Dispatch remains pinned
            # to that original Root's native epoch and unchanged deadline.
            binding=self.local_access.root_binding(context) if until is None else None
            self.local_access.record.require(context['subject'],binding)
        expiry=min(utcnow()+timedelta(seconds=20),timestamp(until) if until is not None
            else timestamp(context['authorizationHorizon']))
        if expiry<=utcnow():raise OSErrorCode('DENIED')
        return control,iso(expiry)

    def app(self):
        app=FastAPI(docs_url=None,redoc_url=None,openapi_url=None)

        # Optional local placement of the existing OS embed. Configured/cloud
        # Host overrides app() and never mounts these synthetic identity routes.
        from urllib.parse import urlsplit
        expected_host=urlsplit(self.origin).netloc
        def browser_request(request):
            if request.headers.get('host')!=expected_host or request.query_params:
                return JSONResponse(dict(code='NOT_FOUND'),status_code=404)
            return None

        @app.get('/assistant')
        async def local_assistant(request:Request):
            denied=browser_request(request)
            if denied is not None:return denied
            return HTMLResponse('''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Family local assistant</title>
<link rel="stylesheet" href="/assistant.css"></head><body><header>
<strong>Family assistant</strong><span>LOCAL TEST · Synthetic account test-user-001</span>
<button id="open" type="button">Open assistant</button><p id="status" role="status">
Use the real assistant forms to review and confirm changes. Native read-back remains separate.</p>
</header><main id="assistant" aria-label="Assistant placement"></main>
<script type="module" src="/assistant.js"></script></body></html>''',headers={
                'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',
                'Referrer-Policy':'no-referrer','Content-Security-Policy':
                "default-src 'none'; script-src 'self' "+self.os_origin+"; style-src 'self'; frame-src "+self.os_origin+"; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"})

        @app.get('/assistant.css')
        async def local_assistant_style(request:Request):
            denied=browser_request(request)
            if denied is not None:return denied
            return Response('body{margin:0;font:16px system-ui,sans-serif;color:#263c3c;background:#f3f7f5}header{padding:16px 24px}strong,span{display:block;margin:4px 0}span,p{font-size:14px}button{padding:10px 18px;margin-top:8px}main{height:calc(100dvh - 190px);min-height:320px;max-width:1100px;margin:auto;background:white}',media_type='text/css',headers={'Cache-Control':'no-store'})

        @app.get('/assistant.js')
        async def local_assistant_script(request:Request):
            denied=browser_request(request)
            if denied is not None:return denied
            # Public placement metadata only. The normal bootstrap callback
            # still checks current synthetic backend identity before exchange.
            script='import {mountAssistant} from '+json.dumps(self.os_origin+'/os/ui/assets/embed.js')+';\n'
            script+='const placement='+json.dumps(dict(origin=self.os_origin,registration=self.embed_ref),ensure_ascii=True)+';\n'
            script+='''const button=document.querySelector('#open'),status=document.querySelector('#status');
let mounted=null;
button.addEventListener('click',()=>{
  if(mounted)return;
  button.disabled=true;status.textContent='Connecting to your local assistant…';
  try {mounted=mountAssistant({...placement,container:document.querySelector('#assistant'),fit:'container',allowReviewPopups:true,
    bootstrap:async binding=>{
      const response=await fetch('/native/bootstrap',{method:'POST',headers:{'Content-Type':'application/json','X-POC-Test-User':'test-user-001'},body:JSON.stringify(binding),credentials:'same-origin'});
      if(!response.ok){const error=new Error('Local sign-in unavailable');error.status=response.status;throw error;}
      status.textContent='Local sign-in accepted. Continue in the assistant when it opens; review every proposed change before confirmation.';
      return await response.json();
    },onError:message=>{mounted?.destroy();mounted=null;button.disabled=false;status.textContent=message;},onClose:()=>{mounted=null;button.disabled=false;status.textContent='Assistant closed.';}});
  } catch {mounted=null;button.disabled=false;status.textContent='Assistant unavailable. Reopen to try again.';}
});'''
            return Response(script,media_type='text/javascript',headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})

        @app.get('/health')
        async def health():return dict(status='local-synthetic-host-adapter')

        if self.local_access is not None:
            @app.post('/native/ceremony/confirm')
            async def native_ceremony_confirm(request:Request):
                try:
                    if (request.headers.get('host')!=expected_host or request.query_params
                            or request.headers.get('origin') is not None or request.headers.get('cookie') is not None
                            or self.native_ceremony is None):raise OSErrorCode('DENIED')
                    raw=await request.body()
                    if len(raw)>4096:raise OSErrorCode('CAPACITY')
                    command=parse_canonical_json(raw)
                    validate_contract('SyntheticOwnerCeremonyCommand',command)
                    subject=self.subject(request.headers.get('x-poc-test-user',''))
                    self.control(subject)
                    result=await self.native_ceremony.confirm(subject,request.headers.get('authorization'),command)
                    return JSONResponse(result,headers={'Cache-Control':'no-store'})
                except OSErrorCode as error:
                    return JSONResponse(dict(code=error.code),status_code=error.STATUS[error.code])
                except (ValueError,TypeError,KeyError):return JSONResponse(dict(code='INVALID'),status_code=400)

            @app.post('/native/session-changed')
            async def native_session_changed(request:Request):
                try:
                    if (request.headers.get('host')!=expected_host or request.query_params
                            or request.headers.get('origin') is not None or request.headers.get('cookie') is not None):
                        raise OSErrorCode('DENIED')
                    raw=await request.body()
                    if len(raw)>4096:raise OSErrorCode('CAPACITY')
                    from .local_synthetic_access import native_metadata
                    expected=native_metadata(parse_canonical_json(raw),self.local_access.record.backend_environment)
                    subject=self.subject(expected['subject'])
                    value=await self.local_access.synchronize(subject,expected)
                    return JSONResponse(dict(schema='vf.native-session-publication/1',published=True,
                        **{k:value[k] for k in ('subject','environment','sessionId','generation','environmentRevision','state')}))
                except OSErrorCode as error:
                    return JSONResponse(dict(code=error.code),status_code=error.STATUS[error.code])
                except (ValueError,TypeError,KeyError):return JSONResponse(dict(code='INVALID'),status_code=400)

        @app.post('/native/bootstrap')
        async def native_bootstrap(request:Request):
            # Native-only local identity is checked by the actual peer backend
            # before a Host session is minted. No agent roster tool is added.
            try:
                # Native URLSession omits Origin. Foreign browser origins are
                # refused; both native forms still require the current local
                # test identity, backend check and exact Core challenge.
                if request.headers.get('origin') not in (None,self.origin):raise OSErrorCode('DENIED')
                user=request.headers.get('x-poc-test-user','')
                subject=self.subject(user);control=self.control(subject)
                body=parse_canonical_json(await request.body())
                if set(body)!={'challengeId','embedRef','frameNonce','proofKeyThumbprint','expiresAt'} or body['embedRef']!=self.embed_ref:
                    raise OSErrorCode('INVALID')
                async with httpx.AsyncClient(trust_env=False,follow_redirects=False,timeout=8) as client:
                    native=None
                    if self.local_access is not None:
                        # The opaque credential is forwarded only to the fixed
                        # native status endpoint, never to Core/model/MCP.
                        if request.headers.get('origin') is not None or request.headers.get('cookie') is not None:
                            raise OSErrorCode('DENIED')
                        native=await self.local_access.native(subject,request.headers.get('authorization'))
                    else:
                        response=await client.get(self.backend_url+'/members',headers={'X-POC-Test-User':user})
                        if response.status_code!=200:raise OSErrorCode('UNAUTHENTICATED')
                    session_ref=str(uuid4())
                    self.remember_session(session_ref,subject,control['sessionGeneration'],native=native)
                    binding=dict(subject=subject,**body,sessionGeneration=control['sessionGeneration'],
                        audience='agentic-os.browser',replayId=str(uuid4()))
                    response=await client.post(self.os_origin+'/os/embed/bootstrap',json=dict(binding=binding,
                        hostSessionRef=session_ref),headers={'Authorization':'Bearer '+self.bridge_key})
                    if self.local_access is not None:self.local_access.record.require(subject,native)
                    return JSONResponse(response.json(),status_code=response.status_code)
            except OSErrorCode as error:
                return JSONResponse(dict(code=error.code),status_code=error.STATUS[error.code])

        return self.attach_private(app)

    def attach_private(self,app):
        @app.post('/host-bridge/v1/{action:path}')
        @app.post('/host-bridge/agent/v1/{action:path}')
        async def host_request(action:str,request:Request):
            try:
                if (request.headers.get('origin') is not None or request.headers.get('cookie') is not None
                        or not hmac.compare_digest(request.headers.get('authorization',''),'Bearer '+self.bridge_key)):
                    raise OSErrorCode('UNAUTHENTICATED')
                raw=await request.body()
                if len(raw)>1024*1024:raise OSErrorCode('CAPACITY')
                body=parse_canonical_json(raw)
                result=await self.dispatch(action,body)
                return JSONResponse(result)
            except OSErrorCode as error:
                return JSONResponse(dict(code=error.code),status_code=error.STATUS[error.code])
            except (KeyError,ValueError,TypeError):
                return JSONResponse(dict(code='INVALID'),status_code=400)
        return app

    async def dispatch(self,action,body):
        if self.local_access is not None and action in {'scope','scope-observe','read','observe'}:
            value=body['scope'] if action=='scope-observe' else body['read'] if action=='observe' else body
            context=value['context'] if action in {'scope','scope-observe'} else value['binding']['context']
            if action in {'scope','read'}:await self.local_access.check_root(context)
            else:
                await self.local_access.synchronize(context['subject'])
                self.local_access.record.require(context['subject'])
        if action in {'scope','scope-observe'}:
            observation=action=='scope-observe'
            value=body['scope'] if observation else body
            validate_contract('AgentCapabilityScopeRequest',value)
            c=value['context'];control,until=self.scoped(c,until=body['validUntil'] if observation else None)
            pins=[pin for pin in value['capabilities'] if pin['ref'] in self.mappings
                and self.mappings[pin['ref']]['capability']==pin
                and self.mappings[pin['ref']]['mapping'].descriptor['name'] in control['tools']]
            return dict(subject=c['subject'],taskId=c['taskId'],rootId=c['rootId'],requestDigest=digest('command',body),
                purpose=c['purpose'],intentRevision=c['intentRevision'],controlEpoch=c['controlEpoch'],
                policyGeneration=control['policyGeneration'],scopeRef=c['scopeRef'],capabilities=pins,validUntil=until)
        if action in {'read','observe'}:
            observation=action=='observe';value=body['read'] if observation else body
            validate_contract('AgentReadAuthorityRequest',value)
            binding=value['binding'];c=binding['context']
            control,until=self.scoped(c,until=body['validUntil'] if observation else None)
            registration=self.mappings.get(binding['capability']['ref'])
            if (registration is None or registration['capability']!=binding['capability']
                    or registration['profile']!=value['profile']):raise OSErrorCode('DENIED')
            mapping=registration['mapping'];tool=mapping.descriptor['name']
            if tool not in control['tools'] or value['providerRef']!=mapping.provider_ref:raise OSErrorCode('DENIED')
            arguments=parse_canonical_json(binding['argumentsJson'])
            from jsonschema import Draft202012Validator
            if not Draft202012Validator(mapping.descriptor['inputSchema']).is_valid(arguments):raise OSErrorCode('INVALID')
            token=self.credential(c['subject'],tool,until)
            allowed=True;credential=None
            if value['phase']=='disclose':
                actual=await self.mcp.request(token,tool=tool,arguments=arguments)
                allowed=(self.authorized_document(mapping,actual,control,arguments)
                    and mapping.matches(actual,c['subject'],parse_canonical_json(value['candidateJson'])))
            elif value['phase']=='dispatch' and not observation:
                credential=dict(accessToken=token,audienceRef='vf.mcp',subject=c['subject'],
                    capabilityRef=binding['capability']['ref'],expiresAt=until)
            else:raise OSErrorCode('DENIED')
            return dict(requestDigest=digest('command',body),subject=c['subject'],taskId=c['taskId'],rootId=c['rootId'],
                policyGeneration=control['policyGeneration'],scopeRef=c['scopeRef'],allowed=allowed,
                validUntil=until,credential=credential)
        subject=body['subject'];control=self.control(subject);now=utcnow();until=iso(now+timedelta(seconds=15))
        if action=='sessions/check':
            session=self.sessions.get(body['hostSessionRef'])
            active=bool(session and session['subject']==subject and session['expires']>time.time()
                and session['generation']==control['sessionGeneration']==body['sessionGeneration'])
            if active and self.local_access is not None:
                try:
                    await self.local_access.synchronize(subject)
                    if 'native' not in session:raise OSErrorCode('DENIED')
                    self.local_access.record.require(subject,session['native'])
                    active=bool(session['expires']>time.time() and self.control(subject)==control)
                except OSErrorCode as error:
                    if error.code not in {'DENIED','CONFLICT'}:raise
                    active=False
            return dict(subject=subject,active=active,sessionGeneration=control['sessionGeneration'],
                policyGeneration=control['policyGeneration'],checkedAt=iso(now),validUntil=until)
        if action=='capabilities':
            return dict(capabilities=[descriptor for tool,descriptor in self.descriptors.items() if tool in control['tools']])
        if action=='authority/check':
            refs=[descriptor['id'] for tool,descriptor in self.descriptors.items() if tool in control['tools']]
            if body['capabilityRef'] not in refs or body['delegationRef'] is not None:raise OSErrorCode('DENIED')
            return dict(id=str(uuid4()),subject=subject,active=True,policyGeneration=control['policyGeneration'],
                capabilityRefs=refs,resourceBounds=[dict(resourceType='member',externalIds=control['memberIds'],
                    fieldNames=['displayName','deviceId'])],purpose=body['purpose'],checkedAt=iso(now),validUntil=until,
                assuranceRef=self.authority_profile,delegationRef=None)
        if action=='credentials/issue':
            tool=next((name for name,d in self.descriptors.items() if d['id']==body['capabilityRef']),None)
            if body['endpointRef']!='vf.mcp' or tool is None:raise OSErrorCode('DENIED')
            return dict(accessToken=self.credential(subject,tool,until),audienceRef='vf.mcp',subject=subject,
                capabilityRef=body['capabilityRef'],expiresAt=until)
        raise OSErrorCode('NOT_FOUND')
