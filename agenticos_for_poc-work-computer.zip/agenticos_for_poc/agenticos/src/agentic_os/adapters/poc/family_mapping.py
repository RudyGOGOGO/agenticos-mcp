"""Pinned, lossless table projections of the five committed VF read DTOs."""
from copy import deepcopy
from datetime import timedelta

from agentic_os.contracts.canonical import digest
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import timestamp
from .external_json import validate_external
from .mcp import ReadMapping


FIELDS={
    'LookupMemberByName':('memberId','displayName','deviceId'),
    'GetLastKnownLocation':('memberId','displayName','deviceId','latitude','longitude',
        'recordedAt','accuracyMeters','batteryPercent','batteryCharging'),
    'ListSavedLocations':('id','name','latitude','longitude','address','revision','createdAt','updatedAt','geofenceCount'),
    'GetSavedLocationWithGeofences':('savedLocationId','name','address','latitude','longitude','locationRevision','geofenceId',
        'memberId','memberDisplayName','radiusMeters','notificationType','enabled','revision','updatedAt','ruleStatus'),
    'GetLocationHistory':('memberId','recordedAt','latitude','longitude','accuracyMeters','batteryPercent',
        'windowDays','from','to','totalCount','truncated','rowStatus'),
}
TYPES={'LookupMemberByName':'member','GetLastKnownLocation':'member-last-known',
    'ListSavedLocations':'saved-location','GetSavedLocationWithGeofences':'saved-location-rule',
    'GetLocationHistory':'member-history-point'}


class FamilyReadMapping(ReadMapping):
    """No guessed names, time, location labels, measurements or empty successes.

    Every resource version fingerprints its complete original DTO, including
    history truncation/window metadata and the location containing each rule.
    Authorization still comes from current Host and downstream owner checks.
    """
    def __init__(self,descriptor,*,observed_history_window=False):
        tool=descriptor['name']
        if tool not in FIELDS:raise ValueError('One committed VF read descriptor required')
        super().__init__(descriptor,provider_ref='vf.mcp',records_field=None,id_field='_rowId',
            resource_type=TYPES[tool],fields=list(FIELDS[tool]),external_descriptor=True)
        self.tool=tool
        self.observed_history_window=observed_history_window and tool=='GetLocationHistory'
        self.pin=digest('manifest',dict(mapping='vf-family-read-tables/1',descriptor=self.pin,
            resourceType=self.resource_type,fields=list(self.fields)))
        if self.observed_history_window:
            self.pin=digest('manifest',dict(mapping='vf-observed-history-window/1',source=self.pin))

    def source(self,document):
        validate_external(self.descriptor['outputSchema'],document)
        tool=self.tool
        if tool=='LookupMemberByName':
            rows=[dict(row,_rowId=row['memberId']) for row in document['members']]
        elif tool=='GetLastKnownLocation':
            rows=[dict(document,_rowId=document['memberId'])]
        elif tool=='ListSavedLocations':
            rows=[dict(row,_rowId=row['id']) for row in document['savedLocations']]
        elif tool=='GetSavedLocationWithGeofences':
            common=dict(savedLocationId=document['id'],name=document['name'],address=document['address'],
                latitude=document['latitude'],longitude=document['longitude'],locationRevision=document['revision'])
            rows=[dict(common,_rowId=document['id']+'/'+row['id'],geofenceId=row['id'],
                **{key:row[key] for key in ('memberId','memberDisplayName','radiusMeters','notificationType',
                    'enabled','revision','updatedAt')},ruleStatus='Boundary alert') for row in document['geofences']]
            if not rows:
                rows=[dict(common,_rowId=document['id']+'/no-rules',geofenceId=None,memberId=None,
                    memberDisplayName=None,radiusMeters=None,notificationType=None,enabled=None,revision=None,
                    updatedAt=document['updatedAt'],ruleStatus='No boundary alerts')]
        else:
            common={key:document[key] for key in ('memberId','windowDays','from','to','totalCount','truncated')}
            rows=[dict(common,**row,_rowId=document['memberId']+'@'+row['recordedAt'],rowStatus='Recorded point')
                for row in document['points']]
            if not rows:
                rows=[dict(common,_rowId=document['memberId']+'@empty',recordedAt=None,latitude=None,
                    longitude=None,accuracyMeters=None,batteryPercent=None,rowStatus='No recorded points')]
        if len(rows)>64 or len({row['_rowId'] for row in rows})!=len(rows):raise OSErrorCode('CAPACITY')
        # Carry the exact outer source into each opaque version without
        # exposing nested product JSON as a FieldValue or Core control value.
        version=self.version(document)
        return [dict(row,_sourceVersion=version) for row in rows]

    @staticmethod
    def version(row):
        return row['_sourceVersion'] if '_sourceVersion' in row else ReadMapping.version(row)

    def completeness(self,document):
        return '0.50' if self.tool=='GetLocationHistory' and document['truncated'] else '1.00'

    def matches(self,document,subject,page):
        if not self.observed_history_window:return super().matches(document,subject,page)
        # The public API has no as-of parameter: re-reading advances only its
        # trailing window clock. Preserve the original observed window while
        # requiring the exact current points/count/truncation and authority.
        # Never normalize coordinates, recordedAt, member identity or coverage.
        validate_external(self.descriptor['outputSchema'],document)
        try:
            windows={(next(f['value'] for f in row if f['name']=='from'),
                next(f['value'] for f in row if f['name']=='to')) for row in page['records']}
            if len(windows)!=1:return False
            start,end=next(iter(windows));left,right=timestamp(start),timestamp(end)
            current_left,current_right=timestamp(document['from']),timestamp(document['to'])
            observed=timestamp(page['evidence']['observedAt'])
            duration=timedelta(days=document['windowDays'])
            if (right-left!=duration or current_right-current_left!=duration
                    or not right<=observed<=right+timedelta(seconds=30)
                    or current_right<right
                    or any(not left<timestamp(point['recordedAt'])<=right for point in document['points'])):
                return False
            original=dict(document,**{'from':start,'to':end})
            return super().matches(original,subject,page)
        except (KeyError,StopIteration,TypeError,ValueError):return False

    def authorized(self,document,control,arguments):
        rows=self.source(document)
        if 'memberId' in arguments and arguments['memberId'] not in control['memberIds']:return False
        return all(row.get('memberId') is None or row['memberId'] in control['memberIds'] for row in rows)
