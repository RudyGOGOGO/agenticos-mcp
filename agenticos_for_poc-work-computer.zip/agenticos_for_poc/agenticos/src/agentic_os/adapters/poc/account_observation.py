"""Private account status only; never fetch or expose a family roster."""
import asyncio
from copy import deepcopy
from pathlib import Path
from urllib.parse import urlsplit

import httpx

from agentic_os.adapters.http.endpoint import reviewed_http_endpoint
from agentic_os.adapters.http.tls import reviewed_tls_context
from agentic_os.adapters.http.circuit import AvailabilityCircuit
from agentic_os.adapters.local.files import private_read
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import fresh,timestamp


class PrivateAccountObservation:
    def __init__(self,*,url,environment,namespace,token_files,network='owned-local-http/1',ca_file=None,ca_sha256=None,
            local_issuer=None):
        self.url=reviewed_http_endpoint(url,network)
        if (urlsplit(self.url).path!='/account-observations' or type(environment) is not str or not 1<=len(environment)<=128
                or type(namespace) is not dict or set(namespace)!={'installationId','applicationId'}
                or type(token_files) is not dict or not 1<=len(token_files)<=16
                or any(type(k) is not str or not 1<=len(k)<=128 or not Path(v).is_absolute() for k,v in token_files.items())):
            raise ValueError('Explicit bounded private account observation binding required')
        self.network=network
        if local_issuer is not None:
            from .local_synthetic_access import LocalAccountIssuer
            if (type(local_issuer) is not LocalAccountIssuer or network!='owned-local-http/1'
                    or local_issuer.environment!=environment):raise ValueError('Local-only account issuer required')
        self.local_issuer=local_issuer
        self.trust=dict(ca_file=ca_file,ca_sha256=ca_sha256)
        self.environment,self.namespace,self.tokens=environment,deepcopy(namespace),{k:Path(v) for k,v in token_files.items()}
        self.tls=reviewed_tls_context(network,ca_file=ca_file,ca_sha256=ca_sha256)
        self.bulkhead=asyncio.Semaphore(2);self.circuit=AvailabilityCircuit()

    async def _request(self,subject,*,local_session=False):
        validate_contract('SubjectRef',subject)
        if (any(subject[k]!=v for k,v in self.namespace.items()) or subject['subjectId'] not in self.tokens):
            raise OSErrorCode('DENIED')
        try:
            token=(await asyncio.to_thread(self.local_issuer.token,subject) if self.local_issuer is not None
                else private_read(self.tokens[subject['subjectId']],16384).decode('ascii').strip())
            if not token or token.count('.')!=2 or any(c.isspace() for c in token):raise OSErrorCode('DENIED')
            payload=canonical_bytes(dict(subject=subject['subjectId'],environment=self.environment))
            async with asyncio.timeout(3) as deadline,self.bulkhead:
                with self.circuit.call(timed_out=deadline.expired):
                    async with httpx.AsyncClient(verify=self.tls,trust_env=False,follow_redirects=False,timeout=3) as client:
                        url=self.url.removesuffix('/account-observations')+'/local-session-observations' if local_session else self.url
                        async with client.stream('POST',url,content=payload,headers={
                                'Authorization':'Bearer '+token,'Content-Type':'application/json','Accept-Encoding':'identity'}) as response:
                            if response.status_code in {401,403}:raise OSErrorCode('DENIED')
                            if (response.status_code!=200 or not response.headers.get('content-type','').startswith('application/json')
                                    or response.headers.get('content-encoding','identity')!='identity'):
                                raise OSErrorCode('UNAVAILABLE')
                            output=bytearray()
                            async for chunk in response.aiter_bytes():
                                output.extend(chunk)
                                if len(output)>4096:raise OSErrorCode('UNAVAILABLE')
            value=parse_canonical_json(bytes(output))
            if local_session:
                from .local_synthetic_access import native_metadata
                checked=native_metadata(value,self.environment,observation=True)
                if checked['subject']!=subject['subjectId']:raise OSErrorCode('DENIED')
                return checked
            if (type(value) is not dict or set(value)!={'schema','subject','environment','active','checkedAt','validUntil'}
                    or value['schema']!='vf-account-observation/1' or value['subject']!=subject['subjectId']
                    or value['environment']!=self.environment or type(value['active']) is not bool
                    or not 0<(timestamp(value['validUntil'])-timestamp(value['checkedAt'])).total_seconds()<=15):
                raise OSErrorCode('DENIED')
            fresh(dict(subject=subject,active=value['active'],checkedAt=value['checkedAt'],validUntil=value['validUntil']),subject=subject)
            return value
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None

    async def observe(self,subject):return await self._request(subject)

    async def observe_local_session(self,subject):
        if self.local_issuer is None or self.network!='owned-local-http/1':raise OSErrorCode('PROFILE_DISABLED')
        return await self._request(subject,local_session=True)
