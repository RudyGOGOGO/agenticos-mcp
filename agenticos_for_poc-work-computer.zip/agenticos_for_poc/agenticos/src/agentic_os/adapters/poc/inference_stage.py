"""The maintained supervised stage, with a fixed separate Agents SDK program."""
from pathlib import Path

from agentic_os.adapters.mem0.classified_stage import ClassifiedMem0Stage
from agentic_os.adapters.mem0.forget_lifecycle import ForgettableStageLifecycle
from agentic_os.adapters.poc import inference_protocol as protocol
from agentic_os.adapters.poc.slots import ProcessSlots
from agentic_os.errors import OSErrorCode


class KeywordInferenceStage(ClassifiedMem0Stage):
    profile = protocol.PROFILE
    checked_request = staticmethod(protocol.checked_request)
    checked_candidate = staticmethod(protocol.checked_candidate)
    checked_observed = staticmethod(protocol.checked_observed)

    def __init__(self, private_root, *, sdk_python, registry, forgetting=None, timeout=30):
        sdk_python = Path(sdk_python)
        if (not sdk_python.is_absolute() or not sdk_python.is_file()
                or not (sdk_python.parent.parent / 'pyvenv.cfg').is_file()):
            raise OSErrorCode('PROFILE_DISABLED')
        super().__init__(private_root, timeout=timeout)
        self.sdk_python = str(sdk_python)
        self.lifecycle = (forgetting.register_sdk_root(private_root) if forgetting is not None
            else ForgettableStageLifecycle(private_root))
        existing = getattr(registry, '_poc_process_slots', None)
        if existing is not None and type(existing) is not ProcessSlots:
            raise OSErrorCode('PROFILE_DISABLED')
        self.process_slots = existing if existing is not None else ProcessSlots()
        registry._poc_process_slots = self.process_slots
        self._recovered = False
        self._recovery_slots = {}

    def command(self, cookie):
        return (self.sdk_python, '-I', '-B', '-m', 'agentic_os_agent_worker.memory_inference', cookie)

    def environment(self, work):
        return dict(HOME=str(work), TMPDIR=str(work), OPENAI_AGENTS_DISABLE_TRACING='1',
            PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', OPENBLAS_NUM_THREADS='1',
            OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')

    def provider_reply(self, response):
        return dict(type='reply', content=response.content, inputTokens=response.input_tokens,
            outputTokens=response.output_tokens)

    async def recover(self):
        state = await self.lifecycle.recover()
        with self.lifecycle._locked() as persisted:
            leases = set(persisted['leases'])
        for cookie, token in getattr(self, '_held_process_slots', {}).items():
            self._recovery_slots.setdefault(cookie, token)
        self._held_process_slots = {}
        # Every unresolved signed birth consumes the same physical placement
        # as foreground/scheduled SDK work. Recovery never replays inference.
        for cookie, token in tuple(self._recovery_slots.items()):
            if cookie not in leases:
                await self.process_slots.release(token)
                del self._recovery_slots[cookie]
        for cookie in leases:
            if cookie not in self._recovery_slots:
                self._recovery_slots[cookie] = await self.process_slots.acquire()
        self._recovered = True
        return state

    async def run(self, request, provider=None, *, before_start=None):
        if not self._recovered:
            raise OSErrorCode('UNAVAILABLE')
        return await super().run(request, provider, before_start=before_start)
