"""Selected canonical memory -> finite current rule-gap read, without effects.

The composite read declares up to three public Java calls. Existing memory,
consent, source retention, proactive delegation and accounting own authority;
this module stores no independent state and never scans conversations/trails.
"""
import asyncio
from copy import deepcopy
from datetime import timedelta
from types import SimpleNamespace
from uuid import UUID,uuid4,uuid5

from sqlalchemy import select
from agentic_os.adapters.postgres.models import (PersonalKnowledgeEntry as Entry,
    ClassifiedKnowledgeBinding as Binding,PersonalLearningSource as Source,
    PersonalLearningSourceOrigin as Origin,AgentPayloadWrite,AgentPrivatePayload,
    AgentToolCall,AgentToolAcceptance,AgentToolArchive,AgentToolSlot,AgentToolFinish,
    Artifact,WorkAttempt,Admission,BudgetRoot,Task)
from agentic_os.contracts.canonical import canonical_bytes,digest,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import iso,utcnow,timestamp
from agentic_os.identity.service import scoped
from agentic_os.memory.inference_consent import permits
from agentic_os.memory.selected import current_origin
from .family_mapping import FamilyReadMapping
from .family_memory import FamilyScheduledMemoryHost

CAPABILITY='vf.reflection.rule-gap/1'
BOT='vf.reflection-reader/1'
RESOURCE='family-reflection-source'
ORIGIN='vf.reflection'
FIELDS=('Member','Place','Status','Suggestion','SourceChecks')
TOOLS=('LookupMemberByName','ListSavedLocations','GetSavedLocationWithGeofences')
DESCRIPTOR=dict(id=CAPABILITY,revision=1,inputSchemaRef='ReadToolArguments',outputSchemaRef='EvidencePage',
    originRef=ORIGIN,kind='read',riskFloor='low',scopeResolverRef='vf.current-owner',timeoutMs=15000,
    guaranteeProfile='current-read/1')


def registration(bundle,host_origin):
    value=deepcopy(bundle);app=value['application'];app['revision']+=1
    connector=deepcopy(value['connectors'][0]);connector.update(id='vf.reflection-connector/1',
        capabilityRefs=[CAPABILITY],transport='host-bridge',protocolProfile='host-bridge/1',
        endpointRef=ORIGIN,credentialRef=app['credentialRef'],authorityProfile='current-read/1',
        timeoutMs=15000,maxResponseBytes=65536)
    value['connectors'].append(connector);app['connectorRefs'].append(connector['id'])
    value['endpoints'].append(dict(id=ORIGIN,url=host_origin+'/host-bridge/reflection/v1',
        audienceRef='vf.reflection-resource',purpose='host-bridge'))
    value['capabilities'].append(dict(descriptor=deepcopy(DESCRIPTOR),connectorRef=connector['id'],
        toolName='ReadSelectedMemoryRuleGap',inputContract='ReadToolArguments',outputContract='EvidencePage'))
    value['bots'].append(dict(id=BOT,revision=1,promptRef='vf.selected-memory-rule-gap/1',modelProfile='deterministic/1',
        capabilityCeiling=[CAPABILITY],budget=dict(maxStages=1,maxChildren=0,maxTokens=1,maxToolCalls=1,
            maxNativeJobs=0,deadlineMs=120000),kbProfile='public/1',enabled=True))
    app['catalogHash']=digest('manifest',[item['descriptor'] for item in value['capabilities']])
    app['schemaHash']=digest('manifest',[app['schemaHash'],'selected-memory-rule-gap/1'])
    validate_contract('HostRegistration',value);return value


def source_id(entry,generation):return f'{entry.id}/{entry.version}/{generation}'


def selected_id(value):
    try:
        ident,version,generation=value.split('/')
        if str(UUID(ident))!=ident or str(int(version))!=version or str(int(generation))!=generation:
            raise ValueError()
        if not 1<=int(version)<=2**53-1 or not 1<=int(generation)<=2**53-1:raise ValueError()
        return UUID(ident),int(version),int(generation)
    except (ValueError,AttributeError):raise OSErrorCode('DENIED') from None


class FamilyReflectionMemory:
    def __init__(self,runtime,artifacts):
        self.runtime,self.store=runtime,runtime.store
        self.jobs=runtime.inference_jobs;self.knowledge=runtime.classified_knowledge
        if self.jobs is None or self.knowledge is None:raise ValueError('Canonical inference consent/account placement required')
        self.artifacts=artifacts

    def _owner(self,db,subject,fact=None):
        _,_,settings=self.jobs._owner(db,subject,fact)
        grant=settings.choice.get('inferenceConsent')
        if (not settings.choice['useMemory'] or not grant or not permits(grant,generation=grant['generation'],
                category='personal-context',purpose='assistant.reflect/1')):raise OSErrorCode('DENIED')
        return grant['generation']

    def _entries(self,db,subject):
        values=list(db.scalars(select(Entry).join(Binding,Binding.revision_id==Entry.active_revision_id).where(
            *scoped(Entry,subject),*scoped(Binding,subject),Entry.state=='ACTIVE',
            Binding.content_kind=='personal-context',Binding.directed_source_id.is_not(None))
            .order_by(Entry.id).limit(65)))
        if len(values)>64:raise OSErrorCode('CAPACITY')
        return values

    def bounds_tx(self,db,subject,fact):
        generation=self._owner(db,subject,fact);ids=[]
        for entry in self._entries(db,subject):
            binding=db.get(Binding,entry.active_revision_id)
            source=db.scalar(select(Source).where(*scoped(Source,subject),Source.id==binding.directed_source_id))
            if (source and source.state=='AVAILABLE' and source.envelope is not None and source.expires_at>utcnow()
                    and (entry.valid_until is None or entry.valid_until>utcnow()) and current_origin(db,source)):
                ids.append(source_id(entry,generation))
        return ids

    async def bounds(self,subject):
        fact=await self.jobs.accounts.check(subject)
        def load():
            with self.store.transaction() as db:return self.bounds_tx(db,subject,fact)
        return await asyncio.to_thread(load)

    def guard(self,db,subject,external_id,*,fact=None,content=False):
        ident,version,generation=selected_id(external_id)
        if self._owner(db,subject,fact)!=generation:raise OSErrorCode('DENIED')
        entry=db.scalar(select(Entry).where(*scoped(Entry,subject),Entry.id==ident).with_for_update())
        if entry is None or entry.state!='ACTIVE' or entry.version!=version:raise OSErrorCode('DENIED')
        binding=db.get(Binding,entry.active_revision_id)
        if binding is None or binding.content_kind!='personal-context' or binding.directed_source_id is None:
            raise OSErrorCode('DENIED')
        source=db.scalar(select(Source).where(*scoped(Source,subject),Source.id==binding.directed_source_id).with_for_update())
        if (source is None or source.state!='AVAILABLE' or source.envelope is None or source.expires_at<=utcnow()
                or entry.valid_until is not None and entry.valid_until<=utcnow() or not current_origin(db,source)):
            raise OSErrorCode('DENIED')
        if not content:return
        actor=SimpleNamespace(subject=subject)
        material=self.knowledge.materialize(db,actor,[entry])[entry.id]
        if material['state']!='ACTIVE' or material['content'] is None:raise OSErrorCode('DENIED')
        origin=db.scalar(select(Origin).where(*scoped(Origin,subject),Origin.source_id==source.id))
        if origin is None or origin.authorization_basis!='owner-directed-turn/1':raise OSErrorCode('DENIED')
        names=self._references(db,subject,origin.task_id)
        # An edit cannot silently retain an unrelated original member/place.
        text=material['content']['text'].casefold()
        if any(label.casefold() not in text for label in (names['memberName'],names['placeName'])):
            raise OSErrorCode('DENIED')
        return dict(names,sourceExpiresAt=source.expires_at)

    def _artifact(self,db,subject,ident,expected,size):
        artifact=db.scalar(select(Artifact).where(*scoped(Artifact,subject),Artifact.id==ident))
        if (artifact is None or artifact.expires_at<=utcnow() or artifact.ciphertext_digest!=expected
                or self.artifacts.pin(str(ident))['ciphertextDigest']!=expected):raise OSErrorCode('DENIED')
        raw=self.artifacts.read(subject,str(ident),purpose='artifact')
        if len(raw)!=size:raise OSErrorCode('DENIED')
        return parse_canonical_json(raw)

    def _references(self,db,subject,task_id):
        task=db.scalar(select(Task).where(*scoped(Task,subject),Task.id==task_id))
        admission=db.scalar(select(Admission).where(*scoped(Admission,subject),Admission.task_id==task_id))
        root=db.scalar(select(BudgetRoot).where(*scoped(BudgetRoot,subject),BudgetRoot.root_task_id==task_id))
        if task is None or task.state!='COMPLETED' or admission is None or root is None or root.state!='CLOSED':
            raise OSErrorCode('DENIED')
        write=db.scalar(select(AgentPayloadWrite).where(*scoped(AgentPayloadWrite,subject),
            AgentPayloadWrite.id==uuid5(task_id,'read-goal/1'),AgentPayloadWrite.task_id==task_id,
            AgentPayloadWrite.root_id==root.id,AgentPayloadWrite.schema_ref=='AgentReadGoalRecord'))
        ready=db.scalar(select(AgentPrivatePayload).where(AgentPrivatePayload.write_id==write.id)) if write else None
        if (write is None or ready is None or write.expires_at<=utcnow()
                or db.get(WorkAttempt,write.attempt_id).state!='SETTLED'):raise OSErrorCode('DENIED')
        record=self._artifact(db,subject,ready.id,ready.ciphertext_digest,write.plain_bytes)
        validate_contract('AgentReadGoalRecord',record);goal=record['goal']
        if goal['context']!=admission.context:raise OSErrorCode('DENIED')
        selected={r['externalId'] for c in goal['criteria'] if c['capability']['ref']=='vf.GetSavedLocationWithGeofences'
            for r in c['resources']}
        if not selected:raise OSErrorCode('DENIED')
        members=set();places=set()
        # Read only this completed source task's accepted lookup/detail pages.
        calls=db.execute(select(AgentToolCall,AgentToolAcceptance).join(AgentToolAcceptance,
            AgentToolAcceptance.call_id==AgentToolCall.id).where(*scoped(AgentToolCall,subject),
            *scoped(AgentToolAcceptance,subject),AgentToolCall.root_id==root.id).order_by(AgentToolCall.id).limit(17)).all()
        if len(calls)>16:raise OSErrorCode('CAPACITY')
        for call,accepted in calls:
            ref=call.request['record']['capability']['ref']
            if ref not in {'vf.LookupMemberByName','vf.GetSavedLocationWithGeofences'}:continue
            if call.request['record']['context']!=admission.context:raise OSErrorCode('DENIED')
            archive=db.get(AgentToolArchive,accepted.artifact_id);slot=db.get(AgentToolSlot,call.id)
            finish=db.get(AgentToolFinish,call.id)
            if (not archive or not slot or not finish or finish.kind!='candidate' or archive.slot_id!=call.id
                    or slot.artifact_id!=archive.id or db.get(WorkAttempt,call.attempt_id).state!='SETTLED'
                    or db.get(WorkAttempt,slot.attempt_id).state!='SETTLED'):raise OSErrorCode('DENIED')
            page=self._artifact(db,subject,archive.id,archive.ciphertext_digest,archive.plain_bytes)
            validate_contract('EvidencePage',page)
            if page['evidence']['subject']!=subject or page['nextCursor'] is not None:raise OSErrorCode('DENIED')
            for resource,row in zip(page['evidence']['resourceRefs'],page['records'],strict=True):
                if resource['subject']!=subject or resource['providerId']!='vf.mcp':raise OSErrorCode('DENIED')
                fields={f['name']:f['value'] for f in row}
                if ref=='vf.LookupMemberByName':members.add((fields['memberId'],fields['displayName']))
                elif resource['externalId'] in selected:places.add((fields['savedLocationId'],fields['name']))
        if len(members)!=1 or len(places)!=1:raise OSErrorCode('DENIED')
        member,name=next(iter(members));place,label=next(iter(places))
        return dict(memberId=member,memberName=name,placeId=place,placeName=label)

    async def selected(self,subject,external_id):
        fact=await self.jobs.accounts.check(subject)
        def load():
            with self.store.transaction() as db:return self.guard(db,subject,external_id,fact=fact,content=True)
        return await asyncio.to_thread(load)


class FamilyReflectionHost(FamilyScheduledMemoryHost):
    reflection=None

    async def dispatch(self,action,body):
        if action=='capabilities':
            result=await super().dispatch(action,body)
            if self.reflection is not None and set(TOOLS)<=set(self.control(body['subject'])['tools']):
                result['capabilities'].append(deepcopy(DESCRIPTOR))
            return result
        if body.get('capabilityRef')!=CAPABILITY:return await super().dispatch(action,body)
        control=self.control(body['subject'])
        if (self.reflection is None or action!='authority/check' or body.get('purpose')!='assistant.read'
                or body.get('delegationRef') is not None or not set(TOOLS)<=set(control['tools'])):raise OSErrorCode('DENIED')
        ids=await self.reflection.bounds(body['subject'])
        if not ids or self.control(body['subject'])!=control:raise OSErrorCode('DENIED')
        now=utcnow()
        return dict(id=str(uuid4()),subject=body['subject'],active=True,policyGeneration=control['policyGeneration'],
            capabilityRefs=[CAPABILITY],resourceBounds=[dict(resourceType=RESOURCE,externalIds=ids,fieldNames=list(FIELDS))],
            purpose='assistant.read',checkedAt=iso(now),validUntil=iso(now+timedelta(seconds=15)),
            assuranceRef=self.authority_profile,delegationRef=None)


class FamilyReflectionSource:
    def __init__(self,runtime,host,memory):self.runtime,self.host,self.memory=runtime,host,memory

    async def read(self,subject,configuration,authority,*,before_execute=None):
        arguments=configuration['arguments'];validate_contract('ReadToolArguments',arguments)
        if (configuration['capabilityRef']!=CAPABILITY or arguments['resourceType']!=RESOURCE
                or len(arguments['externalIds'])!=1 or arguments['fieldNames']!=list(FIELDS)):raise OSErrorCode('DENIED')
        ident=arguments['externalIds'][0];selected=await self.memory.selected(subject,ident)
        control=deepcopy(self.host.control(subject))
        if selected['memberId'] not in control['memberIds'] or not set(TOOLS)<=set(control['tools']):raise OSErrorCode('DENIED')
        if before_execute is not None:await before_execute()
        documents=[]
        async def call(tool,args):
            if self.host.control(subject)!=control:raise OSErrorCode('DENIED')
            await self.memory.selected(subject,ident)
            token=self.host.credential(subject,tool,iso(utcnow()+timedelta(seconds=15)))
            descriptors=await self.host.mcp.request(token)
            if self.host.contracts.tools[tool] not in descriptors:raise OSErrorCode('PROFILE_DISABLED')
            result=await self.host.mcp.request(token,tool=tool,arguments=args)
            FamilyReadMapping(self.host.contracts.tools[tool]).source(result)
            if self.host.control(subject)!=control:raise OSErrorCode('DENIED')
            await self.memory.selected(subject,ident);documents.append(result);return result
        lookup=await call(TOOLS[0],dict(displayName=selected['memberName']))
        selected_documents=dict(members=lookup['members'])
        status='Clarification needed';suggestion='Reconfirm the selected member and place in a fresh conversation.'
        if len(lookup['members'])==1 and lookup['members'][0]['memberId']==selected['memberId']:
            locations=await call(TOOLS[1],{})
            matches=[r for r in locations['savedLocations'] if r['name'].casefold()==selected['placeName'].casefold()]
            selected_documents['places']=matches
            if len(matches)==1 and matches[0]['id']==selected['placeId']:
                detail=await call(TOOLS[2],dict(savedLocationId=selected['placeId']))
                selected_documents['detail']=detail
                if detail['id']!=selected['placeId'] or detail['name']!=matches[0]['name']:raise OSErrorCode('DENIED')
                exists=any(r['memberId']==selected['memberId'] for r in detail['geofences'])
                status='Rule already exists' if exists else 'Boundary rule missing'
                suggestion='No new boundary rule is proposed.' if exists else 'Review a boundary alert for this member and place. Nothing has been changed.'
        values=(selected['memberName'],selected['placeName'],status,suggestion,len(documents))
        resources=[dict(subject=deepcopy(subject),providerId=ORIGIN,resourceType=RESOURCE,contractVersion=1,
            externalId=ident,observedVersion=digest('evidence',dict(member=selected['memberId'],place=selected['placeId'],
                sourceVersion=FamilyReadMapping.version(selected_documents))))]
        evidence=dict(id=str(uuid4()),subject=deepcopy(subject),providerRef=ORIGIN,resourceRefs=resources,
            observedAt=iso(utcnow()),classification='host-authorized',quality='synthetic',completeness='1.00',
            publicFields=list(FIELDS),formatterRef='poc-tool-table',formatterVersion=1)
        records=[[dict(name=k,value=v) for k,v in zip(FIELDS,values,strict=True)]]
        evidence['coreDigest']=digest('evidence',dict(evidence=evidence,records=records))
        page=dict(evidence=evidence,records=records,nextCursor=None);validate_contract('EvidencePage',page);return page


def check_configuration(configuration,*,demo):
    calendar=configuration['calendar'];rules=configuration['notifications'];args=configuration['arguments']
    if (configuration['workflowRef']!='registered-read/1' or configuration['definitionRef']!=BOT
            or configuration['definitionRevision']!=1 or configuration['event'] is not None or calendar is None
            or calendar['mode']!='fixed-wall' or calendar['weekdays']!=list(range(7))
            or calendar['localTime']!='09:00' and not (demo and configuration['name'].startswith('Demo reflection:'))
            or calendar['windowEnd'] is not None or calendar['intervalSeconds'] is not None
            or args['resourceType']!=RESOURCE or len(args['externalIds'])!=1 or args['fieldNames']!=list(FIELDS)
            or rules['cooldownSeconds']!=86400 or not rules['onChangeOnly']
            or rules['timezone']!=calendar['timezone']):raise OSErrorCode('DENIED')
    selected_id(args['externalIds'][0])
    if configuration['name'].startswith('Demo reflection:') and not demo:raise OSErrorCode('DENIED')


def enable(runtime,host,artifacts,*,demo=False):
    from .family_schedules import FamilyScheduleSource,FamilyScheduleCatalog,FamilyScheduleAuthority
    from agentic_os.scheduling.models import ProactiveDefinition,ProactiveRevision,ProactiveRun,ProactiveNotification
    memory=FamilyReflectionMemory(runtime,artifacts);host.reflection=memory
    regular=FamilyScheduleSource(runtime,host);reflection=FamilyReflectionSource(runtime,host,memory)
    class Sources:
        async def read(self,subject,configuration,authority,*,before_execute=None):
            source=reflection if configuration['capabilityRef']==CAPABILITY else regular
            async with asyncio.timeout(15):
                return await source.read(subject,configuration,authority,before_execute=before_execute)
    source=Sources()
    class Catalog(FamilyScheduleCatalog):
        def transaction_guard(self,db,subject,configuration):
            if configuration['capabilityRef']==CAPABILITY:
                from agentic_os.memory.recovery import guard_memory
                guard_memory(db,subject,memory.jobs.settings.recovery)

        async def verify(self,actor,configuration):
            if configuration['capabilityRef']==CAPABILITY:check_configuration(configuration,demo=demo)
            return await super().verify(actor,configuration)

        def draft_guard(self,db,actor,kind,configuration,definition_id):
            if configuration['capabilityRef']!=CAPABILITY:return None
            if kind!='schedule':raise OSErrorCode('DENIED')
            check_configuration(configuration,demo=demo)
            selected=memory.guard(db,actor.subject,configuration['arguments']['externalIds'][0],content=True)
            if timestamp(configuration['validUntil'])>selected['sourceExpiresAt']:raise OSErrorCode('DENIED')
            rows=db.execute(select(ProactiveDefinition,ProactiveRevision).join(ProactiveRevision,
                (ProactiveRevision.definition_id==ProactiveDefinition.id)&
                (ProactiveRevision.revision==ProactiveDefinition.configuration_revision)).where(
                *scoped(ProactiveDefinition,actor.subject),ProactiveRevision.configuration['capabilityRef'].astext==CAPABILITY)).all()
            if any(d.id!=definition_id and d.state not in {'removed','revoked','rejected'} for d,r in rows):
                raise OSErrorCode('CONFLICT')
            if definition_id is not None:return definition_id
            # Existing owner lock serializes the canonical definition identity.
            owner=digest('definition',dict(subject=actor.subject,rule='selected-memory-rule-gap/1'))
            return uuid5(UUID(actor.subject['applicationId']),owner+'/'+str(len(rows)+1))

        def publication_guard(self,db,principal,configuration,output):
            if configuration['capabilityRef']==CAPABILITY:
                memory.guard(db,principal.subject,configuration['arguments']['externalIds'][0])

        def notification_match(self,db,principal,configuration,output,matched):
            if configuration['capabilityRef']!=CAPABILITY:return matched
            fields={f['name']:f['value'] for f in output['read']['records'][0]}
            if fields['Status']=='Rule already exists':return False
            if db.get(ProactiveNotification,self.notification_identity(db,principal,configuration,output)) is not None:
                return False
            prior=db.scalar(select(ProactiveNotification.id).join(ProactiveRun,
                ProactiveRun.id==ProactiveNotification.run_id).join(ProactiveRevision,
                ProactiveRevision.id==ProactiveRun.revision_id).where(*scoped(ProactiveNotification,principal.subject),
                ProactiveRevision.configuration['capabilityRef'].astext==CAPABILITY,
                ProactiveNotification.created_at>utcnow()-timedelta(days=1)).limit(1))
            return matched and prior is None

        def notification_identity(self,db,principal,configuration,output):
            if configuration['capabilityRef']!=CAPABILITY:return None
            # This same canonical notification survives ACK, consent renewal,
            # and definition replacement for the same owner/object/version.
            version=output['read']['evidence']['resourceRefs'][0]['observedVersion']
            return uuid5(UUID(principal.subject['applicationId']),digest('event',dict(
                profile='selected-memory-rule-gap-notification/1',subject=principal.subject,objectVersion=version)))
    service=runtime.schedules;service.catalog=Catalog(runtime,source);service.authority=FamilyScheduleAuthority(service,source)
    # Executor/artifact placement was already bound to this exact installation.
    runtime.family_reflection=memory
    return memory
