"""External RFC8785 bytes only; never the Core authority hash format."""
import hashlib
from importlib.metadata import version
from decimal import Decimal
import math

import rfc8785
from jsonschema import Draft202012Validator,FormatChecker


def external_sha256(value):
    if version('rfc8785')!='0.1.4':raise ValueError('Pinned external JCS implementation required')
    return hashlib.sha256(rfc8785.dumps(value)).hexdigest()


def decimal_numbers(value):
    if type(value) is float:
        if not math.isfinite(value):raise ValueError('Finite external JSON numbers required')
        return Decimal(str(value))
    if type(value) is dict:return {key:decimal_numbers(child) for key,child in value.items()}
    if type(value) is list:return [decimal_numbers(child) for child in value]
    return value


def validate_external(schema,value):
    # All POC definitions are local. Never follow a server-supplied remote ref.
    nodes=0
    def inspect(node,depth=0,active=frozenset()):
        nonlocal nodes
        nodes+=1
        if depth>64 or nodes>8192:raise ValueError('External schema exceeds reviewed bounds')
        if type(node) is dict:
            if '$ref' in node:
                reference=node['$ref']
                if type(reference) is not str or not reference.startswith('#/$defs/'):
                    raise ValueError('Only local external schema definitions are supported')
                if reference in active:raise ValueError('Recursive external schema is unsupported')
                target=schema
                for part in reference[2:].split('/'):
                    target=target[part.replace('~1','/').replace('~0','~')]
                inspect(target,depth+1,active|{reference})
            for child in node.values():inspect(child,depth+1,active)
        elif type(node) is list:
            for child in node:inspect(child,depth+1,active)
    inspect(schema)
    exact=decimal_numbers(schema)
    Draft202012Validator.check_schema(exact)
    Draft202012Validator(exact,format_checker=FormatChecker()).validate(decimal_numbers(value))
