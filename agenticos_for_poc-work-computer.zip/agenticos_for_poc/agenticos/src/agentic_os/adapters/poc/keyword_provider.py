"""One pinned real inference call for the canonical keyword learning job.

The fixed installed SDK still constructs and validates the memory proposal.
This parent-side provider owns only bounded HTTP and measured numeric usage;
the existing learning job owns authority, publication and uncertainty.
"""
from copy import deepcopy

import httpx

from agentic_os.adapters.mem0.stage import ExtractorReply
from agentic_os.contracts.canonical import canonical_bytes,digest
from agentic_os.contracts.validation import validate_contract,schema_registry
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import timestamp,utcnow
from agentic_os.production.model_policy import validate_meter

ENDPOINT='https://api.openai.com/v1/responses'


def response_schema():
    """Constrain shape to the frozen reply; SDK/Core still validate authority."""
    definitions=schema_registry()['$defs']
    def expand(value):
        if type(value) is list:return [expand(v) for v in value]
        if type(value) is not dict:return value
        if '$ref' in value:
            reference=value['$ref']
            if not reference.startswith('#/$defs/'):raise ValueError('Only packaged inference contracts are permitted')
            return expand(definitions[reference.removeprefix('#/$defs/')])
        result={k:expand(v) for k,v in value.items() if k not in {'const','uniqueItems'}}
        if 'const' in value:
            selected=value['const'];result.update(type={str:'string',int:'integer',type(None):'null'}[type(selected)],enum=[selected])
        if result.get('type')=='object' and (result.get('additionalProperties') is not False
                or set(result.get('required',[]))!=set(result.get('properties',{}))):
            raise ValueError('Closed complete inference objects are required')
        return result
    return expand(definitions['AgentKeywordInferenceReply'])


class QualifiedKeywordProvider:
    def __init__(self,*,meter,credential,reserve_job,observe,local_synthetic=False,configured=False,network_transport=None):
        validate_meter(meter)
        if (type(local_synthetic) is not bool or type(configured) is not bool or local_synthetic==configured
                or (meter['model']['provider'],meter['model']['modelId']) not in {
                    ('openai','gpt-5.4-mini-2026-03-17'),('anthropic','claude-haiku-4-5-20251001')}
                or not all(callable(v) for v in (credential,reserve_job,observe))
                or network_transport is not None and type(network_transport) is not httpx.MockTransport):
            raise ValueError('Explicit original-job synthetic inference qualification required')
        self.meter=deepcopy(meter);self.credential=credential
        self.reserve_job,self.observe,self.network_transport=reserve_job,observe,network_transport

    async def complete(self,*args,**kwargs):raise OSErrorCode('PROFILE_DISABLED')

    async def bind_learning_job(self,binding):
        if type(binding) is not dict or set(binding)!={'subject','jobId','leaseId'}:raise OSErrorCode('DENIED')
        validate_contract('SubjectRef',binding['subject'])
        context=await self.reserve_job(deepcopy(binding),deepcopy(self.meter))
        if (type(context) is not dict or any(context.get(key)!=binding[key] for key in binding)
                or context.get('profile')!='keyword-inference/1' or context.get('promptRef')!='owner-turn-inference/1'
                or context.get('budget',{}).get('providerCalls')!=1
                or context['budget'].get('inputTokens')!=16384 or context['budget'].get('outputTokens')!=2048
                or context['budget'].get('costMicros')!=100000
                or not 0<(timestamp(context['leaseUntil'])-utcnow()).total_seconds()<=45
                or timestamp(context['leaseUntil'])>timestamp(context['expiresAt'])):
            raise OSErrorCode('DENIED')
        return _BoundKeywordProvider(self,context)


class _BoundKeywordProvider:
    def __init__(self,parent,context):self.parent,self.context,self.used=parent,deepcopy(context),False

    async def complete(self,messages,*,profile,max_output_tokens):
        parent=self.parent;meter=parent.meter
        if (self.used or profile!='keyword-inference/1' or type(max_output_tokens) is not int or max_output_tokens!=2048
                or type(messages) is not list or len(messages)!=2
                or any(type(m) is not dict or set(m)!={'role','content'} or m['role']!=role
                    or type(m['content']) is not str for m,role in zip(messages,('system','user'),strict=True))):
            raise OSErrorCode('DENIED')
        self.used=True
        remaining=(timestamp(self.context['leaseUntil'])-utcnow()).total_seconds()
        if remaining<=0:raise OSErrorCode('DENIED')
        body=dict(model=meter['model']['modelId'],input=deepcopy(messages),max_output_tokens=2048,
            reasoning=dict(effort='none'),text=dict(format=dict(type='json_schema',name='owner_memory_inference',
                strict=True,schema=response_schema())),
            store=False,background=False,service_tier='default',stream=False)
        anthropic=meter['model']['provider']=='anthropic'
        if anthropic:
            # The installed SDK and Core validate the full original contract.
            # Give Claude the shape without unsupported decoding constraints.
            def supported(schema):
                if isinstance(schema,list):return [supported(v) for v in schema]
                if not isinstance(schema,dict):return schema
                return {k:({name:supported(v) for name,v in item.items()} if k=='properties' else supported(item))
                    for k,item in schema.items() if k not in {'minimum','maximum','maxLength','minLength',
                        'minItems','maxItems','pattern','uniqueItems'}}
            body=dict(model=meter['model']['modelId'],system=messages[0]['content'],messages=[messages[1]],
                max_tokens=2048,thinking=dict(type='disabled'),service_tier='standard_only',
                output_config=dict(format=dict(type='json_schema',schema=supported(response_schema()))),stream=False)
        raw=canonical_bytes(body)
        # One UTF-8 byte per possible token plus a conservative fixed envelope
        # keeps this call inside the unchanged 16384-input-token job ceiling.
        if len(raw)>min(15872,meter['maxRequestBytes']):raise OSErrorCode('CAPACITY')
        record=dict(context=self.context,meterDigest=digest('policy',meter),requestDigest=digest('command',body))
        try:
            key=parent.credential()
            if (type(key) is not str or not key.startswith('sk-ant-' if anthropic else 'sk-')
                    or not anthropic and key.startswith('sk-ant-') or any(c.isspace() for c in key)):
                raise OSErrorCode('PROFILE_DISABLED')
            async with httpx.AsyncClient(trust_env=False,follow_redirects=False,
                    timeout=min(20,meter['requestTimeoutMs']/1000,remaining),transport=parent.network_transport) as client:
                auth={'x-api-key':key,'anthropic-version':'2023-06-01'} if anthropic else {'Authorization':'Bearer '+key}
                endpoint='https://api.anthropic.com/v1/messages' if anthropic else ENDPOINT
                async with client.stream('POST',endpoint,content=raw,headers={
                        **auth,'Content-Type':'application/json','Accept-Encoding':'identity'}) as response:
                    if response.status_code!=200 or response.headers.get('content-encoding','identity')!='identity':
                        raise OSErrorCode('UNAVAILABLE')
                    chunks=bytearray()
                    async for chunk in response.aiter_bytes():
                        chunks.extend(chunk)
                        if len(chunks)>meter['maxResponseBytes']:raise OSErrorCode('CAPACITY')
                    from agentic_os.production.provider_json import provider_json
                    value=provider_json(bytes(chunks),maximum=meter['maxResponseBytes']);request_id=response.headers.get('x-request-id') or response.headers.get('request-id')
            usage=value.get('usage');identifier=value.get('id')
            if (value.get('model')!=meter['model']['modelId'] or type(identifier) is not str or not 1<=len(identifier)<=256
                    or type(usage) is not dict or any(type(usage.get(k)) is not int or not 0<=usage[k]<=2**53-1
                        for k in ('input_tokens','output_tokens'))):raise OSErrorCode('UNAVAILABLE')
            pricing=meter['pricing']['microsPerMillion']
            cost=(usage['input_tokens']*pricing['uncachedInput']+usage['output_tokens']*pricing['output']+999999)//1000000
            if anthropic:
                if (usage.get('service_tier') not in (None,'standard') or usage.get('inference_geo') not in (None,'global','not_available')
                        or any(usage.get(k) not in (None,0) for k in ('cache_read_input_tokens','cache_creation_input_tokens'))
                        or usage.get('server_tool_use')):raise OSErrorCode('UNAVAILABLE')
                blocks=value.get('content',[])
                output=[dict(type='message',role='assistant',content=[dict(type='output_text',text=b['text'])])
                    if b.get('type')=='text' else dict(type='function_call') for b in blocks]
                complete=value.get('stop_reason')=='end_turn'
            else:
                output=value.get('output',[])
                complete=value.get('status')=='completed' and value.get('error') is None
            if type(output) is not list:output=[]
            assistants=[o for o in output if type(o) is dict and o.get('type')=='message' and o.get('role')=='assistant']
            content=''
            if len(assistants)==1:
                parts=assistants[0].get('content',[])
                if (type(parts) is list and len(parts)==1 and type(parts[0]) is dict
                        and parts[0].get('type')=='output_text' and type(parts[0].get('text')) is str):
                    content=parts[0]['text']
            tools=tuple('unexpected-tool-call' for o in output if type(o) is dict and o.get('type')=='function_call')
            # Known usage is returned even for incomplete/invalid model JSON;
            # the installed SDK rejects it after canonical numeric settlement.
            if not complete:content=''
            record.update(state='KNOWN',providerUsageRef=identifier,providerRequestRef=request_id,
                usage=dict(inputTokens=usage['input_tokens'],outputTokens=usage['output_tokens'],costMicros=cost))
            try:
                from agentic_os.contracts.canonical import parse_canonical_json
                validate_contract('AgentKeywordInferenceReply',parse_canonical_json(content))
                record['proposalSchemaValid']=True
            except Exception:record['proposalSchemaValid']=False
            await parent.observe(record)
            return ExtractorReply(content,usage['input_tokens'],usage['output_tokens'],cost,tools)
        except Exception as error:
            record.update(state='UNKNOWN',errorType=type(error).__name__)
            await parent.observe(record)
            raise OSErrorCode('UNAVAILABLE') from None
