"""Explicit local P0 registration and immutable bounded inference profile."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from agentic_os.contracts.canonical import digest
from agentic_os.contracts.validation import schema_registry,validate_contract
from agentic_os.production.profiles import version_pin
from agentic_os.production.resources import vector
from agentic_os.production.execution import DIRECT_PROFILE,TEMPORAL_PROFILE


def schema_json(name):
    # The transport schema uses the existing bounded capability profile.
    # Full EvidencePage validation still runs before observation acceptance;
    # its regex/uniqueness checks are not executable transport schema features.
    definitions=schema_registry()['$defs']
    def expand(value):
        if type(value) is list:return [expand(child) for child in value]
        if type(value) is not dict:return value
        if '$ref' in value:return expand(definitions[value['$ref'].removeprefix('#/$defs/')])
        result={key:expand(child) for key,child in value.items() if key not in {'pattern','uniqueItems'}}
        if 'const' in result and 'type' not in result:
            result['type']={str:'string',int:'integer',bool:'boolean',type(None):'null'}[type(result['const'])]
        if result.get('type')=='string':result.setdefault('maxLength',256)
        return result
    return json.dumps(expand(definitions[name]),sort_keys=True,separators=(',',':'))


def descriptor(tool):
    return dict(id='vf.'+tool['name'],revision=1,inputSchemaRef='GovernedToolArguments',
        outputSchemaRef='EvidencePage',originRef='vf.mcp',kind='read',riskFloor='low',
        scopeResolverRef='vf.current-owner',timeoutMs=3000,guaranteeProfile='current-read/1')


def registration(namespace,host_origin,mcp_origin,tools,*,embed_ref='vf.poc.embed/1'):
    guarantees=dict(currentAuthority=True,typedValidation=False,transactionalReceipt=False,
        authoritativeLookup=False,liveRevocation=True,stableEvents=True)
    descriptors=[descriptor(tool) for tool in tools]
    catalog=digest('manifest',descriptors)
    bundle=dict(application=dict(**namespace,revision=1,generation=1,name='Verizon Family synthetic POC',
        issuerRef='vf.poc.issuer',bridgeRef='vf.bridge',embedRefs=[embed_ref],connectorRefs=['vf.connector'],
        profileRef='poc-frame/1',schemaHash=digest('manifest',[tool['inputSchema'] for tool in tools]),
        catalogHash=catalog,lanes=['interactive-read'],guarantees=guarantees,retentionDays=30,
        residencyRef='local-synthetic',credentialRef='vf.bridge-key/1',active=True),
        endpoints=[dict(id='vf.bridge',url=host_origin+'/host-bridge/v1',audienceRef='vf.bridge-resource',purpose='host-bridge'),
            dict(id='vf.mcp',url=mcp_origin,audienceRef='vf.mcp',purpose='mcp')],
        connectors=[dict(id='vf.connector',revision=1,capabilityRefs=[v['id'] for v in descriptors],transport='mcp',
            protocolProfile='mcp/2025-11-25',endpointRef='vf.mcp',credentialRef='vf.mcp-registration/1',
            authorityProfile='current-read/1',timeoutMs=3000,maxResponseBytes=1048576,conformance='qualified',guarantees=guarantees)],
        embeds=[dict(id=embed_ref,**namespace,parentOrigin=host_origin,clientProfile='poc-frame/1',
            catalogRefs=['agentic-os.safe/0.9.1'],active=True)],
        clientProfiles=[dict(id='poc-frame/1',revision=1,catalogRefs=['agentic-os.safe/0.9.1'],
            assurance='local-synthetic',maxSurfaceBytes=65536,fetchSSE=True,highRiskReview=False)],
        capabilities=[dict(descriptor=value,connectorRef='vf.connector',toolName=tool['name'],
            inputContract=value['inputSchemaRef'],outputContract='EvidencePage') for tool,value in zip(tools,descriptors,strict=True)],
        bots=[dict(id='vf.assistant',revision=1,promptRef='vf.application-knowledge/1',modelProfile='deterministic-p0/1',
            capabilityCeiling=[v['id'] for v in descriptors],budget=dict(maxStages=8,maxChildren=0,maxTokens=1000,
                maxToolCalls=16,maxNativeJobs=0,deadlineMs=120000),kbProfile='public/1',enabled=True)])
    validate_contract('HostRegistration',bundle)
    return bundle


def admission_profile(sdk_lock,*,direct=True):
    runtime=dict(id='poc-runtime/1',revision=1,workflowProfile=DIRECT_PROFILE if direct else TEMPORAL_PROFILE,
        authorizationHorizonMs=120000,maxActiveTasks=2,timeZone='America/New_York')
    capabilities=dict(id='poc-read-capabilities/1',revision=1,purpose='assistant.read',
        capabilityPrefixes=['vf.'],allowedKinds=['read'])
    resources=dict(schema='agent-resources/1',limits=vector(tokens=1000,costMicros=1000,workMs=120000,
        computeMs=120000 if direct else 0,storageBytes=8*1048576),costCurrency='USD',requestTimeoutMs=30000,
        allowResourceGrants=False,exhaustion='wait')
    pricing=dict(id='poc-synthetic-pricing/1',revision=1,currency='USD',microsPerMillion=dict(
        uncachedInput=1000000,cachedInput=100000,cacheWrite5m=1250000,cacheWrite1h=2000000,output=4000000))
    model=dict(id='poc-deterministic-model/1',revision=1,provider='openai',api='responses',
        modelId='gpt-5.4-mini-2026-03-17',modelRevision='2026-03-17',floatingAliasAllowed=False,
        endpointRef='poc-deterministic-responses/1',credentialRef='poc-no-paid-credential/1',pricing=version_pin(pricing),
        retention=dict(ref='poc-no-external-retention/1',revision=1,digest='b'*64),
        residency=dict(ref='poc-offline-fixture/1',revision=1,digest='c'*64),hostedToolPolicyRef=None,lifecycle='qualified')
    harness=dict(dependencyLockDigest=hashlib.sha256(Path(sdk_lock).read_bytes()).hexdigest(),
        checkpointFormat='openai-agents/0.19.4/run-state/1.13',features=['reactive-loop','durable-checkpoint'],
        totalTurnLimit='none',contentTracing='disabled')
    harness['harness']=dict(ref='poc-sdk-read/1',revision=1,digest=digest('manifest',harness))
    definition=dict(schema='agent-production/1',id='poc-family-assistant/1' if direct else 'poc-baseline-assistant/1',revision=2 if direct else 1,
        profile=version_pin(runtime),harness=harness['harness'],model=version_pin(model),
        resourcePolicy=dict(ref='poc-resource-policy/1',revision=1,digest=digest('policy',resources)),
        capabilityPolicy=version_pin(capabilities,'policy'),purpose=capabilities['purpose'],lifecycle='qualified')
    profile=dict(definition=definition,runtime=runtime,harness=harness,model=model,resources=resources,
        grantCeiling=deepcopy(resources['limits']),capabilities=capabilities)
    validate_contract('AgentAdmissionProfile',profile)
    meter=dict(model=model,pricing=pricing,contextWindowTokens=128,maxOutputTokens=32,maxRequestBytes=65536,
        maxResponseBytes=8192,requestTimeoutMs=5000)
    validate_contract('AgentModelMeterPolicy',meter)
    return profile,meter


def wrapped_capability(tool,mapping,mcp_url):
    input_json=json.dumps(tool['inputSchema'],sort_keys=True,separators=(',',':'))
    output_json=schema_json('EvidencePage')
    connection=dict(id='poc-vf-wrapped-mcp/1',revision=1,endpointRef='vf.mcp',audienceRef='vf.mcp',url=mcp_url,
        network='owned-local-http/1',protocolVersion='2025-11-25',catalogCapabilityRef='vf.'+tool['name'],
        requestTimeoutMs=3000,maxRequestBytes=65536,maxResponseBytes=131072,maxToolsPerPage=9)
    value=dict(id='vf.'+tool['name'],revision=1,kind='read',purpose='assistant.read',title=tool['name'],
        description=(tool['description'] or tool['name'])[:160]+' [trusted DTO mapping '+mapping.pin[:16]+']',
        adapterRef='poc.mcp.read/1',scopePolicyRef='vf.current-owner',inputSchemaJson=input_json,
        outputSchemaJson=output_json,mcp=dict(connection=connection,binding=dict(toolName=tool['name'],
            schemaCursor=None,inputSchemaJson=input_json,outputSchemaJson=output_json)),lifecycle='qualified')
    validate_contract('AgentCapabilityRegistration',value)
    return value
