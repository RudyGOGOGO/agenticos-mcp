"""Canonical reviewed provider over the committed Verizon MCP/receipt wire.

Encrypted immutable transport arguments preserve the observation mapping after
source expiry or Stop. They contain no execution state, permit or cached result;
the original WorkAttempt/grant and the backend remain the only authorities.
"""
import asyncio
from copy import deepcopy
import json
from pathlib import Path
from uuid import UUID

from sqlalchemy import select

from agentic_os.adapters.local.artifacts import LocalKeys
from agentic_os.adapters.local.files import private_read, private_write
from agentic_os.adapters.local.resources import ensure_private
from agentic_os.adapters.postgres.models import WorkAttempt
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.service import scoped
from .effect_context import EffectContextSigner
from .receipt_observation import canonical_outcome


class ExternalRequestArtifacts:
    def __init__(self, directory, keys):
        if type(keys) is not LocalKeys:
            raise ValueError('Existing installation encryption keys required')
        self.directory, self.keys = Path(directory), keys
        ensure_private(self.directory)

    @staticmethod
    def identity(grant):
        return {key: deepcopy(grant[key]) for key in
            ('subject', 'invocationId', 'effectRequestDigest', 'providerRef', 'capabilityRef', 'grantDigest')}

    def path(self, grant):
        return self.directory / (str(UUID(grant['invocationId'])) + '.json')

    def create(self, grant, request, resource_type):
        value = dict(identity=self.identity(grant), request=deepcopy(request), resourceType=resource_type)
        envelope = self.keys.encrypt(grant['subject'], 'artifact',
            json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode(),
            artifact_id=grant['invocationId'])
        try:
            private_write(self.path(grant), canonical_bytes(envelope))
        except FileExistsError:
            # Even identical transport material cannot authorize a second send.
            raise OSErrorCode('CONFLICT') from None
        return value

    def read(self, grant):
        try:
            envelope = parse_canonical_json(private_read(self.path(grant), 32768))
            from agentic_os.production.provider_json import provider_json
            value = provider_json(self.keys.decrypt(grant['subject'], 'artifact', envelope,
                artifact_id=grant['invocationId']), maximum=32768)
        except (OSError, ValueError):
            raise OSErrorCode('UNAVAILABLE') from None
        if (set(value) != {'identity', 'request', 'resourceType'}
                or value['identity'] != self.identity(grant)
                or value['request']['idempotencyKey'] != grant['invocationId']):
            raise OSErrorCode('CONFLICT')
        return value


class VerizonEffectProvider:
    def __init__(self, *, permits, providers, signer, observer, artifacts, host, resource_type):
        from agentic_os.effects.reviewed_provider import ReviewedProviderRegistry
        from agentic_os.effects.reviewed_permit import ReviewedPermitService
        from .receipt_observation import ReceiptObservationClient
        if (type(permits) is not ReviewedPermitService or not permits.production
                or type(providers) is not ReviewedProviderRegistry or permits.providers is not providers
                or type(signer) is not EffectContextSigner or signer.permits is not permits
                or type(observer) is not ReceiptObservationClient
                or type(artifacts) is not ExternalRequestArtifacts):
            raise ValueError('Existing canonical production provider and pinned private adapter required')
        self.permits, self.providers, self.signer = permits, providers, signer
        self.observer, self.artifacts, self.host, self.resource_type = observer, artifacts, host, resource_type

    def admitted(self, request):
        validate_contract('EffectLookupRequest', request)
        with self.permits.store.transaction() as db:
            row = db.scalar(select(WorkAttempt).where(*scoped(WorkAttempt, request['subject']),
                WorkAttempt.invocation_id == UUID(request['invocationId']), WorkAttempt.kind == 'agent.effect'))
            if row is None or row.state not in {'RUNNING', 'UNKNOWN', 'SETTLED'}:
                raise OSErrorCode('DENIED')
            _, grant = self.permits.ledger._binding(db, row)
            if (grant['invocationId'] != request['invocationId'] or grant['providerRef'] != request['providerRef']
                    or grant['effectRequestDigest'] != request['requestDigest']
                    or grant['capabilityRef'] != self.signer.mapping.capability_ref):
                raise OSErrorCode('DENIED')
            return deepcopy(grant)

    async def observed(self, grant):
        material = await asyncio.to_thread(self.artifacts.read, grant)
        subject=(grant['subject'] if getattr(self.observer,'workload_credentials',None) is not None
            else grant['subject']['subjectId'])
        value = await self.observer.observe(material['request'], subject=subject)
        return canonical_outcome(grant, material['request'], value, resource_type=material['resourceType'])

    async def observe(self, request):
        grant = await asyncio.to_thread(self.admitted, request)
        observation, _ = await self.observed(grant)
        return observation

    async def execute(self, envelope):
        validate_contract('HostEffectEnvelope', envelope)
        effect = envelope['request']
        check = dict(subject=effect['subject'], permitRef=envelope['permitRef'], invocationId=effect['invocationId'],
            requestDigest=effect['requestDigest'], proposalDigest=envelope['proposal']['digest'],
            capabilityRef=envelope['capabilityRef'])
        # Resolve the real RUNNING attempt and original metadata. The signer
        # independently rechecks current owner/source/approval/Host authority.
        selected = await asyncio.to_thread(self.permits.candidate, check)
        grant = selected['grant']
        original = await asyncio.to_thread(self.providers.original, grant['subject'], grant['registrationRevision'],
            grant['capabilityRef'], grant['providerRef'], purpose='introspect')
        bearer = self.host.credential(grant['subject'], self.signer.mapping.tool, grant['expiresAt'])
        signed = await self.signer.sign(original['introspectionCredential'], check, bearer_token=bearer)
        if envelope['proposal']['digest'] != grant['proposalDigest']:
            raise OSErrorCode('DENIED')
        arguments, revision = self.signer.mapping.project(envelope['proposal'], original['binding'])
        if arguments != signed['arguments']:
            raise OSErrorCode('CONFLICT')
        request = dict(schema='vf.receipt-observation.request/1', tool=signed['tool'], arguments=arguments,
            idempotencyKey=grant['invocationId'], expectedRevision=revision)
        self.observer.wire.validate('Request', request)
        await asyncio.to_thread(self.artifacts.create, grant, request, self.resource_type)
        # Exactly one initial send. Any failure leaves this artifact and the
        # original attempt for read-only observation, never transport replay.
        await self.host.mcp.request(bearer, tool=signed['tool'], arguments=signed['arguments'],
            effect_context=signed['effect_context'])
        _, receipt = await self.observed(grant)
        if receipt is None:
            raise OSErrorCode('UNAVAILABLE')
        return receipt
