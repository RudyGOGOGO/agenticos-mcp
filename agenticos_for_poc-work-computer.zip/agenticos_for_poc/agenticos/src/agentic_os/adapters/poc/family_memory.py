"""Canonical keyword memory with an account-only current Host observation.

The Host does not grant memory access or return product records to learning.
Core retains all source, consent, entry, index and erasure authority.
"""
from copy import deepcopy
import hmac
from uuid import UUID


from agentic_os.adapters.http.learning_accounts import PROFILE,learning_host_binding
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from .family_composition import FamilyHostBridge
from .family_schedules import FamilyScheduledHost


def registration(bundle):
    value=deepcopy(bundle);manifest=value['application'];manifest['revision']+=1
    connector=deepcopy(value['connectors'][0])
    connector.update(id='vf.learning-account/1',capabilityRefs=[],transport='host-bridge',
        protocolProfile='host-bridge/1',endpointRef=manifest['bridgeRef'],credentialRef=manifest['credentialRef'],
        authorityProfile=PROFILE,timeoutMs=3000,maxResponseBytes=4096,conformance='qualified')
    value['connectors'].append(connector);manifest['connectorRefs'].append(connector['id'])
    validate_contract('HostRegistration',value);learning_host_binding(value)
    return value


def require_compatible_registration(registry,bundle):
    from agentic_os.adapters.postgres.models import Application
    manifest=bundle['application']
    if manifest['installationId']!=str(registry.installation_id):raise ValueError('Exact installed namespace required')
    with registry.store.transaction() as db:
        row=db.get(Application,(registry.installation_id,UUID(manifest['applicationId'])))
        if row is None:return
        current=registry.application_tx(db,manifest['applicationId'])
    if current!=bundle:
        raise ValueError('Feature composition needs a new application; preserve immutable admitted profile registrations')


def require_unique_bridge(registry,application_id,secret):
    """One service bearer must resolve one active application before genesis."""
    from sqlalchemy import select
    from agentic_os.adapters.postgres.models import Application,Registration
    with registry.store.transaction() as db:
        rows=db.execute(select(Registration.application_id,Registration.payload).join(Application,
            (Application.installation_id==Registration.installation_id)&(Application.id==Registration.application_id)&
            (Application.revision==Registration.revision)).where(Application.installation_id==registry.installation_id,
            Application.active.is_(True)).limit(65)).all()
    if len(rows)>64:raise ValueError('Bounded explicit application registration required')
    for ident,payload in rows:
        if str(ident)==application_id:continue
        try:other=registry.credential(ident,payload['application']['credentialRef'])
        except OSErrorCode:continue
        if hmac.compare_digest(other,secret):raise ValueError('A new application needs a distinct Host service credential')


class FamilyMemoryHost(FamilyHostBridge):
    def __init__(self,*,account_observer,**options):
        from .account_observation import PrivateAccountObservation
        if type(account_observer) is not PrivateAccountObservation:raise ValueError('Actual private account observer required')
        self.account_observer=account_observer;super().__init__(**options)

    async def dispatch(self,action,body):
        if action!='learning/accounts/check':return await super().dispatch(action,body)
        validate_contract('HostLearningAccountRequest',body)
        subject=body['subject'];control=self.control(subject)
        value=await self.account_observer.observe(subject)
        if self.control(subject)!=control:raise OSErrorCode('DENIED')
        # Preserve the backend's actual observation horizon; the Host does
        # not renew it or grant access to memory/content.
        return dict(subject=subject,purpose=PROFILE,active=value['active'],
            policyGeneration=control['policyGeneration'],checkedAt=value['checkedAt'],validUntil=value['validUntil'])


class FamilyScheduledMemoryHost(FamilyMemoryHost,FamilyScheduledHost):
    """One existing Host bridge with both explicitly registered features."""


def enable(runtime,journal,operator,application_id,*,capacity_root,directed=True,configured=False):
    from agentic_os.adapters.postgres.models import MemoryRecoveryProfile,MemoryControlsRecoveryProfile
    from agentic_os.adapters.local.files import private_directory
    if configured:
        from .configured_placement import configured_poc
        configured_poc(runtime)
        if not journal.is_dir() or journal.is_symlink():raise ValueError('Existing independent memory journals required')
    elif not journal.exists():private_directory(journal)
    forgetting=runtime.enable_keyword_memory_component(journal,local_synthetic=not configured,configured=configured)
    with runtime.store.transaction() as db:
        key=(runtime.registry.installation_id,UUID(application_id))
        deletion=db.get(MemoryRecoveryProfile,key);consent=db.get(MemoryControlsRecoveryProfile,key)
    if configured and (deletion is None or consent is None):
        raise ValueError('Provision both recovery profiles through the configured operator before startup')
    if deletion is None:forgetting.recovery.provision(runtime.manifest,operator,application_id)
    else:forgetting.recovery.journal(deletion).key_digest()
    if consent is None:forgetting.recovery.provision_controls(runtime.manifest,operator,application_id,capacity_root=capacity_root)
    else:forgetting.recovery.controls().journal(consent).key_digest()
    if directed:runtime.enable_directed_memory_component(local_synthetic=not configured,configured=configured)
