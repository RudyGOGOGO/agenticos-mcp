"""Explicit POC adapters; production factories never select these by default."""
