"""Read-only conversation follow-up after one canonical reviewed effect.

Only this selected POC exposes original provider receipt resource identities.
Every follow-up is a fresh editable user message, with its own admission and
approval. There is no new workflow, hidden effect or renewed old authority.
"""
import asyncio
from copy import deepcopy
from uuid import UUID
from fastapi import Request
from sqlalchemy import select
from agentic_os.adapters.postgres.models import WorkAttempt
from agentic_os.contracts.canonical import parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.effects.reviewed_executor import ReviewedEffectExecutor
from agentic_os.effects.reviewed_observer import stable_observation
from agentic_os.errors import OSErrorCode
from agentic_os.identity.service import scoped
from agentic_os.presentation.stream import opaque_id
from agentic_os.production.change_arguments import change_arguments


def resource_identity(receipt,subject):
    validate_contract('EffectReceipt',receipt)
    if receipt['subject']!=subject or receipt['status']!='COMMITTED' or len(receipt['affectedResources'])!=1:
        raise OSErrorCode('DENIED')
    resource=receipt['affectedResources'][0]
    if resource['subject']!=subject or resource['providerId']!='vf.mcp' or resource['contractVersion']!=1:raise OSErrorCode('DENIED')
    if resource['resourceType']=='saved-location':return resource,resource['externalId'],None
    if resource['resourceType']!='geofence':raise OSErrorCode('DENIED')
    identity=parse_canonical_json(resource['externalId'].encode())
    if type(identity) is not dict or set(identity)!={'savedLocationId','geofenceId'}:raise OSErrorCode('DENIED')
    if any(type(v) is not str or not v for v in identity.values()):raise OSErrorCode('DENIED')
    return resource,identity['savedLocationId'],identity['geofenceId']


class ChangeContinuations:
    def __init__(self,runtime,host,verified):self.runtime,self.host,self.verified=runtime,host,verified

    def completed_preparation(self,actor,context,verification):
        """Read historical intent data, never reauthorize its old source facts.

        get() has verified the exact owned decision/preparation/settled receipt.
        A successful write can itself invalidate its planning source (e.g. the
        saved-location collection). Reobserving that graph would reject the
        result of our own write. The immutable source reader retains current
        owner, memory, registration, exact binding and archive fences. Only the
        original remaining-request string is disclosed; fresh receipt/resource
        observation below, and a new admission/review, govern any next effect.
        """
        reference=verification['preparation']
        if reference['payload']['schemaRef']!='AgentPreparedChange':raise OSErrorCode('DENIED')
        accepted=self.verified.observations._source(actor,context,reference)
        if accepted['result']!=reference:raise OSErrorCode('DENIED')
        return accepted

    def grant(self,actor,context,reference):
        with self.verified.models.store.transaction() as db:
            self.verified.observations.fence(db,actor,context)
            work=db.scalar(select(WorkAttempt).where(*scoped(WorkAttempt,actor.subject),
                WorkAttempt.id==UUID(reference['bindingId']),WorkAttempt.task_id==UUID(context['taskId']),
                WorkAttempt.root_id==UUID(context['rootId']),WorkAttempt.kind=='agent.effect'))
            if work is None or work.state!='SETTLED' or work.actual is None:raise OSErrorCode('DENIED')
            _,grant=self.verified.ledger._binding(db,work)
            return deepcopy(grant)

    async def view(self,actor,task_id):
        reviews=self.verified.reviews
        context,original=await asyncio.to_thread(reviews._context,actor,task_id)
        await reviews.current(actor,context)
        snapshot=await self.runtime.presentation.snapshot(actor,task_id)
        if snapshot['taskState'] not in {'WAITING_APPROVAL','COMPLETED'}:return None
        reference=None;resource=None
        if snapshot['taskState']=='WAITING_APPROVAL':
            from agentic_os.admission.service import guarded_owner
            from agentic_os.production.review_amendments import current_review
            def pending():
                with reviews.store.transaction() as db:
                    guarded_owner(db,actor,read_only=True)
                    row=current_review(db,actor.subject,task_id)
                    if row is None:raise OSErrorCode('CONFLICT')
                    return str(row.id)
            review_id=await asyncio.to_thread(pending)
            _,accepted,_=await reviews.material(original,context,review_id)
        else:
            verification,_=await self.verified.get(actor,context)
            accepted=await asyncio.to_thread(self.completed_preparation,actor,context,verification)
            reference=verification['receipt']
        _,remaining=change_arguments(accepted['registration'],accepted['binding']['argumentsJson'])
        if remaining is None:return None
        if reference is not None:
            grant=await asyncio.to_thread(self.grant,actor,context,reference)
            tool=grant['capabilityRef'].removeprefix('vf.')
            provider=self.host.effects.get(tool)
            if provider is None or tool not in self.host.control(actor.subject)['tools']:raise OSErrorCode('DENIED')
            # The receipt-only method never invokes execute or issues a permit.
            observed,receipt=await provider.observed(grant)
            if stable_observation(observed)!=stable_observation(reference['observation']) or receipt is None:
                raise OSErrorCode('CONFLICT')
            ReviewedEffectExecutor.checked_receipt(receipt,grant)
            if receipt['id']!=observed['receiptId']:raise OSErrorCode('DENIED')
            resource,place,rule=resource_identity(receipt,actor.subject)
            if resource['resourceType']!=provider.resource_type:raise OSErrorCode('DENIED')
            current=await self.host.product(actor.subject,'GetSavedLocationWithGeofences',dict(savedLocationId=place))
            if current['id']!=place or rule is not None and not any(row['id']==rule for row in current['geofences']):
                raise OSErrorCode('DENIED')
            # Recheck source/account guards after the external read, before disclosure.
            if await asyncio.to_thread(self.completed_preparation,actor,context,verification)!=accepted:
                raise OSErrorCode('CONFLICT')
        fresh=await self.runtime.presentation.snapshot(actor,task_id)
        if fresh['taskState']!=snapshot['taskState']:raise OSErrorCode('CONFLICT')
        await reviews.current(actor,context)
        return dict(schema='agentic-os.change-continuation/1',subject=deepcopy(actor.subject),taskId=task_id,
            phase='ready' if reference is not None else 'pending',remainingRequest=remaining,receipt=reference,resource=resource)


def attach(app,runtime):
    @app.middleware('http')
    async def advertised(request,call_next):
        response=await call_next(request)
        if request.url.path=='/os/ui/features':response.headers['X-AgenticOS-Change-Continuation']='1'
        return response

    @app.get('/os/ui/agent-review/tasks/{task_id}/continuation')
    async def continuation(task_id:str,request:Request):
        if request.query_params:raise OSErrorCode('INVALID')
        actor=await runtime.authenticate_request(request)
        return await runtime.change_continuations.view(actor,opaque_id(task_id))
