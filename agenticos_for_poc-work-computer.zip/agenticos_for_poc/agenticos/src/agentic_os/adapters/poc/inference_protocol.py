"""One source, one typed ADD; proposals carry no publication authority."""
from copy import deepcopy
import re

from agentic_os.adapters.mem0.classified_protocol import catalog, checked_candidate as classified_candidate
from agentic_os.adapters.mem0.protocol import MAX_FRAME, uid, revision
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.contracts.errors import ContractViolation
from agentic_os.errors import OSErrorCode

PROFILE = 'keyword-inference/1'
PROMPT = 'owner-turn-inference/1'
COORDINATES=re.compile(r'[-+]?\d{1,2}\.\d{3,}\s*[,/]\s*[-+]?\d{1,3}\.\d{3,}|\b(?:latitude|longitude|lat|lon)\s*[:=]\s*[-+]?\d',re.I)


def checked_contract(name, value):
    try:
        validate_contract(name, value)
    except ContractViolation:
        raise OSErrorCode('INVALID') from None


def checked_request(value):
    checked_contract('AgentKeywordInferenceRequest', value)
    uid(value['jobId'])
    revision(value['contextRevision']); revision(value['learningEpoch'])
    contexts = catalog(value['contexts'], 16, labels=True)
    keys = catalog(value['claimKeys'], 32, labels=True)
    catalog(value['tools'], 128)
    if set(contexts) & set(keys):
        raise OSErrorCode('INVALID')
    source = value['sources'][0]
    uid(source['id']); revision(source['revision'])
    if not source['text'].strip():
        raise OSErrorCode('INVALID')
    raw = canonical_bytes(value)
    if len(raw) > MAX_FRAME:
        raise OSErrorCode('CAPACITY')
    return parse_canonical_json(raw)


def checked_candidate(value, request):
    checked_contract('AgentKeywordInferenceCandidate', value)
    classified_candidate(value, request)
    if value['content']['body']['kind'] not in request['allowedCategories']:
        raise OSErrorCode('DENIED')
    if COORDINATES.search(value['content']['text']+' '+value['content']['body'].get('value','')):
        raise OSErrorCode('INVALID')
    return value


def candidates(values, request):
    checked_contract('AgentKeywordInferenceReply', dict(candidates=values))
    for value in values:
        checked_candidate(value, request)
    return deepcopy(values)


def checked_observed(value, provider_calls):
    checked_contract('AgentKeywordInferenceObservation', value)
    if type(provider_calls) is not int or provider_calls != 1:
        raise OSErrorCode('INVALID')
