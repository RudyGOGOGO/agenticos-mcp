"""A1 Host composition with approved identity and the shared VF mappings.

This constructor never enters the local Host constructor or installs its local
bootstrap route. Public native bootstrap and authenticated private Host apps
are separate ASGI surfaces; only the former belongs on public ingress.
"""
from copy import deepcopy
import hmac
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from agentic_os.adapters.http.endpoint import reviewed_parent_origin
from agentic_os.adapters.local.resources import ensure_private
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import timestamp,iso
from .account_observation import PrivateAccountObservation
from .effect_context import EffectContracts,MUTATIONS
from .family_reflection import FamilyReflectionHost
from .family_mapping import FamilyReadMapping
from .family_schedules import TOOL
from .mcp import POCMCP
from .mcp_workload_credentials import MCPWorkloadCredentials
from .native_bootstrap import ConfiguredNativeBootstrap
from .placement import LOCAL_IDENTITY_HEADERS
from .verizon_host import resource_contract


class ConfiguredFamilyHost(FamilyReflectionHost):
    authority_profile='vf.current-account/1'

    def __init__(self,*,target,namespace,tenant,origin,os_origin,embed_ref,bridge_key,effect_key,observer_key,
            controls_file,contracts,stage_directory,keys,mcp_url,mcp_ca_file,mcp_ca_sha256,account_observer,
            workload_credentials,native_verifier,client_profile,session_file,session_key_file,core_ca_file,core_ca_sha256):
        if (target!='aws-test' or type(contracts) is not EffectContracts
                or type(account_observer) is not PrivateAccountObservation or account_observer.network!='web-pki/1'
                or type(workload_credentials) is not MCPWorkloadCredentials
                or workload_credentials.namespace!=namespace or workload_credentials.tenant!=tenant
                or workload_credentials.wire['environment']!=account_observer.environment
                or account_observer.namespace!=namespace or mcp_ca_file is None or mcp_ca_sha256 is None
                or native_verifier.public_key_sha256 in {workload_credentials.execution['public_key_sha256'],
                    workload_credentials.observer['public_key_sha256']}
                or any(type(secret) is not str or not 32<=len(secret)<=256 for secret in (bridge_key,effect_key,observer_key))
                or any(hmac.compare_digest(a,b) for a,b in ((bridge_key,effect_key),(bridge_key,observer_key),(effect_key,observer_key)))):
            raise ValueError('Explicit configured Host and disjoint approved service identities required')
        self.namespace,self.tenant=deepcopy(namespace),tenant
        self.origin=reviewed_parent_origin(origin,'web-pki/1');self.os_origin=reviewed_parent_origin(os_origin,'web-pki/1')
        self.embed_ref,self.bridge_key=embed_ref,bridge_key
        self.controls_file=Path(controls_file);self.contracts,self.keys=contracts,keys
        self.stage_directory=Path(stage_directory);ensure_private(self.stage_directory)
        self.effect_key,self.observer_key=effect_key,observer_key
        self.schemas={tool:resource_contract(contracts,tool) for tool in MUTATIONS}
        self.effects,self.preparation_pins,self.descriptors,self.mappings={},{},{},{}
        self.account_observer,self.workload_credentials=account_observer,workload_credentials
        self.wire_namespace=deepcopy(workload_credentials.wire)
        self.mcp=POCMCP(mcp_url,network='web-pki/1',ca_file=mcp_ca_file,ca_sha256=mcp_ca_sha256)
        self.scheduled_mapping=FamilyReadMapping(contracts.tools[TOOL])
        self.bootstrap=ConfiguredNativeBootstrap(target=target,verifier=native_verifier,accounts=account_observer,
            control=self.control,namespace=namespace,tenant=tenant,host_origin=self.os_origin,core_origin=self.os_origin,
            embed_ref=embed_ref,client_profile=client_profile,bridge_key=bridge_key,session_file=session_file,
            session_key_file=session_key_file,ca_file=core_ca_file,ca_sha256=core_ca_sha256)

    def control(self,subject):
        value=super().control(subject)
        if (type(value) is not dict or set(value)!={'active','memberIds','tools','policyGeneration','sessionGeneration'}
                or value['active'] is not True
                or any(type(value[k]) is not int or not 1<=value[k]<=2**53-1 for k in ('policyGeneration','sessionGeneration'))
                or any(type(value[k]) is not list or len(value[k])>64 or len(set(value[k]))!=len(value[k])
                    or any(type(v) is not str or not 1<=len(v)<=128 for v in value[k]) for k in ('memberIds','tools'))
                or not set(value['tools'])<=set(self.contracts.tools)):
            raise OSErrorCode('DENIED')
        return value

    def credential(self,subject,tool,until):
        if tool not in self.control(subject)['tools']:raise OSErrorCode('DENIED')
        return self.workload_credentials.execution_token(subject,tool,until)

    async def dispatch(self,action,body):
        if action=='sessions/check':
            return await self.bootstrap.session(body['subject'],body['hostSessionRef'],body['sessionGeneration'])
        if action=='learning/accounts/check':return await super().dispatch(action,body)
        value=body['read'] if action=='observe' else body['scope'] if action=='scope-observe' else body
        context=value.get('binding',value).get('context',value.get('context',{}))
        subject=context.get('subject',value.get('subject'))
        control=deepcopy(self.control(subject));account=await self.account_observer.observe(subject)
        if not account['active'] or self.control(subject)!=control:raise OSErrorCode('DENIED')
        result=await super().dispatch(action,body)
        if self.control(subject)!=control:raise OSErrorCode('DENIED')
        if 'validUntil' in result:result['validUntil']=iso(min(timestamp(result['validUntil']),timestamp(account['validUntil'])))
        return result

    def app(self):
        app=self.attach_effects(self.attach_private(FastAPI(docs_url=None,redoc_url=None,openapi_url=None)))
        @app.middleware('http')
        async def deny_local_identity(request,call_next):
            if LOCAL_IDENTITY_HEADERS.intersection(request.headers):return JSONResponse(dict(code='DENIED'),status_code=403)
            return await call_next(request)
        return app

    def public_app(self):return self.bootstrap.app()
