"""Explicit local-test login continuity, separate from finite action authority.

The app authenticates native credentials and owns durable login epochs. This
adapter publishes only verified metadata and never creates a login or a task.
No production/AWS composition imports or enables this profile implicitly.
"""
import asyncio
from copy import deepcopy
import hashlib
from pathlib import Path
import re
import stat
import subprocess
import threading
import time
from uuid import UUID
from urllib.parse import urlsplit

import httpx

from agentic_os.adapters.local.files import check_private,private_read,private_write
from agentic_os.adapters.http.endpoint import local_endpoint
from agentic_os.adapters.local.resources import canonical_path,file_lock
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.distribution import read_regular
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import fresh,timestamp

SUBJECTS=frozenset({'test-user-001','test-user-tom-only'})
STATES=frozenset({'ACTIVE','SIGNED_OUT','REVOKED','STOPPED'})
RECORD_FIELDS=frozenset({'schema','profile','state','subject','installation','application',
    'environment','backendEnvironment','environmentId','sessionId','generation'})
WIRE=dict(installation='798f8bbe-ec2d-4669-8075-3f1392a14b58',
    application='d45ff13d-d44b-4fc9-bd49-7a2808486edc',environment='local')
NATIVE_FIELDS=frozenset({'schema','subject','environment','active','state','sessionId',
    'generation','environmentRevision','environmentState'})


def uuid(value):
    if type(value) is not str or str(UUID(value))!=value:raise ValueError('Canonical UUID required')
    return value


def integer(value):
    if type(value) is not int or not 1<=value<=9007199254740991:raise ValueError('Exact positive revision required')


def check_issuer_pins(c,script_name):
    if (type(c['files']) is not dict or not 2<=len(c['files'])<=16 or c['script'] not in c['files']
            or Path(c['script']).name!=script_name):raise ValueError('Reviewed local issuer closure required')
    for path,expected in {**c['files'],c['python']:c['python_sha256']}.items():
        if not Path(path).is_absolute() or re.fullmatch('[0-9a-f]{64}',expected or '') is None:raise ValueError('Explicit source pin required')
        actual=Path(path).resolve() if path==c['python'] else canonical_path(Path(path))
        if hashlib.sha256(read_regular(actual,32*1024*1024)).hexdigest()!=expected:raise ValueError('Local issuer source pin differs')


def native_metadata(value,environment,*,observation=False):
    fields=NATIVE_FIELDS|{'checkedAt','validUntil'} if observation else NATIVE_FIELDS
    if (type(value) is not dict or set(value)!=fields
            or value['schema']!=('vf.local-session-observation/1' if observation else 'vf.local-native-session/1')
            or value['subject'] not in SUBJECTS or value['environment']!=environment
            or type(value['active']) is not bool or value['state'] not in STATES
            or value['active']!=(value['state']=='ACTIVE')
            or value['environmentState'] not in {'RUNNING','STOPPED'}
            or value['environmentState']=='STOPPED' and value['state']!='STOPPED'):
        raise OSErrorCode('DENIED')
    try:
        uuid(value['sessionId']);integer(value['generation']);integer(value['environmentRevision'])
        if value['generation']>value['environmentRevision']:raise ValueError()
        if observation:
            if not 0<(timestamp(value['validUntil'])-timestamp(value['checkedAt'])).total_seconds()<=15:raise ValueError()
            # Inactive observations are valid revocation evidence, not grants.
            subject=dict(installationId=WIRE['installation'],applicationId=WIRE['application'],
                tenantId='vf-synthetic',subjectId=value['subject'])
            fresh(dict(subject=subject,active=True,checkedAt=value['checkedAt'],validUntil=value['validUntil']),subject=subject)
    except (ValueError,TypeError,KeyError):raise OSErrorCode('DENIED') from None
    return deepcopy(value)


class LocalAccessRecord:
    def __init__(self,path,*,environment_id,backend_environment):
        self.path=canonical_path(Path(path));check_private(self.path.parent,directory=True)
        if stat.S_IMODE(self.path.parent.lstat().st_mode)!=0o700:raise ValueError('Private0700 local access directory required')
        self.environment_id=uuid(environment_id)
        if type(backend_environment) is not str or not backend_environment.startswith('vf-'):
            raise ValueError('Explicit local backend environment required')
        self.backend_environment=backend_environment

    def read(self):
        try:
            raw=private_read(self.path,4096);info=self.path.lstat()
            value=parse_canonical_json(raw)
            if (info.st_nlink!=1 or stat.S_IMODE(info.st_mode)!=0o600 or type(value) is not dict
                    or set(value)!=RECORD_FIELDS or canonical_bytes(value)!=raw
                    or value['schema']!='vf.local-synthetic-access/1' or value['profile']!='local-synthetic-test'
                    or value['subject'] not in SUBJECTS or value['state'] not in STATES
                    or any(value[k]!=v for k,v in WIRE.items())
                    or value['backendEnvironment']!=self.backend_environment
                    or value['environmentId']!=self.environment_id):raise ValueError()
            uuid(value['sessionId']);integer(value['generation']);return value
        except Exception:raise OSErrorCode('DENIED') from None

    def publish(self,observation):
        value=native_metadata(observation,self.backend_environment,observation=True)
        candidate=dict(schema='vf.local-synthetic-access/1',profile='local-synthetic-test',
            state=value['state'],subject=value['subject'],**WIRE,backendEnvironment=self.backend_environment,
            environmentId=self.environment_id,sessionId=value['sessionId'],generation=value['generation'])
        with file_lock(self.path.parent/(self.path.name+'.lock'),timeout=2):
            old=self.read() if self.path.exists() or self.path.is_symlink() else None
            if old is not None:
                if (old['state']=='ACTIVE' and candidate['state'] not in {'ACTIVE','STOPPED'}
                        and candidate['subject']!=old['subject']):raise OSErrorCode('CONFLICT')
                if candidate['generation']<old['generation']:raise OSErrorCode('CONFLICT')
                if candidate['generation']==old['generation'] and candidate!=old:raise OSErrorCode('CONFLICT')
                if old['state']=='STOPPED' and candidate!=old:raise OSErrorCode('DENIED')
            # An inactive old account at the same environment revision cannot
            # overwrite a later active account; generation is a global counter.
            if (candidate['state']!='ACTIVE' and candidate['generation']!=value['environmentRevision']
                    and (old is None or candidate['subject']!=old['subject'])):
                raise OSErrorCode('CONFLICT')
            if candidate!=old:private_write(self.path,canonical_bytes(candidate),replace=old is not None)
        return candidate

    def require(self,subject,binding=None):
        value=self.read()
        if value['state']!='ACTIVE' or value['subject']!=subject['subjectId']:raise OSErrorCode('DENIED')
        actual={key:value[key] for key in ('environmentId','sessionId','generation')}
        if binding is not None and binding!=actual:raise OSErrorCode('DENIED')
        return actual

    def claims(self,subject,binding=None):
        value=self.require(subject,binding)
        return dict(local_environment_id=value['environmentId'],local_access_id=value['sessionId'],
            local_access_generation=value['generation'])


class _AccountTokenRotated(Exception):
    """Cached issuance metadata no longer identifies the protected token file."""


class LocalAccountIssuer:
    """One reviewed app-owned finite account issuer, never a signing-key reader."""
    def __init__(self,configuration,*,environment,token_files):
        required={'python','python_sha256','script','files','fixture','session_registry'}
        if type(configuration) is not dict or set(configuration)!=required:raise ValueError('Closed pinned account issuer required')
        self.config=deepcopy(configuration);self.environment=environment
        self.tokens={key:canonical_path(Path(value)) for key,value in token_files.items()}
        self._issued={};self._lock=threading.Lock()
        if not self.tokens or set(self.tokens)-SUBJECTS:raise ValueError('Explicit account token files required')
        self._pins()

    def _pins(self):
        c=self.config
        check_issuer_pins(c,'issue_account_token.py')
        canonical_path(Path(c['fixture']));canonical_path(Path(c['session_registry']))

    def token(self,subject):
        user=subject.get('subjectId')
        with self._lock:
            old=self._issued.get(user)
            if old and old['expiresAt']-time.time()>60:
                try:return self._read_token(user,old)
                except _AccountTokenRotated:
                    # Another authorized issuer instance may renew this shared
                    # file. Never adopt unchecked bytes or fall back to them;
                    # obtain a new reference from the pinned finite issuer.
                    self._issued.pop(user,None);old=None
            try:return self._mint(subject)
            except OSErrorCode:
                # A retained, genuinely unexpired environment observer can
                # report STOPPED even after its issuer stops. This neither
                # extends that JWT nor grants product/native access.
                if old and old['expiresAt']>time.time():
                    try:return self._read_token(user,old)
                    except _AccountTokenRotated:raise OSErrorCode('DENIED') from None
                raise

    def _read_token(self,user,meta):
        raw=private_read(self.tokens[user],16384)
        if hashlib.sha256(raw).hexdigest()!=meta['tokenSha256']:raise _AccountTokenRotated()
        token=raw.decode('ascii').strip()
        if token.count('.')!=2 or any(ch.isspace() for ch in token):raise OSErrorCode('DENIED')
        return token

    def _mint(self,subject):
        try:
            user=subject['subjectId']
            if user not in self.tokens:raise OSErrorCode('DENIED')
            self._pins();c=self.config
            # No shell, inherited secret environment, stdout token, arbitrary
            # command argument or business API is involved in renewal.
            result=subprocess.run([c['python'],c['script'],'--fixture',c['fixture'],'--subject',user,
                '--ttl-seconds','900','--local-session-registry',c['session_registry']],
                stdin=subprocess.DEVNULL,capture_output=True,timeout=5,check=False,
                env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
            if result.returncode or len(result.stdout)>4096:raise OSErrorCode('UNAVAILABLE')
            meta=parse_canonical_json(result.stdout)
            fields={'schema','profile','state','subject','environment','authorization','expiresAt','tokenFile','tokenSha256'}
            if (type(meta) is not dict or set(meta)!=fields or meta['schema']!='vf.local-account-renewal/1'
                    or meta['profile']!='local-synthetic-test' or meta['state']!='ISSUED'
                    or meta['subject']!=user or meta['environment']!=self.environment
                    or meta['authorization']!='ENVIRONMENT_READ_ONLY' or type(meta['expiresAt']) is not int
                    or not 0<meta['expiresAt']-time.time()<=900 or meta['tokenFile']!=str(self.tokens[user])):
                raise OSErrorCode('DENIED')
            token=self._read_token(user,meta);self._issued[user]=deepcopy(meta);return token
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None


class LocalReceiptIssuer:
    """Fresh finite MCP observer credentials tied to actual native publication."""
    def __init__(self,configuration,*,record):
        fields={'python','python_sha256','script','files','fixture','token_files','issuer','audience','client_id','public_key_file'}
        if (type(configuration) is not dict or set(configuration) not in (fields,fields|{'allocation'}) or type(record) is not LocalAccessRecord
                or re.fullmatch('[a-z0-9][a-z0-9-]{0,63}',configuration['fixture'] or '') is None
                or not configuration['issuer'].startswith('https://') or configuration['audience']=='vf-mcp'
                or configuration['client_id']=='core-poc' or configuration['public_key_file'] not in configuration['files']):
            raise ValueError('Explicit disjoint local receipt issuer required')
        self.config=deepcopy(configuration);self.record=record;self._lock=threading.Lock();self._issued={}
        self.tokens={k:canonical_path(Path(v)) for k,v in configuration['token_files'].items()}
        if not self.tokens or set(self.tokens)-SUBJECTS:raise ValueError('Explicit observer token outputs required')
        check_issuer_pins(self.config,'fixture-credentials.py')

    def token(self,user):
        import jwt
        subject={'subjectId':user}
        with self._lock:
            try:
                binding=self.record.require(subject)
                if user not in self.tokens:raise OSErrorCode('DENIED')
                old=self._issued.get(user)
                if old is None or old['binding']!=binding or old['expiresAt']-time.time()<=60:
                    c=self.config;check_issuer_pins(c,'fixture-credentials.py')
                    allocation_args=[] if 'allocation' not in c else ['--allocation',str(canonical_path(Path(c['allocation']))) ]
                    result=subprocess.run([c['python'],c['script'],*allocation_args,'--fixture',c['fixture'],'--subject',user,
                        '--purpose','observation','--ttl','900','--local-access-state-file',str(self.record.path)],
                        stdin=subprocess.DEVNULL,capture_output=True,timeout=5,check=False,
                        env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
                    if result.returncode or len(result.stdout)>4096:raise OSErrorCode('UNAVAILABLE')
                    meta=parse_canonical_json(result.stdout)
                    expected=dict(schema='vf-mcp.fixture-credential-reference/1',fixture=c['fixture'],purpose='observation',
                        file=str(self.tokens[user]),algorithm='RS256',issuer=c['issuer'],audience=[c['audience']],
                        subject=user,client_id=c['client_id'],installation=WIRE['installation'],application=WIRE['application'],
                        environment='local',scope='receipt:observe',executionGrantIssued=False,privateKeyExported=False)
                    if (type(meta) is not dict or set(meta)!=set(expected)|{'issuedAt','expiresAt'}
                            or any(type(meta[k]) is not type(v) or meta[k]!=v for k,v in expected.items())
                            or type(meta['issuedAt']) is not int or type(meta['expiresAt']) is not int
                            or not 0<meta['expiresAt']-meta['issuedAt']<=900
                            or not 0<meta['expiresAt']-time.time()<=900):raise OSErrorCode('DENIED')
                    old=dict(binding=binding,issuedAt=meta['issuedAt'],expiresAt=meta['expiresAt']);self._issued[user]=old
                token=private_read(self.tokens[user],16384).decode('ascii').strip();c=self.config
                if jwt.get_unverified_header(token)!={'alg':'RS256','typ':'JWT','kid':c['fixture']+'/observation/1'}:
                    raise OSErrorCode('DENIED')
                public=read_regular(Path(c['public_key_file']),16384)
                if hashlib.sha256(public).hexdigest()!=c['files'][c['public_key_file']]:raise OSErrorCode('DENIED')
                claims=jwt.decode(token,public,algorithms=['RS256'],
                    issuer=c['issuer'],audience=c['audience'],options={'require':['iat','exp','jti','sub','scope']})
                expected=dict(iss=c['issuer'],aud=[c['audience']],sub=user,client_id=c['client_id'],**WIRE,
                    scope='receipt:observe',**self.record.claims(subject,binding))
                if (set(claims)!=set(expected)|{'iat','exp','jti'} or any(claims[k]!=v for k,v in expected.items())
                        or type(claims['iat']) is not int or type(claims['exp']) is not int
                        or not 0<claims['exp']-claims['iat']<=900):raise OSErrorCode('DENIED')
                uuid(claims['jti']);self.record.require(subject,binding)
                # The pinned signature, closed role/namespace and current native
                # binding authenticate a concurrently renewed finite observer.
                # Cached timestamps are a renewal hint, never token authority.
                self._issued[user]=dict(binding=binding,issuedAt=claims['iat'],expiresAt=claims['exp'])
                return token
            except OSErrorCode:raise
            except Exception:raise OSErrorCode('UNAVAILABLE') from None


class LocalNativeAccess:
    def __init__(self,*,record,accounts,backend_url,namespace,root_binding):
        from .account_observation import PrivateAccountObservation
        if (type(record) is not LocalAccessRecord or type(accounts) is not PrivateAccountObservation
                or accounts.network!='owned-local-http/1' or accounts.namespace!=namespace
                or accounts.environment!=record.backend_environment or not callable(root_binding)
                or not backend_url.startswith('http://127.0.0.1:')):
            raise ValueError('Explicit local native access composition required')
        local_endpoint(backend_url)
        # Native login is an app-owned root endpoint, separate from the
        # business API base (normally /api/v1). Never append it to that base.
        destination=urlsplit(backend_url)
        self.native_status_url=destination._replace(path='/local-test/native-session').geturl()
        self.record,self.accounts,self.backend_url=record,accounts,backend_url
        self.namespace,self.root_binding=deepcopy(namespace),root_binding

    async def initialize(self,subject_for):
        # Startup never creates or resurrects a login. Query only the dedicated
        # account role and publish the newest actual environment transition.
        rows=[await self.accounts.observe_local_session(subject_for(user)) for user in sorted(self.accounts.tokens)]
        latest=max(value['environmentRevision'] for value in rows)
        current=[value for value in rows if value['generation']==value['environmentRevision']==latest]
        active=[value for value in rows if value['active']]
        if len(active)>1 or not current:raise OSErrorCode('CONFLICT')
        selected=active[0] if active else current[0]
        expected={k:v for k,v in selected.items() if k not in {'checkedAt','validUntil'}}
        expected['schema']='vf.local-native-session/1'
        await self.synchronize(subject_for(selected['subject']),expected)

    async def synchronize(self,subject,expected=None):
        validate_contract('SubjectRef',subject)
        if subject['tenantId']!='vf-synthetic' or any(subject[k]!=v for k,v in self.namespace.items()):raise OSErrorCode('DENIED')
        value=await self.accounts.observe_local_session(subject)
        if expected is not None:
            native_metadata(expected,self.record.backend_environment)
            if any(value[k]!=v for k,v in expected.items() if k!='schema'):raise OSErrorCode('CONFLICT')
        await asyncio.to_thread(self.record.publish,value)
        return value

    async def native(self,subject,authorization):
        if (type(authorization) is not str or not authorization.startswith('Bearer ')
                or re.fullmatch('[A-Za-z0-9_-]{32,128}',authorization[7:]) is None):
            raise OSErrorCode('UNAUTHENTICATED')
        try:
            async with httpx.AsyncClient(trust_env=False,follow_redirects=False,timeout=3) as client:
                response=await client.get(self.native_status_url,headers={
                    'X-POC-Test-User':subject['subjectId'],'Authorization':authorization,'Accept-Encoding':'identity'})
            if response.status_code!=200 or len(response.content)>4096:raise OSErrorCode('UNAUTHENTICATED')
            value=native_metadata(parse_canonical_json(response.content),self.record.backend_environment)
            if value['subject']!=subject['subjectId'] or not value['active']:raise OSErrorCode('DENIED')
            await self.synchronize(subject,value)
            return self.record.require(subject)
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None

    async def check_root(self,context):
        await self.synchronize(context['subject'])
        binding=await asyncio.to_thread(self.root_binding,context)
        return self.record.require(context['subject'],binding)

    async def check_effect(self,context,token):
        import jwt
        binding=await self.check_root(context)
        # The independent MCPBearerVerifier authenticates signature/role first.
        # This comparison adds the original native epoch; no private claim is
        # forwarded into the frozen public EffectCallContext.
        value=jwt.decode(token,options={'verify_signature':False})
        if any(value.get(k)!=v for k,v in self.record.claims(context['subject'],binding).items()):
            raise OSErrorCode('DENIED')


def admitted_native_binding(store,sessions,context):
    """Resolve the original Root admission, never the newest signed-in session."""
    from sqlalchemy import select
    from agentic_os.adapters.postgres.models import Admission,BudgetRoot
    from agentic_os.identity.service import scoped
    from agentic_os.identity.context import utcnow
    from agentic_os.production.planning_scope import check_context
    validate_contract('AgentTaskContext',context)
    with store.transaction() as db:
        root=db.scalar(select(BudgetRoot).where(*scoped(BudgetRoot,context['subject']),
            BudgetRoot.id==UUID(context['rootId'])))
        admission=db.get(Admission,root.admission_id) if root else None
        if (root is None or root.state!='ACTIVE' or root.deadline<=utcnow() or admission is None
                or admission.context['subject']!=context['subject']
                or admission.authority['subject']!=context['subject']):raise OSErrorCode('DENIED')
        check_context(db,admission,context,now=utcnow())
        session=sessions.get(admission.authority['hostSessionRef'])
        if (not session or session['subject']!=context['subject'] or session['expires']<=time.time()
                or session['generation']!=admission.authority['sessionGeneration'] or 'native' not in session):
            raise OSErrorCode('DENIED')
        return deepcopy(session['native'])
