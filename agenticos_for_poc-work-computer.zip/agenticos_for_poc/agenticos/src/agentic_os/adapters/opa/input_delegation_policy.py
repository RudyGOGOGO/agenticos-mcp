"""Explicit fixed policy6 for finite delegated input effects."""

import asyncio
import copy
import re
from datetime import timedelta

import httpx

from agentic_os.adapters.http.endpoint import local_endpoint
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import fresh, timestamp, utcnow


class InputDelegatedExecutionPolicy:
    path = "/v1/data/agentic_os/input_delegated_execution"
    profile_ref = "input-delegated-execution/1"
    revision = 6
    constraints = {"host-current", "bot-ceiling", "owner-scope", "finite-delegation", "exact-grant", "current-input"}

    def __init__(self, origin, token, revision, bundle_digest, *, timeout=2):
        if (type(revision) is not int or revision != self.revision
            or type(timeout) not in {int, float} or not 0 < timeout <= 2
            or type(token) is not str or re.fullmatch(r"[A-Za-z0-9_-]{43,128}", token) is None
            or type(bundle_digest) is not str or re.fullmatch(r"[a-f0-9]{64}", bundle_digest) is None):
            raise OSErrorCode("PROFILE_DISABLED")
        self.origin = local_endpoint(origin, origin_only=True)
        self.token, self.bundle_digest, self.timeout = token, bundle_digest, timeout
        self.bulkhead = asyncio.Semaphore(4)

    def check_input(self, value):
        from agentic_os.effects.input_delegation_contracts import check_execution_input
        check_execution_input(value, self.bundle_digest)

    async def evaluate(self, value):
        value = copy.deepcopy(value)
        self.check_input(value)
        content = canonical_bytes({"input": value})
        if len(content) > 65536:
            raise OSErrorCode("CAPACITY")
        try:
            async with (asyncio.timeout(self.timeout), self.bulkhead,
                httpx.AsyncClient(trust_env=False, follow_redirects=False, timeout=self.timeout) as client,
                client.stream("POST", self.origin+self.path, content=content, headers={
                    "Authorization": "Bearer " + self.token, "Content-Type": "application/json", "Accept-Encoding": "identity"}) as response):
                if (response.status_code != 200 or response.headers.get("content-type", "").split(";")[0] != "application/json"
                    or response.headers.get("content-encoding", "identity") != "identity"):
                    raise OSErrorCode("UNAVAILABLE")
                raw = bytearray()
                async for chunk in response.aiter_bytes():
                    raw.extend(chunk)
                    if len(raw) > 16384:
                        raise OSErrorCode("UNAVAILABLE")
            envelope = parse_canonical_json(bytes(raw))
            if type(envelope) is not dict or set(envelope) != {"result"}:
                raise OSErrorCode("UNAVAILABLE")
            result = envelope["result"]
            validate_contract("PolicyDecision", result)
            self.check_input(value)
            if (result["bundleRevision"] != self.revision or result["bundleDigest"] != self.bundle_digest
                or result["authorityGeneration"] != value["policy"]["authority"]["policyGeneration"]
                or result["risk"] != value["proposal"]["risk"] or result["requiredAssurance"] != "bounded-delegation/1"
                or set(result["constraints"]) != self.constraints
                or not utcnow() < timestamp(result["validUntil"]) <= min(
                    timestamp(value["policy"]["authority"]["validUntil"]), timestamp(value["delegation"]["expiresAt"]),
                    timestamp(value["policy"]["authority"]["checkedAt"])+timedelta(seconds=5),
                    timestamp(value["grant"]["expiresAt"]), timestamp(value["proposal"]["expiresAt"]))
                or result["reasonCode"] != ("CURRENT_INPUT_FINITE_DELEGATED_EFFECT" if result["allowed"] else "DENIED_SCOPE_OR_PROFILE")):
                raise OSErrorCode("DENIED")
            return copy.deepcopy(result)
        except OSErrorCode:
            raise
        except (httpx.HTTPError, TimeoutError, ValueError, TypeError, KeyError):
            raise OSErrorCode("UNAVAILABLE") from None
