"""Explicit local qualification: qualification draft. Fixed committed execution4; never model authority."""

import asyncio
import copy
import re
from datetime import timedelta

import httpx

from agentic_os.adapters.http.endpoint import local_endpoint
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.effects.assurance import binding_digest, check_binding
from agentic_os.effects.contracts import effect_digest, proposal_digest
from agentic_os.effects.decision_disclosure import core_digest
from agentic_os.effects.decisions import grant_digest
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import fresh, timestamp, utcnow


class ReviewedExecutionPolicy:
    path = "/v1/data/agentic_os/reviewed_execution"
    profile_ref = "reviewed-execution/1"
    revision = 4
    constraints = {"host-current", "bot-ceiling", "owner-scope", "owned-decision", "exact-grant"}

    def __init__(self, origin, token, revision, bundle_digest, *, timeout=2):
        if (type(revision) is not int or revision != self.revision
            or type(timeout) not in {int, float} or not 0 < timeout <= 2
            or type(token) is not str or re.fullmatch(r"[A-Za-z0-9_-]{43,128}", token) is None
            or type(bundle_digest) is not str or re.fullmatch(r"[a-f0-9]{64}", bundle_digest) is None):
            raise OSErrorCode("PROFILE_DISABLED")
        self.origin = local_endpoint(origin, origin_only=True)
        self.token, self.bundle_digest, self.timeout = token, bundle_digest, timeout
        self.bulkhead = asyncio.Semaphore(4)

    def check_input(self, value):
        validate_contract("ReviewedExecutionPolicyInput", value)
        policy, proposal, core, grant = (value[k] for k in ("policy", "proposal", "decision", "grant"))
        claim, observed = value["claim"], value["attestation"]
        binding = claim["binding"]
        check_binding(binding)
        fresh(policy["authority"], subject=policy["subject"])
        now = utcnow()
        targets = proposal["intent"]["targets"]
        if len(targets) != 1:
            raise OSErrorCode("PROFILE_DISABLED")
        names = [f["name"] for f in proposal["intent"]["fields"]]
        bounds = [{"resourceType": targets[0]["resourceType"], "externalIds": [targets[0]["externalId"]],
                   "fieldNames": sorted(names)}]
        if (policy["subject"] != proposal["subject"] or policy["subject"] != core["subject"]
            or grant["subject"] != core["subject"] or core["authority"]["subject"] != core["subject"]
            or core["coreDigest"] != core_digest(core)
            or proposal["digest"] != proposal_digest(proposal) or grant["grantDigest"] != grant_digest(grant)
            or core["decision"] != "approve" or core["readAuthority"] is not None
            or not core["eligibility"]["allowed"] or core["eligibility"]["bundleRevision"] != 3
            or core["claim"] != claim or core["challengeId"] != binding["challengeId"]
            or core["proposalId"] != proposal["id"] or core["proposalRevision"] != proposal["revision"]
            or core["proposalDigest"] != proposal["digest"] or core["providerRef"] != proposal["providerRef"]
            or grant["decisionCoreDigest"] != core["coreDigest"] or grant["decision"] != {
                "id": core["id"], "proposalId": proposal["id"], "proposalRevision": proposal["revision"],
                "digest": proposal["digest"], "subject": core["subject"], "expiresAt": core["expiresAt"],
                "assuranceRef": "local-synthetic"}
            or any(grant[k] != core[k] for k in (
                "taskId", "rootId", "controlEpoch", "sourcePinDigest", "requestDigest", "capabilityRef",
                "providerRef", "stageId", "definitionDigest", "registrationRevision", "createdAt", "expiresAt"))
            or grant["segmentId"] != core["successorSegmentId"]
            or grant["proposalId"] != proposal["id"] or grant["proposalRevision"] != proposal["revision"]
            or grant["proposalDigest"] != proposal["digest"]
            or grant["effectRequestDigest"] != effect_digest(core["subject"], grant["invocationId"], proposal, core["capabilityRef"])
            or core["executableProfileRef"] != self.profile_ref or grant["profileRef"] != self.profile_ref
            or core["executableBundleRevision"] != self.revision or grant["bundleRevision"] != self.revision
            or core["executableBundleDigest"] != self.bundle_digest or grant["bundleDigest"] != self.bundle_digest
            or policy["requiredBundleRevision"] != self.revision or policy["purpose"] != "assistant.execute"
            or policy["authority"]["purpose"] != policy["purpose"] or policy["delegation"] is not None
            or policy["resourceBounds"] != bounds or policy["intentRef"] != "proposal/" + proposal["id"]
            or core["capabilityRef"] != policy["capability"]["id"]
            or proposal["risk"] != policy["capability"]["riskFloor"]
            or proposal["risk"] not in {"medium", "high"} or proposal["requiredAssurance"] != "local-synthetic"
            or proposal["guaranteeRef"] != "atomic-host-effect/1"
            or policy["capability"]["guaranteeProfile"] != proposal["guaranteeRef"]
            or policy["capability"]["kind"] != "effect"
            or core["capabilityRef"] not in policy["botCeiling"]
            or core["capabilityRef"] not in policy["authority"]["capabilityRefs"]
            or proposal["expectedVersions"] != targets or targets[0]["subject"] != core["subject"]
            or targets[0]["providerId"] != core["providerRef"]
            or targets[0]["contractVersion"] != proposal["intent"]["contractVersion"]
            or proposal["intent"]["subject"] != core["subject"] or proposal["intent"]["operation"] != "update"
            or proposal["intent"]["destinationRefs"] or proposal["intent"]["evidenceRefs"] != ["stage/" + core["stageId"]]
            or not names or len(names) != len(set(names))
            or not any(b["resourceType"] == targets[0]["resourceType"]
                       and targets[0]["externalId"] in b["externalIds"] and set(names) <= set(b["fieldNames"])
                       for b in policy["authority"]["resourceBounds"])
            or policy["authority"]["policyGeneration"] != core["authority"]["policyGeneration"]
            or binding["subject"] != core["subject"] or binding["proposalId"] != core["proposalId"]
            or binding["proposalRevision"] != core["proposalRevision"] or binding["proposalDigest"] != core["proposalDigest"]
            or any(binding[k] != core["authority"][k] for k in ("sessionId", "sessionGeneration", "hostSessionRef", "policyGeneration"))
            or claim["decision"] != "approve" or claim["commandId"] != core["commandId"]
            or claim["commandDigest"] != core["commandDigest"] or observed["decision"] != "approve"
            or observed["subject"] != binding["subject"] or observed["sessionId"] != binding["sessionId"]
            or observed["challengeId"] != binding["challengeId"] or observed["bindingDigest"] != binding_digest(binding)
            or any(observed[k] != claim[k] for k in ("assertionRef", "commandId", "commandDigest", "decision"))
            or observed["assuranceRef"] != "local-synthetic"
            or not now-timedelta(seconds=5) <= timestamp(observed["observedAt"]) <= now+timedelta(seconds=1)
            or not timestamp(core["createdAt"]) <= now+timedelta(seconds=1)
            or not timestamp(core["createdAt"]) < timestamp(core["expiresAt"]) <= timestamp(core["createdAt"])+timedelta(seconds=60)
            or not now < timestamp(core["expiresAt"]) <= min(timestamp(binding["expiresAt"]),
                timestamp(observed["expiresAt"]), timestamp(proposal["expiresAt"]))):
            raise OSErrorCode("DENIED")

    async def evaluate(self, value):
        value = copy.deepcopy(value)
        self.check_input(value)
        content = canonical_bytes({"input": value})
        if len(content) > 65536:
            raise OSErrorCode("CAPACITY")
        try:
            async with (asyncio.timeout(self.timeout), self.bulkhead,
                httpx.AsyncClient(trust_env=False, follow_redirects=False, timeout=self.timeout) as client,
                client.stream("POST", self.origin+self.path, content=content, headers={
                    "Authorization": "Bearer " + self.token, "Content-Type": "application/json", "Accept-Encoding": "identity"}) as response):
                if (response.status_code != 200 or response.headers.get("content-type", "").split(";")[0] != "application/json"
                    or response.headers.get("content-encoding", "identity") != "identity"):
                    raise OSErrorCode("UNAVAILABLE")
                raw = bytearray()
                async for chunk in response.aiter_bytes():
                    raw.extend(chunk)
                    if len(raw) > 16384:
                        raise OSErrorCode("UNAVAILABLE")
            envelope = parse_canonical_json(bytes(raw))
            if type(envelope) is not dict or set(envelope) != {"result"}:
                raise OSErrorCode("UNAVAILABLE")
            result = envelope["result"]
            validate_contract("PolicyDecision", result)
            self.check_input(value)
            if (result["bundleRevision"] != self.revision or result["bundleDigest"] != self.bundle_digest
                or result["authorityGeneration"] != value["policy"]["authority"]["policyGeneration"]
                or result["risk"] != value["proposal"]["risk"] or result["requiredAssurance"] != "local-synthetic"
                or set(result["constraints"]) != self.constraints
                or not utcnow() < timestamp(result["validUntil"]) <= min(
                    timestamp(value["policy"]["authority"]["validUntil"]), timestamp(value["attestation"]["expiresAt"]),
                    timestamp(value["attestation"]["observedAt"])+timedelta(seconds=5),
                    timestamp(value["grant"]["expiresAt"]), timestamp(value["proposal"]["expiresAt"]))
                or result["reasonCode"] != ("CURRENT_OWNED_REVIEWED_EFFECT" if result["allowed"] else "DENIED_SCOPE_OR_PROFILE")):
                raise OSErrorCode("DENIED")
            return copy.deepcopy(result)
        except OSErrorCode:
            raise
        except (httpx.HTTPError, TimeoutError, ValueError, TypeError, KeyError):
            raise OSErrorCode("UNAVAILABLE") from None
