"""Fixed policy7: new owner assurance for a registered inverse only."""
import asyncio,copy,re
from datetime import timedelta
import httpx
from agentic_os.adapters.http.endpoint import local_endpoint
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.effects.assurance import binding_digest,check_binding
from agentic_os.effects.contracts import effect_digest,proposal_digest
from agentic_os.effects.repair_contracts import grant_digest,repair_digest
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import fresh,timestamp,utcnow

class RepairExecutionPolicy:
    input_contract='RepairExecutionPolicyInput'
    path='/v1/data/agentic_os/repair_execution'
    profile_ref='typed-update-repair-execution/1'
    revision=7
    required_assurance='local-synthetic'
    constraints={'host-current','bot-ceiling','owner-scope','registered-inverse','fresh-repair-approval','exact-grant'}
    def __init__(self, origin, token, revision, bundle_digest, *, timeout=2):
        if (type(revision) is not int or revision != self.revision
            or type(timeout) not in {int, float} or not 0 < timeout <= 2
            or type(token) is not str or re.fullmatch(r"[A-Za-z0-9_-]{43,128}", token) is None
            or type(bundle_digest) is not str or re.fullmatch(r"[a-f0-9]{64}", bundle_digest) is None):
            raise OSErrorCode("PROFILE_DISABLED")
        self.origin = self.endpoint(origin)
        self.token, self.bundle_digest, self.timeout = token, bundle_digest, timeout
        self.bulkhead = asyncio.Semaphore(4)

    def endpoint(self,origin):return local_endpoint(origin,origin_only=True)

    def http_options(self):return {}

    def check_binding(self,binding):check_binding(binding)

    def binding_digest(self,binding):return binding_digest(binding)

    def check_input(self,value):
        validate_contract(self.input_contract,value)
        p,r,proposal,g,claim,a,original=(value[k] for k in ('policy','repair','proposal','grant','claim','attestation','originalReceipt'))
        b=claim['binding'];self.check_binding(b);fresh(p['authority'],subject=p['subject'])
        targets=proposal['intent']['targets'];names=[f['name'] for f in proposal['intent']['fields']]
        if len(targets)!=1 or not names or len(names)!=len(set(names)):raise OSErrorCode('DENIED')
        bounds=[dict(resourceType=targets[0]['resourceType'],externalIds=[targets[0]['externalId']],fieldNames=sorted(names))]
        now=utcnow();d=g['authorization']['decision']
        if (r['repairDigest']!=repair_digest(r) or g['grantDigest']!=grant_digest(g)
            or proposal['digest']!=proposal_digest(proposal)
            or any(v['subject']!=p['subject'] for v in (r,g,proposal,b,a,original,d))
            or g['repairId']!=r['id'] or g['taskId']!=r['taskId'] or g['parentTaskId']!=r['parentTaskId'] or g['rootId']!=r['rootId']
            or g['taskId']==g['parentTaskId'] or proposal['taskId']!=g['taskId']
            or g['profileRef']!=self.profile_ref or g['bundleRevision']!=self.revision or g['bundleDigest']!=self.bundle_digest
            or p['requiredBundleRevision']!=self.revision or p['purpose']!='assistant.execute' or p['authority']['purpose']!=p['purpose']
            or p['authority']['delegationRef'] is not None or p['delegation'] is not None
            or p['resourceBounds']!=bounds or p['intentRef']!='proposal/'+proposal['id']
            or g['capabilityRef']!=p['capability']['id'] or g['capabilityRef'] not in p['botCeiling']
            or g['capabilityRef'] not in p['authority']['capabilityRefs']
            or p['capability']['kind']!='effect' or p['capability']['guaranteeProfile']!='atomic-host-effect/1'
            or proposal['risk']!=p['capability']['riskFloor'] or proposal['risk'] not in {'medium','high'}
            or proposal['guaranteeRef']!='atomic-host-effect/1' or proposal['requiredAssurance']!=self.required_assurance
            or not self.budget_allows(value)
            or g['proposalId']!=proposal['id'] or g['proposalRevision']!=proposal['revision'] or g['proposalDigest']!=proposal['digest']
            or g['providerRef']!=proposal['providerRef'] or targets[0]['providerId']!=g['providerRef'] or targets[0]['subject']!=p['subject']
            or proposal['expectedVersions']!=targets or proposal['intent']['subject']!=p['subject']
            or proposal['intent']['operation']!='update' or proposal['intent']['destinationRefs']
            or proposal['intent']['provenanceRef']!='repair/'+r['id']+'/original/'+original['id']
            or proposal['intent']['evidenceRefs']!=['stage/'+g['stageId']]
            or targets!=original['affectedResources'] or original['status']!='COMMITTED' or original['attestationProfile']!='atomic-host-effect/1'
            or original['id']!=g['originalReceiptId'] or original['version']!=g['originalReceiptVersion']
            or original['providerRef']!=g['providerRef'] or original['invocationId']==g['invocationId']
            or g['effectRequestDigest']!=effect_digest(g['subject'],g['invocationId'],proposal,g['capabilityRef'])
            or d!=dict(id=g['approvalId'],subject=g['subject'],proposalId=proposal['id'],proposalRevision=1,
                digest=proposal['digest'],expiresAt=g['expiresAt'],assuranceRef=self.required_assurance)
            or b['proposalId']!=proposal['id'] or b['proposalRevision']!=1 or b['proposalDigest']!=proposal['digest']
            or any(b[k]!=g['authority'][k] for k in ('subject','sessionId','sessionGeneration','hostSessionRef','policyGeneration'))
            or p['authority']['policyGeneration']!=b['policyGeneration']
            or claim['decision']!='approve' or a['decision']!='approve' or a['bindingDigest']!=self.binding_digest(b)
            or a['sessionId']!=b['sessionId'] or a['challengeId']!=b['challengeId']
            or any(a[k]!=claim[k] for k in ('assertionRef','commandId','commandDigest','decision'))
            or not now-timedelta(seconds=5)<=timestamp(a['observedAt'])<=now+timedelta(seconds=1)
            or not now<timestamp(g['expiresAt'])<=min(timestamp(b['expiresAt']),timestamp(a['expiresAt']),timestamp(proposal['expiresAt']),timestamp(r['expiresAt']))
            or not timestamp(g['createdAt'])<=now+timedelta(seconds=1)
            or not any(x['resourceType']==targets[0]['resourceType'] and targets[0]['externalId'] in x['externalIds']
                and set(names)<=set(x['fieldNames']) for x in p['authority']['resourceBounds'])):
            raise OSErrorCode('DENIED')

    @staticmethod
    def budget_allows(value):
        budget=value['policy']['budget']
        return budget['maxChildren']>=1 and budget['maxStages']>=2 and budget['maxToolCalls']>=5

    async def evaluate(self, value):
        value = copy.deepcopy(value)
        self.check_input(value)
        content = canonical_bytes({"input": value})
        if len(content) > 65536:
            raise OSErrorCode("CAPACITY")
        try:
            async with (asyncio.timeout(self.timeout), self.bulkhead,
                httpx.AsyncClient(trust_env=False, follow_redirects=False, timeout=self.timeout,**self.http_options()) as client,
                client.stream("POST", self.origin+self.path, content=content, headers={
                    "Authorization": "Bearer " + self.token, "Content-Type": "application/json", "Accept-Encoding": "identity"}) as response):
                if (response.status_code != 200 or response.headers.get("content-type", "").split(";")[0] != "application/json"
                    or response.headers.get("content-encoding", "identity") != "identity"):
                    raise OSErrorCode("UNAVAILABLE")
                raw = bytearray()
                async for chunk in response.aiter_bytes():
                    raw.extend(chunk)
                    if len(raw) > 16384:
                        raise OSErrorCode("UNAVAILABLE")
            envelope = parse_canonical_json(bytes(raw))
            if type(envelope) is not dict or set(envelope) != {"result"}:
                raise OSErrorCode("UNAVAILABLE")
            result = envelope["result"]
            validate_contract("PolicyDecision", result)
            self.check_input(value)
            if (result["bundleRevision"] != self.revision or result["bundleDigest"] != self.bundle_digest
                or result["authorityGeneration"] != value["policy"]["authority"]["policyGeneration"]
                or result["risk"] != value["proposal"]["risk"] or result["requiredAssurance"] != self.required_assurance
                or set(result["constraints"]) != self.constraints
                or not utcnow() < timestamp(result["validUntil"]) <= min(
                    timestamp(value["policy"]["authority"]["validUntil"]), timestamp(value["attestation"]["expiresAt"]),
                    timestamp(value["attestation"]["observedAt"])+timedelta(seconds=5),
                    timestamp(value["grant"]["expiresAt"]), timestamp(value["proposal"]["expiresAt"]))
                or result["reasonCode"] != ("CURRENT_REGISTERED_REPAIR" if result["allowed"] else "DENIED_SCOPE_OR_PROFILE")):
                raise OSErrorCode("DENIED")
            return copy.deepcopy(result)
        except OSErrorCode:
            raise
        except (httpx.HTTPError, TimeoutError, ValueError, TypeError, KeyError):
            raise OSErrorCode("UNAVAILABLE") from None
