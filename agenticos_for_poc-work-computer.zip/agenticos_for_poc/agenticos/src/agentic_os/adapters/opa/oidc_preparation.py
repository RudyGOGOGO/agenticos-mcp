"""Explicit production preparation eligibility; authentication is no permit."""
import re
from importlib.resources import files

from agentic_os.contracts.canonical import digest
from agentic_os.errors import OSErrorCode
from .client import OPAClient


def bundle_pin():
    """Shared wheel-owned policy pin for local or AWS OPA packaging."""
    authority=files('agentic_os').joinpath('policies/oidc_effect_preparation.rego').read_text()
    authentication=files('agentic_os').joinpath('policies/operator_auth.rego').read_text()
    return dict(revision=9,digest=digest('policy',dict(revision=9,profile='oidc-effect-preparation/1',
        authority=authority,operatorAuth=authentication)))


class OIDCPreparationPolicy(OPAClient):
    required_assurance='oidc-step-up/1'

    def __init__(self,origin,token,revision,bundle_digest,*,network,timeout=2):
        if (type(revision) is not int or revision!=9
                or network not in {'owned-local-http/1','web-pki/1'}
                or type(bundle_digest) is not str or re.fullmatch('[a-f0-9]{64}',bundle_digest) is None
                or type(token) is not str or not 32<=len(token)<=256 or not token.isascii()
                or any(ord(c)<33 or ord(c)>126 for c in token)
                or type(timeout) not in {int,float} or not 0<timeout<=2):
            raise OSErrorCode('PROFILE_DISABLED')
        self.network=network
        super().__init__(origin,token,revision,bundle_digest,timeout=timeout)
