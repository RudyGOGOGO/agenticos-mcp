"""Explicit qualification: fixed eligibility policy; no decision or permit authority.

Activate only after the registered-challenge checkpoint, generated closed
contracts, actual OPA/host tests and a complete same-source regression gate.
The decision service must obtain claim/attestation through AssurancePort.verify;
this internal client is never exposed as a model tool or browser endpoint.
"""

import asyncio
import copy
import re
from datetime import timedelta

import httpx

from agentic_os.adapters.http.endpoint import local_endpoint
from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.effects.assurance import binding_digest, check_binding
from agentic_os.effects.contracts import proposal_digest
from agentic_os.errors import OSErrorCode
from agentic_os.identity.context import fresh, timestamp, utcnow


class DecisionEligibilityPolicy:
    """One fixed, operator-pinned OPA3 path, never an effect permit issuer."""

    path = "/v1/data/agentic_os/review_eligibility"

    def __init__(self, origin, token, revision, bundle_digest, *, timeout=2):
        if (
            type(revision) is not int
            or revision != 3
            or type(timeout) not in {int, float}
            or not 0 < timeout <= 2
            or type(token) is not str
            or re.fullmatch(r"[A-Za-z0-9_-]{43,128}", token) is None
            or type(bundle_digest) is not str
            or re.fullmatch(r"[a-f0-9]{64}", bundle_digest) is None
        ):
            raise OSErrorCode("PROFILE_DISABLED")
        self.origin = local_endpoint(origin, origin_only=True)
        self.token = token
        self.revision = revision
        self.bundle_digest = bundle_digest
        self.timeout = timeout
        self.bulkhead = asyncio.Semaphore(4)

    def check_input(self, value):
        validate_contract("DecisionEligibilityPolicyInput", value)
        policy, proposal = value["policy"], value["proposal"]
        claim, observed = value["claim"], value["attestation"]
        bound = claim["binding"]
        check_binding(bound)
        fresh(policy["authority"], subject=policy["subject"])
        now = utcnow()
        fields = ("assertionRef", "commandId", "commandDigest", "decision")
        targets = proposal["intent"]["targets"]
        if len(targets) != 1:
            raise OSErrorCode("PROFILE_DISABLED")
        exact_bounds = [
            {
                "resourceType": targets[0]["resourceType"],
                "externalIds": [targets[0]["externalId"]],
                "fieldNames": sorted(f["name"] for f in proposal["intent"]["fields"]),
            }
        ]
        if (
            policy["purpose"] != "assistant.execute"
            or policy["authority"]["purpose"] != policy["purpose"]
            or policy["requiredBundleRevision"] != self.revision
            or policy["delegation"] is not None
            or policy["resourceBounds"] != exact_bounds
            or policy["intentRef"] != "proposal/" + proposal["id"]
            or proposal["intent"]["subject"] != policy["subject"]
            or targets[0]["contractVersion"] != proposal["intent"]["contractVersion"]
            or targets[0]["subject"] != policy["subject"]
            or proposal["expectedVersions"] != targets
            or proposal["providerRef"] != targets[0]["providerId"]
            or proposal["intent"]["operation"] != "update"
            or proposal["intent"]["destinationRefs"]
            or policy["subject"] != proposal["subject"]
            or policy["subject"] != bound["subject"]
            or policy["authority"]["policyGeneration"] != bound["policyGeneration"]
            or proposal_digest(proposal) != proposal["digest"]
            or proposal["risk"] != policy["capability"]["riskFloor"]
            or proposal["requiredAssurance"] != "local-synthetic"
            or proposal["guaranteeRef"] != "atomic-host-effect/1"
            or bound["proposalId"] != proposal["id"]
            or bound["proposalRevision"] != proposal["revision"]
            or bound["proposalDigest"] != proposal["digest"]
            or observed["subject"] != bound["subject"]
            or observed["sessionId"] != bound["sessionId"]
            or observed["challengeId"] != bound["challengeId"]
            or observed["bindingDigest"] != binding_digest(bound)
            or any(observed[k] != claim[k] for k in fields)
            or observed["assuranceRef"] != bound["requiredAssurance"]
            or not now - timedelta(seconds=5)
            <= timestamp(observed["observedAt"])
            <= now + timedelta(seconds=1)
            or not now
            < timestamp(observed["expiresAt"])
            <= timestamp(bound["expiresAt"])
            or timestamp(proposal["expiresAt"]) <= now
        ):
            raise OSErrorCode("DENIED")

    async def evaluate(self, value):
        # Freeze detached material before the first await; no ORM session or
        # mutable caller reference is held across OPA transport.
        value = copy.deepcopy(value)
        self.check_input(value)
        content = canonical_bytes({"input": value})
        if len(content) > 65536:
            raise OSErrorCode("CAPACITY")
        try:
            async with (
                asyncio.timeout(self.timeout),
                self.bulkhead,
                httpx.AsyncClient(
                    trust_env=False, follow_redirects=False, timeout=self.timeout
                ) as client,
                client.stream(
                    "POST",
                    self.origin + self.path,
                    content=content,
                    headers={
                        "Authorization": "Bearer " + self.token,
                        "Content-Type": "application/json",
                        "Accept-Encoding": "identity",
                    },
                ) as response,
            ):
                if (
                    response.status_code != 200
                    or response.headers.get("content-type", "").split(";")[0]
                    != "application/json"
                    or response.headers.get("content-encoding", "identity")
                    != "identity"
                ):
                    raise OSErrorCode("UNAVAILABLE")
                raw = bytearray()
                async for chunk in response.aiter_bytes():
                    raw.extend(chunk)
                    if len(raw) > 16384:
                        raise OSErrorCode("UNAVAILABLE")
            envelope = parse_canonical_json(bytes(raw))
            if type(envelope) is not dict or set(envelope) != {"result"}:
                raise OSErrorCode("UNAVAILABLE")
            result = envelope["result"]
            validate_contract("PolicyDecision", result)
            self.check_input(value)
            policy, proof = value["policy"], value["attestation"]
            if (
                result["bundleRevision"] != self.revision
                or result["bundleDigest"] != self.bundle_digest
                or result["authorityGeneration"]
                != policy["authority"]["policyGeneration"]
                or result["risk"] != policy["capability"]["riskFloor"]
                or result["requiredAssurance"] != "local-synthetic"
                or set(result["constraints"])
                != {"host-current", "bot-ceiling", "owner-scope"}
                or not utcnow()
                < timestamp(result["validUntil"])
                <= min(
                    timestamp(policy["authority"]["validUntil"]),
                    timestamp(proof["expiresAt"]),
                    timestamp(proof["observedAt"]) + timedelta(seconds=5),
                    timestamp(value["proposal"]["expiresAt"]),
                )
                or result["reasonCode"]
                != (
                    "ELIGIBLE_FOR_OWNER_DECISION"
                    if result["allowed"]
                    else "DENIED_SCOPE_OR_PROFILE"
                )
            ):
                raise OSErrorCode("DENIED")
            return copy.deepcopy(result)
        except OSErrorCode:
            raise
        except (httpx.HTTPError, TimeoutError, ValueError, TypeError, KeyError):
            raise OSErrorCode("UNAVAILABLE") from None
