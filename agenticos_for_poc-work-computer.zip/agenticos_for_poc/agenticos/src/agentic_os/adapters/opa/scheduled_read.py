"""Explicit low-read policy for the existing finite background executor."""
from importlib.resources import files
import re
from types import MappingProxyType
from uuid import UUID

from agentic_os.contracts.canonical import digest
from agentic_os.errors import OSErrorCode
from agentic_os.contracts.validation import validate_contract
from .client import OPAClient


def bundle_pin():
    authority=files('agentic_os').joinpath('policies/scheduled_read.rego').read_text()
    authentication=files('agentic_os').joinpath('policies/operator_auth.rego').read_text()
    return dict(revision=10,digest=digest('policy',dict(revision=10,profile='scheduled-read/1',
        authority=authority,operatorAuth=authentication)))


class ScheduledReadPolicy(OPAClient):
    def __init__(self,origin,token,revision,bundle_digest,*,network,timeout=2):
        if (network not in {'owned-local-http/1','web-pki/1'} or type(revision) is not int
                or revision not in ({1,10} if network=='owned-local-http/1' else {10})
                or type(bundle_digest) is not str or re.fullmatch('[a-f0-9]{64}',bundle_digest) is None
                or revision==10 and bundle_digest!=bundle_pin()['digest']
                or type(token) is not str or not 1<=len(token)<=1024 or any(ord(c)<33 or ord(c)>126 for c in token)
                or type(timeout) not in {int,float} or not 0<timeout<=2):
            raise OSErrorCode('PROFILE_DISABLED')
        self.network=network
        self.required_assurance='local-synthetic' if revision==1 else 'current-host-read/1'
        super().__init__(origin,token,revision,bundle_digest,timeout=timeout)


class ScheduledReadPolicyRouter:
    """Select an exact application credential; every decision stays current."""
    def __init__(self,policies):
        if type(policies) is not dict or not 1<=len(policies)<=64:raise OSErrorCode('PROFILE_DISABLED')
        selected={};pins=set()
        for app,policy in policies.items():
            if (type(app) is not str or str(UUID(app))!=app
                    or type(policy) is not ScheduledReadPolicy):raise OSErrorCode('PROFILE_DISABLED')
            selected[app]=policy;pins.add((policy.revision,policy.bundle_digest,policy.required_assurance,policy.network))
        # ToolBroker's existing requiredBundleRevision has one declared policy
        # contract. Different endpoints/secrets may implement that same pin.
        if len(pins)!=1:raise OSErrorCode('PROFILE_DISABLED')
        self.revision,self.bundle_digest,self.required_assurance,self.network=next(iter(pins))
        self._policies=MappingProxyType(selected)

    async def evaluate(self,value):
        validate_contract('PolicyInput',value)
        policy=self._policies.get(value['subject']['applicationId'])
        if policy is None:raise OSErrorCode('DENIED')
        return await policy.evaluate(value)
