"""Fixed OPA decision contract. Undefined HTTP200 is never permission."""
import asyncio
import httpx
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.contracts.validation import validate_contract
from agentic_os.adapters.http.endpoint import reviewed_http_endpoint
from agentic_os.adapters.http.tls import LOCAL_HTTP_TLS_CONTEXT
from agentic_os.identity.context import utcnow,timestamp,fresh
from agentic_os.errors import OSErrorCode


class OPAClient:
    network='owned-local-http/1'
    required_assurance='local-synthetic'

    def __init__(self,origin,token,revision,bundle_digest,timeout=2):
        self.origin=reviewed_http_endpoint(origin,self.network,origin_only=True);self.token=token
        self.revision=revision;self.bundle_digest=bundle_digest;self.timeout=timeout

    async def evaluate(self,value):
        validate_contract('PolicyInput',value)
        fresh(value['authority'],subject=value['subject'])
        if value['requiredBundleRevision']!=self.revision:
            raise OSErrorCode('DENIED')
        try:
            async with asyncio.timeout(self.timeout):
                async with httpx.AsyncClient(verify=LOCAL_HTTP_TLS_CONTEXT,
                        trust_env=False,follow_redirects=False,timeout=self.timeout) as client:
                    async with client.stream('POST',self.origin+'/v1/data/agentic_os/decision',
                            content=canonical_bytes({'input':value}),headers={'Authorization':'Bearer '+self.token,
                            'Content-Type':'application/json','Accept-Encoding':'identity'}) as response:
                        if response.status_code!=200:
                            raise OSErrorCode('UNAVAILABLE')
                        if (response.headers.get('content-type','').split(';')[0]!='application/json'
                                or response.headers.get('content-encoding','identity')!='identity'):
                            raise OSErrorCode('UNAVAILABLE')
                        content=bytearray()
                        async for chunk in response.aiter_bytes():
                            content.extend(chunk)
                            if len(content)>65536:
                                raise OSErrorCode('UNAVAILABLE')
            raw=parse_canonical_json(bytes(content))
            if set(raw)!={'result'}:
                raise OSErrorCode('UNAVAILABLE')
            result=raw['result'];validate_contract('PolicyDecision',result)
            order={'low':0,'medium':1,'high':2}
            if (result['bundleRevision']!=self.revision or result['bundleDigest']!=self.bundle_digest
                    or result['authorityGeneration']!=value['authority']['policyGeneration']
                    or timestamp(result['validUntil'])<=utcnow()
                    or timestamp(result['validUntil'])>timestamp(value['authority']['validUntil'])
                    or order[result['risk']]<order[value['capability']['riskFloor']]
                    or result['requiredAssurance']!=self.required_assurance
                    or set(result['constraints'])!={'host-current','bot-ceiling','owner-scope'}):
                raise OSErrorCode('DENIED')
            return result
        except OSErrorCode:
            raise
        except Exception:
            raise OSErrorCode('UNAVAILABLE') from None
