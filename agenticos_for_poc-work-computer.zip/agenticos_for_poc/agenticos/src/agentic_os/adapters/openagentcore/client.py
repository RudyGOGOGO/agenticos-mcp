"""Bounded private client for the pinned Core self-hosted session contract."""
from dataclasses import dataclass
import asyncio
from urllib.parse import urlsplit
from uuid import UUID, uuid5

import httpx

from agentic_os.contracts.canonical import canonical_bytes, parse_canonical_json, CanonicalError
from agentic_os.errors import OSErrorCode


def opaque(value):
    try:
        if type(value) is not str or str(UUID(value)) != value or UUID(value).int == 0: raise ValueError()
    except (ValueError, TypeError, AttributeError): raise OSErrorCode('INVALID') from None
    return value


@dataclass(frozen=True)
class SessionIdentity:
    session_id: str
    environment_id: str

    def __post_init__(self):
        opaque(self.session_id); opaque(self.environment_id)


@dataclass(frozen=True)
class NativeResult:
    state: str
    source: str | None
    tokens: int | None
    tools: int | None


class CoreClient:
    def __init__(self, endpoint, project_id, project_key, operator_key, *, local_synthetic=False):
        try:
            url = urlsplit(endpoint)
            valid = (local_synthetic is True and url.scheme == 'http' and url.hostname == '127.0.0.1'
                and 1024 <= url.port <= 65535 and not url.path and not url.query and not url.fragment
                and url.username is None and url.password is None)
        except (ValueError, TypeError): valid = False
        if not valid: raise OSErrorCode('PROFILE_DISABLED')
        self.endpoint, self.project_id = endpoint, opaque(project_id)
        if any(type(key) is not str or not 24 <= len(key) <= 512 for key in (project_key, operator_key)):
            raise OSErrorCode('DENIED')
        self.project_key, self.operator_key = project_key, operator_key
        self.http = httpx.AsyncClient(trust_env=False, follow_redirects=False, timeout=5,
            limits=httpx.Limits(max_connections=4, max_keepalive_connections=2))

    async def close(self): await self.http.aclose()

    async def _request(self, method, path, *, body=None, identity=None, operator=False, expected=(200,)):
        headers = {'Authorization': 'Bearer ' + (self.operator_key if operator else self.project_key),
            'Content-Type': 'application/json', 'OpenAI-Beta': 'agents=v1'}
        if identity is not None: headers['Idempotency-Key'] = opaque(identity)
        try:
            async with asyncio.timeout(5), self.http.stream(method, self.endpoint + path, headers=headers,
                    content=canonical_bytes(body) if body is not None else None) as response:
                if response.status_code not in expected:
                    code = 'CONFLICT' if response.status_code == 409 else 'DENIED' if response.status_code in (401,403,404) else 'UNAVAILABLE'
                    raise OSErrorCode(code)
                raw = bytearray()
                async for part in response.aiter_bytes():
                    raw.extend(part)
                    if len(raw) > 1048576: raise OSErrorCode('CAPACITY')
                return parse_canonical_json(bytes(raw)) if raw else None
        except (httpx.HTTPError, TimeoutError): raise OSErrorCode('UNAVAILABLE') from None
        except CanonicalError: raise OSErrorCode('INVALID') from None

    async def create(self, attempt_id, instructions, gateway_token, fence):
        opaque(attempt_id)
        if (type(instructions) is not str or not 1 <= len(instructions) <= 16000
                or type(gateway_token) is not str or not 24 <= len(gateway_token) <= 512):
            raise OSErrorCode('INVALID')
        await fence()
        config = {'environment': {'type': 'self_hosted', 'workspace_directory': '/tmp/workspace'},
            'agent': {'model': 'synthetic-native-model', 'instructions': instructions, 'tools': [],
                'x_agents_core': {'harness': 'codex'}},
            'metadata': {'os_attempt_id': attempt_id},
            'x_agents_core': {'model_provider': {'protocol': 'responses',
                'base_url': 'https://127.0.0.1:19091/model', 'api_key': gateway_token}}}
        try:
            value = await self._request('POST', '/v1/agents/sessions', body=config,
                identity=attempt_id, expected=(201,))
        except OSErrorCode as error:
            if error.code != 'UNAVAILABLE': raise
            # A lost acknowledgement retries the original idempotent create
            # once, under fresh authority and with byte-identical input.
            await fence()
            value = await self._request('POST', '/v1/agents/sessions', body=config,
                identity=attempt_id, expected=(201,))
        if (type(value) is not dict or type(value.get('environment')) is not dict
                or value['environment'].get('type') != 'self_hosted'
                or value.get('metadata') != {'os_attempt_id': attempt_id}):
            raise OSErrorCode('CONFLICT')
        result = SessionIdentity(value.get('id'), value['environment'].get('id'))
        # Preserve the acknowledged identity before the controller rechecks
        # current authority. A revoked owner can still need cleanup metadata.
        return result

    def credential_route(self, identity):
        if type(identity) is not SessionIdentity: raise OSErrorCode('DENIED')
        return '/core/v1/projects/' + self.project_id + '/environments/' + identity.environment_id + '/executor-credentials'

    async def credential(self, identity, fence):
        await fence(); key_id = str(uuid5(UUID(identity.environment_id), 'agentic-os.executor/1'))
        value = await self._request('POST', self.credential_route(identity), operator=True,
            body={'key_id': key_id, 'rotate': False}, expected=(201,))
        if (type(value) is not dict or set(value) != {'key_id','environment_id','executor_token'}
                or value['key_id'] != key_id or value['environment_id'] != identity.environment_id
                or type(value['executor_token']) is not str or not 24 <= len(value['executor_token']) <= 512):
            raise OSErrorCode('CONFLICT')
        await fence()
        return value

    async def connected(self, identity):
        value = await self._request('GET', self.credential_route(identity), operator=True)
        if type(value) is not dict or type(value.get('connection')) is not dict: raise OSErrorCode('UNAVAILABLE')
        status = value['connection'].get('status')
        if status not in {'never_enrolled','connected','disconnected'}: raise OSErrorCode('UNAVAILABLE')
        return status == 'connected'

    async def submit(self, identity, attempt_id, text, fence):
        if type(identity) is not SessionIdentity or type(text) is not str or not 1 <= len(text) <= 16000:
            raise OSErrorCode('INVALID')
        await fence()
        await self._request('POST', '/v1/agents/sessions/' + identity.session_id + '/events',
            body={'events': [{'type': 'agent.session.input.message', 'input': [
                {'role': 'user', 'content': [{'type': 'input_text','text': text}]}]}]},
            identity=str(uuid5(UUID(opaque(attempt_id)), 'agentic-os.native-input/1')), expected=(200,201,202,204))
        await fence()

    async def cancel(self, identity, attempt_id):
        # Identity-only recovery can stop accepted work after revocation.
        if type(identity) is not SessionIdentity: raise OSErrorCode('DENIED')
        await self._request('POST', '/v1/agents/sessions/' + identity.session_id + '/events',
            body={'events':[{'type':'agent.session.input.cancel'}]},
            identity=str(uuid5(UUID(opaque(attempt_id)), 'agentic-os.native-cancel/1')), expected=(200,201,202,204))

    async def revoke(self, identity):
        key_id = str(uuid5(UUID(identity.environment_id), 'agentic-os.executor/1'))
        await self._request('DELETE', self.credential_route(identity) + '/' + key_id,
            operator=True, expected=(204,))

    async def result(self, identity, fence, *, allow_source=True):
        if type(identity) is not SessionIdentity or type(allow_source) is not bool: raise OSErrorCode('DENIED')
        page = await self._request('GET', '/v1/agents/sessions/' + identity.session_id + '/turns?limit=100&order=asc')
        if (type(page) is not dict or page.get('has_more') is not False or type(page.get('data')) is not list
                or len(page['data']) > 1): raise OSErrorCode('CONFLICT')
        if not page['data']: return None
        turn = page['data'][0]
        if (turn.get('session_id') != identity.session_id or turn.get('object') != 'agent.session.turn'
                or turn.get('subagent_id') is not None): raise OSErrorCode('CONFLICT')
        status = turn.get('status')
        if status in {'queued','in_progress','waiting'}: return None
        if status not in {'completed','failed','cancelled'}: raise OSErrorCode('CONFLICT')
        usage = turn.get('usage'); tokens = usage.get('total_tokens') if type(usage) is dict else None
        if type(tokens) is not int or not 0 <= tokens <= 9007199254740991: tokens = None
        if status != 'completed' or not allow_source:
            return NativeResult(status, None, tokens, None)
        await fence()
        items = await self._request('GET', '/v1/agents/sessions/' + identity.session_id + '/items?limit=100&order=asc')
        if (type(items) is not dict or items.get('has_more') is not False or type(items.get('data')) is not list
                or len(items['data']) > 32): raise OSErrorCode('CAPACITY')
        drafts = []; tools = 0
        for item in items['data']:
            if type(item) is not dict: raise OSErrorCode('INVALID')
            if item.get('turn_id') != turn['id']: raise OSErrorCode('CONFLICT')
            kind = item.get('type')
            if kind in {'command_execution','function_call','mcp_call','web_search_call'}: tools += 1
            if kind in {'create_subagent_call','send_subagent_input_call','resume_subagent_call'}:
                raise OSErrorCode('DENIED')
            if (kind == 'message' and item.get('role') == 'assistant' and item.get('status') == 'completed'
                    and item.get('phase') == 'final_answer'):
                parts = item.get('content')
                if (type(parts) is not list or len(parts) != 1 or parts[0].get('type') != 'output_text'
                        or type(parts[0].get('text')) is not str): raise OSErrorCode('INVALID')
                drafts.append(parse_canonical_json(parts[0]['text']))
        if (len(drafts) != 1 or type(drafts[0]) is not dict or set(drafts[0]) != {'source'}
                or type(drafts[0]['source']) is not str or not 1 <= len(drafts[0]['source'].encode()) <= 65536):
            raise OSErrorCode('INVALID')
        await fence()
        return NativeResult('completed', drafts[0]['source'], tokens, tools)
