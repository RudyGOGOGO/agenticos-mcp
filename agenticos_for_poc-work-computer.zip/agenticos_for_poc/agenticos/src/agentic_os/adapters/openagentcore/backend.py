"""Explicit owned Core backend and TLS ingress for the local synthetic profile.

Provisioning persists backend credentials once. Restarts retain the original
project and encryption key; partial provisioning is held for operator recovery.
No guest receives these files or the private operator/project credentials.
"""
import asyncio
import base64
from contextlib import asynccontextmanager
import hashlib
import os
from pathlib import Path
import secrets
import signal
import shlex
import socket
import ssl
import subprocess
import time
from urllib.parse import quote
from uuid import uuid4

from agentic_os.adapters.local.files import check_private, private_directory, private_read, private_write, OwnershipError
from agentic_os.adapters.local.resources import read_signed, write_signed, file_lock
from agentic_os.adapters.local.target import connect_owned, validate_target
from agentic_os.adapters.sandbox.controller import NativeOwner
from agentic_os.adapters.sandbox.certificates import public_certificate
from agentic_os.adapters.sandbox.processes import ProcessPeak,watch_group,reap_group,completed
from agentic_os.contracts.canonical import canonical_bytes
from agentic_os.errors import OSErrorCode
from .client import CoreClient, opaque

FILES = {'password','credential-key','operator-key','core-digests','installation-id',
    'ca.key','ca.crt','server.key','server.csr','server.crt','ca.srl','leaf.ext'}
MAX_LOG=1024**2
MAX_RSS=512*1024**2


class CoreBackend:
    def __init__(self, owner, *, local_synthetic=False):
        if local_synthetic is not True or type(owner) is not NativeOwner:raise OSErrorCode('PROFILE_DISABLED')
        self.owner=owner; self.installation=owner.installation
        self.root=self.installation.manifest_path.parent/'core-service'
        self.key=self.installation.key
        self.process=self.relay=self.client=None;self.connections=set();self.writers=set()
        self.log_task=self.monitor=None;self.peak=None;self.resource_fault=None
        self._guard()

    @classmethod
    def provision(cls, owner, *, local_synthetic=False):
        if local_synthetic is not True or type(owner) is not NativeOwner:raise OSErrorCode('PROFILE_DISABLED')
        owner._guard();installation=owner.installation;root=installation.manifest_path.parent/'core-service'
        if root.exists() or root.is_symlink():
            result=cls(owner,local_synthetic=True)
            # Public CA permissions must survive the SDK's exact CopyFile
            # patch so the assigned UID1000 can read it. The directory and
            # every private key remain private. No certificate bytes change.
            public_certificate(root/'ca.crt');(root/'ca.crt').chmod(0o644)
            return result
        manifest=validate_target(installation.manifest_path,component='core')
        with connect_owned(installation.manifest_path,component='core') as db:
            if db.execute('SELECT max(version_id) FROM agents_api_schema_version WHERE is_applied').fetchone()[0]!=91:
                raise OSErrorCode('UNAVAILABLE')
        private_directory(root);operator=secrets.token_hex(32)
        values={'password':manifest['databases']['core']['runtimePassword'].encode(),
            'credential-key':base64.b64encode(secrets.token_bytes(32)),'operator-key':operator.encode(),
            'core-digests':canonical_bytes([hashlib.sha256(operator.encode()).hexdigest()]),
            'installation-id':manifest['installationId'].encode(),
            'leaf.ext':b'basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=DNS:localhost,IP:127.0.0.1\n'}
        for name,value in values.items():private_write(root/name,value)
        commands=[['req','-x509','-newkey','rsa:2048','-nodes','-days','3650','-subj','/CN=Owned synthetic Core CA','-keyout','ca.key','-out','ca.crt'],
            ['req','-newkey','rsa:2048','-nodes','-subj','/CN=localhost','-keyout','server.key','-out','server.csr'],
            ['x509','-req','-in','server.csr','-CA','ca.crt','-CAkey','ca.key','-CAcreateserial','-days','3650','-extfile','leaf.ext','-out','server.crt']]
        for command in commands:
            result=subprocess.run(['/usr/bin/openssl',*command],cwd=root,env={'PATH':'/usr/bin:/bin'},
                capture_output=True,timeout=15,umask=0o077)
            if result.returncode:raise OSErrorCode('UNAVAILABLE')
        (root/'ca.crt').chmod(0o644)
        pins={name:hashlib.sha256(public_certificate(root/name) if name=='ca.crt' else private_read(root/name,16384)).hexdigest() for name in FILES}
        write_signed(root/'state.json',{'version':1,'owner':owner.owner,'files':pins,
            'phase':'new','projectId':None,'projectKey':None},installation.key)
        return cls(owner,local_synthetic=True)

    def _guard(self):
        self.owner._guard();check_private(self.root,directory=True)
        if self.root.resolve(strict=True)!=self.root or {p.name for p in self.root.iterdir()}-FILES-{'state.json','core.log','service.lock','process.json'}:
            raise OwnershipError('Core service directory is unregistered')
        state=read_signed(self.root/'state.json',self.key,maximum=16384)
        if (type(state) is not dict or set(state)!={'version','owner','files','phase','projectId','projectKey'}
                or state['version']!=1 or state['owner']!=self.owner.owner or set(state['files'])!=FILES
                or state['phase'] not in {'new','provisioning','ready'}):raise OwnershipError('Core service binding changed')
        for name,pin in state['files'].items():
            data=public_certificate(self.root/name) if name=='ca.crt' else private_read(self.root/name,16384)
            if hashlib.sha256(data).hexdigest()!=pin:raise OwnershipError('Core service file changed')
        if state['phase']=='ready':
            opaque(state['projectId'])
            if type(state['projectKey']) is not str or not 24<=len(state['projectKey'])<=512:raise OwnershipError('Core project key changed')
        elif state['projectId'] is not None or state['projectKey'] is not None:raise OwnershipError('Partial Core service identity')
        return state

    async def _copy(self, reader, writer):
        total=0
        try:
            async with asyncio.timeout(125):
                while data:=await reader.read(16384):
                    total+=len(data)
                    if total>16*1024**2:raise OSErrorCode('CAPACITY')
                    writer.write(data);await writer.drain()
        finally:writer.close()

    async def _relay(self, reader, writer):
        task=asyncio.current_task();self.connections.add(task);self.writers.add(writer)
        upstream=None
        try:
            if len(self.connections)>4:return
            r,upstream=await asyncio.open_connection('127.0.0.1',self.port)
            self.writers.add(upstream)
            await asyncio.gather(self._copy(reader,upstream),self._copy(r,writer))
        except (OSError,TimeoutError,OSErrorCode):pass
        finally:
            writer.close();self.writers.discard(writer)
            if upstream is not None:upstream.close();self.writers.discard(upstream)
            self.connections.discard(task)

    @asynccontextmanager
    async def running(self):
        lock=file_lock(self.root/'service.lock',timeout=0)
        _,cancellation=await completed(asyncio.to_thread(lock.__enter__))
        try:
            if cancellation is not None:raise cancellation
            await self._recover_process()
            async with self._running():yield self
        finally:
            _,cancellation=await completed(asyncio.to_thread(lock.__exit__,None,None,None))
            if cancellation is not None:raise cancellation

    async def _original_processes(self,nonce):
        # Environment is inspected privately and never logged. A nonce
        # persisted before spawn binds even a lost allocation acknowledgement.
        probe=await asyncio.create_subprocess_exec('/bin/ps','eww','-axo','pid=,pgid=,command=',
            stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.DEVNULL)
        try:
            async with asyncio.timeout(2):raw,_=await probe.communicate()
            if probe.returncode or len(raw)>4*1024**2:raise OSErrorCode('UNAVAILABLE')
            executable=str(self.installation.root/'core');rows=[]
            for line in raw.decode().splitlines():
                fields=line.split(None,2)
                if len(fields)!=3 or not (fields[2]==executable or fields[2].startswith(executable+' ')):continue
                args=shlex.split(fields[2])
                if nonce is None or 'AOS_CORE_PROCESS_NONCE='+nonce not in args:raise OSErrorCode('UNAVAILABLE')
                pid,group=map(int,fields[:2])
                if pid!=group:raise OSErrorCode('UNAVAILABLE')
                rows.append(pid)
            if len(rows)>1:raise OSErrorCode('UNAVAILABLE')
            return rows
        finally:
            if probe.returncode is None:probe.kill()
            await probe.wait()

    async def _recover_process(self):
        self._guard();path=self.root/'process.json';nonce=None
        if path.exists() or path.is_symlink():
            intent=read_signed(path,self.key,maximum=4096)
            if (type(intent) is not dict or set(intent)!={'version','owner','artifact','nonce'}
                    or intent['version']!=1 or intent['owner']!=self.owner.owner
                    or intent['artifact']!=self.owner.owner_artifact('core')
                    or type(intent['nonce']) is not str or len(intent['nonce'])!=64
                    or any(c not in '0123456789abcdef' for c in intent['nonce'])):raise OSErrorCode('UNAVAILABLE')
            nonce=intent['nonce']
        rows=await self._original_processes(nonce)
        for pid in rows:
            # Recheck the original nonce immediately before signalling.
            if await self._original_processes(nonce)!=rows:raise OSErrorCode('UNAVAILABLE')
            try:os.killpg(pid,signal.SIGKILL)
            except ProcessLookupError:pass
        async with asyncio.timeout(3):
            while await self._original_processes(nonce):await asyncio.sleep(.05)
        if nonce is not None:path.unlink()

    def _fault(self,error):
        self.resource_fault=error
        if self.process is not None and self.process.returncode is None:
            try:
                if os.getpgid(self.process.pid)!=self.process.pid:raise OSErrorCode('UNAVAILABLE')
                os.killpg(self.process.pid,signal.SIGKILL)
            except ProcessLookupError:pass

    async def _log(self,path):
        try:
            used=path.stat().st_size
            with path.open('ab') as output:
                while chunk:=await self.process.stdout.read(8192):
                    if used+len(chunk)>MAX_LOG:raise OSErrorCode('CAPACITY')
                    output.write(chunk);output.flush();used+=len(chunk)
        except Exception as error:self._fault(error)

    async def _resources(self):
        try:await watch_group(self.process,self.peak,max_rss=MAX_RSS)
        except Exception as error:self._fault(error)

    async def _shutdown(self):
        failure=None
        if self.relay is not None:
            try:
                self.relay.close()
                async with asyncio.timeout(3):await self.relay.wait_closed()
            except Exception as error:failure=error
            else:self.relay=None
        for writer in tuple(self.writers):
            try:writer.close()
            except Exception as error:failure=failure or error
        for task in tuple(self.connections):task.cancel()
        try:
            async with asyncio.timeout(3):await asyncio.gather(*tuple(self.connections),return_exceptions=True)
        except Exception as error:failure=failure or error
        if self.client is not None:
            try:
                async with asyncio.timeout(3):await self.client.close()
            except Exception as error:failure=failure or error
            else:self.client=None
        if self.process is not None:
            try:await reap_group(self.process,self.log_task,self.monitor)
            except Exception as error:failure=failure or error
            else:self.process=None
        if self.process is None and getattr(self,'installation',None) is not None:
            try:await self._recover_process()
            except Exception as error:failure=failure or error
        if self.process is None:self.log_task=self.monitor=None
        if failure is not None:raise failure

    @asynccontextmanager
    async def _running(self):
        if self.process is not None or self.client is not None or self.relay is not None or self.connections:raise OSErrorCode('CONFLICT')
        state=await asyncio.to_thread(self._guard)
        if state['phase']=='provisioning':raise OSErrorCode('UNAVAILABLE')
        manifest=await asyncio.to_thread(validate_target,self.installation.manifest_path,component='core')
        database=manifest['databases']['core']
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));self.port=sock.getsockname()[1]
        self.endpoint='http://127.0.0.1:'+str(self.port)
        environment={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','HOME':str(self.root),
            'TMPDIR':str(self.installation.home/'tmp'),
            'OAC_DATABASE_URL':'postgresql://'+quote(database['runtime'],safe='')+'@127.0.0.1:'+str(manifest['postgres']['port'])+'/'+database['name']+'?sslmode=disable',
            **{env:str(self.root/name) for env,name in {'OAC_DATABASE_PASSWORD_FILE':'password',
                'OAC_CREDENTIAL_KEY_FILE':'credential-key','OAC_CORE_KEY_DIGESTS_FILE':'core-digests',
                'OAC_INSTALLATION_ID_FILE':'installation-id'}.items()},
            'OAC_PUBLIC_URL':'https://127.0.0.1:19090','OAC_ADDR':'127.0.0.1:'+str(self.port),
            'OAC_HARNESSES':'codex','OAC_EXECUTION_CONCURRENCY':'2'}
        log=self.root/'core.log'
        if not log.exists():private_write(log,b'')
        check_private(log)
        if log.stat().st_size>=MAX_LOG:raise OSErrorCode('CAPACITY')
        self.resource_fault=None;self.peak=ProcessPeak()
        nonce=secrets.token_hex(32)
        write_signed(self.root/'process.json',{'version':1,'owner':self.owner.owner,
            'artifact':self.owner.owner_artifact('core'),'nonce':nonce},self.key)
        environment['AOS_CORE_PROCESS_NONCE']=nonce
        try:
            self.process,cancellation=await completed(asyncio.create_subprocess_exec(str(self.installation.root/'core'),
                env=environment,cwd=self.root,stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,start_new_session=True,limit=16384))
            self.log_task=asyncio.create_task(self._log(log));self.monitor=asyncio.create_task(self._resources())
            operator=private_read(self.root/'operator-key',512).decode()
            self.client=CoreClient(self.endpoint,state['projectId'] or str(uuid4()),state['projectKey'] or 'pending'*8,
                operator,local_synthetic=True)
            if cancellation is not None:raise cancellation
            until=time.monotonic()+10
            while True:
                if self.process.returncode is not None:raise OSErrorCode('UNAVAILABLE')
                try:await self.client._request('GET','/core/v1/projects',operator=True);break
                except OSErrorCode:
                    if time.monotonic()>=until:raise
                    await asyncio.sleep(.1)
            if state['phase']=='new':
                state['phase']='provisioning';await asyncio.to_thread(write_signed,self.root/'state.json',state,self.key)
                project=await self.client._request('POST','/core/v1/projects',operator=True,
                    body={'name':'Owned Agentic OS native service'},expected=(201,))
                ident=opaque(project.get('id'));self.client.project_id=ident
                key=await self.client._request('POST','/core/v1/projects/'+ident+'/keys',operator=True,
                    body={'name':'OS native private sessions'},expected=(201,))
                self.client.project_key=key['key']
                state.update(phase='ready',projectId=ident,projectKey=key['key'])
                await asyncio.to_thread(write_signed,self.root/'state.json',state,self.key)
            await asyncio.to_thread(self._guard)
            tls=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);tls.minimum_version=ssl.TLSVersion.TLSv1_2
            tls.load_cert_chain(self.root/'server.crt',self.root/'server.key')
            self.relay=await asyncio.start_server(self._relay,'127.0.0.1',0,ssl=tls,
                ssl_handshake_timeout=3,ssl_shutdown_timeout=1)
            self.tls_port=self.relay.sockets[0].getsockname()[1]
            yield self
        finally:
            _,cancellation=await completed(self._shutdown())
            if cancellation is not None:raise cancellation
        if self.resource_fault is not None:raise OSErrorCode('CAPACITY')
