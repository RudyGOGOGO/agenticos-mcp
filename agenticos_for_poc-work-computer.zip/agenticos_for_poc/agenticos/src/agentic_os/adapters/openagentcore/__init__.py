"""Pinned private Core adapter; explicit native profile only."""
