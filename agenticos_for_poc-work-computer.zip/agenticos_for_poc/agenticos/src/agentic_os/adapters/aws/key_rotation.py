"""Purpose-specific staged key material for the existing AWS maintenance operation.

Historical inventory authenticates immutable initial ancestry only. Current
runtime authority still requires the exact selected complete material inventory.
"""
import base64
from copy import deepcopy
import hashlib
from pathlib import Path
import re
from uuid import uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from agentic_os.contracts.canonical import canonical_bytes
from agentic_os.adapters.configured_installation import closed
from agentic_os.adapters.local.artifacts import LocalKeys,checked_id
from agentic_os.adapters.local.files import OwnershipError,private_read
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.resources import ensure_private,read_signed,write_signed,tree_inventory
from agentic_os.adapters.local.recovery_key_continuity import sha
from agentic_os.adapters.local.recovery_key_operations import apply_key_rotation
from agentic_os.adapters.local.recovery_maintenance import DIRECTORY,_operation
from . import readiness

PURPOSES={'history':('privateHistory','keys'),'knowledge':('privateKnowledge','protected-knowledge/keys')}
RECORDS={'privateHistory','privateKnowledge','knowledgeBinding','operatorStateDigest'}
STAGE='aws-staged-private-key/1'
STAGE_FILE='staged-key.json'
STAGE_FIELDS={'profile','installationId','runId','commandId','configurationDigest','priorCertificateDigest',
    'priorGeneration','purpose','keyId','keyDigest','previous','raw'}


def checked_state(value):
    try:
        closed(value,{'records','selectors'});closed(value['records'],RECORDS)
        closed(value['selectors'],{'privateHistory','privateKnowledge'})
        if not re.fullmatch('[a-f0-9]{64}',value['records']['operatorStateDigest']):raise ValueError()
        if type(value['records']['knowledgeBinding']) is not dict:raise ValueError()
        for name in ('privateHistory','privateKnowledge'):
            records=value['records'][name];active=checked_id(value['selectors'][name])
            if type(records) is not dict or not 2<=len(records)<=129 or 'active.json' not in records or active+'.key' not in records:raise ValueError()
            for file,record in records.items():
                closed(record,{'mode','size','sha256'})
                if (type(record['mode']) is not int or record['mode'] not in {0o400,0o600}
                        or type(record['size']) is not int or not 1<=record['size']<=128
                        or type(record['sha256']) is not str or re.fullmatch('[a-f0-9]{64}',record['sha256']) is None):raise ValueError()
                if file=='active.json':
                    raw=canonical_bytes(dict(id=active))
                    if record['size']!=len(raw) or record['sha256']!=hashlib.sha256(raw).hexdigest():raise ValueError()
                elif not file.endswith('.key') or checked_id(file[:-4])+'.key'!=file or record['size']!=32:raise ValueError()
    except Exception:raise OwnershipError('Closed AWS key material inventory unavailable') from None
    return value


def state_digest(value):
    checked_state(value);records=value['records']
    return readiness._material_records_digest(records['privateHistory'],records['privateKnowledge'],
        records['knowledgeBinding'],records['operatorStateDigest'])


def snapshot(path):
    path=Path(path);records={};selectors={}
    for name,directory in PURPOSES.values():
        keys=LocalKeys(path.parent/directory);selectors[name]=keys.active()
        records[name]=tree_inventory(keys.directory,maximum=128*1024)['files']
    records.update(knowledgeBinding=read_signed(path.parent/'knowledge-key-binding.json',path.parent/'owner.key'),
        operatorStateDigest=hashlib.sha256(private_read(path.parent/'operator-state.json')).hexdigest())
    value=checked_state(dict(records=records,selectors=selectors))
    if state_digest(value)!=readiness._materials(path):raise OwnershipError('AWS key inventory changed during capture')
    return value


def historical_digest(path,value,operator_configuration=None):
    """Original keys/binding/operator stay exact; only the active selector may advance."""
    path=Path(path);checked_state(value);records=value['records']
    operator_digest=hashlib.sha256(private_read(path.parent/'operator-state.json')).hexdigest()
    if operator_configuration is not None:
        from .operator_rotation import checked_configuration,digest
        operator_digest=digest(checked_configuration(path,operator_configuration)['initial'])
    if (records['knowledgeBinding']!=read_signed(path.parent/'knowledge-key-binding.json',path.parent/'owner.key')
            or records['operatorStateDigest']!=operator_digest):
        raise OwnershipError('Original AWS private authority changed')
    for name,directory in PURPOSES.values():
        observed=tree_inventory(path.parent/directory,maximum=128*1024)['files']
        for file,record in records[name].items():
            if file!='active.json' and observed.get(file)!=record:raise OwnershipError('Original AWS private key changed')
    return state_digest(value)


def checked_configuration(value,*,path=None,operator_configuration=None):
    try:
        closed(value,{'initial','current','rotations'});checked_state(value['initial']);checked_state(value['current'])
        if type(value['rotations']) is not int or not (0 if operator_configuration is not None else 1)<=value['rotations']<=8:raise ValueError()
        added=0
        for name in ('privateHistory','privateKnowledge'):
            original=value['initial']['records'][name];current=value['current']['records'][name]
            if any(current.get(k)!=v for k,v in original.items() if k!='active.json'):raise ValueError()
            new=set(current)-set(original);added+=len(new)
            active=value['current']['selectors'][name]
            if new and active+'.key' not in new or not new and active!=value['initial']['selectors'][name]:raise ValueError()
        if added!=value['rotations']:raise ValueError()
        if value['initial']['records']['knowledgeBinding']!=value['current']['records']['knowledgeBinding']:raise ValueError()
        if operator_configuration is None:
            if value['initial']['records']['operatorStateDigest']!=value['current']['records']['operatorStateDigest']:raise ValueError()
        else:
            from .operator_rotation import checked_configuration as operators,digest
            operators(path,operator_configuration)
            if any(value[k]['records']['operatorStateDigest']!=digest(operator_configuration[k]) for k in ('initial','current')):raise ValueError()
    except Exception:raise OwnershipError('AWS material continuity unavailable') from None
    return value


def stage(path,command,purpose,prior,configuration_digest,before):
    path=Path(path);checked_id(command);checked_state(before)
    if purpose not in PURPOSES:raise OwnershipError('Explicit AWS private key purpose required')
    if state_digest(before)!=prior['materialsDigest']:raise OwnershipError('Original AWS material checkpoint differs')
    name,_=PURPOSES[purpose]
    if len(before['records'][name])>=129:raise OwnershipError('AWS key rotation envelope exhausted')
    manifest=load_manifest(path)
    if (prior.get('installationId')!=manifest['installationId'] or prior.get('runId')!=manifest['runId']
            or type(configuration_digest) is not str or re.fullmatch('[a-f0-9]{64}',configuration_digest) is None
            or type(prior.get('generation')) is not int or prior['generation']<2 or prior['generation']%2):
        raise OwnershipError('Original AWS key stage authority differs')
    binding=dict(installationId=manifest['installationId'],runId=manifest['runId'],commandId=command,
        configurationDigest=configuration_digest,priorCertificateDigest=sha(prior),priorGeneration=prior['generation'],purpose=purpose,
        previous=before['selectors'][name])
    op=_operation(path,command);file=op/STAGE_FILE
    ensure_private(path.parent/DIRECTORY);ensure_private(op)
    if file.exists() or file.is_symlink():
        value=read_signed(file,path.parent/'owner.key',maximum=32768)
        if file.lstat().st_nlink!=1:raise OwnershipError('Shared AWS key stage unavailable')
        checked_stage(value)
        if any(value.get(k)!=v for k,v in binding.items()):raise OwnershipError('Original AWS key stage selection differs')
    else:
        if set(p.name for p in op.iterdir())-{'prior-ready.json','work-before.json'}:
            raise OwnershipError('Unknown AWS key operation material exists')
        raw=AESGCM.generate_key(bit_length=256)
        value=dict(profile=STAGE,**binding,keyId=str(uuid4()),keyDigest=hashlib.sha256(raw).hexdigest(),raw=base64.b64encode(raw).decode('ascii'))
        checked_stage(value)
        write_signed(file,value,path.parent/'owner.key')
    checked_stage(value)
    if value['keyId']+'.key' in before['records'][name]:raise OwnershipError('AWS key stage adopts known material')
    return value


def checked_stage(value):
    try:
        closed(value,STAGE_FIELDS)
        if value['profile']!=STAGE or value['purpose'] not in PURPOSES:raise ValueError()
        for key in ('installationId','commandId','keyId','previous'):checked_id(value[key])
        if (type(value['priorGeneration']) is not int or value['priorGeneration']<2 or value['priorGeneration']%2
                or re.fullmatch('[a-f0-9]{12}',value['runId']) is None):raise ValueError()
        for key in ('configurationDigest','priorCertificateDigest','keyDigest'):
            if re.fullmatch('[a-f0-9]{64}',value[key]) is None:raise ValueError()
        raw=base64.b64decode(value['raw'],validate=True)
        if len(raw)!=32 or hashlib.sha256(raw).hexdigest()!=value['keyDigest']:raise ValueError()
    except Exception:raise OwnershipError('Exact staged AWS key unavailable') from None
    return value


def pin(value):
    checked_stage(value)
    return {k:value[k] for k in ('purpose','keyId','keyDigest','previous')}|dict(stageDigest=sha(value))


def rotated_configuration(initial,before,value,rotations,*,path=None,operator_configuration=None):
    checked_state(initial);checked_state(before);checked_stage(value)
    name,_=PURPOSES[value['purpose']]
    if value['previous']!=before['selectors'][name] or value['keyId']+'.key' in before['records'][name]:
        raise OwnershipError('Original AWS rotation selector differs')
    after=deepcopy(before);raw=canonical_bytes(dict(id=value['keyId']))
    after['records'][name][value['keyId']+'.key']=dict(mode=0o600,size=32,sha256=value['keyDigest'])
    after['records'][name]['active.json']=dict(mode=0o600,size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    after['selectors'][name]=value['keyId']
    return checked_configuration(dict(initial=initial,current=after,rotations=rotations+1),path=path,operator_configuration=operator_configuration)


def apply(path,before,value):
    """Preserve the other complete purpose before changing any selected key."""
    path=Path(path);checked_state(before);checked_stage(value);name,directory=PURPOSES[value['purpose']]
    for other,relative in PURPOSES.values():
        if other!=name:
            if (tree_inventory(path.parent/relative,maximum=128*1024)['files']!=before['records'][other]
                    or LocalKeys(path.parent/relative).active()!=before['selectors'][other]):
                raise OwnershipError('Other AWS key purpose changed')
    known={file[:-4]:record['sha256'] for file,record in before['records'][name].items() if file!='active.json'}
    apply_key_rotation(path.parent/directory,known,value['previous'],value['keyId'],base64.b64decode(value['raw'],validate=True))
