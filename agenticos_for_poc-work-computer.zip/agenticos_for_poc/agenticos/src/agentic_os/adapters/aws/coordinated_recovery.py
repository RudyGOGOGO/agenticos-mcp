"""Configured three-store recovery capture using an external managed snapshot.

The existing Cloud service retains history. Capture and sealing cannot publish
Ready or restore any database. A target still needs exact data, privacy, history,
quarantine and current-code release reconciliation.
"""
import asyncio
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import asdict
import hashlib
import hmac
import re
from pathlib import Path
import time
from uuid import UUID

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.adapters.configured_installation import closed,canonical_file
from agentic_os.adapters.local import coordinated_backup as backup,recovery_gate as gate
from agentic_os.adapters.local.artifacts import checked_id
from agentic_os.adapters.local.files import OwnershipError,private_directory,private_read,private_write,check_private
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.resources import file_lock,read_signed,write_signed
from agentic_os.adapters.local.recovery_runtime_checkpoint import runtime_checkpoint,checked_runtime_checkpoint
from agentic_os.adapters.local.recovery_checkpoints import snapshot_checkpoints,checked_records
from agentic_os.adapters.local.recovery_metadata import metadata_bytes,bind_cloud_source,checked_metadata,FILE as METADATA
from . import readiness,renewal,key_recovery,storage,recovery
from .temporal import configured_operator_connection,inspect_parked_history,checked_history_capture

PROFILE='aws-managed-cloud-recovery/1'
CONFIGURATION='aws-managed-cloud-recovery-source/1'
INTENT='aws-managed-cloud-recovery-intent/1'
SOURCE_FIELDS={'instance_id','resource_id','kms_key_arn','engine_version','port'}
INTENT_FIELDS={'profile','installationId','sourceRunId','commandId','configurationDigest','priorGate','parkGeneration',
    'sourceRelease','sourceArtifact','operatorContentDigest','recoveryKey','recoveryKeyDigest','journalRoot','controlsRoot'}
PREPARED_FIELDS={'profile','id','installationId','sourceRunId','sourceGeneration','configurationDigest',
    'captureDigest','ciphertextDigest','plaintextBytes','preparedAtNs','snapshot'}
PAYLOAD_FIELDS={'sourceRelease','sourceArtifact','sourceGate','runtimeCheckpoint','journalCheckpoints',
    'controlsCheckpoints','components','cloudCapture','files'}


def configuration(document):
    """Closed public references and complete store/schema inputs before IO."""
    try:
        closed(document,{'schema','current','prior','source','artifact'})
        if document['schema']!=CONFIGURATION:raise ValueError()
        stores,cloud,_=readiness.configuration(document['current']);readiness.configuration(document['prior'])
        manifest=load_manifest(stores['installation']['manifest'])
        if manifest['profile']!='aws-eks/1':raise ValueError()
        artifact=canonical_file(document['artifact'])
        closed(document['source'],SOURCE_FIELDS)
        aws=document['current']['stores']['installation']['aws']
        source=recovery.SnapshotPin(UUID(manifest['installationId']),aws['region'],aws['account'],
            identifier='aos-'+UUID(manifest['installationId']).hex+'-'+'0'*32,capture_digest='0'*64,
            source_run=manifest['runId'],source_generation=1,**document['source'])
        settings=[aws['postgres'],*aws['stores'].values()]
        if any(v['host']!=settings[0]['host'] or v['port']!=source.port for v in settings):raise ValueError()
        return deepcopy(document),stores,cloud,artifact
    except Exception:raise OwnershipError('Closed configured managed recovery source required') from None


def load_configuration(path):
    try:
        value=parse_canonical_json(private_read(canonical_file(str(path)),131072));configuration(value);return value
    except Exception:raise OwnershipError('Managed recovery source configuration unavailable') from None


def _sha(value):return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _intent(path,command):
    path=Path(path);file=path.parent/'backups'/checked_id(command)/'intent.json'
    value=read_signed(file,path.parent/'owner.key',maximum=2*1024**2)
    try:
        closed(value,INTENT_FIELDS);manifest=load_manifest(path)
        if (file.lstat().st_nlink!=1 or value['profile']!=INTENT or value['installationId']!=manifest['installationId']
                or value['sourceRunId']!=manifest['runId'] or value['commandId']!=command
                or type(value['parkGeneration']) is not int or value['parkGeneration']!=value['priorGate']['generation']+1
                or value['priorGate']['mode']!='READY' or value['sourceRelease']['generation']!=value['priorGate']['generation']):raise ValueError()
        closed(value['priorGate'],gate.FIELDS)
        if any(value['priorGate'][k]!=manifest[k] for k in ('installationId','runId')):raise ValueError()
        for k in ('configurationDigest','recoveryKeyDigest','operatorContentDigest'):
            if not backup._digest(value[k]):raise ValueError()
        for k in ('recoveryKey','journalRoot','controlsRoot'):canonical_file(value[k])
        closed(value['sourceArtifact'],{'artifactDigest','releaseDigest','programs'})
        for k in ('artifactDigest','releaseDigest'):
            if not backup._digest(value['sourceArtifact'][k]):raise ValueError()
        checked_runtime_checkpoint(value['sourceArtifact']['programs']|dict(registrations=[],admittedDefinitions=[],pendingEffects=[]))
    except Exception:raise OwnershipError('Original managed recovery intent unavailable') from None
    return value


def _key(intent):
    file=canonical_file(intent['recoveryKey']);raw=private_read(file,32)
    if len(raw)!=32 or file.lstat().st_nlink!=1 or hashlib.sha256(raw).hexdigest()!=intent['recoveryKeyDigest']:
        raise OwnershipError('Original independent recovery key unavailable')
    return raw


def _current(path,token,intent):
    verify_operator(path,token);current=gate.state(path)
    if (current['mode']!='PARKED' or current['generation']!=intent['parkGeneration']
            or key_recovery._raw_proof(path)!=intent['sourceRelease']
            or readiness._runtime_content()!=intent['operatorContentDigest']):
        raise OwnershipError('Original parked managed recovery source changed')
    return current


@contextmanager
def _stores(document,token):
    """Separately scoped migrators; no runtime RLS visibility as backup truth."""
    with storage.configured_storage(document['current']['stores']) as (stores,operator):
        identity=operator(token)
        def connect(name):
            db=stores[name].connect()
            try:
                if name=='control':storage.check_control_namespace(db,stores[name].installation_id)
                else:storage.check_component_namespace(db,stores[name].installation_id,name)
                db.rollback();db.execute('SET TRANSACTION READ ONLY')
                return db
            except BaseException:db.close();raise
        yield {name:(lambda name=name:connect(name)) for name in storage.COMPONENTS}
        if operator(token)!=identity:raise OwnershipError('Snapshot operator secret changed')


def _watermarks(path,connections):
    values={name:backup.component_watermark(path,name,connect=connections[name]) for name in storage.COMPONENTS}
    if sum(v['databaseBytes'] for v in values.values())>backup.MAX_DATABASES:raise OwnershipError('Managed recovery source exceeds storage envelope')
    return values


def _same_rows(before,after):
    if set(before)!=set(after) or any(any(before[name][key]!=after[name][key] for key in ('counts','rowDigests','schemaVersions')) for name in before):
        raise OwnershipError('Managed recovery store changed during capture')


def _snapshot_pin(document,intent,capture_digest):
    aws=document['current']['stores']['installation']['aws'];ident=UUID(intent['installationId'])
    return recovery.SnapshotPin(ident,aws['region'],aws['account'],identifier='aos-'+ident.hex+'-'+UUID(intent['commandId']).hex,
        capture_digest=capture_digest,source_run=intent['sourceRunId'],source_generation=intent['parkGeneration'],**document['source'])


def inspection_configuration(document,intent,capture_digest):
    aws=document['current']['stores']['installation']['aws'];pin=_snapshot_pin(document,intent,capture_digest)
    snapshot=asdict(pin)
    for k in ('installation_id','region','account'):snapshot.pop(k)
    return dict(schema=recovery.CONFIGURATION,manifest=document['current']['stores']['installation']['manifest'],
        region=aws['region'],account=aws['account'],token_root=aws['token_root'],operator=aws['operator'],snapshot=snapshot)


def _response(directory,prepared):
    pin=prepared['snapshot']
    return dict(profile=PROFILE,state='AWAITING_MANAGED_SNAPSHOT',snapshot=str(directory),captureDigest=prepared['captureDigest'],
        sourceGeneration=prepared['sourceGeneration'],managedSnapshot=pin,runtimeReady=False,osControlReconciled=False,productionQualified=False)


async def prepare(document,token,*,command_id,expected_generation,recovery_key,journal_root,controls_root,capacity_root=None):
    document,stores,cloud,artifact=configuration(document);path=stores['installation']['manifest'];verify_operator(path,token)
    command=checked_id(command_id);directory=path.parent/'backups'/command
    key_file=canonical_file(str(recovery_key));journals=canonical_file(str(journal_root));controls=canonical_file(str(controls_root))
    if any(p==path.parent or p.is_relative_to(path.parent) for p in (key_file,journals,controls)):
        raise OwnershipError('Recovery key and privacy journals require independent placement')
    if type(expected_generation) is not int or expected_generation<2 or expected_generation%2:
        raise OwnershipError('Original ready generation required for managed recovery')
    with backup._admission(path,capacity_root=capacity_root,restoring=False):
        with file_lock(path.parent/'recovery-gate.lock',timeout=2):
            verify_operator(path,token)
            if directory.exists() or directory.is_symlink():
                intent=_intent(path,command)
                if (intent['configurationDigest']!=_sha(document) or intent['priorGate']['generation']!=expected_generation
                        or any(intent[k]!=str(v) for k,v in [('recoveryKey',key_file),('journalRoot',journals),('controlsRoot',controls)])):
                    raise OwnershipError('Exact original recovery preparation required')
                _key(intent)
            else:
                if key_file.exists() or key_file.is_symlink():raise OwnershipError('New independent recovery key required')
                value,pin=key_recovery._proof(path,artifact,allow_expired=True)
                prior=gate.state(path)
                if prior['generation']!=expected_generation:raise OwnershipError('Managed recovery source generation differs')
                operators=value.get('operatorConfiguration')
                renewal._checked_service_documents(document['prior'],document['current'],value,operators)
                original=renewal._ancestry(path,value.get('materialConfiguration',{}).get('initial'),operators)
                renewal._service_context(original,dict(installationDigest=readiness.installation_digest(document['current']['stores']['installation']),
                    cloudConfiguration=document['current']['cloud_configuration'],cloudDigest=_sha(cloud),cloud=readiness._cloud_pin(cloud)),operators)
                from agentic_os.adapters.local.recovery_maintenance import artifact_pin
                selected=artifact_pin(artifact)
                # Persist the existing closed source-artifact contract, not the
                # inspector's runtime-only reader capability tuples.
                reviewed={name:selected[name] for name in ('artifactDigest','releaseDigest','programs')}
                from agentic_os.adapters.local.recovery_runtime_checkpoint import release_programs
                if reviewed['programs']!=release_programs():raise OwnershipError('Source capture changes original workflow/contracts')
                proposed=dict(installationId=load_manifest(path)['installationId'],sourceRunId=load_manifest(path)['runId'],
                    commandId=command,parkGeneration=expected_generation+1)
                inspection=inspection_configuration(document,proposed,'0'*64)
                with recovery.configured_inspector(inspection) as (client,source_pin,operator):
                    identity=operator(token)
                    recovery.inspect_source(client,source_pin,document['current']['stores']['installation']['aws']['postgres']['host'])
                    if operator(token)!=identity:raise OwnershipError('Managed source operator changed')
                private_directory(directory);key=AESGCM.generate_key(bit_length=256);private_write(key_file,key)
                intent=dict(profile=INTENT,installationId=load_manifest(path)['installationId'],sourceRunId=load_manifest(path)['runId'],
                    commandId=command,configurationDigest=_sha(document),priorGate=prior,parkGeneration=expected_generation+1,
                    sourceRelease=value,sourceArtifact=reviewed,operatorContentDigest=readiness._runtime_content(),recoveryKey=str(key_file),recoveryKeyDigest=hashlib.sha256(key).hexdigest(),
                    journalRoot=str(journals),controlsRoot=str(controls))
                write_signed(directory/'intent.json',intent,path.parent/'owner.key')
            if gate.state(path)==intent['priorGate']:gate._write(path,mode='PARKED',reason='snapshot')
            _current(path,token,intent)
            if (directory/'prepared.json').exists():
                prepared,_=read_prepared(directory,key_file)
                return _response(directory,prepared)
            if (directory/'files.bin').exists() or (directory/'snapshot-blocked').exists():
                raise OwnershipError('Incomplete managed capture retained; explicit recovery required')
        await asyncio.to_thread(storage.prepare_stores,document['current']['stores'],token,
            expected_generation=intent['parkGeneration'],check_only=True)
        with configured_operator_connection(cloud) as connection:
            capture=await inspect_parked_history(connection,token,expected_generation=intent['parkGeneration'])
            with file_lock(path.parent/'recovery-gate.lock',timeout=2),_stores(document,token) as connections:
                _current(path,token,intent)
                with snapshot_checkpoints(path,journals,controls,require_current=True,control_connect=connections['control']) as checkpoints:
                    before=_watermarks(path,connections);current=runtime_checkpoint(path,installation=connection.installation)
                    if current!=capture['runtimeCheckpoint']:raise OwnershipError('Cloud/source control checkpoint changed')
                    metadata=metadata_bytes(path,cloud_capture=capture,installation=connection.installation)
                    files=backup._files(path.parent,metadata=metadata)
                    _same_rows(before,_watermarks(path,connections))
                    if runtime_checkpoint(path,installation=connection.installation)!=current:raise OwnershipError('Original source work changed')
                    if files!=backup._files(path.parent,metadata=metadata_bytes(path,cloud_capture=capture,installation=connection.installation)):
                        raise OwnershipError('Original private material changed')
                    bind_cloud_source(path,capture)
                    payload=dict(sourceRelease=intent['sourceRelease'],sourceArtifact=intent['sourceArtifact'],sourceGate=_current(path,token,intent),
                        runtimeCheckpoint=current,**checkpoints,components=before,cloudCapture=capture,files=files)
                    raw=canonical_bytes(payload)
                    if len(raw)>2*backup.MAX_FILES:raise OwnershipError('Managed private capture envelope exceeded')
                    digest=_sha(payload);pin=_snapshot_pin(document,intent,digest)
                    encrypted=backup._encrypt(_key(intent),raw,backup._binding(command,intent['installationId'],'files',profile=PROFILE))
                    private_write(directory/'files.bin',encrypted)
                    snapshot=asdict(pin);snapshot['installation_id']=str(pin.installation_id)
                    prepared=dict(profile=PROFILE,id=command,installationId=intent['installationId'],sourceRunId=intent['sourceRunId'],
                        sourceGeneration=intent['parkGeneration'],configurationDigest=intent['configurationDigest'],captureDigest=digest,
                        ciphertextDigest=hashlib.sha256(encrypted).hexdigest(),plaintextBytes=len(raw),preparedAtNs=str(time.time_ns()),snapshot=snapshot)
                    private_write(directory/'prepared.json',canonical_bytes(dict(prepared=prepared,
                        signature=hmac.digest(_key(intent),canonical_bytes(prepared),'sha256').hex())))
            return _response(directory,prepared)


def read_prepared(directory,recovery_key):
    directory=canonical_file(str(directory));recovery_key=canonical_file(str(recovery_key));checked_id(directory.name)
    check_private(directory,directory=True)
    if (directory/'snapshot-blocked').exists() or (directory/'snapshot-blocked').is_symlink():
        raise OwnershipError('Incomplete managed recovery capture refused')
    if recovery_key.is_relative_to(directory):raise OwnershipError('Independent recovery key required')
    key=private_read(recovery_key,32)
    try:
        if len(key)!=32:raise ValueError()
        value=parse_canonical_json(private_read(directory/'prepared.json',2*1024**2));closed(value,{'prepared','signature'})
        record=value['prepared'];closed(record,PREPARED_FIELDS)
        if (record['profile']!=PROFILE or record['id']!=directory.name
                or type(value['signature']) is not str or not hmac.compare_digest(value['signature'],hmac.digest(key,canonical_bytes(record),'sha256').hex())
                or not backup._clock(record['preparedAtNs']) or type(record['sourceGeneration']) is not int or record['sourceGeneration']<3 or not record['sourceGeneration']%2
                or type(record['plaintextBytes']) is not int or not 0<record['plaintextBytes']<=2*backup.MAX_FILES):raise ValueError()
        for k in ('configurationDigest','captureDigest','ciphertextDigest'):
            if not backup._digest(record[k]):raise ValueError()
        snapshot=dict(record['snapshot']);snapshot['installation_id']=UUID(snapshot['installation_id']);pin=recovery.SnapshotPin(**snapshot)
        if (str(pin.installation_id)!=record['installationId'] or pin.source_run!=record['sourceRunId']
                or pin.source_generation!=record['sourceGeneration'] or pin.capture_digest!=record['captureDigest']
                or pin.identifier!='aos-'+pin.installation_id.hex+'-'+UUID(record['id']).hex):raise ValueError()
        encrypted=private_read(directory/'files.bin',2*backup.MAX_FILES+28)
        if any(file.lstat().st_nlink!=1 for file in (directory/'prepared.json',directory/'files.bin',recovery_key)):raise ValueError()
        if hashlib.sha256(encrypted).hexdigest()!=record['ciphertextDigest']:raise ValueError()
        raw=backup._decrypt(key,encrypted,backup._binding(record['id'],record['installationId'],'files',profile=PROFILE))
        if len(raw)!=record['plaintextBytes']:raise ValueError()
        payload=parse_canonical_json(raw);closed(payload,PAYLOAD_FIELDS)
        if _sha(payload)!=record['captureDigest']:raise ValueError()
        checked_runtime_checkpoint(payload['runtimeCheckpoint']);checked_history_capture(payload['cloudCapture'])
        checked_records(payload['journalCheckpoints']);checked_records(payload['controlsCheckpoints'])
        deleting={v['applicationId']:v for v in payload['journalCheckpoints']}
        if any(v['applicationId'] not in deleting or v['journalId']==deleting[v['applicationId']]['journalId']
                or v['keyDigest']==deleting[v['applicationId']]['keyDigest'] for v in payload['controlsCheckpoints']):raise ValueError()
        closed(payload['sourceGate'],gate.FIELDS)
        if (payload['sourceGate']['mode']!='PARKED' or payload['sourceGate']['generation']!=record['sourceGeneration']
                or payload['sourceGate']['installationId']!=record['installationId'] or payload['sourceGate']['runId']!=record['sourceRunId']
                or payload['sourceRelease']['generation']+1!=record['sourceGeneration']
                or any(payload['sourceRelease'][k]!=record[v] for k,v in [('installationId','installationId'),('runId','sourceRunId')])
                or any(payload['cloudCapture'][k]!=record[v] for k,v in [('installationId','installationId'),('sourceRunId','sourceRunId'),('sourceGeneration','sourceGeneration')])
                or payload['cloudCapture']['runtimeCheckpoint']!=payload['runtimeCheckpoint']):raise ValueError()
        closed(payload['sourceArtifact'],{'artifactDigest','releaseDigest','programs'})
        if (payload['sourceArtifact']['releaseDigest']!=payload['sourceRelease']['releaseDigest']
                or payload['sourceArtifact']['programs']!={k:payload['runtimeCheckpoint'][k] for k in ('contracts','workflowPrograms')}
                or any(not backup._digest(payload['sourceArtifact'][k]) for k in ('artifactDigest','releaseDigest'))):raise ValueError()
        if set(payload['components'])!=set(storage.COMPONENTS):raise ValueError()
        for watermark in payload['components'].values():backup._watermark(watermark)
        if sum(v['databaseBytes'] for v in payload['components'].values())>backup.MAX_DATABASES:raise ValueError()
        material=backup._validated_material(canonical_bytes(payload['files']))
        if METADATA not in material:raise ValueError()
        checked_metadata(parse_canonical_json(material[METADATA]),record['installationId'],record['sourceRunId'])
    except Exception:raise OwnershipError('Authenticated managed source capture unavailable') from None
    return record,payload


async def seal(document,token,*,command_id,expected_generation,recovery_key,capacity_root=None):
    """Attest an externally created snapshot against the unchanged parked source."""
    document,stores,cloud,_=configuration(document);path=stores['installation']['manifest'];verify_operator(path,token)
    directory=path.parent/'backups'/checked_id(command_id);intent=_intent(path,command_id)
    if (type(expected_generation) is not int or expected_generation!=intent['parkGeneration']
            or str(recovery_key)!=intent['recoveryKey'] or intent['configurationDigest']!=_sha(document)):
        raise OwnershipError('Exact original managed source capture required')
    _current(path,token,intent);prepared,payload=read_prepared(directory,recovery_key)
    if (directory/'receipt.json').exists() or (directory/'receipt.json').is_symlink():
        sealed,_=read_snapshot(directory,recovery_key)
        return dict(profile=PROFILE,state='SEALED',snapshot=str(directory),captureDigest=sealed['prepared']['captureDigest'],
            sourceGeneration=expected_generation,runtimeReady=False,osControlReconciled=False,productionQualified=False)
    inspection=inspection_configuration(document,intent,prepared['captureDigest'])
    with backup._admission(path,capacity_root=capacity_root,restoring=False):
        with recovery.configured_inspector(inspection) as (client,pin,operator):
            identity=operator(token)
            source=recovery.inspect_source(client,pin,document['current']['stores']['installation']['aws']['postgres']['host'])
            snapshot=recovery.inspect_snapshot(client,pin)
            if operator(token)!=identity:raise OwnershipError('Managed snapshot operator changed')
        from datetime import datetime
        created=datetime.fromisoformat(snapshot['snapshotCreatedAt'].replace('Z','+00:00'))
        created_ns=int(created.timestamp()*1_000_000_000)
        if not int(prepared['preparedAtNs'])//1_000_000_000<=created_ns//1_000_000_000<=time.time_ns()//1_000_000_000:
            raise OwnershipError('Managed snapshot predates its authenticated source capture')
        with configured_operator_connection(cloud) as connection:
            capture=await inspect_parked_history(connection,token,expected_generation=expected_generation)
            original=payload['cloudCapture']
            fields={'installationId','sourceRunId','sourceGeneration','namespace','namespaceId','retentionDays',
                'endpoint','serverCASha256','requiredWorkflows','runtimeCheckpoint'}
            if any(capture[k]!=original[k] for k in fields):raise OwnershipError('Original Cloud capture changed')
            from .temporal import original_history
            from agentic_os.adapters.local.recovery_temporal import verify_cloud_history_prefix,INSPECTION_SECONDS
            async with asyncio.timeout(INSPECTION_SECONDS):
                await verify_cloud_history_prefix(await connection.connect(),original_history(original),capture['catalog'])
            with file_lock(path.parent/'recovery-gate.lock',timeout=2),_stores(document,token) as connections:
                _current(path,token,intent)
                with snapshot_checkpoints(path,Path(intent['journalRoot']),Path(intent['controlsRoot']),require_current=True,
                        control_connect=connections['control']) as checkpoints:
                    if any(payload[k]!=v for k,v in checkpoints.items()):raise OwnershipError('Surviving privacy checkpoint changed')
                    _same_rows(payload['components'],_watermarks(path,connections))
                    if runtime_checkpoint(path,installation=connection.installation)!=payload['runtimeCheckpoint']:
                        raise OwnershipError('Original runtime checkpoint changed')
                    # Original Cloud prefix metadata stays immutable even when a running history appends.
                    files=backup._files(path.parent,metadata=metadata_bytes(path,cloud_capture=original,installation=connection.installation))
                    if files!=payload['files']:raise OwnershipError('Source material changed after managed capture')
                    record=dict(profile=PROFILE,prepared=prepared,source=source,snapshot=snapshot,sealedAtNs=str(time.time_ns()))
                    private_write(directory/'receipt.json',canonical_bytes(dict(receipt=record,
                        signature=hmac.digest(_key(intent),canonical_bytes(record),'sha256').hex())))
        return dict(profile=PROFILE,state='SEALED',snapshot=str(directory),captureDigest=prepared['captureDigest'],
            sourceGeneration=expected_generation,runtimeReady=False,osControlReconciled=False,productionQualified=False)


def read_snapshot(directory,recovery_key):
    """Independent authenticated archive reader; no source availability required."""
    directory=canonical_file(str(directory));prepared,payload=read_prepared(directory,recovery_key)
    key=private_read(canonical_file(str(recovery_key)),32)
    try:
        value=parse_canonical_json(private_read(directory/'receipt.json',2*1024**2));closed(value,{'receipt','signature'})
        receipt=value['receipt'];closed(receipt,{'profile','prepared','source','snapshot','sealedAtNs'})
        if (receipt['profile']!=PROFILE or receipt['prepared']!=prepared or not backup._clock(receipt['sealedAtNs'])
                or int(receipt['sealedAtNs'])<int(prepared['preparedAtNs']) or type(value['signature']) is not str
                or not hmac.compare_digest(value['signature'],hmac.digest(key,canonical_bytes(receipt),'sha256').hex())):raise ValueError()
        pin_values=dict(prepared['snapshot']);pin_values['installation_id']=UUID(pin_values['installation_id']);pin=recovery.SnapshotPin(**pin_values)
        closed(receipt['source'],{'profile','instanceArn','resourceId','endpoint','port','encrypted','publiclyAccessible','installationId','runtimeReady'})
        source=receipt['source'];snapshot=receipt['snapshot']
        if (source['profile']!='aws-managed-source-inspection/1' or source['installationId']!=prepared['installationId']
                or source['instanceArn']!='arn:aws:rds:'+pin.region+':'+pin.account+':db:'+pin.instance_id
                or source['resourceId']!=pin.resource_id or type(source['port']) is not int or source['port']!=pin.port
                or type(source['endpoint']) is not str or re.fullmatch(r'[a-z0-9-]+\.[a-z0-9-]+\.'+re.escape(pin.region)+r'\.rds\.amazonaws\.com',source['endpoint']) is None
                or source['encrypted'] is not True or source['publiclyAccessible'] is not False or source['runtimeReady'] is not False):raise ValueError()
        closed(snapshot,{'profile','state','snapshotArn','snapshotCreatedAt','encrypted','privateRestoreAttributes','captureTagsMatched',
            'runtimeReady','osControlReconciled','cloudHistoryReconciled'})
        if (snapshot['profile']!=recovery.CONFIGURATION or snapshot['state']!='managed-snapshot-available' or snapshot['snapshotArn']!=pin.arn
                or any(snapshot[k] is not True for k in ('encrypted','privateRestoreAttributes','captureTagsMatched'))
                or any(snapshot[k] is not False for k in ('runtimeReady','osControlReconciled','cloudHistoryReconciled'))):raise ValueError()
        from datetime import datetime
        created=datetime.fromisoformat(snapshot['snapshotCreatedAt'].replace('Z','+00:00'))
        if (created.tzinfo is None or created.utcoffset() is None
                or not int(prepared['preparedAtNs'])//1_000_000_000<=int(created.timestamp())<=int(receipt['sealedAtNs'])//1_000_000_000):raise ValueError()
        if (directory/'receipt.json').lstat().st_nlink!=1:raise ValueError()
    except Exception:raise OwnershipError('Sealed managed recovery archive unavailable') from None
    return receipt,payload


def plan(document,*,command_id,expected_generation):
    document,stores,_,_=configuration(document);manifest=load_manifest(stores['installation']['manifest'])
    command=checked_id(command_id)
    if type(expected_generation) is not int or expected_generation<2 or expected_generation%2:
        raise OwnershipError('Original ready generation required')
    intent=dict(installationId=manifest['installationId'],sourceRunId=manifest['runId'],commandId=command,parkGeneration=expected_generation+1)
    inspection=inspection_configuration(document,intent,'0'*64);result=recovery.plan(inspection)
    pin=_snapshot_pin(document,intent,'0'*64);result['permissions']['Statement'].append(recovery.source_permissions(pin))
    return dict(profile=PROFILE,state='PLANNED',roleArn=result['roleArn'],permissions=result['permissions'],
        sourceGeneration=expected_generation+1,snapshotArn=pin.arn,runtimeReady=False,awsResourcesCreated=False,
        billableActions=[],prerequisites=['Capture and Park the exact current source before externally creating a managed snapshot',
            'Use the capture digest/tags returned by preparation; zero planning digest grants no snapshot acceptance',
            'Sealing grants no Ready; separately provisioned target/privacy/history/quarantine/release remains mandatory'])
