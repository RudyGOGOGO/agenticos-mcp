"""Finite same-artifact AWS control renewal over existing maintenance storage.

Park fences Core commits. Existing remote SQL/checkpoint and supported Cloud
history inspection verify the unchanged installation before another finite
release. No workflow, task, budget, privacy row or original deadline is changed.
Artifact/configuration/key rollover and restored recovery remain distinct gates.
"""
import asyncio
from pathlib import Path
from importlib.resources import files
import re
import time

from agentic_os.adapters.local import recovery_gate as gate
from agentic_os.adapters.local.files import OwnershipError,check_private,private_read,private_write
from agentic_os.adapters.local.artifacts import checked_id
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.resources import ensure_private,file_lock,read_signed,write_signed
from agentic_os.adapters.local.recovery_maintenance import DIRECTORY,FILE,_operation
from agentic_os.adapters.local.recovery_key_continuity import sha
from agentic_os.adapters.local.recovery_runtime_checkpoint import runtime_checkpoint,checked_runtime_checkpoint
from . import readiness

LEGACY_PROFILE='aws-finite-control-renewal/1'
PROFILE='aws-finite-control-renewal/2'
LEGACY_ARTIFACT_PROFILE='aws-compatible-artifact-renewal/1'
ARTIFACT_PROFILE='aws-compatible-artifact-renewal/2'
SERVICE_PROFILE='aws-service-credential-renewal/1'
MATERIAL_PROFILE='aws-private-material-renewal/1'
OPERATOR_PROFILE='aws-operator-credential-renewal/1'
SERVICE_PROFILES={SERVICE_PROFILE,MATERIAL_PROFILE,OPERATOR_PROFILE}
MATERIAL_PROFILES={MATERIAL_PROFILE,OPERATOR_PROFILE}
# Selected artifacts must explicitly support every control record they publish.
SUPPORTED_PROFILES=('aws-initial-control-release/1','aws-initial-control-release/2',
    'aws-finite-control-renewal/1','aws-finite-control-renewal/2',
    'aws-compatible-artifact-renewal/1','aws-compatible-artifact-renewal/2','aws-service-credential-renewal/1','aws-private-material-renewal/1','aws-operator-credential-renewal/1')
CHECKS={'currentSchemas','runtimeRoles','privateMaterials','embedding','cloudNamespace','originalWorkPreserved'}
INTENT_FIELDS={'profile','installationId','runId','commandId','priorGeneration','parkGeneration','nextGeneration',
    'priorGate','priorCertificateDigest','initialCertificateDigest','configurationDigest',
    'installationDigest','cloudDigest','materialsDigest','releaseDigest'}
READY_FIELDS=readiness.FIELDS|{'commandId','initialCertificateDigest','priorCertificateDigest','checkpointDigest','historyDigest'}


SERVICE_FIELDS={'installationDigest','cloudConfiguration','cloudDigest','cloud'}


def _service_context(initial,context,operator_configuration=None):
    """Only immutable service credentials/TLS may change, never logical ownership."""
    from copy import deepcopy
    from agentic_os.adapters.configured_installation import closed,canonical_file
    from .temporal import load_operator_configuration
    try:
        closed(context,SERVICE_FIELDS)
        old=load_operator_configuration(canonical_file(initial['cloudConfiguration']))
        new=load_operator_configuration(canonical_file(context['cloudConfiguration']))
        if (sha(new)!=context['cloudDigest'] or readiness._cloud_pin(new)!=context['cloud']
                or readiness.installation_digest(new['installation'])!=context['installationDigest']):raise ValueError()
        if operator_configuration is not None:
            old_operator=old['installation']['aws']['operator'];new_operator=new['installation']['aws']['operator']
            if (old_operator['generation']!=operator_configuration['initial']['record']['generation']
                    or new_operator['generation']!=operator_configuration['current']['record']['generation']
                    or old_operator['pin']['version']==new_operator['pin']['version']):raise ValueError()
        def logical(value):
            value=deepcopy(value)
            # Pin ARNs, scoped users/endpoints, workload identity, application
            # credentials and operator generation remain exactly the original.
            value.pop('server_ca');value.pop('server_ca_sha256')
            value['identity']['pin'].pop('version')
            aws=value['installation']['aws']
            if operator_configuration is not None:aws['operator'].pop('generation')
            aws['operator']['pin'].pop('version')
            for settings in [aws['postgres'],*aws['stores'].values()]:
                settings.pop('ca');settings.pop('ca_sha256');settings['password'].pop('version')
            return value
        if logical(old)!=logical(new):raise ValueError()
    except Exception:raise OwnershipError('Reviewed service configuration changes original ownership') from None
    return initial|context


def _ancestry(path,materials=None,operator_configuration=None):
    value=read_signed(Path(path).parent/readiness.FILE,Path(path).parent/'owner.key',maximum=65536)
    return readiness._initial_metadata(path,value['installationDigest'],allow_expired=True,current_release=False,_historical_materials=materials,_historical_operator=operator_configuration)


def selected(path):
    marker=Path(path).parent/FILE
    return marker.exists() or marker.is_symlink()


def _selector(path):
    value=read_signed(Path(path).parent/FILE,Path(path).parent/'owner.key',maximum=32768)
    if type(value) is not dict or set(value)!={'profile','commandId'} or value['profile'] not in {PROFILE,LEGACY_PROFILE,LEGACY_ARTIFACT_PROFILE,ARTIFACT_PROFILE,*SERVICE_PROFILES}:
        raise OwnershipError('Explicit AWS renewal selection unavailable')
    _operation(path,value['commandId'])
    return value


def _hash(value):return type(value) is str and re.fullmatch('[a-f0-9]{64}',value) is not None


def _checked_ready(value,initial,*,allow_expired=False,artifact=None,path=None):
    ancestry=initial
    service=value.get('profile') in SERVICE_PROFILES if type(value) is dict else False
    material=value.get('profile') in MATERIAL_PROFILES if type(value) is dict else False
    operators=value.get('operatorConfiguration') if type(value) is dict and value.get('profile')==OPERATOR_PROFILE else None
    if operators is not None:
        from .operator_rotation import checked_configuration as checked_operators
        checked_operators(path,operators)
    if service:initial=_service_context(initial,value.get('serviceConfiguration'),operators)
    if material:
        from .key_rotation import checked_configuration,state_digest
        configured=checked_configuration(value.get('materialConfiguration'),path=path,operator_configuration=operators)
        if state_digest(configured['initial'])!=ancestry['materialsDigest']:raise OwnershipError('Original material digest differs')
        initial=initial|dict(materialsDigest=state_digest(configured['current']))
    try:
        now=int(time.time())
        ordinary=artifact is None and value.get('profile')==PROFILE
        full=ordinary or artifact is not None and 'contentDigest' in artifact
        fields=READY_FIELDS if artifact is None else READY_FIELDS|{'artifactDigest'}|({'contentDigest'} if full else set())
        if ordinary:fields=fields|{'contentDigest'}
        if service:fields=fields|{'serviceConfiguration'}
        if material:fields=fields|{'materialConfiguration'}
        if value.get('profile')==OPERATOR_PROFILE:fields=fields|{'operatorConfiguration'}
        profile=(PROFILE if ordinary else LEGACY_PROFILE) if artifact is None else ARTIFACT_PROFILE if full else LEGACY_ARTIFACT_PROFILE
        if service:profile=OPERATOR_PROFILE if operators is not None else MATERIAL_PROFILE if material else SERVICE_PROFILE
        release=initial['releaseDigest'] if artifact is None else artifact['releaseDigest']
        if (type(value) is not dict or set(value)!=fields or value['profile']!=profile
                or any(value[key]!=initial[key] for key in ('installationId','runId','installationDigest','cloudConfiguration',
                    'cloudDigest','cloud','materialsDigest'))
                or value['releaseDigest']!=release
                or artifact is not None and value['artifactDigest']!=artifact['artifactDigest']
                or ordinary and initial['profile']!=readiness.PROFILE
                or full and not _hash(value['contentDigest'])
                or full and value['contentDigest']!=(initial.get('contentDigest') if ordinary else artifact['contentDigest'])
                or service and (artifact is None or 'contentDigest' not in artifact)
                or value['initialCertificateDigest']!=sha(ancestry)
                or type(value['generation']) is not int or not 4<=value['generation']<=2**53-1 or value['generation']%2
                or type(value['issuedAt']) is not int or type(value['expiresAt']) is not int
                or value['issuedAt']>now or not allow_expired and now>=value['expiresAt']
                or not 60<=value['expiresAt']-value['issuedAt']<=86400
                or any(not _hash(value[key]) for key in ('initialCertificateDigest','priorCertificateDigest','checkpointDigest','historyDigest'))
                or type(value['checks']) is not dict or set(value['checks'])!=CHECKS
                or any(flag is not True for flag in value['checks'].values())):raise ValueError()
        checked_id(value['commandId'])
    except Exception:raise OwnershipError('Finite AWS renewal proof unavailable') from None
    return value


def _intent(path,command,digest):
    op=_operation(path,command);root=Path(path).parent
    value=read_signed(op/'intent.json',root/'owner.key',maximum=1024**2)
    try:
        artifact=value.get('profile') in {LEGACY_ARTIFACT_PROFILE,ARTIFACT_PROFILE,*SERVICE_PROFILES}
        service=value.get('profile') in SERVICE_PROFILES
        material=value.get('profile') in MATERIAL_PROFILES
        operators=value.get('operatorConfiguration') if value.get('profile')==OPERATOR_PROFILE else None
        if operators is not None:
            from .operator_rotation import checked_configuration as checked_operators
            checked_operators(path,operators)
        materials=value['materialConfiguration']['initial'] if material else None
        initial=_ancestry(path,materials,operators) if service else readiness._initial_metadata(path,digest,allow_expired=True,current_release=False)
        context=_service_context(initial,value.get('serviceConfiguration'),operators) if service else initial
        if material:
            from .key_rotation import checked_configuration,state_digest
            configured=checked_configuration(value['materialConfiguration'],path=path,operator_configuration=operators)
            context=context|dict(materialsDigest=state_digest(configured['current']))
        if context['installationDigest']!=digest:raise ValueError()
        if (type(value) is not dict or set(value)!=((INTENT_FIELDS|{'artifact'} if artifact else INTENT_FIELDS)|({'serviceConfiguration'} if service else set())|({'materialConfiguration'} if material else set())
                |({'keyRotation'} if material and 'keyRotation' in value else set())
                |({'operatorConfiguration'} if operators is not None else set())|({'operatorRotation'} if operators is not None and 'operatorRotation' in value else set()))
                or value['profile'] not in {PROFILE,LEGACY_PROFILE,LEGACY_ARTIFACT_PROFILE,ARTIFACT_PROFILE,*SERVICE_PROFILES}
                or value['profile']==PROFILE and initial['profile']!=readiness.PROFILE
                or value['commandId']!=command or any(value[key]!=context[key] for key in
                    ('installationId','runId','installationDigest','cloudDigest','materialsDigest','releaseDigest'))
                or value['initialCertificateDigest']!=sha(initial)
                or any(type(value[key]) is not int for key in ('priorGeneration','parkGeneration','nextGeneration'))
                or value['priorGeneration']<2 or value['priorGeneration']%2
                or value['parkGeneration']!=value['priorGeneration']+1 or value['nextGeneration']!=value['priorGeneration']+2
                or value['nextGeneration']>2**53-1
                or set(value['priorGate'])!=gate.FIELDS or value['priorGate']['mode']!='READY'
                or value['priorGate']['version']!=1
                or any(value['priorGate'][key]!=initial[key] for key in ('installationId','runId'))
                or value['priorGate']['generation']!=value['priorGeneration']
                or any(not _hash(value[key]) for key in ('priorCertificateDigest','initialCertificateDigest','configurationDigest'))):raise ValueError()
        prior=read_signed(op/'prior-ready.json',root/'owner.key',maximum=1024**2)
        if prior.get('profile') in readiness.INITIAL_PROFILES:
            if prior!=initial:raise ValueError()
        else:
            previous=(dict(artifactDigest=prior.get('artifactDigest'),releaseDigest=prior.get('releaseDigest'))
                if prior.get('profile') in {LEGACY_ARTIFACT_PROFILE,ARTIFACT_PROFILE,*SERVICE_PROFILES} else None)
            if previous is not None and prior.get('profile') in {ARTIFACT_PROFILE,*SERVICE_PROFILES}:previous['contentDigest']=prior.get('contentDigest')
            if previous is not None and any(not _hash(v) for v in previous.values()):raise ValueError()
            _checked_ready(prior,initial,allow_expired=True,artifact=previous,path=path)
        if material:_material_intent(path,command,value,prior)
        if operators is not None:
            from .operator_rotation import intent_stage
            intent_stage(path,command,value,prior)
        if prior['generation']!=value['priorGeneration'] or sha(prior)!=value['priorCertificateDigest']:raise ValueError()
        if artifact:
            selection=value['artifact']
            fields={'artifactDigest','releaseDigest','checkpointDigest','priorArtifactDigest'}
            if value['profile'] in {ARTIFACT_PROFILE,*SERVICE_PROFILES}:fields.add('contentDigest')
            if (type(selection) is not dict or set(selection)!=fields
                    or any(not _hash(v) for v in selection.values())):raise ValueError()
            _original_work(path,command,selection)
    except Exception:raise OwnershipError('Original AWS renewal intent unavailable') from None
    return value,initial


def certificate(path,digest,*,allow_expired=False,_operator_release=None,_operator_content=None):
    root=Path(path).parent;selection=_selector(path);intent,initial=_intent(path,selection['commandId'],digest)
    op=_operation(path,selection['commandId']);value=_checked_ready(
        read_signed(op/'ready.json',root/'owner.key',maximum=1024**2),initial,allow_expired=allow_expired,
        artifact=intent.get('artifact'),path=path)
    full=value['profile'] in {PROFILE,ARTIFACT_PROFILE,*SERVICE_PROFILES}
    expected=(value['releaseDigest'] if full else readiness.release_digest()) if _operator_release is None else _operator_release
    if (not _hash(expected) or value['profile']!=selection['profile'] or value['releaseDigest']!=expected
            or value['profile'] in {LEGACY_PROFILE,LEGACY_ARTIFACT_PROFILE} and _operator_release is None
            or full and value['contentDigest']!=(_runtime_content() if _operator_content is None else _operator_content)):
        raise OwnershipError('Selected AWS artifact code differs')
    current=gate.state(Path(path))
    if (value['commandId']!=selection['commandId'] or value['generation']!=intent['nextGeneration']
            or value['priorCertificateDigest']!=intent['priorCertificateDigest']
            or intent['profile'] in SERVICE_PROFILES and value['serviceConfiguration']!=intent['serviceConfiguration']
            or intent['profile']==OPERATOR_PROFILE and value['operatorConfiguration']!=intent['operatorConfiguration']
            or intent['profile'] in MATERIAL_PROFILES and (value['materialConfiguration']!=intent['materialConfiguration']
                or readiness._materials(path)!=value['materialsDigest'])
            or current['mode']!='READY' or current['generation']!=value['generation']):
        raise OwnershipError('Current AWS renewal generation differs')
    capture=_checked_capture(read_signed(op/'history.json',root/'owner.key',maximum=16*1024**2),initial,intent)
    if 'artifact' in intent:_compatible_work(_original_work(path,selection['commandId'],intent['artifact']),capture['runtimeCheckpoint'])
    if (sha(capture)!=value['historyDigest'] or sha(capture['runtimeCheckpoint'])!=value['checkpointDigest']
            or capture['installationId']!=value['installationId'] or capture['sourceRunId']!=value['runId']
            or capture['sourceGeneration']!=intent['parkGeneration']):
        raise OwnershipError('AWS renewal work checkpoint differs')
    return value


def _original_work(path,command,selection):
    value=read_signed(_operation(path,command)/'work-before.json',Path(path).parent/'owner.key',maximum=16*1024**2)
    checked_runtime_checkpoint(value)
    if sha(value)!=selection['checkpointDigest']:raise OwnershipError('Original artifact work checkpoint differs')
    return value


def _compatible_work(original,current):
    """Original programs are immutable; new public definitions may be additive."""
    checked_runtime_checkpoint(original);checked_runtime_checkpoint(current)
    programs={'contracts','workflowPrograms'}
    if (any(any(current[group].get(name)!=pin for name,pin in original[group].items()) for group in programs)
            or {k:v for k,v in original.items() if k not in programs}!={k:v for k,v in current.items() if k not in programs}):
        raise OwnershipError('Selected artifact changes original work or workflow semantics')


def _artifact(artifact,checkpoint,*,prior_digest,required_profiles=None):
    from agentic_os.adapters.local.recovery_maintenance import artifact_pin
    import ast
    import hashlib
    from io import BytesIO
    import zipfile
    value=artifact_pin(artifact)
    raw=private_read(Path(artifact),64*1024**2)
    if hashlib.sha256(raw).hexdigest()!=value['artifactDigest']:raise OwnershipError('Selected artifact changed during inspection')
    try:
        with zipfile.ZipFile(BytesIO(raw)) as wheel:
            source=wheel.read('agentic_os/adapters/aws/renewal.py')
            members={n.removeprefix('agentic_os/'):wheel.read(n) for n in wheel.namelist()
                if n.startswith('agentic_os/') and not n.endswith('/') and not n.endswith('.pyc') and '/__pycache__/' not in n}
        if len(source)>1024**2:raise ValueError()
        declarations=[ast.literal_eval(node.value) for node in ast.parse(source).body if isinstance(node,ast.Assign)
            and any(isinstance(target,ast.Name) and target.id=='SUPPORTED_PROFILES' for target in node.targets)]
        if (len(declarations)!=1 or type(declarations[0]) is not tuple
                or not ({ARTIFACT_PROFILE} if required_profiles is None else set(required_profiles))<=set(declarations[0])):raise ValueError()
    except Exception:raise OwnershipError('Selected artifact cannot read AWS lifecycle records; rollback requires supported code or forward recovery') from None
    current=checkpoint|value['programs']
    _compatible_work(checkpoint,current)
    return dict(artifactDigest=value['artifactDigest'],releaseDigest=value['releaseDigest'],checkpointDigest=sha(checkpoint),
        priorArtifactDigest=prior_digest,contentDigest=_member_digest(members))


def _member_digest(members):
    from agentic_os.distribution import member_inventory
    return sha(member_inventory(members))


def _runtime_content(package=None):
    """Fresh full package bytes through the existing finite public scanner."""
    from agentic_os.adapters.local.recovery_ready import _PROGRAM_SCAN
    from agentic_os.adapters.local.public_inventory import measure
    replacements={
        "names.append(directory)":"children[:]=[n for n in children if n!='__pycache__'];names.append((directory,metadata(directory,True)))",
        "paths.extend(os.path.join(directory,name) for name in files if name.endswith('.py'))":
            "paths.extend(os.path.join(directory,name) for name in files if not name.endswith('.pyc') and name!='.DS_Store')",
        "names.sort();paths.sort();paths.append(os.path.join(root,'contracts/schema/contracts.json'))":"names.sort();paths.sort()",
        "value=(root,tuple(metadata(name,True) for name in names),tuple(observed))":
            "if any(metadata(n,True)!=prior for n,prior in names):sys.exit(1)\n    value={os.path.relpath(e[0],root).replace(os.sep,'/'):{'sha256':e[-1],'bytes':e[6]} for e in observed}",
        "ensure_ascii=True).encode()":"ensure_ascii=False,sort_keys=True).encode()"}
    program=_PROGRAM_SCAN
    for before,after in replacements.items():
        if program.count(before)!=1:raise OwnershipError('Public content scanner compatibility differs')
        program=program.replace(before,after)
    measured=measure(files('agentic_os') if package is None else package,program)
    if measured is None:raise OwnershipError('Regular installed Core package required')
    return measured[1]


def _wheel_content(artifact,expected):
    import hashlib
    from io import BytesIO
    import zipfile
    raw=private_read(Path(artifact),64*1024**2)
    if hashlib.sha256(raw).hexdigest()!=expected:raise OwnershipError('Reviewed prior artifact changed')
    with zipfile.ZipFile(BytesIO(raw)) as wheel:
        members={n.removeprefix('agentic_os/'):wheel.read(n) for n in wheel.namelist()
            if n.startswith('agentic_os/') and not n.endswith('/') and not n.endswith('.pyc') and '/__pycache__/' not in n}
    return _member_digest(members)


def _required_profiles(path,command,initial):
    prior=read_signed(_operation(path,command)/'prior-ready.json',Path(path).parent/'owner.key',maximum=1024**2)
    intent=read_signed(_operation(path,command)/'intent.json',Path(path).parent/'owner.key',maximum=1024**2)
    return {intent['profile'],initial['profile'],prior['profile']}


def _checked_capture(capture,initial,intent):
    from .temporal import checked_history_capture
    checked_history_capture(capture)
    if intent['profile'] in SERVICE_PROFILES:initial=_service_context(initial,intent['serviceConfiguration'],intent.get('operatorConfiguration'))
    if (capture['installationId']!=initial['installationId'] or capture['sourceRunId']!=initial['runId']
            or capture['sourceGeneration']!=intent['parkGeneration']
            or any(capture[field]!=initial['cloud'][field] for field in
                ('namespace','namespaceId','retentionDays','endpoint','serverCASha256'))):
        raise OwnershipError('Original AWS Cloud work namespace differs')
    return capture


def _material_intent(path,command,intent,prior):
    from . import key_rotation as keys
    operators=intent.get('operatorConfiguration')
    configured=keys.checked_configuration(intent['materialConfiguration'],path=path,operator_configuration=operators)
    previous=prior.get('materialConfiguration') if prior['profile'] in MATERIAL_PROFILES else None
    initial=previous['initial'] if previous is not None else configured['initial']
    before=previous['current'] if previous is not None else initial
    if keys.state_digest(before)!=prior['materialsDigest'] or configured['initial']!=initial:
        raise OwnershipError('Original material checkpoint differs')
    if 'keyRotation' in intent:
        stage_file=_operation(path,command)/keys.STAGE_FILE
        if stage_file.lstat().st_nlink!=1:raise OwnershipError('Shared AWS key stage unavailable')
        staged=read_signed(stage_file,Path(path).parent/'owner.key',maximum=32768)
        keys.checked_stage(staged)
        binding=dict(installationId=intent['installationId'],runId=intent['runId'],commandId=command,
            priorGeneration=intent['priorGeneration'],configurationDigest=intent['configurationDigest'],priorCertificateDigest=intent['priorCertificateDigest'])
        if (any(staged[k]!=v for k,v in binding.items()) or keys.pin(staged)!=intent['keyRotation']
                or keys.rotated_configuration(initial,before,staged,0 if previous is None else previous['rotations'],path=path,operator_configuration=operators)!=configured):
            raise OwnershipError('Exact material rotation intent differs')
        return before,staged
    if 'operatorRotation' in intent:
        from copy import deepcopy
        expected=deepcopy(before)
        from .operator_rotation import digest
        expected['records']['operatorStateDigest']=digest(operators['current'])
        if configured['current']!=expected or configured['rotations']!=(0 if previous is None else previous['rotations']):
            raise OwnershipError('Operator rotation changes private keys')
    elif previous is None or configured!=previous:raise OwnershipError('Material renewal changes selected keys')
    return before,None


def _checked_service_documents(prior,current,proof,operator_configuration=None,*,original_run_id=None,validated_cloud=None):
    from copy import deepcopy
    if validated_cloud is None:
        _,cloud,path=readiness.configuration(prior,**({} if original_run_id is None else dict(expected_run_id=original_run_id)))
    else:cloud,path=validated_cloud,Path(prior['cloud_configuration'])
    if (readiness.installation_digest(prior['stores']['installation'])!=proof['installationDigest']
            or str(path)!=proof['cloudConfiguration'] or sha(cloud)!=proof['cloudDigest']):
        raise OwnershipError('Reviewed prior service configuration differs')
    old=deepcopy(prior['stores']);new=deepcopy(current['stores'])
    if operator_configuration is not None:
        previous=old['installation']['aws']['operator'];selected=new['installation']['aws']['operator']
        if (selected['generation'] not in {previous['generation'],previous['generation']+1}
                or selected['generation']!=previous['generation'] and selected['pin']['version']==previous['pin']['version']):
            raise OwnershipError('Operator cutover requires a distinct immutable secret version')
    for value in (old,new):
        value.pop('installation')
        for pin in value['migrators'].values():pin.pop('version')
    if old!=new:raise OwnershipError('Service rollover changes schema or migrator ownership')


def prepare(document,token,*,expected_generation,command_id,artifact=None,prior_artifact=None,prior_document=None,key_purpose=None,replacement_token=None):
    stores,cloud,cloud_path=readiness.configuration(document);path=stores['installation']['manifest'];root=path.parent
    verify_operator(path,token);op=_operation(path,command_id);digest=readiness.installation_digest(document['stores']['installation'])
    if type(expected_generation) is not int or expected_generation<2 or expected_generation%2:
        raise OwnershipError('Exact original ready generation required')
    if (artifact is None)!=(prior_artifact is None):raise OwnershipError('Exact prior and selected artifacts required together')
    if prior_document is not None:
        readiness.configuration(prior_document)
        if artifact is None:raise OwnershipError('Service rollover requires exact prior and selected artifacts')
    if key_purpose is not None:
        from .key_rotation import PURPOSES
        if key_purpose not in PURPOSES or artifact is None:raise OwnershipError('Rotation requires reviewed purpose and paired artifacts')
    if replacement_token is not None:
        if key_purpose is not None or prior_document is None or artifact is None:
            raise OwnershipError('Operator handoff requires paired configurations/artifacts and no key rotation')
        if type(replacement_token) is not bytes or len(replacement_token)!=32:raise OwnershipError('Exact replacement credential required')
    prior_pin=None
    if prior_artifact is not None:
        from agentic_os.adapters.local.recovery_maintenance import artifact_pin
        prior_pin=artifact_pin(prior_artifact)
        prior_pin['contentDigest']=_wheel_content(prior_artifact,prior_pin['artifactDigest'])
    with file_lock(root/'recovery-gate.lock',timeout=2):
        verify_operator(path,token)
        materials=None;operators=None
        if selected(path) and _selector(path)['profile'] in MATERIAL_PROFILES:
            selected_intent=read_signed(_operation(path,_selector(path)['commandId'])/'intent.json',root/'owner.key',maximum=1024**2)
            materials=selected_intent['materialConfiguration']['initial']
            operators=selected_intent.get('operatorConfiguration')
        prepared=(op/'intent.json').exists() or (op/'intent.json').is_symlink()
        if replacement_token is not None:
            from . import operator_rotation as credentials
            if prepared:
                operators=read_signed(op/'intent.json',root/'owner.key',maximum=1024**2)['operatorConfiguration']
            else:operators=credentials.next_configuration(path,credentials.state(path),replacement_token,operators)
        initial=_ancestry(path,materials,operators)
        service_context=None
        if prior_document is not None or key_purpose is not None or selected(path) and _selector(path)['profile'] in SERVICE_PROFILES:
            service_context=dict(installationDigest=digest,cloudConfiguration=str(cloud_path),cloudDigest=sha(cloud),cloud=readiness._cloud_pin(cloud))
            _service_context(initial,service_context,operators)
        context=initial if service_context is None else initial|service_context
        if digest!=context['installationDigest'] or str(cloud_path)!=context['cloudConfiguration'] or sha(cloud)!=context['cloudDigest']:
            raise OwnershipError('Same configured Cloud connection required for renewal')
        if op.exists() or op.is_symlink():
            check_private(op,directory=True)
        prepared=(op/'intent.json').exists() or (op/'intent.json').is_symlink()
        if prepared:
            intent,_=_intent(path,command_id,digest)
            if prior_document is not None:
                _checked_service_documents(prior_document,document,read_signed(op/'prior-ready.json',root/'owner.key',maximum=1024**2),operators)
            if (replacement_token is not None)!=('operatorRotation' in intent):raise OwnershipError('Original operator handoff selection differs')
            if replacement_token is not None:
                from .operator_rotation import intent_stage
                staged_operator=intent_stage(path,command_id,intent,read_signed(op/'prior-ready.json',root/'owner.key',maximum=1024**2))
                import base64,hmac
                if not hmac.compare_digest(replacement_token,base64.b64decode(staged_operator['raw'],validate=True)):
                    raise OwnershipError('Original replacement operator credential differs')
            if key_purpose!=intent.get('keyRotation',{}).get('purpose'):
                raise OwnershipError('Original AWS key purpose differs')
            if intent['priorGeneration']!=expected_generation or intent['configurationDigest']!=sha(document):
                raise OwnershipError('AWS renewal retry selection differs')
            if artifact is not None:
                if 'artifact' not in intent or _artifact(artifact,_original_work(path,command_id,intent['artifact']),
                        prior_digest=prior_pin['artifactDigest'],required_profiles=_required_profiles(path,command_id,initial))!=intent['artifact']:
                    raise OwnershipError('Selected AWS artifact retry differs')
            current=gate.state(path)
            if current['mode']=='READY' and current['generation']==intent['nextGeneration']:
                value=certificate(path,digest)
                return _result(value,'READY')
        else:
            current=gate.state(path)
            release=readiness.release_digest() if prior_pin is None else prior_pin['releaseDigest']
            prior_digest=digest if prior_document is None else readiness.installation_digest(prior_document['stores']['installation'])
            if selected(path):prior=certificate(path,prior_digest,allow_expired=True,_operator_release=release,
                _operator_content=None if prior_pin is None else prior_pin['contentDigest'])
            else:
                prior=readiness._initial_metadata(path,prior_digest,allow_expired=True,current_release=False)
                if prior['releaseDigest']!=release:raise OwnershipError('Explicit prior AWS artifact differs')
                if prior['profile']==readiness.PROFILE and prior['contentDigest']!=(
                        _runtime_content() if prior_pin is None else prior_pin['contentDigest']):
                    raise OwnershipError('Exact initial Core package differs')
            if prior_pin is None and prior['profile'] in {readiness.LEGACY_PROFILE,LEGACY_PROFILE,LEGACY_ARTIFACT_PROFILE}:
                raise OwnershipError('Legacy release requires explicit reviewed artifact migration')
            if prior_document is not None:
                _checked_service_documents(prior_document,document,prior,operators)
            if current['mode']!='READY' or current['generation']!=expected_generation or prior['generation']!=expected_generation:
                raise OwnershipError('AWS renewal original ready generation differs')
            prior_file=(_operation(path,_selector(path)['commandId'])/'ready.json' if selected(path) else root/readiness.FILE)
            intent=dict(profile=PROFILE,installationId=prior['installationId'],runId=prior['runId'],commandId=command_id,
                priorGeneration=expected_generation,parkGeneration=expected_generation+1,nextGeneration=expected_generation+2,
                priorGate=current,priorCertificateDigest=sha(prior),initialCertificateDigest=sha(initial),
                configurationDigest=sha(document),**{key:prior[key] for key in
                    ('installationDigest','cloudDigest','materialsDigest')},releaseDigest=initial['releaseDigest'])
            if service_context is not None:
                intent.update(serviceConfiguration=service_context,installationDigest=digest,cloudDigest=sha(cloud))
            baseline=None
            if artifact is not None or prior['profile'] in {LEGACY_ARTIFACT_PROFILE,ARTIFACT_PROFILE,*SERVICE_PROFILES}:
                from .temporal import configured_operator_connection
                with configured_operator_connection(cloud) as connection:
                    if service_context is not None:connection.installation.verify_operator(token if replacement_token is None else replacement_token)
                    baseline=runtime_checkpoint(path,installation=connection.installation)
                if prior_pin is not None:baseline.update(prior_pin['programs'])
                selected_artifact=(_artifact(artifact,baseline,prior_digest=prior_pin['artifactDigest'],
                    required_profiles={OPERATOR_PROFILE if operators is not None else MATERIAL_PROFILE if key_purpose is not None or prior['profile'] in MATERIAL_PROFILES else
                        SERVICE_PROFILE if service_context is not None else ARTIFACT_PROFILE,initial['profile'],prior['profile']}) if artifact is not None else
                    dict(artifactDigest=prior['artifactDigest'],releaseDigest=prior['releaseDigest'],checkpointDigest=sha(baseline),
                        priorArtifactDigest=prior['artifactDigest'],contentDigest=prior['contentDigest']))
                intent.update(profile=OPERATOR_PROFILE if operators is not None else MATERIAL_PROFILE if key_purpose is not None or prior['profile'] in MATERIAL_PROFILES else
                    SERVICE_PROFILE if service_context is not None else ARTIFACT_PROFILE,artifact=selected_artifact)
            if operators is not None:intent['operatorConfiguration']=operators
            if replacement_token is not None:
                from copy import deepcopy
                from . import key_rotation as keys,operator_rotation as credentials
                previous=prior.get('materialConfiguration')
                before=keys.snapshot(path);original=before if previous is None else previous['initial']
                after=deepcopy(before);after['records']['operatorStateDigest']=credentials.digest(operators['current'])
                configured=keys.checked_configuration(dict(initial=original,current=after,rotations=0 if previous is None else previous['rotations']),
                    path=path,operator_configuration=operators)
                staged=credentials.stage(path,command_id,replacement_token,prior,sha(document),credentials.state(path),operators)
                intent.update(operatorRotation=credentials.pin(staged),materialConfiguration=configured,materialsDigest=keys.state_digest(after))
            elif key_purpose is not None:
                from . import key_rotation as keys
                previous=prior.get('materialConfiguration') if prior['profile'] in MATERIAL_PROFILES else None
                if previous is not None and previous['rotations']>=8:raise OwnershipError('AWS key rotation envelope exhausted')
                before=keys.snapshot(path);original=before if previous is None else previous['initial']
                staged=keys.stage(path,command_id,key_purpose,prior,sha(document),before)
                configured=keys.rotated_configuration(original,before,staged,0 if previous is None else previous['rotations'],path=path,operator_configuration=operators)
                intent.update(materialConfiguration=configured,keyRotation=keys.pin(staged),materialsDigest=keys.state_digest(configured['current']))
            elif prior['profile'] in MATERIAL_PROFILES:
                intent['materialConfiguration']=prior['materialConfiguration']
            ensure_private(root/DIRECTORY);ensure_private(op)
            # A crash before intent publication may leave only the immutable
            # prior proof. Reuse those exact bytes; never adopt other contents.
            allowed={'prior-ready.json'}|({'work-before.json'} if baseline is not None else set())
            if 'keyRotation' in intent:
                from .key_rotation import STAGE_FILE
                allowed.add(STAGE_FILE)
            if 'operatorRotation' in intent:
                from .operator_rotation import STAGE_FILE
                allowed.add(STAGE_FILE)
            if set(p.name for p in op.iterdir())-allowed:
                raise OwnershipError('Unprepared AWS renewal operation differs')
            raw=private_read(prior_file,1024**2)
            previous=op/'prior-ready.json'
            if previous.exists() or previous.is_symlink():
                if private_read(previous,1024**2)!=raw:raise OwnershipError('AWS renewal prior proof differs')
            else:private_write(previous,raw)
            if baseline is not None:write_signed(op/'work-before.json',baseline,root/'owner.key')
            write_signed(op/'intent.json',intent,root/'owner.key')
        if (gate.state(path)!=intent['priorGate'] and (gate.state(path)['mode']!='PARKED'
                or gate.state(path)['generation']!=intent['parkGeneration'])):
            raise OwnershipError('AWS renewal preparation generation differs')
        write_signed(root/FILE,dict(profile=intent['profile'],commandId=command_id),root/'owner.key')
        if gate.state(path)==intent['priorGate']:gate._write(path,mode='PARKED',reason='operator-park')
        return dict(profile=intent['profile'],state='PARKED',generation=intent['parkGeneration'],controlReady=False,
            runtimeReady=False,enabledLanes=[],unknownUsageHeld=True)


def _result(value,state):
    return dict(profile=value['profile'],state=state,generation=value['generation'],expiresAt=value['expiresAt'],
        controlReady=True,runtimeReady=False,enabledLanes=[],productionQualified=False,
        unknownUsageHeld=True,originalDeadlinesUnchanged=True)


async def requalify(document,token,*,expected_generation,command_id,artifact=None,key_purpose=None):
    stores,cloud,cloud_path=readiness.configuration(document);path=stores['installation']['manifest'];root=path.parent
    digest=readiness.installation_digest(document['stores']['installation']);intent,initial=_intent(path,command_id,digest)
    def operator_check():
        if intent['profile']==OPERATOR_PROFILE:
            from .operator_rotation import authorize
            authorize(path,token,intent)
        else:verify_operator(path,token)
    operator_check()
    context=_service_context(initial,intent['serviceConfiguration'],intent.get('operatorConfiguration')) if intent['profile'] in SERVICE_PROFILES else initial
    if intent['profile'] in MATERIAL_PROFILES:
        from .key_rotation import state_digest
        context=context|dict(materialsDigest=state_digest(intent['materialConfiguration']['current']))
    if key_purpose!=intent.get('keyRotation',{}).get('purpose'):raise OwnershipError('Original AWS key purpose differs')
    if (type(expected_generation) is not int or expected_generation!=intent['parkGeneration']
            or intent['configurationDigest']!=sha(document)
            or _selector(path)!=dict(profile=intent['profile'],commandId=command_id)
            or str(cloud_path)!=context['cloudConfiguration'] or sha(cloud)!=context['cloudDigest']):
        raise OwnershipError('Exact parked AWS renewal selection required')
    if intent['profile'] in {LEGACY_PROFILE,LEGACY_ARTIFACT_PROFILE}:
        raise OwnershipError('Legacy operation requires its supported operator or reviewed migration')
    if artifact is not None:
        if 'artifact' not in intent or _artifact(artifact,_original_work(path,command_id,intent['artifact']),
                prior_digest=intent['artifact']['priorArtifactDigest'],required_profiles=_required_profiles(path,command_id,initial))!=intent['artifact']:
            raise OwnershipError('Selected AWS artifact differs')
    selected_release=intent.get('artifact',{}).get('releaseDigest',initial['releaseDigest'])
    expected_content=(intent['artifact']['contentDigest'] if intent['profile'] in {ARTIFACT_PROFILE,*SERVICE_PROFILES} else
        initial.get('contentDigest') if intent['profile']==PROFILE else None)
    if (expected_content is not None and _runtime_content()!=expected_content
            or expected_content is None and readiness.release_digest()!=selected_release):
        raise OwnershipError('Selected AWS artifact is not the running code')
    current=gate.state(path)
    if current['mode']=='READY':return _result(certificate(path,digest),'READY')
    if current['mode']!='PARKED' or current['generation']!=expected_generation:
        raise OwnershipError('AWS renewal requires its original Park')
    def unchanged():
        operator_check()
        if (gate.state(path)!=current or _selector(path)!=dict(profile=intent['profile'],commandId=command_id)
                or _intent(path,command_id,digest)[0]!=intent):raise OwnershipError('AWS renewal changed during qualification')
    unchanged()
    if intent['profile']==OPERATOR_PROFILE and 'operatorRotation' in intent:
        from .temporal import configured_operator_connection
        with configured_operator_connection(cloud) as connection:
            connection.installation.verify_operator(token)
        with file_lock(root/'recovery-gate.lock',timeout=2):
            unchanged()
            from .operator_rotation import apply
            apply(path,token,intent)
    await asyncio.to_thread(readiness.storage.prepare_stores,document['stores'],token,
        expected_generation=expected_generation,check_only=True)
    if intent['profile'] in MATERIAL_PROFILES:
        from . import key_rotation as keys
        with file_lock(root/'recovery-gate.lock',timeout=2):
            unchanged()
            prior=read_signed(_operation(path,command_id)/'prior-ready.json',root/'owner.key',maximum=1024**2)
            before,staged=_material_intent(path,command_id,intent,prior)
            if staged is not None:keys.apply(path,before,staged)
            if keys.snapshot(path)!=intent['materialConfiguration']['current']:
                raise OwnershipError('Selected AWS private material differs')
    from .temporal import configured_operator_connection,inspect_parked_history
    with configured_operator_connection(cloud) as connection:
        await asyncio.to_thread(readiness._runtime_stores,connection,token,require_empty=False)
        before=await asyncio.to_thread(runtime_checkpoint,path,installation=connection.installation)
        if 'artifact' in intent:_compatible_work(_original_work(path,command_id,intent['artifact']),before)
        capture=_checked_capture(await inspect_parked_history(connection,token,expected_generation=expected_generation),initial,intent)
        if capture['runtimeCheckpoint']!=before:raise OwnershipError('Original AWS work changed during inspection')
        from agentic_os.adapters.embedding.rpc import EmbeddingClient
        embedded=await EmbeddingClient(path).embed(['Agentic OS control renewal'],purpose='query')
        if len(embedded.vectors)!=1:raise OwnershipError('AWS renewal embedding service differs')
        await asyncio.to_thread(readiness._runtime_stores,connection,token,require_empty=False)
        if await asyncio.to_thread(runtime_checkpoint,path,installation=connection.installation)!=before:
            raise OwnershipError('Original AWS work changed during qualification')
    unchanged()
    with file_lock(root/'recovery-gate.lock',timeout=2):
        unchanged()
        if intent['profile'] in MATERIAL_PROFILES and readiness._materials(path)!=context['materialsDigest']:
            raise OwnershipError('Selected AWS keys changed before publication')
        if expected_content is not None and _runtime_content()!=expected_content:
            raise OwnershipError('Selected AWS code changed before publication')
        now=int(time.time());value={key:context[key] for key in readiness.FIELDS-{'profile','generation','issuedAt','expiresAt','checks'}}
        value.update(profile=intent['profile'],generation=intent['nextGeneration'],issuedAt=now,expiresAt=now+document['release_seconds'],
            checks={key:True for key in CHECKS},commandId=command_id,initialCertificateDigest=sha(initial),
            priorCertificateDigest=intent['priorCertificateDigest'],checkpointDigest=sha(before),historyDigest=sha(capture),
            releaseDigest=selected_release)
        if intent['profile'] in SERVICE_PROFILES:value['serviceConfiguration']=intent['serviceConfiguration']
        if intent['profile'] in MATERIAL_PROFILES:value['materialConfiguration']=intent['materialConfiguration']
        if intent['profile']==OPERATOR_PROFILE:value['operatorConfiguration']=intent['operatorConfiguration']
        if 'artifact' in intent:
            value['artifactDigest']=intent['artifact']['artifactDigest']
            if 'contentDigest' in intent['artifact']:value['contentDigest']=intent['artifact']['contentDigest']
        elif intent['profile']==PROFILE:value['contentDigest']=initial['contentDigest']
        _checked_ready(value,initial,artifact=intent.get('artifact'),path=path)
        op=_operation(path,command_id)
        write_signed(op/'history.json',capture,root/'owner.key')
        write_signed(op/'ready.json',value,root/'owner.key')
        gate._write(path,mode='READY',reason='verified')
        if certificate(path,digest)!=value:raise OwnershipError('AWS renewal publication differs')
    return _result(value,'READY')
