"""Pinned AWS secrets and TLS control PostgreSQL over the shared core ports.

No resource creation, migration, environment/DSN discovery, secret rotation or
qualification occurs here. Runtime roles read explicitly reviewed secret versions.
Local target and recovery adapters remain independent and unchanged.
"""
from contextlib import contextmanager
from dataclasses import dataclass
import hmac
import hashlib
from pathlib import Path
import re
from types import MappingProxyType
from uuid import UUID

import psycopg

from agentic_os.adapters.installation import InstallationPorts,ComponentPorts
from agentic_os.adapters.local.artifacts import LocalArtifacts,LocalKeys
from agentic_os.adapters.local.files import OwnershipError,check_private,private_read
from agentic_os.adapters.local.target import check_owned_connection
from agentic_os.adapters.postgres.migrate import migration_head
from agentic_os.adapters.postgres.profiles import LEGACY_RDS,RDS_EXACT,checked_profile,vector_version,migration_profile


def regional_client(session,service,region):
    """Caller explicitly supplies the AWS SDK session/credential source."""
    from botocore.config import Config
    if service not in {'secretsmanager','scheduler','rds'} or region not in session.get_available_regions(service):
        raise OwnershipError('Unsupported explicit AWS service or region')
    return session.client(service,region_name=region,verify=True,use_ssl=True,
        endpoint_url='https://'+service+'.'+region+'.amazonaws.com',config=Config(signature_version='v4',
        connect_timeout=2,read_timeout=2,max_pool_connections=4,proxies={},defaults_mode='standard',
        retries={'total_max_attempts':1}))


def secrets_client(session,region):return regional_client(session,'secretsmanager',region)


@dataclass(frozen=True)
class SecretPin:
    arn:str
    version:str

    def __post_init__(self):
        if (type(self.arn) is not str or re.fullmatch(r'arn:aws:secretsmanager:[a-z0-9-]+:[0-9]{12}:secret:[A-Za-z0-9/_+=.@-]+-[A-Za-z0-9]{6}',self.arn) is None
                or type(self.version) is not str or re.fullmatch(r'[A-Za-z0-9-]{32,64}',self.version) is None):
            raise OwnershipError('Exact secret ARN and immutable version required')


class AWSSecrets:
    def __init__(self,client,*,region,account,installation_id):
        if (type(region) is not str or re.fullmatch(r'[a-z]{2}(?:-[a-z]+)+-[0-9]+',region) is None
                or type(account) is not str or re.fullmatch(r'[0-9]{12}',account) is None
                or type(installation_id) is not UUID or client.meta.region_name!=region
                or client.meta.endpoint_url!='https://secretsmanager.'+region+'.amazonaws.com'):
            raise OwnershipError('Explicit regional AWS secret client and installation required')
        self.client,self.region,self.account,self.installation_id=client,region,account,installation_id

    def validate_pin(self,pin,scope):
        if type(pin) is not SecretPin or (scope not in ('control','retrieval','knowledge') and type(scope) is not UUID):
            raise OwnershipError('Explicit scoped secret pin required')
        prefix='arn:aws:secretsmanager:'+self.region+':'+self.account+':secret:agentic-os/'+str(self.installation_id)+'/'+str(scope)+'/'
        if not pin.arn.startswith(prefix):raise OwnershipError('Secret does not belong to this installation scope')

    def read(self,pin,scope):
        self.validate_pin(pin,scope)
        try:
            value=self.client.get_secret_value(SecretId=pin.arn,VersionId=pin.version)
            if (value.get('ARN')!=pin.arn or value.get('VersionId')!=pin.version
                    or ('SecretString' in value)==('SecretBinary' in value)):raise ValueError()
            raw=value['SecretString'].encode('utf-8') if 'SecretString' in value else value['SecretBinary']
            if type(raw) is not bytes or not 1<=len(raw)<=65536:raise ValueError()
            return raw
        except Exception:raise OwnershipError('Pinned AWS secret unavailable') from None


class AWSHostCredentials:
    def __init__(self,secrets,pins):
        if type(secrets) is not AWSSecrets or type(pins) is not dict or any(
                type(key) is not tuple or len(key)!=2 or type(key[0]) is not UUID
                or type(key[1]) is not str or not key[1] or type(pin) is not SecretPin for key,pin in pins.items()):
            raise OwnershipError('Explicit application credential pins required')
        self.secrets=secrets;self.installation_id=secrets.installation_id;self.pins=MappingProxyType(dict(pins))
        for (application,_),pin in pins.items():secrets.validate_pin(pin,application)

    def get(self,application,reference):
        try:
            application=UUID(str(application));pin=self.pins[(application,reference)]
            value=self.secrets.read(pin,application).decode('ascii')
            if not 32<=len(value)<=256:raise ValueError()
            return value
        except Exception:raise OwnershipError('Scoped Host credential unavailable') from None

    def put(self,application,reference,secret):
        if type(secret) is not str or not secret.isascii() or not 32<=len(secret)<=256:
            raise OwnershipError('Invalid Host credential')
        if not hmac.compare_digest(self.get(application,reference),secret):
            raise OwnershipError('Credential rotation requires a newly provisioned immutable reference')


class AWSOperator:
    def __init__(self,secrets,pin,*,generation):
        if type(secrets) is not AWSSecrets or type(pin) is not SecretPin or type(generation) is not int or not 1<=generation<=2**53-1:
            raise OwnershipError('Explicit operator identity required')
        self.secrets,self.pin,self.generation=secrets,pin,generation;self.installation_id=secrets.installation_id
        secrets.validate_pin(pin,'control')

    def __call__(self,token):
        if type(token) is not bytes or len(token)!=32:raise OwnershipError('Operator credential rejected')
        expected=self.secrets.read(self.pin,'control')
        if len(expected)!=32 or not hmac.compare_digest(expected,token):raise OwnershipError('Operator credential rejected')
        return dict(installationId=str(self.installation_id),principal='installation-operator',generation=self.generation,profile='aws-eks/1')

    def checkpoint(self,token):
        # Secrets Manager versions are immutable. Authenticate anew before
        # each short SQL operation; never carry a network read across SQL.
        # A new operation must read its pin again, including after an await.
        value=self(token)
        return lambda:dict(value)


def check_control_namespace(connection,installation_id):
    """Existing schema/namespace prerequisites, without adopting or changing data."""
    if type(installation_id) is not UUID:raise OwnershipError('Explicit control installation required')
    connection.execute("SET LOCAL lock_timeout='2s'")
    connection.execute("SET LOCAL statement_timeout='3s'")
    if connection.execute('SELECT version_num FROM alembic_version').fetchall()!=[(migration_head(),)]:
        raise OwnershipError('Control schema does not match this installed release')
    if connection.execute('SELECT installation_id FROM os_applications WHERE installation_id<>%s LIMIT 1',(installation_id,)).fetchone() is not None:
        raise OwnershipError('Foreign control installation; adoption refused')


def check_component_namespace(connection,installation_id,component,*,storage_profile=LEGACY_RDS):
    if type(installation_id) is not UUID or component not in {'retrieval','knowledge'}:
        raise OwnershipError('Explicit component installation required')
    connection.execute("SET LOCAL lock_timeout='2s'")
    connection.execute("SET LOCAL statement_timeout='3s'")
    selected=migration_profile(storage_profile)
    head=migration_head(component,storage_profile=selected) if selected is not None else migration_head(component)
    if (connection.execute('SELECT version_num FROM alembic_version').fetchall()!=[(head,)]
            or connection.execute('SELECT installation_id,component FROM os_store_registry').fetchall()!=[(installation_id,component)]
            or connection.execute("SELECT extversion FROM pg_extension WHERE extname='vector'").fetchall()!=[(vector_version(storage_profile),)]):
        raise OwnershipError('Configured component schema, namespace or extension differs')
    if storage_profile==RDS_EXACT and connection.execute(
            "SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace "
            "JOIN pg_am a ON a.oid=c.relam WHERE n.nspname='public' AND a.amname IN ('hnsw','ivfflat') LIMIT 1").fetchone():
        raise OwnershipError('RDS exact profile cannot contain ANN indexes')


class RDSControl:
    def __init__(self,secrets,password,*,host,port,database,user,ca,ca_sha256,
            component='control',role='runtime',storage_profile=LEGACY_RDS):
        self.storage_profile=checked_profile(storage_profile)
        migration=type(self) is RDSMigrator and role=='migrator'
        if (component not in {'control','retrieval','knowledge'} or role not in {'runtime','migrator','public'}
                or not migration and (
                component!='knowledge' and role!='runtime'
                or type(self) is RDSControl and (component,role)!=('control','runtime'))):
            raise OwnershipError('Explicit supported component and purpose role required')
        suffix={'runtime':'_r','migrator':'_m','public':'_r_public'}[role]
        if (type(secrets) is not AWSSecrets or type(password) is not SecretPin
                or type(host) is not str or re.fullmatch(r'[a-z0-9-]+\.[a-z0-9-]+\.'+re.escape(secrets.region)+r'\.rds\.amazonaws\.com',host) is None
                or type(port) is not int or not 1<=port<=65535
                or database!='aos_'+secrets.installation_id.hex+'_'+component or user!=database+suffix
                or not isinstance(ca,Path) or not ca.is_absolute() or ca.resolve()!=ca
                or type(ca_sha256) is not str or re.fullmatch(r'[a-f0-9]{64}',ca_sha256) is None):
            raise OwnershipError('Explicit TLS RDS control endpoint, namespace and runtime role required')
        check_private(ca)
        secrets.validate_pin(password,component)
        self.secrets,self.password=secrets,password;self.installation_id=secrets.installation_id
        self.component,self.role=component,role
        self.host,self.port,self.database,self.user,self.ca=host,port,database,user,ca
        self.ca_sha256=ca_sha256
        self._ca()

    def _ca(self):
        if hashlib.sha256(private_read(self.ca)).hexdigest()!=self.ca_sha256:
            raise OwnershipError('Reviewed control CA changed')

    def connect(self):
        connection=None
        try:
            self._ca()
            password=self.secrets.read(self.password,self.component).decode('ascii')
            if not 32<=len(password)<=256:raise ValueError()
            connection=psycopg.connect(host=self.host,port=self.port,dbname=self.database,user=self.user,password=password,
                connect_timeout=2,sslmode='verify-full',sslrootcert=str(self.ca),autocommit=False,
                options='-c lock_timeout=2s -c statement_timeout=3s')
            if not connection.pgconn.ssl_in_use:raise OwnershipError('TLS control connection required')
            if self.role=='public':
                from agentic_os.knowledge.access import check_public_connection
                check_public_connection(connection,database=self.database,role=self.user)
            else:
                check_owned_connection(connection,dict(name=self.database,**{self.role:self.user}),role=self.role)
                self._namespace(connection)
            return connection
        except BaseException as error:
            if connection is not None:connection.close()
            if isinstance(error,Exception):raise OwnershipError('Configured control connection unavailable') from None
            raise

    def _namespace(self,connection):
        if self.component=='control':check_control_namespace(connection,self.installation_id)
        else:check_component_namespace(connection,self.installation_id,self.component,storage_profile=self.storage_profile)


class RDSMigrator(RDSControl):
    """Separate TLS migrator credential; schema is checked under its DDL lock.

    Only the explicit storage operator uses this adapter. Runtime assembly
    rejects it and cannot borrow its credentials or bypass schema checks.
    """
    def __init__(self,secrets,password,*,component,**kwargs):
        super().__init__(secrets,password,component=component,role='migrator',**kwargs)

    def _namespace(self,connection):
        # A fresh store has no Alembic table. The caller must establish its
        # exact expected catalog before DDL, in the same locked transaction.
        pass


class RDSComponent(RDSControl):
    """Same TLS boundary, separately scoped non-control database credentials."""
    def __init__(self,secrets,password,*,component,role,**kwargs):
        if component not in {'retrieval','knowledge'}:
            raise OwnershipError('Isolated component store required')
        super().__init__(secrets,password,component=component,role=role,**kwargs)


def aws_component_ports(*,root,postgres,stores):
    """Compose reviewed existing stores; no role, key or embedding setup."""
    expected={'retrieval':('retrieval','runtime'),'knowledge':('knowledge','runtime'),
        'knowledge_public':('knowledge','public'),'knowledge_operator':('knowledge','migrator')}
    if (type(postgres) is not RDSControl or type(stores) is not dict or set(stores)!=set(expected)
            or any(type(stores[k]) is not RDSComponent or (stores[k].component,stores[k].role)!=v
                or stores[k].installation_id!=postgres.installation_id
                or stores[k].storage_profile!=postgres.storage_profile for k,v in expected.items())):
        raise OwnershipError('Complete isolated component connections required')
    def keys():
        from agentic_os.adapters.local.ownership import load_manifest
        from agentic_os.knowledge.access import bound_knowledge_keys
        value=load_manifest(root/'manifest.json')
        if value['installationId']!=str(postgres.installation_id):raise OwnershipError('Knowledge key installation differs')
        if value['profile']=='aws-eks/1':
            from .bootstrap import private_knowledge_keys
            return private_knowledge_keys(root/'manifest.json')
        return bound_knowledge_keys(root/'manifest.json',value)
    from agentic_os.adapters.embedding.rpc import EmbeddingClient
    return ComponentPorts(installation_id=postgres.installation_id,
        **{k:store.connect for k,store in stores.items()},knowledge_keys=keys,
        embedding=lambda:EmbeddingClient(root/'manifest.json'),
        retrieval_modes=frozenset({'exact','lexical','hybrid'} if postgres.storage_profile==RDS_EXACT else {'exact','ann','lexical','hybrid'}))


@dataclass(frozen=True)
class CoordinatedControlRelease:
    """Borrow the real finite recovery lease, without local target discovery.

    The signed installation metadata and existing release proofs must already
    belong to this control namespace. This adapter creates no certificate,
    adopts no database and cannot enable an unqualified original installation.
    RDSControl independently validates each actual TLS database connection.
    """
    manifest:Path
    installation_id:UUID

    def __post_init__(self):
        if (not isinstance(self.manifest,Path) or not self.manifest.is_absolute()
                or self.manifest.resolve()!=self.manifest or self.manifest.name!='manifest.json'
                or type(self.installation_id) is not UUID):
            raise OwnershipError('Explicit certified control installation required')
        self._identity()

    def _identity(self):
        from agentic_os.adapters.local.ownership import load_manifest
        if load_manifest(self.manifest)['installationId']!=str(self.installation_id):
            raise OwnershipError('Control recovery installation differs')

    @contextmanager
    def __call__(self):
        from agentic_os.adapters.local.recovery_gate import runtime_guard
        from agentic_os.adapters.local.recovery_ready import TransactionRelease
        self._identity()
        with runtime_guard(self.manifest) as proof:
            if (type(proof) is not TransactionRelease or proof.path!=self.manifest
                    or proof.current()['installationId']!=str(self.installation_id)):
                raise OwnershipError('Verified production recovery proof required')
            yield proof


class _OperatorMetadataKeys:
    """Typed metadata-only ports never open or create encryption key material."""
    def unavailable(self,*args,**kwargs):raise OwnershipError('Operator metadata cannot access encryption keys')
    active=rotate=encrypt=decrypt=_key=unavailable


def aws_installation_ports(*,root,postgres,credentials,operator,transaction_guard=None,components=None,preparing_recovery=False,key_generation=None):
    """Compose filesystem artifacts and an actual coordinated recovery lease.

    Recovery must supply its original verifiable release proof; a null/unready
    guard cannot enable a cloud transaction. The default reuses the existing
    certified installation. Explicit alternative placement guards retain their
    original proof requirement. This factory grants no deployment qualification.
    """
    if (type(postgres) is not RDSControl or type(credentials) is not AWSHostCredentials or type(operator) is not AWSOperator
            or postgres.installation_id!=credentials.installation_id or postgres.installation_id!=operator.installation_id
            or not isinstance(root,Path) or not root.is_absolute() or root.resolve()!=root
            or transaction_guard is not None and not callable(transaction_guard) or type(preparing_recovery) is not bool):
        raise OwnershipError('One exact installation and complete recovery backend required')
    selected=CoordinatedControlRelease(root/'manifest.json',postgres.installation_id) if transaction_guard is None else transaction_guard
    if preparing_recovery:
        from .managed_restore import assert_preparing
        assert_preparing(root/'manifest.json')
    if key_generation is not None:
        if preparing_recovery:raise OwnershipError('One explicit managed operator purpose required')
        from agentic_os.adapters.local.recovery_operator import _key_archive
        _key_archive(root/'manifest.json',key_generation)
    @contextmanager
    def guard():
        if preparing_recovery or key_generation is not None:raise OwnershipError('Recovery preparation cannot grant runtime transactions')
        with selected() as proof:
            if proof is None or not callable(getattr(proof,'verify',None)):raise OwnershipError('Verified production recovery proof required')
            yield proof
    keys=LocalKeys(root/'keys') if key_generation is None else _OperatorMetadataKeys()
    if not preparing_recovery and key_generation is None:keys.active()
    def connect():
        def current():
            if key_generation is None:assert_preparing(root/'manifest.json')
            else:_key_archive(root/'manifest.json',key_generation)
        current();db=postgres.connect()
        try:
            db.rollback();db.execute('SET TRANSACTION READ ONLY');current();return db
        except BaseException:db.close();raise
    inspecting=preparing_recovery or key_generation is not None
    return InstallationPorts(installation_id=postgres.installation_id,root=root,connect=connect if inspecting else postgres.connect,
        transaction_guard=guard,operator=operator,credentials=credentials,
        artifacts=LocalArtifacts(root/'artifacts',keys),components=None if inspecting else components)
