"""Thin serial Lambda lifecycle for the existing schedule wake adapter.

The trusted async-context factory supplies the configured core services. Keep
one event loop across warm invocations; no event supplies configuration, time,
credentials, a task launch or execution authority. No public API is enabled.
"""
import asyncio
import threading
import sys

from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode
from .scheduler import SchedulerPlacement,EventBridgeSchedule


class ScheduleWakeHandler:
    def __init__(self,placement,factory,*,reuse_services=True):
        if type(placement) is not SchedulerPlacement or not callable(factory):raise ValueError('Explicit Lambda placement and service factory required')
        if type(reuse_services) is not bool:raise ValueError('Explicit service lifecycle required')
        self.reuse_services=reuse_services
        self.placement,self.factory=placement,factory
        self.runner=asyncio.Runner();self.lock=threading.Lock()
        self.context=None;self.services=None;self.closed=False

    async def _start(self):
        if self.services is None:
            context=self.factory()
            services=await context.__aenter__()
            try:
                scheduler,activities=services
                if type(scheduler) is not EventBridgeSchedule or scheduler.placement!=self.placement:
                    raise ValueError('Lambda services do not match this placement')
            except BaseException:
                await context.__aexit__(*sys.exc_info());raise
            self.context,self.services=context,services
        return self.services

    def __call__(self,event,context):
        if (self.closed or getattr(context,'invoked_function_arn',None)!=self.placement.function_arn
                or type(event) is not dict or set(event)!={'driver'}):raise OSErrorCode('DENIED')
        try:validate_contract('ScheduleDriverState',event['driver'])
        except Exception:raise OSErrorCode('INVALID') from None
        if event['driver']['installationId']!=str(self.placement.installation_id):raise OSErrorCode('DENIED')
        if not self.lock.acquire(blocking=False):raise OSErrorCode('CAPACITY')
        try:
            remaining=context.get_remaining_time_in_millis()
            if type(remaining) is not int or remaining<=1000:raise OSErrorCode('UNAVAILABLE')
            async def invoke():
                # Same25s cap as the existing OSScheduleTick activity, shortened
                # by the invocation's real remaining time; no grant extension.
                async with asyncio.timeout(min(25,(remaining-1000)/1000)):
                    try:
                        scheduler,activities=await self._start()
                        return await scheduler.wake(activities,event)
                    finally:
                        if not self.reuse_services and self.context is not None:
                            owned=self.context;self.context=None;self.services=None
                            await owned.__aexit__(*sys.exc_info())
            return self.runner.run(invoke())
        except OSErrorCode:raise
        except Exception:raise OSErrorCode('UNAVAILABLE') from None
        finally:self.lock.release()

    def close(self):
        if not self.lock.acquire(blocking=False):raise OSErrorCode('CAPACITY')
        try:
            if self.closed:return
            self.closed=True
            try:
                if self.context is not None:self.runner.run(self.context.__aexit__(None,None,None))
            finally:self.runner.close()
        except Exception:raise OSErrorCode('UNAVAILABLE') from None
        finally:self.lock.release()
