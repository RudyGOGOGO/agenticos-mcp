"""Reviewed operator credential handoff inside the finite AWS maintenance gate.

A replacement is separately provisioned as an immutable secret version. This
module stages it privately; it does not create secrets or grant runtime access.
"""
import base64
import hashlib
import hmac
from pathlib import Path
import re

from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.adapters.configured_installation import closed
from agentic_os.adapters.local import operator
from agentic_os.adapters.local.files import OwnershipError,private_read,private_write
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.resources import ensure_private,read_signed,write_signed
from agentic_os.adapters.local.recovery_maintenance import DIRECTORY,_operation
from agentic_os.adapters.local.recovery_key_continuity import sha

PROFILE='aws-staged-operator-credential/1'
STAGE_FILE='staged-operator.json'
FIELDS={'profile','installationId','runId','commandId','configurationDigest','priorCertificateDigest',
    'priorGeneration','before','after','raw'}
_INHERIT=object()


def state(path):
    path=Path(path);file=path.parent/'operator-state.json'
    value=parse_canonical_json(private_read(file))
    if file.lstat().st_nlink!=1:raise OwnershipError('Shared operator state unavailable')
    operator.checked_state(path.parent,value)
    return value


def digest(value):return hashlib.sha256(canonical_bytes(value)).hexdigest()


def checked_configuration(path,value):
    """Authenticated initial/current state, not a bypass of live operator checks."""
    path=Path(path)
    try:
        closed(value,{'initial','current'})
        initial=operator.checked_state(path.parent,value['initial']);current=operator.checked_state(path.parent,value['current'])
        ident=load_manifest(path)['installationId']
        if (initial['installationId']!=ident or current['installationId']!=ident or not initial['consumed']
                or not current['consumed'] or initial['generation']!=1 or current['generation']<=1
                or current['version']!=2 or initial['operatorDigest']==current['operatorDigest']
                or any(initial[k]!=current[k] for k in ('bootstrapDigest','expiresAt','consumed'))):raise ValueError()
        for record in (initial,current):
            if any(type(record[k]) is not str or re.fullmatch('[a-f0-9]{64}',record[k]) is None
                    for k in ('bootstrapDigest','operatorDigest')):raise ValueError()
    except Exception:raise OwnershipError('Authenticated AWS operator continuity unavailable') from None
    return value


def next_configuration(path,before,replacement,previous=None):
    path=Path(path);old=operator.checked_state(path.parent,before)
    if old['generation']>=2**53-1:raise OwnershipError('Operator generation exhausted')
    ident=load_manifest(path)['installationId'];new_digest=operator.bound_digest(ident,replacement)
    if new_digest==old['operatorDigest']:raise OwnershipError('Replacement operator credential must differ')
    current=parse_canonical_json(operator.encoded_state(path.parent,old|dict(version=2,
        generation=old['generation']+1,operatorDigest=new_digest)))
    initial=before if previous is None else checked_configuration(path,previous)['initial']
    return checked_configuration(path,dict(initial=initial,current=current))


def checked_stage(path,value):
    path=Path(path);manifest=load_manifest(path)
    try:
        closed(value,FIELDS)
        if value['profile']!=PROFILE or any(value[k]!=manifest[k] for k in ('installationId','runId')):raise ValueError()
        from agentic_os.adapters.local.artifacts import checked_id
        checked_id(value['commandId'])
        if type(value['priorGeneration']) is not int or value['priorGeneration']<2 or value['priorGeneration']%2:raise ValueError()
        for k in ('configurationDigest','priorCertificateDigest'):
            if type(value[k]) is not str or re.fullmatch('[a-f0-9]{64}',value[k]) is None:raise ValueError()
        before=operator.checked_state(path.parent,value['before']);after=operator.checked_state(path.parent,value['after'])
        raw=base64.b64decode(value['raw'],validate=True)
        if (before['installationId']!=manifest['installationId'] or not before['consumed'] or len(raw)!=32
                or after!=before|dict(version=2,generation=before['generation']+1,
                    operatorDigest=operator.bound_digest(manifest['installationId'],raw))
                or before['operatorDigest']==after['operatorDigest']):raise ValueError()
    except Exception:raise OwnershipError('Exact staged operator credential unavailable') from None
    return value


def stage(path,command,replacement,prior,configuration_digest,before,configured):
    path=Path(path);manifest=load_manifest(path);checked_configuration(path,configured)
    value=dict(profile=PROFILE,installationId=manifest['installationId'],runId=manifest['runId'],commandId=command,
        configurationDigest=configuration_digest,priorCertificateDigest=sha(prior),priorGeneration=prior['generation'],
        before=before,after=configured['current'],raw=base64.b64encode(replacement).decode('ascii'))
    checked_stage(path,value);op=_operation(path,command);ensure_private(path.parent/DIRECTORY);ensure_private(op)
    file=op/STAGE_FILE
    if file.exists() or file.is_symlink():
        existing=read_signed(file,path.parent/'owner.key',maximum=32768)
        if file.lstat().st_nlink!=1 or existing!=value:raise OwnershipError('Original operator stage differs')
    else:
        if set(p.name for p in op.iterdir())-{'prior-ready.json','work-before.json'}:
            raise OwnershipError('Unknown operator stage material')
        write_signed(file,value,path.parent/'owner.key')
    return value


def pin(value):return dict(stageDigest=sha(value),operatorDigest=value['after']['record']['operatorDigest'])


def intent_stage(path,command,intent,prior,*,prior_configuration=_INHERIT):
    path=Path(path);configured=checked_configuration(path,intent['operatorConfiguration'])
    previous=prior.get('operatorConfiguration') if prior_configuration is _INHERIT else prior_configuration
    if previous is not None:checked_configuration(path,previous)
    if 'operatorRotation' not in intent:
        if previous is None or configured!=previous:raise OwnershipError('Ordinary renewal changes operator authority')
        return None
    file=_operation(path,command)/STAGE_FILE
    staged=checked_stage(path,read_signed(file,path.parent/'owner.key',maximum=32768))
    if file.lstat().st_nlink!=1:raise OwnershipError('Shared staged operator credential')
    binding=dict(installationId=intent['installationId'],runId=intent['runId'],commandId=command,
        priorGeneration=intent['priorGeneration'],configurationDigest=intent['configurationDigest'],priorCertificateDigest=intent['priorCertificateDigest'])
    before=staged['before']
    if (any(staged[k]!=v for k,v in binding.items()) or pin(staged)!=intent['operatorRotation']
            or staged['after']!=configured['current']
            or (configured['initial'] if previous is None else previous['current'])!=before
            or (before if previous is None else previous['initial'])!=configured['initial']):
        raise OwnershipError('Reviewed operator intent differs')
    return staged


def authorize(path,token,intent,*,prior_configuration=_INHERIT):
    """Only the staged new credential may finish its original parked handoff."""
    path=Path(path);configured=checked_configuration(path,intent['operatorConfiguration'])
    if not hmac.compare_digest(operator.bound_digest(load_manifest(path)['installationId'],token),
            configured['current']['record']['operatorDigest']):raise OwnershipError('Replacement operator credential rejected')
    current=state(path)
    if 'operatorRotation' not in intent:
        if current!=configured['current']:raise OwnershipError('Current operator state differs')
        operator.verify_operator(path,token);return
    prior=read_signed(_operation(path,intent['commandId'])/'prior-ready.json',path.parent/'owner.key',maximum=1024**2)
    staged=intent_stage(path,intent['commandId'],intent,prior,prior_configuration=prior_configuration)
    if current not in (staged['before'],staged['after']):raise OwnershipError('Operator handoff state differs')


def apply(path,token,intent,*,prior_configuration=_INHERIT):
    path=Path(path);authorize(path,token,intent,prior_configuration=prior_configuration)
    if 'operatorRotation' not in intent:return
    op=_operation(path,intent['commandId']);prior=read_signed(op/'prior-ready.json',path.parent/'owner.key',maximum=1024**2)
    staged=intent_stage(path,intent['commandId'],intent,prior,prior_configuration=prior_configuration)
    file=path.parent/'operator.key';old=private_read(file,32)
    if file.lstat().st_nlink!=1:raise OwnershipError('Shared operator credential unavailable')
    old_digest=operator.bound_digest(load_manifest(path)['installationId'],old)
    if old_digest not in {staged['before']['record']['operatorDigest'],staged['after']['record']['operatorDigest']}:
        raise OwnershipError('Unrelated operator key prevents handoff')
    # Original credential remains in private, digest-bound recovery evidence;
    # a current generation never authenticates it after the state cutover.
    retained=op/'prior-operator.key'
    if old_digest==staged['before']['record']['operatorDigest']:
        if retained.exists() or retained.is_symlink():
            if private_read(retained,32)!=old:raise OwnershipError('Retained original operator key differs')
        else:private_write(retained,old)
    elif not retained.exists():raise OwnershipError('Original operator key evidence unavailable')
    if retained.lstat().st_nlink!=1 or operator.bound_digest(load_manifest(path)['installationId'],private_read(retained,32))!=staged['before']['record']['operatorDigest']:
        raise OwnershipError('Retained operator key authentication differs')
    private_write(file,token,replace=True)
    private_write(path.parent/'operator-state.json',canonical_bytes(staged['after']),replace=True)
    operator.verify_operator(path,token)
