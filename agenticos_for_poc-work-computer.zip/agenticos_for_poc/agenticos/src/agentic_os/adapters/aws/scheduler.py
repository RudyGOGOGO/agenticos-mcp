"""EventBridge wake/repair placement for the existing private schedule driver.

EventBridge never selects slots or admits tasks. The same Temporal driver,
current owner/Host authority, SQL dedupe and finite outbox remain authoritative.
"""
import asyncio
from dataclasses import dataclass
import re
from uuid import UUID

from botocore.exceptions import ClientError

from agentic_os.adapters.local.files import OwnershipError
from agentic_os.contracts.canonical import canonical_bytes,digest
from agentic_os.contracts.validation import validate_contract
from agentic_os.errors import OSErrorCode


@dataclass(frozen=True)
class SchedulerPlacement:
    installation_id:UUID
    region:str
    account:str
    function_arn:str
    role_arn:str

    def __post_init__(self):
        if (type(self.installation_id) is not UUID or type(self.region) is not str
                or re.fullmatch(r'[a-z]{2}(?:-[a-z]+)+-[0-9]+',self.region) is None
                or type(self.account) is not str or re.fullmatch(r'[0-9]{12}',self.account) is None
                or type(self.function_arn) is not str or re.fullmatch('arn:aws:lambda:'+re.escape(self.region)+':'+self.account+r':function:[A-Za-z0-9_-]{1,64}:[A-Za-z0-9_-]{1,128}',self.function_arn) is None
                or type(self.role_arn) is not str or re.fullmatch('arn:aws:iam::'+self.account+r':role/[A-Za-z0-9+=,.@_/-]{1,512}',self.role_arn) is None):
            raise OwnershipError('One explicit qualified-function alias/version and scheduler role required')

    @property
    def group(self):return 'aos-'+self.installation_id.hex

    @property
    def group_arn(self):return 'arn:aws:scheduler:'+self.region+':'+self.account+':schedule-group/'+self.group

    def permissions(self):
        return dict(trust=dict(Version='2012-10-17',Statement=[dict(Effect='Allow',
            Principal=dict(Service='scheduler.amazonaws.com'),Action='sts:AssumeRole',
            Condition=dict(StringEquals={'aws:SourceAccount':self.account},ArnEquals={'aws:SourceArn':self.group_arn}))]),
            execution=dict(Version='2012-10-17',Statement=[dict(Effect='Allow',Action='lambda:InvokeFunction',Resource=self.function_arn)]),
            controller=dict(Version='2012-10-17',Statement=[dict(Effect='Allow',
                Action=['scheduler:CreateSchedule','scheduler:GetSchedule','scheduler:DeleteSchedule'],
                Resource='arn:aws:scheduler:'+self.region+':'+self.account+':schedule/'+self.group+'/*'),
                dict(Effect='Allow',Action='iam:PassRole',Resource=self.role_arn,
                    Condition=dict(StringEquals={'iam:PassedToService':'scheduler.amazonaws.com'}))]))


class EventBridgeSchedule:
    def __init__(self,client,placement,durable):
        if (type(placement) is not SchedulerPlacement or client.meta.region_name!=placement.region
                or client.meta.endpoint_url!='https://scheduler.'+placement.region+'.amazonaws.com'
                or not callable(getattr(durable,'driver_state',None)) or not callable(getattr(durable,'start_driver',None))
                or not callable(getattr(durable,'start_task',None)) or getattr(durable,'client',None) is None):
            raise OwnershipError('Explicit scheduler placement and original durable driver required')
        self.scheduler,self.placement,self.durable=client,placement,durable
        self.client=durable.client

    def request(self,state):
        validate_contract('ScheduleDriverState',state)
        if state['installationId']!=str(self.placement.installation_id):raise OSErrorCode('DENIED')
        target=dict(Arn=self.placement.function_arn,RoleArn=self.placement.role_arn,
            Input=canonical_bytes(dict(driver=state)).decode(),
            RetryPolicy=dict(MaximumEventAgeInSeconds=60,MaximumRetryAttempts=1))
        identity=digest('command',dict(target=target,group=self.placement.group))
        name='aos-'+UUID(state['definitionId']).hex+'-'+identity[:16]
        request=dict(Name=name,GroupName=self.placement.group,ScheduleExpression='rate(1 minute)',
            ScheduleExpressionTimezone='UTC',FlexibleTimeWindow=dict(Mode='OFF'),State='ENABLED',Target=target)
        request['ClientToken']=digest('command',request)
        return request

    def arn(self,request):return 'arn:aws:scheduler:'+self.placement.region+':'+self.placement.account+':schedule/'+request['GroupName']+'/'+request['Name']

    def checked(self,request,value):
        if (type(value) is not dict or value.get('Arn')!=self.arn(request)
                or any(value.get(key)!=request[key] for key in ('Name','GroupName','ScheduleExpression','ScheduleExpressionTimezone','FlexibleTimeWindow','State','Target'))
                or value.get('KmsKeyArn') is not None or value.get('StartDate') is not None or value.get('EndDate') is not None):
            raise OwnershipError('Foreign or changed scheduler placement; adoption refused')
        return value

    def ensure(self,state):
        request=self.request(state)
        try:
            value=self.scheduler.create_schedule(**request)
            if value.get('ScheduleArn')!=self.arn(request):raise OwnershipError('Unexpected scheduler placement')
        except ClientError as error:
            if error.response.get('Error',{}).get('Code')!='ConflictException':raise OwnershipError('Scheduler placement unavailable') from None
            try:self.checked(request,self.scheduler.get_schedule(Name=request['Name'],GroupName=request['GroupName']))
            except OwnershipError:raise
            except Exception:raise OwnershipError('Scheduler placement observation unavailable') from None
        except OwnershipError:raise
        except Exception:raise OwnershipError('Scheduler placement unavailable') from None
        return self.arn(request)

    def remove(self,state):
        request=self.request(state)
        try:
            value=self.scheduler.get_schedule(Name=request['Name'],GroupName=request['GroupName'])
            self.checked(request,value)
            self.scheduler.delete_schedule(Name=request['Name'],GroupName=request['GroupName'],
                ClientToken=digest('command',dict(action='remove',request=request)))
        except ClientError as error:
            if error.response.get('Error',{}).get('Code')!='ResourceNotFoundException':raise OwnershipError('Scheduler cleanup unavailable') from None
        except OwnershipError:raise
        except Exception:raise OwnershipError('Scheduler cleanup unavailable') from None

    async def start_driver(self,definition,*,history_limit=128):
        state=self.durable.driver_state(definition,history_limit=history_limit)
        self.request(state)
        # Start/signal the original durable workflow first. A placement failure
        # remains repairable from its existing committed definition intent.
        run=await self.durable.start_driver(definition,history_limit=history_limit)
        await asyncio.to_thread(self.ensure,state)
        return run

    async def start_task(self,launch):return await self.durable.start_task(launch)

    async def wake(self,activities,event):
        if type(event) is not dict or set(event)!={'driver'}:raise OSErrorCode('INVALID')
        state=event['driver'];validate_contract('ScheduleDriverState',state)
        self.request(state)  # Installation/profile validation before SQL.
        if state['installationId']!=str(activities.service.runtime.registry.installation_id):raise OSErrorCode('DENIED')
        definition=await asyncio.to_thread(activities.definition,state)
        await activities.dispatch(state['definitionId'])
        closed=definition['state'] in {'removed','revoked','retired'}
        if closed:await asyncio.to_thread(self.remove,state)
        else:
            # Only a wake hint: the original workflow performs its normal
            # current-authority and SQL slot checks before any new admission.
            await self.durable.start_driver(dict(id=state['definitionId'],subject=dict(
                installationId=state['installationId'],applicationId=state['applicationId'])),history_limit=state['historyLimit'])
        return dict(closed=closed)
