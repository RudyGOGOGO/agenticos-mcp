#!/usr/bin/env python3
"""Fresh RDS database/role preparation only. No existing object adoption or migration.

Default is a read-only prerequisite check. Credentials are private file paths;
no values or connection strings are printed. Product CLI owns immutable DDL.
"""
import argparse
import json
from pathlib import Path
import re


def initialize(args):
    import psycopg
    from psycopg import sql
    from agentic_os.adapters.postgres.profiles import checked_profile,vector_version
    profile=checked_profile(args.storage_profile)
    version=vector_version(profile)
    from agentic_os.adapters.local.files import private_read
    from agentic_os.adapters.local.ownership import load_manifest
    from agentic_os.adapters.local.operator import verify_operator
    from agentic_os.adapters.local import recovery_gate as gate
    if args.component not in {'agenticos','temporal'}:raise ValueError('Explicit database component required')
    manifest=load_manifest(args.manifest)
    token=private_read(args.operator_key,32)
    def guard():
        verify_operator(args.manifest,token)
        current=load_manifest(args.manifest);state=gate.state(args.manifest)
        if current!=manifest or current['profile']!='aws-eks/1' or state['mode']!='PARKED' or state['generation']!=1:
            raise ValueError('Fresh generation-one parked AWS installation required')
    guard()
    config=json.loads(private_read(args.credentials,65536))
    if set(config)!={'host','admin_user','admin_password_file','ca','password_files'} or re.fullmatch(
            r'[a-z0-9-]+\.[a-z0-9-]+\.[a-z0-9-]+\.rds\.amazonaws\.com',config['host']) is None:
        raise ValueError('Explicit private RDS credentials required')
    components=('control','retrieval','knowledge') if args.component=='agenticos' else ('temporal','visibility')
    names={name:('aos_'+manifest['installationId'].replace('-','')+'_'+name if args.component=='agenticos'
        else 'temporal_'+('workflows' if name=='temporal' else 'visibility')) for name in components}
    roles={name:([database+'_m',database+'_r']+([database+'_r_public'] if name=='knowledge' else [])
        if args.component=='agenticos' else [database]) for name,database in names.items()}
    all_roles=[role for values in roles.values() for role in values]
    if set(config['password_files'])!=set(all_roles):raise ValueError('Exact separate role/password-file map required')
    passwords={role:private_read(Path(config['password_files'][role]),256).decode('ascii') for role in all_roles}
    if any(not 32<=len(value)<=256 for value in passwords.values()) or len(set(passwords.values()))!=len(passwords):
        raise ValueError('Separate strong role credentials required')
    options=dict(host=config['host'],user=config['admin_user'],password=private_read(Path(config['admin_password_file']),256).decode('ascii'),
        sslmode='verify-full',sslrootcert=str(Path(config['ca'])),connect_timeout=5,
        options='-c lock_timeout=2s -c statement_timeout=3s')
    with psycopg.connect(**options,dbname='postgres',autocommit=True) as admin:
        if not admin.pgconn.ssl_in_use or admin.execute("SELECT current_setting('server_version_num')").fetchone()!=('160015',):
            raise ValueError('Exact TLS PostgreSQL16.15 required')
        if args.component=='agenticos' and not admin.execute("SELECT 1 FROM pg_available_extension_versions WHERE name='vector' AND version=%s",(version,)).fetchone():
            raise ValueError('Selected explicit storage profile extension unavailable; no databases or roles changed.')
        if admin.execute('SELECT 1 FROM pg_database WHERE datname=ANY(%s)',(list(names.values()),)).fetchone() or admin.execute(
                'SELECT 1 FROM pg_roles WHERE rolname=ANY(%s)',(all_roles,)).fetchone():raise ValueError('Existing database/role detected; adoption refused')
        if not args.apply:return dict(state='fresh-prerequisites-pass-no-mutation',databases=list(names.values()))
        # CREATE DATABASE is non-transactional. Every prerequisite was checked;
        # failure leaves exact resources for operator review, never auto-drop.
        for role in all_roles:
            guard()
            admin.execute(sql.SQL('CREATE ROLE {} LOGIN PASSWORD {} NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS').format(sql.Identifier(role),sql.Literal(passwords[role])))
        for name,database in names.items():
            guard()
            owner=roles[name][0];admin.execute(sql.SQL('CREATE DATABASE {} OWNER {}').format(sql.Identifier(database),sql.Identifier(owner)))
            admin.execute(sql.SQL('REVOKE ALL ON DATABASE {} FROM PUBLIC').format(sql.Identifier(database)))
            admin.execute(sql.SQL('GRANT CONNECT ON DATABASE {} TO {}').format(sql.Identifier(database),sql.SQL(',').join(map(sql.Identifier,roles[name]))))
        if args.component=='agenticos':
            admin.execute(sql.SQL('ALTER ROLE {} IN DATABASE {} SET default_transaction_read_only=on').format(sql.Identifier(names['knowledge']+'_r_public'),sql.Identifier(names['knowledge'])))
    for name,database in names.items():
        guard()
        with psycopg.connect(**options,dbname=database,autocommit=True) as db:
            db.execute('REVOKE ALL ON SCHEMA public FROM PUBLIC')
            db.execute(sql.SQL('GRANT USAGE,CREATE ON SCHEMA public TO {}').format(sql.Identifier(roles[name][0])))
            for role in roles[name][1:]:db.execute(sql.SQL('GRANT USAGE ON SCHEMA public TO {}').format(sql.Identifier(role)))
            if args.component=='agenticos':
                if name in {'retrieval','knowledge'}:db.execute(sql.SQL('CREATE EXTENSION vector VERSION {}').format(sql.Literal(version)))
                db.execute(sql.SQL('ALTER DEFAULT PRIVILEGES FOR ROLE {} IN SCHEMA public GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO {}').format(sql.Identifier(roles[name][0]),sql.Identifier(database+'_r')))
    guard()
    return dict(state='fresh-roles-databases-prepared',migrationsApplied=False,runtimeReady=False)


def main(argv=None):
    from agentic_os.adapters.postgres.profiles import RDS_EXACT,LEGACY_RDS
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--component',choices=['agenticos','temporal'],required=True)
    for key in ('manifest','operator-key','credentials'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--storage-profile',choices=[RDS_EXACT,LEGACY_RDS],default=RDS_EXACT,
        help='Explicit component catalog/extension contract; no automatic fallback')
    p.add_argument('--apply',action='store_true');args=p.parse_args(argv)
    try:print(json.dumps(initialize(args)))
    except ValueError as error:p.exit(1,str(error)+'\n')
    except Exception:p.exit(1,'Database preparation failed; preserve partial resources and inspect private diagnostics. No automatic cleanup.\n')
