"""Admit a separately provisioned managed target to the shared held recovery.

This operator adapter creates no cloud resources and writes no restored SQL.
Exact source data/materials and supported history must reconcile before a held
binding is published. Privacy, quarantine and current release remain separate.
"""
import asyncio
from contextlib import contextmanager
from contextvars import ContextVar
import hashlib
from copy import deepcopy
from datetime import timedelta
from pathlib import Path
from uuid import UUID

from temporalio.api.workflowservice.v1 import DescribeNamespaceRequest

from agentic_os.adapters.configured_installation import closed,canonical_file
from agentic_os.adapters.local import coordinated_backup as backup,recovery_gate as gate
from agentic_os.adapters.local.files import OwnershipError,private_read,private_write,private_directory
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.resources import read_signed,write_signed,file_lock,tree_inventory
from agentic_os.adapters.local.recovery_runtime_checkpoint import runtime_checkpoint,assert_release_compatible
from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from . import bootstrap,coordinated_recovery as capture,recovery,storage,temporal,readiness

CONFIGURATION='aws-managed-cloud-recovery-target/1'
PROFILE='aws-managed-target-admission/1'
FILE='recovery-managed-target.json'
ROOT_FILE='managed-recovery-root.json'
_operator_cloud=ContextVar('managed_operator_cloud_replacement',default=None)
FIELDS={'profile','installationId','runId','configuration','configurationDigest','operatorContentDigest',
    'archiveDigest','captureDigest','priorGate','target','generation','state','receiptDigest','materialDigestsDigest','cloudDigest'}


def _archive(document):
    return capture.read_snapshot(canonical_file(document['archive']),canonical_file(document['recovery_key']))


def prepare_root(directory,recovery_key,*,root):
    """Prepare fresh ownership with the authenticated logical installation ID."""
    receipt,payload=capture.read_snapshot(Path(directory),Path(recovery_key))
    assert_release_compatible(payload['runtimeCheckpoint'])
    result=bootstrap._prepare_root(root,installation_id=receipt['prepared']['installationId'],history_keys=False)
    path=Path(result['manifest']);manifest=load_manifest(path)
    write_signed(path.parent/ROOT_FILE,dict(profile=PROFILE,installationId=manifest['installationId'],runId=manifest['runId'],
        sourceRunId=receipt['prepared']['sourceRunId'],archiveDigest=capture._sha(receipt),
        captureDigest=receipt['prepared']['captureDigest']),path.parent/'owner.key')
    return result|dict(profile=PROFILE,restorationSelected=True,privateKeysCreated=False)


def assert_preparing(path):
    """Keyless metadata reads belong only to this fresh held recovery leaf."""
    path=Path(path);manifest=load_manifest(path);value=read_signed(path.parent/ROOT_FILE,path.parent/'owner.key')
    try:
        closed(value,{'profile','installationId','runId','sourceRunId','archiveDigest','captureDigest'})
        state=gate.state(path)
        if (manifest['profile']!='aws-eks/1' or value['profile']!=PROFILE
                or (path.parent/ROOT_FILE).lstat().st_nlink!=1
                or any(value[k]!=manifest[k] for k in ('installationId','runId'))
                or type(value['sourceRunId']) is not str or len(value['sourceRunId'])!=12
                or any(c not in '0123456789abcdef' for c in value['sourceRunId']) or value['sourceRunId']==manifest['runId']
                or not all(backup._digest(value[k]) for k in ('archiveDigest','captureDigest'))
                or (state['generation'],state['mode'],state['reason']) not in {
                    (1,'PARKED','operator-park'),(2,'RESTORING','restore')}):raise ValueError()
    except Exception:raise OwnershipError('Fresh managed recovery preparation required') from None


def configuration(document):
    """Validate archive, logical identity, schema and all connection references."""
    try:
        closed(document,{'schema','stores','cloud_configuration','target','archive','recovery_key'})
        if document['schema']!=CONFIGURATION:raise ValueError()
        value=deepcopy(document);stores=storage.configuration(value['stores']);storage.plan(value['stores'])
        if any(stores['expected_heads'][n]!=storage.component_head(n,stores['installation']) for n in storage.COMPONENTS):raise ValueError()
        cloud=temporal.load_operator_configuration(canonical_file(value['cloud_configuration']))
        if cloud['installation']!=value['stores']['installation']:raise ValueError()
        path=stores['installation']['manifest'];manifest=load_manifest(path)
        if manifest['profile']!='aws-eks/1':raise ValueError()
        if any(canonical_file(value[k]).is_relative_to(path.parent) for k in ('archive','recovery_key')):raise ValueError()
        receipt,payload=_archive(value);source=receipt['prepared'];original=temporal.original_history(payload['cloudCapture'])
        selected=read_signed(path.parent/ROOT_FILE,path.parent/'owner.key')
        expected=dict(profile=PROFILE,installationId=manifest['installationId'],runId=manifest['runId'],
            sourceRunId=source['sourceRunId'],archiveDigest=capture._sha(receipt),captureDigest=source['captureDigest'])
        if (selected!=expected or manifest['installationId']!=source['installationId'] or manifest['runId']==source['sourceRunId']
                or cloud['run_id']!=original['data']['runId'] or cloud['namespace']!=original['namespace']
                or cloud['namespace_id']!=original['namespaceId'] or cloud['retention_days']!=original['retentionDays']):raise ValueError()
        closed(value['target'],capture.SOURCE_FIELDS)
        pin_values=dict(source['snapshot']);pin_values.update(value['target']);pin_values['installation_id']=UUID(manifest['installationId'])
        pin=recovery.SnapshotPin(**pin_values);aws=value['stores']['installation']['aws']
        if (aws['region']!=pin.region or aws['account']!=pin.account
                or pin.instance_id==source['snapshot']['instance_id'] or pin.resource_id==source['snapshot']['resource_id']
                or pin.kms_key_arn!=source['snapshot']['kms_key_arn'] or pin.engine_version!=source['snapshot']['engine_version']):raise ValueError()
        settings=[aws['postgres'],*aws['stores'].values()]
        if (any(v['host']!=settings[0]['host'] or v['port']!=pin.port for v in settings)
                or settings[0]['host']==receipt['source']['endpoint']):raise ValueError()
        assert_release_compatible(payload['runtimeCheckpoint'])
        return value,path,cloud,receipt,payload,pin
    except Exception:raise OwnershipError('Explicit managed target/archive/schema/history configuration required') from None


def load_configuration(path,*,admitted=False,maintenance_command=None):
    try:
        value=parse_canonical_json(private_read(canonical_file(str(path)),131072))
        if admitted:
            target=canonical_file(value['stores']['installation']['manifest'])
            from agentic_os.adapters.local.recovery_maintenance import cloud_configuration
            if value not in (cloud_configuration(target),cloud_configuration(target,command=maintenance_command)):raise ValueError()
        else:configuration(value)
        return value
    except Exception:raise OwnershipError('Managed target configuration unavailable') from None



def load_configuration_replacement(path,current,*,replacement_token=None):
    selected=parse_canonical_json(private_read(canonical_file(str(path)),131072))
    manifest=canonical_file(current['stores']['installation']['manifest'])
    from agentic_os.adapters.local.recovery_maintenance import cloud_configuration,operator_configuration
    published=cloud_configuration(manifest)
    operators=operator_configuration(manifest)
    if replacement_token is not None:
        from . import operator_rotation as credentials
        proposed=credentials.next_configuration(manifest,credentials.state(manifest),replacement_token,operators)
        return checked_operator_replacement(manifest,published,selected,proposed,previous=operators)
    check=checked_service_replacement if selected.get('stores')!=published['stores'] else checked_cloud_replacement
    return check(manifest,published,selected,operator_configuration=operators)


def load_cloud_replacement(path,current):
    """A reviewed current transport change does not reopen the offline archive."""
    selected=parse_canonical_json(private_read(canonical_file(str(path)),131072))
    manifest=canonical_file(current['stores']['installation']['manifest'])
    from agentic_os.adapters.local.recovery_maintenance import operator_configuration
    return checked_cloud_replacement(manifest,current,selected,operator_configuration=operator_configuration(manifest))


def _inspection(document,receipt):
    aws=document['stores']['installation']['aws'];snapshot=dict(receipt['prepared']['snapshot'])
    for key in ('installation_id','region','account'):snapshot.pop(key)
    return dict(schema=recovery.CONFIGURATION,manifest=document['stores']['installation']['manifest'],region=aws['region'],
        account=aws['account'],token_root=aws['token_root'],operator=aws['operator'],snapshot=snapshot)


def plan(document,*,expected_generation):
    document,path,_,receipt,_,pin=configuration(document)
    if type(expected_generation) is not int or expected_generation!=1:raise OwnershipError('Fresh target generation required')
    value=recovery.plan(_inspection(document,receipt))
    value['permissions']['Statement'].append(recovery.source_permissions(pin))
    return dict(profile=PROFILE,state='PLANNED',roleArn=value['roleArn'],permissions=value['permissions'],
        snapshotArn=pin.arn,runtimeReady=False,billableActions=[],awsResourcesCreated=False,
        prerequisites=['Separately provisioned installation-owned encrypted private target with exact snapshot/capture tags',
            'Exact current source rows/schema, protected material and original Cloud history',
            'Admission stays held; surviving privacy, quarantine and current-code release remain mandatory'])


def _record(path):
    value=read_signed(path.parent/FILE,path.parent/'owner.key',maximum=256*1024)
    try:
        closed(value,FIELDS);manifest=load_manifest(path)
        if (path.parent/FILE).lstat().st_nlink!=1:raise ValueError()
        if (value['profile']!=PROFILE or any(value[k]!=manifest[k] for k in ('installationId','runId'))
                or value['state'] not in {'PENDING','ADMITTED'} or value['configurationDigest']!=capture._sha(value['configuration'])
                or any(not backup._digest(value[k]) for k in ('archiveDigest','captureDigest','operatorContentDigest','receiptDigest','materialDigestsDigest','cloudDigest'))
                or value['cloudDigest']!=capture._sha(temporal.load_operator_configuration(Path(value['configuration']['cloud_configuration'])))
                or type(value['generation']) is not int or value['generation']!=3
                or value['generation']!=value['priorGate']['generation']+2):raise ValueError()
        closed(value['priorGate'],gate.FIELDS)
        if (type(value['priorGate']['generation']) is not int or value['priorGate']['generation']!=1
                or value['priorGate']['mode']!='PARKED'
                or any(value['priorGate'][k]!=manifest[k] for k in ('installationId','runId'))
                or value['configuration']['stores']['installation']['manifest']!=str(path)):raise ValueError()
    except Exception:raise OwnershipError('Original managed target operation unavailable') from None
    return value


def target_binding(path):
    """Signed provider identity for shared held readers; no SQL/runtime grant."""
    path=Path(path);record=_record(path)
    if record['state']!='ADMITTED':raise OwnershipError('Managed target admission incomplete')
    return dict(instanceArn=record['target']['instanceArn'],resourceId=record['target']['resourceId'],
        configurationDigest=record['configurationDigest'],snapshotArn=record['target']['snapshotArn'],captureDigest=record['captureDigest'])


def assert_restoration(path,value):
    record=_record(Path(path))
    if (value['managedTarget']!=target_binding(path) or value['receiptDigest']!=record['receiptDigest']
            or capture._sha(value['materialDigests'])!=record['materialDigestsDigest']):
        raise OwnershipError('Original admitted managed source facts changed')


def configuration_certificate(path,digest):
    """Current authenticated adapter bindings; grants no runtime release."""
    path=Path(path);record=_record(path)
    from agentic_os.adapters.local.recovery_maintenance import cloud_configuration
    selected=cloud_configuration(path)
    expected=readiness.installation_digest(selected['stores']['installation'])
    if record['state']!='ADMITTED' or type(digest) is not str or digest!=expected:
        raise OwnershipError('Current managed release configuration differs')
    cloud=temporal.load_operator_configuration(Path(selected['cloud_configuration']))
    return dict(installationId=record['installationId'],installationDigest=expected,
        configurationDigest=record['configurationDigest'],cloudDigest=capture._sha(cloud),cloud=readiness._cloud_pin(cloud))


def certificate(path,digest):
    """Reuse the shared certified release through the existing AWS guard."""
    from agentic_os.adapters.local.recovery_ready import certificate as released
    binding=configuration_certificate(path,digest)
    return released(Path(path))|dict(installationDigest=binding['installationDigest'],cloud=binding['cloud'])


def reviewed_cloud(connection,*,operator=False):
    """Exact operator-reviewed current transport; logical history stays original."""
    record=_record(connection.installation.root/'manifest.json')
    from agentic_os.adapters.local.recovery_maintenance import cloud_configuration
    path=connection.installation.root/'manifest.json'
    selected=cloud_configuration(path)
    if operator:
        from agentic_os.adapters.local.recovery_operator import configured_cloud_document
        active=configured_cloud_document(path)
        if active is not None:selected=active
    proposed=_operator_cloud.get()
    if operator and proposed is not None and proposed['path']==path:
        from agentic_os.adapters.local.recovery_operator import _scope
        scope=_scope(path)
        if scope['operator'](proposed['token'])!=scope['operatorIdentity']:
            raise OwnershipError('Current Cloud rollover operator changed')
        selected=proposed['document']
    document=temporal.load_operator_configuration(Path(selected['cloud_configuration']))
    pin=readiness._cloud_pin(document)
    if (record['state']!='ADMITTED' or type(connection.identity) is not temporal.AWSCloudTemporalIdentity
            or connection.identity.pin.arn!=pin['identityArn'] or connection.identity.pin.version!=pin['identityVersion']
            or connection.namespace!=pin['namespace'] or connection.cloud.namespace_id!=pin['namespaceId']
            or connection.cloud.retention_days!=pin['retentionDays'] or connection.host!=pin['endpoint']
            or connection.server_ca_sha256!=pin['serverCASha256'] or connection.run_id!=pin['runId']):
        raise OwnershipError('Reviewed managed Cloud transport changed')
    return True



@contextmanager
def operator_cloud_replacement(path,token,current,replacement):
    """An exact scoped operator may inspect a proposal, never activate runtime."""
    from agentic_os.adapters.local.recovery_operator import _scope
    from agentic_os.adapters.local.recovery_maintenance import cloud_configuration,operator_configuration
    path=Path(path);verify_operator(path,token);scope=_scope(path)
    if (_operator_cloud.get() is not None or cloud_configuration(path)!=current
            or scope['operator'](token)!=scope['operatorIdentity']):
        raise OwnershipError('Exact un-nested current Cloud rollover operator required')
    checked_cloud_replacement(path,current,replacement,operator_configuration=operator_configuration(path))
    selected=_operator_cloud.set(dict(path=path,token=token,document=deepcopy(replacement)))
    try:
        yield
        if scope['operator'](token)!=scope['operatorIdentity']:raise OwnershipError('Cloud rollover operator changed')
    finally:_operator_cloud.reset(selected)


def checked_cloud_replacement(path,current,replacement,*,operator_configuration=None):
    """Validate a proposed transport change; grant no release or connection.

    The admitted archive/target/store configuration remains immutable. Reuse
    the existing service-renewal comparison for Cloud identity and TLS only;
    publication still belongs to the finite managed maintenance operation.
    """
    path=Path(path);record=_record(path)
    reference=record['configuration']
    if (record['state']!='ADMITTED' or type(current) is not dict or set(current)!=set(reference)
            or any(current[k]!=reference[k] for k in reference if k not in {'stores','cloud_configuration'})):
        raise OwnershipError('Exact admitted managed target and store configuration required')
    if current['stores']!=reference['stores']:_checked_service_document(reference,current,metadata_only=True,operator_configuration=operator_configuration)
    if (type(replacement) is not dict or set(replacement)!=set(current)
            or any(replacement[k]!=current[k] for k in current if k!='cloud_configuration')
            or replacement['cloud_configuration']==current['cloud_configuration']):
        raise OwnershipError('Cloud rollover cannot change managed target or store ownership')
    old=temporal.load_operator_configuration(Path(current['cloud_configuration']))
    new=temporal.load_operator_configuration(Path(replacement['cloud_configuration']))
    from .renewal import _service_context
    digest=readiness.installation_digest(current['stores']['installation'])
    _service_context(dict(cloudConfiguration=reference['cloud_configuration']),dict(
        installationDigest=digest,cloudConfiguration=current['cloud_configuration'],
        cloudDigest=capture._sha(old),cloud=readiness._cloud_pin(old)))
    _service_context(dict(cloudConfiguration=current['cloud_configuration']),dict(
        installationDigest=digest,cloudConfiguration=replacement['cloud_configuration'],
        cloudDigest=capture._sha(new),cloud=readiness._cloud_pin(new)))
    if new['installation']!=old['installation'] or new['identity']['pin']['version']==old['identity']['pin']['version']:
        raise OwnershipError('Reviewed replacement needs a new immutable Cloud credential version')
    for cloud in (old,new):
        if hashlib.sha256(private_read(Path(cloud['server_ca']),65536)).hexdigest()!=cloud['server_ca_sha256']:
            raise OwnershipError('Reviewed Cloud CA content differs')
    return deepcopy(replacement)


def _readiness_document(value):
    return dict(schema=readiness.CONFIGURATION,stores=value['stores'],cloud_configuration=value['cloud_configuration'],release_seconds=86400)


def _checked_service_document(reference,value,*,metadata_only=False,operator_configuration=None):
    """Reuse the existing full store/schema and logical service comparator."""
    from .renewal import _service_context,_checked_service_documents
    if operator_configuration is not None:
        from .operator_rotation import checked_configuration
        checked_configuration(canonical_file(reference['stores']['installation']['manifest']),operator_configuration)
    admitted=temporal.load_operator_configuration(Path(reference['cloud_configuration']))
    original_run_id=admitted['run_id']
    if metadata_only:
        # Signed ancestry compares immutable reviewed DTOs; repeated live
        # schema planning belongs to preparation/release, not each read.
        from .storage import configuration as store_configuration
        store_configuration(value['stores'],_head_reference=reference['stores']['expected_heads']);old=admitted
        cloud=temporal.load_operator_configuration(Path(value['cloud_configuration']))
        if cloud['installation']!=value['stores']['installation'] or cloud['run_id']!=original_run_id:
            raise OwnershipError('Reviewed restored service installation or original data run differs')
        aws=value['stores']['installation']['aws']
        for settings in [aws['postgres'],*aws['stores'].values()]:
            if hashlib.sha256(private_read(Path(settings['ca']),65536)).hexdigest()!=settings['ca_sha256']:
                raise OwnershipError('Reviewed SQL CA content differs')
        if hashlib.sha256(private_read(Path(cloud['server_ca']),65536)).hexdigest()!=cloud['server_ca_sha256']:
            raise OwnershipError('Reviewed Cloud CA content differs')
    else:
        _,old,_=readiness.configuration(_readiness_document(reference),expected_run_id=original_run_id)
        _,cloud,_=readiness.configuration(_readiness_document(value),expected_run_id=original_run_id)
    before=dict(installationDigest=readiness.installation_digest(reference['stores']['installation']),
        cloudConfiguration=reference['cloud_configuration'],cloudDigest=capture._sha(old),cloud=readiness._cloud_pin(old))
    _service_context(before,dict(installationDigest=readiness.installation_digest(value['stores']['installation']),
        cloudConfiguration=value['cloud_configuration'],cloudDigest=capture._sha(cloud),cloud=readiness._cloud_pin(cloud)),operator_configuration)
    # The restored ancestry's initial/current operator pair is validated above;
    # this comparator owns unchanged schemas and migrator/secret ownership.
    _checked_service_documents(_readiness_document(reference),_readiness_document(value),before,
        original_run_id=original_run_id,validated_cloud=old)
    if operator_configuration is None and value['stores']['installation']['aws']['operator']!=reference['stores']['installation']['aws']['operator']:
        raise OwnershipError('SQL service selection cannot change the operator credential')
    return cloud


def checked_service_replacement(path,current,replacement,*,metadata_only=False,operator_configuration=None):
    """Select immutable SQL service pins; keep all resource/operator ownership."""
    reference=_record(Path(path))['configuration']
    for value in (current,replacement):
        if (type(value) is not dict or set(value)!=set(reference)
                or any(value[k]!=reference[k] for k in reference if k not in {'stores','cloud_configuration'})):
            raise OwnershipError('SQL service rollover cannot change managed target ownership')
    old=_checked_service_document(reference,current,metadata_only=metadata_only,operator_configuration=operator_configuration)
    new=_checked_service_document(reference,replacement,metadata_only=metadata_only,operator_configuration=operator_configuration)
    if current['stores']['installation']['aws']['operator']!=replacement['stores']['installation']['aws']['operator']:
        raise OwnershipError('SQL service selection cannot change the operator credential')
    if (current['stores']==replacement['stores'] or current['cloud_configuration']==replacement['cloud_configuration']
            or {k:v for k,v in old.items() if k!='installation'}!={k:v for k,v in new.items() if k!='installation'}):
        raise OwnershipError('SQL service rollover needs distinct store pins and unchanged Cloud transport')
    return deepcopy(replacement)


def checked_operator_replacement(path,current,replacement,operators,*,previous=None,metadata_only=False):
    """Only a reviewed operator generation/version changes; SQL/Cloud stay exact."""
    from . import operator_rotation as credentials
    path=Path(path);reference=_record(path)['configuration']
    credentials.checked_configuration(path,operators)
    if previous is not None:credentials.checked_configuration(path,previous)
    for value in (current,replacement):
        if (type(value) is not dict or set(value)!=set(reference)
                or any(value[k]!=reference[k] for k in reference if k not in {'stores','cloud_configuration'})):
            raise OwnershipError('Operator rollover cannot change managed target ownership')
    old=_checked_service_document(reference,current,metadata_only=metadata_only,operator_configuration=previous)
    new=_checked_service_document(reference,replacement,metadata_only=metadata_only,operator_configuration=operators)
    before=current['stores']['installation']['aws']['operator'];after=replacement['stores']['installation']['aws']['operator']
    old_stores=deepcopy(current['stores']);new_stores=deepcopy(replacement['stores'])
    old_stores['installation']['aws'].pop('operator');new_stores['installation']['aws'].pop('operator')
    if (old_stores!=new_stores or after['generation']!=before['generation']+1 or after['pin']['arn']!=before['pin']['arn']
            or after['pin']['version']==before['pin']['version'] or current['cloud_configuration']==replacement['cloud_configuration']
            or {k:v for k,v in old.items() if k!='installation'}!={k:v for k,v in new.items() if k!='installation'}
            or (previous is not None and operators['initial']!=previous['initial'])):
        raise OwnershipError('Exact next operator secret generation and unchanged SQL/Cloud required')
    return deepcopy(replacement)


def restoration_receipt(receipt,payload):
    """Existing recovery facts, explicitly selecting three managed OS stores."""
    prepared=receipt['prepared']
    return dict(profile=backup.MANAGED_PROFILE,id=prepared['id'],installationId=prepared['installationId'],
        sourceRunId=prepared['sourceRunId'],sourceGate=payload['sourceGate'],runtimeCheckpoint=payload['runtimeCheckpoint'],
        components={name:dict(before=value,after=value) for name,value in payload['components'].items()},
        journalCheckpoints=payload['journalCheckpoints'],controlsCheckpoints=payload['controlsCheckpoints'],managedSource=receipt)


async def _history(cloud,token,generation,payload):
    from agentic_os.adapters.local.recovery_temporal import _history_catalog,verify_cloud_history_prefix,INSPECTION_SECONDS
    original=temporal.original_history(payload['cloudCapture'])
    with temporal.configured_operator_connection(cloud,preparing_recovery=True) as connection:
        await temporal.operator_readiness(connection,token,expected_generation=generation)
        async with asyncio.timeout(INSPECTION_SECONDS):
            client=await connection.connect()
            records=await _history_catalog(client,connection.binding,original,payload['runtimeCheckpoint'],required=original['requiredWorkflows'])
            await verify_cloud_history_prefix(client,original,records)
            connection.cloud.verify(await client.workflow_service.describe_namespace(DescribeNamespaceRequest(namespace=connection.namespace),timeout=timedelta(seconds=5)))
        if runtime_checkpoint(connection.installation.root/'manifest.json',installation=connection.installation)!=payload['runtimeCheckpoint']:
            raise OwnershipError('Managed target runtime differs from captured source')


def _current(path,token,prior,record=None):
    verify_operator(path,token);current=gate.state(path)
    allowed=(prior,) if record is None else (prior,prior|dict(generation=prior['generation']+1,mode='RESTORING',reason='restore'),
        prior|dict(generation=prior['generation']+2,mode='BLOCKED',reason='reconciliation-required'))
    if not any(all(current[k]==value[k] for k in gate.FIELDS-{'changedAt'}) for value in allowed):
        raise OwnershipError('Original managed target gate differs')
    return current


def _result(path,record):
    return dict(profile=PROFILE,state='BLOCKED',manifest=str(path),generation=record['generation'],
        snapshotId=record['configuration']['archive'].rsplit('/',1)[-1],runtimeReady=False,
        privacyReconciled=False,cloudHistoryQuarantined=False,productionQualified=False,enabledLanes=[])


async def admit(document,token,*,expected_generation,capacity_root=None):
    document,path,cloud,receipt,payload,pin=configuration(document);verify_operator(path,token)
    if type(expected_generation) is not int or expected_generation!=1:raise OwnershipError('Fresh managed target generation required')
    material=backup._validated_material(canonical_bytes(payload['files']))
    from agentic_os.adapters.local.restoration_binding import publish_restoration,load_restoration
    with backup._admission(path,capacity_root=capacity_root,restoring=True):
        record=_record(path) if (path.parent/FILE).exists() or (path.parent/FILE).is_symlink() else None
        if record is not None:
            if (record['configuration']!=document or record['archiveDigest']!=capture._sha(receipt)
                    or record['captureDigest']!=receipt['prepared']['captureDigest']):raise OwnershipError('Exact original managed target retry required')
            prior=record['priorGate'];_current(path,token,prior,record)
            if record['state']=='ADMITTED':
                if not (path.parent/'recovery-snapshot.json').exists():publish_restoration(path,restoration_receipt(receipt,payload),record['generation'],material,managed_target=target_binding(path))
                load_restoration(path);return _result(path,record)
        else:
            prior=gate.state(path)
            if prior['generation']!=1 or prior['mode']!='PARKED':raise OwnershipError('Fresh parked managed target required')
            for name in backup.FILE_ROOTS:
                if (path.parent/name).exists() and tree_inventory(path.parent/name,maximum=backup.MAX_FILES)['files']:
                    raise OwnershipError('Empty target private material required')
        # All external identity/data/schema/history prerequisites precede material mutation.
        with recovery.configured_inspector(_inspection(document,receipt)) as (client,source_pin,operator):
            identity=operator(token);snapshot=recovery.inspect_snapshot(client,source_pin)
            if snapshot!=receipt['snapshot']:raise OwnershipError('Original managed snapshot changed')
            target=recovery.inspect_target(client,pin,document['stores']['installation']['aws']['postgres']['host'],snapshot=snapshot)
            if operator(token)!=identity:raise OwnershipError('Managed target operator changed')
        if record is not None and record['target']!=target:raise OwnershipError('Original managed target identity changed')
        with storage.configured_storage(document['stores']) as (stores,operator):
            identity=operator(token)
            for name in storage.COMPONENTS:
                check=operator.checkpoint(token)
                storage.prepare_component(stores[name],expected_head=document['stores']['expected_heads'][name],check_only=True,
                    operator_check=check,
                    file_check=lambda:_current(path,token,prior,record))
            if operator(token)!=identity:raise OwnershipError('Managed target operator changed')
        with capture._stores(dict(current=dict(stores=document['stores'])),token) as connections:
            capture._same_rows(payload['components'],capture._watermarks(path,connections))
        await _history(cloud,token,_current(path,token,prior,record)['generation'],payload)
        with file_lock(path.parent/'recovery-gate.lock',timeout=2):
            _current(path,token,prior,record)
            if record is None:
                record=dict(profile=PROFILE,installationId=load_manifest(path)['installationId'],runId=load_manifest(path)['runId'],
                    configuration=document,configurationDigest=capture._sha(document),operatorContentDigest=readiness._runtime_content(),
                    archiveDigest=capture._sha(receipt),captureDigest=receipt['prepared']['captureDigest'],priorGate=prior,
                    target=target,generation=3,state='PENDING',cloudDigest=capture._sha(cloud),
                    receiptDigest=capture._sha(restoration_receipt(receipt,payload)),
                    materialDigestsDigest=capture._sha({name:hashlib.sha256(raw).hexdigest() for name,raw in material.items()}))
                write_signed(path.parent/FILE,record,path.parent/'owner.key')
            if gate.state(path)['generation']==1:gate._write(path,mode='RESTORING',reason='restore')
            for name,content in material.items():
                destination=path.parent/name
                for parent in reversed(destination.parents):
                    if parent.is_relative_to(path.parent) and not parent.exists():private_directory(parent)
                if destination.exists() or destination.is_symlink():
                    if private_read(destination,backup.MAX_FILES)!=content:raise OwnershipError('Tracked target material differs')
                else:private_write(destination,content)
            from agentic_os.adapters.local.recovery_metadata import FILE as METADATA
            if backup._files(path.parent,metadata=material[METADATA])!=payload['files']:
                raise OwnershipError('Managed target private material differs')
            with capture._stores(dict(current=dict(stores=document['stores'])),token) as connections:
                capture._same_rows(payload['components'],capture._watermarks(path,connections))
            if gate.state(path)['generation']==2:gate._write(path,mode='BLOCKED',reason='reconciliation-required')
            record['state']='ADMITTED';write_signed(path.parent/FILE,record,path.parent/'owner.key')
            publish_restoration(path,restoration_receipt(receipt,payload),record['generation'],material,managed_target=target_binding(path))
        return _result(path,record)
