"""Explicit initial OS schema preparation over separately pinned RDS roles.

Uses the packaged Alembic lineage and existing catalog/privilege checks. No RDS
provisioning, role/database creation, populated upgrade or runtime activation.
"""
from contextlib import contextmanager
from pathlib import Path
import hashlib
import re
from uuid import UUID

from alembic import command
from sqlalchemy import create_engine
from sqlalchemy.pool import NullPool

from agentic_os.adapters.configured_installation import closed,installation_configuration
from agentic_os.adapters.local.files import OwnershipError,private_read
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.resources import file_lock
from agentic_os.adapters.local import recovery_gate as gate
from agentic_os.adapters.postgres.migrate import (migration_config,migration_head,
    assert_control_checks,protected_metadata_permissions)
from agentic_os.contracts.canonical import parse_canonical_json
from .backend import (AWSSecrets,AWSOperator,RDSMigrator,SecretPin,secrets_client,
    check_control_namespace,check_component_namespace)
from .workload import AWSWebIdentitySession,role_arn

CONFIGURATION='aws-initial-store-preparation/1'
COMPONENTS=('control','retrieval','knowledge')


def component_head(component,installation):
    from agentic_os.adapters.postgres.profiles import LEGACY_RDS,migration_profile
    profile=migration_profile(installation['aws'].get('storage_profile',LEGACY_RDS))
    return migration_head(component,storage_profile=profile) if profile is not None else migration_head(component)


def configuration(document,*,_head_reference=None):
    try:
        closed(document,{'schema','installation','migrators','expected_heads'})
        if document['schema']!=CONFIGURATION:raise ValueError()
        installation=installation_configuration(document['installation'])
        if (installation['provider']!='aws-eks' or installation['aws']['role']!='core'
                or 'stores' not in installation['aws']):raise ValueError()
        closed(document['migrators'],COMPONENTS);closed(document['expected_heads'],COMPONENTS)
        if _head_reference is not None:
            # Only authenticated restored ancestry supplies the already
            # admitted schema contract. Live preparation still derives the
            # packaged heads and checks the actual populated catalogs.
            closed(_head_reference,COMPONENTS)
            if document['expected_heads']!=_head_reference:raise ValueError()
        migrators={}
        for component in COMPONENTS:
            pin=document['migrators'][component];closed(pin,{'arn','version'})
            migrators[component]=SecretPin(**pin)
            expected=document['expected_heads'][component]
            if (expected is not None and (type(expected) is not str or not 1<=len(expected)<=64
                    or _head_reference is None and expected!=component_head(component,installation))):raise ValueError()
        runtime=installation['aws'];pins=[runtime['postgres']['password'],runtime['operator']['pin'],
            *(store['password'] for store in runtime['stores'].values()),*migrators.values()]
        if len({(p.arn,p.version) for p in pins})!=len(pins):raise ValueError()
        return dict(installation=installation,migrators=migrators,expected_heads=dict(document['expected_heads']))
    except Exception:raise OwnershipError('Invalid initial store preparation configuration') from None


def load_configuration(path):
    try:
        value=parse_canonical_json(private_read(Path(path),65536));configuration(value);return value
    except Exception:raise OwnershipError('Initial store preparation configuration unavailable') from None


def _settings(value,component):
    aws=value['installation']['aws']
    settings=dict(aws['postgres'] if component=='control' else aws['stores'][component])
    settings.pop('password');settings['user']=settings['database']+'_m'
    return settings


def plan(document):
    value=configuration(document);manifest=load_manifest(value['installation']['manifest'])
    if manifest['profile']!='aws-eks/1':raise OwnershipError('Fresh explicit AWS installation required')
    aws=value['installation']['aws'];ident=UUID(manifest['installationId'])
    prefix='arn:aws:secretsmanager:'+aws['region']+':'+aws['account']+':secret:agentic-os/'+str(ident)+'/'
    pins={component:[value['migrators'][component]] for component in COMPONENTS}
    pins['control'].append(aws['operator']['pin'])
    for component,items in pins.items():
        if any(not pin.arn.startswith(prefix+component+'/') for pin in items):
            raise OwnershipError('Initial store credential scope differs')
        settings=_settings(value,component);database='aos_'+ident.hex+'_'+component
        if (settings['database']!=database or settings['user']!=database+'_m'
                or re.fullmatch(r'[a-z0-9-]+\.[a-z0-9-]+\.'+re.escape(aws['region'])+r'\.rds\.amazonaws\.com',settings['host']) is None
                or hashlib.sha256(private_read(settings['ca'])).hexdigest()!=settings['ca_sha256']):
            raise OwnershipError('Explicit initial store namespace/TLS pin differs')
    targets=[('control','_r',aws['postgres']),*[(component,suffix,aws['stores'][name])
        for name,component,suffix in (('retrieval','retrieval','_r'),('knowledge','knowledge','_r'),
            ('knowledge_operator','knowledge','_m'),('knowledge_public','knowledge','_r_public'))]]
    for component,suffix,settings in targets:
        database='aos_'+ident.hex+'_'+component
        if (settings['database']!=database or settings['user']!=database+suffix
                or not settings['password'].arn.startswith(prefix+component+'/')
                or re.fullmatch(r'[a-z0-9-]+\.[a-z0-9-]+\.'+re.escape(aws['region'])+r'\.rds\.amazonaws\.com',settings['host']) is None
                or hashlib.sha256(private_read(settings['ca'])).hexdigest()!=settings['ca_sha256']):
            raise OwnershipError('Runtime store handoff differs from initial schema namespace')
    return dict(profile=CONFIGURATION,installationId=str(ident),
        roleArn=role_arn(ident,aws['account'],'storage'),
        permissions=dict(Version='2012-10-17',Statement=[dict(Effect='Allow',
            Action=['secretsmanager:GetSecretValue'],Resource=pin.arn,
            Condition={'StringEquals':{'secretsmanager:VersionId':pin.version}})
            for items in pins.values() for pin in items]),
        stores={name:dict(database='aos_'+ident.hex+'_'+name,migrator='aos_'+ident.hex+'_'+name+'_m',
            expectedHead=value['expected_heads'][name],targetHead=component_head(name,value['installation'])) for name in COMPONENTS},
        prerequisites=['Separately provisioned private TLS PostgreSQL16.15 databases and isolated roles',
            'No PUBLIC database/schema grants; exact selected storage profile extension/catalog on retrieval and knowledge',
            'Fresh empty schema for migration; populated/current schemas permit verification only'],
        runtimeReady=False,awsResourcesCreated=False)


@contextmanager
def configured_storage(document):
    value=configuration(document);selected=plan(document);installation=value['installation']
    aws=installation['aws'];ident=UUID(selected['installationId'])
    from agentic_os.adapters.kubernetes.projected_token import ProjectedTokenReader
    session=AWSWebIdentitySession(installation_id=ident,account=aws['account'],region=aws['region'],
        role='storage',token_provider=ProjectedTokenReader(aws['token_root']).read)
    try:
        secrets=AWSSecrets(secrets_client(session,aws['region']),region=aws['region'],account=aws['account'],installation_id=ident)
        from agentic_os.adapters.postgres.profiles import LEGACY_RDS
        stores={name:RDSMigrator(secrets,value['migrators'][name],component=name,
            storage_profile=aws.get('storage_profile',LEGACY_RDS),**_settings(value,name)) for name in COMPONENTS}
        yield stores,AWSOperator(secrets,aws['operator']['pin'],generation=aws['operator']['generation'])
    finally:session.close()


def _catalog(connection,component,installation,*,storage_profile=None):
    raw=connection.connection.driver_connection
    if component=='control':check_control_namespace(raw,installation);assert_control_checks(connection)
    else:
        from agentic_os.adapters.postgres.component_checks import assert_component_checks
        if storage_profile is None:check_component_namespace(raw,installation,component)
        else:check_component_namespace(raw,installation,component,storage_profile=storage_profile)
        from agentic_os.adapters.postgres.profiles import RDS_EXACT
        if storage_profile==RDS_EXACT:assert_component_checks(connection,component,storage_profile=RDS_EXACT)
        else:assert_component_checks(connection,component)


def _fresh(connection,component,*,storage_profile=None):
    # Validate prerequisites before running any packaged DDL. An empty-looking
    # Alembic table cannot authorize adoption of other schema objects.
    count=connection.exec_driver_sql("SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace "
        "WHERE n.nspname='public' AND c.relkind IN ('r','p','v','m','S','f')").scalar_one()
    functions=connection.exec_driver_sql("SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace "
        "WHERE n.nspname='public' AND NOT EXISTS (SELECT 1 FROM pg_depend d WHERE d.classid='pg_proc'::regclass "
        "AND d.objid=p.oid AND d.deptype='e')").scalar_one()
    schemas=connection.exec_driver_sql("SELECT count(*) FROM pg_namespace WHERE nspname NOT IN ('public','information_schema') "
        "AND left(nspname,3)<>'pg_'").scalar_one()
    extensions=connection.exec_driver_sql("SELECT extname,extversion FROM pg_extension WHERE extname<>'plpgsql'").all()
    public_schema=connection.exec_driver_sql("SELECT count(*) FROM pg_namespace n, LATERAL "
        "aclexplode(coalesce(n.nspacl,acldefault('n',n.nspowner))) a WHERE n.nspname='public' AND a.grantee=0").scalar_one()
    public_database=connection.exec_driver_sql("SELECT count(*) FROM pg_database d, LATERAL "
        "aclexplode(coalesce(d.datacl,acldefault('d',d.datdba))) a WHERE d.datname=current_database() AND a.grantee=0").scalar_one()
    from agentic_os.adapters.postgres.profiles import LEGACY_RDS,vector_version
    if (count or functions or schemas or public_schema or public_database
            or extensions!=([] if component=='control' else [('vector',vector_version(storage_profile or LEGACY_RDS))])):
        raise OwnershipError('Fresh isolated store or required extension/grants unavailable')


def prepare_component(connector,*,expected_head,operator_check,file_check,check_only=False):
    """One short-lock-bounded transaction; no network secret reads inside it."""
    if type(connector) is not RDSMigrator:raise OwnershipError('Separate pinned store migrator required')
    from agentic_os.adapters.postgres.profiles import migration_profile
    component=connector.component;profile=migration_profile(connector.storage_profile)
    target=migration_head(component,storage_profile=profile) if profile is not None else migration_head(component)
    if expected_head not in (None,target) or check_only and expected_head!=target:
        raise OwnershipError('Exact initial or current store head required')
    engine=create_engine('postgresql+psycopg://',poolclass=NullPool,creator=connector.connect)
    try:
        with engine.begin() as connection:
            connection.exec_driver_sql("SET LOCAL lock_timeout='2s'")
            connection.exec_driver_sql("SET LOCAL statement_timeout='3s'")
            connection.exec_driver_sql('SELECT pg_advisory_xact_lock(78109431)')
            present=connection.exec_driver_sql("SELECT to_regclass('public.alembic_version')").scalar_one()
            current=connection.exec_driver_sql('SELECT version_num FROM alembic_version').all() if present else []
            if current!=([ (expected_head,) ] if expected_head else []):
                raise OwnershipError('Store head differs; no automatic retry or adoption')
            config=(migration_config(component,storage_profile=profile) if profile is not None else migration_config(component))
            config.attributes.update(connection=connection,installation_id=connector.installation_id)
            if expected_head is None:
                if profile is None:_fresh(connection,component)
                else:_fresh(connection,component,storage_profile=connector.storage_profile)
                command.upgrade(config,'head')
                raw=connection.connection.driver_connection
                protected_metadata_permissions(raw,component=component,runtime=connector.database+'_r',migrator=connector.user)
                if component=='knowledge':
                    from psycopg import sql
                    raw.execute(sql.SQL('GRANT SELECT ON knowledge_public_metadata TO {}').format(sql.Identifier(connector.database+'_r_public')))
            if profile is None:_catalog(connection,component,connector.installation_id)
            else:_catalog(connection,component,connector.installation_id,storage_profile=connector.storage_profile)
            command.check(config)
            operator_check();file_check()
        return dict(component=component,head=target,action='migrated' if expected_head is None else 'verified')
    finally:engine.dispose()


def prepare_stores(document,token,*,expected_generation,check_only=False):
    value=configuration(document);plan(document);path=value['installation']['manifest']
    if check_only and any(value['expected_heads'][name]!=component_head(name,value['installation']) for name in COMPONENTS):
        raise OwnershipError('Verification requires all exact installed store heads')
    verify_operator(path,token)
    if type(expected_generation) is not int or expected_generation<1:raise OwnershipError('Exact parked generation required')
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        current=gate.state(path)
        if current['mode']!='PARKED' or current['generation']!=expected_generation:
            raise OwnershipError('Initial store operation requires current parked installation')
        def file_check():
            verify_operator(path,token)
            if gate.state(path)!=current:raise OwnershipError('Parked installation changed')
        with configured_storage(document) as (stores,operator):
            results=[]
            for name in COMPONENTS:
                file_check();check=operator.checkpoint(token)
                results.append(prepare_component(stores[name],expected_head=value['expected_heads'][name],
                    operator_check=check,file_check=file_check,check_only=check_only))
            operator(token);file_check()
    return dict(profile=CONFIGURATION,state='store-schemas-verified',stores=results,
        runtimeReady=False,cloudHistoryChecked=False,enabledLanes=[],awsResourcesCreated=False)


def provision_memory_controls(document,token,application_id,*,expected_generation,journal_root,capacity_root):
    return _provision_memory_journal(document,token,application_id,expected_generation=expected_generation,
        journal_root=journal_root,capacity_root=capacity_root,controls=True)


def provision_memory_recovery(document,token,application_id,*,expected_generation,journal_root,capacity_root):
    return _provision_memory_journal(document,token,application_id,expected_generation=expected_generation,
        journal_root=journal_root,capacity_root=capacity_root,controls=False)


def _provision_memory_journal(document,token,application_id,*,expected_generation,journal_root,capacity_root,controls):
    """Explicit journal genesis under the current certified operator release.

    Consent uses its existing separate control migrator. Deletion reuses the
    existing canonical RecoveryBinding operation and unchanged runtime grants.
    Neither operation adopts an existing profile or activates a runtime lane.
    """
    from agentic_os.adapters.configured_installation import configured_installation
    from agentic_os.adapters.postgres.store import ControlStore
    from agentic_os.registry.service import Registry
    from agentic_os.memory.recovery import RecoveryBinding
    from .readiness import certificate,installation_digest
    value=configuration(document);plan(document);installation=document['installation']
    if installation['aws'].get('control_profile')=='poc-direct-control/1':
        from agentic_os.adapters.poc.direct_readiness import certificate
    path=value['installation']['manifest'];verify_operator(path,token)
    if (type(expected_generation) is not int or expected_generation<1
            or any(value['expected_heads'][name]!=component_head(name,value['installation']) for name in COMPONENTS)):
        raise OwnershipError('Exact current generation and store heads required')
    digest=installation_digest(installation);original=certificate(path,digest)
    if original['generation']!=expected_generation:
        raise OwnershipError('Current consent provisioning generation differs')
    def file_check():
        verify_operator(path,token)
        if certificate(path,digest)!=original:
            raise OwnershipError('Consent provisioning release changed')
    with configured_storage(document) as (stores,operator), configured_installation(installation) as ports:
        ports.verify_operator(token);operator(token);file_check()
        prepare_component(stores['control'],expected_head=value['expected_heads']['control'],
            operator_check=operator.checkpoint(token),file_check=file_check,check_only=True)
        def connect():
            file_check();operator(token)
            connection=stores['control'].connect()
            try:
                check_control_namespace(connection,ports.installation_id)
                connection.rollback()
                return connection
            except BaseException:
                connection.close();raise
        store=ControlStore(path,installation_ports=ports)
        try:
            registry=Registry(path,store,installation_ports=ports,network='web-pki/1')
            binding=RecoveryBinding(registry,journal_root)
            if controls:
                result=binding.provision_controls(path,token,application_id,
                    capacity_root=capacity_root,control_connect=connect)
            else:
                from agentic_os.adapters.local.capacity import Capacity
                ledger=Capacity(Path(capacity_root))
                if ledger.root.stat().st_dev!=binding.root.stat().st_dev:
                    raise OwnershipError('Journal capacity must use the surviving journal volume')
                with ledger.reserve(32*1024**2,purpose='artifact'):
                    result=binding.provision(path,token,application_id)
            file_check();operator(token)
        finally:store.close()
    return result|dict(state='controls-provisioned' if controls else 'recovery-provisioned',
        enabledLanes=[],runtimeActivation=False,awsResourcesCreated=False)
