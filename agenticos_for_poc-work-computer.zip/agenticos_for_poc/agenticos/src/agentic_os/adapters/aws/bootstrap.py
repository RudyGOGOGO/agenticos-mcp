"""Explicit private AWS installation identity preparation, never activation."""
import os
from pathlib import Path
import secrets
from uuid import uuid4

from agentic_os.adapters.local.files import OwnershipError,private_directory,private_read,private_write
from agentic_os.adapters.local.resources import canonical_path,file_lock,read_signed,write_signed
from agentic_os.adapters.local.ownership import load_manifest,save_manifest


def prepare_root(root):
    """Prepare only a new caller-owned leaf; create no AWS/SQL resource.

    Initial schema, identity, storage and runtime readiness are separate gates.
    Normal startup cannot call this operation or mint another installation ID.
    """
    return _prepare_root(root,installation_id=str(uuid4()),history_keys=True)


def _prepare_root(root,*,installation_id,history_keys):
    """Shared private leaf preparation; recovery supplies authenticated identity."""
    from agentic_os.adapters.local.artifacts import checked_id
    installation_id=checked_id(installation_id)
    if type(history_keys) is not bool:raise OwnershipError('Explicit key preparation required')
    root=canonical_path(Path(root))
    if root.exists() or root.is_symlink():raise OwnershipError('New explicit AWS installation directory required')
    private_directory(root)
    for name in ('home','keys','artifacts','backups'):private_directory(root/name)
    private_write(root/'owner.key',secrets.token_bytes(32))
    run=uuid4().hex[:12]
    value=dict(version=2,profile='aws-eks/1',ownerUid=os.getuid(),root=str(root),
        installationId=installation_id,runId=run,project='aos-'+run,dockerEndpoint=None,postgres=None,databases={})
    save_manifest(root,value)
    from agentic_os.adapters.local.artifacts import LocalKeys
    from agentic_os.adapters.local.operator import issue_bootstrap
    from agentic_os.adapters.local import recovery_gate as gate
    if history_keys:LocalKeys(root/'keys').rotate()
    issue_bootstrap(root/'manifest.json')
    gate._write(root/'manifest.json',mode='PARKED',reason='operator-park')
    return dict(profile='aws-installation-preparation/1',state='PARKED',manifest=str(root/'manifest.json'),
        installationId=value['installationId'],operatorBootstrapFile=str(root/'operator-bootstrap.key'),
        runtimeReady=False,storageChecked=False,cloudHistoryChecked=False,enabledLanes=[],awsResourcesCreated=False)


def claim_root(path,bootstrap_file):
    """Consume the existing one-use token without printing credential material."""
    from agentic_os.adapters.local.operator import consume_bootstrap
    from agentic_os.adapters.local import recovery_gate as gate
    path=Path(path);manifest=load_manifest(path)
    if manifest['profile']!='aws-eks/1':raise OwnershipError('Explicit AWS installation identity required')
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        current=gate.state(path)
        if current['mode']!='PARKED' or current['generation']!=1:
            raise OwnershipError('Initial parked AWS preparation required')
        operator=consume_bootstrap(path,private_read(Path(bootstrap_file),32))
    return dict(profile='aws-installation-preparation/1',state='PARKED',installationId=manifest['installationId'],
        operatorFile=str(operator),runtimeReady=False,enabledLanes=[])


def _knowledge_binding(path,manifest):
    if manifest['profile']!='aws-eks/1':raise OwnershipError('Explicit AWS installation identity required')
    return dict(profile='OSProtectedKnowledgeKeysAWS/1',installationId=manifest['installationId'],
        runId=manifest['runId'],database='aos_'+manifest['installationId'].replace('-','')+'_knowledge',
        root=str(path.parent/'protected-knowledge'),purpose='planner.read/1')


def private_knowledge_keys(path):
    from agentic_os.adapters.local.artifacts import LocalKeys
    path=Path(path);manifest=load_manifest(path);expected=_knowledge_binding(path,manifest)
    if read_signed(path.parent/'knowledge-key-binding.json',path.parent/'owner.key')!=expected:
        raise OwnershipError('Protected AWS knowledge key binding differs')
    root=canonical_path(path.parent/'protected-knowledge')
    from agentic_os.adapters.local.files import check_private
    check_private(root,directory=True)
    from agentic_os.adapters.local.recovery_ready import restored
    if restored(path):
        from agentic_os.adapters.local.recovery_key_continuity import RestoredKnowledgeKeys
        return RestoredKnowledgeKeys(path)
    keys=LocalKeys(root/'keys');keys.active();return keys


def prepare_private_files(path,token,*,expected_generation):
    """Create purpose-separated keys only in a new explicit parked directory."""
    from agentic_os.adapters.local.artifacts import LocalKeys
    from agentic_os.adapters.local.operator import verify_operator
    from agentic_os.adapters.local import recovery_gate as gate
    path=Path(path);manifest=load_manifest(path);expected=_knowledge_binding(path,manifest)
    verify_operator(path,token)
    if type(expected_generation) is not int or expected_generation<1:
        raise OwnershipError('Exact initial parked generation required')
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        current=gate.state(path)
        if (current['mode']!='PARKED' or current['generation']!=expected_generation
                or expected_generation!=1):raise OwnershipError('Initial parked AWS preparation required')
        root=canonical_path(path.parent/'protected-knowledge');binding=path.parent/'knowledge-key-binding.json'
        if root.exists() or root.is_symlink() or binding.exists() or binding.is_symlink():
            raise OwnershipError('Protected knowledge material already exists; no adoption or replacement')
        keys=LocalKeys(path.parent/'keys');keys._key(keys.active())
        private_directory(root);private_directory(root/'keys');LocalKeys(root/'keys').rotate()
        verify_operator(path,token)
        if gate.state(path)!=current:raise OwnershipError('Initial parked installation changed')
        write_signed(binding,expected,path.parent/'owner.key')
        private_knowledge_keys(path)
    return dict(profile='aws-private-material-preparation/1',state='private-keys-prepared',
        installationId=manifest['installationId'],purpose='planner.read/1',runtimeReady=False,enabledLanes=[])


async def serve_embedding(path,token,*,expected_generation,stop=None):
    """Operator-owned offline preparation service, not public runtime authority."""
    from agentic_os.adapters.local.operator import verify_operator
    from agentic_os.adapters.local import recovery_gate as gate
    from agentic_os.adapters.embedding.rpc import _serve_bound
    path=Path(path);manifest=load_manifest(path);_knowledge_binding(path,manifest)
    if type(expected_generation) is not int or expected_generation<1:
        raise OwnershipError('Exact parked service generation required')
    initial=gate.state(path)
    if initial['mode'] not in {'PARKED','READY'} or initial['generation']!=expected_generation:
        raise OwnershipError('Explicit current embedding service generation required')
    def current():
        state=gate.state(path)
        from . import renewal
        staged=False
        if state['mode']=='PARKED' and state==initial and renewal.selected(path):
            selection=renewal._selector(path)
            if selection['profile']==renewal.OPERATOR_PROFILE:
                op=renewal._operation(path,selection['commandId'])
                raw=read_signed(op/'intent.json',path.parent/'owner.key',maximum=1024**2)
                intent,_=renewal._intent(path,selection['commandId'],raw['installationDigest'])
                if intent['parkGeneration']!=expected_generation:raise OwnershipError('Embedding operator handoff generation differs')
                from .operator_rotation import authorize
                authorize(path,token,intent);staged=True
        if not staged:verify_operator(path,token)
        if load_manifest(path)!=manifest or state['mode'] not in {'PARKED','READY'}:
            raise OwnershipError('Embedding installation is unavailable')
        if state['mode']=='READY':
            from .readiness import FILE,certificate
            from agentic_os.adapters.local.recovery_ready import restored
            if restored(path):
                from agentic_os.adapters.local.recovery_maintenance import cloud_configuration
                from .readiness import installation_digest
                certificate(path,installation_digest(cloud_configuration(path)['stores']['installation']))
            else:
                file=renewal._operation(path,renewal._selector(path)['commandId'])/'ready.json' if renewal.selected(path) else path.parent/FILE
                value=read_signed(file,path.parent/'owner.key',maximum=1024**2)
                certificate(path,value.get('installationDigest') if type(value) is dict else None)
        elif initial['mode']!='PARKED' or state!=initial:
            raise OwnershipError('Embedding preparation generation changed')
    current()
    await _serve_bound(path,manifest,stop,current=current)
