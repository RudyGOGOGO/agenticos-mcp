"""One Lambda invocation's explicit execution-role credentials and attestation.

Only the runtime's three temporary credential variables are read. No SDK
provider chain or workstation credentials are consulted, and no credentials
survive into another invocation's service factory.
"""
import os
import re

import boto3
from botocore.config import Config
from botocore.credentials import Credentials,CredentialResolver

from agentic_os.adapters.local.files import OwnershipError
from .workload import AWSWebIdentitySession,isolated_session,role_arn,_Credentials
from .scheduler import SchedulerPlacement


class AWSLambdaSession(AWSWebIdentitySession):
    def __init__(self,placement):
        if type(placement) is not SchedulerPlacement:raise OwnershipError('Explicit Lambda placement required')
        try:
            name=placement.function_arn.split(':')[6]
            if (os.environ.get('AWS_EXECUTION_ENV')!='AWS_Lambda_python3.12'
                    or os.environ.get('AWS_REGION')!=placement.region
                    or os.environ.get('AWS_LAMBDA_FUNCTION_NAME')!=name
                    or re.fullmatch(r'[1-9][0-9]*',os.environ.get('AWS_LAMBDA_FUNCTION_VERSION','')) is None):raise ValueError()
            key,secret,token=(os.environ.get(k,'') for k in ('AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN'))
            if (re.fullmatch(r'ASIA[A-Z0-9]{16}',key) is None
                    or re.fullmatch(r'[A-Za-z0-9/+=]{40}',secret) is None
                    or not 16<=len(token)<=16384 or any(ord(c)<33 or ord(c)>126 for c in token)):raise ValueError()
            session=isolated_session(placement.region)
            if placement.region not in session.get_available_regions('sts'):raise ValueError()
            session.register_component('credential_provider',CredentialResolver([_Credentials(Credentials(key,secret,token))]))
            self._session=boto3.Session(botocore_session=session)
            self.region,self.role=placement.region,'scheduler'
            self.placement=placement;self._closed=False;self._clients=[];self._cache={};self._verified=False
            self._sts=session.create_client('sts',region_name=self.region,verify=True,use_ssl=True,
                endpoint_url='https://sts.'+self.region+'.amazonaws.com',config=Config(signature_version='v4',
                    connect_timeout=2,read_timeout=2,max_pool_connections=4,proxies={},defaults_mode='standard',
                    retries={'total_max_attempts':1}))
            self._clients.append(self._sts)
        except Exception:raise OwnershipError('Lambda execution credential unavailable') from None

    def verify(self):
        self._current();self._verified=False
        try:
            value=self._sts.get_caller_identity()
            name=role_arn(self.placement.installation_id,self.placement.account,'scheduler').split('/')[-1]
            if (value.get('Account')!=self.placement.account or type(value.get('Arn')) is not str
                    or re.fullmatch('arn:aws:sts::'+self.placement.account+':assumed-role/'+re.escape(name)+r'/[A-Za-z0-9+=,.@_-]{2,64}',value['Arn']) is None):raise ValueError()
            self._verified=True
        except Exception:raise OwnershipError('Lambda execution identity differs') from None

    def client(self,service,**options):
        if not self._verified:raise OwnershipError('Lambda execution identity not verified')
        return super().client(service,**options)

    def matches(self,installation_id,account,region):
        self._current()
        return self._verified and (self.placement.installation_id,self.placement.account,self.region)==(installation_id,account,region)
