"""AWS Lambda container handler; only deployment supplies private config pins."""
import atexit
import os
import threading

from agentic_os.errors import OSErrorCode
from agentic_os.production.lambda_service import load_configuration,handler as configured_handler

_handler=None
_lock=threading.Lock()


def handler(event,context):
    global _handler
    if not _lock.acquire(blocking=False):raise OSErrorCode('CAPACITY')
    try:
        if _handler is None:
            # These two non-secret deployment variables cannot be supplied by
            # an invocation. Loading enables no service or credential IO.
            value=load_configuration(os.environ.get('AGENTIC_OS_LAMBDA_CONFIGURATION'),
                os.environ.get('AGENTIC_OS_LAMBDA_CONFIGURATION_SHA256'))
            _handler=configured_handler(value)
            atexit.register(_handler.close)
        return _handler(event,context)
    finally:_lock.release()
