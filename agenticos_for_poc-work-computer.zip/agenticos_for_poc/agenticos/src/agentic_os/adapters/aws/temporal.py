"""Cloud mTLS credentials from the existing immutable AWS secret boundary.

No namespace, service, database, secret or workflow is provisioned or restored.
The operator supplies one reviewed version containing the matching identity pair.
"""
from dataclasses import dataclass,field
from contextlib import contextmanager
import asyncio
from datetime import timedelta
import hashlib

from agentic_os.adapters.local.files import OwnershipError
from agentic_os.adapters.temporal.connection import (CloudNamespace,SelfHostedNamespace,REMOTE_NAMESPACES,
    namespace_identity,TemporalConnection,TemporalIdentity)
from agentic_os.contracts.canonical import parse_canonical_json
from .backend import AWSSecrets,SecretPin

CONFIGURATION='temporal-cloud-operator/1'
SELF_HOSTED_CONFIGURATION='temporal-self-hosted-operator/1'


HISTORY_PROFILES={'temporal-cloud-history-inspection/1','temporal-self-hosted-history-inspection/1'}
HELD_HISTORY_PROFILES={'temporal-cloud-held-history-inspection/1','temporal-self-hosted-held-history-inspection/1'}


def history_profile(connection,*,held=False):
    return 'temporal-'+('self-hosted' if type(connection.cloud) is SelfHostedNamespace else 'cloud')+('-held' if held else '')+'-history-inspection/1'


def selected_namespace(value):
    return namespace_identity(value,self_hosted=value['schema']==SELF_HOSTED_CONFIGURATION)


def runtime_connection(installation,document):
    """Same secure transport for Core, assigned workers and scheduler/Lambda."""
    from pathlib import Path
    from agentic_os.adapters.local.files import private_read
    value=operator_configuration(document)
    if Path(value['installation']['manifest'])!=installation.root/'manifest.json':
        raise OwnershipError('Temporal installation differs')
    selected=value['identity']
    if selected['provider']=='aws-secrets-manager':
        identity=AWSCloudTemporalIdentity(installation.credentials.secrets,SecretPin(**selected['pin']))
    else:
        def identity():
            return TemporalIdentity(private_read(Path(selected['certificate']),65536),
                private_read(Path(selected['private_key']),65536))
    namespace=selected_namespace(value)
    return TemporalConnection(installation,namespace.host,7233,namespace.host,namespace.namespace,value['run_id'],
        private_read(Path(value['server_ca']),65536),value['server_ca_sha256'],identity,namespace)


async def transition_check(connection,token,destination,*,expected_generation):
    """Read-only maintenance check for a NEW installation, never state migration.

    Retain the parked source/history for inspection. In-place backend changes
    remain refused by existing signed initial/service/recovery bindings.
    """
    from pathlib import Path
    from temporalio.api.workflowservice.v1 import DescribeNamespaceRequest,ListWorkflowExecutionsRequest
    from agentic_os.adapters.local import recovery_gate as gate
    from agentic_os.adapters.local.ownership import load_manifest
    from agentic_os.adapters.local.recovery_runtime_checkpoint import runtime_checkpoint
    selected=operator_configuration(destination);target=load_manifest(Path(selected['installation']['manifest']))
    if (type(connection) is not TemporalConnection or type(connection.cloud) not in REMOTE_NAMESPACES
            or type(expected_generation) is not int or expected_generation<1
            or target['installationId']==str(connection.installation.installation_id)
            or target['runId']!=selected['run_id'] or selected['namespace_id']==connection.cloud.namespace_id
            or selected_namespace(selected).host==connection.host and selected['namespace']==connection.namespace):
        raise OwnershipError('Transition requires a distinct fresh installation and namespace; live migration is unsupported')
    installation=connection.installation;path=installation.root/'manifest.json'
    target_gate=gate.state(Path(selected['installation']['manifest']))
    if target['profile']!='aws-eks/1' or target_gate['mode']!='PARKED' or target_gate['generation']!=1:
        raise OwnershipError('Destination must be a new parked AWS installation; initial readiness remains required')
    def checkpoint():
        installation.verify_operator(token);state=gate.state(path)
        if state['mode']!='PARKED' or state['generation']!=expected_generation:
            raise OwnershipError('Original source must remain parked at the reviewed generation')
        from agentic_os.adapters.local.resources import read_signed
        from agentic_os.adapters.local.recovery_ready import restored
        if restored(path):
            from agentic_os.adapters.local.restoration_binding import relocation_metadata
            original=relocation_metadata(path)['temporal']
            logical_run=original['data']['runId']
        else:
            from .readiness import FILE
            certificate=read_signed(path.parent/FILE,path.parent/'owner.key',maximum=65536)
            source=load_manifest(path)
            if (certificate['profile'] not in {'aws-initial-control-release/1','aws-initial-control-release/2'}
                    or certificate['installationId']!=str(installation.installation_id)
                    or certificate['runId']!=source['runId'] or connection.run_id!=source['runId']):
                raise OwnershipError('Original installation service selection differs')
            original=certificate['cloud'];logical_run=original['runId']
        if (original['namespace']!=connection.namespace or original['namespaceId']!=connection.cloud.namespace_id
                or original['endpoint']!=connection.host or original['retentionDays']!=connection.cloud.retention_days
                or logical_run!=connection.run_id):
            raise OwnershipError('Transition must inspect the original bound backend and namespace')
        with installation.connect() as db:
            db.rollback();db.execute('SET TRANSACTION READ ONLY')
            db.execute("SET LOCAL lock_timeout='2s'");db.execute("SET LOCAL statement_timeout='3s'")
            # UNKNOWN is never released, transferred or treated as drained.
            if any(db.execute(sql).fetchone()[0] for sql in (
                    "SELECT EXISTS(SELECT 1 FROM os_budget_roots WHERE state<>'CLOSED')",
                    "SELECT EXISTS(SELECT 1 FROM os_work_attempts WHERE state IN ('RESERVED','RUNNING','UNKNOWN'))",
                    "SELECT EXISTS(SELECT 1 FROM os_proactive_definitions WHERE state NOT IN ('removed','revoked','rejected'))",
                    "SELECT EXISTS(SELECT 1 FROM os_proactive_dispatches WHERE state IN ('DUE','POISON'))")):
                raise OwnershipError('Original work, UNKNOWN usage or schedules remain; transition is refused')
        return state,runtime_checkpoint(path,installation=installation)
    before=await asyncio.to_thread(checkpoint)
    async with asyncio.timeout(15):
        client=await connection.connect()
        request=DescribeNamespaceRequest(namespace=connection.namespace)
        connection.cloud.verify(await client.workflow_service.describe_namespace(request,timeout=timedelta(seconds=5)))
        running=await client.workflow_service.list_workflow_executions(ListWorkflowExecutionsRequest(
            namespace=connection.namespace,page_size=1,query='ExecutionStatus = "Running"'),timeout=timedelta(seconds=5))
        if running.executions or running.next_page_token:
            raise OwnershipError('Original Temporal workflows, including scheduler drivers, must finish before transition')
        connection.cloud.verify(await client.workflow_service.describe_namespace(request,timeout=timedelta(seconds=5)))
    if await asyncio.to_thread(checkpoint)!=before:raise OwnershipError('Source changed during transition inspection')
    return dict(profile='temporal-maintenance-transition-check/1',sourceParked=True,sourceDrained=True,
        destinationInstallationId=target['installationId'],destinationNamespace=selected['namespace'],
        stateMigration=False,sourceHistoryRetained=True,destinationReadinessRequired=True,runtimeReady=False)


def operator_configuration(document):
    """Closed private configuration, checked before clients or credentials."""
    from copy import deepcopy
    import re
    from agentic_os.adapters.configured_installation import closed,canonical_file,installation_configuration
    try:
        value=deepcopy(document)
        self_hosted=value.get('schema')==SELF_HOSTED_CONFIGURATION
        closed(value,{'schema','installation','namespace','namespace_id','retention_days','run_id',
            'server_ca','server_ca_sha256','identity'}|({'endpoint','server_name'} if self_hosted else set()))
        if value['schema'] not in {CONFIGURATION,SELF_HOSTED_CONFIGURATION}:raise ValueError()
        installation=installation_configuration(value['installation'])
        selected=selected_namespace(value)
        if self_hosted and value['server_name']!=selected.host:raise ValueError()
        canonical_file(value['server_ca'])
        if (type(value['run_id']) is not str or re.fullmatch('[a-f0-9]{12}',value['run_id']) is None
                or type(value['server_ca_sha256']) is not str
                or re.fullmatch('[a-f0-9]{64}',value['server_ca_sha256']) is None):raise ValueError()
        identity=value['identity']
        if installation['provider']=='aws-eks':
            if installation['aws']['role']!='core':raise ValueError()
            closed(identity,{'provider','pin'})
            if identity['provider']!='aws-secrets-manager':raise ValueError()
            closed(identity['pin'],{'arn','version'});SecretPin(**identity['pin'])
        else:
            closed(identity,{'provider','certificate','private_key'})
            if identity['provider']!='private-files':raise ValueError()
            canonical_file(identity['certificate']);canonical_file(identity['private_key'])
        return value
    except Exception:raise OwnershipError('Invalid Cloud operator configuration') from None


def load_operator_configuration(path):
    from agentic_os.adapters.configured_installation import canonical_file
    from agentic_os.adapters.local.files import private_read
    try:return operator_configuration(parse_canonical_json(private_read(canonical_file(str(path)),65536)))
    except Exception:raise OwnershipError('Cloud operator configuration unavailable') from None


@contextmanager
def configured_operator_connection(document,*,preparing_recovery=False,key_generation=None):
    """Reuse installation ownership and rotating identity; create no resources."""
    from pathlib import Path
    from agentic_os.adapters.configured_installation import configured_installation
    from agentic_os.adapters.local.files import private_read
    if type(preparing_recovery) is not bool:raise OwnershipError('Explicit recovery preparation selection required')
    value=operator_configuration(document)
    ca=private_read(Path(value['server_ca']),65536)
    if hashlib.sha256(ca).hexdigest()!=value['server_ca_sha256']:
        raise OwnershipError('Reviewed Cloud server CA changed')
    if preparing_recovery and key_generation is not None:raise OwnershipError('One explicit Cloud operator purpose required')
    options={'preparing_recovery':True} if preparing_recovery is True else ({} if key_generation is None else dict(key_generation=key_generation))
    with configured_installation(value['installation'],**options) as installation:
        selected=value['identity']
        if selected['provider']=='aws-secrets-manager':
            identity=AWSCloudTemporalIdentity(installation.credentials.secrets,SecretPin(**selected['pin']))
        else:
            def identity():
                return TemporalIdentity(private_read(Path(selected['certificate']),65536),
                    private_read(Path(selected['private_key']),65536))
            # Operator inspection must work while PARKED. Runtime composition
            # keeps its normal guarded connection; this explicit operator
            # factory supplies only a read-only control session.
            from dataclasses import replace
            from agentic_os.adapters.local.target import connect_owned
            manifest=installation.root/'manifest.json'
            def inspect_control():
                db=connect_owned(manifest,role='migrator')
                try:
                    db.rollback();db.execute('SET TRANSACTION READ ONLY')
                    return db
                except BaseException:
                    db.close();raise
            installation=replace(installation,connect=inspect_control)
        cloud=selected_namespace(value)
        yield TemporalConnection(installation,cloud.host,7233,cloud.host,cloud.namespace,value['run_id'],
            ca,value['server_ca_sha256'],identity,cloud)


async def operator_readiness(connection,token,*,expected_generation):
    """Current Cloud service only; no storage, task or runtime Ready claim."""
    from temporalio.api.workflowservice.v1 import DescribeNamespaceRequest
    from agentic_os.adapters.local import recovery_gate as gate
    if (type(connection) is not TemporalConnection or type(connection.cloud) not in REMOTE_NAMESPACES
            or type(expected_generation) is not int or not 0<=expected_generation<=2**53-1):
        raise OwnershipError('Explicit Cloud connection and current generation required')
    installation=connection.installation
    def current():
        path=installation.root/'manifest.json';operator=installation.verify_operator(token)
        state=gate.state(path) if gate.selected(path) else None
        if (0 if state is None else state['generation'])!=expected_generation:
            raise OwnershipError('Cloud operator generation changed')
        return operator,state
    before=await asyncio.to_thread(current)
    try:
        async with asyncio.timeout(10):
            client=await connection.connect()
            if not await client.service_client.check_health():raise ValueError()
            connection.cloud.verify(await client.workflow_service.describe_namespace(
                DescribeNamespaceRequest(namespace=connection.namespace),timeout=timedelta(seconds=5)))
    except Exception:raise OwnershipError('Cloud service readiness unavailable') from None
    if await asyncio.to_thread(current)!=before:raise OwnershipError('Cloud operator checkpoint changed')
    return dict(profile='temporal-self-hosted-readiness/1' if type(connection.cloud) is SelfHostedNamespace else 'temporal-cloud-readiness/1',state='service-available',runtimeReady=False,
        storageChecked=False,enabledLanes=[])


@dataclass(frozen=True)
class AWSCloudTemporalIdentity:
    secrets:AWSSecrets=field(repr=False)
    pin:SecretPin

    def __post_init__(self):
        if type(self.secrets) is not AWSSecrets or type(self.pin) is not SecretPin:
            raise OwnershipError('Pinned installation Temporal identity required')
        self.secrets.validate_pin(self.pin,'control')

    def __call__(self):
        try:
            value=parse_canonical_json(self.secrets.read(self.pin,'control'))
            if (type(value) is not dict or set(value)!={'certificate','privateKey'}
                    or any(type(raw) is not str for raw in value.values())):raise ValueError()
            return TemporalIdentity(value['certificate'].encode('ascii'),value['privateKey'].encode('ascii'))
        except Exception:raise OwnershipError('Pinned Cloud client identity unavailable') from None


def cloud_connection(installation,*,namespace,namespace_id,retention_days,run_id,server_ca,server_ca_sha256,identity):
    if (type(identity) is not AWSCloudTemporalIdentity
            or identity.secrets.installation_id!=installation.installation_id):
        raise OwnershipError('Cloud credentials must belong to this installation')
    cloud=CloudNamespace(namespace,namespace_id,retention_days)
    return TemporalConnection(installation,cloud.host,7233,cloud.host,namespace,run_id,
        server_ca,server_ca_sha256,identity,cloud=cloud)


def worker_configuration(connection,*,resume_existing):
    """Secret material: write only with the existing private worker-file helper.

    Never put this value in a ConfigMap, environment, workflow history or report.
    Rotating the immutable secret pin requires a new connection and worker rollout.
    """
    if (type(connection) is not TemporalConnection or type(connection.cloud) not in REMOTE_NAMESPACES
            or type(resume_existing) is not bool):
        raise OwnershipError('Reviewed Cloud connection required')
    connection.assert_runtime()
    identity=connection.identity()
    if type(identity) is not TemporalIdentity:raise OwnershipError('Current Cloud identity required')
    identity.check()
    connection.assert_runtime()
    result=dict(profile='temporal-cloud-mtls/1',installationId=str(connection.installation.installation_id),
        namespace=connection.namespace,namespaceId=connection.cloud.namespace_id,retentionDays=connection.cloud.retention_days,
        serverCA=connection.server_ca.decode('ascii'),serverCASha256=connection.server_ca_sha256,
        certificate=identity.certificate.decode('ascii'),privateKey=identity.private_key.decode('ascii'),
        resumeExisting=resume_existing)
    if type(connection.cloud) is SelfHostedNamespace:
        result.update(profile='temporal-self-hosted-mtls/1',endpoint=connection.host,serverName=connection.server_name)
    return result


async def inspect_parked_history(connection,token,*,expected_generation):
    """Capture opaque original Cloud history through supported read APIs.

    This is the source-side prerequisite for coordinated recovery, not a Ready
    certificate. No namespace/database is created, restored or adopted. Private
    payloads remain undecoded; returned IDs/digests belong in protected recovery
    material. Independent component clocks do not form an atomic global backup.
    Missing/expired history or a changed control checkpoint refuses the capture.
    """
    from temporalio.api.workflowservice.v1 import DescribeNamespaceRequest
    from temporalio.service import RPCError
    from agentic_os.adapters.local import recovery_gate as gate
    from agentic_os.adapters.local.ownership import load_manifest
    from agentic_os.adapters.local.resources import file_lock
    from agentic_os.adapters.local.recovery_ready import restored
    from agentic_os.adapters.local.recovery_runtime_checkpoint import runtime_checkpoint
    from agentic_os.adapters.local.recovery_temporal import _admitted_workflows,_history_catalog,INSPECTION_SECONDS
    if (type(connection) is not TemporalConnection or type(connection.cloud) not in REMOTE_NAMESPACES
            or type(expected_generation) is not int or expected_generation<1):
        raise OwnershipError('Reviewed Cloud connection and parked generation required')
    installation=connection.installation;path=installation.root/'manifest.json'
    def checkpoint():
        identity=installation.verify_operator(token)
        with file_lock(installation.root/'recovery-gate.lock',timeout=2):
            manifest=load_manifest(path);current=gate.state(path)
            if (manifest['installationId']!=str(installation.installation_id)
                    or manifest['runId']!=connection.run_id or current['mode']!='PARKED'
                    or current['generation']!=expected_generation or restored(path)):
                raise OwnershipError('Original parked Cloud installation required')
            value=runtime_checkpoint(path,installation=installation)
            required=_admitted_workflows(path,manifest,installation=installation)
            return identity,current,value,required
    before=await asyncio.to_thread(checkpoint)
    original=dict(namespace=connection.namespace,namespaceId=connection.cloud.namespace_id,
        data={k:v for k,v in connection.binding.items() if k!='namespace'})
    try:
        async with asyncio.timeout(INSPECTION_SECONDS):
            client=await connection.connect()
            response=await client.workflow_service.describe_namespace(
                DescribeNamespaceRequest(namespace=connection.namespace),timeout=timedelta(seconds=5))
            connection.cloud.verify(response)
            catalog=await _history_catalog(client,connection.binding,original,before[2],required=before[3])
            response=await client.workflow_service.describe_namespace(
                DescribeNamespaceRequest(namespace=connection.namespace),timeout=timedelta(seconds=5))
            connection.cloud.verify(response)
    except (RPCError,TimeoutError):
        raise OwnershipError('Original Cloud history unavailable; recovery remains held') from None
    if await asyncio.to_thread(checkpoint)!=before:
        raise OwnershipError('Parked Cloud checkpoint changed during inspection')
    value=dict(profile=history_profile(connection),installationId=original['data']['installationId'],
        sourceRunId=connection.run_id,sourceGeneration=expected_generation,namespace=connection.namespace,
        namespaceId=connection.cloud.namespace_id,retentionDays=connection.cloud.retention_days,
        endpoint=connection.host,serverCASha256=connection.server_ca_sha256,
        requiredWorkflows=before[3],catalog=catalog,runtimeCheckpoint=before[2],
        runtimeReady=False)
    return checked_history_capture(value)


def original_history(capture):
    from agentic_os.adapters.local.recovery_metadata import CLOUD_TEMPORAL_PROFILE,SELF_HOSTED_TEMPORAL_PROFILE
    profile=SELF_HOSTED_TEMPORAL_PROFILE if capture['profile'].startswith('temporal-self-hosted-') else CLOUD_TEMPORAL_PROFILE
    return dict(profile=profile,namespace=capture['namespace'],namespaceId=capture['namespaceId'],
        retentionDays=capture['retentionDays'],endpoint=capture['endpoint'],serverCASha256=capture['serverCASha256'],
        data=dict(installationId=capture['installationId'],runId=capture.get('originalRunId',capture['sourceRunId'])),
        taskQueue='os-admission-'+capture.get('originalRunId',capture['sourceRunId']),
        requiredWorkflows=capture['requiredWorkflows'],catalog=capture['catalog'])


def checked_history_capture(value):
    import re
    from agentic_os.adapters.local.recovery_metadata import checked_cloud_temporal
    from agentic_os.adapters.local.recovery_runtime_checkpoint import checked_runtime_checkpoint
    fields={'profile','installationId','sourceRunId','sourceGeneration','namespace','namespaceId','retentionDays',
        'endpoint','serverCASha256','requiredWorkflows','catalog','runtimeCheckpoint','runtimeReady'}
    held=type(value) is dict and value.get('profile') in HELD_HISTORY_PROFILES
    if (type(value) is not dict or set(value)!=fields|({'originalRunId'} if held else set())
            or value['profile'] not in HISTORY_PROFILES|HELD_HISTORY_PROFILES
            or type(value['sourceGeneration']) is not int or not 1<=value['sourceGeneration']<=2**53-1
            or type(value['sourceRunId']) is not str or re.fullmatch('[a-f0-9]{12}',value['sourceRunId']) is None
            or held and (type(value['originalRunId']) is not str or re.fullmatch('[a-f0-9]{12}',value['originalRunId']) is None)
            or value['runtimeReady'] is not False):
        raise OwnershipError('Original Cloud history capture unavailable')
    checked_runtime_checkpoint(value['runtimeCheckpoint'])
    checked_cloud_temporal(original_history(value),value['installationId'])
    from agentic_os.adapters.local.recovery_temporal import production_workflow
    for row in value['catalog']:
        if row['workflowType']=='OSAgentTaskDriver/1':production_workflow(value['runtimeCheckpoint'],row['workflowId'])
    return value


async def inspect_held_history(connection,token,*,expected_generation):
    """Recheck the original service before resnapshotting a held OS copy.

    Physical store ownership follows the held target, while raw history and
    queues retain their original logical run. No locks or SQL cross RPCs.
    """
    from agentic_os.adapters.local.recovery_operator import held_operator
    from agentic_os.adapters.local.restoration_binding import relocation_metadata
    from agentic_os.adapters.local.recovery_runtime_checkpoint import runtime_checkpoint
    from agentic_os.adapters.local.recovery_temporal import _available_history,_admitted_workflows
    from agentic_os.adapters.local.recovery_metadata import CLOUD_PROFILE
    if (type(connection) is not TemporalConnection or type(connection.cloud) not in REMOTE_NAMESPACES
            or type(expected_generation) is not int or not 1<=expected_generation<=2**53-1):
        raise OwnershipError('Explicit held Cloud connection and generation required')
    installation=connection.installation;path=installation.root/'manifest.json'
    def checkpoint():
        with held_operator(path,token,expected_generation=expected_generation) as (manifest,admitted):
            metadata=relocation_metadata(path)
            if metadata['profile']!=CLOUD_PROFILE:raise OwnershipError('Held Cloud archive required')
            original=metadata['temporal'];binding=recovery_binding(connection,original)
            value=runtime_checkpoint(path,installation=installation)
            required=sorted(set(original['requiredWorkflows'])|set(_admitted_workflows(path,manifest,installation=installation)))
            return manifest,admitted,original,binding,value,required
    before=await asyncio.to_thread(checkpoint)
    catalog=await _available_history(path,before[3],before[2],connection=connection)
    if not set(before[5])<={row['workflowId'] for row in catalog}:
        raise OwnershipError('Admitted Cloud workflow history is missing')
    if await asyncio.to_thread(checkpoint)!=before:raise OwnershipError('Held Cloud checkpoint changed during inspection')
    original=before[2]
    return checked_history_capture(dict(profile=history_profile(connection,held=True),
        installationId=before[0]['installationId'],sourceRunId=before[0]['runId'],
        originalRunId=original['data']['runId'],sourceGeneration=expected_generation,
        **{k:original[k] for k in ('namespace','namespaceId','retentionDays','endpoint','serverCASha256')},
        requiredWorkflows=before[5],catalog=catalog,runtimeCheckpoint=before[4],runtimeReady=False))


def recovery_binding(connection,original):
    """Public service pins only; fresh mTLS credentials are never archived here."""
    from agentic_os.adapters.local.recovery_metadata import checked_cloud_temporal
    from agentic_os.adapters.local.ownership import load_manifest
    if type(connection) is not TemporalConnection or type(connection.cloud) not in REMOTE_NAMESPACES:
        raise OwnershipError('Explicit original Cloud recovery connection required')
    installation=connection.installation;manifest=load_manifest(installation.root/'manifest.json')
    checked_cloud_temporal(original,str(installation.installation_id))
    from agentic_os.adapters.local.recovery_metadata import SELF_HOSTED_TEMPORAL_PROFILE
    if (original['profile']==SELF_HOSTED_TEMPORAL_PROFILE)!=(type(connection.cloud) is SelfHostedNamespace):
        raise OwnershipError('Original Temporal backend differs')
    current_ca=connection.server_ca_sha256==original['serverCASha256']
    if manifest['profile']=='aws-eks/1':
        from .managed_restore import reviewed_cloud
        current_ca=reviewed_cloud(connection,operator=True)
    if (manifest['installationId']!=str(installation.installation_id)
            or connection.run_id!=original['data']['runId'] or connection.namespace!=original['namespace']
            or connection.cloud.namespace_id!=original['namespaceId']
            or connection.cloud.retention_days!=original['retentionDays']
            or connection.host!=original['endpoint'] or not current_ca):
        raise OwnershipError('Original Cloud service pins differ')
    return dict(profile='self-hosted-temporal-recovery-service/1' if type(connection.cloud) is SelfHostedNamespace else 'cloud-temporal-recovery-service/1',installationId=manifest['installationId'],
        runId=manifest['runId'],namespace=connection.namespace,namespaceId=connection.cloud.namespace_id,
        retentionDays=connection.cloud.retention_days,endpoint=connection.host,serverCASha256=connection.server_ca_sha256)
