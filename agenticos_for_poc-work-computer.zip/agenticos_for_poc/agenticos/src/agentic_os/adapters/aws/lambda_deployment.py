"""Pure reviewed Lambda placement; no AWS client or provisioning operation."""
from copy import deepcopy
import hashlib
import re

from agentic_os.adapters.configured_installation import closed
from agentic_os.adapters.local.files import OwnershipError
from agentic_os.contracts.canonical import canonical_bytes
from agentic_os.production.lambda_service import configuration,placement,INSTALLATION_ROOT
from .workload import role_arn


def resources(document):
    try:
        value=deepcopy(document)
        closed(value,{'schema','configuration','configuration_path','configuration_sha256','image','efs','subnets','security_groups'})
        if value['schema']!='agent-lambda-schedule-deployment/1':raise ValueError()
        core=configuration(value['configuration'])['core'];selected=placement(value['configuration'])
        region,account,installation=selected.region,selected.account,str(selected.installation_id)
        if (type(value['configuration_path']) is not str
                or re.fullmatch(re.escape(INSTALLATION_ROOT)+r'/config/[A-Za-z0-9_-]{1,64}\.json',value['configuration_path']) is None
                or type(value['configuration_sha256']) is not str or re.fullmatch('[a-f0-9]{64}',value['configuration_sha256']) is None
                or hashlib.sha256(canonical_bytes(value['configuration'])).hexdigest()!=value['configuration_sha256']
                or type(value['image']) is not str or re.fullmatch(re.escape(account+'.dkr.ecr.'+region+'.amazonaws.com/agentic-os/'+installation+'/lambda')+r'@sha256:[a-f0-9]{64}',value['image']) is None):raise ValueError()
        qualifier=selected.function_arn.split(':')[7]
        if re.fullmatch(r'[A-Za-z_-][A-Za-z0-9_-]{0,127}',qualifier) is None:raise ValueError()
        def network(values,prefix,minimum,maximum):
            if (type(values) is not list or not minimum<=len(values)<=maximum or len(set(values))!=len(values)
                    or any(type(item) is not str or re.fullmatch(prefix+r'-[a-f0-9]{17}',item) is None for item in values)):raise ValueError()
        network(value['subnets'],'subnet',2,4);network(value['security_groups'],'sg',1,4)
        efs=value['efs'];closed(efs,{'filesystem','access_point'})
        efs_prefix='arn:aws:elasticfilesystem:'+region+':'+account+':'
        if (type(efs['filesystem']) is not str or re.fullmatch(re.escape(efs_prefix)+r'file-system/fs-[a-f0-9]{17}',efs['filesystem']) is None
                or type(efs['access_point']) is not str or re.fullmatch(re.escape(efs_prefix)+r'access-point/fsap-[a-f0-9]{17}',efs['access_point']) is None):raise ValueError()
        # The EFS access point must expose the same certified installation root
        # and POSIX65534 ownership as the EKS mount. This is a deployment/live
        # qualification prerequisite; configuration never creates that material.
        aws=core['installation']['aws'];apps={policy['proactive']['applicationId'] for policy in core['proactivity']['policies']}
        pins=[aws['postgres']['password']['arn'],aws['operator']['pin']['arn'],core['proactivity']['temporal']['identity']['pin']['arn']]
        pins.extend(v['pin']['arn'] for v in aws['credentials'] if v['application_id'] in apps)
        function=selected.function_arn.split(':')[6];name=role_arn(selected.installation_id,account,'scheduler').split('/')[-1]
        log_group='/aws/lambda/'+function
        log_arn='arn:aws:logs:'+region+':'+account+':log-group:'+log_group+':*'
        policies=[dict(Effect='Allow',Action='secretsmanager:GetSecretValue',Resource=sorted(set(pins))),
            dict(Effect='Allow',Action=['scheduler:GetSchedule','scheduler:DeleteSchedule'],
                Resource='arn:aws:scheduler:'+region+':'+account+':schedule/'+selected.group+'/*'),
            dict(Effect='Allow',Action=['elasticfilesystem:ClientMount','elasticfilesystem:ClientWrite'],
                Resource=efs['filesystem'],Condition=dict(StringEquals={'elasticfilesystem:AccessPointArn':efs['access_point']})),
            dict(Effect='Allow',Action=['logs:CreateLogStream','logs:PutLogEvents'],Resource=log_arn),
            dict(Effect='Allow',Action=['ec2:CreateNetworkInterface','ec2:DescribeNetworkInterfaces','ec2:DescribeSubnets',
                'ec2:DeleteNetworkInterface','ec2:AssignPrivateIpAddresses','ec2:UnassignPrivateIpAddresses'],Resource='*')]
        role=dict(Type='AWS::IAM::Role',Properties=dict(RoleName=name,Path='/agentic-os/'+installation+'/',
            AssumeRolePolicyDocument=dict(Version='2012-10-17',Statement=[dict(Effect='Allow',Principal=dict(Service='lambda.amazonaws.com'),Action='sts:AssumeRole')]),
            Policies=[dict(PolicyName='finite-schedule-wake',PolicyDocument=dict(Version='2012-10-17',Statement=policies))]))
        function_resource=dict(Type='AWS::Lambda::Function',DependsOn=['WakeLogs'],Properties=dict(
            FunctionName=function,PackageType='Image',Architectures=['arm64'],Code=dict(ImageUri=value['image']),
            ImageConfig=dict(EntryPoint=['/lambda-entrypoint.sh'],Command=['agentic_os.adapters.aws.lambda_entry.handler']),
            Role={'Fn::GetAtt':['WakeRole','Arn']},Timeout=30,MemorySize=1024,ReservedConcurrentExecutions=1,
            VpcConfig=dict(SubnetIds=value['subnets'],SecurityGroupIds=value['security_groups']),
            FileSystemConfigs=[dict(Arn=efs['access_point'],LocalMountPath=INSTALLATION_ROOT)],
            Environment=dict(Variables=dict(AGENTIC_OS_LAMBDA_CONFIGURATION=value['configuration_path'],
                AGENTIC_OS_LAMBDA_CONFIGURATION_SHA256=value['configuration_sha256']))))
        template=dict(AWSTemplateFormatVersion='2010-09-09',Resources=dict(WakeRole=role,WakeFunction=function_resource,
            WakeLogs=dict(Type='AWS::Logs::LogGroup',Properties=dict(LogGroupName=log_group,RetentionInDays=14)),
            WakeVersion=dict(Type='AWS::Lambda::Version',DeletionPolicy='Retain',UpdateReplacePolicy='Retain',Properties=dict(FunctionName={'Ref':'WakeFunction'},
                Description='Image '+value['image'].split('@')[-1]+' configuration '+value['configuration_sha256'])),
            WakeAlias=dict(Type='AWS::Lambda::Alias',Properties=dict(Name=qualifier,FunctionName={'Ref':'WakeFunction'},
                FunctionVersion={'Fn::GetAtt':['WakeVersion','Version']}))))
        return dict(schema=value['schema'],status='reviewed-plan-only',template=template,qualifiedTarget=selected.function_arn,
            qualification='Requires certified shared EFS/runtime material, private networking, exact image build/platform/security and actual AWS/Cloud acceptance; no resource is provisioned or activated.')
    except Exception:raise OwnershipError('Invalid Lambda schedule deployment') from None
