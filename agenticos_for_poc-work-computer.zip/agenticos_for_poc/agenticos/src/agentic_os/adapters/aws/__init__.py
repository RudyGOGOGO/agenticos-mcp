"""Explicit AWS deployment adapters; local startup contacts no AWS service."""
