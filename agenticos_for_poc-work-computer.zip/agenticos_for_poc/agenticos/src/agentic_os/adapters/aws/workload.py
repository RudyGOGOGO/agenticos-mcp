"""Explicit EKS web identity for the existing regional AWS adapters.

The caller supplies the rotating projected-token reader and reviewed role.
The official SDK owns temporary credentials and refresh; no workstation,
environment, instance-metadata or shared-file credential provider is installed.
"""
import os
import inspect
import re
from uuid import UUID

import boto3
from botocore import UNSIGNED
from botocore.config import Config
from botocore.credentials import (AssumeRoleWithWebIdentityCredentialFetcher,
    CredentialProvider,CredentialResolver,DeferredRefreshableCredentials)
from botocore.loaders import Loader
from botocore.session import Session

from agentic_os.adapters.local.files import OwnershipError


def role_arn(installation_id,account,role):
    if (type(installation_id) is not UUID or type(account) is not str
            or re.fullmatch(r'[0-9]{12}',account) is None
            or type(role) is not str or role not in {'core','native','worker','recovery','storage','scheduler'}):
        raise OwnershipError('Explicit installation AWS workload role required')
    # IAM friendly names are account-wide; a different path alone cannot
    # distinguish two installations' roles in the same AWS account.
    name='aos-'+installation_id.hex+'-'+role
    return 'arn:aws:iam::'+account+':role/agentic-os/'+str(installation_id)+'/'+name


class _Credentials(CredentialProvider):
    METHOD='custom-agentic-os-web-identity'
    CANONICAL_NAME='custom-agentic-os-web-identity'

    def __init__(self,credentials):self.credentials=credentials
    def load(self):return self.credentials


def isolated_session(region):
    """Use only locked SDK service models and explicit caller credentials."""
    variables={name:(None,None,value[2],value[3]) for name,value in Session.SESSION_VARIABLES.items()}
    variables.update(profile=(None,None,None,None),region=(None,None,region,None),
        config_file=(None,None,os.devnull,None),credentials_file=(None,None,os.devnull,None),
        data_path=(None,None,None,None))
    session=Session(session_vars=variables)
    session.register_component('data_loader',Loader(extra_search_paths=[Loader.BUILTIN_DATA_PATH],
        include_default_search_paths=False))
    return session


class AWSWebIdentitySession:
    """One configured SDK session and its bounded, explicitly closed clients."""
    def __init__(self,*,installation_id,account,region,role,token_provider):
        arn=role_arn(installation_id,account,role)
        if (type(region) is not str or re.fullmatch(r'[a-z]{2}(?:-[a-z]+)+-[0-9]+',region) is None
                or not callable(token_provider) or inspect.iscoroutinefunction(token_provider)
                or inspect.iscoroutinefunction(getattr(token_provider,'__call__',None))):
            raise OwnershipError('Explicit regional projected workload credential required')
        # Session variables are a supported constructor input in the locked
        # SDK. Preserve SDK defaults while removing file/environment sources.
        session=isolated_session(region)
        if region not in session.get_available_regions('sts'):
            raise OwnershipError('Unsupported explicit AWS region')
        self.region,self.role=region,role;self._closed=False;self._clients=[]
        # This unsigned STS call authenticates only the supplied OIDC token.
        # Every request has one SDK attempt and a fixed TLS regional endpoint.
        sts=session.create_client('sts',region_name=region,verify=True,use_ssl=True,
            endpoint_url='https://sts.'+region+'.amazonaws.com',config=Config(signature_version=UNSIGNED,
                connect_timeout=2,read_timeout=2,max_pool_connections=4,proxies={},defaults_mode='standard',
                retries={'total_max_attempts':1}))
        self._clients.append(sts)
        def token():
            try:
                if self._closed:raise ValueError()
                value=token_provider()
                if (type(value) is not str or not 32<=len(value)<=8192
                        or re.fullmatch(r'[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',value) is None):raise ValueError()
                return value
            except Exception:raise OwnershipError('Projected AWS workload credential unavailable') from None
        self._cache={}
        fetcher=AssumeRoleWithWebIdentityCredentialFetcher(
            client_creator=lambda *args,**kwargs:sts,web_identity_token_loader=token,role_arn=arn,
            extra_args=dict(RoleSessionName='aos-'+installation_id.hex+'-'+role,DurationSeconds=3600),cache=self._cache)
        def refresh():
            try:
                if self._closed:raise ValueError()
                return fetcher.fetch_credentials()
            except Exception:raise OwnershipError('AWS workload credential unavailable') from None
        credentials=DeferredRefreshableCredentials(refresh_using=refresh,method=_Credentials.METHOD)
        session.register_component('credential_provider',CredentialResolver([_Credentials(credentials)]))
        self._session=boto3.Session(botocore_session=session)

    def _current(self):
        if self._closed:raise OwnershipError('AWS workload session closed')

    def get_available_regions(self,service):
        self._current()
        return self._session.get_available_regions(service)

    def client(self,service,**options):
        self._current()
        config=options.get('config')
        allowed=({'secretsmanager'} if self.role=='storage' else
            {'secretsmanager','rds'} if self.role=='recovery' else {'secretsmanager','scheduler'})
        if (type(service) is not str or service not in allowed
                or set(options)!={'region_name','verify','use_ssl','endpoint_url','config'}
                or options['region_name']!=self.region or options['verify'] is not True or options['use_ssl'] is not True
                or options['endpoint_url']!='https://'+service+'.'+self.region+'.amazonaws.com'
                or not isinstance(config,Config) or config.signature_version!='v4'
                or (config.connect_timeout,config.read_timeout,config.max_pool_connections)!=(2,2,4)
                or config.proxies!={} or config.retries!={'total_max_attempts':1} or config.defaults_mode!='standard'):
            raise OwnershipError('Unsupported AWS workload service')
        client=self._session.client(service,**options);self._clients.append(client)
        return client

    def close(self):
        if not self._closed:
            self._closed=True
            for client in reversed(self._clients):client.close()
            self._cache.clear()
