"""Exact independent repair of the two original AWS private key sets.

Uses existing key protection/repair and finite release authority. No rotation,
new key adoption, certificate publication, SQL or Cloud history mutation.
"""
import base64
import hashlib
import stat
from pathlib import Path

from agentic_os.contracts.canonical import canonical_bytes,parse_canonical_json
from agentic_os.adapters.local.artifacts import LocalKeys,checked_id
from agentic_os.adapters.local.files import OwnershipError,check_private,private_read,private_write
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.resources import ensure_private,file_lock,read_signed
from agentic_os.adapters.local import recovery_gate as gate
from agentic_os.adapters.local.recovery_key_operations import (
    _external,protect_keys,unprotect_keys,check_key_repair,repair_key_files)
from agentic_os.adapters.local.recovery_key_continuity import sha
from agentic_os.adapters.local.recovery_maintenance import artifact_pin,_operation,FILE
from . import readiness,renewal

PROFILE='aws-independent-private-key-backup/1'
FIELDS={'profile','installationId','runId','generation','certificateDigest','artifact',
    'materialsDigest','authority','files'}
PURPOSES={'history':'keys','knowledge':'protected-knowledge/keys'}


def _artifact(wheel):
    pin=artifact_pin(wheel)
    return dict(artifactDigest=pin['artifactDigest'],releaseDigest=pin['releaseDigest'],
        contentDigest=renewal._wheel_content(wheel,pin['artifactDigest']))


def _raw_proof(path):
    if renewal.selected(path):
        selected=renewal._selector(path)
        return read_signed(_operation(path,selected['commandId'])/'ready.json',path.parent/'owner.key',maximum=1024**2)
    return read_signed(path.parent/readiness.FILE,path.parent/'owner.key',maximum=65536)


def _proof(path,wheel,*,allow_expired=False):
    selected=_artifact(wheel);raw=_raw_proof(path)
    if renewal.selected(path):
        value=renewal.certificate(path,raw['installationDigest'],allow_expired=allow_expired,
            _operator_release=selected['releaseDigest'],_operator_content=selected['contentDigest'])
    else:
        value=readiness._initial_metadata(path,raw['installationDigest'],allow_expired=allow_expired,current_release=False)
        if value.get('contentDigest')!=selected['contentDigest'] or value['releaseDigest']!=selected['releaseDigest']:
            raise OwnershipError('Exact reviewed AWS key release required')
    state=gate.state(path)
    if state['mode']!='READY' or state['generation']!=value['generation']:
        raise OwnershipError('Original AWS key release generation required')
    return value,selected


def _authority(path):
    """Authenticate unchanged control bytes without hydrating missing live keys.

    Recovery compares the exact snapshot authenticated at backup. It never
    bypasses material checks in a runtime certificate or adopts a new release.
    """
    manifest=load_manifest(path)
    if manifest['profile']!='aws-eks/1' or any((path.parent/n).exists() or (path.parent/n).is_symlink() for n in readiness.MARKERS):
        raise OwnershipError('Original fresh AWS key authority required')
    names={'manifest.json','operator-state.json','recovery-gate.json','knowledge-key-binding.json',readiness.FILE}
    if renewal.selected(path):
        names.add(FILE);selected=renewal._selector(path);op=_operation(path,selected['commandId'])
        allowed={'prior-ready.json','intent.json','work-before.json','history.json','ready.json'}
        if selected['profile'] in renewal.MATERIAL_PROFILES:
            intent=read_signed(op/'intent.json',path.parent/'owner.key',maximum=1024**2)
            if 'keyRotation' in intent:
                from .key_rotation import STAGE_FILE
                allowed.add(STAGE_FILE)
            if 'operatorRotation' in intent:
                from .operator_rotation import STAGE_FILE
                allowed.update({STAGE_FILE,'prior-operator.key'})
        actual={p.name for p in op.iterdir()}
        if not {'prior-ready.json','intent.json','history.json','ready.json'}<=actual or actual-allowed:
            raise OwnershipError('Original AWS key operation inventory differs')
        names.update(str((op/name).relative_to(path.parent)) for name in actual)
    result={}
    for name in sorted(names):
        file=path.parent/name
        check_private(file)
        if file.lstat().st_nlink!=1:raise OwnershipError('Shared AWS key authority file')
        if name=='manifest.json':load_manifest(file)
        elif name=='operator-state.json':
            from agentic_os.adapters.local.operator import read_state
            read_state(path.parent)
        elif name.endswith('/prior-operator.key'):
            if len(private_read(file,32))!=32:raise OwnershipError('Retained original operator key differs')
        else:read_signed(file,path.parent/'owner.key',maximum=16*1024**2)
        result[name]=hashlib.sha256(private_read(file,16*1024**2)).hexdigest()
    return result


def _key_files(directory):
    keys=LocalKeys(directory);active=keys.active();values={}
    for file in directory.iterdir():
        name=file.name
        if name!='active.json':
            if not name.endswith('.key'):raise OwnershipError('Unknown AWS private key material')
            checked_id(name[:-4])
        if file.lstat().st_nlink!=1:raise OwnershipError('Shared AWS private key material')
        raw=private_read(file,128)
        if name!='active.json' and len(raw)!=32:raise OwnershipError('Invalid AWS private key size')
        values[name]=raw
    if not 2<=len(values)<=129 or active+'.key' not in values:
        raise OwnershipError('AWS private key inventory unavailable')
    return values


def backup(path,token,*,expected_generation,destination,recovery_key,artifact):
    path=Path(path);verify_operator(path,token)
    destination,recovery_key=_external(path,destination,recovery_key)
    if destination.exists() or destination.is_symlink():raise OwnershipError('Independent key backup already exists')
    with file_lock(path.parent/'recovery-gate.lock',timeout=2,shared=True):
        verify_operator(path,token);value,pin=_proof(path,artifact)
        if type(expected_generation) is not int or value['generation']!=expected_generation:
            raise OwnershipError('Current AWS key generation required')
        authority=_authority(path)
        contents={purpose:_key_files(path.parent/name) for purpose,name in PURPOSES.items()}
        metadata=dict(profile=PROFILE,installationId=value['installationId'],runId=value['runId'],generation=expected_generation,
            certificateDigest=sha(value),artifact=pin,materialsDigest=value['materialsDigest'],authority=authority,
            files={purpose:{name:dict(sha256=hashlib.sha256(raw).hexdigest(),size=len(raw),mode=stat.S_IMODE((path.parent/PURPOSES[purpose]/name).lstat().st_mode)) for name,raw in files.items()}
                for purpose,files in contents.items()})
        plain=canonical_bytes({purpose:{name:base64.b64encode(raw).decode('ascii') for name,raw in files.items()}
            for purpose,files in contents.items()})
        envelope=protect_keys(path,metadata,plain,recovery_key)
        if _proof(path,artifact)[0]!=value or _authority(path)!=authority:
            raise OwnershipError('AWS key authority changed during backup')
        private_write(destination,canonical_bytes(envelope))
    return dict(profile=PROFILE,state='PROTECTED',generation=expected_generation,purposes=sorted(PURPOSES),runtimeReady=False)


def recover(path,token,*,expected_generation,backup_path,recovery_key,artifact,command_id):
    path=Path(path);verify_operator(path,token);checked_id(command_id)
    backup_path,recovery_key=_external(path,backup_path,recovery_key)
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        verify_operator(path,token);manifest=load_manifest(path);state=gate.state(path)
        try:selected=read_signed(backup_path,path.parent/'owner.key',maximum=256*1024)
        except (OSError,ValueError):raise OwnershipError('Independent AWS key backup unavailable') from None
        try:
            if type(selected) is not dict or set(selected)!=FIELDS|{'nonce','ciphertext'}:raise ValueError()
            metadata={k:selected[k] for k in FIELDS}
            if (metadata['profile']!=PROFILE or metadata['installationId']!=manifest['installationId'] or metadata['runId']!=manifest['runId']
                    or type(expected_generation) is not int or metadata['generation']!=expected_generation
                    or state['mode']!='READY' or state['generation']!=expected_generation
                    or metadata['certificateDigest']!=sha(_raw_proof(path)) or metadata['materialsDigest']!=_raw_proof(path)['materialsDigest']
                    or metadata['artifact']!=_artifact(artifact)
                    or metadata['authority']!=_authority(path) or set(metadata['files'])!=set(PURPOSES)):
                raise ValueError()
            decoded=parse_canonical_json(unprotect_keys(metadata,selected,recovery_key,maximum=65552))
            if type(decoded) is not dict or set(decoded)!=set(PURPOSES):raise ValueError()
            restored={}
            for purpose,encoded in decoded.items():
                if type(encoded) is not dict or not 2<=len(encoded)<=129 or set(encoded)!=set(metadata['files'][purpose]):raise ValueError()
                files={name:base64.b64decode(raw,validate=True) for name,raw in encoded.items()}
                for name,raw in files.items():
                    if name=='active.json':
                        active=parse_canonical_json(raw)
                        if type(active) is not dict or set(active)!={'id'} or checked_id(active['id'])+'.key' not in files:raise ValueError()
                    elif not name.endswith('.key') or checked_id(name[:-4])+'.key'!=name or len(raw)!=32:raise ValueError()
                    record=metadata['files'][purpose][name]
                    if (type(record) is not dict or set(record)!={'sha256','size','mode'}
                            or type(record['mode']) is not int or record['mode'] not in {0o400,0o600}
                            or len(raw)>128 or type(record['size']) is not int or record['size']!=len(raw)
                            or record['sha256']!=hashlib.sha256(raw).hexdigest()):raise ValueError()
                if 'active.json' not in files:raise ValueError()
                restored[purpose]=files
            expected_materials=readiness._material_records_digest(metadata['files']['history'],metadata['files']['knowledge'],
                read_signed(path.parent/'knowledge-key-binding.json',path.parent/'owner.key'),
                hashlib.sha256(private_read(path.parent/'operator-state.json')).hexdigest())
            if expected_materials!=metadata['materialsDigest']:raise ValueError()
        except (ValueError,TypeError,KeyError):raise OwnershipError('Independent AWS key recovery authority unavailable') from None
        # Validate both inventories before any repair or directory creation.
        repair_root=path.parent/'recovery-key-repair'/command_id
        for purpose,name in PURPOSES.items():check_key_repair(path.parent/name,restored[purpose],repair_root/purpose)
        verify_operator(path,token)
        if _authority(path)!=metadata['authority']:raise OwnershipError('AWS key authority changed before repair')
        ensure_private(repair_root.parent);ensure_private(repair_root)
        for purpose in PURPOSES:ensure_private(repair_root/purpose)
        for purpose,name in PURPOSES.items():
            repair_key_files(path.parent/name,restored[purpose],repair_root/purpose)
            for file,record in metadata['files'][purpose].items():(path.parent/name/file).chmod(record['mode'])
        if readiness._materials(path)!=metadata['materialsDigest'] or _proof(path,artifact,allow_expired=True)[0]!=_raw_proof(path):
            raise OwnershipError('Recovered AWS key material differs')
        if gate.state(path)!=state or _authority(path)!=metadata['authority']:raise OwnershipError('AWS key repair authority changed')
    return dict(profile=PROFILE,state='RECOVERED',generation=expected_generation,purposes=sorted(PURPOSES),
        runtimeReady=False,unknownUsageHeld=True,originalDeadlinesUnchanged=True)
