"""Operator-only managed RDS snapshot metadata, never runtime release.

Supported RDS APIs inspect an existing private encrypted snapshot. No snapshot,
instance, namespace, key, export, grant or workflow is created or restored here.
Coordinated OS files/control/privacy/history reconciliation remains mandatory.
"""
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime,timezone
from pathlib import Path
import re
from uuid import UUID

from agentic_os.adapters.local.files import OwnershipError,private_read
from agentic_os.adapters.configured_installation import closed,canonical_file
from agentic_os.contracts.canonical import parse_canonical_json
from .backend import AWSOperator,AWSSecrets,SecretPin,regional_client,secrets_client
from .workload import AWSWebIdentitySession,role_arn

CONFIGURATION='aws-managed-snapshot-inspection/1'


@dataclass(frozen=True)
class SnapshotPin:
    installation_id:UUID
    region:str
    account:str
    instance_id:str
    resource_id:str
    identifier:str
    kms_key_arn:str
    engine_version:str
    port:int
    capture_digest:str
    source_run:str
    source_generation:int

    def __post_init__(self):
        try:
            role_arn(self.installation_id,self.account,'recovery')
            if (type(self.region) is not str or re.fullmatch(r'[a-z]{2}(?:-[a-z]+)+-[0-9]+',self.region) is None
                    or self.region.startswith(('cn-','us-gov-','us-iso'))):raise ValueError()
            prefix='aos-'+self.installation_id.hex+'-'
            if (type(self.instance_id) is not str or not self.instance_id.startswith(prefix)
                    or not 1<=len(self.instance_id)<=63 or re.fullmatch(r'[a-z][a-z0-9]*(?:-[a-z0-9]+)*',self.instance_id) is None
                    or type(self.resource_id) is not str or re.fullmatch(r'db-[A-Za-z0-9]{10,64}',self.resource_id) is None
                    or type(self.identifier) is not str or re.fullmatch(prefix+r'[a-f0-9]{32}',self.identifier) is None
                    or type(self.kms_key_arn) is not str or re.fullmatch('arn:aws:kms:'+re.escape(self.region)+':'+self.account+
                        r':key/(?:[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}|mrk-[a-f0-9]{32})',self.kms_key_arn) is None
                    or self.engine_version!='16.15' or type(self.port) is not int or not 1<=self.port<=65535
                    or type(self.capture_digest) is not str or re.fullmatch('[a-f0-9]{64}',self.capture_digest) is None
                    or type(self.source_run) is not str or re.fullmatch('[a-f0-9]{12}',self.source_run) is None
                    or type(self.source_generation) is not int or not 1<=self.source_generation<=2**53-1):raise ValueError()
        except Exception:raise OwnershipError('Explicit installation-owned encrypted RDS snapshot pins required') from None

    @property
    def arn(self):return 'arn:aws:rds:'+self.region+':'+self.account+':snapshot:'+self.identifier

    @property
    def tags(self):
        return {'agentic-os.installation':str(self.installation_id),'agentic-os.capture':self.capture_digest,
            'agentic-os.source-run':self.source_run,'agentic-os.source-generation':str(self.source_generation)}

    def permissions(self):
        return dict(Version='2012-10-17',Statement=[dict(Effect='Allow',Resource=self.arn,
            Action=['rds:DescribeDBSnapshots','rds:DescribeDBSnapshotAttributes','rds:ListTagsForResource'],
            Condition=dict(StringEquals={'aws:ResourceTag/agentic-os.installation':str(self.installation_id)}))])


def configuration(document):
    """Validate all source/credential references before creating SDK clients."""
    from copy import deepcopy
    from agentic_os.adapters.local.ownership import load_manifest
    try:
        value=deepcopy(document)
        closed(value,{'schema','manifest','region','account','token_root','operator','snapshot'})
        if value['schema']!=CONFIGURATION:raise ValueError()
        manifest=canonical_file(value['manifest']);canonical_file(value['token_root'])
        owned=load_manifest(manifest)
        closed(value['operator'],{'pin','generation'});closed(value['operator']['pin'],{'arn','version'})
        pin=SecretPin(**value['operator']['pin'])
        prefix='arn:aws:secretsmanager:'+value['region']+':'+value['account']+':secret:agentic-os/'+owned['installationId']+'/control/'
        if (not pin.arn.startswith(prefix) or type(value['operator']['generation']) is not int
                or not 1<=value['operator']['generation']<=2**53-1):raise ValueError()
        closed(value['snapshot'],{'instance_id','resource_id','identifier','kms_key_arn','engine_version','port',
            'capture_digest','source_run','source_generation'})
        SnapshotPin(UUID(owned['installationId']),value['region'],value['account'],**value['snapshot'])
        return value
    except Exception:raise OwnershipError('Invalid managed RDS recovery inspection configuration') from None


def load_configuration(path):
    try:return configuration(parse_canonical_json(private_read(canonical_file(str(path)),65536)))
    except Exception:raise OwnershipError('Managed RDS recovery inspection configuration unavailable') from None


def plan(document):
    from agentic_os.adapters.local.ownership import load_manifest
    value=configuration(document);ident=UUID(load_manifest(Path(value['manifest']))['installationId'])
    pin=SnapshotPin(ident,value['region'],value['account'],**value['snapshot'])
    policy=pin.permissions()
    policy['Statement'].append(dict(Effect='Allow',Action='secretsmanager:GetSecretValue',
        Resource=value['operator']['pin']['arn'],Condition=dict(StringEquals={
            'secretsmanager:VersionId':value['operator']['pin']['version']})))
    return dict(profile=CONFIGURATION,state='configuration-planned',roleArn=role_arn(ident,value['account'],'recovery'),
        permissions=policy,snapshotArn=pin.arn,runtimeReady=False,osControlReconciled=False,billableActions=[])


def inspect_snapshot(client,pin):
    """One bounded supported API inspection; never a recovery/Ready proof."""
    if (type(pin) is not SnapshotPin or client.meta.region_name!=pin.region
            or client.meta.endpoint_url!='https://rds.'+pin.region+'.amazonaws.com'):
        raise OwnershipError('Explicit regional RDS snapshot client required')
    try:
        result=client.describe_db_snapshots(DBSnapshotIdentifier=pin.identifier,SnapshotType='manual',
            IncludePublic=False,IncludeShared=False,MaxRecords=20)
        if result.get('Marker') or type(result.get('DBSnapshots')) is not list or len(result['DBSnapshots'])!=1:raise ValueError()
        value=result['DBSnapshots'][0]
        expected=dict(DBSnapshotIdentifier=pin.identifier,DBSnapshotArn=pin.arn,DBInstanceIdentifier=pin.instance_id,
            DbiResourceId=pin.resource_id,Engine='postgres',EngineVersion=pin.engine_version,Port=pin.port,
            Status='available',SnapshotType='manual',Encrypted=True,PercentProgress=100,KmsKeyId=pin.kms_key_arn)
        if (any(type(value.get(k)) is not type(v) or value[k]!=v for k,v in expected.items())
                or value.get('SourceRegion') or value.get('SourceDBSnapshotIdentifier')
                or value.get('SnapshotTarget') not in {None,'region'}):raise ValueError()
        created=value.get('SnapshotCreateTime')
        if not isinstance(created,datetime) or created.tzinfo is None or created.utcoffset() is None:raise ValueError()
        attributes=client.describe_db_snapshot_attributes(DBSnapshotIdentifier=pin.identifier)['DBSnapshotAttributesResult']
        if (attributes.get('DBSnapshotIdentifier')!=pin.identifier or attributes.get('DBSnapshotAttributes')!=[
                dict(AttributeName='restore',AttributeValues=[])]):raise ValueError()
        tags=client.list_tags_for_resource(ResourceName=pin.arn)['TagList']
        if (type(tags) is not list or len(tags)>50 or any(type(t) is not dict or set(t)!={'Key','Value'}
                or type(t['Key']) is not str or type(t['Value']) is not str for t in tags)
                or len({t['Key'] for t in tags})!=len(tags)):raise ValueError()
        observed={t['Key']:t['Value'] for t in tags}
        if any(observed.get(k)!=v for k,v in pin.tags.items()):raise ValueError()
        return dict(profile=CONFIGURATION,state='managed-snapshot-available',snapshotArn=pin.arn,
            snapshotCreatedAt=created.astimezone(timezone.utc).isoformat().replace('+00:00','Z'),
            encrypted=True,privateRestoreAttributes=True,captureTagsMatched=True,
            runtimeReady=False,osControlReconciled=False,cloudHistoryReconciled=False)
    except Exception:raise OwnershipError('Managed RDS snapshot unavailable or its ownership/privacy pins differ') from None


@contextmanager
def configured_inspector(document):
    from agentic_os.adapters.local.ownership import load_manifest
    from agentic_os.adapters.kubernetes.projected_token import ProjectedTokenReader
    value=configuration(document);path=Path(value['manifest']);ident=UUID(load_manifest(path)['installationId'])
    pin=SnapshotPin(ident,value['region'],value['account'],**value['snapshot'])
    session=AWSWebIdentitySession(installation_id=ident,account=value['account'],region=value['region'],role='recovery',
        token_provider=ProjectedTokenReader(Path(value['token_root'])).read)
    try:
        secrets=AWSSecrets(secrets_client(session,value['region']),region=value['region'],account=value['account'],installation_id=ident)
        operator=AWSOperator(secrets,SecretPin(**value['operator']['pin']),generation=value['operator']['generation'])
        yield regional_client(session,'rds',value['region']),pin,operator
    finally:session.close()


def inspect_configuration(document,token,*,expected_generation):
    from agentic_os.adapters.local import recovery_gate as gate
    from agentic_os.adapters.local.operator import verify_operator
    value=configuration(document);path=Path(value['manifest'])
    def current():
        verify_operator(path,token);state=gate.state(path)
        if (type(expected_generation) is not int or state['generation']!=expected_generation
                or state['mode'] not in {'PARKED','BLOCKED'}):
            raise OwnershipError('Exact held recovery operator generation required')
        return state
    before=current()
    with configured_inspector(value) as (client,pin,operator):
        identity=operator(token);result=inspect_snapshot(client,pin)
        if operator(token)!=identity or current()!=before:raise OwnershipError('Recovery inspection checkpoint changed')
    return result


def inspect_source(client,pin,endpoint):
    """Bind the configured TLS endpoint to the exact dedicated source resource."""
    _inspect_instance(client,pin,endpoint)
    return dict(profile='aws-managed-source-inspection/1',instanceArn='arn:aws:rds:'+pin.region+':'+pin.account+':db:'+pin.instance_id,
        resourceId=pin.resource_id,endpoint=endpoint,port=pin.port,encrypted=True,publiclyAccessible=False,
        installationId=str(pin.installation_id),runtimeReady=False)


def _inspect_instance(client,pin,endpoint):
    if (type(pin) is not SnapshotPin or type(endpoint) is not str
            or re.fullmatch(r'[a-z0-9-]+\.[a-z0-9-]+\.'+re.escape(pin.region)+r'\.rds\.amazonaws\.com',endpoint) is None
            or client.meta.region_name!=pin.region or client.meta.endpoint_url!='https://rds.'+pin.region+'.amazonaws.com'):
        raise OwnershipError('Pinned regional source instance required')
    arn='arn:aws:rds:'+pin.region+':'+pin.account+':db:'+pin.instance_id
    try:
        result=client.describe_db_instances(DBInstanceIdentifier=pin.instance_id)
        if result.get('Marker') or type(result.get('DBInstances')) is not list or len(result['DBInstances'])!=1:raise ValueError()
        value=result['DBInstances'][0]
        expected=dict(DBInstanceIdentifier=pin.instance_id,DBInstanceArn=arn,DbiResourceId=pin.resource_id,
            Engine='postgres',EngineVersion=pin.engine_version,DBInstanceStatus='available',
            StorageEncrypted=True,KmsKeyId=pin.kms_key_arn,PubliclyAccessible=False)
        if (any(type(value.get(k)) is not type(v) or value[k]!=v for k,v in expected.items())
                or type(value.get('Endpoint')) is not dict
                or value['Endpoint'].get('Address')!=endpoint or type(value['Endpoint'].get('Port')) is not int
                or value['Endpoint']['Port']!=pin.port):raise ValueError()
        tags=client.list_tags_for_resource(ResourceName=arn)['TagList']
        if (type(tags) is not list or len(tags)>50 or any(type(t) is not dict or set(t)!={'Key','Value'}
                or type(t['Key']) is not str or type(t['Value']) is not str for t in tags)
                or len({t['Key'] for t in tags})!=len(tags)
                or {t['Key']:t['Value'] for t in tags}.get('agentic-os.installation')!=str(pin.installation_id)):
            raise ValueError()
    except Exception:raise OwnershipError('Managed source endpoint or ownership differs') from None
    return value,{t['Key']:t['Value'] for t in tags}


def inspect_target(client,pin,endpoint,*,snapshot):
    """Inspect a separately provisioned target; tags alone never prove its data."""
    value,tags=_inspect_instance(client,pin,endpoint)
    try:
        created=value['InstanceCreateTime']
        original=datetime.fromisoformat(snapshot['snapshotCreatedAt'].replace('Z','+00:00'))
        if (snapshot.get('profile')!=CONFIGURATION or snapshot.get('snapshotArn')!=pin.arn
                or snapshot.get('privateRestoreAttributes') is not True or snapshot.get('captureTagsMatched') is not True
                or not isinstance(created,datetime) or created.tzinfo is None or created.utcoffset() is None
                or created<original or created>datetime.now(timezone.utc)
                or any(tags.get(k)!=v for k,v in (pin.tags|{'agentic-os.snapshot':snapshot['snapshotArn']}).items())):raise ValueError()
    except Exception:raise OwnershipError('Managed target creation or snapshot lineage differs') from None
    return dict(profile='aws-managed-target-inspection/1',instanceArn='arn:aws:rds:'+pin.region+':'+pin.account+':db:'+pin.instance_id,
        resourceId=pin.resource_id,endpoint=endpoint,port=pin.port,encrypted=True,publiclyAccessible=False,
        installationId=str(pin.installation_id),snapshotArn=snapshot['snapshotArn'],captureDigest=pin.capture_digest,
        instanceCreatedAt=created.astimezone(timezone.utc).isoformat().replace('+00:00','Z'),runtimeReady=False)


def source_permissions(pin):
    if type(pin) is not SnapshotPin:raise OwnershipError('Pinned source instance required')
    arn='arn:aws:rds:'+pin.region+':'+pin.account+':db:'+pin.instance_id
    return dict(Effect='Allow',Resource=arn,Action=['rds:DescribeDBInstances','rds:ListTagsForResource'],
        Condition=dict(StringEquals={'aws:ResourceTag/agentic-os.installation':str(pin.installation_id)}))
