"""Finite initial control release over existing installation and recovery ports.

This is not restored-data recovery or a production qualification certificate.
No task, user, resource balance, deadline, namespace or AWS resource is created.
"""
import asyncio
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import timedelta
import hashlib
from pathlib import Path
import re
import time

from agentic_os.adapters.configured_installation import closed,canonical_file
from agentic_os.adapters.local.files import OwnershipError,check_private,private_read
from agentic_os.adapters.local.ownership import load_manifest
from agentic_os.adapters.local.operator import verify_operator
from agentic_os.adapters.local.resources import file_lock,read_signed,write_signed,tree_inventory
from agentic_os.adapters.local import recovery_gate as gate
from agentic_os.adapters.local.recovery_ready import release_digest,MARKERS
from agentic_os.contracts.canonical import canonical_bytes
from . import storage
from .bootstrap import private_knowledge_keys
from .temporal import load_operator_configuration,configured_operator_connection

LEGACY_PROFILE='aws-initial-control-release/1'
PROFILE='aws-initial-control-release/2'
INITIAL_PROFILES={LEGACY_PROFILE,PROFILE}
FILE='aws-initial-ready.json'
CONFIGURATION='aws-initial-readiness/1'
CHECKS={'schemas','runtimeRoles','privateMaterials','embedding','cloudNamespace','emptyInstallation'}
FIELDS={'profile','installationId','runId','generation','installationDigest','cloudConfiguration','cloudDigest',
    'cloud','releaseDigest','materialsDigest','issuedAt','expiresAt','checks'}


def installation_digest(document):
    from agentic_os.adapters.configured_installation import installation_configuration
    installation_configuration(document)
    return hashlib.sha256(canonical_bytes(document)).hexdigest()


def _materials(path):
    from agentic_os.adapters.local.artifacts import LocalKeys
    primary=LocalKeys(path.parent/'keys');primary._key(primary.active())
    knowledge=private_knowledge_keys(path);knowledge._key(knowledge.active())
    records={}
    for name,directory in (('privateHistory',primary.directory),('privateKnowledge',knowledge.directory)):
        inventory=tree_inventory(directory,maximum=128*1024)
        if not 2<=len(inventory['files'])<=129:raise OwnershipError('Initial private key inventory unavailable')
        records[name]=inventory['files']
    return _material_records_digest(records['privateHistory'],records['privateKnowledge'],
        read_signed(path.parent/'knowledge-key-binding.json',path.parent/'owner.key'),
        hashlib.sha256(private_read(path.parent/'operator-state.json')).hexdigest())


def _material_records_digest(history,knowledge,binding,operator):
    return hashlib.sha256(canonical_bytes(dict(privateHistory=history,privateKnowledge=knowledge,
        knowledgeBinding=binding,operatorStateDigest=operator))).hexdigest()


def configuration(document,*,expected_run_id=None):
    try:
        closed(document,{'schema','stores','cloud_configuration','release_seconds'})
        if document['schema']!=CONFIGURATION:raise ValueError()
        stores=storage.configuration(document['stores']);storage.plan(document['stores'])
        if any(stores['expected_heads'][name]!=storage.component_head(name,stores['installation']) for name in storage.COMPONENTS):raise ValueError()
        path=canonical_file(document['cloud_configuration']);cloud=load_operator_configuration(path)
        if (cloud['installation']!=document['stores']['installation']
                or type(document['release_seconds']) is not int or not 60<=document['release_seconds']<=86400):raise ValueError()
        manifest=load_manifest(stores['installation']['manifest'])
        if stores['installation']['aws'].get('private_files')=='aws-shared-private65534/1':
            root=Path(manifest['root'])
            if (manifest['ownerUid']!=65534 or not path.is_relative_to(root)
                    or not canonical_file(cloud['server_ca']).is_relative_to(root)):raise ValueError()
        selected=manifest['runId'] if expected_run_id is None else expected_run_id
        if (type(selected) is not str or re.fullmatch('[0-9a-f]{12}',selected) is None
                or cloud['run_id']!=selected):raise ValueError()
        return stores,cloud,path
    except Exception:raise OwnershipError('Invalid initial readiness configuration') from None


def load_configuration(path):
    from agentic_os.contracts.canonical import parse_canonical_json
    try:
        document=parse_canonical_json(private_read(canonical_file(str(path)),65536));configuration(document);return document
    except Exception:raise OwnershipError('Initial readiness configuration unavailable') from None


def _cloud_pin(cloud):
    from .temporal import selected_namespace
    return dict(namespace=cloud['namespace'],namespaceId=cloud['namespace_id'],retentionDays=cloud['retention_days'],
        endpoint=selected_namespace(cloud).host,serverCASha256=cloud['server_ca_sha256'],runId=cloud['run_id'],
        identityArn=cloud['identity']['pin']['arn'],identityVersion=cloud['identity']['pin']['version'])


def _initial_metadata(path,digest,*,allow_expired=False,current_release=True,_historical_materials=None,_historical_operator=None):
    """Authenticate immutable initial ancestry; this alone grants no runtime."""
    path=Path(path);manifest=load_manifest(path)
    if manifest['profile']!='aws-eks/1' or any((path.parent/name).exists() or (path.parent/name).is_symlink() for name in MARKERS):
        raise OwnershipError('Initial control proof cannot replace restored recovery')
    file=path.parent/FILE;check_private(file)
    if file.lstat().st_nlink!=1:raise OwnershipError('Initial control proof has shared storage')
    value=read_signed(file,path.parent/'owner.key',maximum=65536)
    try:
        full=value.get('profile')==PROFILE
        closed(value,FIELDS|{'contentDigest'} if full else FIELDS)
        now=int(time.time())
        if (value['profile'] not in INITIAL_PROFILES or value['installationId']!=manifest['installationId'] or value['runId']!=manifest['runId']
                or type(value['generation']) is not int or value['generation']!=2 or value['installationDigest']!=digest
                or type(digest) is not str or re.fullmatch('[a-f0-9]{64}',digest) is None
                or type(value['issuedAt']) is not int or type(value['expiresAt']) is not int
                or not value['issuedAt']<=now or not allow_expired and now>=value['expiresAt']
                or not 60<=value['expiresAt']-value['issuedAt']<=86400
                or type(value['checks']) is not dict or set(value['checks'])!=CHECKS
                or any(v is not True for v in value['checks'].values())
                or full and (type(value['contentDigest']) is not str or re.fullmatch('[a-f0-9]{64}',value['contentDigest']) is None)
                or current_release and not full):raise ValueError()
        material_digest=_materials(path) if _historical_materials is None else None
        if _historical_materials is not None:
            if current_release:raise ValueError()
            from .key_rotation import historical_digest
            material_digest=historical_digest(path,_historical_materials,_historical_operator)
        cloud_path=canonical_file(value['cloudConfiguration']);cloud=load_operator_configuration(cloud_path)
        if (hashlib.sha256(canonical_bytes(cloud)).hexdigest()!=value['cloudDigest'] or _cloud_pin(cloud)!=value['cloud']
                or installation_digest(cloud['installation'])!=digest
                or type(value['releaseDigest']) is not str or re.fullmatch('[a-f0-9]{64}',value['releaseDigest']) is None
                or current_release and value['releaseDigest']!=release_digest()
                or current_release and value['contentDigest']!=_runtime_content()
                or value['materialsDigest']!=material_digest):raise ValueError()
    except Exception:raise OwnershipError('Current initial control release unavailable') from None
    return value


def _runtime_content():
    from .renewal import _runtime_content as measure
    return measure()


def _certificate(path,digest,*,allow_expired=False):
    value=_initial_metadata(path,digest,allow_expired=allow_expired);current=gate.state(Path(path))
    if current['mode']!='READY' or current['generation']!=value['generation']:
        raise OwnershipError('Current initial control release unavailable')
    return value


def certificate(path,digest):
    try:
        from agentic_os.adapters.local.recovery_ready import restored
        if restored(path):
            from .managed_restore import certificate as recovered
            return recovered(path,digest)
        from . import renewal
        if renewal.selected(path):return renewal.certificate(path,digest)
        return _certificate(path,digest)
    except Exception:raise OwnershipError('Current initial control release unavailable') from None


class InitialTransactionRelease:
    def __init__(self,path,digest):
        self.path=Path(path);self.digest=digest;self._release=self._read()

    def _read(self):return certificate(self.path,self.digest)

    def verify(self):
        if self._read()!=self._release:raise OwnershipError('Initial transaction release changed')

    def verify_temporal(self,connection):
        from agentic_os.adapters.temporal.connection import TemporalConnection
        from .temporal import AWSCloudTemporalIdentity
        self.verify();pin=self._release['cloud']
        if (type(connection) is not TemporalConnection or str(connection.installation.installation_id)!=self._release['installationId']
                or connection.installation.root!=self.path.parent
                or type(connection.identity) is not AWSCloudTemporalIdentity
                or connection.identity.pin.arn!=pin['identityArn'] or connection.identity.pin.version!=pin['identityVersion']
                or connection.cloud is None or connection.namespace!=pin['namespace'] or connection.cloud.namespace_id!=pin['namespaceId']
                or connection.cloud.retention_days!=pin['retentionDays'] or connection.host!=pin['endpoint']
                or connection.server_ca_sha256!=pin['serverCASha256'] or connection.run_id!=pin['runId']):
            raise OwnershipError('Initial runtime Cloud connection differs')


class _RestoredConfigurationBinding(InitialTransactionRelease):
    """Adapter checks alongside, never in place of, the shared release proof."""
    def _read(self):
        from copy import deepcopy
        from .managed_restore import configuration_certificate
        from agentic_os.adapters.local.recovery_ready import _proof_inventory
        inventory=_proof_inventory(self.path,include_keys=False)
        if hasattr(self,'_binding_inventory'):
            if (configuration_certificate is not self._binding_reader
                    or inventory!=self._binding_inventory):
                raise OwnershipError('Restored transaction configuration changed')
            return deepcopy(self._binding_metadata)
        value=configuration_certificate(self.path,self.digest)
        if _proof_inventory(self.path,include_keys=False)!=inventory:
            raise OwnershipError('Restored transaction configuration changed')
        # This object lives only inside the existing short, gate-locked SQL
        # transaction. Every use fingerprints all referenced file contents;
        # shared release, expiry and current owner checks remain independent.
        self._binding_inventory=inventory
        self._binding_reader=configuration_certificate
        self._binding_metadata=deepcopy(value)
        return value


@dataclass(frozen=True)
class InitialControlRelease:
    manifest:Path
    digest:str

    def __post_init__(self):
        if (not isinstance(self.manifest,Path) or not self.manifest.is_absolute() or self.manifest.resolve()!=self.manifest
                or self.manifest.name!='manifest.json' or type(self.digest) is not str or re.fullmatch('[a-f0-9]{64}',self.digest) is None
                or load_manifest(self.manifest)['profile']!='aws-eks/1'):
            raise OwnershipError('Exact initial control installation and configuration required')

    @contextmanager
    def __call__(self):
        with file_lock(self.manifest.parent/'recovery-gate.lock',timeout=2,shared=True):
            from agentic_os.adapters.local.recovery_ready import restored,TransactionRelease
            if restored(self.manifest):
                # Identity and owner guards consume the shared restored proof.
                # Keep the exact AWS configuration/Cloud checks as additional
                # adapter checks, including before the actual SQL COMMIT.
                binding=_RestoredConfigurationBinding(self.manifest,self.digest)
                proof=TransactionRelease(self.manifest,binding_verify=binding.verify,temporal_verify=binding.verify_temporal)
            else:proof=InitialTransactionRelease(self.manifest,self.digest)
            yield proof
            proof.verify()


def _runtime_stores(connection,token,*,require_empty):
    """Actual read-only roles; visibility alone never proves private emptiness."""
    installation=connection.installation;installation.verify_operator(token)
    components=installation.require_components(installation.root/'manifest.json')
    for name,connect in [('control',installation.connect),('retrieval',components.retrieval),('knowledge',components.knowledge),
            ('knowledge_public',components.knowledge_public),('knowledge_operator',components.knowledge_operator)]:
        with connect() as db:
            db.rollback();db.execute('SET TRANSACTION READ ONLY')
            db.execute("SET LOCAL lock_timeout='2s'");db.execute("SET LOCAL statement_timeout='3s'")
            tables={'control':('os_applications','os_budget_roots','os_tasks'),
                'retrieval':('personal_knowledge_vectors','personal_knowledge_fences'),
                'knowledge':('knowledge_documents','knowledge_generations','knowledge_publications'),
                'knowledge_public':('knowledge_public_metadata',),'knowledge_operator':('knowledge_documents',)}[name]
            for table in tables:
                if not require_empty:
                    # A connection alone does not establish its current table
                    # grants. RLS may hide rows; only verify bounded read access.
                    db.execute('SELECT 1 FROM '+table+' LIMIT 1').fetchone()
                    continue
                if db.execute('SELECT count(*) FROM '+table).fetchone()[0]:raise OwnershipError('Initial release requires empty installation stores')
    installation.verify_operator(token)


def _empty_runtime_stores(connection,token):
    return _runtime_stores(connection,token,require_empty=True)


def _empty_owner_stores(document,token):
    # Runtime retrieval uses RLS and can legitimately see zero hidden rows.
    # Only the separately qualified table owner can establish initial emptiness.
    with storage.configured_storage(document) as (stores,operator):
        for name,connector in stores.items():
            check=operator.checkpoint(token)
            with connector.connect() as db:
                db.rollback();db.execute('SET TRANSACTION READ ONLY')
                db.execute("SET LOCAL lock_timeout='2s'");db.execute("SET LOCAL statement_timeout='3s'")
                if name=='control':storage.check_control_namespace(db,connector.installation_id)
                else:
                    from agentic_os.adapters.postgres.profiles import LEGACY_RDS,RDS_EXACT
                    profile=document['installation']['aws'].get('storage_profile',LEGACY_RDS)
                    if profile==RDS_EXACT:
                        storage.check_component_namespace(db,connector.installation_id,name,storage_profile=profile)
                    else:storage.check_component_namespace(db,connector.installation_id,name)
                for table in {'control':('os_applications','os_budget_roots','os_tasks'),
                        'retrieval':('personal_knowledge_vectors','personal_knowledge_fences'),
                        'knowledge':('knowledge_documents','knowledge_generations','knowledge_publications')}[name]:
                    if db.execute('SELECT count(*) FROM '+table).fetchone()[0]:
                        raise OwnershipError('Initial owner store contains private data')
                check()
        operator(token)


async def qualify_initial(document,token,*,expected_generation):
    stores,cloud,cloud_path=configuration(document);path=stores['installation']['manifest']
    verify_operator(path,token)
    if type(expected_generation) is not int or expected_generation!=1:raise OwnershipError('Initial parked generation required')
    def checkpoint():
        verify_operator(path,token)
        with file_lock(path.parent/'recovery-gate.lock',timeout=2):
            current=gate.state(path)
            if (current['mode']!='PARKED' or current['generation']!=expected_generation
                    or (path.parent/FILE).exists() or (path.parent/FILE).is_symlink()
                    or any((path.parent/name).exists() or (path.parent/name).is_symlink() for name in MARKERS)):
                raise OwnershipError('Fresh initial parked installation required')
            for name in ('artifacts','backups'):
                check_private(path.parent/name,directory=True)
                if any((path.parent/name).iterdir()):raise OwnershipError('Initial installation contains private data')
            return current,_materials(path)
    before=await asyncio.to_thread(checkpoint)
    content=await asyncio.to_thread(_runtime_content)
    await asyncio.to_thread(storage.prepare_stores,document['stores'],token,expected_generation=expected_generation,check_only=True)
    await asyncio.to_thread(_empty_owner_stores,document['stores'],token)
    from agentic_os.adapters.embedding.rpc import EmbeddingClient
    embedded=await EmbeddingClient(path).embed(['Agentic OS installation readiness'],purpose='query')
    if len(embedded.vectors)!=1:raise OwnershipError('Offline embedding readiness differs')
    from temporalio.api.workflowservice.v1 import DescribeNamespaceRequest,ListWorkflowExecutionsRequest
    with configured_operator_connection(cloud) as connection:
        await asyncio.to_thread(_empty_runtime_stores,connection,token)
        async with asyncio.timeout(10):
            client=await connection.connect()
            if not await client.service_client.check_health():raise OwnershipError('Cloud frontend unavailable')
            request=DescribeNamespaceRequest(namespace=connection.namespace)
            connection.cloud.verify(await client.workflow_service.describe_namespace(request,timeout=timedelta(seconds=5)))
            listing=await client.workflow_service.list_workflow_executions(ListWorkflowExecutionsRequest(
                namespace=connection.namespace,page_size=1),timeout=timedelta(seconds=5))
            if listing.executions or listing.next_page_token:raise OwnershipError('Initial Cloud namespace contains retained work')
            connection.cloud.verify(await client.workflow_service.describe_namespace(request,timeout=timedelta(seconds=5)))
        await asyncio.to_thread(_empty_runtime_stores,connection,token)
    await asyncio.to_thread(_empty_owner_stores,document['stores'],token)
    if await asyncio.to_thread(checkpoint)!=before:raise OwnershipError('Initial readiness changed during verification')
    with file_lock(path.parent/'recovery-gate.lock',timeout=2):
        verify_operator(path,token)
        if (gate.state(path)!=before[0] or _materials(path)!=before[1]
                or (path.parent/FILE).exists() or (path.parent/FILE).is_symlink()
                or load_operator_configuration(cloud_path)!=cloud or _runtime_content()!=content):
            raise OwnershipError('Initial readiness changed before publication')
        now=int(time.time());value=dict(profile=PROFILE,installationId=load_manifest(path)['installationId'],
            runId=cloud['run_id'],generation=2,installationDigest=installation_digest(document['stores']['installation']),
            cloudConfiguration=str(cloud_path),cloudDigest=hashlib.sha256(canonical_bytes(cloud)).hexdigest(),cloud=_cloud_pin(cloud),
            releaseDigest=release_digest(),materialsDigest=before[1],issuedAt=now,expiresAt=now+document['release_seconds'],
            checks={name:True for name in CHECKS},contentDigest=content)
        write_signed(path.parent/FILE,value,path.parent/'owner.key')
        gate._write(path,mode='READY',reason='verified')
        certificate(path,value['installationDigest'])
    return dict(profile=PROFILE,state='initial-control-ready',controlReady=True,runtimeReady=False,enabledLanes=[],
        generation=2,expiresAt=value['expiresAt'],productionQualified=False)
