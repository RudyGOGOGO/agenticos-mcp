# Explicit POC DTO wrapper; frozen default policy remains separate.
package agentic_os_agent_observe
import rego.v1

# Observation has its own fresh, short authority. The original context remains
# immutable. No accepted observation can be used by the execution policy.
default allowed := false
allowed if {
    request := input.request
    observation := request.observation
    observation.schema == "agent-read-observation/1"
    read := observation.read
    valid_read(read)
    context := read.binding.context
    authority := request.authority
    authority.allowed
    authority.credential == null
    authority.subject == context.subject
    authority.taskId == context.taskId
    authority.rootId == context.rootId
    authority.policyGeneration == observation.policyGeneration
    time.now_ns() < time.parse_rfc3339_ns(authority.validUntil)
    time.parse_rfc3339_ns(authority.validUntil) <= time.parse_rfc3339_ns(observation.validUntil)
    request.requiredBundle == data.observationProfile
    capability := request.registration
    ceiling := request.capabilityPolicy
    capability.kind == "read"
    capability.kind in ceiling.allowedKinds
    capability.adapterRef == "poc.mcp.read/1"
    context.profile.ref == "poc-runtime/1"
    capability.lifecycle == "qualified"
    capability.purpose == ceiling.purpose
    context.purpose == ceiling.purpose
    capability.id == read.binding.capability.ref
    capability.revision == read.binding.capability.revision
    some prefix in ceiling.capabilityPrefixes
    startswith(capability.id, prefix)
    context.accountingFormat == "agent-resources/1"
    context.delegationRef == null
}

valid_read(read) if {
    read.phase == "disclose"
    is_string(read.candidateJson)
}
valid_read(read) if {
    read.phase == "query-navigation"
    read.candidateJson == null
}

decision := {"allowed": allowed, "bundle": data.observationProfile,
    "requestDigest": input.requestDigest,
    "authorityGeneration": input.request.authority.policyGeneration,
    "validUntil": input.request.authority.validUntil}
