package agentic_os
import rego.v1

scope_allowed if {
    input.authority.active
    input.subject == input.authority.subject
    input.purpose == input.authority.purpose
    input.capability.id in input.authority.capabilityRefs
    input.capability.id in input.botCeiling
    input.requiredBundleRevision == data.profile.revision
    input.budget.maxStages > 0
    input.budget.maxTokens > 0
    every bound in input.resourceBounds {
        some host in input.authority.resourceBounds
        host.resourceType == bound.resourceType
        every external in bound.externalIds { external in host.externalIds }
        every field in bound.fieldNames { field in host.fieldNames }
    }
}

# Eligibility is not effect authorization. Trusted dispatch additionally
# resolves an exact reviewed decision or finite delegation outside model tools.
eligible if {
    scope_allowed
    input.purpose == "assistant.prepare"
    input.capability.kind == "effect"
    input.capability.riskFloor in {"medium", "high"}
    input.capability.guaranteeProfile == "atomic-host-effect/1"
    input.delegation == null
    input.budget.maxToolCalls > 0
}

default eligible := false
reason := "ELIGIBLE_FOR_TYPED_REVIEW" if eligible
reason := "DENIED_SCOPE_OR_PROFILE" if not eligible

decision := {
    "allowed": eligible,
    "risk": input.capability.riskFloor,
    "requiredAssurance": "local-synthetic",
    "constraints": ["host-current", "bot-ceiling", "owner-scope"],
    "bundleRevision": data.profile.revision,
    "bundleDigest": data.profile.digest,
    "authorityGeneration": input.authority.policyGeneration,
    "validUntil": input.authority.validUntil,
    "reasonCode": reason
}
