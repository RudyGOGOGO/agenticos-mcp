# Explicit qualification: separately qualified revision3 decision eligibility only.
package agentic_os
import rego.v1

scope_allowed if {
    p := input.policy
    p.authority.active
    p.subject == p.authority.subject
    p.purpose == "assistant.execute"
    p.authority.purpose == p.purpose
    p.capability.id in p.authority.capabilityRefs
    p.capability.id in p.botCeiling
    p.requiredBundleRevision == data.profile.revision
    p.delegation == null
    p.budget.maxStages > 0
    p.budget.maxToolCalls > 0
    p.budget.maxTokens > 0
    p.resourceBounds != []
    now := time.now_ns()
    time.parse_rfc3339_ns(p.authority.checkedAt) >= now - 5000000000
    time.parse_rfc3339_ns(p.authority.checkedAt) <= now + 1000000000
    time.parse_rfc3339_ns(p.authority.validUntil) > now
    p.capability.kind == "effect"
    p.capability.riskFloor in {"medium", "high"}
    p.capability.guaranteeProfile == "atomic-host-effect/1"
    every bound in p.resourceBounds {
        some host in p.authority.resourceBounds
        host.resourceType == bound.resourceType
        every external in bound.externalIds { external in host.externalIds }
        every field in bound.fieldNames { field in host.fieldNames }
    }
}

proof_bound if {
    b := input.claim.binding
    a := input.attestation
    proposal := input.proposal
    b.subject == input.policy.subject
    b.proposalId == proposal.id
    b.proposalRevision == proposal.revision
    b.proposalDigest == proposal.digest
    proposal.subject == b.subject
    proposal.risk == input.policy.capability.riskFloor
    proposal.requiredAssurance == "local-synthetic"
    proposal.guaranteeRef == "atomic-host-effect/1"
    count(proposal.intent.targets) == 1
    target := proposal.intent.targets[0]
    target.subject == proposal.subject
    proposal.intent.subject == proposal.subject
    target.contractVersion == proposal.intent.contractVersion
    input.policy.intentRef == concat("", ["proposal/", proposal.id])
    proposal.expectedVersions == proposal.intent.targets
    proposal.providerRef == target.providerId
    proposal.intent.operation == "update"
    proposal.intent.destinationRefs == []
    count(proposal.intent.fields) > 0
    names := [f.name | some f in proposal.intent.fields]
    count(names) == count({name | some name in names})
    exact := [{"resourceType":target.resourceType, "externalIds":[target.externalId],
               "fieldNames":sort(names)}]
    input.policy.resourceBounds == exact
    b.policyGeneration == input.policy.authority.policyGeneration
    now := time.now_ns()
    created := time.parse_rfc3339_ns(b.createdAt)
    expires := time.parse_rfc3339_ns(b.expiresAt)
    created <= now + 1000000000
    created < expires
    expires <= created + 60000000000
    expires > now
    time.parse_rfc3339_ns(proposal.expiresAt) > now
    observed := time.parse_rfc3339_ns(a.observedAt)
    observed >= now - 5000000000
    observed <= now + 1000000000
    proof_until := time.parse_rfc3339_ns(a.expiresAt)
    proof_until > now
    proof_until <= expires
    a.subject == b.subject
    a.sessionId == b.sessionId
    a.challengeId == b.challengeId
    a.assertionRef == input.claim.assertionRef
    a.commandId == input.claim.commandId
    a.commandDigest == input.claim.commandDigest
    a.decision == input.claim.decision
    a.assuranceRef == "local-synthetic"
    a.decision in {"approve", "reject"}
}

eligible if { scope_allowed; proof_bound }
default eligible := false
reason := "ELIGIBLE_FOR_OWNER_DECISION" if eligible
reason := "DENIED_SCOPE_OR_PROFILE" if not eligible
until := time.format(min({time.parse_rfc3339_ns(input.policy.authority.validUntil),
    time.parse_rfc3339_ns(input.attestation.expiresAt),
    time.parse_rfc3339_ns(input.attestation.observedAt) + 5000000000,
    time.parse_rfc3339_ns(input.proposal.expiresAt)}))

review_eligibility := {
    "allowed": eligible,
    "risk": input.policy.capability.riskFloor,
    "requiredAssurance": "local-synthetic",
    "constraints": ["host-current", "bot-ceiling", "owner-scope"],
    "bundleRevision": data.profile.revision,
    "bundleDigest": data.profile.digest,
    "authorityGeneration": input.policy.authority.policyGeneration,
    "validUntil": until,
    "reasonCode": reason
}
