package system.authz
import rego.v1
# OPA parses Authorization: Bearer as input.identity. Workers can evaluate only
# the reviewed fixed decision path; management/compiler/query routes are denied.
default allow := false
allow if {
    input.identity == data.operator.token
    input.method == "POST"
    input.path == ["v1", "data", "agentic_os", "decision"]
}
allow if {
    input.identity == data.operator.token
    input.method == "GET"
    input.path == ["health"]
}
