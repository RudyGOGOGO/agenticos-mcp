# Explicit qualification: one fixed eligibility route. Execution is a later profile.
package system.authz
import rego.v1

default allow := false
allow if {
    input.identity == data.operator.token
    input.method == "POST"
    input.path == ["v1", "data", "agentic_os", "review_eligibility"]
}
allow if {
    input.identity == data.operator.token
    input.method == "GET"
    input.path == ["health"]
}
