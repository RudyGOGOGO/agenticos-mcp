# Explicit qualification separately pinned execution4. Eligibility3 is not a permit.
package agentic_os
import rego.v1

execution_scope_allowed if {
    p := input.policy
    p.authority.active
    p.subject == p.authority.subject
    p.purpose == "assistant.execute"
    p.authority.purpose == p.purpose
    p.capability.id in p.authority.capabilityRefs
    p.capability.id in p.botCeiling
    p.requiredBundleRevision == data.profile.revision
    data.profile.revision == 4
    p.delegation == null
    p.capability.kind == "effect"
    p.capability.riskFloor in {"medium", "high"}
    p.capability.guaranteeProfile == "atomic-host-effect/1"
    p.resourceBounds != []
    now := time.now_ns()
    time.parse_rfc3339_ns(p.authority.checkedAt) >= now - 5000000000
    time.parse_rfc3339_ns(p.authority.checkedAt) <= now + 1000000000
    time.parse_rfc3339_ns(p.authority.validUntil) > now
    every bound in p.resourceBounds {
        some host in p.authority.resourceBounds
        host.resourceType == bound.resourceType
        every external in bound.externalIds { external in host.externalIds }
        every field in bound.fieldNames { field in host.fieldNames }
    }
}

owned_decision_and_grant_bound if {
    c := input.decision
    g := input.grant
    p := input.proposal
    c.decision == "approve"
    c.subject == input.policy.subject
    c.subject == p.subject
    c.id == g.decision.id
    c.coreDigest == g.decisionCoreDigest
    c.proposalId == p.id
    c.proposalRevision == p.revision
    c.proposalDigest == p.digest
    g.decision.proposalId == p.id
    g.decision.proposalRevision == p.revision
    g.decision.digest == p.digest
    g.decision.subject == c.subject
    g.subject == c.subject
    g.taskId == c.taskId
    g.rootId == c.rootId
    g.segmentId == c.successorSegmentId
    g.controlEpoch == c.controlEpoch
    g.sourcePinDigest == c.sourcePinDigest
    g.requestDigest == c.requestDigest
    g.capabilityRef == c.capabilityRef
    g.capabilityRef == input.policy.capability.id
    g.providerRef == p.providerRef
    g.providerRef == c.providerRef
    g.stageId == c.stageId
    g.definitionDigest == c.definitionDigest
    g.registrationRevision == c.registrationRevision
    g.profileRef == "reviewed-execution/1"
    c.executableProfileRef == g.profileRef
    g.bundleRevision == data.profile.revision
    c.executableBundleRevision == g.bundleRevision
    g.bundleDigest == data.profile.digest
    c.executableBundleDigest == g.bundleDigest
    c.readAuthority == null
    c.eligibility.allowed
    c.eligibility.bundleRevision == 3
    c.claim.decision == "approve"
    c.claim == input.claim
    c.authority.subject == c.subject
    c.authority.policyGeneration == input.policy.authority.policyGeneration
    p.guaranteeRef == "atomic-host-effect/1"
    p.risk == input.policy.capability.riskFloor
    p.requiredAssurance == "local-synthetic"
    p.expectedVersions == p.intent.targets
    count(p.intent.targets) == 1
    target := p.intent.targets[0]
    target.subject == c.subject
    p.intent.subject == c.subject
    target.providerId == g.providerRef
    target.contractVersion == p.intent.contractVersion
    p.intent.operation == "update"
    p.intent.destinationRefs == []
    p.intent.evidenceRefs == [concat("", ["stage/", g.stageId])]
    input.policy.intentRef == concat("", ["proposal/", p.id])
    names := [f.name | some f in p.intent.fields]
    count(names) > 0
    count(names) == count({name | some name in names})
    input.policy.resourceBounds == [{"resourceType": target.resourceType,
        "externalIds": [target.externalId], "fieldNames": sort(names)}]
    now := time.now_ns()
    created := time.parse_rfc3339_ns(c.createdAt)
    expires := time.parse_rfc3339_ns(c.expiresAt)
    created <= now + 1000000000
    created < expires
    expires <= created + 60000000000
    expires > now
    g.createdAt == c.createdAt
    g.expiresAt == c.expiresAt
    g.decision.expiresAt == c.expiresAt
    time.parse_rfc3339_ns(p.expiresAt) >= expires
}

fresh_review_proof_bound if {
    claim := input.claim
    b := claim.binding
    a := input.attestation
    c := input.decision
    a.subject == b.subject
    a.sessionId == b.sessionId
    a.challengeId == b.challengeId
    a.assertionRef == claim.assertionRef
    a.commandId == claim.commandId
    a.commandDigest == claim.commandDigest
    a.decision == "approve"
    a.assuranceRef == "local-synthetic"
    b.subject == c.subject
    b.sessionId == c.authority.sessionId
    b.sessionGeneration == c.authority.sessionGeneration
    b.hostSessionRef == c.authority.hostSessionRef
    b.policyGeneration == c.authority.policyGeneration
    b.proposalId == c.proposalId
    b.proposalRevision == c.proposalRevision
    b.proposalDigest == c.proposalDigest
    claim.commandId == c.commandId
    claim.commandDigest == c.commandDigest
    now := time.now_ns()
    time.parse_rfc3339_ns(a.observedAt) >= now - 5000000000
    time.parse_rfc3339_ns(a.observedAt) <= now + 1000000000
    proof_until := time.parse_rfc3339_ns(a.expiresAt)
    proof_until > now
    proof_until <= time.parse_rfc3339_ns(b.expiresAt)
    time.parse_rfc3339_ns(c.expiresAt) <= proof_until
}

execution_allowed if { execution_scope_allowed; owned_decision_and_grant_bound; fresh_review_proof_bound }
default execution_allowed := false
execution_reason := "CURRENT_OWNED_REVIEWED_EFFECT" if execution_allowed
execution_reason := "DENIED_SCOPE_OR_PROFILE" if not execution_allowed
execution_until := time.format(min({
    time.parse_rfc3339_ns(input.policy.authority.validUntil),
    time.parse_rfc3339_ns(input.attestation.expiresAt),
    time.parse_rfc3339_ns(input.attestation.observedAt)+5000000000,
    time.parse_rfc3339_ns(input.grant.expiresAt),
    time.parse_rfc3339_ns(input.proposal.expiresAt)}))
reviewed_execution := {"allowed": execution_allowed,
    "risk": input.policy.capability.riskFloor, "requiredAssurance": "local-synthetic",
    "constraints": ["host-current", "bot-ceiling", "owner-scope", "owned-decision", "exact-grant"],
    "bundleRevision": data.profile.revision, "bundleDigest": data.profile.digest,
    "authorityGeneration": input.policy.authority.policyGeneration,
    "validUntil": execution_until, "reasonCode": execution_reason}
