package agentic_os_agent_read
import rego.v1

# The kernel supplies an authenticated Host observation, an accepted model-bound
# request and the original immutable ceiling. Neither MCP nor the model can set
# these policy inputs. Credential bytes are excluded from policy input.
default allowed := false
allowed if {
    request := input.request
    read := request.read
    binding := read.binding
    context := binding.context
    authority := request.authority
    ceiling := request.capabilityPolicy
    capability := request.registration
    request.requiredBundle == data.profile
    authority.allowed
    authority.subject == context.subject
    authority.taskId == context.taskId
    authority.rootId == context.rootId
    time.now_ns() < time.parse_rfc3339_ns(authority.validUntil)
    time.parse_rfc3339_ns(authority.validUntil) <= time.parse_rfc3339_ns(context.authorizationHorizon)
    capability.kind == "read"
    capability.kind in ceiling.allowedKinds
    capability.adapterRef == "mcp.read/1"
    capability.lifecycle == "qualified"
    capability.purpose == ceiling.purpose
    context.purpose == ceiling.purpose
    capability.id == binding.capability.ref
    capability.revision == binding.capability.revision
    some prefix in ceiling.capabilityPrefixes
    startswith(capability.id, prefix)
    binding.identity.kind == "tool"
    binding.identity.parentOperationId == binding.modelOperationId
    binding.identity.taskId == context.taskId
    binding.identity.rootId == context.rootId
    binding.identity.segmentId == context.segmentId
    binding.identity.intentRevision == context.intentRevision
    binding.identity.controlEpoch == context.controlEpoch
    binding.modelResult.subject == context.subject
    binding.modelResult.taskId == context.taskId
    binding.modelResult.rootId == context.rootId
    context.accountingFormat == "agent-resources/1"
    context.delegationRef == null
    valid_phase(read)
}
valid_phase(read) if { read.phase == "dispatch"; read.candidateJson == null }
valid_phase(read) if { read.phase == "disclose"; is_string(read.candidateJson) }

decision := {
    "allowed": allowed,
    "bundle": data.profile,
    "requestDigest": input.requestDigest,
    "authorityGeneration": input.request.authority.policyGeneration,
    "validUntil": input.request.authority.validUntil,
}
