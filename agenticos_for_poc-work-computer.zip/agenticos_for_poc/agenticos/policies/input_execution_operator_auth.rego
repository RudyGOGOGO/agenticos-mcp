package system.authz
import rego.v1

default allow := false
allow if {
    input.identity == data.operator.token
    input.method == "POST"
    input.path == ["v1", "data", "agentic_os", "input_reviewed_execution"]
}
allow if {
    input.identity == data.operator.token
    input.method == "GET"
    input.path == ["health"]
}
