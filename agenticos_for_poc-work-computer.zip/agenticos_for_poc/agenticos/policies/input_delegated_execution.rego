package agentic_os
import rego.v1

delegated_scope_allowed if {
    p := input.policy
    g := input.grant
    c := input.delegation
    d := c.delegation
    v := input.currentInput
    proposal := input.proposal
    p.authority.active
    p.subject == p.authority.subject
    p.subject == c.subject
    p.subject == g.subject
    p.subject == proposal.subject
    p.purpose == "assistant.execute"
    p.authority.purpose == p.purpose
    p.authority.delegationRef == concat("", ["delegation/", c.id])
    p.authority.policyGeneration == c.authority.policyGeneration
    p.capability.id in p.authority.capabilityRefs
    p.capability.id in p.botCeiling
    p.capability.kind == "effect"
    p.capability.riskFloor == "medium"
    p.capability.guaranteeProfile == "atomic-host-effect/1"
    p.budget.maxStages >= 1
    p.budget.maxToolCalls >= 1
    p.requiredBundleRevision == 6
    data.profile.revision == 6
    g.bundleRevision == 6
    g.bundleDigest == data.profile.digest
    g.profileRef == "input-delegated-execution/1"
    c.profileRef == "input-bounded-delegation/1"
    c.notificationPolicy == "private-result/1"
    d.id == c.id
    d.subject == c.subject
    d.revision == 1
    d.active
    d.maxRisk == "medium"
    d.purpose == "assistant.change"
    d.budget.maxToolCalls == 1
    d.budget.maxStages == 1
    d.budget.maxChildren == 0
    d.budget.maxNativeJobs == 0
    d.budget.maxTokens == 1
    d.capabilityRefs == [p.capability.id]
    p.delegation == d
    g.authorization == {"kind":"bounded_delegation","delegation":d}
    g.delegationId == c.id
    g.delegationDigest == c.delegationDigest
    v == c.input
    v.subject == c.subject
    g.taskId == v.taskId
    g.rootId == v.rootId
    g.segmentId == v.segmentId
    g.controlEpoch == v.controlEpoch
    g.inputId == v.id
    g.inputRevision == v.revision
    g.inputDigest == v.inputDigest
    g.requestDigest == v.requestDigest
    g.requestDigest == c.requestDigest
    g.sourcePinDigest == c.sourcePinDigest
    g.definitionDigest == c.definitionDigest
    g.registrationRevision == c.registrationRevision
    g.proposalId == c.record.id
    g.proposalDigest == c.record.proposalDigest
    g.proposalId == proposal.id
    g.proposalRevision == proposal.revision
    g.proposalDigest == proposal.digest
    g.providerRef == proposal.providerRef
    g.capabilityRef == p.capability.id
    proposal.risk == "medium"
    proposal.guaranteeRef == "atomic-host-effect/1"
    proposal.expectedVersions == proposal.intent.targets
    proposal.taskId == v.taskId
    count(proposal.intent.targets) == 1
    target := proposal.intent.targets[0]
    target.subject == p.subject
    target.providerId == g.providerRef
    target.contractVersion == proposal.intent.contractVersion
    proposal.intent.subject == p.subject
    proposal.intent.operation == "update"
    proposal.intent.destinationRefs == []
    proposal.intent.provenanceRef == concat("", ["input/", v.id, "/", v.inputDigest])
    proposal.intent.evidenceRefs == [concat("", ["stage/", g.stageId])]
    names := [f.name | some f in proposal.intent.fields]
    count(names) > 0
    count(names) == count({n | some n in names})
    bound := {"resourceType":target.resourceType,"externalIds":[target.externalId],"fieldNames":sort(names)}
    p.resourceBounds == [bound]
    d.resourceBounds == [bound]
    some host in p.authority.resourceBounds
    host.resourceType == bound.resourceType
    target.externalId in host.externalIds
    every n in names { n in host.fieldNames }
    p.intentRef == concat("", ["proposal/", proposal.id])
    now := time.now_ns()
    checked := time.parse_rfc3339_ns(p.authority.checkedAt)
    checked >= now - 5000000000
    checked <= now + 1000000000
    time.parse_rfc3339_ns(p.authority.validUntil) > now
    created := time.parse_rfc3339_ns(c.createdAt)
    expires := time.parse_rfc3339_ns(c.expiresAt)
    created <= now + 1000000000
    created < expires
    expires <= created + 300000000000
    expires > now
    d.validFrom == c.createdAt
    d.validUntil == c.expiresAt
    time.parse_rfc3339_ns(g.createdAt) >= created
    time.parse_rfc3339_ns(g.createdAt) <= now + 1000000000
    time.parse_rfc3339_ns(g.expiresAt) > now
    time.parse_rfc3339_ns(g.expiresAt) <= expires
    time.parse_rfc3339_ns(g.expiresAt) <= time.parse_rfc3339_ns(v.expiresAt)
    time.parse_rfc3339_ns(g.expiresAt) <= time.parse_rfc3339_ns(proposal.expiresAt)
}

default delegated_allowed := false
delegated_allowed if delegated_scope_allowed
delegated_reason := "CURRENT_INPUT_FINITE_DELEGATED_EFFECT" if delegated_allowed
delegated_reason := "DENIED_SCOPE_OR_PROFILE" if not delegated_allowed
delegated_until := time.format(min({
    time.parse_rfc3339_ns(input.policy.authority.validUntil),
    time.parse_rfc3339_ns(input.policy.authority.checkedAt)+5000000000,
    time.parse_rfc3339_ns(input.delegation.expiresAt),
    time.parse_rfc3339_ns(input.grant.expiresAt),
    time.parse_rfc3339_ns(input.proposal.expiresAt)}))
input_delegated_execution := {"allowed":delegated_allowed,"risk":input.policy.capability.riskFloor,
    "requiredAssurance":"bounded-delegation/1",
    "constraints":["host-current","bot-ceiling","owner-scope","finite-delegation","exact-grant","current-input"],
    "bundleRevision":data.profile.revision,"bundleDigest":data.profile.digest,
    "authorityGeneration":input.policy.authority.policyGeneration,"validUntil":delegated_until,
    "reasonCode":delegated_reason}
