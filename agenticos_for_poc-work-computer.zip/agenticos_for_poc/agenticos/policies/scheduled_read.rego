package agentic_os
import rego.v1

allowed if {
    input.authority.active
    input.subject == input.authority.subject
    input.purpose == input.authority.purpose
    input.capability.id in input.authority.capabilityRefs
    input.capability.id in input.botCeiling
    input.capability.kind == "read"
    input.capability.riskFloor == "low"
    input.delegation == null
    input.requiredBundleRevision == data.profile.revision
    input.budget.maxStages > 0
    input.budget.maxTokens > 0
    every bound in input.resourceBounds {
        some host in input.authority.resourceBounds
        host.resourceType == bound.resourceType
        every external in bound.externalIds { external in host.externalIds }
        every field in bound.fieldNames { field in host.fieldNames }
    }
}

default allowed := false
reason := "ADMITTED_READ" if allowed
reason := "DENIED_SCOPE_OR_PROFILE" if not allowed

decision := {
    "allowed": allowed,
    "risk": input.capability.riskFloor,
    "requiredAssurance": "current-host-read/1",
    "constraints": ["host-current", "bot-ceiling", "owner-scope"],
    "bundleRevision": data.profile.revision,
    "bundleDigest": data.profile.digest,
    "authorityGeneration": input.authority.policyGeneration,
    "validUntil": input.authority.validUntil,
    "reasonCode": reason
}
