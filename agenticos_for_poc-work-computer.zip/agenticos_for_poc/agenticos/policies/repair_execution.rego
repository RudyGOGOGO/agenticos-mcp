package agentic_os
import rego.v1

default repair_allowed := false
repair_allowed if {
    p := input.policy
    r := input.repair
    g := input.grant
    proposal := input.proposal
    claim := input.claim
    b := claim.binding
    a := input.attestation
    original := input.originalReceipt
    p.authority.active
    p.subject == r.subject
    p.subject == g.subject
    p.subject == proposal.subject
    p.subject == b.subject
    p.subject == a.subject
    p.subject == original.subject
    p.purpose == "assistant.execute"
    p.authority.purpose == p.purpose
    p.authority.delegationRef == null
    p.delegation == null
    p.capability.id in p.authority.capabilityRefs
    p.capability.id in p.botCeiling
    p.capability.id == g.capabilityRef
    p.capability.kind == "effect"
    p.capability.guaranteeProfile == "atomic-host-effect/1"
    proposal.risk == p.capability.riskFloor
    proposal.risk in {"medium", "high"}
    proposal.requiredAssurance == "local-synthetic"
    proposal.guaranteeRef == "atomic-host-effect/1"
    p.budget.maxChildren >= 1
    p.budget.maxStages >= 2
    p.budget.maxToolCalls >= 5
    p.requiredBundleRevision == 7
    data.profile.revision == 7
    g.bundleRevision == 7
    g.bundleDigest == data.profile.digest
    g.profileRef == "typed-update-repair-execution/1"
    r.profileRef == "typed-update-repair/1"
    g.repairId == r.id
    g.taskId == r.taskId
    g.parentTaskId == r.parentTaskId
    g.taskId != g.parentTaskId
    g.rootId == r.rootId
    proposal.taskId == g.taskId
    g.proposalId == proposal.id
    g.proposalDigest == proposal.digest
    g.proposalRevision == 1
    proposal.revision == 1
    g.providerRef == proposal.providerRef
    original.providerRef == g.providerRef
    original.status == "COMMITTED"
    original.attestationProfile == "atomic-host-effect/1"
    original.id == g.originalReceiptId
    original.version == g.originalReceiptVersion
    original.invocationId != g.invocationId
    proposal.expectedVersions == original.affectedResources
    proposal.intent.targets == original.affectedResources
    count(proposal.intent.targets) == 1
    target := proposal.intent.targets[0]
    target.subject == p.subject
    target.providerId == g.providerRef
    target.contractVersion == proposal.intent.contractVersion
    proposal.intent.operation == "update"
    proposal.intent.destinationRefs == []
    proposal.intent.provenanceRef == concat("", ["repair/",r.id,"/original/",original.id])
    proposal.intent.evidenceRefs == [concat("", ["stage/",g.stageId])]
    p.intentRef == concat("", ["proposal/",proposal.id])
    names := [f.name | some f in proposal.intent.fields]
    count(names) > 0
    count(names) == count({n | some n in names})
    bound := {"resourceType":target.resourceType,"externalIds":[target.externalId],"fieldNames":sort(names)}
    p.resourceBounds == [bound]
    some host in p.authority.resourceBounds
    host.resourceType == bound.resourceType
    target.externalId in host.externalIds
    every n in names { n in host.fieldNames }
    g.authorization.kind == "review_decision"
    d := g.authorization.decision
    d.id == g.approvalId
    d.subject == p.subject
    d.proposalId == proposal.id
    d.proposalRevision == 1
    d.digest == proposal.digest
    d.assuranceRef == "local-synthetic"
    d.expiresAt == g.expiresAt
    claim.decision == "approve"
    a.decision == "approve"
    a.assuranceRef == "local-synthetic"
    a.assertionRef == claim.assertionRef
    a.commandId == claim.commandId
    a.commandDigest == claim.commandDigest
    a.challengeId == b.challengeId
    a.sessionId == b.sessionId
    b.proposalId == proposal.id
    b.proposalRevision == 1
    b.proposalDigest == proposal.digest
    b.assuranceProfile == "local-synthetic-assurance/1"
    b.requiredAssurance == "local-synthetic"
    b.sessionId == g.authority.sessionId
    b.sessionGeneration == g.authority.sessionGeneration
    b.hostSessionRef == g.authority.hostSessionRef
    b.policyGeneration == g.authority.policyGeneration
    b.policyGeneration == p.authority.policyGeneration
    now := time.now_ns()
    time.parse_rfc3339_ns(p.authority.checkedAt) >= now - 5000000000
    time.parse_rfc3339_ns(p.authority.checkedAt) <= now + 1000000000
    time.parse_rfc3339_ns(p.authority.validUntil) > now
    time.parse_rfc3339_ns(a.observedAt) >= now - 5000000000
    time.parse_rfc3339_ns(a.observedAt) <= now + 1000000000
    time.parse_rfc3339_ns(g.createdAt) <= now + 1000000000
    expires := time.parse_rfc3339_ns(g.expiresAt)
    expires > now
    expires <= time.parse_rfc3339_ns(g.createdAt) + 60000000000
    expires <= time.parse_rfc3339_ns(b.expiresAt)
    expires <= time.parse_rfc3339_ns(a.expiresAt)
    expires <= time.parse_rfc3339_ns(proposal.expiresAt)
    expires <= time.parse_rfc3339_ns(r.expiresAt)
}
repair_reason := "CURRENT_REGISTERED_REPAIR" if repair_allowed
repair_reason := "DENIED_SCOPE_OR_PROFILE" if not repair_allowed
repair_until := time.format(min({time.parse_rfc3339_ns(input.policy.authority.validUntil),
    time.parse_rfc3339_ns(input.policy.authority.checkedAt)+5000000000,
    time.parse_rfc3339_ns(input.attestation.expiresAt),time.parse_rfc3339_ns(input.attestation.observedAt)+5000000000,
    time.parse_rfc3339_ns(input.grant.expiresAt),time.parse_rfc3339_ns(input.proposal.expiresAt)}))
repair_execution := {"allowed":repair_allowed,"risk":input.proposal.risk,
    "requiredAssurance":"local-synthetic","constraints":["host-current","bot-ceiling","owner-scope",
        "registered-inverse","fresh-repair-approval","exact-grant"],
    "bundleRevision":data.profile.revision,"bundleDigest":data.profile.digest,
    "authorityGeneration":input.policy.authority.policyGeneration,"validUntil":repair_until,"reasonCode":repair_reason}
