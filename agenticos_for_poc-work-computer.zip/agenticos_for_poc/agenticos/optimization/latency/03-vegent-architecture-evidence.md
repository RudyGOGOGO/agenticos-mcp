# Vegent 架构照片：提取、判断及 VF 对应优化

2026-11-03 补充。用户提供 IMG_9641–IMG_9647.HEIC；已逐张目视阅读。原图位于 `/Users/weizhang/Downloads/`，哈希记录在 evidence-index.json；格式转换仅用于阅读，未编辑原图，也未复制进产品或部署仓库。

照片中的文档标题为 “Vegent Personal Secretary — Simplified Architecture Reference”。它自称是实现参考摘要，以源码和 `docs/en/developer-guide/personal-secretary.md` 为最终依据；本文并未取得这些实际文件。因此下面的等级是**架构说明报告的实现机制**，不是独立代码验证。文档自己明确说没有端到端延迟 benchmark，这一限制应保留。

## 逐张覆盖

| 照片 | 可读内容 | 与此次优化有关的事实 |
|---|---|---|
| IMG_9641 | 用途、honesty note、§1、§2技术栈 | Next.js/React；FastAPI/Pydantic/SQLAlchemy；SQLite；Claude executor；FastMCP；Socket.IO；asyncio scheduler＋Redis lease；无E2E latency数字 |
| IMG_9642 | §3架构图、§4开头 | 单backend部署；TaskRequestBuilder→最后应用SecretaryProfile；task房间streaming；独立completion handler；五个稳定边界 |
| IMG_9643 | §4组件通信、chat/delegation流程 | typed REST、task-token audience/user过滤、output guard、DB turn锁、预算gate、确认后launch、确定性completion summary |
| IMG_9644 | 核心流程、§5九项速度机制 | 小tool surface；context pack与delta；prompt/session复用；分层读取；能代码处理的不调模型；通知/游标；后台工作；显式busy |
| IMG_9645 | §6准确性、§7体验 | allowlist＋per-call scope；服务端提案验证；output guard；确认；确定性receipt；memory忘记/session rotation；统一时间线和可操作卡片 |
| IMG_9646 | §8数据模型、§9映射开头 | conversation/events/delegation/memory/schedule/ledger/budget/audit；状态机声明集中；与AgenticOS概念对应 |
| IMG_9647 | §9映射、§10限制、§11源码指针 | 可复用思想；多项feature默认关闭；一次一turn、在线scheduler、无自动补偿；源码路径指针 |

## 真正值得迁移的机制

### 1. 模型只承担需要语义判断的工作

照片报告：候选评分、briefing、完成摘要、提醒、预算通知等由确定性代码处理；模型负责对话和按需调用 MCP。`TaskCompletedEvent` 触发一次确定性 `completion_summary`，不再调用模型复述已经存在的状态。

这与 VF 源码里“Core已经知道 goalDigest，却再让模型返回该digest”的候选冗余阶段直接对应。优先删除这样的无信息往返，而不是先换模型。确认后的原样执行、已提交receipt的展示也不应为了语言润色重新规划。

边界：不能把 Vegent的简单词匹配/候选评分照搬成所有VF意图的硬编码路由。自然语言理解仍需模型；确定性机制应处理有明确输入合同的步骤。

### 2. 小上下文＋版本化增量，而不是每轮重建一份巨大指令

文档报告首轮 context pack约3k tokens，后续发送delta；分层读取状态→有界摘要→必要时深读。稳定persona/system prefix、稳定每用户会话归属和resume有利于缓存。

照片中的 S0数字：默认模式冷cache-creation约25.3k tokens，17-name deny-list约8k，去掉内建工具后约4.8k；报告cache reads为每turn tokens的60–75%；示例Sonnet4.6 turn规模约routing9.3k、follow-up3.5k、plain chat2.5k。**这些是照片转述的token测量，不是本次复测；不同分母也不能直接彼此相除。**

VF应检查实际发给模型的序列化请求，而不是只数用户问题字数。将稳定合同和变动状态分开，按需带上下文，保留实体ID与来源。这个方向已补入P1.5。缓存命中不等于同等比例降低总时延，长session也可能增加后续成本。

### 3. 通知轻量，读取权威；完成状态不由模型记忆决定

Vegent的notification携带事件ID/类型或状态提示；客户端按游标获取持久事件。流式文字走另一类task事件，UI将其与持久卡片合并。漏通知可在下次拉取/重连恢复。

VF已有SSE和游标，不必换Socket.IO。可在同一现有通道发送受限的surface-ready提示，立即获取当前授权结果并去重，避免等stream结束后再串行读一组资源。事件和receipt的权威来源仍是持久状态，不是socket是否成功发送。

### 4. 明确的执行profile和能力缩减，比无限指令更可靠

Vegent在builder后最后应用profile，去掉内建Bash/Edit等工具，只留指定MCP；能力接口仍检查task audience、run kind和user ownership。

VF可借鉴“最终有效配置只收窄能力”的验证点。不能直接复制字面`tools=[]`；在不同SDK中它可能意味着不同的组合方式。检查实际注册工具、模型输入和序列化worker配置，确保后续装配不会重新注入无关能力。profile本身不是backend authorization的替代。

### 5. 一条连续时间线＋可操作状态，而不是让用户理解内部流程

文档说明消息、提案、提醒、草稿和结果在一个cursor-ordered时间线中；卡片支持Start/Revise/Decline/Approve；拒绝后不再循环提议；busy保留输入并说明正在做什么。

这能直接改善VF的亲切感与可控性：用户在App里看到草稿、编辑、确认、实际创建结果，再在Saved Locations中看到同一资源。可靠状态机和自然表达可以同时存在。不要把所有内部保障做成必须点击的界面步骤。

### 6. 让后台工作不拖住当前交互

提醒可以投递既有批准内容，不必每次到期重新请求模型；反思才创建有预算的模型turn。embedding是opt-in后台投影。该原则可迁移到VF，但保留其持久schedule、权限、consent和future effect要求，不照搬仅设备醒着才能调度的限制。

## 不能照搬，或不能从这份文档推导的结论

| 文档说法/选择 | 严格解释与VF边界 |
|---|---|
| “Everything in one process / no network hop” | 同时写明HTTP MCP endpoint和Redis；可理解为主要组件同backend/本机，而不是证明没有HTTP序列化、socket或SDK子进程。没有代码不能认证字面进程拓扑 |
| 更小prompt所以更快 | 是合理优化方向；无法从token规模推出确切首token/完成时延。模型、cache、provider排队也影响结果 |
| SQLite＋同进程executor | 有利于缩短本地路径；不能直接迁移到需要AWS、多身份、Java MCP和独立SDK依赖的VF，也不是消除1万条SQL的替代 |
| output guard保证准确 | 能限制工具/代码输出边界，不自动保证自然语言事实正确。代码围栏检测也不是VF事实、数值、源版本或权限证明 |
| crash后interrupted，用户ask again | 可用于未执行效果的对话恢复；VF写入状态UNKNOWN时必须先按原操作/幂等键恢复，不能重新创建一遍 |
| forgetting＝physical delete＋session rotation | 可减少未来应用级召回；不等于已证明删除所有provider存储、备份、模型已有通用知识。VF必须同时处理旧上下文、缓存和checkpoint可见性 |
| 一次只允许一个turn，409busy | 容量限制透明是优点；不应该为模拟低延迟而悄悄拒绝原本承诺的任务或改变已有排队语义 |
| scheduler只在线，超grace后missed | 是明确产品降级，不能用于宣称AWS持久调度已完成 |
| 表只有少量，所以架构更好 | 技术栈行数和后续表清单的计数口径并不完全明显；表数本身不能衡量性能。应比较同一意图的SQL、模型往返与网络成本 |
| guard＋用户确认＋audit已足够 | 它证明设计没有简单放弃控制；但并未证明与VF跨组件撤权、source绑定、UNKNOWN/accounting恢复的保证完全等价 |

## 对原方案的具体调整

1. 保留P0依赖图/SQL复用为最高优先级：VF有直接测量，照片没有推翻它。
2. 提高确定性completion和消除无信息模型阶段的重要性：Vegent架构提供了清晰参照，见P1.1。
3. 新增P1.5：最终有效profile＋有界context pack＋delta/session失效规则，避免只优化SQL而留下冗余模型输入。
4. 加强P0.2通知/游标增量更新和P1.3统一交互时间线，保留现有SSE/WKWebView/A2UI。
5. 不新增Redis、Socket.IO、SQLite、Claude迁移等组件任务。引用实现思想，不复制整套技术栈。

现在能够较有把握地说：Vegent架构**把确定性工作交给代码，把模型和上下文成本限定在真正需要的步骤，并及时把状态交给用户**。这些原则与VF已发现的重复工作形成了具体可实施的对照。至于每项可节省多少秒，仍需在VF同环境、同模型、同语义下验证，不能用用户的主观流畅感或照片中的token数代替。
