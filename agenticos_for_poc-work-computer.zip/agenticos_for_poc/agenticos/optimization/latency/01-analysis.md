# Verizon Family AgenticOS：延迟与交互体验审查

日期：2026-11-03。状态：**分析与优化设计，尚未实施或验证本方案。**

本次只读取设计、代码、已有记录和用户补充的七张 Vegent 架构说明照片，没有调用模型、执行业务操作、重启服务或修改产品代码。Vegent 的当前源码位于用户工作电脑，未提供；照片提供了实现机制说明，证据级别高于原始需求，但仍不是代码审计或可重算的性能 trace。用户观察到的流畅体验值得作为产品目标，但不是生产容量、尾延迟或安全性认证。

**补充后的结论：**照片明确描述了小型上下文包、后续 delta、SDK session/prompt-cache复用、确定性完成摘要、流式文字和通知＋游标增量同步。这些机制加强了下面的优化方向，并新增实施项 P1.5；照片本身也明确声明没有端到端延迟基准。逐张提取及不能照搬的部分见 [Vegent 架构照片对照](./03-vegent-architecture-evidence.md)。

## 结论

Verizon 侧存在真实且可优化的结构性成本。当前简化路径已经使用 DirectRunner 和独立 SDK 子进程，不能把问题主要归因于 Temporal、Firecracker 或尚未部署的 AWS。部署组件减少了，但每次请求仍然承担较重的通用治理、依赖图验证、模型阶段和结果发布流程。

最有力的证据是：一个指定已有地点 ID 的完整摘要读取，只需一次业务工具调用，却用了 **3 次模型调用、23 次 Core RPC、10,339 条 SQL**；客户端约 **29.376 秒**才显示完整结果。RPC 累计覆盖 12.736 秒，其中 SQL 计时累计 6.180 秒。重复图验证已被实现 session 定位，当前源码也已提交同次验证复用修复；本审查没有看到该新修复的等价端到端提速证明，因此不能把旧数字当成修复后的性能。

应当借鉴 Vegent 的原则：**根据任务需要组织工作，让简单读取、编辑确认、复杂任务分别承担必要成本。** 不需要重写整个 OS，也不应该删除授权、账本或恢复能力。最值得做的是改变重复工作的组织方式、减少没有新增信息的模型往返，并在获得合法可用结果时及时显示。

另一个必须纠正的说法是“简单写操作需要 80 多秒系统时间”。保留记录中的 83.489 秒和 86.945 秒包含人工打开、编辑、确认等等待；它们证明完整体验仍不理想，但不能全部归给模型、数据库或 Core。

## 审查基线和证据边界

实际 Core 工作源码为：

`/Volumes/AgenticOSVerification-a7e243c29b41/poc-core-20261101/source/modules/agentic-os`

App 和 Java MCP 分别为：

`/Users/weizhang/workspace/agenticos_for_poc/simplified-vf-ios-app-and-backend`

`/Users/weizhang/workspace/agenticos_for_poc/mcp`

不是用旧的部署导出副本代替当前源码。审查期间 owner 仍在开发；证据清单记录最终取样源码 HEAD `c016f6cd5add12f41299fca7c8553ac79996d072`、工作区状态和 27 个文件的 SHA-256。历史性能样本属于各自安装版本，不能混为同一版本的验收结果。

- [源码与证据清单](./evidence-index.json)：文件绝对路径、大小、哈希；没有复制凭证、私人历史或数据库。原始 27 个文件和后来加入的七张照片分开记录。
- [提取后的计时数据](./retained-timing-summary.json)：从现有记录计算，非新测试。
- [实施设计与最小验证计划](./02-implementation-plan.md)：优先级、落点、不变量、验证、回退、阶段目标。

下面用 C 表示上述 Core 源码目录，用 A 表示 App 目录，用 M 表示 MCP 目录。文件位置以清单中的哈希为准；活跃分支的行号可能继续移动。

## 三个实际样本的时间线

### R：读取一个明确指定 ID 的地点及 geofence 摘要

Task `b2b52b54-6a18-45f4-9008-62fc07e5984c`，Core/SDK `b748b89e…`，一次 `GetSavedLocationWithGeofences`，零写操作，3 次模型调用。来源：`work/verified-coverage-complete-seed.json`、`family-full/journey-ctxfull.json`、`family-full/rpc-numeric-ctxfull.jsonl`，均位于上述 SSD 工作目录。

| 客户端连续区间 | 耗时 | 占总时长 | 能够说明什么 |
|---|---:|---:|---|
| 提交 → admission | 0.204s | 0.69% | 接收并建立任务很快 |
| admission → 客户端观察到 tool-result | 28.539s | 97.15% | 混合区间，**不是业务工具耗时** |
| tool-result → first-meaningful | 0.632s | 2.15% | 最后读取/展示区间 |
| first-meaningful → verified-completion 标记 | 0.001s | <0.01% | 两个标记几乎同时发生 |
| 合计 | **29.376s** | 100% | 当前证据中的一个完整只读样本 |

`tool-result` 来自客户端步骤事件或任务快照响应头，不代表 Java HTTP 返回时间。这个案例的 first-meaningful 与完成几乎重合，说明该测量没有证明“中途已经展示了有用结果”。

服务器内部可进一步确认：

| 内部计数或区间 | 测量值 | 如何解释 |
|---|---:|---|
| Core RPC | 23 次 / 12.736s | 累计服务端 RPC span；约为客户端总时长的 43.35%，不是互斥瓶颈份额 |
| RPC 内 SQL | 10,339 条 / 6.180s | 嵌套在 RPC 中，约为总时长的 21.04%；**不能与 RPC 耗时相加** |
| 三轮 stage/prepare/begin/finish/accept/accepted-operation | 18 RPC / 5.530s | 每轮模型之外的协议/控制成本，不全是可删成本 |
| execute-tool | 2.917s / 2,320 SQL | 包含 Core 验证和工具边界，不能全部算 Java 或 REST |
| bind-read-goal | 1.419s / 1,273 SQL | 目标绑定的局部测量 |
| complete-read | 1.832s / 1,365 SQL | 完成边界的局部测量，不等同于最后一帧显示 |
| 账本累计 tokens / workMs | 12,598 / 6,209ms | 原有计费/工作指标；不是精确分阶段瀑布图 |

SQL 逐条平均计时约 0.598ms。这个样本首先提示“查询次数太多”，而不是“每次数据库访问都很慢”。平均值不是 p95；未测锁等待、磁盘、CPU 分布，不能据此宣称基础设施完全无影响。

三次 `begin` RPC 返回至相应 `finish` RPC 开始的空档约为 2.766s、2.338s、1.057s。这些是包围 SDK 工作的空档，**不是独立 provider span**。当前资料没有分别提供每次模型的准确型号、输入/输出 tokens、首 token、推理/输出时间，不能伪造拆分。保留记录只给出模型 profile `synthetic-data-live-openai-analysis` revision 3 及其 digest。

### W1：创建 saved location，经用户编辑后确认

Task `bdbe51c8-8eaf-45d9-95dc-a5eb486e91a2`；Core `7d09f662…` / SDK `f59e6e76…`。1 次模型调用、1 次实际写入，最终 CLOSED，有实际 receipt。来源：`C/poc/evidence/actual-created-place-boundary-read.json`。

| 客户端连续区间 | 耗时 | 占总时长 |
|---|---:|---:|
| 提交 → admission | 0.295s | 0.35% |
| admission → tool-result 观察标记 | 14.527s | 17.40% |
| tool-result → proposal-ready | 23.884s | 28.61% |
| proposal-ready → first-meaningful | 0.001s | <0.01% |
| first-meaningful → editable-form | 14.732s | 17.65% |
| editable-form → verified-completion | 30.049s | 35.99% |
| 合计 | **83.489s** | 100% |

### W2：给新地点创建一个成员的 geofence，经用户编辑后确认

Task `e9ea8662-1d81-4889-bb36-df52a91e4a14`；与 W1 同一历史安装。3 次模型调用、1 次实际写入，最终 CLOSED，有实际 receipt。

| 客户端连续区间 | 耗时 | 占总时长 |
|---|---:|---:|
| 提交 → admission | 0.276s | 0.32% |
| admission → tool-result 观察标记 | 31.036s | 35.70% |
| tool-result → proposal-ready | 14.167s | 16.29% |
| proposal-ready → first-meaningful | 0.001s | <0.01% |
| first-meaningful → editable-form | 10.647s | 12.25% |
| editable-form → verified-completion | 30.819s | 35.45% |
| 合计 | **86.945s** | 100% |

W1/W2 是浏览器中的真实 Agent→Java MCP→合成 backend 操作，**不是完整原生 App 操作证据**。两次独立用户请求共享刚创建的地点 ID；不是已经证明一句话原子完成两项写入。记录明确说明包含 operator pauses/actions，且没有单独的“用户点确认”和“backend commit”时间。因此这些区间只能指出需继续分段的位置，不能直接预测可节省多少秒。

每次模型的 tokens、provider 首输出、MCP 初始化、授权、REST、冷启动、排队、表单打开和确认后时延，均未在这两个样本中完整分离。补齐少量 span 即可；无需为本报告重跑全部验收。

## 最重要的五组问题

这是按现有证据强弱和潜在收益排序，**不是虚构的五个互斥百分比**。只有第一组有较完整的控制开销测量，其余份额未知或与它重叠。

| 顺序 | 已看到的问题 | 根因及影响 | 证据/限定 |
|---|---|---|---|
| 1 | 同一请求反复验证完整依赖图，数千次控制 SQL | 每层独立重建证明和当前状态，简单读取也承担多轮整图检查；下一轮模型还扩大依赖图 | R 的 23 RPC / 10,339 SQL；`FamilyReadGoals._validated_planner`、`AcceptedObservations._read_graph`。新提交 `869e255c` 已开始同次复用，收益待测 |
| 2 | 一次工具读取需要三次模型决策及对应完整边界 | 有的模型阶段主要重述已绑定目标或返回已知 goalDigest，没有新增推理价值 | `read_journey.py:1003,1256,1321–1327`；3 次模型是实际记录；可删除多少必须按语义验证 |
| 3 | 结果发布/前端刷新延后，而且存在人为文字播放成本 | SDK 非流式 run；已接受 narrative 切为 32 字符后每段等待 80ms；UI 常等 SSE 一段结束才刷新 snapshot，再串行读 owner-input/resources/surface | `interaction/presentation.py:18–29`、`presentation/stream.py:123–151`、`ui/shell/main.tsx:240–291`；每 N 个文字块强制等待 0.08N 秒，另有每块权限/游标成本，实际占比未测 |
| 4 | 获取/展示内容比用户所需更大，transport 重复发现 | DETAIL 强制整组字段；LAST/HISTORY 依赖全部 saved-location detail；Core MCP 每次新建 client/session，前后重复 list_tools | `family_reads.py:21–32,81–91`、`mcp.py:54,70–109,200–218`；单次 read lane 至少两个初始化和三个 list_tools，数量须以改后 span确认 |
| 5 | App 和诊断链路进一步增加重复 I/O | native refresh 串行全地点/全成员读取；写入后全地点 readback 再完整 refresh；诊断在 HTTP 响应路径额外查 SQL、同步保存整份有界记录 | `A/.../Store.swift:37–56,139–146`；`journey_observation.py:91–135`。属于代码确认的机会，不足以证明占主导 |

Java `BackendHttpClient` 已复用实例级 HttpClient，一次操作只做对应一次 REST 请求，没有在该层发现自动重试或业务 fan-out。因此不要笼统宣布“Java MCP 需要重写为 Python”或再次给已经复用的客户端加连接池。Core→MCP 的新建会话与 Java→backend 的连接生命周期是两回事。

DirectConversationService 有每 tick 后 1 秒 sleep，SSE 有 250ms 轮询；它们会带来通知等待和重复读，但不能解释全部 29 秒。tick 自身可能很慢，不能简单认为最坏只有 1 秒。SDK 每任务启动子进程，最大执行并发 2；其冷启动/排队占比未测，暂不把常驻 worker pool 或扩容当成第一项。

## Vegent 设计与照片说明可借鉴什么

| 架构元素 | Vegent 请求中的选择 | VF 简化版现状 | 转移判断 |
|---|---|---|---|
| 编排 | Adapted：本地 Claude executor、确定性完成摘要，按需 MCP 调用 | 已有 DirectRunner，但 SDK/Core 阶段仍重 | 删除无信息的模型阶段；不把 Claude executor 文档中的 in-process 当成已审计的进程拓扑 |
| 隔离 | Dropped：不使用 Firecracker，在 owner 权限下本地执行 | POC 固定可信 SDK 子进程，不运行该 VM 路径 | 不能用单用户本地权限替代多用户隔离与 backend 授权 |
| 上下文 | Adapted：约 3k token context pack，之后传 delta；分层深读；稳定前缀和 session复用 | 已加 owner context，但存在完整字段/完整图成本 | 复用身份绑定的上下文，严格失效；新增 P1.5，不照搬 3k 数字为硬阈值 |
| 动态能力 | Adopted/adapted：统一版本化 MCP，按需组合 | 九工具的显式合同与映射已存在 | 保留；能力 schema 可按 pin复用，权限不可变成永久缓存 |
| 交互 UI | Adapted：复用 Vegent UI，照片说明 streamed turn text＋统一时间线、可操作卡片；原请求 Phase 1 不做 A2UI | WKWebView + A2UI + trusted owner review | 借鉴及时可编辑、通知＋游标和统一状态，不需要换 Socket.IO或删表单合同 |
| Effect 纪律 | Adopted：提议、授权、执行、receipt、unknown 恢复 | 更强的 Core/Host/backend 分界 | 保留证明，消除相同证明的重复计算 |
| Scheduler | Adapted：应用运行时提醒/反思，错过不无限补偿 | VF 包含更多持久化/受控操作需求 | 把后台工作移出前台关键路径；不能悄悄降级持久性或未来写入语义 |
| Memory | Adopted/adapted：独立 global memory、分层读、写入需批准 | 需保留原有 consent、来源、忘记、用户隔离 | 按需 recall 和后台提案可迁移；两者 consent 产品规则不能混同 |
| 预算 | Adapted：秘书与委派分开，达到上限停新自主工作 | 共享治理与 UNKNOWN保留更严格 | 精简可视化和重复查询，不能清除 hold 或事后补造账本 |
| 数据与部署 | Adapted：SQLite、同 backend部署工具，30秒 scheduler tick＋Redis lease＋DB claim | PostgreSQL、跨组件身份与可部署 AWS 目标 | 同机更短I/O可有帮助，但 HTTP仍有协议成本；不建议换SQLite或删身份校验 |

**仍不能从照片推导**：Claude/Sonnet比当前VF模型更快、每个等价请求的模型调用次数、真实首token时间、完整表单执行协议、连接池实现及延迟分位数。现在可以说“照片中的架构说明报告了 streaming、session复用和 cache读比例”，不能说我们已独立验证。照片报告的 cache比例是 token指标，不能换算成相同比例的总耗时下降。

## 体验问题不能只靠改一句 system prompt

1. 简单读取应直接回答所问字段。用户问“这个围栏开了吗”，不应强迫九列表格；需要完整列表时仍必须完整。表单和事实字段由可信工具数据/合同产生，表达可以自然。
2. 对“刚才那个地点”“把半径改成 450 米”的上下文，应保留有来源的实体 ID、用户请求字段和未完成草稿；执行前刷新权限与 revision。不要靠压缩文本重新猜 ID，也不要把上下文当最新事实。
3. 草稿应该尽早可编辑；必填项未知时明确留空或提出一个有意义的问题。不能把“表单已出现”当“已创建”。确认后的反馈应及时并关联实际 receipt。
4. 将正在查什么、已找到什么、还缺什么说清楚。不要把内部 Root、control epoch、验证阶段等细节塞进普通用户对话。来源与技术细节保留在展开区。
5. 不支持的操作应直接、自然地解释能力边界，并提供真正可做的替代。无可用能力时不应反复规划或假装执行；也不能以硬编码几条 demo 语句取代动态组合。
6. 复合创建需要展示每一步状态和部分成功。地点已创建而围栏失败时，显示已创建地点，恢复只处理剩余操作，沿用原幂等键；不能整段重新执行。
7. native App 也要快速看到变更。完成事件应触发受影响实体的授权 readback，并更新相关页面；不要每次重载 WKWebView 或扫描整个家庭。

另有一项独立的语义风险：`family_reads.append_labels` 把所有命中地点名称合并；设计合同 `05-contracts.md:170` 要求“选中成员、enabled、最小半径优先、地点 ID 打破平局”。这不是性能优化，需先以两个重叠围栏的廉价确定性例子确认并修正，否则加速后的结果仍可能不对。

## 对 Muse 提示词的修正

总体方向正确：要求实测、区分固有与偶然成本、保留不变量、先设计后实施。以下不能照单全收：

- 审查对象应明确是**当前 VF 简化版的实际安装路径**，不是泛指成熟版所有组件。
- “80+秒”不是统一的机器耗时基线；历史 105 秒 synthetic 样本也不是当前版本。
- 无完整 span 时不能硬凑各阶段时间或五个百分比；未知必须保留。
- L/A1 是 POC identity / synthetic backend，不能写成已验证真实 Verizon Authorizer 的用户原 token转发；A2 需要真实批准的身份/委派集成。
- 读操作证据与写操作 receipt 的语义不同。“每次能力调用有记录”不等于强制所有读取走一次写入 receipt ceremony。
- 成员列表、能力可见性、旧 plans不是天然安全的全局缓存；需按身份、会话/权限代次和 capability pin区分，且不能缓存出授权结论。
- 快路径不能增加一个单独的 LLM分类器来决定是否再调用原LLM；否则可能加长简单请求。
- streaming本身不会减少推理或 SQL时间，甚至粗粒度设计不当会增加每 token验权成本；优先消除假流式和串行阻塞。
- 不为比较而同时更换模型、数据库、SDK、部署架构；先在原模型和原语义下量化改进。

## 建议的工作顺序

先完成 owner 已在做的图复用修复并保留其效果证据；接着一次连贯增量处理重复传输/验证、结果及时可见和简单读的无信息模型阶段。然后收口原生编辑—确认—readback链路，最后才考虑预热、扩容和模型路由。

不建议暂停全部工作去重写 OS，也不建议等全部剩余功能完成后才处理这些问题。它们是当前交互可用性的共同依赖，应作为有明确出口的小型性能/体验增量纳入现有实施计划；详细实施设计见第二份文件。该建议尚未发送给其他执行 session。

官方依据仅用来核对接口方向：OpenAI 的[运行与流式交互说明](https://developers.openai.com/api/docs/guides/agents/running-agents)支持 SDK循环与流式输出，但不能证明本项目换一个调用方法就安全完成改造；已安装 Python SDK 的 `run.py` 也有 `run_streamed`。当前 Core明确固定 MCP `2025-11-25`，优化其会话生命周期时应遵循该版本的[传输规范](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports)，无需为了本次提速升级协议。
