# VF simplified AgenticOS — proposed responsiveness implementation plan

Date: 2026-11-03, updated with seven owner-provided Vegent architecture photographs. **Design only; not authorization to implement, benchmark, restart services, or deploy.** Read `01-analysis.md` first. This plan supplements the existing implementation roadmap; it does not replace unresolved acceptance obligations or certify a completed native journey. `03-vegent-architecture-evidence.md` distinguishes documented Vegent mechanisms from inspected VF code and measured VF timings.

## Scope, owners and invariants

Apply approved product changes in the currently authoritative POC source, with App and MCP changes in their respective owner repositories. Do not patch a generated deployment export to simulate an upstream fix. Update the POC export using its existing synchronization process at accepted milestones. Do not change the mature `agenticos_deployment` repository as a side effect.

The review inspected Core under `/Volumes/AgenticOSVerification-a7e243c29b41/poc-core-20261101/source/modules/agentic-os`, App under `/Users/weizhang/workspace/agenticos_for_poc/simplified-vf-ios-app-and-backend`, and MCP under `/Users/weizhang/workspace/agenticos_for_poc/mcp`. Resolve current owner revisions before applying anything: the active session has already committed a fresh-planner graph reuse correction (`869e255c`). Do not implement that correction again or reinstall an older baseline just to obtain a comparison.

Keep one task authority and the existing metering/UNKNOWN recovery rules. Preserve current authorization at actual protected reads, effects and private-result egress, including revocation during an awaited operation. Preserve subject, original request, immutable profile, source version, deadline, consent, expected revision and idempotency bindings. An acknowledgement or draft never counts as verified business success. Maintain separate Core/SDK dependency environments and authenticated private RPC.

L/A1 still uses the authenticated synthetic backend and POC identity. Real Verizon authorization/API/delegation remains a separate A2 qualification. None of the optimizations may turn a locally persistent test login into permanently valid task authority.

New conceptual names below describe proposed seams, not interfaces claimed to exist today.

## Intended execution shape

```mermaid
flowchart TD
  A[Native App / retained WKWebView] --> B[Authenticated admission + persistent task]
  B --> C[Bounded context + pinned capability descriptions]
  C --> D[Existing model selects a typed intent]
  D --> E[Simple read]
  D --> F[Draft / mutation]
  D --> G[Complex task or genuinely missing information]
  E --> H[Current authority + bounded MCP reads]
  H --> I[Evidence verification + deterministic presentation]
  I --> J[Authorized surface-ready event]
  F --> K[Editable draft + explicit trusted confirmation]
  K --> L[Current authority / revision + original idempotency key]
  L --> M[Execute + durable outcome / receipt]
  M --> N[Targeted authorized native readback]
  G --> O[Existing governed continuation]
  J --> A
  N --> A
  O --> A
```

This is a request-shaping change inside the existing system. It is not a separate ungoverned agent, a scripted five-scenario demo, or a permission bypass.

## P0 — remove demonstrated amplification and unnecessary waiting

### P0.1: Finish and extend invocation-scoped graph reuse only where justified

**Anchors:** `src/agentic_os/adapters/poc/family_reads.py:44–91`; `production/observation.py:231–318`; the saved `fresh-read-graph-latency-diagnosis.json`.

1. Inspect the owner's existing fresh/retained graph correction and its retained focused results. Start from that implementation.
2. Build the immutable causal closure once for a validation invocation; pass that exact material to planner, discovery, resource and required-field checks instead of having each wrapper recursively read the same graph.
3. Within a bounded transaction/request scope, batch independent ledger lookups using existing scope filters. Retain cycle/conflicting-reference detection. Do not retain a DB transaction across model or HTTP waits.
4. Separate immutable structure/hash validation from mutable authorization and source/version checks. A reusable structural result is not proof of current access. Preserve the post-Host fence, and obtain fresh checks at later operations/egress.
5. Measure query counts by action and unique graph nodes. Prevent work scaling with repeated traversals of the same nodes; do not set an arbitrary global SQL limit that breaks larger legitimate graphs.

**Saving:** addressable historical envelope is 12.736s inclusive Core RPC, with 6.180s nested SQL in sample R. The recoverable part is unknown and less than the full envelope; do not add these values or promise a percentage. The previously retained 1.459→1.313s snapshot result applies only to that older snapshot step, not the new whole journey.

**Risks/verification:** reuse the existing fresh/retained tests; add only missing tests for source change/revocation during Host await, conflicting graph refs, required fields and original-owner binding. One affected installed read confirms count/time improvement. No browser/mobile rerun for unrelated code.

**Rollback:** pin new tasks to the prior reviewed implementation/profile; retain old in-flight semantics. No frozen migration edits or rewriting accepted evidence.

### P0.2: Remove result-delivery barriers and artificial replay delay

**Anchors:** `interaction/presentation.py:18–29`; `presentation/stream.py:123–151`; `production/presentation.py:60`; `ui/shell/main.tsx:240–291`.

1. Remove the unconditional server-side 80ms sleep after each accepted 32-character narrative chunk. A small visual typing effect, if desired, must not delay authoritative table/form presentation, cancellation, or completion controls.
2. Initially preserve existing durable event formats and cursor semantics; changing event batching is a separate step if the per-event authorization/cursor costs remain material. Do not batch across permission changes without an equivalent egress fence.
3. Refresh the affected authorized surface on an existing verified publication event, or an additive versioned `surface-ready` reference event, while the stream is open. Do not wait for transport closure or a 30-second transport window. The event signals availability; the protected current read remains authoritative.
   Borrow Vegent's lightweight-notification/authoritative-pull split through the existing SSE channel. Use subject-scoped IDs/generations, not raw private data, for notifications. Coalesce multiple notifications into one outstanding cursor read; deduplicate event IDs and retain reconnect recovery. Even notification metadata must obey visibility rules. Do not replace SSE with Socket.IO merely to imitate the reference.
4. In `refreshView`, stop serially blocking the answer fetch on optional owner-input/resources reads. Use bounded independent reads or one versioned snapshot envelope if necessary, with the same subject/task/visibility/projection generation and stale-response rejection. A failure to fetch resources must not display a stale or unauthorized answer; nor should unrelated metadata unnecessarily hide an already authorized surface.
5. Wake the direct coordinator on committed work/continuation/publication via an existing local event or supported DB notification, with the persisted outbox and periodic polling as recovery. Notifications are hints, not authority. Instrument the existing one-second tick first; do not add Redis, Kafka or a new orchestration service.

**Saving:** mandatory pacing removed is `0.08 × N` seconds for N text chunks, plus any measured redundant per-chunk work if later batched. For a 1,000-character accepted narrative that is 32 chunks / 2.56s of configured sleeps, an illustrative calculation, not an observed case. A wake can avoid up to the applicable idle poll interval; slow tick execution and validation remain separate. The result-fetch/barrier saving is unmeasured, so quote no total prediction.

**Risks/verification:** deterministic cursor/order/revocation/Stop tests at the changed stream boundary; one native reconnect with the current accepted surface. Preserve existing compatible restart evidence. Assert that ready tables do not wait for narrative playback and that no private content is shown before authorization.

**Rollback:** disable the new publication-triggered refresh for new client sessions and restore the previous transport behavior without altering receipts/history. Do not undo a passed backend optimization just because the UI path is reverted.

### P0.3: Stop repeating MCP initialization and schema discovery

**Anchors:** `adapters/poc/mcp.py`, especially `POCSession.validate_tool_result`, `POCMCP.request`, `POCReadLane.observe`.

1. Reuse the already fetched, pinned tool schema for output validation within the same invocation instead of `list_tools` again.
2. Keep an HTTP transport/connection lifecycle across related operations where the existing security wrapper permits it. The pinned 2025-11-25 protocol may use sessions; preserve initialize/version negotiation and required session expiry/reconnect behavior. Do not silently upgrade the protocol.
3. If reusing an authenticated session, partition it by endpoint/trust identity, registration/capability generation and the actual subject/credential scope. Never mutate shared client authorization/effect headers across concurrent users. A simpler first step is request-scoped session reuse with immutable headers.
4. Cache immutable descriptor/schema content by digest. Recheck current registration, current tool availability and authorization using the existing boundary. A TTL alone is insufficient authorization freshness.
5. Java `BackendHttpClient` already reuses its client. Leave it unless its own measured span shows a problem. Keep one intended backend operation, expected revision, same effect key, and UNKNOWN handling.

**Saving:** reduces known redundant initialization/catalog round trips; no measured network-only duration is available. End-to-end lower bound is zero if another stage dominates. Do not claim the entire 2.917s execute-tool span is removable.

**Risks/verification:** cached-schema invalidation, credential rotation, two-subject isolation, changed tool pin, revoked authority and malformed output; reuse existing fixtures. No paid model is needed for these cases.

**Rollback:** return to short-lived transport while retaining the validated schema parsing change; expire retained sessions safely.

### P0.4: Make diagnostic collection non-blocking

**Anchor:** `adapters/poc/journey_observation.py:91–135`.

The current optional collector awaits a diagnostic SQL query and saves the bounded accumulated report on the response path. `Server-Timing` is calculated before these operations, so it excludes part of the observer overhead.

Move numeric observations to a bounded in-memory queue and batch/terminal flush. Count dropped diagnostics explicitly; a missing sample is preferable to delaying a product response. Prefer an already established task event for tool-observed timing instead of a new SQL query on every snapshot. Never move actual accounting, effect receipts, or recovery state to a lossy queue. Record collector overhead and compare observer-on/off with deterministic data.

**Saving:** unmeasured; bound by the measured observer contribution only. **Verify:** no secret/body content, no per-span private-file rewrite, bounded overflow and shutdown, unchanged product result on collector failure. **Rollback:** disable optional diagnostics; never disable canonical records.

## P1 — simplify the interaction algorithm without weakening the contract

### P1.1: Introduce a general simple-read completion path

**Anchors:** `harnesses/agent-worker/.../read_journey.py:1003,1256–1327`; `production/goals.py`; `production/table_reads.py`; `adapters/poc/family_reads.py`.

Eligibility: a current registered read capability, a resolved and authorized entity, bounded output, no unsupported cross-source inference, no pending owner ambiguity, no consequential effect, and a projection expressible by the accepted output schema. Complex reads stay on the existing path. If eligibility fails, fall back within the original task/deadline/accounting; do not submit a duplicate task.

Use the existing first semantic model decision to select capability, typed arguments and requested field projection. Do not add a preceding model classifier. The Core validates these against the original request representation, authorized capability and returned evidence. It must not treat a model's claimed coverage as proof that all user-requested information was returned.

After verified tool output, use a deterministic result compiler where the accepted schema/goal permits it. The present continuation sometimes asks the model only to return an already known `goalDigest`; replace that no-information phase with an explicit typed control result from Core. Keep whatever semantic model pass is actually needed to interpret the request/result. Aim for one or two calls for an eligible read, not an unconditional one-call rule.

Keep freeform narrative optional for structured facts; do not make every table wait for another paraphrase. For a greeting or a genuine unsupported capability, avoid constructing a full evidence-query plan. Natural replies still remain bounded, honest and metered. No hidden chain-of-thought or fabricated progress should be streamed.

**Saving:** one unnecessary model call and its associated control actions are candidates for removal in R. The last observed begin/finish gap was ~1.057s and a typical model boundary adds several RPCs, but neither is a portable saving guarantee. One-call completion could require more design than this increment; first prove removal of the redundant digest phase.

**Risks/verification:** missing requested fields, unsupported joins, wrong member, empty/no-match, profile mismatch, truncated output, prompt paraphrase and different member/location. Verify the same canonical answer, provenance and accounting. Test deterministic controls first, then one representative live model journey only after those pass.

**Rollback:** additive versioned harness/profile selection for new tasks; existing tasks retain old behavior. Do not reinterpret old checkpoints under the new phase graph.

### P1.2: Separate requested presentation from tool transport completeness

**Anchors:** `family_reads.py` `RULE_FIELDS`, `_family_goal`, `surface_messages`, `label_sources`, `append_labels`; owner-context code selected by `read_journey.py`.

- Validate the complete backend output contract, but render the fields the user requested. A concise enabled/radius answer should not require the full standard summary. An explicit complete-summary request still requires every requested field, including coordinates.
- Represent active entity IDs, requested field coverage and pending draft separately from prose conversation memory. Preserve provenance and identity/generation; refresh mutable state before executing. Resolve genuine ambiguity with one concise question.
- LAST/HISTORY currently requires list plus details for all saved locations. Initially parallelize independent detail reads with a bounded limit and retain completeness. A future filtered/batch capability is an explicit backend contract addition, not a hidden call to an assumed real API.
- If the product permits coordinates/time before inferred labels, show that verified portion with labels explicitly pending. If full label inference is mandatory, retain the requirement. Never say “Unknown” solely because remaining pages have not arrived.
- Confirm and correct the overlapping-geofence selection discrepancy against the existing smallest-radius/stable-ID contract. This is a focused correctness fix, not permission to broaden scenarios indefinitely.

**Saving:** one-call detail projection mainly reduces context/rendering/repair loops; it may not reduce backend payload. For N independent detail reads, bounded concurrency reduces their serial sum toward a bounded critical path, not to zero. Exact seconds unmeasured.

**Risks/verification:** selected-member scope, overlap winner, all-page coverage, history `(from,to]`, exact units, same-summary follow-up retaining fields, and no reused stale source. Use existing seed plus the minimum overlapping-rule fixture.

**Rollback:** old display/profile mapping for new requests; retain output-contract and authorization checks. A proposed batch API remains disabled until both backend and MCP support it.

### P1.3: Deliver one coherent editable-form → confirmation → native readback experience

**Anchors:** `ui/shell/ProductionReview.tsx`, `review-channel.mjs`, `native-tool-review.mjs`; App `AgentSurface.swift`, `Store.swift`, `VFCore/Outbox.swift`; existing Core review/effect services.

Render an editable draft as soon as its selected capability/schema and safe defaults are known. Unknown values remain visibly unset; drafts cannot dispatch effects. Keep draft editing in the embedded experience. If the security model requires a separate trusted confirmation surface, use it for the final exact-value authorization without reopening a second editor. Removing that ceremony entirely requires a separate approved trust design, not a latency fix.

User changes must update the reviewed canonical payload, expected revision and display units before confirmation. Persist the intent/key through app death. On confirmation, immediately acknowledge receipt of the confirmation; only the committed outcome may say created/updated. Treat conflict, refusal and UNKNOWN distinctly.

Native `Store.refresh` currently performs sequential roster, list, all-detail and all-member location reads. Add coalescing/single-flight for the same account generation; fetch independent items concurrently within a bound; prefer the selected member and visible screen. After a known effect, read back the affected entity and refresh the relevant native view. The current all-location readback followed by another all-location refresh is redundant. Do not claim a new revision solely by updating the UI optimistically.

Preserve the same WKWebView across ordinary navigation/foreground transitions. Reconnect with the existing cursor and current generation; do not fix every UI issue by reauthenticating/reloading the whole surface. On account switch, cancel and discard old-owner responses. Unchanged native tab/layout tests can be retained.

**Saving:** avoid serial full-family refresh and duplicate detail passes; no numeric gain can be assigned from W1/W2 because user time is mixed in. Measure form-ready, trusted-confirmation and confirm-to-native-readback separately.

**Risks/verification:** one actual in-app create location then geofence, edit member/radius/mode, exact native readback, one affected reconnect; retained T8 evidence stays valid unless persistence/effect dispatch changes invalidate it. Do not rerun every unrelated journey.

**Rollback:** restore prior UI path behind the same session/protocol selection; preserve accepted receipts and original outbox keys. Never retry an UNKNOWN write with a new key.

Photo-informed refinement: keep replies, proposals, pending confirmations, partial outcomes and receipts in one ordered conversational experience. The underlying task boundaries remain explicit in storage; the user should not have to navigate unrelated technical panels to discover the next required action. Refusal/busy states preserve the typed request. Declining a proposal ends that proposal and does not trigger a fresh model loop that offers it again.

### P1.4: Conversational, memory and proactive behavior

Maintain an answer-first conversational style: concise relevant answer, useful editable next step, and a clear explanation when capability is missing. Keep precise units and scope even when wording is friendly. Do not add a second “make it sound human” model pass to every turn; use the existing semantic response and deterministic receipt summaries.

Recall only memory relevant to the request; do not launch embedding/vector retrieval for every greeting or route that has a declared keyword-only mode. This is an inspection/measurement item, not a claim that the current ordinary read did load embeddings. Preserve forgetting/revocation, separate memory from fresh product facts, and use the currently approved standing-consent/per-entry-review rules. Vegent's consent design is not automatic authorization to change VF semantics.

Move reflection, optional summarization and proactive discovery off the foreground critical path. Give user-initiated work fair priority while preserving already-due schedules and active work. A reminder draft is not a consequential scheduled effect. Scope reflection to named members/context already permitted by the design, not full-family discovery.

**Saving:** reduced irrelevant context/model work where observed; presently unmeasured. **Verify:** one absent-capability reply, contextual follow-up, consent refusal and existing schedule/inbox behavior at touched seams. **Rollback:** retain previous prompt/profile/queue selection and cancel no existing authorized schedule merely to make the demo faster.

### P1.5: Compile a small effective execution profile and versioned context pack

**Photo evidence:** IMG_9642–9645 describe `TaskRequestBuilder` followed by a restrictive `SecretaryProfile`, a roughly 3k-token context pack, delta-only resumed turns, and stable cached prompt prefixes. These are reported Vegent mechanisms, not inspected Vegent code. The original VF read sample has 12,598 aggregate tokens over three calls; that is not directly comparable with Vegent's per-turn cache statistics.

**VF seams:** the final Agent construction and per-phase instruction assembly in `read_journey.py`, Core dispatcher payload construction, the current owner-context producer, MCP catalog pins, and the SDK checkpoint/session adapter. Inspect the final serialized model request rather than only the source prompt: count static instructions, tool descriptions/schemas, current request, history, retrieved evidence, repeated goal/control metadata, and response budget separately.

1. Reuse the existing selected immutable profile as the final restriction point after request assembly. Its effective tools must be a subset of current authorized registered capabilities. Exclude unused worker frameworks, shell/edit/web tools and irrelevant harness instructions from ordinary VF reads, if present. Do not blindly copy `tools=[]`: in Vegent that removes built-in tools while retaining its MCP allowlist; doing so without understanding this SDK's configuration could remove all useful VF tools.
2. Put stable instructions and pinned tool definitions in a stable prefix; put current owner request and changing evidence after them. Avoid changing incidental ordering/IDs in the stable prefix. Do not put another subject's private content into a shared application cache or assume provider prompt caching is an authorization boundary.
3. Build a bounded context pack with typed active-entity references, current requested fields, explicitly active consented preferences, and a concise pending-operation summary. Deep memory or other member records are fetched only when relevant and authorized. Select the budget from measured quality; Vegent's 3k/4k figures are reference values, not new VF acceptance limits.
4. If the current SDK context can be resumed safely, send a versioned delta rather than replaying the full pack. Bind it to subject, conversation, profile/tool digest, context version and visibility/consent generations. A missing delta base requires reconstruction. Do not combine provider-managed continuation with a duplicate full local replay.
5. Forget, sign-out/account switch, revoked consent/source access and profile changes must invalidate the affected cached context and resumable model session before more use. New turns must not retrieve forgotten text through previous responses/checkpoints. Provider data retention is a separate policy question; session rotation alone is not proof of deletion from all provider storage.
6. Use deterministic code for already-known control transitions, receipt summaries, budget notices and delivery of user-approved reminder text. Keep the model for semantic interpretation, genuinely needed composition, and reflection. Do not replace natural-language interpretation with brittle keyword scenario scripts.

**Saving:** fewer duplicated input tokens and no unnecessary model calls on deterministic paths. Expected milliseconds remain unmeasured; cache-hit percentage does not predict end-to-end speedup. First separate this improvement from P1.1's call-count reduction so the same gain is not counted twice.

**Risks/verification:** serialized effective allowlist; no accidental tool reintroduction after profile assembly; preserved requested fields under pruning; same-entity follow-up; delta base mismatch; two-subject separation; forgotten/revoked memory absent from subsequent model inputs. Use retained deterministic fixtures and a small live follow-up only after them. Capture actual input/output/cached token counts.

**Rollback:** select the former immutable profile/context producer for new tasks; invalidate incompatible resumptions. Preserve in-flight work's original profile and canonical outcome. Do not reuse a known-stale model session as a rollback shortcut.

## P2 — only after the above identifies a remaining bottleneck

| Candidate | Trigger / saving bound | Required safeguards and limited proof | Rollback |
|---|---|---|---|
| Warm SDK worker/process pool | Child startup/import or occupied slots materially delays measured interactive work; saving cannot exceed that span | Separate dependency environment, per-task private RPC identity, cleanup of previous subject/context, crash/Stop/accounting. Human-waiting tasks should not monopolize compute slots, but changing placement must preserve their durable continuation | Prior per-task process placement for new work |
| Model routing/prompt reduction | After eliminating redundant phases, provider time dominates | Same quality corpus; no blind smaller-model switch; compare exact-field extraction, capability composition, refusals, ambiguity and costs. Cache immutable instruction prefixes, not mutable private facts or permissions | Original model/profile pin |
| Targeted database/index/pool changes | Explain plans / lock / pool spans reveal a remaining expensive query | Tune a demonstrated query, use additive schema changes if required; no blanket schema rewrite or disabling durability | Prior query/index selection with additive migration discipline |
| AWS colocation/resource/SSE settings | Actual AWS measurements become available | Core/MCP/backend/DB topology, network and connection metrics, streaming/cancellation at deployed ingress; local measurements cannot certify AWS p95 | Previous deploy config/artifacts |
| Shared read snapshots/batch API | Real backend exposes supported versioned batch semantics | Approved contract, filtered member authorization, completeness and per-source version semantics; no false atomic snapshot | Existing bounded single-operation composition |

Do not initially switch databases, rewrite Java, replace A2UI, collapse dependency environments, or enlarge all timeouts. Those actions do not address the best-supported root cause.

## Minimal measurement and acceptance plan

Extend existing collectors; do not introduce a new tracing framework. Keep request/task/operation correlation and numeric durations, with no tokens, request bodies, exact locations or model reasoning in exported timing logs.

Required spans: `admission`, `dispatch_wait`, `worker_start`, `context_recall`, `model[i].request/first_delta/done`, `core_rpc[action]`, `graph_validation` (unique nodes / visits), `sql` (aggregate count/time/wait), `mcp.initialize/list_tools/call_tool`, `backend.request/response/commit`, `draft_ready`, `surface_publish`, `sse_receive`, `form_paint`, `confirm_click/accepted`, `effect_settled`, `native_readback/paint`. Record model/profile, input/output/cached tokens where available, and retry count. Do not invent a separate reasoning-time split when the provider does not supply it.

Use monotonic clocks within each process and native `ContinuousClock` or the existing equivalent; keep WebView `performance.now()` for rendering. Parent/child spans and correlation establish ordering. Do not subtract unrelated monotonic epochs or sum nested durations. Add explicit actor-wait intervals so machine time excludes user think/edit/confirmation time. A necessary clarification is meaningful progress but must not count as successful completion of the original request.

Three frozen prompts on an isolated synthetic fixture:

1. **Simple exact read:** “Show the current radius, notification setting and enabled status for Tom's School geofence. Do not change anything.” Resolve the frozen fixture's actual ID consistently; distinguish the pure known-ID read from the optional name-resolution variant. Add the existing complete-summary prompt as a cheap coverage variant when projection changes.
2. **Reviewed update:** “Change Tom's School geofence to 450 meters and notify me when he leaves. Let me review the values before applying.” Start from an explicitly recorded revision; edit/confirm through the actual native WebView. Reset only the owned backend fixture between independent baseline/new intents; never reset OS memory, accounting, receipts or UNKNOWN holds.
3. **Compound create:** “Save Practice Center at the supplied synthetic address and coordinates, and set a 300-meter leave alert for Mia. Let me review the changes first.” Bind a concrete fixture address/coordinate literal once before the run. Show partial completion honestly; use real tool data and per-operation keys. This is the compound quality case, not proof that one read's latency improved.

Keep prompt, fixture, model, capability pins, environment and warm/cold condition equivalent. A reset produces a new intentional test operation with a new key; a retry/recovery of an existing operation retains its original key. Keep historical failed reports failed.

Run cheap deterministic tests for changed boundaries first. Then one affected installed scenario proves integration. Reuse unchanged native/mobile/package results. If a latency comparison is still noisy, a small paired set of reads can characterize the direction; report individual values and range. Do not call three samples p95/p99 or run large paid load tests to chase a near-threshold number. Use a frozen deterministic provider for OS-overhead comparison and separately label the minimal real-provider check; a deterministic run does not prove model UX.

An optimization is accepted when it preserves required behavior, removes its targeted repeated work, improves the corresponding measured span without a new regression, and passes the changed negative boundary checks. Only broaden tests if code changes invalidate prior evidence or a new defect justifies it.

## Targets and stopping rules

Use **proposed engineering goals**, not retroactive pass thresholds:

| Stage | Goal | Qualification caveat |
|---|---|---|
| Stage 0: correct measurement | Separate submit→useful output, draft→editable form, human wait, confirm→receipt/native readback | Current 83–87s writes do not satisfy this breakdown |
| Stage 1: P0 work | No deliberate replay delay; authorized result/form should start rendering within roughly 1s of its ready event in a warm local session; remove repeated graph/catalog work | This is a proposed delivery-overhead budget, not a promised total latency |
| Stage 2: eligible simple read | Initially aim for useful structured output around 2–5s and verified completion within about 10–15s on a warm, healthy provider/backend | Aspirational until paired measurements establish feasibility; do not weaken verification to hit it |
| Stage 2: write | Evaluate draft-ready separately; after confirmation aim for OS-added overhead around 1–2s above the actual authorization/backend/readback path | Excludes human input and genuine backend/provider waits; compound steps need separate budgets |
| Stage 3: deployment | Set environment-specific percentiles and concurrency targets from realistic AWS runs | No local measurement or Vegent user observation certifies these |

The old 5s/15s numbers are not universal pass/fail rules for every task. A 6s provider response can make a 5s verified response impossible; that does not justify fabricating progress or weakening correctness. Conversely, 10,000 control queries for one bounded read should not be excused as unavoidable architecture. Stop tuning an item when its target span is no longer material; move to the next demonstrated bottleneck rather than repeatedly spending setup/API cost for rare gains.

At major milestones update the existing status with: exact source/install/export revisions, what behavior closed, before/after counts and clock definitions, retained evidence, remaining defects and next task exit. Keep the services available for owner testing. Do not present package synchronization as end-to-end acceptance, and do not interrupt an active acceptance run solely to apply this document.

## What remains unknown after the Vegent photos

The photos now document context limits/deltas, a Claude/Sonnet example, session reuse, small deterministic completion operations, 30-second scheduling, confirmation and cursor-based UI synchronization. Still missing are the matching current source revision, exact per-turn model calls/settings, raw cache/token records, provider/SDK process behavior, complete editable-form execution protocol, and a comparable timing trace. Do not use absence of these artifacts to block evidence-backed VF fixes, and do not claim that changing SDK, database or UI library will reproduce Vegent's observed speed.
