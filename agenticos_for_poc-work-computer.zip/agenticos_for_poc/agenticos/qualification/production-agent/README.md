# Production Agent outcome fixtures

`fixtures/host-outcomes-v1.json` freezes synthetic inputs and exact expected
outcomes for two unrelated Host domains before their execution implementation.
It is not a question router, runtime data source, or a claim that the outcomes
already pass. No fixture is imported into a business database.

The warehouse cases distinguish joined allocation rows, allocated property/bill
amounts, property/period totals and bill face amounts. The global winner occurs
after the first page. Currency, date, shared-bill scope, null/zero and repeated
page handling are explicit. The laboratory cases require scoped joins, accepted
version selection, compatible unit conversion and honest missing-data coverage.
Identical opaque resource IDs across Hosts intentionally test namespace isolation.

Use the immutable inputs and goldens in future guarded Host/compute/outcome
qualification. Accept multiple valid tool sequences. Changes require a new fixture
version and an evidence impact review. These model-authored labels require the
independent human calibration specified by the production evaluation gate.

Current production executor outage isolation is exercised by
`test_production_goal_publication_remains_independent_of_an_unavailable_host`
in `tests/integration/resources/test_read_completion.py` and
`test_installed_production_goal_completes_while_the_other_host_is_offline`
in `tests/integration/resources/test_read_browser.py`. Both select the existing
owned Python/Node Hosts. The unrelated fixture process is physically stopped
before admission; the surviving Host produces an exact verified answer, fresh
owner reload and current-access denial under the original closed resource root.
The installed check uses the actual independent SDK worker and local Temporal,
saving completed private histories and accounting before teardown. It requires
neither WP/MySQL nor cloud credentials. Run the exact affected cases through the
existing guarded `agent-resources` component, retaining compatible build and
browser evidence. This local synthetic proof does not qualify live models,
production cloud outages, full system conformance or release activation.

The existing G10 `foundation-conformance` component also registers these production
resource suites. Installed checks require `--release-bundle`,
`--release-manifest-sha256` and `--release-module`; the maintained incremental runner
forwards that complete binding after checking external storage. Collection and
execution both use the verified independent interpreter. The exact product is
checked before and after execution; dependency reuse is separate setup evidence.
A synchronized frozen environment is retained, while failed preparation prevents
collection or a product installation. A frozen external build can declare its
baseline with `build_release.py --source-commit`; its source is always recorded as
dirty and remains content-pinned. These mechanisms preserve pending phase/final
qualification flags and do not promote earlier source-based development reports.

`fixtures/english-task-bank-v1.json` freezes twelve English outcome facets over
the existing pinned Host goldens, with three independent trial slots per task.
It grades the requested outcome rather than a particular tool sequence. The
labels are model-authored; independent human calibration is still required.
`tools/outcome_evaluation.py` supplies the deterministic scorer to the maintained
qualification tooling. It checks exact facts/grain/coverage, current sources and
the independently observed authority/accounting/deadline/effect guards. An
explicit identity set permits equivalent page order while rejecting duplicates
and out-of-scope records. Missing trials and repeated task/slot evidence cannot
receive complete-bank credit. No statistical confidence is inferred from this
small heterogeneous bank.

`tests/integration/resources/test_outcome_capture.py` exercises the existing
complete memory workflow and records its actual published field, current memory
references, original SQL accounting and source/bank pins before teardown. This
is one synthetic observation, leaving 35 trial slots unfinished. Source/report/
artifact provenance, actual provider execution and authoritative costs, complete
bank capture bindings, repeated live trials and human review are separate gates.
The scorer always labels API/release qualification pending; it authenticates no
observation, calls no provider, creates no resource root and grants no spending
or production activation. Run only the affected scorer/capture cases through the
existing guarded incremental runner. This addition requires no unchanged browser,
worker-package or UI acceptance rerun.

The scorer's `read_memory_capture` binds that specific reviewed observer to its
exact completed case, tested source archive, frozen bank/fixture bytes and four
independent artifact pins, using the existing qualification readers. It checks
the observation against the actual snapshot/current references and original held
accounting. An unrelated failure may retain this completed case while its
original aggregate remains failed. Substituted or unfinished evidence receives
no credit. Authority comes from a separate source-side review, never from a
capture's own claims. The result remains one synthetic observation; it cannot
qualify a different producer, live provider, human judgment or the full bank.

The separate live memory case uses the production assigned-worker entry, the
existing owned SQL-backed local Temporal service, offline exact memory recall,
and the actual OpenAI transport. The private navigation handoff supplies the
owner-selected recall context while preserving the original question as the
first SDK user message. Existing memory goal/answer contracts supply the SDK's
structured output; original Core validation still checks exact pins, current
sources, uniqueness, authority and satisfaction. Temporal version markers retain
legacy replay behavior. This uses the SDK's supported output-schema subtype and
serialized model-activity path, without new domain records or migrations.

Live execution requires the exact case
`tests/integration/resources/test_outcome_capture.py::test_live_openai_memory_outcome_on_original_owned_root`
and `--live-openai-qualification` through the existing G10
`foundation-conformance` runner and complete installed-release binding. The
argument names a private owned JSON file inside the external verification root:

```json
{
  "profile": "synthetic-openai-memory-qualification/1",
  "credentialFile": "/absolute/private/openai.env",
  "allowanceFile": "/absolute/existing/live-openai/allowance.json",
  "accountPolicyRef": "explicit-reviewed-standard-account-controls-reference"
}
```

The credential file contains one explicit `OPENAI_API_KEY` assignment. Ambient
credentials are ignored. Account-managed retention, disabled request storage and
the global endpoint are explicit configuration, not zero-retention or regional
residency guarantees. Only synthetic data is admitted by this qualification.

`tools/live_outcome.py` adapts the existing version-1 cumulative US$104 allowance
(owner amendment of October29). Retained US$100 and US$101 ledger snapshots remain readable
under their original ceiling; admission always uses the selected ledger's ceiling.
It never creates a replacement allowance or resets inherited UNKNOWN holds.
Before admission it atomically reserves the full finite original Root cost
ceiling. The source-owned SQL observer binds that exact Root/task/model/deadline
and settles only known, closed accounting with zero outstanding usage. Failed or
interrupted ambiguous usage remains held. Decimal elapsed-time metadata from the
inherited canary is retained; monetary arithmetic remains exact integer micros.
No automatic provider retry, resource grant or deadline extension is introduced.

The live case saves the actual snapshot/current references, provider usage and
request/response identities, original accounting, frozen bank/fixture pins,
encrypted private histories and current-access denial before teardown. Its
single engineering trial does not establish complete-bank pass rate, repeated
live qualification, independent human calibration or production activation.
The synthetic `read_memory_capture` reader intentionally cannot promote this
different live producer. Failed diagnostic runs remain separately recorded;
compatible UI/layout and package evidence is retained by its actual inputs.

`read_live_memory_capture` supports only that separately reviewed live producer.
Its source-side authority pins the original completed case, tested source archive,
observer/scorer/live-profile bytes, frozen bank, independent artifacts, exact
model meter, current-denial projection and immutable cumulative-ledger snapshot.
It requires the original Root/task/model/deadline settlement and checks every
distinct provider request/response against known usage, pinned prices and total
SQL token/cost accounting. Owner scope and the currently accepted memory revision
must agree with published evidence. A capture cannot certify its own usage or
refund an UNKNOWN target. Unrelated failed aggregates retain only the exact
completed subset and remain failed. This reader binds one actual observation;
it grants neither full-bank, repeated-trial nor human-calibration credit and
never changes the allowance. Saved passing evidence can be bound without
executing the product or making another provider call.

The `agent-lookup-read-journey/1` profile resolves resource labels before binding
an ordinary selected-record goal. It reuses the source-bound discovery prelude,
accepted read/tool journals, private goal record, fact compiler and publisher.
The original harness pins the allowed lookup capabilities. Execution tools stay
blocked until binding, and every selected resource ID must occur in accepted,
currently authorized lookup evidence. The complete causal graph stays checked;
only the goal-selected lanes supply answer facts. A lookup page is neither a
permission grant nor a substitute for the requested source fields.

The frozen direct-bill local profile uses actual WP invoice search and bill read,
including complete shared-bill authorization, line-grain face amount and the
invoice currency. Focused prerequisites exercise the actual serialized worker,
checkpoint, goal and downstream compiler, including repeated lookup projections.
Installed acceptance uses the retained SQL-backed local Temporal service, physical
worker replacement after accepted lookup, original accounting and completed
encrypted histories before teardown. Desktop acceptance checks current source
inspection, History/reload and authority withdrawal; unchanged mobile/layout
evidence is retained. No new persisted record or database migration is introduced.
Synthetic provider decisions remain confined to the existing qualification
fixture and are derived from actual tool/goal wires; worker configuration supplies
no business ID, amount or expected answer. These local checks do not qualify a
real-provider direct-bill capture, repeated bank trials, human judgment or release.

The separate live direct-bill observer selects only
`tests/integration/wp/test_lookup_read.py::test_live_openai_direct_bill_outcome_on_original_owned_root`
through the existing guarded Host composition and G10 independent installation.
It requires the explicit `synthetic-openai-lookup-qualification/1` controls, the
same original allowance/credential/privacy boundaries and a separately pinned
lookup meter. Its4096-token individual-output bound accommodates repeated full
fact references; memory retains its1024-token profile. Root ceilings, original
horizons, current authorization and UNKNOWN holds are unchanged.

The Host composition supplies existing operator-reviewed `RegisteredToolSchema`
semantics, checks their input schema against current MCP metadata, and registers
the bounded Agent catalog description. MCP server descriptions remain untrusted
and are not promoted. Focused prerequisites check both schema bounds and the
actual installed planner handoff before provider execution. The observer records
the published bill/amount/currency, currently inspected source rows, original SQL
accounting, provider identities/usage, completed private histories and current
access denial before teardown. Wrong-field observations remain failures; known
spend still settles and ambiguous usage remains held. A passing single capture
requires its separately reviewed source/Host/report/artifact/allowance binding
before outcome-bank credit, and establishes no repeated-trial, human or release
qualification. Compatible local browser and package evidence is retained.

`read_live_lookup_capture` binds that exact producer using the same completed-case,
source-inventory, installed-artifact, closed-meter, measured-pricing and original
allowance checks as the live memory reader. Its additional pinned Host report must
be the exact completed live composition with an unchanged source inventory and
the same frozen fixture. Current source-page digests, owner/resource identities,
published field selections and invoice/amount/currency projections must agree.
Allocation `net` cannot substitute for the face field. Missing, self-asserted,
UNKNOWN, repriced or renewed accounting is refused. Retained source, provider,
Host and denial evidence is read without executing work or changing the ledger.
The returned observation grants only its single declared trial; full-bank,
repeated-provider, human and deployment gates remain separate.

The exact missing-primitive observer selects
`tests/integration/resources/test_catalog_discovery_worker.py::test_live_openai_missing_primitive_outcome_on_original_owned_root`
with `synthetic-openai-catalog-qualification/1` controls through the existing G10
independent installation. It reuses the governed catalog/diagnosis executor,
production private worker and retained SQL-backed local Temporal. Its finite
1024-token output profile covers the167-byte closed missing-primitive draft;
original Root and allowance ceilings, privacy policies and deadlines stay fixed.
Cheap prerequisites exercise the exact frozen question through real serialized
SDK transitions, current metadata, goal binding, not-satisfied publication and
owner reload. The actual observer requires no business tool invocation or
published business facts, the precise supported diagnosis, original all-known
accounting, completed encrypted histories and current denial before teardown.
The expected public task state is failed/not-satisfied, not a completed business
answer. Single-trial capture and independent provenance binding remain separate;
full bank/repetitions/human/deployment qualification is not inferred.

`read_live_catalog_capture` binds that exact non-success producer with the shared
completed-case/source/artifact/model/price/original-allowance checks. A separately
pinned retained original-generation catalog observation must match the published
catalog version and include every immutable registration sequence up to that
version. Registration digests, revision selection and creation times are checked;
any latest qualified business primitive rejects a missing-primitive claim. The
proof explicitly records observation after teardown, with the application still
retired and Root closed; it grants no fresh authority or resumption. The published
answer must be the supported Core diagnosis with no business evidence, and the
public state remains failed/not-satisfied. Known usage and denied current access
must still match the original Root. Binding retained evidence executes no task,
makes no provider call and changes no allowance row.

`read_live_analysis_capture` binds the completed property-composition observer,
its shared collector and assigned-worker fixture, exact Host analysis case and
independent artifacts using those same source, model, price and original-ledger
checks. It validates the two publication-selected query pages as one complete
snapshot/cursor chain, their current owner/resource identities and public source
digests, and the derived table's source/resource binding. Independent Decimal
sums over the frozen allocation grain must match the published property-period
maximum; bill-face amounts, other currencies, missing pages and duplicate
allocations cannot substitute. Page presentation order and earlier tool/model
steps need not match one prescribed plan. Reload, denial, completed private
histories and all-known original closed accounting remain required.

The separate `read_live_analysis_failure_trace` authenticates a finished failed
trial's versions and known costs without manufacturing its absent final source,
reload or denial proof. It returns no accepted observation or bank-slot credit.
Neither reader can turn a synthetic service result, a corrected forensic trace
or an unfinished/failed case into live success. Reader vectors exercise these
boundaries without executing a provider or changing the allowance; actual live
capture, repeated trials and independent human calibration remain separate.

The frozen `all-pages` facet reuses that same adaptive query/SDK/exact-table
path with a criterion that returns every property total. Its independent local
case is `test_installed_all_pages_outcome`; actual-provider execution has its
own exact `test_live_openai_all_pages_outcome_on_original_owned_root` selection
and `synthetic-openai-analysis-pages-qualification/1` controls. It retains the
analysis meter, original allowance, deadlines and privacy boundaries. No model
configuration receives a business ID, expected total or computed winner.
`read_live_all_pages_capture` binds the separate case and Host evidence using
the shared complete query-chain checks. Every published USD property total,
global maximum and eligible bill must agree with the independently inspected
allocations; a winner-only table is insufficient. Optional separately labeled
winner rows are accepted without prescribing the earlier tool sequence. The
local synthetic workflow grants no real-provider or repeated-trial credit.

The `ambiguous-grain` facet evaluates the existing registered clarification
profile, with distinct property-period, property-bill-allocation and whole-bill
face choices. It is not a general ambiguity classifier. The actual SDK must
request owner input before binding a goal; the capture retains the original
question, current registered question view, `WAITING_INPUT` snapshot and no-effect
facts before cleanup. The fixture then uses the existing owner Stop command,
records its separate cancelled snapshot and known closed Root, and exports
completed private histories before teardown. Cleanup never supplies an owner
answer or turns the pending outcome into successful business completion.
The separate exact live case requires
`synthetic-openai-analysis-grain-qualification/1` controls and the unchanged
analysis meter/allowance. `read_live_grain_capture` authenticates the registered
policy and its source fixture, pending state, no-effect proof and original Stop
settlement independently. Local acceptance leaves actual-provider, repeated-trial
and human calibration open; missing allowance cannot authorize another trial.

The frozen `dependent-iteration` path reuses the existing allocation snapshot and
property-scoped query-job adapters. Current accepted allocation rows determine
the winning property ID before the later scoped query; the immutable goal keeps
period totals and allocated-bill amounts at their distinct grains. Exact values
come from the shared Core operator. Both source chains, job progress, owner
reload, current denial, original known accounting and completed private histories
are collected before teardown. The synthetic planner is a fixture; it is not
production question routing or live model qualification.

Its exact live entry is
`test_live_openai_dependent_iteration_outcome_on_original_owned_root`, with
`synthetic-openai-analysis-iteration-qualification/1` controls and the same analysis
meter and cumulative allowance. `read_live_dependent_iteration_capture` checks
the reviewed Host adapters, source-bound tool arguments and parent model, complete
query chains, independently derived winner/bill amounts and original settlement.
Alternate earlier tool steps are allowed. No new allowance, deadline, executor,
Core schema or production activation is introduced. Local acceptance does not
replace actual-provider repetitions or independent human calibration.


The distinct frozen `result-followup` question reuses that same source-dependent
pipeline: current authorized totals select the later property query, with both
source chains retained. Its installed capture and serialized SDK check preserve
the original question and collect final accounting and private histories before
teardown. The exact live entry is
`test_live_openai_result_followup_outcome_on_original_owned_root`, using
`synthetic-openai-analysis-followup-qualification/1` controls.
`read_live_result_followup_capture` requires that distinct completed source case,
Host case, outcome profile and frozen bank observation, then applies the same
query/selector/grain/authority/accounting checks. A dependent-iteration capture
cannot be relabeled as this outcome; local synthetic acceptance supplies no
actual-provider or repeated-trial credit.

Both dependent readers can also bind the existing before-teardown
`dependent-collector-input.json` through `planning_raw` and an independently
reviewed `planningSHA256`. This preserves a completed outcome when publication
rereads run in parallel after an earlier accepted discovery selected the winner.
The reader requires the exact saved snapshot, goal and publication bindings,
known original model producers, earlier acceptance, identical source rows and
scopes, and each snapshot's exact row-version hashes. Missing or substituted
planning evidence cannot replace the original serial causal check. Final source,
current-authority, independent arithmetic and original settlement checks remain.
The bound provenance retains the additional evidence hash; no task is re-executed.

The frozen `code-analysis` outcome uses the existing source-query, isolated native
program and source-selected child pipeline. Its three USD results retain distinct
property-period, property-bill-allocation and whole-bill grains. The public result
choices expose every metric and original input; the installed observer collects
current owner reload/denial, the original native binding/goal/program digest,
physical receipt, known accounting and completed encrypted histories before teardown.

Its exact live entry is
`test_live_openai_code_analysis_outcome_on_original_owned_root`, with
`synthetic-openai-analysis-native-qualification/1` controls. The existing analysis
model/privacy profile, original Root ceiling and cumulative allowance remain in force.
Reviewed fixture metadata supplies the current utility selector; it grants no new
resource authority. `read_live_code_analysis_capture` binds the exact completed
source/Host/artifact/capture/placement evidence, independently checks all three grains
and rejects UNKNOWN native usage or missing public results. It conservatively charges
the original Root's validated native cost plus independently priced provider usage;
it never releases inherited holds or creates another allowance. Synthetic acceptance
and read-only projection diagnostics supply no actual-provider or bank credit.

The frozen exact-chart question reuses the registered chart-analysis harness,
the same scoped paged allocation read and exact-summary operator. Its sole bar
chart and exact table contain all authorized USD property totals, with linked
current sources. Installed collection retains the original goal, preferred chart
surface, exact-table fallback, reload, denial, original accounting and completed
private histories before teardown. Existing renderer/mobile/layout evidence stays
compatible when only qualification fixtures change.

The exact live entry is `test_live_openai_exact_chart_outcome_on_original_owned_root`
with `synthetic-openai-analysis-chart-qualification/1` controls.
`read_live_exact_chart_capture` binds source/Host/artifact/goal evidence, checks
all source rows independently and verifies every bar against its exact table.
The original analysis privacy profile, Root ceiling, cumulative allowance and
UNKNOWN holds remain unchanged. Synthetic acceptance grants no live bank credit.

The frozen reviewed-actions outcome uses the existing typed preparation and
trusted owner-review workflow. The selected authorized item/version/proposed
fields come from reviewed fixture metadata; worker configuration supplies no
hidden arguments. The observer captures the exact current private owner view,
accepted preparation, original question and zero decisions/effects while the
task waits. An explicit fixture-owner Stop is recorded separately from that
waiting outcome. Installed acceptance requires its known original Root closure
and completed encrypted histories; the worker-free source prerequisite proves
only the persisted Stop fence. Neither path approves or applies a change.

`test_live_openai_review_before_effect_outcome_on_original_owned_root` requires
`synthetic-openai-review-qualification/1` controls. It keeps the existing analysis
meter/privacy, full original Root reserve and cumulative allowance.
`read_live_review_capture` binds the reviewed observer, selected-item fixtures,
actual Host sources, independent artifacts, exact historical proposal and
separate Stop settlement. A waiting owner review grants no execution authority;
synthetic acceptance grants no live-provider, repeated-trial or human credit.
