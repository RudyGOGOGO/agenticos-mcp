"""Synthetic model-authored proposal fixture; execute only inside the guest.

It consumes the declared JSONL fields and criteria, never expected answers or
Host identifiers. This fixture supplies repeatable local evidence, not API
generation qualification or a new production calculation engine.
"""
import json
import sys
from collections import defaultdict
from decimal import Decimal,localcontext,ROUND_HALF_EVEN


header=json.loads(sys.stdin.readline())
assert header['schema']=='agent-native-query-input/1'
queries={query['key']:[] for query in header['queries']}
ordinals={key:0 for key in queries}
for line in sys.stdin:
    page=json.loads(line);key=page['queryKey']
    assert page['pageOrdinal']==ordinals[key]
    ordinals[key]+=1;queries[key].extend(page['records'])


def identity(row,fields):return tuple(row[field] for field in fields)
def matches(row,filters):return all(row[rule['field']]==rule['value'] for rule in filters)
def fields(names,values):return [dict(name=name,value=value) for name,value in zip(names,values)]


metrics=[]
with localcontext() as arithmetic:
    arithmetic.prec=200
    for criterion in header['criteria']:
        rows=queries[criterion['queryKey']]
        population={identity(row,criterion['populationFields']) for row in rows if matches(row,criterion['populationFilters'])}
        selected=[row for row in rows if matches(row,criterion['populationFilters']) and matches(row,criterion['filters'])]
        # Different allocation rows may repeat one whole-bill value. Project
        # only the declared metric grain and semantics before deduplication;
        # irrelevant source fields do not turn that same bill into a conflict.
        relevant=set(criterion['grain']+criterion['groupBy']+criterion['populationFields']+[criterion['valueField']])
        if criterion['unitField'] is not None:relevant.add(criterion['unitField'])
        if criterion['latest'] is not None:relevant.update(criterion['latest']['groupBy']+[criterion['latest']['versionField']])
        if criterion['conversion'] is not None:
            relevant.update(criterion['conversion'][key] for key in ('factorField','targetUnitField','versionField'))
        unique={}
        for row in selected:
            key=identity(row,criterion['grain']);projection={field:row[field] for field in relevant}
            assert key not in unique or unique[key]==projection
            unique[key]=projection
        if criterion['latest'] is not None:
            latest=criterion['latest'];versions={}
            for row in unique.values():
                key=identity(row,latest['groupBy']);version=row[latest['versionField']]
                assert type(version) is int and version>=0
                versions[key]=max(version,versions.get(key,version))
            unique={key:row for key,row in unique.items() if row[latest['versionField']]==versions[identity(row,latest['groupBy'])]}
        groups=defaultdict(list);available=set();units={}
        for row in unique.values():
            person=identity(row,criterion['populationFields'])
            if person not in population or row[criterion['valueField']] is None:continue
            amount=Decimal(str(row[criterion['valueField']]));unit=row[criterion['unitField']]
            conversion=criterion['conversion']
            if conversion is not None:
                assert row[conversion['targetUnitField']]==conversion['targetUnit']
                assert row[conversion['factorField']] is not None and row[conversion['versionField']] is not None
                amount*=Decimal(row[conversion['factorField']]);unit=conversion['targetUnit']
            key=identity(row,criterion['groupBy'])
            assert key not in units or units[key]==unit
            units[key]=unit;groups[key].append(amount);available.add(person)
        computed={}
        for key,values in groups.items():
            operation=criterion['aggregate']
            if operation=='maximum':amount=max(values)
            elif operation=='minimum':amount=min(values)
            elif operation=='sum':amount=sum(values,Decimal(0))
            elif operation=='mean':amount=sum(values,Decimal(0))/len(values)
            else:raise ValueError('Unsupported synthetic proposal aggregate')
            computed[key]=amount
        ranking=criterion['ranking']
        if ranking!='all':
            partitions=defaultdict(list)
            for key,amount in computed.items():
                row=dict(zip(criterion['groupBy'],key));partition=identity(row,criterion['partitions'])
                partitions[partition].append(amount)
            choose=max if ranking=='maximum' else min
            computed={key:amount for key,amount in computed.items()
                if amount==choose(partitions[identity(dict(zip(criterion['groupBy'],key)),criterion['partitions'])])}
        quantum=Decimal(1).scaleb(-criterion['outputScale'])
        assert criterion['rounding']=='half-even' and criterion['ties']=='all' and criterion['nulls']=='omit-and-report'
        output=[[*fields(criterion['groupBy'],key),dict(name='value',value=format(amount.quantize(quantum,rounding=ROUND_HALF_EVEN),'f')),
            dict(name='unit',value=units[key])] for key,amount in computed.items()]
        metrics.append(dict(criterionId=criterion['id'],rows=output,eligible=len(population),available=len(available),
            missing=[fields(criterion['populationFields'],person) for person in population-available]))
print(json.dumps(dict(goalDigest=header['goalDigest'],metrics=metrics),ensure_ascii=False,separators=(',',':')))
