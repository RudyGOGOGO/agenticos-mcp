"""Use an actual Agno Agent as the lower-migration comparison candidate."""
import asyncio
import json

from agno.agent import Agent
from agno.models.base import Model
from agno.models.response import ModelResponse
from agno.tools.function import Function


class ChainModel(Model):
    def __init__(self):
        super().__init__(id="synthetic-sdk-comparison", name="Synthetic comparison", provider="local",
                         retries=0, retry_with_guidance=False, cache_response=False)
        self.calls = 0

    def invoke(self, *args, **kwargs):
        raise AssertionError("Only the asynchronous comparison is selected")

    def invoke_stream(self, *args, **kwargs):
        raise AssertionError("Streaming is not selected")

    async def ainvoke_stream(self, *args, **kwargs):
        raise AssertionError("Streaming is not selected")
        yield

    def _parse_provider_response(self, response, **kwargs):
        return response

    def _parse_provider_response_delta(self, response):
        return response

    async def ainvoke(self, *, messages, **kwargs):
        self.calls += 1
        values = [json.loads(m.get_content_string()) for m in messages if m.role == "tool"]
        latest = values[-1] if values else 0
        if latest == 12:
            return ModelResponse(content="Reached 12")
        return ModelResponse(tool_calls=[{"id": f"step-{latest}", "type": "function",
            "function": {"name": "advance", "arguments": json.dumps({"previous": latest})}}])


def test_actual_agno_agent_runs_repeated_result_dependent_tools():
    executed = []

    async def advance(previous: int) -> str:
        """Advance the synthetic value from its previous result."""
        executed.append(previous)
        return json.dumps(previous + 1)

    model = ChainModel()
    agent = Agent(model=model, tools=[Function.from_callable(advance)], tool_call_limit=None,
        telemetry=False, debug_mode=False, add_history_to_context=False,
        enable_agentic_memory=False, update_memory_on_run=False)
    result = asyncio.run(agent.arun("Advance twelve times"))
    assert result.content == "Reached 12"
    assert executed == list(range(12))
    assert model.calls == 13
