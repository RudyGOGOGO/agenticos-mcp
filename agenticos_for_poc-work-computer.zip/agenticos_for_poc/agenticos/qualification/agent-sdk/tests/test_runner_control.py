"""Qualification failures must not leave a test service consuming disk or CPU."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def test_timeout_terminates_a_child_that_outlives_its_parent(proof_root):
    file = Path(__file__).resolve().parents[3] / "tools/qualify_agent_sdk.py"
    spec = importlib.util.spec_from_file_location("sdk_qualification_runner", file)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    pid_file = proof_root / "orphan.pid"
    child = "import os,signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);open(os.environ['SDK_PID_FILE'],'w').write(str(os.getpid()));time.sleep(60)"
    parent = "import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',sys.argv[1]]);time.sleep(60)"
    env = {"PATH": os.environ["PATH"], "SDK_PID_FILE": str(pid_file)}
    code = runner.run_logged([sys.executable, "-c", parent, child], cwd=proof_root,
        env=env, log=proof_root / "orphan.log", timeout=.5)
    assert code == 124
    pid = int(pid_file.read_text())
    deadline = time.monotonic() + 3
    while True:
        status = subprocess.run(["ps", "-p", str(pid), "-o", "stat="],
                                capture_output=True, text=True, timeout=2)
        if status.returncode == 1 or status.stdout.strip().startswith("Z"):
            break
        assert time.monotonic() < deadline, "SDK test child survived runner timeout"
        time.sleep(.05)


def test_completed_case_evidence_survives_a_later_fixture_timeout(proof_root):
    """A killed aggregate must retain only cases whose teardown completed."""
    from agentic_os.adapters.local.resources import initialize_key, write_signed
    from agentic_os.adapters.local.files import private_directory
    candidate = Path(__file__).resolve().parents[1]
    spec = importlib.util.spec_from_file_location("sdk_qualification_runner",
        candidate.parents[1] / "tools/qualify_agent_sdk.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    target = proof_root / "interrupted-selection"
    private_directory(target)
    initialize_key(target, allowed_entries=set())
    write_signed(target / "manifest.json", {"version": 1,
        "profile": "agent-sdk-engineering/1", "root": str(target)}, target / "resource.key")
    (target / "conftest.py").write_bytes((candidate / "tests/conftest.py").read_bytes())
    (target / "test_interrupted.py").write_text('''import time
import pytest

@pytest.fixture
def blocked_setup():
    time.sleep(60)

def test_finished():
    assert True

def test_unfinished(blocked_setup):
    assert True
''')
    env = {**os.environ, "AGENTIC_OS_SDK_PROOF_ROOT": str(target)}
    code = runner.run_logged([sys.executable, "-m", "pytest", "-q",
        "test_interrupted.py"], cwd=target, env=env, log=target / "interrupted.log", timeout=5)
    assert code == 124
    rows = [json.loads(line) for line in (target / "completed-cases.jsonl").read_text().splitlines()]
    assert rows == [{"nodeid": "test_interrupted.py::test_finished", "result": "passed",
                    "phases": {"setup": "passed", "call": "passed", "teardown": "passed"}}]
    assert not (target / "junit.xml").exists()
    # A writer can die during its next JSON/UTF-8 record. The previous completed
    # lifecycle remains readable without crediting the unfinished suffix.
    journal=target/'completed-cases.jsonl'
    with journal.open('ab') as stream:stream.write(b'{"nodeid":"unfinished-\xe2')
    assert runner.completed_cases(journal)==rows
