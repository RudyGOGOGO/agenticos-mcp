"""The separately installed worker must fail closed on implicit configuration."""
import pytest
from agentic_os_agent_worker.policy import WorkerPolicy, HarnessPolicyError, verify_dependencies


def test_locked_worker_dependency_set_matches_the_installed_distribution():
    verify_dependencies()


def test_no_implicit_provider_or_tracing_is_selected():
    policy = WorkerPolicy(60_000)
    with pytest.raises(HarnessPolicyError):
        policy.plugin(None)
    config = policy.run_config(model_override="operator-model-profile/1")
    assert config.tracing_disabled is True
    assert config.model == "operator-model-profile/1"


@pytest.mark.parametrize("timeout", [True, 0, -1, 900_001, 1.5])
def test_request_timeout_is_an_explicit_finite_request_policy(timeout):
    with pytest.raises(HarnessPolicyError):
        WorkerPolicy(timeout)


@pytest.mark.parametrize('request_ms,task_seconds',[(30000,30),(45000,45),(900000,120)])
def test_private_decode_window_is_bounded_without_raising_the_request_policy(request_ms,task_seconds):
    from datetime import timedelta
    policy=WorkerPolicy(request_ms)
    assert policy.workflow_task_timeout==timedelta(seconds=task_seconds)
    assert policy.operation_timeout_ms==request_ms
