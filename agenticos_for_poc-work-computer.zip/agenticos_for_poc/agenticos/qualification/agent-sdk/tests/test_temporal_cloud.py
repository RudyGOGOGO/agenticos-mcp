"""Cloud transport prerequisites through the installed assigned-worker router."""
import asyncio
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import hashlib
import importlib.util
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

import pytest
from temporalio.api.workflowservice.v1 import DescribeNamespaceResponse

from agentic_os_agent_worker.temporal_cloud import CloudTemporalConnection
from agentic_os_agent_worker.sdk_model import SDKModelPolicyError
from test_parallel_children import fixture,sample
from test_sdk_model import binding_fixture


def configuration(installation=None,*,backend='cloud'):
    path=Path(__file__).parents[3]/'tests/temporal_tls.py'
    spec=importlib.util.spec_from_file_location('cloud_tls_fixture',path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    namespace='production.a1b2c';host=namespace+'.tmprl.cloud' if backend=='cloud' else 'temporal.agentic-os.test';tls=module.certificates(host)
    value=dict(profile='temporal-cloud-mtls/1',installationId=installation or str(uuid4()),namespace=namespace,
        namespaceId=str(uuid4()),retentionDays=1,serverCA=tls['ca'].decode(),
        serverCASha256=hashlib.sha256(tls['ca']).hexdigest(),certificate=tls['client'][0].decode(),
        privateKey=tls['client'][1].decode(),resumeExisting=False)
    if backend=='self-hosted':value.update(profile='temporal-self-hosted-mtls/1',endpoint=host,serverName=host)
    return value,tls


@pytest.mark.parametrize('backend',['cloud','self-hosted'])
def test_static_configuration_cli_checks_real_parsers_without_task_token_or_network(proof_root,monkeypatch,capsys,backend):
    from dataclasses import asdict
    import json,sys,socket
    from agentic_os_agent_worker import task_service
    from provider_transport_fixture import privacy_configuration
    transport,_,binding=binding_fixture();transport=privacy_configuration(transport)
    cloud,_=configuration(binding['context']['subject']['installationId'],backend=backend)
    value=dict(profile='assigned-read-'+backend+'/1',target=CloudTemporalConnection(cloud).target,
        namespace=cloud['namespace'],temporal=cloud,kernelOrigin='https://core.agentic-os.test',
        workloadTokenRoot=str(proof_root/'future-projected-token'),transport=asdict(transport),
        apiKey='PRIVATE-PROVIDER-CANARY',historyKeyId=str(uuid4()),historyKeyHex='ab'*32)
    path=proof_root/'static-worker.json'
    def forbidden(*a,**kw):raise AssertionError('Static validation attempted task/network/token activity')
    monkeypatch.setattr(task_service,'assigned_main',forbidden)
    monkeypatch.setattr(CloudTemporalConnection,'connect',forbidden)
    monkeypatch.setattr(socket,'create_connection',forbidden)
    class NoStart:
        @property
        def buffer(self):raise AssertionError('No future task start may be read')
    monkeypatch.setattr(sys,'stdin',NoStart())
    def check(document,*extra):
        raw=json.dumps(document).encode();path.write_bytes(raw);path.chmod(0o600)
        monkeypatch.setattr(sys,'argv',['assigned-worker','--configuration',str(path),
            '--configuration-sha256',hashlib.sha256(raw).hexdigest(),'--check-configuration',*extra])
        return task_service.main()
    assert check(value)==0
    result=json.loads(capsys.readouterr().out)
    assert result['state']=='configuration-validated' and result['installationId']==cloud['installationId']
    assert result['namespaceId']==cloud['namespaceId'] and result['modelProfileDigests']==[transport.model_profile_digest]
    assert result['runtimeStarted'] is False and result['newProviderCalls']==0
    assert not (proof_root/'future-projected-token').exists()
    for mutation in [dict(unrecognized='private'),dict(apiKey=''),dict(target='wrong:7233'),
            dict(namespace='foreign'),dict(historyKeyHex='00'),dict(workloadTokenRoot='relative'),
            dict(workloadToken='PRIVATE-AMBIGUOUS'),dict(rpcTLS=dict(ca='wrong',sha256='0'*64))]:
        assert check(value|mutation)==1
        output=capsys.readouterr()
        assert output.out=='' and output.err=='assigned_worker_unavailable\n'
        assert 'PRIVATE-PROVIDER-CANARY' not in output.err
    assert check(value,'--start-file',str(proof_root/'future-start.json'))==1
    assert not (proof_root/'future-start.json').exists()


def test_serialized_cloud_recovery_probe_reaches_actual_assigned_router(proof_root):
    from dataclasses import asdict
    import json
    import agentic_os_agent_worker
    from agentic_os_agent_worker import task_service
    from agentic_os_agent_worker.sdk_model import GovernedResponsesModel
    from agentic_os_agent_worker.workflow_control import WorkflowControl
    from provider_transport_fixture import fixture as transport_fixture,privacy_configuration
    value,_=fixture();config,request,_,_=transport_fixture('openai');config=privacy_configuration(config)
    context=request['context'];context['model']['digest']=config.model_profile_digest
    context['authorizationHorizon']=(datetime.now(timezone.utc)+timedelta(minutes=2)).isoformat().replace('+00:00','Z')
    value['start'].update(context=context,modelId=config.model_id,checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        childContinuations=[],childAfter=None,childContinuation=None)
    cloud,tls=configuration(context['subject']['installationId'])
    cloud['resumeExisting']=False
    path=Path(__file__).parents[3]/'tests/integration/resources/assigned_read_probe.py'
    installed=Path(agentic_os_agent_worker.__file__).parent
    sources={str(p.relative_to(installed)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in installed.rglob('*') if p.is_file() and p.suffix in {'.py','.json'}}
    document=dict(workerSource=sources,transport=asdict(config),temporalCloud=cloud,
        target=cloud['namespace']+'.tmprl.cloud:7233',namespace=cloud['namespace'],cloudRoute='127.0.0.1:17233',
        origin='https://localhost:18443',token='PRIVATE-WORKLOAD-CANARY',mode='child-reads-reference',
        workerFailure=str(proof_root/'cloud-probe-failure.json'),historyKeyId=str(uuid4()),historyKeyHex='ab'*32,
        rpcTLS=dict(ca=tls['ca'].decode(),sha256=hashlib.sha256(tls['ca']).hexdigest()))
    import os,subprocess,sys
    settings=proof_root/'cloud-probe.json'
    settings.write_text(json.dumps(dict(document=document,start=value,probe=str(path))));settings.chmod(0o600)
    # The runner imports Core for admission guards. The actual assigned probe
    # runs in the same installed worker-only interpreter used by the service.
    code=r'''import asyncio,importlib.util,json,sys
from datetime import timedelta
from pathlib import Path
from agentic_os_agent_worker import task_service
from agentic_os_agent_worker.temporal_cloud import CloudTemporalConnection
from agentic_os_agent_worker.workflow_control import WorkflowControl
incoming=json.loads(Path(sys.argv[1]).read_bytes());document=incoming['document'];value=incoming['start']
context=value['start']['context'];seen=[]
assert importlib.util.find_spec('agentic_os') is None
spec=importlib.util.spec_from_file_location('cloud_recovery_assigned_probe',incoming['probe'])
probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
class Finished:
    async def result(self):return WorkflowControl(context['rootId'],context['taskId'],None,'candidate-ready')
class Client:
    async def start_workflow(self,workflow,original,**kwargs):
        assert original==value and kwargs['retry_policy'].maximum_attempts==1
        seen.append(('start',kwargs));return Finished()
async def connect(self,**kwargs):
    assert self.configuration==document['temporalCloud'] and kwargs['data_converter'].payload_codec is not None
    seen.append(('cloud',self.namespace));return Client()
CloudTemporalConnection.connect=connect
class Worker:
    def __init__(self,client,**kwargs):seen.append(('worker',kwargs['task_queue']))
    async def __aenter__(self):return self
    async def __aexit__(self,*args):pass
task_service.Worker=Worker
parsed=probe.parse_start(json.dumps(value).encode())
assert probe.serve_read_task is task_service.serve_read_task
asyncio.run(probe.run(document,parsed))
assert [row[0] for row in seen]==['cloud','worker','worker','start']
assert seen[-1][1]['execution_timeout']<=timedelta(minutes=2)
assert not Path(document['workerFailure']).exists()
'''
    child=subprocess.run([sys.executable,'-I','-B','-c',code,str(settings)],cwd=proof_root,
        env={k:v for k,v in os.environ.items() if k in {'PATH','TMPDIR','OPENAI_AGENTS_DISABLE_TRACING'}},
        capture_output=True,text=True,timeout=20)
    assert child.returncode==0,child.stderr
    assert 'candidate-ready' in child.stdout
    assert all(secret not in child.stdout+child.stderr for secret in (document['token'],cloud['privateKey']))


@pytest.mark.parametrize('backend',['cloud','self-hosted'])
def test_cloud_transport_validates_identity_namespace_retention_and_keeps_private_converter(monkeypatch,backend):
    from agentic_os_agent_worker import temporal_cloud as module
    value,_=configuration(backend=backend);connection=CloudTemporalConnection(value);events=[]
    response=DescribeNamespaceResponse();response.namespace_info.name=value['namespace']
    response.namespace_info.id=value['namespaceId'];response.namespace_info.state=1
    response.config.workflow_execution_retention_ttl.seconds=86400
    converter,plugin=object(),object()
    async def health():return True
    async def describe(request,**kwargs):events.append('namespace');return response
    async def connect(target,**kwargs):
        events.append('tls')
        assert target==connection.target and kwargs['namespace']==value['namespace']
        assert kwargs['tls'].domain==connection.server_name
        assert kwargs['tls'].client_private_key==value['privateKey'].encode()
        assert kwargs['data_converter'] is converter and kwargs['plugins']==[plugin]
        return SimpleNamespace(service_client=SimpleNamespace(check_health=health),
            workflow_service=SimpleNamespace(describe_namespace=describe))
    monkeypatch.setattr(module.Client,'connect',connect)
    asyncio.run(connection.connect(data_converter=converter,plugins=[plugin]))
    response.namespace_info.id=str(uuid4())
    with pytest.raises(SDKModelPolicyError):asyncio.run(connection.connect(data_converter=converter,plugins=[plugin]))
    response.namespace_info.id=value['namespaceId'];response.config.workflow_execution_retention_ttl.seconds=2*86400
    with pytest.raises(SDKModelPolicyError):asyncio.run(connection.connect(data_converter=converter,plugins=[plugin]))
    assert events==['tls','namespace']*3 and 'PRIVATE KEY' not in repr(connection)
    value['namespace']='foreign.a1b2c';assert connection.namespace=='production.a1b2c'
    for changes in [dict(privateKey='PRIVATE-CANARY'),dict(namespace='default'),dict(retentionDays=True),
            dict(namespaceId='foreign'),dict(serverCASha256='0'*64),dict(apiKey='PRIVATE-CANARY')]:
        with pytest.raises(SDKModelPolicyError):CloudTemporalConnection(connection.configuration|changes)


@pytest.mark.parametrize('backend',['cloud','self-hosted'])
def test_actual_assigned_worker_router_uses_cloud_connection_only_after_original_start_guards(monkeypatch,backend):
    from agentic_os_agent_worker import task_service
    value,_=fixture();config,_,binding=binding_fixture();context=binding['context']
    context['authorizationHorizon']=(datetime.now(timezone.utc)+timedelta(minutes=1)).isoformat().replace('+00:00','Z')
    clock=[datetime.fromisoformat(context['authorizationHorizon'].replace('Z','+00:00'))-timedelta(minutes=1)]
    class Clock(datetime):
        @classmethod
        def now(cls,tz=None):return clock[0]
    monkeypatch.setattr(task_service,'datetime',Clock)
    value['start'].update(context=context,modelId=config.model_id,checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        childContinuations=[],childAfter=None,childContinuation=None)
    cloud,_=configuration(context['subject']['installationId'],backend=backend);connection=CloudTemporalConnection(cloud)
    from agentic_os_agent_worker.model_rpc import RPCModelBoundary
    async def token():return 'synthetic-workload'
    boundary=RPCModelBoundary('https://core.agentic-os.test',token)
    transport=SimpleNamespace(boundary=boundary,config=config);seen=[]
    converter,plugin=object(),object()
    monkeypatch.setattr(task_service,'agent_converter',lambda *args,**kwargs:converter)
    monkeypatch.setattr(task_service,'agent_plugin',lambda *args,**kwargs:plugin)
    class Finished:
        async def result(self):return 'original-result'
    class Client:
        async def start_workflow(self,*args,**kwargs):
            seen.append(('start',kwargs));return Finished()
        def get_workflow_handle(self,ident):
            seen.append(('lookup',ident));raise SDKModelPolicyError()
    async def connect(self,**kwargs):
        assert kwargs==dict(data_converter=converter,plugins=[plugin]);seen.append(('cloud',None))
        clock[0]+=timedelta(seconds=10);return Client()
    monkeypatch.setattr(CloudTemporalConnection,'connect',connect)
    async def forbidden(*args,**kwargs):raise AssertionError('Cloud selected the plaintext local connector')
    monkeypatch.setattr(task_service.Client,'connect',forbidden)
    class Worker:
        def __init__(self,*args,**kwargs):seen.append(('worker',kwargs['task_queue']))
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
    monkeypatch.setattr(task_service,'Worker',Worker)
    async def run(start=value,**changes):
        return await task_service.serve_read_task(target=connection.target,namespace=connection.namespace,
            boundary=boundary,transport=transport,history_keys=None,history_key_id='original',start=start,
            cloud_connection=connection,**changes)
    assert asyncio.run(run())=='original-result'
    assert [event[0] for event in seen]==['cloud','worker','worker','start']
    start=seen[-1][1];assert start['execution_timeout']==timedelta(seconds=50)
    assert str(start['id']).endswith(context['taskId']) and start['retry_policy'].maximum_attempts==1
    seen.clear();changed=deepcopy(value);changed['start']['context']['subject']['installationId']=str(uuid4())
    with pytest.raises(SDKModelPolicyError):asyncio.run(run(changed))
    changed=deepcopy(value);changed['childContinuations']=[sample('AgentSDKChildContinuation')]
    with pytest.raises(SDKModelPolicyError):asyncio.run(run(changed))
    with pytest.raises(SDKModelPolicyError):asyncio.run(run(local_synthetic=True))
    assert seen==[]
    connection.configuration['resumeExisting']=True
    with pytest.raises(SDKModelPolicyError):asyncio.run(run())
    assert [event[0] for event in seen]==['cloud','worker','worker','lookup']
    asyncio.run(boundary.close())


@pytest.mark.parametrize('backend',['cloud','self-hosted'])
def test_serialized_private_cloud_assignment_selects_tls_and_https_without_credential_disclosure(proof_root,monkeypatch,capsys,backend):
    from dataclasses import asdict
    import json
    from agentic_os_agent_worker import task_service
    from agentic_os_agent_worker.model_rpc import ModelRPCError
    from agentic_os_agent_worker.workflow_control import WorkflowControl
    from provider_transport_fixture import privacy_configuration
    value,_=fixture();config,_,binding=binding_fixture();context=binding['context']
    config=privacy_configuration(config);context['model']['digest']=config.model_profile_digest
    value['start'].update(context=context,modelId=config.model_id,checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        childContinuations=[],childAfter=None,childContinuation=None)
    cloud,_=configuration(context['subject']['installationId'],backend=backend);seen=[]
    document=dict(profile='assigned-read-'+backend+'/1',target=CloudTemporalConnection(cloud).target,namespace=cloud['namespace'],
        temporal=cloud,kernelOrigin='https://core.agentic-os.test',workloadToken='PRIVATE-WORKLOAD-CANARY',
        transport=asdict(config),apiKey='PRIVATE-PROVIDER-CANARY',historyKeyId=str(uuid4()),historyKeyHex='ab'*32)
    path=proof_root/'private-cloud-assignment.json';path.write_text(json.dumps(document));path.chmod(0o600)
    decoded=task_service._private_configuration(path)
    async def serve(**kwargs):
        seen.append(kwargs)
        assert kwargs['local_synthetic'] is False and type(kwargs['cloud_connection']) is CloudTemporalConnection
        assert kwargs['boundary'].base_url=='https://core.agentic-os.test'
        assert kwargs['cloud_connection'].target==kwargs['target'] and kwargs['cloud_connection'].namespace==kwargs['namespace']
        assert kwargs['history_keys']._key(document['historyKeyId'])==bytes.fromhex(document['historyKeyHex'])
        return WorkflowControl(context['rootId'],context['taskId'],None,'candidate-ready')
    monkeypatch.setattr(task_service,'serve_read_task',serve)
    asyncio.run(task_service.assigned_main(decoded,value))
    assert len(seen)==1
    output=capsys.readouterr()
    assert all(secret not in output.out+output.err for secret in [document['workloadToken'],document['apiKey'],cloud['privateKey']])
    document['kernelOrigin']='http://127.0.0.1:8890'
    with pytest.raises(ModelRPCError):asyncio.run(task_service.assigned_main(document,value))
    assert len(seen)==1


def test_serialized_assigned_worker_rotates_projection_and_routes_native_acceptance_without_moving_core_sources(proof_root,monkeypatch,capsys):
    from dataclasses import asdict
    import json
    import httpx
    from agentic_os_agent_worker import task_service
    from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
    from agentic_os_agent_worker.workflow_control import WorkflowControl
    from provider_transport_fixture import privacy_configuration
    from test_native_tool import native_accepted,program
    from test_tool_rpc import fixture as tool_fixture
    from test_workload import rotate
    value,_=fixture();config,request,_=tool_fixture();config=privacy_configuration(config)
    context=request['context'];context['model']['digest']=config.model_profile_digest
    request['argumentsJson']=json.dumps(program());value['start'].update(context=context,modelId=config.model_id,checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        childContinuations=[],childAfter=None,childContinuation=None)
    reply=native_accepted(request)
    source=sample('AgentNativeSourceState');source.update(context=deepcopy(context),result=deepcopy(reply['accepted']['result']))
    source['goal']['context']=deepcopy(context)
    projection=proof_root/'projection';projection.mkdir(mode=0o700)
    first='e30.e30.'+'a'*43;second='e30.e30.'+'b'*43;rotate(projection,1,first)
    cloud,_=configuration(context['subject']['installationId']);sent=[];seen=[]
    document=dict(profile='assigned-read-cloud/1',target=cloud['namespace']+'.tmprl.cloud:7233',namespace=cloud['namespace'],
        temporal=cloud,kernelOrigin='https://core.agentic-os.test',nativeOrigin='https://native.agentic-os.test',
        workloadTokenRoot=str(projection),transport=asdict(config),apiKey='PRIVATE-PROVIDER-CANARY',
        historyKeyId=str(uuid4()),historyKeyHex='ab'*32)
    async def remote(incoming):
        body=json.loads(incoming.content);sent.append(incoming)
        assert body['transport']['modelDigest']==context['model']['digest']
        assert incoming.headers['authorization']=='Bearer '+(first if len(sent)==1 else second)
        assert first not in incoming.content.decode() and second not in incoming.content.decode()
        if incoming.url.path.endswith('/execute-native'):
            assert incoming.url.host=='native.agentic-os.test' and body['request']==request
            return httpx.Response(200,json=reply)
        assert incoming.url.host=='core.agentic-os.test' and incoming.url.path.endswith('/native-source-state')
        assert body['context']==context and body['operationId']==request['modelOperationId']
        return httpx.Response(200,json=source)
    def boundary(*args,**kwargs):return RPCModelBoundary(*args,**kwargs,network_transport=httpx.MockTransport(remote))
    monkeypatch.setattr(task_service,'RPCModelBoundary',boundary,raising=False)
    # assigned_main imports the supported class locally, so replace that
    # module export while keeping this test's real class for construction.
    import agentic_os_agent_worker.model_rpc as rpc_module
    monkeypatch.setattr(rpc_module,'RPCModelBoundary',boundary)
    async def serve(**kwargs):
        seen.append(kwargs);client=kwargs['boundary']
        assert type(kwargs['cloud_connection']) is CloudTemporalConnection and kwargs['local_synthetic'] is False
        assert await client.execute_native(request)==reply
        rotate(projection,2,second)
        assert await client.native_source_state(context,request['modelOperationId'])==source
        (projection/'token').unlink()
        with pytest.raises(ModelRPCError):await client.execute_native(request)
        assert len(sent)==2
        return WorkflowControl(context['rootId'],context['taskId'],None,'candidate-ready')
    monkeypatch.setattr(task_service,'serve_read_task',serve)
    path=proof_root/'assigned.json';path.write_text(json.dumps(document));path.chmod(0o600)
    asyncio.run(task_service.assigned_main(task_service._private_configuration(path),value))
    assert len(seen)==1 and len(sent)==2
    for bad in [document|dict(workloadToken=first),document|dict(nativeOrigin='http://127.0.0.1:80'),
            document|dict(nativeOrigin=None)]:
        with pytest.raises((SDKModelPolicyError,ModelRPCError)):asyncio.run(task_service.assigned_main(bad,value))
    assert len(seen)==1 and len(sent)==2
    output=capsys.readouterr()
    assert all(secret not in output.out+output.err for secret in [first,second,document['apiKey'],cloud['privateKey']])


def test_private_planner_projection_and_history_keys_remain_distinct_and_close_after_failed_preparation(proof_root,monkeypatch):
    from dataclasses import asdict,replace
    import json
    from agentic_os_agent_worker import task_service
    from provider_transport_fixture import fixture as transport_fixture,privacy_configuration
    from test_workload import rotate
    config,_,_,_=transport_fixture('openai');public=privacy_configuration(config)
    profile=json.loads(config.model_profile_json);profile.update(id='synthetic-private-model',credentialRef='private-model-credential')
    fingerprint=hashlib.sha256(b'agentic-os.hash/1\0manifest\0'+json.dumps(profile,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    private=privacy_configuration(replace(config,credential_ref=profile['credentialRef'],model_profile_json=json.dumps(profile),model_profile_digest=fingerprint))
    start=sample('AgentSDKPrivatePlannedReadJourneyStart');cloud,_=configuration(start['start']['context']['subject']['installationId'])
    roots=[]
    for name,letter in [('public','a'),('private','b')]:
        root=proof_root/name;root.mkdir(mode=0o700);rotate(root,1,'e30.e30.'+letter*43);roots.append(root)
    document=dict(profile='assigned-private-planned-read-cloud/1',target=cloud['namespace']+'.tmprl.cloud:7233',namespace=cloud['namespace'],
        temporal=cloud,kernelOrigin='https://core.agentic-os.test',nativeOrigin='https://native.agentic-os.test',
        workloadTokenRoot=str(roots[0]),transport=asdict(public),apiKey='PUBLIC-PROVIDER',historyKeyId=str(uuid4()),historyKeyHex='ab'*32,
        planner=dict(workloadTokenRoot=str(roots[1]),transport=asdict(private),apiKey='PRIVATE-PROVIDER',
            historyKeyId=str(uuid4()),historyKeyHex='cd'*32,meterPolicyJson=json.dumps(sample('AgentModelMeterPolicy'))))
    clients=[]
    async def serve(**kwargs):
        planner=kwargs['planner'];clients.extend([kwargs['boundary'],planner['boundary']])
        assert clients[0] is not clients[1] and clients[0].native_base_url==clients[1].native_base_url==document['nativeOrigin']
        assert await clients[0].token_provider()=='e30.e30.'+'a'*43
        assert await clients[1].token_provider()=='e30.e30.'+'b'*43
        rotate(roots[1],2,'e30.e30.'+'c'*43)
        assert await clients[1].token_provider()=='e30.e30.'+'c'*43
        assert await clients[0].token_provider()=='e30.e30.'+'a'*43
        assert kwargs['transport'].config.credential_ref!=planner['transport'].config.credential_ref
        assert kwargs['history_keys']._key(document['historyKeyId'])!=planner['historyKeys']._key(document['planner']['historyKeyId'])
        raise SDKModelPolicyError()
    monkeypatch.setattr(task_service,'serve_read_task',serve)
    path=proof_root/'private-planner.json';path.write_text(json.dumps(document));path.chmod(0o600)
    with pytest.raises(SDKModelPolicyError):asyncio.run(task_service.assigned_main(task_service._private_configuration(path),start))
    assert len(clients)==2 and all(client.client.is_closed for client in clients)
    document['planner']['workloadToken']='FORBIDDEN-FALLBACK'
    with pytest.raises(SDKModelPolicyError):asyncio.run(task_service.assigned_main(document,start))
    assert len(clients)==2


def test_assigned_cli_private_start_file_preserves_original_serialized_start_without_reading_stdin(proof_root,monkeypatch,capsys):
    import json,sys
    from types import SimpleNamespace
    from agentic_os_agent_worker import task_service
    value=sample('AgentSDKQuerySourceChildJoinJourneyStart');configuration={'privateFixture':'PRIVATE-CONFIG-CANARY'}
    start=proof_root/'start.json';settings=proof_root/'settings.json'
    start.write_text(json.dumps(value));start.chmod(0o600)
    settings.write_text(json.dumps(configuration));settings.chmod(0o600);seen=[]
    class NoPipe:
        def read(self,*args):raise AssertionError('Explicit original start must not read an ambient pipe')
    async def assigned(config,original):seen.append((config,original))
    monkeypatch.setattr(task_service,'assigned_main',assigned)
    monkeypatch.setattr(sys,'stdin',SimpleNamespace(buffer=NoPipe()))
    monkeypatch.setattr(sys,'argv',['worker','--configuration',str(settings),'--start-file',str(start)])
    assert task_service.main()==0 and seen==[(configuration,value)]
    start.chmod(0o644);assert task_service.main()==1 and len(seen)==1
    start.chmod(0o600);original=start.read_text();start.write_text(original[:-1]);assert task_service.main()==1 and len(seen)==1
    start.write_text(original);alias=proof_root/'start-alias';alias.symlink_to(start)
    monkeypatch.setattr(sys,'argv',['worker','--configuration',str(settings),'--start-file',str(alias)])
    assert task_service.main()==1 and len(seen)==1
    output=capsys.readouterr()
    assert 'PRIVATE-CONFIG-CANARY' not in output.out+output.err and str(start) not in output.err


def test_assigned_configuration_pin_is_checked_before_stdin_or_worker_start(proof_root,monkeypatch,capsys):
    import json,sys
    from agentic_os_agent_worker import task_service
    value=sample('AgentSDKQuerySourceChildJoinJourneyStart');configuration={'privateFixture':'PRIVATE-CONFIG-PIN-CANARY'}
    settings=proof_root/'pinned-settings.json';settings.write_text(json.dumps(configuration));settings.chmod(0o600)
    pin=hashlib.sha256(settings.read_bytes()).hexdigest();seen=[];reads=[]
    class Pipe:
        def read(self,maximum):reads.append(maximum);return json.dumps(value).encode()
    async def assigned(config,original):seen.append((config,original))
    monkeypatch.setattr(task_service,'assigned_main',assigned)
    monkeypatch.setattr(sys,'stdin',SimpleNamespace(buffer=Pipe()))
    command=['worker','--configuration',str(settings),'--configuration-sha256',pin]
    monkeypatch.setattr(sys,'argv',command);assert task_service.main()==0 and seen==[(configuration,value)]
    assert reads==[16*1024**2+1]
    for wrong in ('f'*64,'alias','F'*64):
        command[-1]=wrong
        assert task_service.main()==1 and len(seen)==len(reads)==1
    command[-1]=pin;settings.write_text(json.dumps(configuration|{'changed':True}))
    assert task_service.main()==1 and len(seen)==len(reads)==1
    output=capsys.readouterr()
    assert 'PRIVATE-CONFIG-PIN-CANARY' not in output.out+output.err and str(settings) not in output.err


def test_assigned_rpc_tls_pins_private_service_ca_and_rejects_untrusted_peer_before_sending_credentials(proof_root,monkeypatch,capsys):
    from dataclasses import asdict
    from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
    from threading import Thread
    import json,ssl
    from agentic_os_agent_worker import task_service
    from agentic_os_agent_worker.model_rpc import ModelRPCError,RPCModelBoundary
    from agentic_os_agent_worker.workflow_control import WorkflowControl
    from provider_transport_fixture import fixture as transport_fixture,privacy_configuration
    value,_=fixture();config,request,body,_=transport_fixture('openai');config=privacy_configuration(config)
    context=request['context'];context['model']['digest']=config.model_profile_digest
    value['start'].update(context=context,modelId=config.model_id,checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        childContinuations=[],childAfter=None,childContinuation=None)
    cloud,_=configuration(context['subject']['installationId'])
    path=Path(__file__).parents[3]/'tests/temporal_tls.py';spec=importlib.util.spec_from_file_location('rpc_tls_fixture',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);material=module.certificates('localhost');calls=[]
    cert=proof_root/'rpc-server.pem';key=proof_root/'rpc-server.key';cert.write_bytes(material['server'][0]);key.write_bytes(material['server'][1])
    cert.chmod(0o600);key.chmod(0o600)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            assert self.path=='/private/agent/model/begin'
            assert self.headers['Authorization']=='Bearer PRIVATE-RPC-CANARY'
            content=json.loads(self.rfile.read(int(self.headers['Content-Length'])));calls.append(content)
            assert content['request']==request and content['transport']['modelDigest']==config.model_profile_digest
            raw=json.dumps(dict(inputJson=json.dumps(body))).encode()
            self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
    tls=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);tls.load_cert_chain(cert,key)
    server.socket=tls.wrap_socket(server.socket,server_side=True)
    thread=Thread(target=server.serve_forever,daemon=True);thread.start()
    document=dict(profile='assigned-read-cloud/1',target=cloud['namespace']+'.tmprl.cloud:7233',namespace=cloud['namespace'],temporal=cloud,
        kernelOrigin='https://localhost:'+str(server.server_port),workloadToken='PRIVATE-RPC-CANARY',
        transport=asdict(config),apiKey='PRIVATE-PROVIDER-CANARY',historyKeyId=str(uuid4()),historyKeyHex='ab'*32,
        rpcTLS=dict(ca=material['ca'].decode(),sha256=hashlib.sha256(material['ca']).hexdigest()))
    async def serve(**kwargs):
        assert await kwargs['boundary'].begin_model(request)==json.dumps(body)
        return WorkflowControl(context['rootId'],context['taskId'],None,'candidate-ready')
    monkeypatch.setattr(task_service,'serve_read_task',serve)
    try:
        settings=proof_root/'rpc-assignment.json';settings.write_text(json.dumps(document));settings.chmod(0o600)
        asyncio.run(task_service.assigned_main(task_service._private_configuration(settings),value));assert len(calls)==1
        # Correctly pinned but unrelated trust cannot authenticate the actual
        # server. No request/token is sent and there is no transport retry.
        other=module.certificates('localhost')['ca']
        wrong=deepcopy(document);wrong['rpcTLS']=dict(ca=other.decode(),sha256=hashlib.sha256(other).hexdigest())
        with pytest.raises(ModelRPCError):asyncio.run(task_service.assigned_main(wrong,value))
        assert len(calls)==1
        wrong=deepcopy(document);wrong['rpcTLS']['sha256']='0'*64
        with pytest.raises(SDKModelPolicyError):asyncio.run(task_service.assigned_main(wrong,value))
        assert len(calls)==1
        unsafe=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);unsafe.check_hostname=False;unsafe.verify_mode=ssl.CERT_NONE
        with pytest.raises(ModelRPCError):RPCModelBoundary(document['kernelOrigin'],lambda:None,tls_context=unsafe)
    finally:server.shutdown();server.server_close();thread.join(5)
    assert not thread.is_alive()
    output=capsys.readouterr();assert all(secret not in output.out+output.err for secret in (document['workloadToken'],document['apiKey'],cloud['privateKey']))
