"""Scoped navigation through actual SDK tools and metered dependency indexes."""
import asyncio
from collections import Counter
from copy import deepcopy
from dataclasses import replace
import json
from uuid import UUID,uuid5

from agents import Agent,ModelSettings,RunConfig,Runner
import pytest

from agentic_os_agent_worker.checkpoint import export_checkpoint,restore_checkpoint,tool_alias
from agentic_os_agent_worker.model_rpc import ModelRPCError
from agentic_os_agent_worker.query_context import SCOPED_FORMAT,FACT_FORMAT,completed_scoped_query_window,incomplete_query_window
from agentic_os_agent_worker.sdk_model import SDKModelSequence,SDKModelPolicyError
from agentic_os_agent_worker.sdk_tools import governed_read_tool
from test_sdk_model import binding_fixture
from test_sdk_tools import Boundary,ModelCalls,item_fixture
from test_tool_execution_rpc import accepted_for


def query_item(index):
    item=deepcopy(item_fixture());item['capability']['ref']='scoped.query.'+str(index)
    schema=json.loads(item['inputSchemaJson']);schema['properties']['cursor']={'type':['string','null']}
    schema['required'].append('cursor');item['inputSchemaJson']=json.dumps(schema)
    query=dict(key='query-'+str(index),capability=item['capability'],providerRef='synthetic.provider/'+str(index),
        argumentsJson='{"value":0.5,"cursor":null}',cursorField='cursor',grain=['recordId'],pageGroupFields=[])
    return item,query


def test_actual_sdk_linked_query_windows_restore_without_a_cumulative_key_list():
    from agentic_os_agent_worker.logical_query_journey import current_window,completed_window,saved_queries
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    _,_,binding=binding_fixture();binding['context']['harness'].update(ref='focused-child-reads/1',revision=3)
    pairs=[query_item(i) for i in range(2)];items,queries=zip(*pairs);goal='a'*64
    index=dict(schema='agent-query-intent-index/2',context=binding['context'],goalDigest=goal,queryCount=80,criterionCount=96)
    class LogicalBoundary(QueryBoundary):
        async def logical_query_progress(self,context,goal_digest,set_id,references):
            assert goal_digest==goal and len(references)<=3
            remaining=[q for q in queries if self.pages[tool_alias(q['capability'])]<6]
            frontiers=[dict(queryKey=q['key'],queryDigest='d'*64,pageOrdinal=self.pages[tool_alias(q['capability'])]-1,
                nextCursor='opaque/'+str(self.pages[tool_alias(q['capability'])])) for q in remaining if self.pages[tool_alias(q['capability'])]]
            reference=await self.accepted_model_operation(context,set_id)
            reference['payload']['schemaRef']='AgentQueryFactSet'
            return dict(kind='ready',index=deepcopy(index),queries=deepcopy(remaining),frontiers=frontiers,
                result=reference,allComplete=not remaining,invalidCount=0)
    boundary=LogicalBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    value=dict(start=dict(context=binding['context']),goalDigest=goal,goalDraftJson=json.dumps(index),continuationInputJson=None)
    async def run():
        nonlocal sequence
        for ordinal in range(12):
            window,hydrated=await current_window(value,boundary,sequence)
            assert hydrated and len(hydrated)<=2
            value['continuationInputJson']=json.dumps(window)
            assert saved_queries(value)==hydrated
            changed=deepcopy(value);cache=json.loads(changed['sourceQueryWindowJson']);cache['goalDigest']='b'*64
            changed['sourceQueryWindowJson']=json.dumps(cache)
            with pytest.raises(SDKModelPolicyError):saved_queries(changed)
            selected=ordinal%2;page=ordinal//2;cursor=None if page==0 else 'opaque/'+str(page)
            model=QueryModel(tool_alias(items[selected]['capability']),cursor)
            def agent():return Agent(name='Linked query window',instructions='x'*24576,model=model,
                tools=[replace(governed_read_tool(item,boundary,sequence,result_context='agent-accepted-query-ref/1'),needs_approval=True)
                    for item in items],tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
            paused=await Runner.run(agent(),window,hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
            envelope=export_checkpoint(paused,sequence,[item['capability'] for item in items])
            assert saved_queries(value)==hydrated  # No progress RPC while restoring this pending SDK round.
            payload=AgentPayloadConverter().to_payloads([dict(checkpointId='00000000-0000-4000-8000-000000000001',value=envelope)])[0]
            assert len(payload.SerializeToString(deterministic=True))<=65536
            sequence=SDKModelSequence(envelope['binding'],dependency_boundary=boundary)
            restored=await restore_checkpoint(agent(),envelope,expected_context=binding['context'],
                sdk_instance_id=binding['sdkInstanceId'],capabilities=[item['capability'] for item in items],
                sequence=sequence,dependency_boundary=boundary)
            for interruption in restored.state.get_interruptions():restored.state.approve(interruption)
            result=await Runner.run(agent(),restored.state,hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
            window=await completed_window(value,boundary,sequence,result)
            content=json.loads(window[0]['content'])
            assert len(content['frontiers'])<=2 and len(content['results'])==1 and len(json.dumps(window).encode())<8192
            value['continuationInputJson']=json.dumps(window)
        window,hydrated=await current_window(value,boundary,sequence)
        assert not hydrated and not json.loads(window[0]['content'])['frontiers']
        assert len(boundary.requests)==12 and sum(len(item.inputs) for item in [model])==1
    asyncio.run(run())


def test_linked_objective_receipts_fit_actual_model_and_temporal_serialization(retained_logical=False):
    from pathlib import Path
    from types import SimpleNamespace
    from agents.models.interface import ModelTracing
    from agentic_os_agent_worker.logical_query_journey import instructions,accept_part
    from agentic_os_agent_worker.sdk_model import GovernedResponsesModel,BINDING_KEY
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    from agentic_os_agent_worker.transport import _validate
    config,_,binding=binding_fixture();binding['context']['harness'].update(ref='focused-child-reads/1',revision=3)
    if retained_logical:
        from agentic_os.production.logical_goal_retention import profile_pin
        binding['context']['harness']=profile_pin()
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_text())
    sample=lambda name:deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']==name))
    receipt=sample('AgentQueryIntentPartState');receipt.update(context=binding['context'],ordinal=0,
        sealed=False,goalDigest=None,queryCount=1,criterionCount=16)
    value=sample('AgentSDKQuerySourceChildJoinJourneyStart');value['start'].update(context=binding['context'],checkpointId=None,input='Compute every one of the 32 requested views.')
    value.update(binding=binding,phase='objective',goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        childAfter=None,childContinuation=None,childContinuations=[],sourceBindingId=None,sourceQueryWindowJson=None)
    metadata=instructions([item_fixture()],value['providers'])
    class NoIO:
        async def stage_model_input(self,*_):raise AssertionError('Serialization probe attempted storage')
        async def prepare_model_operation(self,*_):raise AssertionError('Serialization probe attempted admission')
        async def accept_model(self,*_):raise AssertionError('Serialization probe attempted acceptance')
    model=GovernedResponsesModel(SimpleNamespace(config=replace(config,max_request_bytes=49152),boundary=NoIO()),max_output_tokens=4096)
    settings=ModelSettings(metadata={BINDING_KEY:json.dumps(binding)},store=False)
    for part in range(2):
        receipt.update(ordinal=part,sealed=part==1,goalDigest='a'*64 if part else None,
            queryCount=2 if part else 1,criterionCount=32 if part else 16)
        initial=value['start']['input'] if not part else json.loads(value['continuationInputJson'])
        _,_,raw=model._request(metadata,initial,settings,[],None,[],ModelTracing.DISABLED,None,None,None)
        assert len(raw.encode())<=49152
        draft,continuation=accept_part(value,receipt)
        value.update(goalDraftJson=json.dumps(draft),continuationInputJson=json.dumps(continuation) if continuation else None)
        if part:value.update(phase='query-source',goalDigest=receipt['goalDigest'])
        _validate('AgentSDKQuerySourceChildJoinJourneyStart',value)
        payload=AgentPayloadConverter().to_payloads([value])[0]
        assert len(payload.SerializeToString(deterministic=True))<=65536
        if retained_logical:
            value=AgentPayloadConverter().from_payloads([payload])[0]
            assert value['start']['context']['harness']==profile_pin()
    assert json.loads(value['goalDraftJson'])['schema']=='agent-query-intent-index/2'
    assert 'queries' not in json.loads(value['goalDraftJson']) and value['continuationInputJson'] is None
    _,query=query_item(0);query['argumentsJson']=' '*20000+query['argumentsJson']
    value['sourceQueryWindowJson']=json.dumps(dict(schema='agent-logical-query-window/1',goalDigest='a'*64,queries=[query]),separators=(',',':'))
    from agentic_os_agent_worker.logical_query_journey import saved_queries
    assert saved_queries(value)==[query]
    _validate('AgentSDKQuerySourceChildJoinJourneyStart',value)
    assert len(AgentPayloadConverter().to_payloads([value])[0].SerializeToString(deterministic=True))<=65536
    with pytest.raises(SDKModelPolicyError):accept_part(value,receipt)


def test_retained_linked_entry_keeps_serialized_parts_and_original_model_wait(monkeypatch):
    from test_read_profile import test_model_timeout_retains_pending_operation_only_for_patched_histories
    test_linked_objective_receipts_fit_actual_model_and_temporal_serialization(retained_logical=True)
    test_model_timeout_retains_pending_operation_only_for_patched_histories(monkeypatch,True,retained_logical=True)


def test_logical_parallel_sdk_round_keeps_both_accepted_query_references():
    from agentic_os_agent_worker.logical_query_journey import current_window,completed_window,saved_queries
    _,_,binding=binding_fixture();binding['context']['harness'].update(ref='focused-child-reads/1',revision=3)
    item,query=query_item(0);queries=[query,dict(query,key='comparison',argumentsJson='{"value":0.75,"cursor":null}')]
    goal='c'*64;index=dict(schema='agent-query-intent-index/2',context=binding['context'],goalDigest=goal,queryCount=2,criterionCount=32)
    class ParallelBoundary(QueryBoundary):
        async def execute_tool(self,request):
            self.requests.append(deepcopy(request));result=accepted_for(request,query=True)
            page=json.loads(result['accepted']['payloadJson']);which=int(json.loads(request['argumentsJson'])['value']==.75)
            page.update(queryDigest=('b' if which else 'a')*64,pageOrdinal=0,requestCursor=None)
            page['page']['nextCursor']='next/'+str(which)
            result['accepted']['payloadJson']=json.dumps(page);return result
        async def logical_query_progress(self,context,goal_digest,set_id,references):
            assert goal_digest==goal
            if self.requests:
                assert len(references)==3
                assert sum(v['payload']['schemaRef']=='AgentQueryPage' for v in references)==2
                assert len({v['resultId'] for v in references})==3
            reference=await self.accepted_model_operation(context,set_id);reference['payload']['schemaRef']='AgentQueryFactSet'
            return dict(kind='ready',index=index,queries=queries,frontiers=[],result=reference,allComplete=False,invalidCount=0)
    class ParallelModel(ModelCalls):
        async def get_response(self,*args,**kwargs):
            response=await super().get_response(*args,**kwargs)
            for call,query in zip(response.output,queries):call.arguments=query['argumentsJson']
            return response
    boundary=ParallelBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    value=dict(start=dict(context=binding['context']),goalDigest=goal,goalDraftJson=json.dumps(index),continuationInputJson=None)
    async def run():
        nonlocal sequence
        window,hydrated=await current_window(value,boundary,sequence);value['continuationInputJson']=json.dumps(window)
        model=ParallelModel(tool_alias(item['capability']),count=2)
        def agent():return Agent(name='Parallel linked queries',model=model,
            tools=[replace(governed_read_tool(item,boundary,sequence,result_context='agent-accepted-query-ref/1'),needs_approval=True)],
            tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={},parallel_tool_calls=True))
        paused=await Runner.run(agent(),window,hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert len(paused.interruptions)==2 and saved_queries(value)==hydrated
        envelope=export_checkpoint(paused,sequence,[item['capability']]);sequence=SDKModelSequence(envelope['binding'],dependency_boundary=boundary)
        saved=await restore_checkpoint(agent(),envelope,expected_context=binding['context'],sdk_instance_id=binding['sdkInstanceId'],
            capabilities=[item['capability']],sequence=sequence,dependency_boundary=boundary)
        for interruption in saved.state.get_interruptions():saved.state.approve(interruption)
        result=await Runner.run(agent(),saved.state,hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        projected=await completed_window(value,boundary,sequence,result)
        assert len(model.inputs)==1 and len(boundary.requests)==2
        assert len(json.loads(projected[0]['content'])['results'])==1
    asyncio.run(run())


class QueryModel(ModelCalls):
    def __init__(self,name,cursor):super().__init__(name,count=1);self.cursor=cursor
    async def get_response(self,*args,**kwargs):
        response=await super().get_response(*args,**kwargs)
        for call in response.output:
            if call.type=='function_call':call.arguments=json.dumps(dict(value=.5,cursor=self.cursor))
        return response


class QueryBoundary(Boundary):
    def __init__(self):super().__init__();self.pages=Counter()
    async def execute_tool(self,request):
        result=accepted_for(request,query=True);name=request['toolName'];ordinal=self.pages[name]
        self.pages[name]+=1;self.requests.append(deepcopy(request));value=json.loads(result['accepted']['payloadJson'])
        value.update(queryDigest='d'*64,pageOrdinal=ordinal,requestCursor=json.loads(request['argumentsJson'])['cursor'])
        value['page']['nextCursor']=None if ordinal==5 else 'opaque/'+str(ordinal+1)
        result['accepted']['payloadJson']=json.dumps(value);result['accepted']['result']['payload']['bytes']=len(result['accepted']['payloadJson'].encode())
        return result


def test_actual_sdk_same_digest_and_arguments_keep_distinct_capability_query_frontiers(*,alias_keys=False,instruction_bytes=0):
    _,_,binding=binding_fixture();boundary=QueryBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    pairs=[query_item(i) for i in range(2)];items,queries=zip(*pairs);pins=[item['capability'] for item in items];goal='a'*64
    previous=json.dumps(incomplete_query_window(sequence,None,goal,format=SCOPED_FORMAT));last={}
    def tools():return [replace(governed_read_tool(item,boundary,sequence,result_context='agent-accepted-query-ref/1'),needs_approval=True) for item in items]
    async def run():
        nonlocal sequence,previous
        for ordinal in range(12):
            selected=ordinal%2;page=ordinal//2;cursor=None if page==0 else 'opaque/'+str(page)
            model=QueryModel(tool_alias(items[selected]['capability']),cursor)
            agent=Agent(name='Scoped query windows',instructions='x'*instruction_bytes,model=model,tools=tools(),tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
            paused=await Runner.run(agent,json.loads(previous),hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
            assert len(paused.interruptions)==1 and len(boundary.requests)==ordinal
            envelope=export_checkpoint(paused,sequence,pins)
            if instruction_bytes:
                from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
                payload=AgentPayloadConverter().to_payloads([dict(checkpointId='00000000-0000-4000-8000-000000000001',value=envelope)])[0]
                assert len(payload.SerializeToString(deterministic=True))<=65536
            sequence=SDKModelSequence(envelope['binding'],dependency_boundary=boundary)
            agent=Agent(name=agent.name,instructions=agent.instructions,model=model,tools=tools(),tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
            saved=await restore_checkpoint(agent,envelope,expected_context=binding['context'],sdk_instance_id=binding['sdkInstanceId'],capabilities=pins,sequence=sequence,dependency_boundary=boundary)
            for interruption in saved.state.get_interruptions():saved.state.approve(interruption)
            result=await Runner.run(agent,saved.state,hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
            assert len(model.inputs)==1 and len(boundary.requests)==ordinal+1
            if ordinal==0:
                with pytest.raises(SDKModelPolicyError):await completed_scoped_query_window(result,sequence,previous,goal,[queries[1]])
            aliases=[dict(queryKey=query['key'],queryKeys=[query['key'],query['key']+'-equivalent']) for query in queries]
            window=await completed_scoped_query_window(result,sequence,previous,goal,queries,
                **(dict(query_aliases=aliases) if alias_keys else {}))
            previous=json.dumps(window,separators=(',',':'));last[queries[selected]['key']]=page
            content=json.loads(window[0]['content']);frontiers={v['queryKeys'][0]:v for v in content['frontiers']}
            assert set(frontiers)==set(last) and len(previous.encode())<8192
            for key,expected in last.items():
                if alias_keys:assert frontiers[key]['queryKeys']==[key,key+'-equivalent']
                assert frontiers[key]['pageOrdinal']==expected
                assert frontiers[key]['nextCursor']==(None if expected==5 else 'opaque/'+str(expected+1))
            assert len({v['toolName'] for v in frontiers.values()})==len(frontiers)
        assert boundary.pages=={tool_alias(item['capability']):6 for item in items}
        assert len({request['modelOperationId'] for request in boundary.requests})==12 and not boundary.sets
    asyncio.run(run())


def test_actual_sdk_metadata_windows_keep_all_equivalent_query_keys_in_the_original_frontier():
    test_actual_sdk_same_digest_and_arguments_keep_distinct_capability_query_frontiers(alias_keys=True)


def test_actual_sdk_large_metadata_instructions_fit_the_existing_private_checkpoint():
    test_actual_sdk_same_digest_and_arguments_keep_distinct_capability_query_frontiers(alias_keys=True,instruction_bytes=24*1024)


def test_dependency_index_ack_loss_keeps_identical_metered_set_identity_and_accepted_inputs():
    _,_,binding=binding_fixture()
    class LostAck(Boundary):
        def __init__(self):super().__init__();self.identities=[]
        async def pack_input_results(self,context,set_id,results):
            self.identities.append(set_id);accepted=await super().pack_input_results(context,set_id,results)
            if len(self.identities)==1:raise ModelRPCError('UNAVAILABLE')
            return accepted
    boundary=LostAck()
    async def run():
        for ordinal in range(32):
            operation=str(uuid5(UUID(binding['sdkInstanceId']),'accepted/'+str(ordinal)))
            binding['inputResults'].append(await boundary.accepted_model_operation(binding['context'],operation))
        sequence=SDKModelSequence(binding,dependency_boundary=boundary);before=sequence.snapshot()
        with pytest.raises(ModelRPCError):await sequence.pack_accepted_results()
        assert sequence.snapshot()==before
        packed=await sequence.pack_accepted_results()
        assert len(packed)==1 and packed[0]['payload']['schemaRef']=='AgentInputResultSet'
        assert boundary.identities[0]==boundary.identities[1] and boundary.sets[0]==boundary.sets[1]
        assert await sequence.pack_accepted_results()==packed and len(boundary.identities)==2
        assert sequence.snapshot()['context']==before['context'] and sequence.snapshot()['turn']==before['turn']
    asyncio.run(run())


def test_actual_sdk_completed_batch_uses_existing_private_index_for_large_causal_head():
    pairs=[query_item(i) for i in range(32)];items,queries=zip(*pairs)
    class BatchModel(ModelCalls):
        async def get_response(self,*args,**kwargs):
            response=await super().get_response(*args,**kwargs)
            for call,item in zip(response.output,items):
                call.name=tool_alias(item['capability']);call.arguments='{"value":0.5,"cursor":null}'
            return response
    _,_,binding=binding_fixture();boundary=QueryBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    tools=[governed_read_tool(item,boundary,sequence,result_context='agent-accepted-query-ref/1') for item in items]
    model=BatchModel(tools[0].name,count=32);goal='a'*64
    previous=json.dumps(incomplete_query_window(sequence,None,goal,format=SCOPED_FORMAT))
    async def run():
        agent=Agent(name='Bounded accepted batch',model=model,tools=tools,tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
        result=await Runner.run(agent,json.loads(previous),hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert len(model.inputs)==1 and len(boundary.requests)==32 and not boundary.sets
        window=await completed_scoped_query_window(result,sequence,previous,goal,queries)
        content=json.loads(window[0]['content'])
        assert len(content['frontiers'])==32 and len(content['results'])==1 and len(boundary.sets)==1
        assert len(boundary.sets[0])==33 and content['results'][0]['payload']['schemaRef']=='AgentInputResultSet'
        assert len(json.dumps(window).encode())<24576 and sequence.snapshot()['context']==binding['context']
    asyncio.run(run())


@pytest.mark.parametrize('format,patched,retained',[(SCOPED_FORMAT,True,True),(SCOPED_FORMAT,False,False),('agent-query-context-window/1',True,False)])
def test_lost_index_activity_ack_keeps_accepted_parent_only_in_patched_scoped_histories(monkeypatch,format,patched,retained,*,parallel=False):
    from pathlib import Path
    from types import SimpleNamespace
    from temporalio.exceptions import ApplicationError
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.workflow_control import WorkflowControl,WAIT_TYPE
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_text())
    value=deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']=='AgentSDKQuerySourceChildJoinJourneyStart'))
    goal=deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']=='AgentQuerySourceIntentDraft'))
    context=value['start']['context'];context['harness']['ref']='focused-child-reads/1';item=item_fixture()
    goal['queries']=[dict(goal['queries'][0],capability=item['capability'])]
    value['start'].update(capabilities=[item],checkpointId=None)
    instance=str(uuid5(UUID(context['taskId']),'sdk-instance/1'));parent=str(uuid5(UUID(instance),'accepted-parent'))
    binding=dict(context=context,sdkInstanceId=instance,turn=3,planRevision=1,parentOperationId=parent,inputResults=[])
    boundary=Boundary()
    for operation in [parent,str(uuid5(UUID(instance),'accepted-tool-head'))]:
        binding['inputResults'].append(asyncio.run(boundary.accepted_model_operation(context,operation)))
    if format==FACT_FORMAT:binding['inputResults']=[]
    sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    value.update(phase='query-source',binding=binding,goalDigest='a'*64,goalDraftJson=json.dumps(goal),
        continuationInputJson=json.dumps(incomplete_query_window(sequence,None,'a'*64,format=format)))
    workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=workflow_id))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:patched if name=='query-context-index-wait-parent/1'
        else parallel if name=='scoped-query-parallel-round/1' else name=='query-completed-context-window/1')
    activity=[];waited=[]
    async def lost_ack(name,payload,**kwargs):
        assert name=='agent.pack-results/1' and payload['context']==context and len(payload['results'])==2
        activity.append(deepcopy(payload))
        raise ApplicationError('agent_wait',WorkflowControl(context['rootId'],context['taskId'],None,'waiting-reconciliation'),type=WAIT_TYPE,non_retryable=True)
    monkeypatch.setattr(read_journey.workflow,'execute_activity',lost_ack)
    class SettingsObserved(Exception):pass
    async def completed_round(agent,initial,*,hooks,**kwargs):
        assert agent.model_settings.parallel_tool_calls==(parallel and format in {SCOPED_FORMAT,FACT_FORMAT})
        assert ('Independent query chains may use parallel tool calls' in agent.instructions)==(parallel and format in {SCOPED_FORMAT,FACT_FORMAT})
        if format==FACT_FORMAT:
            assert hooks.snapshot()['context']==context and hooks.snapshot()['inputResults']==[]
            raise SettingsObserved()
        assert hooks.pending is None and hooks.snapshot()==binding
        await hooks.pack_accepted_results()
        raise AssertionError('An uncertain index cannot start another model')
    monkeypatch.setattr(read_journey.Runner,'run',completed_round)
    class Driver:
        stopped=False;pending_control=None
        def _expired(self):return False
        def _terminal(self,control):return control
        async def _pause(self,control):waited.append(control);self.stopped=True
    if format==FACT_FORMAT:
        with pytest.raises(SettingsObserved):asyncio.run(read_journey.run_read_journey(Driver(),value))
        assert not activity and not waited
        return
    result=asyncio.run(read_journey.run_read_journey(Driver(),value))
    assert result.status=='stopped' and len(activity)==len(waited)==1
    assert waited[0].operationId==(parent if retained else None)
    assert waited[0].rootId==context['rootId'] and activity[0]['results']==sorted(binding['inputResults'],key=lambda reference:reference['resultId'])


@pytest.mark.parametrize('format',[SCOPED_FORMAT,FACT_FORMAT,'agent-query-context-window/1'])
def test_scoped_parallel_query_round_retains_original_index_wait_and_legacy_serial_policy(monkeypatch,format):
    test_lost_index_activity_ack_keeps_accepted_parent_only_in_patched_scoped_histories(
        monkeypatch,format,True,format!= 'agent-query-context-window/1',parallel=True)
