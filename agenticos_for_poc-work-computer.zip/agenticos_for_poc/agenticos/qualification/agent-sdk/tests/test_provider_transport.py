"""Actual pinned official SDK protocol/usage/cancellation, without paid requests."""
import asyncio
from dataclasses import replace
from datetime import datetime,timedelta,timezone
import json

import httpx
import httpx2
import pytest

from agentic_os_agent_worker.transport import OfficialTransport,TransportError,_retry_delay,_work_ms
from provider_transport_fixture import Boundary,fixture,privacy_configuration


def timing_probe():
    import importlib.util
    from pathlib import Path
    path=Path(__file__).resolve().parents[3]/'tests/integration/resources/assigned_read_probe.py'
    spec=importlib.util.spec_from_file_location('owned_provider_timing_probe',path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


@pytest.mark.parametrize('fault',['success','cancel-body','oversize'])
def test_official_provider_stage_observer_keeps_real_body_accounting_and_privacy(fault):
    probe=timing_probe();config,request,body,response=fixture('openai');boundary=Boundary(body);calls=[]
    raw=json.dumps(response).encode();reached=asyncio.Event()
    class Stream(httpx.AsyncByteStream):
        async def __aiter__(self):
            yield b''  # Headers and empty chunks are not a first body byte.
            await asyncio.sleep(.01)
            if fault=='cancel-body':reached.set();await asyncio.Event().wait()
            yield raw if fault!='oversize' else b'x'*(config.max_response_bytes+1)
        async def aclose(self):pass
    async def handler(value):
        calls.append(value);return httpx.Response(200,stream=Stream(),headers={'x-request-id':'private-request-canary'})
    original=(OfficialTransport.__init__,OfficialTransport.invoke)
    async def run():
        with probe.provider_stage_observation(OfficialTransport) as evidence:
            transport=OfficialTransport(config,boundary,api_key='PRIVATE-API-KEY-CANARY',network_transport=httpx.MockTransport(handler))
            try:
                if fault=='cancel-body':
                    task=asyncio.create_task(transport.invoke(request));await asyncio.wait_for(reached.wait(),2);task.cancel()
                    with pytest.raises(asyncio.CancelledError):await task
                else:await transport.invoke(request)
            finally:await transport.close()
        return evidence
    evidence=asyncio.run(run());assert (OfficialTransport.__init__,OfficialTransport.invoke)==original
    assert len(calls)==len(evidence['samples'])==1 and not evidence['truncated'] and not evidence['privateContentRecorded']
    row=evidence['samples'][0];assert row['taskId']==request['context']['taskId'] and row['httpRequests']==1
    assert int(row['invocationStartedNs'])<=int(row['requestStartedNs'])<=int(row['headersReceivedNs'])<int(row['invocationFinishedNs'])
    if fault in {'cancel-body','oversize'}:
        assert 'firstBodyByteNs' not in row and 'bodyCompletedNs' not in row and boundary.outstanding==2000
        assert row['outcome']==('raised' if fault=='cancel-body' else 'unknown') and boundary.events==['begun','unknown']
    else:
        assert int(row['headersReceivedNs'])<int(row['firstBodyByteNs'])<=int(row['bodyCompletedNs'])<=int(row['invocationFinishedNs'])
        assert row['outcome']=='succeeded' and boundary.outstanding==0
        assert row['bodyBytes']==len(raw) and boundary.records[0]['usage']['outputTokens']==10
    text=json.dumps(evidence)
    assert all(secret not in text for secret in ['PRIVATE-API-KEY-CANARY','private-request-canary','Synthetic private request','Synthetic result'])


def test_provider_stage_observer_keeps_bounded_samples_and_original_transport():
    probe=timing_probe();config,request,body,response=fixture('openai');boundary=Boundary(body);calls=[]
    async def handler(value):calls.append(value);return httpx.Response(200,json=response)
    async def run():
        with probe.provider_stage_observation(OfficialTransport) as evidence:
            evidence['samples'][:]=[{} for _ in range(128)]
            transport=OfficialTransport(config,boundary,api_key='synthetic-key',network_transport=httpx.MockTransport(handler))
            try:result=await transport.invoke(request)
            finally:await transport.close()
        assert evidence['truncated'] and evidence['samples']==[{} for _ in range(128)]
        assert result['operation']['state']=='succeeded' and boundary.outstanding==0
    asyncio.run(run());assert len(calls)==1


def test_observed_live_entry_delegates_unchanged_configuration_and_start(tmp_path,monkeypatch):
    from agentic_os_agent_worker import task_service
    probe=timing_probe();calls=[];value=dict(profile='assigned-read-local/1',apiKey='PRIVATE-KEY-CANARY');start={'original':'unchanged'}
    async def assigned(configuration,original):
        assert configuration is value and original is start;calls.append(True)
        raise RuntimeError('PRIVATE-ERROR-CANARY')
    monkeypatch.setattr(task_service,'assigned_main',assigned)
    with pytest.raises(RuntimeError):asyncio.run(probe.observed_live_entry(value,start,tmp_path/'private.json'))
    reports=list(tmp_path.glob('provider-stage-timing-*.json'));assert len(reports)==1 and calls==[True]
    assert reports[0].stat().st_mode&0o077==0 and 'PRIVATE-' not in reports[0].read_text()
    assert json.loads(reports[0].read_bytes())['samples']==[]
    with pytest.raises(ValueError):asyncio.run(probe.observed_live_entry(value,start,tmp_path/'private.json'))
    assert calls==[True]  # Refuse reused diagnostics before any execution.
    public=tmp_path/'not-private';public.mkdir(mode=0o755);public.chmod(0o755)
    with pytest.raises(ValueError):asyncio.run(probe.observed_live_entry(value,start,public/'private.json'))
    assert calls==[True] and not list(public.iterdir())


def test_observed_assigned_router_records_official_http_and_serialized_private_handoff(tmp_path):
    import os,subprocess,sys
    from pathlib import Path
    tests=Path(__file__).resolve().parent
    program='''
import sys
from pathlib import Path
from pytest import MonkeyPatch
tests=Path(sys.argv[1]);sys.path[:0]=[str(tests.parent),str(tests)]
from test_provider_transport import _assigned_router_roundtrip
with MonkeyPatch.context() as patch:_assigned_router_roundtrip(Path(sys.argv[2]),patch)
'''
    subprocess.run([sys.executable,'-I','-B','-c',program,str(tests),str(tmp_path)],cwd=tmp_path,
        env={k:v for k,v in os.environ.items()if k in {'PATH','HOME','TMPDIR','PYTHONDONTWRITEBYTECODE'}},check=True,timeout=30)


def _assigned_router_roundtrip(tmp_path,monkeypatch):
    from dataclasses import asdict
    from uuid import uuid4
    from test_parallel_children import sample
    from agentic_os_agent_worker import task_service,model_rpc
    from agentic_os_agent_worker.workflow_control import WorkflowControl
    probe=timing_probe();config,request,body,response=fixture('openai');config=privacy_configuration(config)
    request['context']['model']['digest']=config.model_profile_digest
    boundary=Boundary(body);remote=[];provider=[];real_rpc=model_rpc.RPCModelBoundary
    async def kernel(incoming):
        value=json.loads(incoming.content);remote.append(incoming.url.path)
        assert value['request']==request and incoming.headers['authorization']=='Bearer PRIVATE-WORKLOAD-CANARY'
        if incoming.url.path.endswith('/begin'):
            assert value['transport']['modelDigest']==config.model_profile_digest
            return httpx.Response(200,json=dict(inputJson=await boundary.begin_model(request)))
        assert incoming.url.path.endswith('/finish')
        names=dict(candidateJson='candidate_json',providerEvidenceJson='provider_evidence_json',
            requestId='request_id',responseId='response_id',workMs='work_ms',retryAfterMs='retry_after_ms')
        result=await boundary.finish_model(request,**{names.get(k,k):v for k,v in value.items() if k!='request'})
        return httpx.Response(200,json=result)
    class Stream(httpx.AsyncByteStream):
        async def __aiter__(self):yield json.dumps(response).encode()
        async def aclose(self):pass
    async def model(incoming):provider.append(incoming);return httpx.Response(200,stream=Stream())
    monkeypatch.setattr(httpx,'AsyncHTTPTransport',lambda **kwargs:httpx.MockTransport(model))
    monkeypatch.setattr(model_rpc,'RPCModelBoundary',lambda *args,**kwargs:real_rpc(*args,**kwargs,network_transport=httpx.MockTransport(kernel)))
    start=sample('AgentSDKReadJourneyStart');start['start'].update(context=request['context'],modelId=config.model_id,checkpointId=None)
    start.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None)
    decoded=probe.parse_start(json.dumps(start).encode())
    async def serve(**options):
        assert options['start']==decoded and options['local_synthetic'] and options['cloud_connection'] is None
        result=await options['transport'].invoke(request);assert result['operation']['state']=='succeeded'
        return WorkflowControl(request['context']['rootId'],request['context']['taskId'],None,'candidate-ready')
    monkeypatch.setattr(task_service,'serve_read_task',serve)
    document=dict(profile='assigned-read-local/1',target='127.0.0.1:7233',namespace='owned-stage',
        kernelOrigin='http://127.0.0.1:18080',workloadToken='PRIVATE-WORKLOAD-CANARY',transport=asdict(config),
        apiKey='PRIVATE-API-CANARY',historyKeyId=str(uuid4()),historyKeyHex='ab'*32)
    path=tmp_path/'assigned.json';path.write_text(json.dumps(document));path.chmod(0o600)
    asyncio.run(probe.run(task_service._private_configuration(path),decoded,path))
    reports=list(tmp_path.glob('provider-stage-timing-*.json'));assert len(reports)==1
    evidence=json.loads(reports[0].read_bytes());assert len(evidence['samples'])==1 and len(provider)==1
    row=evidence['samples'][0];assert row['taskId']==request['context']['taskId'] and row['outcome']=='succeeded'
    assert int(row['requestStartedNs'])<=int(row['headersReceivedNs'])<=int(row['firstBodyByteNs'])<=int(row['bodyCompletedNs'])<=int(row['invocationFinishedNs'])
    assert remote==['/private/agent/model/begin','/private/agent/model/finish']
    assert boundary.events==['begun','settled'] and boundary.outstanding==0 and 'PRIVATE-' not in reports[0].read_text()


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_official_sdk_is_explicit_no_retry_and_records_disjoint_usage(provider):
    config,request,body,response=fixture(provider);boundary=Boundary(body);calls=[]
    library=httpx if provider=='openai' else httpx2
    async def handler(r):
        assert boundary.events==['begun'];calls.append(r)
        sent=json.loads(r.content)
        assert sent['model']==config.model_id and sent['stream'] is False
        if provider=='openai':assert sent['store'] is False and sent['background'] is False and sent['max_output_tokens']==64
        else:assert sent['max_tokens']==64 and sent['service_tier']=='standard_only'
        return library.Response(200,json=response,headers={'x-request-id':'req_synthetic'})
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=library.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run());record=boundary.records[0]
    assert result['operation']['state']=='succeeded' and boundary.events==['begun','settled'] and len(calls)==1
    assert record['usage']['uncachedInputTokens']==80 and record['usage']['cachedInputTokens']==20
    assert record['usage']['outputTokens']==10 and record['provider_evidence_json'] and record['candidate_json']
    assert result['operation']['usage']['measured']['tokens']==(110 if provider=='openai' else 122)
    assert boundary.outstanding==0 and result['providerRequestId']=='req_synthetic'


@pytest.mark.parametrize('provider',['openai','anthropic'])
@pytest.mark.parametrize('status',[429,503])
def test_official_errors_do_not_retry_or_refund_unknown_usage(provider,status,caplog):
    config,request,body,_=fixture(provider);boundary=Boundary(body);calls=[];library=httpx if provider=='openai' else httpx2
    async def handler(r):
        calls.append(r);return library.Response(status,json=dict(error=dict(type='synthetic_error',message='PRIVATE_PROVIDER_MARKER')),
            headers={'retry-after':'3600','x-request-id':'req_rejected'})
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=library.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run())
    assert len(calls)==1 and boundary.outstanding==2000 and boundary.events==['begun','unknown']
    assert result['operation']['state']=='unknown' and boundary.records[0]['retry_after_ms']==3600000
    assert result['operation']['failure']==('rate-limited' if status==429 else 'provider-unavailable')
    assert 'PRIVATE_PROVIDER_MARKER' not in caplog.text and boundary.records[0]['provider_evidence_json']


def test_known_failed_response_preserves_usage_and_retry_time_without_client_retry():
    config,request,body,response=fixture('openai');boundary=Boundary(body);calls=[]
    response.update(status='failed',error=dict(code='server_error',message='PRIVATE_TRANSIENT_CANARY'),output=[])
    async def handler(r):
        calls.append(r);return httpx.Response(200,json=response,headers={'retry-after':'60','x-request-id':'known_failed'})
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider-key',network_transport=httpx.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run());record=boundary.records[0]
    assert len(calls)==1 and boundary.events==['begun','settled'] and boundary.outstanding==0
    assert result['operation']['state']=='failed' and result['operation']['usage']['measured']['tokens']==110
    assert record['candidate_json'] is None and record['provider_evidence_json'] and record['retry_after_ms']==60000


@pytest.mark.parametrize('status,code,unavailable',[(404,'model_not_found',True),
    (404,'previous_response_not_found',False),(503,'model_not_found',False),(404,None,False)])
def test_explicit_unavailable_model_is_configuration_blocked_without_refunding_or_retry(status,code,unavailable,caplog):
    config,request,body,_=fixture('openai');boundary=Boundary(body);calls=[]
    async def handler(r):
        calls.append(r);return httpx.Response(status,json=dict(error=dict(code=code,type='invalid_request_error',
            message='PRIVATE-MODEL-ERROR-CANARY')),headers={'retry-after':'60','x-request-id':'unavailable_model'})
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-no-live-key',network_transport=httpx.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run());record=boundary.records[0]
    assert len(calls)==1 and boundary.events==['begun','unknown'] and boundary.outstanding==2000
    assert result['operation']['state']=='unknown' and record['usage'] is None and record['candidate_json'] is None
    assert record['failure']==('invalid-input' if unavailable else 'provider-unavailable')
    assert record['reason']==('provider-model-unavailable' if unavailable else 'provider-http-error')
    assert record['retry_after_ms']==60000 and record['provider_evidence_json']
    assert 'PRIVATE-MODEL-ERROR-CANARY' not in caplog.text and 'PRIVATE-' not in json.dumps(result)


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_active_sdk_cancellation_preserves_original_unknown_reservation(provider):
    config,request,body,_=fixture(provider);boundary=Boundary(body);library=httpx if provider=='openai' else httpx2
    async def run():
        reached=asyncio.Event()
        async def handler(r):reached.set();await asyncio.Event().wait()
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=library.MockTransport(handler))
        try:
            operation=asyncio.create_task(transport.invoke(request));await asyncio.wait_for(reached.wait(),2)
            operation.cancel()
            with pytest.raises(asyncio.CancelledError):await operation
        finally:await transport.close()
    asyncio.run(run())
    assert boundary.events==['begun','unknown'] and boundary.outstanding==2000
    assert boundary.records[0]['reason']=='cancelled-unknown-completion'


@pytest.mark.parametrize('change',['boolean-usage','wrong-model','oversize','incomplete'])
def test_malformed_or_incomplete_output_cannot_become_a_successful_candidate(change):
    config,request,body,response=fixture('openai');boundary=Boundary(body)
    if change=='boolean-usage':response['usage']['input_tokens']=True
    elif change=='wrong-model':response['model']='unexpected-model'
    elif change=='oversize':response['private']='x'*70000
    else:response['status']='incomplete'
    async def handler(r):return httpx.Response(200,json=response)
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=httpx.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run())
    assert result['operation']['state']!='succeeded' and boundary.records[0]['candidate_json'] is None
    assert boundary.outstanding==(0 if change=='incomplete' else 2000)


def test_invalid_or_hosted_tool_input_is_refused_without_any_provider_io():
    config,request,body,_=fixture('openai');body['tools']=[dict(type='web_search')];boundary=Boundary(body);calls=[]
    async def handler(r):calls.append(r);raise AssertionError('Provider must not be called')
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=httpx.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run())
    assert calls==[] and result['operation']['state']=='failed' and boundary.outstanding==0
    assert boundary.records[0]['usage']['outputTokens']==0


@pytest.mark.parametrize('include',[[],['file_search_call.results'],['reasoning.encrypted_content','file_search_call.results']])
def test_unqualified_provider_includes_cannot_expand_the_private_response_profile(include):
    config,request,body,_=fixture('openai');body['include']=include;boundary=Boundary(body);calls=[]
    async def handler(r):calls.append(r);raise AssertionError('Provider must not be called')
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=httpx.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run())
    assert result['operation']['state']=='failed' and calls==[] and boundary.outstanding==0
    assert boundary.records[0]['usage']['outputTokens']==0


def test_denied_kernel_begin_prevents_sdk_io_and_model_mismatch_prevents_input_disclosure():
    config,request,body,_=fixture('openai');boundary=Boundary(body);boundary.denied=True;calls=[]
    async def handler(r):calls.append(r);raise AssertionError('Provider must not be called')
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=httpx.MockTransport(handler))
        try:
            with pytest.raises(PermissionError):await transport.invoke(request)
            request['context']['model']['digest']='f'*64
            with pytest.raises(TransportError):await transport.invoke(request)
        finally:await transport.close()
    asyncio.run(run());assert calls==[] and boundary.events==[]


def test_profile_account_endpoint_and_retry_delay_are_not_silently_changed(monkeypatch):
    config,_,body,_=fixture('openai')
    for fields in (dict(model_id='wrong-model'),dict(base_url='https://example.invalid'),dict(credential_ref='wrong')):
        with pytest.raises(TransportError):replace(config,**fields)
    config=privacy_configuration(config)
    monkeypatch.setenv('OPENAI_PROJECT_ID','ambient-project')
    with pytest.raises(TransportError):OfficialTransport(config,Boundary(body),api_key='synthetic-not-a-real-secret')
    assert _retry_delay({'retry-after':'3600'})==3600000


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_individual_sdk_timeout_is_finite_without_refunding_uncertain_work(provider):
    # Cold official-SDK request construction exceeded the former20ms before
    # reaching the mock. Exercise a real in-flight deadline, not import timing.
    config,request,body,_=fixture(provider);request['requestTimeoutMs']=1000;boundary=Boundary(body)
    library=httpx if provider=='openai' else httpx2;calls=[]
    async def handler(r):calls.append(r);await asyncio.Event().wait()
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=library.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run())
    assert len(calls)==1 and boundary.outstanding==2000 and result['operation']['state']=='unknown'
    assert boundary.records[0]['reason']=='provider-request-timeout'
    assert boundary.records[0]['usage'] is None and boundary.records[0]['work_ms']>=1000


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_official_sdk_read_timeout_keeps_unknown_and_only_a_safe_reason(provider,caplog):
    config,request,body,_=fixture(provider);boundary=Boundary(body)
    library=httpx if provider=='openai' else httpx2;calls=[]
    async def handler(r):
        calls.append(r)
        raise library.ReadTimeout('synthetic-private-provider-detail',request=r)
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=library.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run());record=boundary.records[0]
    assert len(calls)==1 and boundary.outstanding==2000 and result['operation']['state']=='unknown'
    assert record['reason']=='provider-request-timeout' and record['usage'] is None and record['candidate_json'] is None
    assert 'synthetic-private-provider-detail' not in json.dumps(record) and 'synthetic-private-provider-detail' not in caplog.text


def test_elapsed_work_rounds_up_at_integer_millisecond_boundaries(monkeypatch):
    monkeypatch.setattr('agentic_os_agent_worker.transport.time.monotonic_ns',lambda:1000001)
    assert _work_ms(0)==2 and _work_ms(1)==1


def test_expired_lease_after_kernel_begin_never_sends_a_paid_request():
    config,request,body,_=fixture('openai');boundary=Boundary(body);calls=[]
    request['grant']['expiresAt']=(datetime.now(timezone.utc)-timedelta(seconds=1)).isoformat()
    async def handler(r):calls.append(r);raise AssertionError('Expired work must not be sent')
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',network_transport=httpx.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run())
    assert calls==[] and boundary.events==['begun','settled'] and boundary.outstanding==0
    assert result['operation']['failure']=='cancelled' and boundary.records[0]['reason']=='lease-expired-before-provider'


def test_output_tokens_cannot_exceed_the_original_kernel_reservation():
    config,request,body,_=fixture('openai');boundary=Boundary(body)
    request['maxOutputTokens']=request['grant']['reserved']['tokens']+1
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-not-a-real-secret',
            network_transport=httpx.MockTransport(lambda _:pytest.fail('Unreserved output reached provider I/O')))
        try:
            with pytest.raises(TransportError):await transport.invoke(request)
        finally:await transport.close()
    asyncio.run(run());assert boundary.events==[]


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_invalid_provider_unicode_keeps_known_usage_and_private_proof_without_candidate(provider):
    config,request,body,response=fixture(provider);boundary=Boundary(body)
    response['invalid_private_text']=chr(0xD800)
    library=httpx if provider=='openai' else httpx2
    async def handler(_):
        return library.Response(200,content=json.dumps(response,ensure_ascii=True).encode(),headers={'content-type':'application/json'})
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider-key',network_transport=library.MockTransport(handler))
        try:return await transport.invoke(request)
        finally:await transport.close()
    result=asyncio.run(run());record=boundary.records[0]
    assert record['usage'] is not None and record['candidate_json'] is None and record['provider_evidence_json']
    assert record['reason']=='provider-invalid-output' and result['operation']['state']=='failed'
    assert boundary.outstanding==0
