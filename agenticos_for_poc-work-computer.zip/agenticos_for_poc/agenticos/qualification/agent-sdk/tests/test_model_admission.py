"""Prove supported per-model-call authority callbacks without claiming SQL safety."""
import asyncio
import pytest
from agents import Agent, Runner
from model_admission_fixture import AdmissionProbeModel, ProbeModelUnavailable
from test_openai_control_flow import ScriptedModel, answer, CONFIG


class ResourceDenied(RuntimeError):
    pass


class AuthorityProbe:
    def __init__(self, tokens):
        self.tokens = tokens
        self.events = []
        self.outstanding = 0
        self.spent = 0

    async def reserve(self):
        if self.spent + self.outstanding + 10 > self.tokens:
            raise ResourceDenied()
        self.outstanding += 10
        self.events.append("reserved")
        return "original-root-reservation"

    async def begin(self, lease):
        assert lease == "original-root-reservation"
        self.events.append("begun")

    async def settle(self, lease, amount):
        assert lease == "original-root-reservation" and amount == 10
        self.outstanding -= 10
        self.spent += amount
        self.events.append("settled")

    async def unknown(self, lease):
        assert lease == "original-root-reservation"
        self.events.append("unknown")


def test_resource_denial_prevents_the_actual_sdk_provider_invocation():
    authority = AuthorityProbe(0)
    inner = ScriptedModel(lambda _: answer("Must not be called"))
    agent = Agent(name="Metered candidate", model=AdmissionProbeModel(inner, authority))
    with pytest.raises(ResourceDenied):
        asyncio.run(Runner.run(agent, "Read", max_turns=None, run_config=CONFIG))
    assert inner.inputs == [] and authority.events == []


def test_actual_sdk_provider_runs_only_after_begin_and_settles_before_output():
    authority = AuthorityProbe(10)

    def respond(_):
        assert authority.events == ["reserved", "begun"]
        return answer("A synthetic answer")

    inner = ScriptedModel(respond)
    agent = Agent(name="Metered candidate", model=AdmissionProbeModel(inner, authority))
    result = asyncio.run(Runner.run(agent, "Read", max_turns=None, run_config=CONFIG))
    assert result.final_output == "A synthetic answer"
    assert authority.events == ["reserved", "begun", "settled"]
    assert authority.spent == 10 and authority.outstanding == 0


def test_unknown_provider_completion_keeps_the_reservation_and_safe_error(caplog):
    authority = AuthorityProbe(10)

    def fail(_):
        raise RuntimeError("synthetic-provider-private-marker")

    inner = ScriptedModel(fail)
    agent = Agent(name="Metered candidate", model=AdmissionProbeModel(inner, authority))
    with pytest.raises(ProbeModelUnavailable) as failure:
        asyncio.run(Runner.run(agent, "Read", max_turns=None, run_config=CONFIG))
    assert authority.events == ["reserved", "begun", "unknown"]
    assert authority.outstanding == 10 and authority.spent == 0
    assert failure.value.__context__ is None and failure.value.__cause__ is None
    assert "synthetic-provider-private-marker" not in caplog.text
