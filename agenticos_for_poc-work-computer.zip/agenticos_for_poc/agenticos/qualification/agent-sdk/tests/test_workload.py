"""Actual rotating-volume reader through the installed worker RPC callback."""
import asyncio
from copy import deepcopy
import json
import os

import httpx
import pytest

from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from agentic_os_agent_worker.workload import ProjectedWorkloadToken
from provider_transport_fixture import fixture,ident


def rotate(root,number,token):
    generation=root/('generation-'+str(number));generation.mkdir(mode=0o700)
    path=generation/'token';path.write_text(token);path.chmod(0o440)
    link=root/'next-data';link.symlink_to(generation.name,target_is_directory=True);link.replace(root/'..data')
    if not (root/'token').is_symlink():(root/'token').symlink_to('..data/token')
    return path


def test_rotating_projected_token_reaches_each_rpc_without_caching_or_changing_original_context(tmp_path):
    root=tmp_path/'projection';root.mkdir(mode=0o700)
    first='e30.e30.'+'a'*43;second='e30.e30.'+'b'*43
    rotate(root,1,first);provider=ProjectedWorkloadToken(root)
    assert provider.read()==first
    config,request,body,_=fixture('openai');original=deepcopy(request['context']);calls=[]
    async def remote(incoming):
        calls.append(incoming)
        assert incoming.headers['authorization']=='Bearer '+(first if len(calls)==1 else second)
        assert first not in incoming.content.decode() and second not in incoming.content.decode()
        return httpx.Response(200,json=dict(inputJson=json.dumps(body)))
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',provider,network_transport=httpx.MockTransport(remote))
        boundary.bind_transport(config)
        try:
            assert await boundary.begin_model(request)==json.dumps(body)
            rotate(root,2,second)
            assert provider.read()==second
            another=deepcopy(request);another['step']['stepId']=ident(40);another['grant']['attemptId']=ident(41)
            assert await boundary.begin_model(another)==json.dumps(body)
            (root/'token').unlink()
            with pytest.raises(ModelRPCError,match='unavailable'):await boundary.begin_model(another)
            assert len(calls)==2 and request['context']==another['context']==original
        finally:await boundary.close()
    asyncio.run(run())


def test_projected_reader_rejects_escape_alias_mutable_oversized_and_special_files(tmp_path):
    root=tmp_path/'projection';root.mkdir(mode=0o700);token='e30.e30.'+'a'*43
    path=rotate(root,1,token);provider=ProjectedWorkloadToken(root)
    async def denied():
        with pytest.raises(ModelRPCError,match='unavailable') as failed:await provider()
        assert token not in str(failed.value) and str(root) not in str(failed.value)
    asyncio.run(provider())
    path.chmod(0o640);asyncio.run(denied());path.chmod(0o440)
    link=tmp_path/'alias';link.symlink_to(root,target_is_directory=True)
    with pytest.raises(ModelRPCError,match='invalid'):ProjectedWorkloadToken(link)
    outside=tmp_path/'outside';outside.write_text(token);outside.chmod(0o440)
    (root/'token').unlink();(root/'token').symlink_to(outside);asyncio.run(denied())
    (root/'token').unlink();(root/'token').symlink_to('..data/token')
    path.chmod(0o640);path.write_text('x'*8193);path.chmod(0o440);asyncio.run(denied())
    path.unlink();os.mkfifo(path,0o440);asyncio.run(denied())
