"""Complete SDK mechanism probes; production SQL/Host qualification stays separate."""
import asyncio
from contextlib import asynccontextmanager
from datetime import timedelta
import json
import os
from uuid import uuid4
import pytest

from agents import RunContextWrapper
from agents.models.interface import ModelProvider
from temporalio import activity
from temporalio.client import WorkflowFailureError
from temporalio.common import RetryPolicy
from temporalio.contrib.openai_agents import OpenAIAgentsPlugin, ModelActivityParameters
from temporalio.converter import DataConverter
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Replayer

from agentic_os.adapters.local.artifacts import LocalKeys, LocalArtifacts
from agentic_os.adapters.local.files import OwnershipError
from agentic_os.adapters.temporal.privacy import HistoryCodec, SafeFailureConverter, SafeActivityInterceptor
from agentic_os_agent_worker.policy import WorkerPolicy
from model_admission_fixture import AdmissionProbeModel
from workflow_matrix_fixture import SDKCompatibilityMatrix, SDKCompatibilityParent, SDKCompatibilityChild, matrix_dispatch
from test_openai_control_flow import ScriptedModel, calls, answer, outputs
from test_temporal_control_flow import bounded_worker


@asynccontextmanager
async def service(proof_root, provider):
    key_dir = proof_root / ("matrix-keys-" + uuid4().hex)
    key_dir.mkdir(mode=0o700)
    keys = LocalKeys(key_dir)
    keys.rotate()
    installation = str(uuid4())
    converter = DataConverter(payload_codec=HistoryCodec(keys, "default", installation),
                              failure_converter_class=SafeFailureConverter)
    plugin = WorkerPolicy(10_000).plugin(provider)
    async with await WorkflowEnvironment.start_local(ip="127.0.0.1", ui=False,
        dev_server_existing_path=os.environ["AGENTIC_OS_SDK_TEMPORAL_BINARY"],
        dev_server_database_filename=str(proof_root / (uuid4().hex + ".sqlite")),
        data_converter=converter, plugins=[plugin]) as env:
        yield env, f"os:{installation}:{uuid4()}:{uuid4()}", converter, plugin


def test_parallel_durable_tools_join_and_context_mutations_do_not_grant_authority(proof_root):
    async def scenario():
        started, both = set(), asyncio.Event()
        received = []

        @activity.defn(name="matrix_dispatch")
        async def observed(envelope: dict) -> str:
            key = envelope["key"]
            received.append((envelope["root"], envelope["toolCallId"]))
            started.add(key)
            if len(started) == 2:
                both.set()
            await asyncio.wait_for(both.wait(), 2)
            return await matrix_dispatch(envelope)

        def respond(items):
            values = outputs(items)
            if not values:
                return calls(("matrix_branch", "parallel-a", {"key": "a"}),
                             ("matrix_branch", "parallel-b", {"key": "b"}))
            assert {x["key"] for x in values} == {"a", "b"}
            return answer(str(sum(x["amount"] for x in values)))

        class Provider(ModelProvider):
            def get_model(self, name):
                assert name == "matrix-parallel"
                return ScriptedModel(respond)

        async with service(proof_root, Provider()) as (env, ident, _, _):
            queue = "matrix-" + uuid4().hex
            async with bounded_worker(env.client, task_queue=queue, workflows=[SDKCompatibilityMatrix],
                activities=[observed], interceptors=[SafeActivityInterceptor()]):
                result = await asyncio.wait_for(env.client.execute_workflow(SDKCompatibilityMatrix.run,
                    "parallel", id=ident, task_queue=queue, execution_timeout=timedelta(seconds=30)), 20)
            assert result == {"answer": "13", "touches": 0}
            assert set(received) == {("fixture-original-root", "parallel-a"),
                                     ("fixture-original-root", "parallel-b")}
    asyncio.run(scenario())


class OriginalRootProbe:
    """In-memory boundary observation, not the PA03 production SQL ledger."""
    def __init__(self, tokens):
        self.capacity, self.spent, self.held = tokens, 0, {}
        self.workflows = set()
        self.calls = 0

    async def reserve(self):
        if self.spent + sum(self.held.values()) + 10 > self.capacity:
            raise RuntimeError("original_resource_root_exhausted")
        lease = str(uuid4())
        self.held[lease] = 10
        return lease

    async def begin(self, lease):
        assert lease in self.held
        self.workflows.add(activity.info().workflow_id)

    async def settle(self, lease, amount):
        assert self.held.pop(lease) == amount == 10
        self.spent += amount

    async def unknown(self, lease):
        assert lease in self.held


@pytest.mark.parametrize("tokens,expected_calls", [(150, 15), (140, 14)])
def test_real_child_sdk_loop_exceeds_ten_turns_and_shares_original_resources(proof_root, tokens, expected_calls):
    async def scenario():
        root = OriginalRootProbe(tokens)
        tool_values = []

        @activity.defn(name="matrix_step")
        async def observed(previous: int) -> str:
            tool_values.append(previous)
            return json.dumps(previous + 1)

        class Provider(ModelProvider):
            def get_model(self, name):
                def respond(items):
                    root.calls += 1
                    values = outputs(items)
                    if name == "matrix-parent":
                        if not values:
                            return calls(("delegate", "delegate-one", {"request": "Advance twelve times"}))
                        assert values == [12]
                        return answer("Child reached twelve")
                    assert name == "matrix-child"
                    latest = values[-1] if values else 0
                    return answer("12") if latest == 12 else calls(
                        ("matrix_step", f"child-{latest}", {"previous": latest}))
                return AdmissionProbeModel(ScriptedModel(respond), root)

        async with service(proof_root, Provider()) as (env, ident, _, _):
            queue = "children-" + uuid4().hex
            async with bounded_worker(env.client, task_queue=queue,
                workflows=[SDKCompatibilityParent, SDKCompatibilityChild], activities=[observed],
                interceptors=[SafeActivityInterceptor()]):
                handle = await env.client.start_workflow(SDKCompatibilityParent.run, id=ident,
                    task_queue=queue, execution_timeout=timedelta(seconds=40),
                    retry_policy=RetryPolicy(maximum_attempts=1))
                if tokens == 150:
                    assert await asyncio.wait_for(handle.result(), 30) == "Child reached twelve"
                else:
                    with pytest.raises(WorkflowFailureError):
                        await asyncio.wait_for(handle.result(), 30)
            assert tool_values == list(range(12))
            assert root.calls == expected_calls
            assert root.spent == tokens and not root.held
            assert len(root.workflows) == 2 and ident in root.workflows
            (proof_root / f"child-root-{tokens}.json").write_text(json.dumps({
                "modelCalls": root.calls, "settledTokens": root.spent,
                "workflowCount": len(root.workflows), "childToolCalls": len(tool_values),
                "productionSqlAccountingQualified": False,
            }))
    asyncio.run(scenario())


def test_durable_branch_failure_is_safe_and_cannot_become_a_completed_answer(proof_root, caplog):
    async def scenario():
        model_calls = []

        @activity.defn(name="matrix_dispatch")
        async def fail(envelope: dict) -> str:
            raise RuntimeError("matrix-private-provider-marker")

        class Provider(ModelProvider):
            def get_model(self, name):
                def respond(_):
                    model_calls.append(activity.info().activity_id)
                    return calls(("matrix_branch", "failing-call", {"key": "fail"}))
                return ScriptedModel(respond)

        async with service(proof_root, Provider()) as (env, ident, _, _):
            queue = "failure-" + uuid4().hex
            async with bounded_worker(env.client, task_queue=queue, workflows=[SDKCompatibilityMatrix],
                activities=[fail], interceptors=[SafeActivityInterceptor()]):
                handle = await env.client.start_workflow(SDKCompatibilityMatrix.run, "failure",
                    id=ident, task_queue=queue, execution_timeout=timedelta(seconds=30),
                    retry_policy=RetryPolicy(maximum_attempts=1))
                with pytest.raises(WorkflowFailureError):
                    await asyncio.wait_for(handle.result(), 20)
            history = await handle.fetch_history()
            assert len(model_calls) == 1
            assert "matrix-private-provider-marker" not in history.to_json()
            assert "matrix-private-provider-marker" not in caplog.text
            assert not any(e.HasField("workflow_execution_completed_event_attributes") for e in history.events)
    asyncio.run(scenario())


def test_cancel_reaches_the_active_durable_tool_before_another_model_call(proof_root):
    async def scenario():
        started, cancelled = asyncio.Event(), asyncio.Event()
        model_calls = []

        @activity.defn(name="matrix_dispatch")
        async def block(envelope: dict) -> str:
            started.set()
            try:
                while True:
                    activity.heartbeat()
                    await asyncio.sleep(.05)
            finally:
                cancelled.set()

        class Provider(ModelProvider):
            def get_model(self, name):
                def respond(_):
                    model_calls.append(activity.info().activity_id)
                    return calls(("matrix_branch", "cancel-call", {"key": "cancel"}))
                return ScriptedModel(respond)

        async with service(proof_root, Provider()) as (env, ident, _, _):
            queue = "cancel-" + uuid4().hex
            async with bounded_worker(env.client, task_queue=queue, workflows=[SDKCompatibilityMatrix],
                activities=[block], interceptors=[SafeActivityInterceptor()]):
                handle = await env.client.start_workflow(SDKCompatibilityMatrix.run, "cancel",
                    id=ident, task_queue=queue, execution_timeout=timedelta(seconds=30))
                await asyncio.wait_for(started.wait(), 10)
                await handle.cancel()
                with pytest.raises(WorkflowFailureError):
                    await asyncio.wait_for(handle.result(), 10)
                await asyncio.wait_for(cancelled.wait(), 3)
            assert len(model_calls) == 1
    asyncio.run(scenario())


def test_large_private_tool_result_uses_an_owner_bound_artifact_reference(proof_root):
    async def scenario():
        directory = proof_root / "claimcheck"
        directory.mkdir(mode=0o700)
        keys_dir, artifacts_dir = directory / "keys", directory / "artifacts"
        keys_dir.mkdir(mode=0o700)
        artifacts_dir.mkdir(mode=0o700)
        keys = LocalKeys(keys_dir)
        keys.rotate()
        artifacts = LocalArtifacts(artifacts_dir, keys)
        subject = {"installationId": str(uuid4()), "applicationId": str(uuid4()),
                   "tenantId": "fixture-tenant", "subjectId": "fixture-owner"}
        raw = b"sdk-claimcheck-private-marker" + b"x" * 100_000
        observed = []

        @activity.defn(name="matrix_dispatch")
        async def store(envelope: dict) -> str:
            assert envelope["root"] == "fixture-original-root"
            reference = artifacts.create(subject, "artifact", raw)
            observed.append(reference)
            return json.dumps({**artifacts.pin(reference), "bytes": len(raw)})

        class Provider(ModelProvider):
            def get_model(self, name):
                def respond(items):
                    serialized = json.dumps(items)
                    assert "sdk-claimcheck-private-marker" not in serialized
                    assert len(serialized.encode()) < 65_536
                    values = outputs(items)
                    if not values:
                        return calls(("matrix_branch", "claimcheck-one", {"key": "large"}))
                    assert values[-1]["bytes"] == len(raw)
                    assert values[-1]["reference"] == observed[0]
                    return answer("Private result retained by reference")
                return ScriptedModel(respond)

        async with service(proof_root, Provider()) as (env, ident, _, _):
            queue = "claimcheck-" + uuid4().hex
            async with bounded_worker(env.client, task_queue=queue, workflows=[SDKCompatibilityMatrix],
                activities=[store], interceptors=[SafeActivityInterceptor()]):
                handle = await env.client.start_workflow(SDKCompatibilityMatrix.run, "claimcheck",
                    id=ident, task_queue=queue, execution_timeout=timedelta(seconds=30))
                assert (await asyncio.wait_for(handle.result(), 20))["answer"] == "Private result retained by reference"
            assert artifacts.read(subject, observed[0]) == raw
            with pytest.raises(OwnershipError):
                artifacts.read({**subject, "subjectId": "different-owner"}, observed[0])
            assert "sdk-claimcheck-private-marker" not in (await handle.fetch_history()).to_json()
    asyncio.run(scenario())
