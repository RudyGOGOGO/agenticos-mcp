"""A current binding resumes only the original private query objective."""
import asyncio
from copy import deepcopy
import json
from uuid import UUID,uuid4,uuid5

import httpx
import pytest

from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from agentic_os_agent_worker.query_context import FACT_FORMAT,rebound_query_window
from agentic_os_agent_worker.sdk_model import SDKModelSequence,SDKModelPolicyError
from test_private_state_rpc import fixture
from test_query_frontiers import query_item
from test_sdk_model import binding_fixture
from test_sdk_tools import Boundary


@pytest.mark.parametrize('fault',[None,'owner','goal','query','order'])
def test_query_intent_rpc_freezes_scope_and_validates_bounded_descriptors(fault):
    config,context,_,_,_=fixture();original=deepcopy(context);_,query=query_item(0);keys=[query['key']];goal='a'*64
    response=dict(context=deepcopy(context),goalDigest=goal,queries=[query],
        aliases=[dict(queryKey=query['key'],queryKeys=[query['key']])])
    if fault=='owner':response['context']['subject']['subjectId']='foreign'
    elif fault=='goal':response['goalDigest']='b'*64
    elif fault=='query':response['queries'][0]['key']='foreign'
    elif fault=='order':response['queries'].append(dict(deepcopy(query),key='foreign'))
    async def token():
        context['subject']['subjectId']='changed-after-call';keys.append('changed-after-call')
        return 'synthetic-private-worker'
    async def rpc(request):
        value=json.loads(request.content)
        assert value['context']==original and value['queryKeys']==['query-0'] and value['goalDigest']==goal
        assert request.url.path.endswith('/query-intent-metadata')
        return httpx.Response(200,json=response)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.query_intent_metadata(context,goal,keys)
            else:assert await client.query_intent_metadata(context,goal,keys)==response
        finally:await client.close()
    asyncio.run(run())


def test_indexed_intent_navigation_keeps_alias_completion_and_only_hydrates_pending_queries():
    from agentic_os_agent_worker.query_source_journey import query_execution_queries,query_goal_queries
    _,_,binding=binding_fixture();context=binding['context'];_,query=query_item(0);goal='a'*64
    index=dict(schema='agent-query-intent-index/1',context=deepcopy(context),goalDigest=goal,
        queryKeys=['query-0','equivalent-query','query-1'])
    value=dict(start=dict(context=context),goalDraftJson=json.dumps(index),continuationInputJson=None)
    class Metadata:
        def __init__(self):self.requests=[]
        async def query_intent_metadata(self,c,g,keys):
            assert c==context and g==goal;self.requests.append(keys)
            return dict(context=c,goalDigest=g,queries=[query],aliases=[dict(queryKey='query-0',queryKeys=['query-0','equivalent-query'])])
    async def run():
        boundary=Metadata();queries,aliases=await query_execution_queries(value,boundary)
        assert queries==[query] and aliases[0]['queryKeys']==['query-0','equivalent-query']
        assert boundary.requests==[['query-0','equivalent-query']]
        value['continuationInputJson']=json.dumps([dict(role='user',content=json.dumps(dict(
            frontiers=[dict(queryKeys=['query-0','equivalent-query'],nextCursor=None)])))])
        # A changed owner/goal response cannot replace the immutable index.
        assert [q['key'] for q in query_goal_queries(value)]==index['queryKeys']
        async def next_query(c,g,keys):
            assert keys==['query-1']
            return dict(context=c,goalDigest=g,queries=[dict(query,key='query-1')],
                aliases=[dict(queryKey='query-1',queryKeys=['query-1'])])
        boundary.query_intent_metadata=next_query
        assert (await query_execution_queries(value,boundary))[0][0]['key']=='query-1'
    asyncio.run(run())


def test_plain_native_query_selection_reopens_only_current_unfinished_chains():
    from agentic_os_agent_worker.query_source_journey import query_execution_queries
    queries=[query_item(i)[1] for i in range(2)];goal='a'*64
    window=dict(schema=FACT_FORMAT,goalDigest=goal,results=[],frontiers=[dict(queryKeys=[queries[0]['key']],
        toolName='owned-tool',queryDigest='b'*64,pageOrdinal=0,nextCursor=None)])
    value=dict(goalDraftJson=json.dumps(dict(queries=queries)),goalDigest=goal,
        continuationInputJson=json.dumps([dict(role='user',content=json.dumps(window))]))
    async def run():
        assert (await query_execution_queries(value,None))[0]==queries  # Legacy/checkpoint selection.
        assert (await query_execution_queries(value,None,skip_completed=True))[0]==queries[1:]
        window['frontiers'][0]['nextCursor']='next-page'
        value['continuationInputJson']=json.dumps([dict(role='user',content=json.dumps(window))])
        assert (await query_execution_queries(value,None,skip_completed=True))[0]==queries
        window['frontiers']=[]  # Current-fact invalidation reopens the original query.
        value['continuationInputJson']=json.dumps([dict(role='user',content=json.dumps(window))])
        assert (await query_execution_queries(value,None,skip_completed=True))[0]==queries
        value['goalDigest']='c'*64
        with pytest.raises(SDKModelPolicyError):await query_execution_queries(value,None,skip_completed=True)
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'turn','parent','owner','goal','causal-head'])
def test_known_model_recovery_rpc_accepts_only_the_exact_next_binding_and_current_fact(fault):
    config,context,_,_,private=fixture();instance=str(uuid5(UUID(context['taskId']),'sdk-instance/1'));goal='a'*64;ident=str(uuid4())
    reference=dict(subject=deepcopy(context['subject']),rootId=context['rootId'],taskId=context['taskId'],
        resultId=ident,producerStepId=ident,acceptedAttemptId=str(uuid4()),payload=dict(private['payload'],schemaRef='AgentQueryFactSet'),
        lineageRef=None,scopeRef=context['scopeRef'],acceptedAt=private['createdAt'])
    binding=dict(context=deepcopy(context),sdkInstanceId=instance,turn=4,planRevision=1,
        parentOperationId=str(uuid5(UUID(instance),'model-turn/3')),inputResults=[deepcopy(reference)])
    original=deepcopy(binding);operation=str(uuid5(UUID(instance),'model-turn/4'))
    resumed=dict(deepcopy(binding),turn=5,parentOperationId=operation,inputResults=[reference])
    response=dict(kind='changed',operationId=operation,binding=resumed,goalDigest=goal,result=reference,invalidQueryKeys=['concentrations'])
    if fault=='turn':resumed['turn']+=1
    elif fault=='parent':resumed['parentOperationId']=str(uuid4())
    elif fault=='owner':resumed['context']['subject']['subjectId']='foreign'
    elif fault=='goal':response['goalDigest']='b'*64
    elif fault=='causal-head':resumed['inputResults']=[]
    async def token():binding['turn']=99;return 'synthetic-private-worker'
    async def rpc(request):
        command=json.loads(request.content);assert command['binding']==original and command['goalDigest']==goal
        assert request.url.path.endswith('/query-model-recovery')
        return httpx.Response(200,json=response)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.recover_query_model(binding,goal)
            else:assert await client.recover_query_model(binding,goal)==response
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'checkpoint','parent','owner','goal','causal-head'])
def test_pending_query_refresh_rpc_keeps_original_instance_parent_and_current_fact_head(fault):
    config,context,_,_,private=fixture();instance=str(uuid5(UUID(context['taskId']),'sdk-instance/1'))
    ident=str(uuid5(UUID(instance),'checkpoint/4'));slot=str(uuid4());goal='a'*64
    reference=dict(subject=deepcopy(context['subject']),rootId=context['rootId'],taskId=context['taskId'],
        resultId=slot,producerStepId=slot,acceptedAttemptId=str(uuid4()),payload=dict(private['payload'],schemaRef='AgentQueryFactSet'),
        lineageRef=None,scopeRef=context['scopeRef'],acceptedAt=private['createdAt'])
    binding=dict(context=deepcopy(context),sdkInstanceId=instance,turn=4,planRevision=1,
        parentOperationId=str(uuid5(UUID(instance),'model-turn/3')),inputResults=[deepcopy(reference)])
    result=dict(kind='changed',checkpointId=ident,binding=binding,goalDigest=goal,result=reference,invalidQueryKeys=['concentrations'])
    if fault=='checkpoint':result['checkpointId']=str(uuid4())
    elif fault=='parent':binding['parentOperationId']=str(uuid4())
    elif fault=='owner':binding['context']['subject']['subjectId']='foreign'
    elif fault=='goal':result['goalDigest']='b'*64
    elif fault=='causal-head':binding['inputResults']=[]
    async def rpc(request):return httpx.Response(200,json=result)
    async def token():return 'synthetic-private-worker'
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.query_checkpoint_state(context,ident,goal)
            else:assert await client.query_checkpoint_state(context,ident,goal)==result
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'binding','candidate','owner'])
def test_binding_rpc_pins_accepted_operation_and_freezes_context_before_token_await(fault):
    config,context,_,_,private=fixture();original=deepcopy(context);operation=str(uuid4())
    step=str(uuid5(UUID(operation),'model-attempt/1'))
    candidate=dict(subject=deepcopy(context['subject']),rootId=context['rootId'],taskId=context['taskId'],
        resultId=str(uuid5(UUID(step),'accepted-result')),producerStepId=step,acceptedAttemptId=str(uuid4()),
        payload=dict(private['payload'],schemaRef='AgentProviderResponse'),lineageRef=None,
        scopeRef=context['scopeRef'],acceptedAt=private['createdAt'])
    ident=str(uuid5(UUID(context['taskId']),'query-source-binding/1/'+candidate['resultId']))
    response=dict(kind='ready',context=deepcopy(original),bindingId=ident,targetCount=1,
        goalDigest='a'*64,sourceCandidate=deepcopy(candidate))
    if fault=='binding':response['bindingId']=str(uuid4())
    elif fault=='candidate':response['sourceCandidate']['resultId']=str(uuid4())
    elif fault=='owner':response['context']['subject']['subjectId']='foreign'
    actions=[]
    async def token():
        context['rootId']=str(uuid4());return 'synthetic-private-worker'
    async def rpc(request):
        value=json.loads(request.content);assert value['context']==original and value['operationId']==operation
        action=request.url.path.rsplit('/',1)[1];actions.append(action)
        return httpx.Response(200,json=dict(operationId=operation,attemptNumber=1,result=candidate)
            if action=='accepted-operation' else response)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.bind_current_query_source(context,operation)
            else:assert await client.bind_current_query_source(context,operation)==response
        finally:await client.close()
    asyncio.run(run());assert actions==['accepted-operation','bind-current-query-source']


@pytest.mark.parametrize('fault',[None,'binding','owner','root','schema','producer'])
def test_child_recovery_rpc_rejects_foreign_or_malformed_current_fact_heads(fault):
    test_refresh_rpc_rejects_foreign_or_malformed_fact_heads(fault,recover=True)


@pytest.mark.parametrize('fault',[None,'binding','owner','root','schema','producer'])
def test_refresh_rpc_rejects_foreign_or_malformed_fact_heads(fault,*,recover=False):
    config,context,_,_,private=fixture();ident=str(uuid4());slot=str(uuid4());original=deepcopy(context)
    reference=dict(subject=deepcopy(context['subject']),rootId=context['rootId'],taskId=context['taskId'],
        resultId=slot,producerStepId=slot,acceptedAttemptId=str(uuid4()),
        payload=dict(private['payload'],schemaRef='AgentQueryFactSet'),lineageRef=None,
        scopeRef=context['scopeRef'],acceptedAt=private['createdAt'])
    response=dict(kind='changed',context=deepcopy(context),bindingId=ident,queryGoalDigest='a'*64,
        result=reference,invalidQueryKeys=['concentrations'])
    if fault=='binding':response['bindingId']=str(uuid4())
    elif fault=='owner':reference['subject']['subjectId']='foreign'
    elif fault=='root':reference['rootId']=str(uuid4())
    elif fault=='schema':reference['payload']['schemaRef']='AgentProviderResponse'
    elif fault=='producer':reference['producerStepId']=str(uuid4())
    async def token():context['taskId']=str(uuid4());return 'synthetic-private-worker'
    async def rpc(request):
        assert json.loads(request.content)['context']==original
        return httpx.Response(200,json=response)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            method=client.recover_bound_query_source if recover else client.inspect_bound_query_source
            if fault:
                with pytest.raises(ModelRPCError):await method(context,ident)
            else:assert await method(context,ident)==response
        finally:await client.close()
    asyncio.run(run())


def test_rebinding_window_replaces_stale_causal_head_and_only_invalid_query_frontier():
    _,_,binding=binding_fixture();original=deepcopy(binding);boundary=Boundary()
    sequence=SDKModelSequence(binding,dependency_boundary=boundary);goal='a'*64
    queries=[query_item(index)[1] for index in range(2)]
    reference=asyncio.run(boundary.accepted_model_operation(binding['context'],str(uuid4())))
    reference['payload']['schemaRef']='AgentQueryFactSet'
    frontiers=[dict(toolName='query_'+str(index),queryKeys=[query['key']],queryDigest=str(index)*64,
        pageOrdinal=3,nextCursor=None) for index,query in enumerate(queries)]
    previous=json.dumps([dict(role='user',content=json.dumps(dict(schema=FACT_FORMAT,goalDigest=goal,
        results=[],frontiers=frontiers)))])
    for changed_goal,invalid in [('b'*64,[queries[0]['key']]),(goal,['undeclared-query']), (goal,[])]:
        with pytest.raises(SDKModelPolicyError):rebound_query_window(sequence,previous,changed_goal,queries,reference,invalid)
    foreign=deepcopy(reference);foreign['rootId']=str(uuid4())
    with pytest.raises(SDKModelPolicyError):rebound_query_window(sequence,previous,goal,queries,foreign,[queries[0]['key']])
    stale_native=deepcopy(reference);stale_native['resultId']=str(uuid4());stale_native['payload']['schemaRef']='AgentNativeAnalysisResult'
    sequence.binding['inputResults'].append(stale_native)
    result=rebound_query_window(sequence,previous,goal,queries,reference,[queries[0]['key']])
    content=json.loads(result[0]['content'])
    assert content['results']==[reference] and content['frontiers']==[frontiers[1]]
    assert sequence.snapshot()['inputResults']==[reference]
    assert all(sequence.snapshot()[key]==value for key,value in original.items() if key!='inputResults')


@pytest.mark.parametrize('pending',[None,'parent','child'])
def test_settled_phase_rebinds_original_query_without_discarding_pending_sdk_state(monkeypatch,pending,*,recovery=None):
    from pathlib import Path
    from agentic_os_agent_worker import query_source_journey
    _,_,binding=binding_fixture();query=query_item(0)[1];goal='a'*64;ident=str(uuid4())
    reference=asyncio.run(Boundary().accepted_model_operation(binding['context'],str(uuid4())))
    reference['payload']['schemaRef']='AgentQueryFactSet'
    value=deepcopy(next(row['value'] for row in json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
        if row['valid'] and row['contract']=='AgentSDKQuerySourceChildJoinJourneyStart'))
    value.update(phase='children',binding=binding,goalDigest='b'*64,goalDraftJson=json.dumps(dict(queries=[query])),
        sourceBindingId=ident,sourceQueryWindowJson=json.dumps([dict(role='user',content=json.dumps(dict(
            schema=FACT_FORMAT,goalDigest=goal,results=[],frontiers=[])))]),childContinuation=None,childContinuations=[])
    value['start']['context']=deepcopy(binding['context']);value['start']['checkpointId']=str(uuid4()) if pending=='parent' else None
    if pending=='child':
        if recovery is None:value['childContinuations']=[dict(ownedPendingSDKState=True)]
        else:
            state=deepcopy(next(row['value'] for row in json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
                if row['valid'] and row['contract']=='AgentSDKChildContinuation'))
            state['binding']['context']=deepcopy(binding['context']);value['childContinuations']=[state]
            from agentic_os_agent_worker.transport import _validate
            _validate('AgentSDKChildContinuation',state)
    original=deepcopy(value);calls=[];carried=[]
    class Continued(Exception):pass
    def carry(result):carried.append(deepcopy(result));raise Continued()
    monkeypatch.setattr(query_source_journey.workflow,'continue_as_new',carry)
    class CurrentBoundary(Boundary):
        async def recover_bound_query_source(self,context,operation,binding_id):
            if recovery=='reconciliation':return dict(kind='reconciliation',bindingId=ident)
            response=await self.inspect_bound_query_source(context,operation,binding_id)
            if recovery=='current':
                return dict(kind='ready',context=deepcopy(context),bindingId=ident,targetCount=1,
                    goalDigest=value['goalDigest'],sourceCandidate=dict(reference,payload=dict(reference['payload'],schemaRef='AgentProviderResponse')))
            return response
        async def inspect_bound_query_source(self,context,operation,binding_id):
            calls.append(1);assert context==binding['context'] and binding_id==ident
            return dict(kind='changed',context=deepcopy(context),bindingId=ident,queryGoalDigest=goal,
                result=reference,invalidQueryKeys=[query['key']])
    def refresh():return query_source_journey.refresh_bound_source(value,CurrentBoundary(),pending_recovery=recovery is not None)
    if recovery=='reconciliation':
        from temporalio.exceptions import ApplicationError
        with pytest.raises(ApplicationError):asyncio.run(refresh())
        assert value==original and carried==[]
    elif pending and recovery is None or recovery=='current':
        assert asyncio.run(refresh()) is False
        assert value==original and (recovery=='current' or calls==[])
    else:
        with pytest.raises(Continued):asyncio.run(refresh())
        assert len(calls)==1 and len(carried)==1
        result=carried[0]
        assert result['phase']=='query-source' and result['goalDigest']==goal
        assert result['binding']['inputResults']==[reference] and result['start']==original['start']
        assert all(result['binding'][key]==item for key,item in binding.items() if key!='inputResults')


@pytest.mark.parametrize('recovery',['current','changed','reconciliation'])
def test_pending_child_state_is_preserved_until_core_proves_current_recovery(monkeypatch,recovery):
    test_settled_phase_rebinds_original_query_without_discarding_pending_sdk_state(monkeypatch,'child',recovery=recovery)
