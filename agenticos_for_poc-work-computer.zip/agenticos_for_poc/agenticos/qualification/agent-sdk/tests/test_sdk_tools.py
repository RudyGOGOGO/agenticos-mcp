"""Actual SDK tool loop/hooks; all model and kernel responses are synthetic."""
import asyncio
from copy import deepcopy
import json
from uuid import UUID,uuid5

from agents import Agent,Model,ModelSettings,Runner,RunConfig
from agents.items import ModelResponse
from agents.tool_context import ToolContext
from agents.usage import Usage
from agents.exceptions import UserError
from openai.types.responses import ResponseFunctionToolCall,ResponseOutputMessage,ResponseOutputText
import pytest

from agentic_os_agent_worker.checkpoint import tool_alias
from agentic_os_agent_worker.sdk_model import SDKModelSequence,SDKModelPolicyError,operation_id,BINDING_KEY
from agentic_os_agent_worker.sdk_tools import governed_read_tool,SDKToolDeferred,deferred_tool_condition
from test_sdk_model import binding_fixture
from test_tool_execution_rpc import accepted_for
from test_tool_rpc import fixture


def item_fixture():
    _,request,_=fixture()
    return dict(capability=request['capability'],kind='read',title='Synthetic read',description='Read a synthetic value.',
        inputSchemaJson='{"type":"object","properties":{"value":{"type":"number"}},"required":["value"],"additionalProperties":false}',
        outputSchemaJson='{"type":"object","properties":{}}',scopeRef=request['context']['scopeRef'],available=True,blocker=None)


class Boundary:
    def __init__(self,kind='accepted'):self.requests=[];self.kind=kind;self.sets=[]
    async def accepted_model_operation(self,context,operation):
        _,_,binding=fixture();result=deepcopy(binding['modelResult'])
        result.update(subject=deepcopy(context['subject']),taskId=context['taskId'],rootId=context['rootId'],resultId=str(uuid5(UUID(operation),'synthetic-accepted')),producerStepId=str(uuid5(UUID(operation),'model-attempt/1')))
        return result
    async def pack_input_results(self,context,set_id,references):
        self.sets.append(deepcopy(references));result=deepcopy(references[0])
        result.update(resultId=str(uuid5(UUID(set_id),'accepted-result-set')),producerStepId=set_id);result['payload']['schemaRef']='AgentInputResultSet'
        return dict(kind='ready',setId=set_id,result=result)
    async def execute_tool(self,request):
        self.requests.append(deepcopy(request));result=accepted_for(request)
        if self.kind=='accepted':return result
        return dict(kind='reconciliation',operationId=result['accepted']['binding']['identity']['operationId'],
            callId=result['accepted']['result']['producerStepId'],reason='tool-completion-unknown')


class ModelCalls(Model):
    def __init__(self,name,count=2):self.name=name;self.inputs=[];self.count=count;self.bindings=[]
    async def get_response(self,system_instructions,input,*args,**kwargs):
        self.inputs.append(deepcopy(input))
        settings=kwargs.get('model_settings') if 'model_settings' in kwargs else args[0]
        self.bindings.append(json.loads(settings.metadata[BINDING_KEY]))
        if len(self.inputs)==1:
            output=[ResponseFunctionToolCall(type='function_call',name=self.name,arguments='{"value":0.5}',call_id='call_'+str(i),id='fc_'+str(i)) for i in range(self.count)]
        else:output=[ResponseOutputMessage(type='message',id='msg_done',role='assistant',status='completed',
            content=[ResponseOutputText(type='output_text',text='Done',annotations=[])])]
        return ModelResponse(output=output,usage=Usage(requests=1),response_id='response_'+str(len(self.inputs)))
    def stream_response(self,*args,**kwargs):raise AssertionError('Streaming is not this profile')


@pytest.mark.parametrize('bounded',[False,True])
def test_actual_sdk_discovery_filter_bounds_temporal_activity_payload_without_dropping_history(bounded):
    from agentic_os_agent_worker.catalog_context import discovery_call_model_input_filter
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    _,_,binding=binding_fixture();binding['context']['harness']['ref']='governed-read-discovery/'+'a'*64
    class CatalogBoundary(Boundary):
        async def execute_tool(self,request):
            self.requests.append(deepcopy(request));result=accepted_for(request)
            entries=[dict(capability=dict(request['capability'],ref='reviewed.read.'+str(i)),kind='read',
                title='Reviewed choice '+str(i),description='M'*512,descriptionTruncated=False,
                available=True,blocker=None,providerRef='synthetic.read') for i in range(16)]
            page=dict(context=deepcopy(request['context']),request=dict(cursor=None,limit=16,retain=[]),
                catalogVersion=130,items=entries,retained=[],nextCursor='opaque-next',validUntil=request['context']['authorizationHorizon'])
            raw=json.dumps(page,separators=(',',':'));result['accepted']['payloadJson']=raw
            result['accepted']['result']['payload'].update(schemaRef='AgentCapabilityDiscoveryPage',bytes=len(raw.encode()))
            return result
    boundary=CatalogBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    tool=governed_read_tool(item_fixture(),boundary,sequence,result_context='agent-capability-discovery/1')
    sizes=[];inputs=[]
    class SerializedModel(Model):
        async def get_response(self,system_instructions,input,model_settings,*args,**kwargs):
            inputs.append(deepcopy(input))
            payload=AgentPayloadConverter().to_payloads([dict(input=input,system_instructions=system_instructions,
                model_settings=model_settings,tracing=0)])[0]
            sizes.append(len(payload.SerializeToString(deterministic=True)))
            ordinal=len(inputs)
            output=([ResponseFunctionToolCall(type='function_call',name=tool.name,arguments='{"value":0.5}',
                call_id='page_'+str(ordinal),id='fc_'+str(ordinal))] if ordinal<=9 else
                [ResponseOutputMessage(type='message',id='done',role='assistant',status='completed',
                    content=[ResponseOutputText(type='output_text',text='Done',annotations=[])])])
            return ModelResponse(output=output,usage=Usage(requests=1),response_id='response_'+str(ordinal))
        def stream_response(self,*args,**kwargs):raise AssertionError('No streaming in this profile')
    async def run():
        result=await Runner.run(Agent(name='Bounded metadata',model=SerializedModel(),tools=[tool],model_settings=ModelSettings(metadata={})),
            'Original read objective',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True,
                call_model_input_filter=discovery_call_model_input_filter(binding['context']) if bounded else None))
        # The SDK owns the complete supported history even when its per-call
        # public filter sends only the latest accepted page to Temporal.
        assert len([item for item in result.to_input_list() if item.get('type')=='function_call_output'])==9
    asyncio.run(run());assert len(boundary.requests)==9 and len(inputs)==10
    assert max(sizes)<=65536 if bounded else max(sizes)>65536
    assert all(len([item for item in current if item.get('type')=='function_call_output'])<=1 for current in inputs) if bounded else True


def test_actual_sdk_memory_result_retains_causal_reference_and_truthful_empty_page():
    from test_tool_execution_rpc import memory_accepted_for
    _,_,binding=binding_fixture();binding['context']['harness']['ref']='memory-assisted-read/synthetic-source'
    class MemoryBoundary(Boundary):
        async def execute_tool(self,request):
            self.requests.append(deepcopy(request));return memory_accepted_for(request)
    boundary=MemoryBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    item=item_fixture()|dict(kind='memory');tool=governed_read_tool(item,boundary,sequence,result_context='agent-accepted-memory/1')
    model=ModelCalls(tool.name,count=1)
    async def run():
        result=await Runner.run(Agent(name='Governed memory source',model=model,tools=[tool],model_settings=ModelSettings(metadata={})), 'Recall',hooks=sequence,
            max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert result.final_output=='Done'
    asyncio.run(run())
    output=next(value for value in model.inputs[1] if value.get('type')=='function_call_output')
    value=json.loads(output['output'])
    assert value['schema']=='agent-accepted-memory/1' and value['memory']['page']['records']==[]
    assert value['memory']['coverage']['exhaustive'] is False
    assert value['result'] in model.bindings[1]['inputResults']
    assert all(request['context']['rootId']==binding['context']['rootId'] for request in boundary.requests)


def test_actual_sdk_parallel_tools_keep_call_ids_arguments_and_accepted_model_parent():
    _,_,binding=binding_fixture();boundary=Boundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary);item=item_fixture()
    tool=governed_read_tool(item,boundary,sequence);model=ModelCalls(tool.name)
    assert tool.params_json_schema==json.loads(item['inputSchemaJson']) and tool.strict_json_schema is False and tool.needs_approval is False
    async def run():
        agent=Agent(name='Synthetic governed tools',model=model,tools=[tool],model_settings=ModelSettings(metadata={}))
        result=await Runner.run(agent,'Read twice',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert result.final_output=='Done'
    asyncio.run(run())
    assert sorted(r['callId'] for r in boundary.requests)==['call_0','call_1']
    assert all(r['modelOperationId']==operation_id(binding) and r['argumentsJson']=='{"value":0.5}' and r['toolName']==tool_alias(item['capability']) for r in boundary.requests)
    outputs=[v for v in model.inputs[1] if v.get('type')=='function_call_output']
    assert len(outputs)==2 and all(json.loads(v['output'])['records']==[] and json.loads(v['output'])['nextCursor'] is None for v in outputs)
    assert sequence.snapshot()['turn']==3
    assert len(model.bindings[1]['inputResults'])==3 and len(sequence.snapshot()['inputResults'])==1


def test_unknown_tool_stops_the_actual_sdk_run_without_a_second_model_call():
    _,_,binding=binding_fixture();boundary=Boundary('unknown');sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    tool=governed_read_tool(item_fixture(),boundary,sequence);model=ModelCalls(tool.name)
    async def run():
        agent=Agent(name='Synthetic deferred tool',model=model,tools=[tool],model_settings=ModelSettings(metadata={}))
        with pytest.raises(UserError) as caught:await Runner.run(agent,'Read',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        condition=deferred_tool_condition(caught.value)
        assert isinstance(condition,SDKToolDeferred) and condition.preparation['kind']=='reconciliation'
    asyncio.run(run());assert len(model.inputs)==1 and len(boundary.requests)==2


def test_review_preparation_restores_sdk_checkpoint_and_stops_before_another_model():
    from dataclasses import replace
    from pathlib import Path
    from agentic_os_agent_worker.checkpoint import export_checkpoint,restore_checkpoint
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
    prepared=next(row['value'] for row in vectors if row['valid'] and row['contract']=='AgentPreparedChange')
    class PreparationBoundary(Boundary):
        async def execute_tool(self,request):
            self.requests.append(deepcopy(request));result=accepted_for(request)
            raw=json.dumps(prepared,separators=(',',':'));result['accepted']['payloadJson']=raw
            result['accepted']['result']['payload'].update(schemaRef='AgentPreparedChange',bytes=len(raw.encode()))
            return result
    class NoMoreModel(ModelCalls):
        async def get_response(self,*args,**kwargs):raise AssertionError('Preparation must stop before another model')
    _,_,binding=binding_fixture();boundary=PreparationBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    item=item_fixture()|dict(kind='propose');tool=replace(governed_read_tool(item,boundary,sequence,result_context='agent-prepared-change/1'),needs_approval=True)
    model=ModelCalls(tool.name,count=1)
    async def run():
        agent=Agent(name='Prepare exact reviewed change',model=model,tools=[tool],tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
        paused=await Runner.run(agent,'Prepare this exact change',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert len(paused.interruptions)==1 and boundary.requests==[]
        envelope=export_checkpoint(paused,sequence,[item['capability']]);recovered=SDKModelSequence(envelope['binding'],dependency_boundary=boundary)
        restored_tool=replace(governed_read_tool(item,boundary,recovered,result_context='agent-prepared-change/1'),needs_approval=True)
        restored_agent=Agent(name=agent.name,model=NoMoreModel(tool.name),tools=[restored_tool],tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
        restored=await restore_checkpoint(restored_agent,envelope,expected_context=binding['context'],sdk_instance_id=binding['sdkInstanceId'],capabilities=[item['capability']],sequence=recovered,dependency_boundary=boundary)
        for interruption in restored.state.get_interruptions():restored.state.approve(interruption)
        result=await Runner.run(restored_agent,restored.state,hooks=recovered,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert json.loads(result.final_output)==prepared
        assert len(boundary.requests)==1 and len(model.inputs)==1
        assert sum(ref['payload']['schemaRef']=='AgentPreparedChange' for ref in recovered.snapshot()['inputResults'])==1
    asyncio.run(run())


@pytest.mark.parametrize('profile',['evidence-page/1','agent-accepted-read/1','agent-accepted-query/1','agent-accepted-query-ref/1'])
def test_invalid_payload_cannot_advance_the_sdk_dependency_sequence(profile):
    _,_,binding=binding_fixture();binding['parentOperationId']=str(uuid5(UUID(binding['sdkInstanceId']),'accepted-parent'))
    class InvalidBoundary(Boundary):
        async def execute_tool(self,request):
            result=accepted_for(request,query=profile in {'agent-accepted-query/1','agent-accepted-query-ref/1'})
            result['accepted']['payloadJson']='{"records":[]}'
            return result
    boundary=InvalidBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    tool=governed_read_tool(item_fixture(),boundary,sequence,result_context=profile)
    context=ToolContext(context=None,tool_name=tool.name,tool_call_id='call_exact',tool_arguments='{"value":0.5}')
    before=sequence.snapshot()
    with pytest.raises(ValueError):asyncio.run(tool.on_invoke_tool(context,'{"value":0.5}'))
    assert sequence.snapshot()==before and boundary.sets==[]


@pytest.mark.parametrize('fault',['name','arguments','namespace','pending','no-parent'])
def test_callback_refuses_unbound_or_changed_sdk_context_before_kernel_request(fault):
    _,_,binding=binding_fixture();binding['parentOperationId']=str(uuid5(UUID(binding['sdkInstanceId']),'accepted-parent'))
    boundary=Boundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary);tool=governed_read_tool(item_fixture(),boundary,sequence)
    context=ToolContext(context=None,tool_name=tool.name,tool_call_id='call_exact',tool_arguments='{"value":0.5}')
    if fault=='name':context.tool_name='changed'
    elif fault=='arguments':context.tool_arguments='{"value":999}'
    elif fault=='namespace':context.tool_namespace='unreviewed'
    elif fault=='pending':sequence.pending='pending'
    else:sequence.binding['parentOperationId']=None
    with pytest.raises(SDKModelPolicyError):asyncio.run(tool.on_invoke_tool(context,'{"value":0.5}'))
    assert boundary.requests==[]


def test_actual_sdk_parallel_results_use_bounded_sets_without_a_total_branch_ceiling():
    _,_,binding=binding_fixture();boundary=Boundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    tool=governed_read_tool(item_fixture(),boundary,sequence);model=ModelCalls(tool.name,count=130)
    async def run():
        agent=Agent(name='Synthetic paged result set',model=model,tools=[tool],model_settings=ModelSettings(metadata={}))
        result=await Runner.run(agent,'Read a batch',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert result.final_output=='Done'
    asyncio.run(run())
    assert len(boundary.requests)==130 and len(boundary.sets)==1 and len(boundary.sets[0])==128
    assert len(model.bindings[1]['inputResults'])==4
    assert any(r['payload']['schemaRef']=='AgentInputResultSet' for r in model.bindings[1]['inputResults'])


def test_public_checkpoint_restore_reuses_the_sequence_captured_by_governed_tools():
    from dataclasses import replace
    from agentic_os_agent_worker.checkpoint import export_checkpoint,restore_checkpoint
    _,_,binding=binding_fixture();boundary=Boundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    item=item_fixture();tool=replace(governed_read_tool(item,boundary,sequence),needs_approval=True);model=ModelCalls(tool.name)
    async def run():
        agent=Agent(name='Synthetic governed checkpoint',model=model,tools=[tool],model_settings=ModelSettings(metadata={}))
        paused=await Runner.run(agent,'Read twice',max_turns=None,hooks=sequence,run_config=RunConfig(tracing_disabled=True))
        assert len(paused.interruptions)==2 and boundary.requests==[]
        envelope=export_checkpoint(paused,sequence,[item['capability']])
        recovered=SDKModelSequence(envelope['binding'],dependency_boundary=boundary)
        resumed_tool=replace(governed_read_tool(item,boundary,recovered),needs_approval=True)
        resumed_model=ModelCalls(resumed_tool.name);resumed_model.inputs=[[]]
        resumed_agent=Agent(name=agent.name,model=resumed_model,tools=[resumed_tool],model_settings=ModelSettings(metadata={}))
        loaded=await restore_checkpoint(resumed_agent,envelope,expected_context=binding['context'],
            sdk_instance_id=binding['sdkInstanceId'],capabilities=[item['capability']],sequence=recovered,dependency_boundary=boundary)
        assert loaded.sequence is recovered
        # Internal synthetic read checkpoints grant no OS permission; each
        # callback still invokes the governed boundary with its original ID.
        for interruption in loaded.state.get_interruptions():loaded.state.approve(interruption)
        result=await Runner.run(resumed_agent,loaded.state,max_turns=None,hooks=loaded.sequence,run_config=RunConfig(tracing_disabled=True))
        assert result.final_output=='Done' and len(resumed_model.bindings[0]['inputResults'])==3
        assert loaded.sequence.snapshot()['turn']==3
        assert sorted(r['callId'] for r in boundary.requests)==['call_0','call_1']
    asyncio.run(run())


def test_actual_sdk_paged_context_keeps_accepted_cursor_and_reference_without_raw_rows():
    _,_,binding=binding_fixture()
    class QueryBoundary(Boundary):
        async def execute_tool(self,request):
            self.requests.append(deepcopy(request));result=accepted_for(request,query=True)
            query=json.loads(result['accepted']['payloadJson'])
            query['page'].update(records=[[dict(name='raw',value='PRIVATE-RAW-CONTENT-'+'x'*900)] for _ in range(16)],nextCursor='next/owned')
            query['page']['evidence']['publicFields']=['raw']
            query['coverage'].update(observedRows=16,expectedRows=32,status='partial',nextCursorRef='cursor/owned')
            result['accepted']['payloadJson']=json.dumps(query,separators=(',',':'))
            result['accepted']['result']['payload']['bytes']=len(result['accepted']['payloadJson'].encode())
            return result
    boundary=QueryBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    tool=governed_read_tool(item_fixture(),boundary,sequence,result_context='agent-accepted-query-ref/1');model=ModelCalls(tool.name,count=1)
    async def run():
        agent=Agent(name='Paged accepted context',model=model,tools=[tool],model_settings=ModelSettings(metadata={}))
        result=await Runner.run(agent,'Read the authorized query page',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert result.final_output=='Done'
    asyncio.run(run())
    output=next(item for item in model.inputs[1] if isinstance(item,dict) and item.get('type')=='function_call_output')
    context=json.loads(output['output'])
    assert context['schema']=='agent-accepted-query-ref/1' and context['nextCursor']=='next/owned'
    assert context['coverage']['observedRows']==16 and context['result']['payload']['schemaRef']=='AgentQueryPage'
    assert 'PRIVATE-RAW-CONTENT' not in json.dumps(model.inputs) and len(json.dumps(model.inputs[1]).encode())<8192
    assert len(boundary.requests)==1 and len(model.inputs)==2
