"""Production connection admission resolves original model privacy pins first."""
import asyncio
from dataclasses import replace
import json

import httpx
import httpx2
import pytest

from agentic_os_agent_worker.transport import OfficialTransport,TransportError
from provider_transport_fixture import Boundary,fixture,privacy_configuration


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_unresolved_privacy_denies_default_and_custom_network_before_boundary_or_client(provider,monkeypatch):
    config,_,body,_=fixture(provider);boundary=Boundary(body)
    library=httpx if provider=='openai' else httpx2
    def forbidden(*args,**kwargs):pytest.fail('Unresolved policies constructed a provider client')
    monkeypatch.setattr(library,'AsyncClient',forbidden)
    for network in (None,library.AsyncHTTPTransport(retries=0)):
        try:
            with pytest.raises(TransportError):OfficialTransport(config,boundary,api_key='synthetic-key',network_transport=network)
        finally:
            if network is not None:asyncio.run(network.aclose())
    assert boundary.events==[]


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_resolved_exact_policies_allow_reusable_default_client_without_network_requests(provider):
    config,_,body,_=fixture(provider);config=privacy_configuration(config);boundary=Boundary(body)
    async def run():
        transport=OfficialTransport(config,boundary,api_key='synthetic-key')
        try:
            assert transport.config==config
            assert transport.client.max_retries==0
            assert str(transport.client.base_url).rstrip('/')==config.base_url
        finally:await transport.close()
    asyncio.run(run());assert boundary.events==[]


@pytest.mark.parametrize('fault',['credential','storage','retention','placement','endpoint','geo','extra','boolean-revision'])
def test_even_repinned_unsupported_privacy_cannot_change_account_storage_or_placement(fault):
    config,_,_,_=fixture('openai')
    def change(value):
        if fault=='credential':value['retention']['credentialRef']='foreign-account'
        elif fault=='storage':value['retention']['requestStorage']='enabled'
        elif fault=='retention':value['retention']['mode']='zero-retention'
        elif fault=='placement':value['residency']['placement']='region-restricted'
        elif fault=='endpoint':value['residency']['baseUrl']='https://foreign.invalid/v1'
        elif fault=='geo':value['residency']['inferenceGeo']='unqualified-region'
        elif fault=='extra':value['retention']['allowPrivateTelemetry']=True
        else:value['retention']['revision']=True
    with pytest.raises(TransportError):privacy_configuration(config,change=change)


def test_resolved_policy_bytes_cannot_change_under_original_pin_or_duplicate_keys():
    config,_,_,_=fixture('openai');config=privacy_configuration(config)
    value=json.loads(config.privacy_configuration_json);value['retention']['accountPolicyRef']='different-reviewed-controls'
    with pytest.raises(TransportError):replace(config,privacy_configuration_json=json.dumps(value))
    with pytest.raises(TransportError):replace(config,privacy_configuration_json='{"retention":{},"retention":{},"residency":{}}')
    with pytest.raises(TransportError):replace(config,inference_geo='unqualified-region')


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_even_repinned_profile_cannot_select_the_other_official_api(provider):
    import hashlib
    config,_,_,_=fixture(provider);profile=json.loads(config.model_profile_json)
    profile['api']='messages' if provider=='openai' else 'responses'
    raw=json.dumps(profile,sort_keys=True,ensure_ascii=False,separators=(',',':'))
    pin=hashlib.sha256(b'agentic-os.hash/1\0manifest\0'+raw.encode()).hexdigest()
    with pytest.raises(TransportError):replace(config,model_profile_json=raw,model_profile_digest=pin)
