"""Independent tool-binding protocol, with synthetic kernel replies and no I/O tools."""
import asyncio
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import json
from uuid import UUID,uuid5

import httpx
import pytest

from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from test_operation_rpc import operation_fixture


def fixture():
    config,record,_,_,ready=operation_fixture();context=record['context'];model=ready['preparation']['request']
    pin=dict(ref='synthetic.read',revision=1,digest='a'*64);call_id='call_synthetic';arguments='{"value":0.5}'
    request=dict(context=context,modelOperationId=record['identity']['operationId'],capability=pin,
        toolName='cap_synthetic',callId=call_id,argumentsJson=arguments)
    source=dict(subject=context['subject'],taskId=context['taskId'],rootId=context['rootId'],
        resultId=model['step']['stepId'],producerStepId=model['step']['stepId'],acceptedAttemptId=model['grant']['attemptId'],
        payload=dict(artifactRef='artifact/'+model['step']['stepId'],ciphertextDigest='b'*64,bytes=100,
            schemaRef='AgentProviderResponse',schemaVersion=1),lineageRef=None,scopeRef=context['scopeRef'],acceptedAt=datetime.now(timezone.utc).isoformat())
    payload=dict(modelResult=source,capability=pin,callId=call_id,callIndex=0,toolName=request['toolName'],argumentsJson=arguments)
    fingerprint=hashlib.sha256(b'agentic-os.hash/1\0command\0'+json.dumps(payload,sort_keys=True,ensure_ascii=False,
        allow_nan=False,separators=(',',':')).encode()).hexdigest()
    identity={k:context[k] for k in ('taskId','rootId','segmentId','intentRevision','controlEpoch')}
    identity.update(operationId=str(uuid5(UUID(request['modelOperationId']),'sdk-tool/'+call_id)),
        planRevision=1,parentOperationId=request['modelOperationId'],iteration=0,kind='tool',inputDigest=fingerprint)
    return config,request,dict(context=context,identity=identity,modelOperationId=request['modelOperationId'],**payload)


def test_worker_freezes_tool_request_before_credential_renewal_and_returns_only_binding():
    config,request,result=fixture();original=deepcopy(request);result=deepcopy(result);sent=[]
    async def token():
        await asyncio.sleep(0);request['context']['subject']['subjectId']='changed-after-await'
        request['argumentsJson']='{"value":999}'
        return 'synthetic-workload'
    async def rpc(http):
        value=json.loads(http.content);sent.append(value)
        assert value['request']==original and http.url.path.endswith('/resolve-tool')
        assert 'synthetic-workload' not in http.content.decode()
        return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:assert await client.resolve_tool(request)==result
        finally:await client.close()
    asyncio.run(run());assert len(sent)==1


@pytest.mark.parametrize('fault',['owner','arguments','operation','digest','pin','parent'])
def test_worker_rejects_cross_context_or_changed_binding_reply(fault):
    config,request,result=fixture();result=deepcopy(result);sent=[]
    if fault=='owner':result['modelResult']['subject']['subjectId']='foreign-owner'
    elif fault=='arguments':result['argumentsJson']='{"value":0.6}'
    elif fault=='operation':result['identity']['operationId']='00000000-0000-4000-8000-000000000099'
    elif fault=='digest':result['identity']['inputDigest']='0'*64
    elif fault=='pin':result['capability']['revision']+=1
    else:result['identity']['parentOperationId']='00000000-0000-4000-8000-000000000099'
    async def token():return 'synthetic-workload'
    async def rpc(http):sent.append(1);return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            with pytest.raises(ModelRPCError):await client.resolve_tool(request)
        finally:await client.close()
    asyncio.run(run());assert sent==[1]
