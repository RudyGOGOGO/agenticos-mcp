import asyncio
import base64
import json

import httpx2
import pytest
from openai.types.responses import Response

from agentic_os_agent_worker.transport import OfficialTransport, _json
from provider_transport_fixture import Boundary, fixture


def test_claude_wire_projection_and_tool_result_round_trip():
    config, request, _, original = fixture('anthropic')
    raw = dict(type='message', role='assistant', id='msg_fixture', model=config.model_id,
        stop_reason='tool_use', content=[dict(type='tool_use', id='toolu_fixture', name='read',
            input=dict(place='Park'))], usage=dict(original['usage'],inference_geo='not_available',speed='standard'))
    tool = dict(type='function', name='read', description='Read a place', parameters={
        'type':'object', 'properties':{'place':{'type':'string'}}, 'required':['place'],
        'additionalProperties':False}, strict=True)
    body = dict(input=[dict(role='user', content='Read Park')], tools=[tool], parallel_tool_calls=False,
        include=['reasoning.encrypted_content'], reasoning=dict(effort='none'))
    sent = []

    async def invoke(input_body, reply):
        boundary = Boundary(input_body)
        async def handler(req):
            sent.append(json.loads(req.content))
            assert req.headers['x-api-key']=='synthetic-only'
            return httpx2.Response(200, json=reply, headers={'request-id':'req_fixture'})
        transport = OfficialTransport(config, boundary, api_key='synthetic-only',
            network_transport=httpx2.MockTransport(handler))
        try:
            result = await transport.invoke(request)
        finally:
            await transport.close()
        record = boundary.records[0]
        assert result['operation']['state']=='succeeded'
        assert record['usage']['provider']=='anthropic'
        proof = json.loads(record['provider_evidence_json'])
        assert json.loads(base64.b64decode(proof['bodyBase64']))==reply
        return Response.model_validate_json(record['candidate_json'])

    first = asyncio.run(invoke(body, raw))
    call = first.output[0].model_dump()
    assert call['call_id']=='toolu_fixture'
    assert sent[0]['tool_choice']=={'type':'auto','disable_parallel_tool_use':True}
    body['input'] += [dict(type='reasoning', encrypted_content='foreign-private-ciphertext'),
        call, dict(type='function_call_output', call_id='toolu_fixture', output='Park exists')]
    body['text'] = dict(format=dict(type='json_schema', schema={'type':'object',
        'properties':{'place':{'type':'string','minLength':1}}, 'required':['place'],
        'additionalProperties':False}))
    raw.update(stop_reason='end_turn',content=[dict(type='text',text='{"place":"Park"}')])
    second = asyncio.run(invoke(body, raw))
    assert second.output_text=='{"place":"Park"}'
    assert sent[1]['messages'][-1]['content']==[dict(type='tool_result', tool_use_id='toolu_fixture', content='Park exists')]
    assert sent[1]['output_config']['format']['type']=='json_schema'
    assert 'foreign-private-ciphertext' not in json.dumps(sent)
    assert all(value['stream'] is False for value in sent)


def test_claude_unpaired_tool_history_fails_closed():
    from agentic_os_agent_worker.anthropic_messages import messages_body
    with pytest.raises(ValueError, match='Invalid tool result'):
        messages_body(dict(input=[dict(type='function_call_output',call_id='foreign',output='result')]),_json)
