"""Real SDK entry, approval/checkpoint and goal transitions for truthful gaps."""
import asyncio
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from types import SimpleNamespace
from uuid import uuid4

import pytest
from agents import RunConfig
from agents.models.interface import ModelProvider
from temporalio.converter import WorkflowSerializationContext

from agentic_os_agent_worker import read_journey
from agentic_os_agent_worker.checkpoint import tool_alias
from agentic_os_agent_worker.private_history import AgentHistoryCodec,PrivateHistoryUnavailable
from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
from agentic_os_agent_worker.transport import _validate
from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,PartialReadControl
from test_openai_control_flow import ScriptedModel,answer,calls
from test_parallel_children import Rollover,sample
from test_sdk_tools import Boundary,item_fixture
from test_tool_execution_rpc import accepted_for

from agentic_os.production.capability_gaps import compile_capability_gap


@pytest.mark.parametrize('case',['missing','adapter','composition'])
def test_actual_capability_entry_preserves_original_request_and_serializes_diagnosis_or_composition(monkeypatch,case):
    value=sample('AgentSDKCapabilityReadJourneyStart');context=value['start']['context']
    metadata=item_fixture();metadata['capability']=value['discovery']['capability']
    metadata['inputSchemaJson']=json.dumps(dict(type='object',additionalProperties=False,
        required=['cursor','limit','retain'],properties=dict(cursor=dict(anyOf=[dict(type='null'),dict(type='string')]),
            limit=dict(type='integer'),retain=dict(type='array',items=dict(type='object')))))
    expected_ref='governed-read-discovery/'+hashlib.sha256(b'agentic-os.hash/1\0manifest\0'+read_journey._dump(value['discovery']).encode()).hexdigest()
    context['harness'].update(ref=expected_ref,revision=2)
    value['start'].update(input='Read the current application record; use supported available primitives.',capabilities=[metadata],checkpointId=None)
    if case=='missing':
        from pathlib import Path
        bank=json.loads((Path(__file__).parents[3]/'qualification/production-agent/fixtures/english-task-bank-v1.json').read_bytes())
        value['start']['input']=next(row['question'] for row in bank['cases'] if row['id']=='missing-primitive')
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        objectiveFeedback=None,discoveryCapabilities=[metadata['capability']],providers=[])
    _validate('AgentSDKCapabilityReadJourneyStart',value)
    unavailable=sample('AgentCapabilityDiscoveryEntry')
    unavailable.update(capability=dict(ref='app.unavailable-read/1',revision=1,digest='b'*64),kind='read',available=False,
        blocker=dict(code='os-adapter-unavailable',explanation='Registered adapter is unavailable.',developerAction='Enable and qualify the registered adapter.'),providerRef=None)
    available=deepcopy(unavailable);available.update(capability=dict(ref='app.available-read/1',revision=1,digest='c'*64),
        available=True,blocker=None,providerRef='app/current-data')
    entries=[] if case=='missing' else [unavailable] if case=='adapter' else [unavailable,available]
    diagnosis=dict(schema='agent-capability-gap/1',id=str(uuid4()),requirement='current-application-data/1',
        code='missing-primitive' if case=='missing' else 'os-adapter-unavailable',
        capability=None if case=='missing' else unavailable['capability'])
    ordinary=dict(criteria=[dict(id=str(uuid4()),capability=available['capability'],resources=[dict(
        providerRef=available['providerRef'],resourceType='record',externalId='original-record')],fields=['title'],coverage='selected-records')])
    expected='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,
        is_continue_as_new_suggested=lambda:False,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda _:False)
    converter=AgentPayloadConverter();carried=[];checkpoints={};material=[];model_documents=[];instructions=[];accepted={};kernel=Boundary()
    def wire(item):
        payload=converter.to_payloads([item])[0];assert len(payload.SerializeToString(deterministic=True))<=65536
        return converter.from_payloads([payload])[0]
    def rollover(next_value,**options):
        assert not options or options==dict(task_queue=expected+'/execution/1')
        carried.append(wire(next_value));raise Rollover()
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    async def execute(self,request):
        assert request['capability']==metadata['capability'];result=accepted_for(request)
        result['accepted']['result'].update(**{key:context[key] for key in ('subject','taskId','rootId')})
        binding=result['accepted']['binding'];binding['modelResult']=deepcopy(accepted[request['modelOperationId']])
        identity={key:binding[key] for key in ('modelResult','capability','callId','callIndex','toolName','argumentsJson')}
        binding['identity']['inputDigest']=hashlib.sha256(b'agentic-os.hash/1\0command\0'+read_journey._dump(identity).encode()).hexdigest()
        page=dict(context=deepcopy(context),request=json.loads(request['argumentsJson']),catalogVersion=7,
            items=deepcopy(entries),retained=[],nextCursor=None,validUntil=context['authorizationHorizon'])
        raw=json.dumps(page);result['accepted']['payloadJson']=raw
        result['accepted']['result']['payload'].update(schemaRef='AgentCapabilityDiscoveryPage',bytes=len(raw.encode()))
        material.append(dict(result=deepcopy(result['accepted']['result']),binding=deepcopy(result['accepted']['binding']),page=page))
        return result
    async def accepted_model(self,c,operation):
        if operation not in accepted:accepted[operation]=await kernel.accepted_model_operation(c,operation)
        return deepcopy(accepted[operation])
    async def get_checkpoint(self,c,ident):return deepcopy(checkpoints[ident])
    monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted_model)
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',get_checkpoint)
    def respond(items):
        if not material:return calls((tool_alias(metadata['capability']),'discover',dict(cursor=None,limit=16,retain=[])))
        document=ordinary if case=='composition' and model_documents else diagnosis
        model_documents.append(deepcopy(document));return answer(json.dumps(document))
    class Model(ScriptedModel):
        async def get_response(self,system_instructions,input,*args,**kwargs):
            instructions.append(system_instructions)
            assert input[0]['content']==value['start']['input']
            assert not any(item.get('role') in {'user','system','developer'} for item in input[1:])
            return await super().get_response(system_instructions,input,*args,**kwargs)
    model=Model(respond)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    consumers=[]
    async def complete(driver,boundary,c,operation,**flags):
        assert flags['objective'] and not flags['analysis'] and c==context
        document=model_documents[-1]
        if 'criteria' in document:
            _validate('AgentReadGoalDraft',document);state='goal-bound';missing=[]
        else:
            result=compile_capability_gap(context,document,material,discovery_capability=metadata['capability'],
                catalog_version=7,registered_business_count=len(entries));consumers.append(result)
            state='not-satisfied' if result['kind']=='verified' else 'incomplete';missing=result['missingCriteria']
        return wire(PartialReadControl(rootId=c['rootId'],taskId=c['taskId'],operationId=operation,
            state=state,goalDigest='d'*64,missingCriteria=missing))
    monkeypatch.setattr(read_journey,'complete_goal',complete)
    class Driver(AgentTaskDriver):
        def _expired(self):return False
        async def _save(self,boundary,ident,envelope):
            stored=wire(dict(checkpointId=ident,value=envelope));checkpoints[ident]=stored['value'];return dict(kind='ready')
    async def run():
        current=wire(value)
        while True:
            try:return await Driver().run(current)
            except Rollover:
                current=carried[-1]
                if current['phase']=='execution':return current
    result=asyncio.run(run())
    assert len(material)==1 and checkpoints
    if case=='composition':
        assert result['phase']=='execution' and result['objectiveFeedback'] is None
        assert json.loads(result['goalDraftJson'])==ordinary
        assert any(state['objectiveFeedback']=='consider-available-primitives' for state in carried)
        assert any('last capability-gap diagnosis was not established' in text for text in instructions)
        assert consumers==[dict(kind='incomplete',missingCriteria=[diagnosis['id']])]
        assert len(model.inputs)==3
    else:
        assert isinstance(result,PartialReadControl) and result.state=='not-satisfied' and len(model.inputs)==2
        assert consumers[0]['diagnosis']==diagnosis and consumers[0]['answer']['evidence']==[]
        keys=SimpleNamespace(_key=lambda _:b'k'*32);store=SimpleNamespace(put_history=lambda:None,lookup_history=lambda:None)
        serialization=WorkflowSerializationContext('private-local',expected);key_id=str(uuid4())
        codec=AgentHistoryCodec(store,keys,deepcopy(context),'private-local',key_id=key_id,serialization_context=serialization)
        payload=converter.to_payloads([result])[0];codec._control(payload)
        assert diagnosis['code'].encode() not in payload.data and b'application record' not in payload.data
        wrong=deepcopy(context);wrong['harness']['revision']=1
        with pytest.raises(PrivateHistoryUnavailable):AgentHistoryCodec(store,keys,wrong,'private-local',key_id=key_id,serialization_context=serialization)._control(payload)
        assert asdict(converter.from_payloads([payload])[0])==asdict(result)


@pytest.mark.parametrize('failures,stopped,expired,patched,pauses,terminal',[
    (1,False,False,True,0,None),(2,False,False,True,1,None),
    (1,True,False,True,0,'stopped'),(1,False,True,True,0,'authorization-expired'),
    (1,False,False,False,1,None),
])
def test_objective_outcome_ack_observes_original_candidate_once_then_preserves_wait_stop_and_horizon(
        monkeypatch,failures,stopped,expired,patched,pauses,terminal):
    from temporalio.exceptions import ApplicationError
    from agentic_os_agent_worker.workflow_control import WorkflowControl,WAIT_TYPE
    value=sample('AgentSDKCapabilityReadJourneyStart');context=value['start']['context']
    context['harness'].update(ref='governed-read-discovery/'+'a'*64,revision=2)
    operation=str(uuid4());seen=[];waited=[]
    result=PartialReadControl(context['rootId'],context['taskId'],operation,'not-satisfied','d'*64,[str(uuid4())])
    # Exercise the real completion wrapper and typed error cause chain used by
    # the actual WorkflowBoundary, rather than replacing complete_goal.
    async def bind(c,ident):
        assert c==context and ident==operation;seen.append(ident)
        if len(seen)<=failures:
            raise ApplicationError('agent_wait',WorkflowControl(context['rootId'],context['taskId'],operation,
                'waiting-reconciliation',None),type=WAIT_TYPE,non_retryable=True)
        converter=AgentPayloadConverter()
        return converter.from_payloads(converter.to_payloads([result]))[0]
    class Driver:
        def _expired(self):return expired
        async def _pause(self,control):
            assert control.operationId==operation;waited.append(control)
    driver=Driver();driver.stopped=stopped
    def patch(name):
        assert name=='capability-goal-ack-observation/1';return patched
    monkeypatch.setattr(read_journey.workflow,'patched',patch)
    actual=asyncio.run(read_journey.complete_goal(driver,SimpleNamespace(bind_read_goal=bind),context,operation,
        analysis=False,objective=True))
    assert len(waited)==pauses and len(seen)==(1 if terminal else failures+1)
    assert actual.rootId==context['rootId'] and actual.taskId==context['taskId']
    if terminal:assert actual.status==terminal and actual.operationId is None
    else:assert actual==result
