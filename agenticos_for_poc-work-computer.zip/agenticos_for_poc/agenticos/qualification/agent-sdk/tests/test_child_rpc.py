"""Focused input staging retains its binding across credential renewal."""
import asyncio
from copy import deepcopy
import json
from uuid import UUID,uuid4,uuid5

import httpx
import pytest

from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from agentic_os_agent_worker.transport import TransportError
from test_private_state_rpc import fixture


@pytest.mark.parametrize('fault',[None,'page-slot','preparation-slot','legacy-profile'])
def test_goal_page_storage_wait_is_bound_to_its_original_task_and_exact_page_slot(fault):
    config,context,_,_,_=fixture();original=deepcopy(context);operation=str(uuid4())
    expected=str(uuid5(UUID(context['taskId']),'source-child-goal-page/1/2'))
    response=dict(kind='goal-page-storage',pageOrdinal=2,writeId=expected,
        preparation=dict(kind='failed',writeId=expected,reason='private-payload-not-created'))
    if fault=='page-slot':response['pageOrdinal']=3
    if fault=='preparation-slot':response['preparation']['writeId']=str(uuid4())
    async def token():
        context['rootId']=str(uuid4());return 'synthetic-private-worker'
    async def rpc(request):
        assert request.url.path.endswith('/child-source-state') and json.loads(request.content)['context']==original
        return httpx.Response(200,json=response)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            method=client.child_source_join_state if fault=='legacy-profile' else client.child_paged_source_join_state
            if fault:
                with pytest.raises((ModelRPCError,TransportError)):await method(context,operation)
            else:assert await method(context,operation)==response
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'bytes','root'])
def test_child_stage_freezes_the_request_and_checks_the_exact_private_result(fault):
    config,context,_,_,reference=fixture();original=deepcopy(context)
    binding=dict(context=deepcopy(context),sdkInstanceId=str(uuid4()),turn=1,planRevision=1,
        parentOperationId=str(uuid4()),inputResults=[]);expected=deepcopy(binding);raw='{"input":"Own focused selector"}'
    operation=uuid5(UUID(binding['sdkInstanceId']),'model-turn/1')
    reference.update(writeId=str(uuid5(operation,'provider-input/1')))
    reference['payload'].update(schemaRef='AgentProviderInput',bytes=len(raw.encode()))
    if fault=='bytes':reference['payload']['bytes']+=1
    if fault=='root':reference['rootId']=str(uuid4())
    async def token():
        context['subject']['subjectId']='changed-after-await';binding['turn']=2
        return 'synthetic-private-worker'
    async def rpc(request):
        value=json.loads(request.content)
        assert request.url.path.endswith('/child-stage') and value['context']==original and value['binding']==expected
        return httpx.Response(200,json=dict(kind='ready',reference=reference))
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.stage_child_model_input(context,binding,raw)
            else:assert (await client.stage_child_model_input(context,binding,raw))['reference']==reference
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'parent-owner','policy','width'])
def test_parallel_page_freezes_current_context_and_checks_policy_and_child_bindings(fault):
    from test_parallel_children import fixture as children_fixture
    config,context,_,_,_=fixture();original=deepcopy(context);_,page=children_fixture()
    page['context']=deepcopy(original)
    for item in page['items']:
        item['scope']['goal']['context']=deepcopy(original)
        item['scope']['parentResult'].update(**{key:deepcopy(original[key]) for key in ('subject','rootId','taskId')})
    if fault=='parent-owner':page['items'][0]['scope']['parentResult']['subject']['subjectId']='foreign-owner'
    elif fault=='policy':page['items'][0]['scope']['policy']['digest']='b'*64
    elif fault=='width':page['maxActiveChildren']=0
    async def token():
        context['rootId']=str(uuid4());return 'synthetic-private-worker'
    async def rpc(request):
        assert request.url.path.endswith('/child-parallel-page') and json.loads(request.content)['context']==original
        return httpx.Response(200,json=page)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises((ModelRPCError,TransportError)):await client.child_parallel_page(context)
            else:assert (await client.child_parallel_page(context))['maxActiveChildren']==2
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'context','source-owner','premature-goal','partial-goal'])
@pytest.mark.parametrize('reduction',[False,True])
def test_source_state_freezes_context_and_rejects_foreign_or_unverified_targets(fault,reduction):
    from test_parallel_children import fixture as children_fixture
    config,context,_,_,_=fixture();original=deepcopy(context);_,page=children_fixture()
    source=deepcopy(page['items'][0]);source['scope']['goal']['context']=deepcopy(original)
    source['scope']['parentResult'].update(**{key:deepcopy(original[key]) for key in ('subject','rootId','taskId')})
    state=dict(kind='ready',context=deepcopy(original),source=source,targetCount=None,goalDigest=None)
    if fault=='context':state['context']['rootId']=str(uuid4())
    elif fault=='source-owner':source['scope']['parentResult']['subject']['subjectId']='foreign-owner'
    elif fault=='premature-goal':state.update(targetCount=1,goalDigest='a'*64)
    elif fault=='partial-goal':state['targetCount']=1
    async def token():
        context['rootId']=str(uuid4());return 'synthetic-private-worker'
    async def rpc(request):
        assert request.url.path.endswith('/child-source-state') and json.loads(request.content)['context']==original
        return httpx.Response(200,json=state)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        state_call=client.child_source_reduction_state if reduction else client.child_source_state
        try:
            if fault:
                with pytest.raises((ModelRPCError,TransportError)):await state_call(context,str(uuid4()))
            else:assert (await state_call(context,str(uuid4())))['targetCount'] is None
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('reduction',[False,True])
@pytest.mark.parametrize('fault',[None,'other-schema','owner','write'])
def test_source_goal_storage_keeps_profile_owner_and_original_write_binding(reduction,fault):
    config,context,_,_,reference=fixture()
    expected=str(uuid5(UUID(context['taskId']),'source-child-goal/1'))
    reference['writeId']=expected
    reference['payload'].update(schemaRef='AgentSourceChildReductionGoalRecord' if reduction else 'AgentSourceChildGoalRecord',schemaVersion=1)
    if fault=='other-schema':reference['payload']['schemaRef']='AgentSourceChildGoalRecord' if reduction else 'AgentSourceChildReductionGoalRecord'
    elif fault=='owner':reference['subject']['subjectId']='foreign-owner'
    elif fault=='write':reference['writeId']=str(uuid4())
    async def token():return 'synthetic-private-worker'
    async def rpc(request):return httpx.Response(200,json=dict(kind='storage',writeId=expected,preparation=dict(kind='ready',reference=reference)))
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        call=client.child_source_reduction_state if reduction else client.child_source_state
        try:
            if fault:
                with pytest.raises((ModelRPCError,TransportError)):await call(context,str(uuid4()))
            else:assert (await call(context,str(uuid4())))['preparation']['reference']==reference
        finally:await client.close()
    asyncio.run(run())
