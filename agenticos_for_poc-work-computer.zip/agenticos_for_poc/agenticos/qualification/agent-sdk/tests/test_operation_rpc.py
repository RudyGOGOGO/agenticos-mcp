"""Independent staged-operation client; synthetic replies, no kernel import."""
import asyncio
from copy import deepcopy
from datetime import datetime,timezone
import json
from uuid import UUID,uuid5

import httpx
import pytest

from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from provider_transport_fixture import fixture,ident


def operation_fixture():
    config,request,body,response=fixture('openai');operation_id=ident(31);context=request['context'];raw=json.dumps(body)
    request=deepcopy(request);step_id=str(uuid5(UUID(operation_id),'model-attempt/1'))
    request['step']['stepId']=request['grant']['stepId']=step_id
    payload=dict(artifactRef='artifact/'+ident(32),ciphertextDigest='c'*64,bytes=len(raw.encode()),schemaRef='AgentProviderInput',schemaVersion=1)
    request['input']=request['grant']['input']=payload
    identity={k:context[k] for k in ('taskId','rootId','segmentId','intentRevision','controlEpoch')}
    identity.update(operationId=operation_id,planRevision=1,parentOperationId=None,iteration=0,kind='model',inputDigest=request['step']['inputDigest'])
    record=dict(context=context,identity=identity,input=payload,inputResults=[])
    stage=dict(kind='ready',reference=dict(subject=context['subject'],rootId=context['rootId'],taskId=context['taskId'],
        writeId=str(uuid5(UUID(operation_id),'provider-input/1')),payload=payload,
        createdAt=datetime.now(timezone.utc).isoformat(),expiresAt=context['authorizationHorizon']))
    ready=dict(preparation=dict(kind='ready',operationId=operation_id,attemptNumber=1,request=request),accepted=None)
    return config,record,raw,stage,ready


def test_independent_worker_stages_and_prepares_with_pinned_transport_and_no_secret_in_body():
    config,record,raw,stage,ready=operation_fixture();calls=[]
    async def token():return 'synthetic-workload-token'
    async def rpc(request):
        value=json.loads(request.content);action=request.url.path.rsplit('/',1)[1];calls.append(action)
        assert value['transport']['modelDigest']==config.model_profile_digest
        assert 'synthetic-workload-token' not in request.content.decode()
        if action=='stage':
            assert value['operationId']==record['identity']['operationId'] and value['inputJson']==raw
            return httpx.Response(200,json=stage)
        assert action=='prepare-operation' and value['record']==record
        return httpx.Response(200,json=ready)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            assert await client.stage_model_input(record['context'],record['identity']['operationId'],raw)==stage
            assert await client.prepare_model_operation(record,max_output_tokens=64,request_timeout_ms=10000)==ready
        finally:await client.close()
    asyncio.run(run());assert calls==['stage','prepare-operation']


@pytest.mark.parametrize('action',['stage','prepare-operation'])
def test_operation_binding_is_frozen_before_workload_token_renewal(action):
    config,record,raw,stage,ready=operation_fixture();original=deepcopy(record);calls=[]
    stage,ready=deepcopy(stage),deepcopy(ready)
    async def token():
        # Renewal can yield control to a caller which still owns its input.
        await asyncio.sleep(0)
        record['context']['subject']['subjectId']='changed-after-call'
        record['identity']['operationId']=ident(77)
        return 'synthetic-workload-token'
    async def rpc(request):
        value=json.loads(request.content);calls.append(value)
        assert (value['context'] if action=='stage' else value['record']['context'])==original['context']
        if action=='prepare-operation':assert value['record']==original
        return httpx.Response(200,json=stage if action=='stage' else ready)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if action=='stage':assert await client.stage_model_input(record['context'],record['identity']['operationId'],raw)==stage
            else:assert await client.prepare_model_operation(record,max_output_tokens=64,request_timeout_ms=10000)==ready
        finally:await client.close()
    asyncio.run(run());assert len(calls)==1 and record!=original


@pytest.mark.parametrize('fault',['stage-owner','stage-write','prepared-step','prepared-input'])
def test_cross_context_or_wrong_operation_reply_is_refused_before_execution(fault):
    config,record,raw,stage,ready=operation_fixture();calls=[]
    if fault=='stage-owner':stage['reference']['subject']=stage['reference']['subject']|dict(subjectId='foreign-owner')
    elif fault=='stage-write':stage['reference']['writeId']=ident(44)
    elif fault=='prepared-step':ready['preparation']['request']['step']['stepId']=ident(45)
    else:ready['preparation']['request']['input']=ready['preparation']['request']['input']|dict(artifactRef='foreign-artifact')
    async def token():return 'synthetic-workload-token'
    async def rpc(request):calls.append(1);return httpx.Response(200,json=stage if fault.startswith('stage') else ready)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            with pytest.raises(ModelRPCError):
                if fault.startswith('stage'):await client.stage_model_input(record['context'],record['identity']['operationId'],raw)
                else:await client.prepare_model_operation(record,max_output_tokens=64,request_timeout_ms=10000)
        finally:await client.close()
    asyncio.run(run());assert calls==[1]


@pytest.mark.parametrize('foreign_root',[False,True])
def test_accepted_operation_reply_preserves_reference_binding_without_reexecution(foreign_root):
    config,record,raw,stage,ready=operation_fixture();request=ready['preparation']['request'];context=record['context']
    reference=dict(subject=context['subject'],taskId=context['taskId'],rootId=context['rootId'],resultId=ident(51),
        producerStepId=request['step']['stepId'],acceptedAttemptId=request['grant']['attemptId'],
        payload=dict(artifactRef='artifact/'+ident(52),ciphertextDigest='d'*64,bytes=2,schemaRef='AgentProviderResponse',schemaVersion=1),
        lineageRef=None,scopeRef=context['scopeRef'],acceptedAt=datetime.now(timezone.utc).isoformat())
    if foreign_root:reference['rootId']=ident(53)
    reply=dict(preparation=dict(kind='accepted',operationId=record['identity']['operationId'],attemptNumber=1,result=reference),
        accepted=dict(result=reference,contentJson='{}'));calls=[]
    async def token():return 'synthetic-workload-token'
    async def rpc(request):calls.append(request.url.path);return httpx.Response(200,json=reply)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if foreign_root:
                with pytest.raises(ModelRPCError):await client.prepare_model_operation(record,max_output_tokens=64,request_timeout_ms=10000)
            else:assert await client.prepare_model_operation(record,max_output_tokens=64,request_timeout_ms=10000)==reply
        finally:await client.close()
    asyncio.run(run());assert calls==['/private/agent/model/prepare-operation']
