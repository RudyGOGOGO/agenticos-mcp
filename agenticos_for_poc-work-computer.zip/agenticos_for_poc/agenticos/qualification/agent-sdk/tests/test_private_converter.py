"""Verify the real integration preserves the existing history encryption boundary."""
import asyncio
from uuid import uuid4

from temporalio.converter import DataConverter, WorkflowSerializationContext
from temporalio.contrib.openai_agents import OpenAIAgentsPlugin
from agentic_os.adapters.local.artifacts import LocalKeys
from agentic_os.adapters.temporal.privacy import HistoryCodec, SafeFailureConverter, ENCODING


def test_plugin_preserves_context_bound_codec_and_safe_failures(proof_root):
    async def scenario():
        directory = proof_root / ("keys-" + uuid4().hex)
        directory.mkdir(mode=0o700)
        keys = LocalKeys(directory)
        keys.rotate()
        installation = str(uuid4())
        workflow_id = f"os:{installation}:{uuid4()}:{uuid4()}"
        codec = HistoryCodec(keys, "sdk-proof", installation)
        original = DataConverter(payload_codec=codec, failure_converter_class=SafeFailureConverter)
        plugin = OpenAIAgentsPlugin(add_temporal_spans=False)
        # SimplePlugin's documented client hook supplies the real SDK payload converter.
        applied = plugin.configure_client({"data_converter": original})["data_converter"]
        assert applied.payload_codec is codec
        assert applied.failure_converter_class is SafeFailureConverter
        bound = applied.with_context(WorkflowSerializationContext("sdk-proof", workflow_id))
        payloads = await bound.encode([{"private": "synthetic-private-marker"}])
        assert payloads[0].metadata["encoding"] == ENCODING
        assert b"synthetic-private-marker" not in payloads[0].data
        assert await bound.decode(payloads) == [{"private": "synthetic-private-marker"}]
        import pytest
        wrong = applied.with_context(WorkflowSerializationContext("sdk-proof", f"os:{installation}:{uuid4()}:{uuid4()}"))
        with pytest.raises(ValueError):
            await wrong.decode(payloads)
    asyncio.run(scenario())
