"""Actual Temporal converter/crypto; the private storage port is synthetic here."""
import asyncio
from copy import deepcopy
from datetime import datetime,timezone
import json
import os
from uuid import UUID,uuid4,uuid5
import pytest
from temporalio.converter import DataConverter,WorkflowSerializationContext
from temporalio.api.common.v1 import Payload
from agentic_os_agent_worker.model_rpc import ModelRPCError
from agentic_os_agent_worker.private_history import (
    AgentHistoryCodec,PrivateHistoryUnavailable,PrivateHistoryDeferred,ENCODING,
    COMPRESSED_ENCODING,MAX_RAW_PAYLOAD,
)
from test_sdk_model import binding_fixture


class Keys:
    def __init__(self):self.id=str(uuid4());self.key=os.urandom(32)
    def active(self):return self.id
    def _key(self,key):
        if key!=self.id:raise ValueError('Unavailable test history key')
        return self.key


class Store:
    def __init__(self,context,*,fault=None):self.context=deepcopy(context);self.values={};self.writes=[];self.fault=fault
    async def lookup_history(self,context,write_id,namespace,workflow_id):
        assert context==self.context
        return deepcopy(self.values.get(write_id,dict(kind='missing',writeId=write_id)))
    async def put_history(self,context,write_id,envelope):
        assert context==self.context;self.writes.append(write_id)
        if write_id in self.values:raise ModelRPCError('CONFLICT')
        if self.fault=='unknown':
            handle=dict(subject=context['subject'],id=str(uuid4()),taskId=context['taskId'],segmentId=context['segmentId'],rootId=context['rootId'],
                controlEpoch=context['controlEpoch'],leaseToken=str(uuid4()),leaseUntil=context['authorizationHorizon'],state='UNKNOWN')
            preparation=dict(kind='reconciliation',writeId=write_id,attempt=handle,reason='private-payload-write-uncertain')
            self.values[write_id]=dict(kind='storage',preparation=preparation);return preparation
        payload=dict(artifactRef='artifact/'+str(uuid5(UUID(write_id),'artifact')),ciphertextDigest='a'*64,
            bytes=len(json.dumps(envelope).encode()),schemaRef='AgentTemporalHistoryEnvelope',schemaVersion=1)
        reference=dict(subject=deepcopy(context['subject']),taskId=context['taskId'],rootId=context['rootId'],writeId=write_id,payload=payload,
            createdAt=datetime.now(timezone.utc).isoformat(),expiresAt=context['authorizationHorizon'])
        self.values[write_id]=dict(kind='ready',reference=reference,envelope=deepcopy(envelope))
        if self.fault=='lost-ack':raise ModelRPCError('UNAVAILABLE')
        return dict(kind='ready',reference=reference)


class CreateStore(Store):
    """Synthetic versioned Core exchange; count actual worker port calls."""
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.creates=[];self.lookups=[]
    async def lookup_history(self,*args):self.lookups.append(1);return await super().lookup_history(*args)
    async def store_history(self,context,write_id,envelope,*,observe=False):
        self.creates.append(dict(writeId=write_id,observe=observe))
        original=await Store.lookup_history(self,context,write_id,envelope['namespace'],envelope['workflowId'])
        if original['kind']!='missing':return original
        prepared=await self.put_history(context,write_id,envelope)
        return dict(kind='ready',reference=prepared['reference'],envelope=deepcopy(envelope)) if prepared['kind']=='ready' else dict(kind='storage',preparation=prepared)


@pytest.mark.parametrize('versioned',[False,True])
def test_checkpoint_reload_exposes_the_duplicate_history_storage_dependency(versioned,monkeypatch):
    from temporalio.converter import ActivitySerializationContext
    from temporalio import activity
    from agentic_os_agent_worker import temporal_driver
    from agentic_os_agent_worker.temporal_driver import AgentActivities,WorkflowBoundary
    from agentic_os_agent_worker.temporal_runtime import agent_converter
    from agentic_os_agent_worker.workflow_control import WAIT_TYPE
    from temporalio.exceptions import ApplicationError
    from test_checkpoint import paused
    async def run():
        item=await paused()
        try:
            context=item['binding']['context'];checkpoint=str(uuid4());keys=Keys()
            store=(CreateStore if versioned else Store)(context)
            workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
            converter=agent_converter(store,keys,context,'default',keys.active())
            original=converter.with_context(WorkflowSerializationContext('default',workflow_id))
            replacement=converter.with_context(ActivitySerializationContext('default','5','agent.checkpoint-get/2',
                'owned-checkpoint',workflow_id,'OSAgentTaskDriver/1',False))
            # The actual Core canonical persistence changes dictionary order,
            # while preserving complete opaque SDK state and source bindings.
            persisted=None;reads=[];saved_frames=[]
            from test_parallel_children import sample
            native_state=sample('AgentNativeSourceState');native_state['context']=deepcopy(context)
            if 'context' in native_state['goal']:native_state['goal']['context']=deepcopy(context)
            native_state=json.loads(json.dumps(native_state,sort_keys=True,separators=(',',':')))
            native_calls=[];native_frames=[]
            class Boundary:
                async def put_checkpoint(self,ident,value):
                    nonlocal persisted
                    assert ident==checkpoint and value==item['saved']
                    persisted=json.loads(json.dumps(value,sort_keys=True,separators=(',',':')))
                    return dict(kind='ready')
                async def get_checkpoint(self,c,ident):
                    assert c==context and ident==checkpoint;reads.append((c,ident))
                    return deepcopy(persisted)
                async def native_source_state(self,c,operation):
                    assert c==context;native_calls.append(operation)
                    return deepcopy(native_state)
            activities=AgentActivities(Boundary())
            registered={activity._Definition.must_from_callable(method).name:method for method in activities.registered()}
            async def execute(name,value,**options):
                assert options['retry_policy'].maximum_attempts==1
                frames=await original.encode([value]);command=(await replacement.decode(frames))[0]
                if name=='agent.checkpoint-put/1':saved_frames.append(frames)
                else:assert name in {'agent.checkpoint-get/2','agent.native-source-state/1'}
                result=await registered[name](command)
                encoded=await replacement.encode([result])
                if name=='agent.checkpoint-get/2':assert encoded==saved_frames[0]
                if name=='agent.native-source-state/1':
                    if native_frames:assert encoded==native_frames[0]
                    else:native_frames.append(encoded)
                return (await original.decode(encoded))[0]
            monkeypatch.setattr(temporal_driver.workflow,'execute_activity',execute)
            monkeypatch.setattr(temporal_driver.workflow,'patched',lambda _:True)
            boundary=WorkflowBoundary(30000)
            assert await boundary.put_checkpoint(checkpoint,item['saved'])==dict(kind='ready')
            # Source inspection before the program proposal uses its previous
            # model operation. Re-entry after a granted native-result wait uses
            # the accepted program model instead; this is a new input frame.
            initial_operation=str(uuid4());pending_operation=str(uuid4())
            assert await boundary.native_source_state(context,initial_operation)==native_state
            before=deepcopy(store.values);writes=len(store.writes)
            async def full(*args):raise ModelRPCError('CAPACITY')
            store.put_history=full
            # Reproduce the old bare-state result's unneeded allocation first.
            old=await activities.load(dict(context=context,checkpointId=checkpoint))
            with pytest.raises(ApplicationError) as caught:await replacement.encode([old])
            assert caught.value.type==WAIT_TYPE and caught.value.details[0].status=='waiting-resources'
            assert caught.value.details[0].operationId not in store.values
            # Complete actual save producer -> Core wire -> load producer ->
            # codecs -> versioned consumer, with all new allocations refused.
            assert await boundary.get_checkpoint(context,checkpoint)==item['saved']
            with pytest.raises(ApplicationError):
                await original.encode([dict(context=context,operationId=pending_operation)])
            monkeypatch.setattr(temporal_driver.workflow,'patched',
                lambda name:name!='native-source-state-opaque-command/1')
            with pytest.raises(ApplicationError):await boundary.native_source_state(context,pending_operation)
            monkeypatch.setattr(temporal_driver.workflow,'patched',lambda _:True)
            # Reuse the ordinary authenticated metadata path for that new
            # command. The unchanged current-state result already has a private
            # claim check. No new write may precede the original pending write.
            current=await boundary.native_source_state(context,pending_operation)
            from agentic_os_agent_worker.transport import _validate
            _validate('AgentNativeSourceState',current)
            assert current==native_state and native_calls==[initial_operation,pending_operation]
            assert len(reads)==2 and store.values==before and len(store.writes)==writes
            assert len(item['issued'])==1 and not item['executed']
            assert b'private checkpoint marker' not in saved_frames[0][0].SerializeToString()
        finally:
            await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'lost-ack','unknown'])
@pytest.mark.parametrize('large',[False,True])
def test_versioned_history_create_observe_uses_one_exchange_and_original_ciphertext(fault,large):
    from agentic_os_agent_worker.temporal_runtime import ObservedHistoryBoundary
    _,_,keys,context,workflow_id=fixture();store=CreateStore(context,fault=fault)
    codec=AgentHistoryCodec(ObservedHistoryBoundary(store),keys,context,'default',key_id=keys.active())
    converter=DataConverter(payload_codec=codec).with_context(WorkflowSerializationContext('default',workflow_id))
    private=dict(private='VERSIONED_PRIVATE_CANARY'*(5000 if large else 1))
    async def run():
        if fault is not None:
            with pytest.raises(PrivateHistoryDeferred if fault=='unknown' else PrivateHistoryUnavailable):await converter.encode([private])
        original=deepcopy(store.values)
        if fault=='unknown':
            with pytest.raises(PrivateHistoryDeferred):await converter.encode([private])
        else:
            first=await converter.encode([private]);second=await converter.encode([private])
            assert first==second and len(store.lookups)==0
            # Decode remains the current governed observation, never a cache.
            async def observed(*args):return await store.lookup_history(*args)
            store.observe_history=observed
            assert await converter.decode(first)==[private] and len(store.lookups)==1
            assert b'VERSIONED_PRIVATE_CANARY' not in first[0].SerializeToString()
        if original:assert store.values==original
    asyncio.run(run())
    assert len(store.writes)==1 and all(x['observe'] for x in store.creates)
    assert len({x['writeId'] for x in store.creates})==1


def fixture(fault=None):
    _,_,binding=binding_fixture();context=binding['context'];store=Store(context,fault=fault);keys=Keys()
    workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    converter=DataConverter(payload_codec=AgentHistoryCodec(store,keys,context,'default',key_id=keys.active())).with_context(WorkflowSerializationContext('default',workflow_id))
    return converter,store,keys,context,workflow_id


def protocol_fixture():
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    original,store,keys,context,workflow_id=fixture()
    return DataConverter(payload_converter_class=AgentPayloadConverter,
        payload_codec=original.payload_codec),store,keys,context,workflow_id


def model_reference(context):
    return dict(**{k:deepcopy(context[k]) for k in ('subject','rootId','taskId')},
        resultId=str(uuid4()),producerStepId=str(uuid4()),acceptedAttemptId=str(uuid4()),
        payload=dict(artifactRef='artifact/'+str(uuid4()),ciphertextDigest='a'*64,
            bytes=512,schemaRef='AgentProviderResponse',schemaVersion=1),
        lineageRef=None,scopeRef=context['scopeRef'],acceptedAt=datetime.now(timezone.utc).isoformat())


def test_authenticated_protocol_metadata_reuses_no_private_history_or_source_walk():
    from agentic_os_agent_worker.protocol_metadata import ProtocolMetadata,ProtocolCommand,command,ENCODING as metadata_encoding
    converter,store,_,context,_=protocol_fixture();lookups=[]
    async def forbidden(*args):lookups.append(1);raise AssertionError('Metadata contains no source bytes')
    store.lookup_history=forbidden
    operation=dict(context=context,operationId=str(uuid4()));checkpoint=dict(context=context,checkpointId=str(uuid4()))
    reference=model_reference(context)
    async def run():
        encoded=await converter.encode([command('operation',operation),command('checkpoint',checkpoint),ProtocolMetadata('model-result',reference)])
        assert all(p.metadata['encoding']==metadata_encoding for p in encoded)
        raw=b''.join(p.SerializeToString() for p in encoded)
        for private in (context['subject']['applicationId'],context['scopeRef'],context['harness']['ref'],context['model']['ref']):
            assert private.encode() not in raw
        decoded=await converter.decode(encoded,[dict,dict,dict])
        assert decoded==[operation,checkpoint,reference] and isinstance(decoded[0],ProtocolCommand)
        assert isinstance(decoded[1],ProtocolCommand) and type(decoded[2]) is dict
        assert await converter.encode([command('operation',operation)])==encoded[:1]
    asyncio.run(run());assert not store.writes and not lookups


@pytest.mark.parametrize('fault',['signature','key','workflow','namespace','epoch','model','subject','extra-header','unsigned'])
def test_protocol_metadata_authentication_rejects_cross_binding_and_unsigned_frames(fault):
    from agentic_os_agent_worker.protocol_metadata import command,INPUT_ENCODING
    converter,store,keys,context,workflow_id=protocol_fixture()
    async def run():
        encoded=await converter.encode([command('operation',dict(context=context,operationId=str(uuid4())))])
        selected=converter
        if fault=='signature':
            value=json.loads(encoded[0].data);value['value']['value']['operationId']=str(uuid4());encoded[0].data=json.dumps(value).encode()
        elif fault=='key':keys.key=os.urandom(32)
        elif fault=='workflow':selected=converter.with_context(WorkflowSerializationContext('default',workflow_id+'x'))
        elif fault=='namespace':selected=converter.with_context(WorkflowSerializationContext('other',workflow_id))
        elif fault=='extra-header':encoded[0].metadata['untrusted']=b'1'
        elif fault=='unsigned':encoded[0]=converter.payload_converter.to_payloads([command('operation',dict(context=context,operationId=str(uuid4())))])[0];assert encoded[0].metadata['encoding']==INPUT_ENCODING
        else:
            other=deepcopy(context)
            if fault=='epoch':other['controlEpoch']+=1
            elif fault=='model':other['model']['digest']='b'*64
            else:other['subject']['applicationId']=str(uuid4())
            codec=AgentHistoryCodec(store,keys,other,'default',key_id=keys.active())
            from dataclasses import replace
            selected=replace(converter,payload_codec=codec).with_context(WorkflowSerializationContext('default',workflow_id))
        with pytest.raises(PrivateHistoryUnavailable):await selected.decode(encoded)
    asyncio.run(run());assert not store.writes


def test_protocol_metadata_keeps_user_dicts_child_context_and_legacy_history_private():
    from agentic_os_agent_worker.protocol_metadata import command,ProtocolCommand,ProtocolMetadata,ENCODING as metadata_encoding
    converter,store,_,context,_=protocol_fixture();child=deepcopy(context);child['scopeRef']='private-child-scope-canary'
    operation=dict(context=context,operationId=str(uuid4()))
    child_operation=dict(context=child,operationId=str(uuid4()))
    large=dict(private='COMPRESSED_PROTOCOL_CANARY'*4000)
    async def run():
        encoded=await converter.encode([operation,command('operation',child_operation),large,command('operation',operation)])
        assert [p.metadata['encoding'] for p in encoded]==[ENCODING,ENCODING,COMPRESSED_ENCODING,metadata_encoding]
        decoded=await converter.decode(encoded)
        assert decoded==[operation,child_operation,large,operation]
        assert type(decoded[0]) is dict and type(decoded[1]) is dict and isinstance(decoded[3],ProtocolCommand)
        for secret in (child['scopeRef'],'COMPRESSED_PROTOCOL_CANARY'):
            assert secret.encode() not in b''.join(p.SerializeToString() for p in encoded)
        malformed=ProtocolMetadata('operation',dict(operation,private='DO_NOT_LEAK'))
        with pytest.raises(PrivateHistoryUnavailable):await converter.encode([malformed])
        bad=model_reference(context);bad['payload']['schemaRef']='PrivateUnapprovedSchema'
        with pytest.raises(PrivateHistoryUnavailable):await converter.encode([ProtocolMetadata('model-result',bad)])
    asyncio.run(run());assert len(store.writes)==3


@pytest.mark.parametrize('patched',[False,True])
def test_actual_protocol_command_and_accepted_reference_cross_serialized_activity_router(monkeypatch,patched):
    from temporalio import activity
    from agentic_os_agent_worker import temporal_driver
    from agentic_os_agent_worker.protocol_metadata import ENCODING as metadata_encoding
    converter,store,_,context,_=protocol_fixture();operation=str(uuid4());reference=model_reference(context);seen=[];encodings=[]
    class Boundary:
        async def accepted_model_operation(self,c,op):seen.append((c,op));return reference
    activities=temporal_driver.AgentActivities(Boundary())
    registered={activity._Definition.must_from_callable(method).name:method for method in activities.registered()}
    async def execute(name,value,**options):
        encoded=await converter.encode([value]);encodings.append(encoded[0].metadata['encoding'])
        decoded=(await converter.decode(encoded,[dict]))[0]
        result=await registered[name](decoded)
        encoded=await converter.encode([result]);encodings.append(encoded[0].metadata['encoding'])
        return (await converter.decode(encoded,[dict]))[0]
    monkeypatch.setattr(temporal_driver.workflow,'patched',lambda marker:patched)
    monkeypatch.setattr(temporal_driver.workflow,'execute_activity',execute)
    async def run():
        assert await temporal_driver.WorkflowBoundary(30000).accepted_model_operation(context,operation)==reference
    asyncio.run(run());assert seen==[(context,operation)]
    assert encodings==[metadata_encoding if patched else ENCODING]*2
    assert len(store.writes)==(0 if patched else 2)


def test_converter_uses_opaque_claim_checks_and_reuses_original_encryption_without_another_write():
    converter,store,_,_,_=fixture();private=dict(private='SDK_PRIVATE_MARKER',decimal=0.5)
    async def run():
        first=await converter.encode([private]);assert first[0].metadata['encoding']==ENCODING
        assert b'SDK_PRIVATE_MARKER' not in first[0].SerializeToString()
        assert await converter.decode(first)==[private]
        assert await converter.encode([private])==first
    asyncio.run(run());assert len(store.writes)==1
    assert 'SDK_PRIVATE_MARKER' not in json.dumps(store.values)


@pytest.mark.parametrize('large',[False,True])
def test_lost_store_ack_is_observed_before_any_new_encryption_or_write(large):
    converter,store,_,_,_=fixture('lost-ack')
    private=dict(private='KNOWN_PRIVATE_VALUE'*(5000 if large else 1))
    async def run():
        with pytest.raises(PrivateHistoryUnavailable):await converter.encode([private])
        recovered=await converter.encode([private])
        assert await converter.decode(recovered)==[private]
    asyncio.run(run());assert len(store.writes)==1


@pytest.mark.parametrize('large',[False,True])
def test_unknown_original_storage_never_gets_another_write_identity_or_overwrite(large):
    converter,store,_,_,_=fixture('unknown')
    async def run():
        for _ in range(2):
            with pytest.raises(PrivateHistoryDeferred) as caught:await converter.encode([dict(private='HELD_PRIVATE_VALUE'*(5000 if large else 1))])
            assert caught.value.preparation['kind']=='reconciliation'
            assert 'HELD_PRIVATE_VALUE' not in str(caught.value)
    asyncio.run(run());assert len(store.writes)==1


@pytest.mark.parametrize('versioned',[False,True])
@pytest.mark.parametrize('large',[False,True])
def test_resource_wait_identifies_the_exact_pending_encrypted_write(versioned,large,tmp_path,monkeypatch):
    from temporalio.exceptions import ApplicationError
    from agentic_os_agent_worker.model_rpc import ResourceGroupDeferred
    from agentic_os_agent_worker.temporal_runtime import AgentTemporalCodec
    from agentic_os_agent_worker.workflow_control import WorkflowControl,WAIT_TYPE
    from test_resource_group_rpc import outcome
    # Include the installed journey's actual observer in this producer/codec/
    # failure/consumer replay. Expected capacity must not abort the browser;
    # an unbound capacity error and permanent failures must remain diagnostic.
    import ast
    from pathlib import Path
    from agentic_os_agent_worker.private_history import MAX_PAYLOAD
    tree=ast.parse((Path(__file__).parents[3]/'tests/integration/resources/assigned_read_probe.py').read_text())
    observer=next(node for node in ast.walk(tree)if isinstance(node,ast.AsyncFunctionDef)and node.name=='diagnosed_history_encode')
    failure_path=tmp_path/'worker-failure.json'
    scope=dict(encode_history=AgentHistoryCodec.encode,PrivateHistoryUnavailable=PrivateHistoryUnavailable,
        MAX_PAYLOAD=MAX_PAYLOAD,Path=Path,json=json,value=dict(workerFailure=str(failure_path)))
    exec(compile(ast.Module(body=[observer],type_ignores=[]),'actual-history-observer','exec'),scope)
    monkeypatch.setattr(AgentHistoryCodec,'encode',scope['diagnosed_history_encode'])
    _,store,keys,context,workflow_id=fixture()
    if versioned:store=CreateStore(context)
    put=store.put_history;blocked=True
    async def pending(c,write_id,envelope):
        if blocked:
            store.writes.append(write_id);raise ResourceGroupDeferred(outcome(c))
        return await put(c,write_id,envelope)
    store.put_history=pending
    converter=DataConverter(payload_codec=AgentTemporalCodec(store,keys,context,'default',key_id=keys.active()))
    converter=converter.with_context(WorkflowSerializationContext('default',workflow_id))
    private=dict(private='QUEUED_PRIVATE_HISTORY_CANARY'*(5000 if large else 1),nextStep='original pending work')
    async def run():
        nonlocal blocked
        with pytest.raises(ApplicationError) as caught:await converter.encode([private])
        assert caught.value.type==WAIT_TYPE and len(caught.value.details)==1
        control=caught.value.details[0];assert isinstance(control,WorkflowControl)
        assert not failure_path.exists()
        assert control.status=='waiting-resources' and control.operationId==store.writes[0]
        assert control.rootId==context['rootId'] and control.taskId==context['taskId']
        assert 'QUEUED_PRIVATE_HISTORY_CANARY' not in str(caught.value) and not store.values
        from temporalio.api.failure.v1 import Failure
        from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,ReadFailureConverter
        from agentic_os_agent_worker.temporal_driver import _wait
        failure=Failure();failures=ReadFailureConverter();payloads=AgentPayloadConverter()
        failures.to_failure(caught.value,payloads,failure)
        restored=_wait(failures.from_failure(failure,payloads))
        assert restored==control and b'QUEUED_PRIVATE_HISTORY_CANARY' not in failure.SerializeToString()
        blocked=False
        replacement=DataConverter(payload_codec=AgentTemporalCodec(store,keys,context,'default',key_id=keys.active()))
        replacement=replacement.with_context(WorkflowSerializationContext('default',workflow_id))
        encoded=await replacement.encode([private]);assert await replacement.decode(encoded)==[private]
        assert len(store.values)==1 and store.writes==[control.operationId,control.operationId]
        assert b'QUEUED_PRIVATE_HISTORY_CANARY' not in encoded[0].SerializeToString()
        for code in ('CAPACITY','DENIED','UNAVAILABLE'):
            async def refused(*args):raise PrivateHistoryUnavailable(code)
            scope['encode_history']=refused
            with pytest.raises(PrivateHistoryUnavailable):await scope['diagnosed_history_encode'](None,[Payload(data=b'PRIVATE_CANARY')])
            diagnostic=json.loads(failure_path.read_bytes())
            assert diagnostic['code']==code and diagnostic['action']=='private-history-encode'
            assert b'PRIVATE_CANARY' not in failure_path.read_bytes()
            failure_path.unlink()
    asyncio.run(run())


@pytest.mark.parametrize('fault',['workflow','namespace','ticket','ciphertext','key'])
def test_wrong_workflow_or_changed_stored_content_is_refused(fault):
    converter,store,keys,context,workflow_id=fixture()
    async def run():
        encoded=await converter.encode([dict(private='BOUND_PRIVATE_VALUE')])
        selected=converter
        if fault=='workflow':selected=DataConverter(payload_codec=AgentHistoryCodec(store,keys,context,'default',key_id=keys.active())).with_context(WorkflowSerializationContext('default',workflow_id[:-1]+('1' if workflow_id[-1]!='1' else '2')))
        elif fault=='namespace':selected=DataConverter(payload_codec=AgentHistoryCodec(store,keys,context,'default',key_id=keys.active())).with_context(WorkflowSerializationContext('other',workflow_id))
        elif fault=='ticket':
            ticket=json.loads(encoded[0].data);ticket['payload']['ciphertextDigest']='0'*64;encoded[0].data=json.dumps(ticket).encode()
        elif fault=='ciphertext':
            value=next(iter(store.values.values()));cipher=value['envelope']['ciphertextBase64'];value['envelope']['ciphertextBase64']=('A' if cipher[0]!='A' else 'B')+cipher[1:]
        else:keys.key=os.urandom(32)
        with pytest.raises(PrivateHistoryUnavailable):await selected.decode(encoded)
    asyncio.run(run());assert len(store.writes)==1


def test_payload_and_batch_limits_are_checked_before_storage():
    converter,store,_,_,_=fixture()
    async def run():
        with pytest.raises(PrivateHistoryUnavailable):await converter.encode(['x'*MAX_RAW_PAYLOAD])
        with pytest.raises(PrivateHistoryUnavailable):await converter.encode([os.urandom(80000)])
        with pytest.raises(PrivateHistoryUnavailable):await converter.encode([0]*65)
    asyncio.run(run());assert store.writes==[]


def test_large_private_checkpoint_and_legacy_history_share_existing_bounded_store():
    from agentic_os.contracts.validation import validate_contract
    converter,store,_,_,_=fixture();small=dict(private='LEGACY_PRIVATE_MARKER')
    large=dict(stateJson=json.dumps(dict(input='PRIVATE_CHECKPOINT_MARKER'*4000,next='original next-page approval')))
    async def run():
        encoded=await converter.encode([small,large])
        assert [payload.metadata['encoding'] for payload in encoded]==[ENCODING,COMPRESSED_ENCODING]
        assert all(len(payload.SerializeToString())<16384 for payload in encoded)
        assert await converter.decode(encoded)==[small,large]
        assert await converter.encode([small,large])==encoded
        assert b'PRIVATE_CHECKPOINT_MARKER' not in b''.join(p.SerializeToString() for p in encoded)
        for record in store.values.values():
            validate_contract('AgentTemporalHistoryEnvelope',record['envelope'])
            validate_contract('AgentPrivatePayloadRef',record['reference'])
    asyncio.run(run());assert len(store.writes)==2


@pytest.mark.parametrize('fault',['encoding','namespace','key','ciphertext','expansion','truncated','trailing'])
def test_compressed_history_authentication_and_decompression_are_bounded(fault):
    import base64,zlib
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    converter,store,keys,_,_=fixture();large=dict(private='COMPRESSED_PRIVATE_MARKER'*4000)
    async def run():
        encoded=await converter.encode([large]);assert encoded[0].metadata['encoding']==COMPRESSED_ENCODING
        selected=converter;codec=converter.payload_codec
        if fault=='encoding':encoded[0].metadata['encoding']=ENCODING
        elif fault=='namespace':
            selected=converter.with_context(WorkflowSerializationContext('foreign',codec.serialization_context.workflow_id))
        elif fault=='key':keys.key=os.urandom(32)
        else:
            record=next(iter(store.values.values()));envelope=record['envelope']
            data=base64.b64decode(envelope['ciphertextBase64']);nonce=data[:12]
            if fault=='ciphertext':data=data[:-1]+bytes([data[-1]^1])
            else:
                binding=codec._binding(keys.id,compressed=True)
                packed=AESGCM(keys.key).decrypt(nonce,data[12:],binding)
                if fault=='expansion':packed=zlib.compress(b'x'*(MAX_RAW_PAYLOAD+1))
                elif fault=='truncated':packed=packed[:-1]
                else:packed+=b'forbidden-tail'
                data=nonce+AESGCM(keys.key).encrypt(nonce,packed,binding)
            envelope['ciphertextBase64']=base64.b64encode(data).decode()
        with pytest.raises(PrivateHistoryUnavailable):await selected.decode(encoded)
    asyncio.run(run());assert len(store.writes)==1


def test_official_agents_plugin_preserves_the_private_claim_check_codec():
    from temporalio.contrib.openai_agents import OpenAIAgentsPlugin
    converter,store,keys,context,workflow_id=fixture()
    codec=AgentHistoryCodec(store,keys,context,'default',key_id=keys.active());original=DataConverter(payload_codec=codec)
    selected=OpenAIAgentsPlugin(add_temporal_spans=False,use_otel_instrumentation=False).configure_client({'data_converter':original})['data_converter']
    assert selected.payload_codec is codec
    scoped=selected.with_context(WorkflowSerializationContext('default',workflow_id))
    async def run():
        encoded=await scoped.encode([dict(private='SDK_PLUGIN_PRIVATE_MARKER')])
        assert encoded[0].metadata['encoding']==ENCODING and b'SDK_PLUGIN_PRIVATE_MARKER' not in encoded[0].data
        assert await scoped.decode(encoded)==[dict(private='SDK_PLUGIN_PRIVATE_MARKER')]
    asyncio.run(run())


@pytest.mark.parametrize('large',[False,True])
def test_concurrent_encoders_observe_one_original_content_claim(large):
    converter,store,_,_,_=fixture();actual=store.lookup_history
    async def run():
        entered=0;both=asyncio.Event()
        async def raced(context,write_id,namespace,workflow_id):
            nonlocal entered
            if not store.values:
                entered+=1
                if entered==2:both.set()
                await both.wait()
                return dict(kind='missing',writeId=write_id)
            return await actual(context,write_id,namespace,workflow_id)
        store.lookup_history=raced
        first,second=await asyncio.gather(converter.encode([dict(private='RACE_PRIVATE_VALUE'*(5000 if large else 1))]),converter.encode([dict(private='RACE_PRIVATE_VALUE'*(5000 if large else 1))]))
        assert first==second and await converter.decode(first)==[dict(private='RACE_PRIVATE_VALUE'*(5000 if large else 1))]
    asyncio.run(run());assert len(store.values)==1 and len(set(store.writes))==1
