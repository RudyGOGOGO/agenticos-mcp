"""Actual SDK rounds retain current facts and restart only invalidated queries."""
import asyncio
from copy import deepcopy
from dataclasses import replace
import json
from uuid import UUID,uuid5

from agents import Agent,ModelSettings,RunConfig,Runner
import pytest

from agentic_os_agent_worker.checkpoint import export_checkpoint,restore_checkpoint,tool_alias
from agentic_os_agent_worker.model_rpc import ModelRPCError
from agentic_os_agent_worker.query_context import FACT_FORMAT,incomplete_query_window,completed_current_query_window,refresh_query_window
from agentic_os_agent_worker.sdk_model import SDKModelSequence
from agentic_os_agent_worker.sdk_tools import governed_read_tool
from test_query_frontiers import QueryBoundary,QueryModel,query_item
from test_sdk_model import binding_fixture


class FactsBoundary(QueryBoundary):
    def __init__(self,queries):
        super().__init__();self.queries=queries;self.leaf_keys={};self.fact_sets={};self.obsolete=set();self.fact_requests=[];self.lose_ack=False
    async def execute_tool(self,request):
        result=await super().execute_tool(request)
        self.leaf_keys[result['accepted']['result']['resultId']]=next(query['key'] for query in self.queries if tool_alias(query['capability'])==request['toolName'])
        return result
    async def retain_query_facts(self,context,goal,set_id,references,operation):
        self.fact_requests.append(dict(setId=set_id,references=deepcopy(references),operation=operation))
        pending=list(references);leaves={}
        while pending:
            ref=pending.pop()
            if ref['payload']['schemaRef']=='AgentQueryFactSet':pending.extend(self.fact_sets[ref['producerStepId']])
            else:leaves[ref['resultId']]=ref
        invalid={self.leaf_keys[key] for key in leaves if key in self.obsolete}
        selected=[ref for key,ref in leaves.items() if self.leaf_keys[key] not in invalid]
        self.fact_sets[set_id]=deepcopy(selected)
        result=deepcopy(next(iter(leaves.values())))
        result.update(resultId=set_id,producerStepId=set_id);result['payload']['schemaRef']='AgentQueryFactSet'
        if self.lose_ack:self.lose_ack=False;raise ModelRPCError('UNAVAILABLE')
        return dict(kind='ready',setId=set_id,result=result,invalidQueryKeys=sorted(invalid))


def test_actual_sdk_refresh_drops_changed_query_keeps_unrelated_fact_and_replays_lost_ack(*,indexed=False):
    _,_,binding=binding_fixture();pairs=[query_item(i) for i in range(2)];items,queries=zip(*pairs)
    boundary=FactsBoundary(queries);sequence=SDKModelSequence(binding,dependency_boundary=boundary);goal='a'*64
    previous=json.dumps(incomplete_query_window(sequence,None,goal,format=FACT_FORMAT));accepted=[]
    def tools():return [replace(governed_read_tool(item,boundary,sequence,result_context='agent-accepted-query-ref/1'),needs_approval=True) for item in items]
    async def step(selected):
        nonlocal sequence,previous
        model=QueryModel(tool_alias(items[selected]['capability']),None)
        agent=Agent(name='Current query facts',model=model,tools=tools(),tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
        paused=await Runner.run(agent,json.loads(previous),hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert len(paused.interruptions)==1
        envelope=export_checkpoint(paused,sequence,[item['capability'] for item in items]);sequence=SDKModelSequence(envelope['binding'],dependency_boundary=boundary)
        agent=Agent(name=agent.name,model=model,tools=tools(),tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
        saved=await restore_checkpoint(agent,envelope,expected_context=binding['context'],sdk_instance_id=binding['sdkInstanceId'],
            capabilities=[item['capability'] for item in items],sequence=sequence,dependency_boundary=boundary)
        for interruption in saved.state.get_interruptions():saved.state.approve(interruption)
        result=await Runner.run(agent,saved.state,hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        window=await completed_current_query_window(result,sequence,previous,goal,[queries[selected]] if indexed else queries,
            **(dict(all_queries=[dict(key=query['key']) for query in queries]) if indexed else {}))
        previous=json.dumps(window);content=json.loads(window[0]['content'])
        assert len(model.inputs)==1 and len(content['results'])==1 and content['results'][0]['payload']['schemaRef']=='AgentQueryFactSet'
        assert len(previous.encode())<8192 and sequence.snapshot()['context']==binding['context']
        accepted.append(deepcopy(boundary.fact_sets[content['results'][0]['producerStepId']]))
    async def run():
        nonlocal previous
        await step(0)
        if indexed:
            old=accepted[-1][0];boundary.obsolete.add(old['resultId'])
            await step(1)
            assert old not in accepted[-1]
            content=json.loads(json.loads(previous)[0]['content'])
            assert [frontier['queryKeys'] for frontier in content['frontiers']]==[[queries[1]['key']]]
            assert len(boundary.requests)==2 and len({request['modelOperationId'] for request in boundary.requests})==2
            return
        await step(1)
        old=next(ref for ref in accepted[-1] if boundary.leaf_keys[ref['resultId']]==queries[0]['key'])
        unrelated=next(ref for ref in accepted[-1] if boundary.leaf_keys[ref['resultId']]==queries[1]['key'])
        boundary.obsolete.add(old['resultId']);boundary.pages[tool_alias(items[0]['capability'])]=0
        before=sequence.snapshot();boundary.lose_ack=True
        with pytest.raises(ModelRPCError):await refresh_query_window(sequence,previous,goal,queries)
        assert sequence.snapshot()==before
        window=await refresh_query_window(sequence,previous,goal,queries)
        assert boundary.fact_requests[-1]==boundary.fact_requests[-2]
        content=json.loads(window[0]['content']);assert [frontier['queryKeys'] for frontier in content['frontiers']]==[[queries[1]['key']]]
        assert boundary.fact_sets[content['results'][0]['producerStepId']]==[unrelated]
        assert sequence.snapshot()['turn']==before['turn'] and sequence.snapshot()['parentOperationId']==before['parentOperationId']
        previous=json.dumps(window);await step(0)
        assert old not in accepted[-1] and unrelated in accepted[-1]
        assert boundary.pages[tool_alias(items[1]['capability'])]==1 and len(boundary.requests)==3
        assert len({request['modelOperationId'] for request in boundary.requests})==3
    asyncio.run(run())


def test_current_fact_invalidation_can_remove_query_outside_the_hydrated_metadata_window():
    test_actual_sdk_refresh_drops_changed_query_keeps_unrelated_fact_and_replays_lost_ack(indexed=True)


def test_checkpoint_metadata_rpc_ack_loss_retains_the_original_controller_wake_parent():
    from uuid import uuid4
    from agentic_os_agent_worker.temporal_driver import AgentActivities,WorkflowBoundary
    _,_,binding=binding_fixture();operation=str(uuid4());checkpoint=str(uuid4());goal='a'*64;calls=[]
    class LostBoundary:
        async def query_checkpoint_state(self,context,ident,digest):
            assert context==binding['context'] and ident==checkpoint and digest==goal
            raise ModelRPCError('UNAVAILABLE')
    class Workflow(WorkflowBoundary):
        async def _call(self,name,value):
            calls.append(value)
            return await AgentActivities(LostBoundary()).query_checkpoint_state(value)
    async def run():
        control=await Workflow(1000).query_checkpoint_state(binding['context'],checkpoint,goal,operation_id=operation)
        assert control.status=='waiting-reconciliation' and control.operationId==operation
        assert control.rootId==binding['context']['rootId'] and control.taskId==binding['context']['taskId']
    asyncio.run(run());assert calls[0]['operationId']==operation


def test_current_fact_wire_pages_do_not_limit_total_retained_sources():
    _,_,binding=binding_fixture();item,query=query_item(0);boundary=FactsBoundary([query]);references=[]
    async def run():
        for ordinal in range(257):
            operation=str(uuid5(UUID(binding['sdkInstanceId']),'source/'+str(ordinal)))
            ref=await boundary.accepted_model_operation(binding['context'],operation);ref['payload']['schemaRef']='AgentQueryPage'
            boundary.leaf_keys[ref['resultId']]=query['key'];references.append(ref)
        sequence=SDKModelSequence(binding,dependency_boundary=boundary)
        assert await sequence.retain_query_facts('a'*64,references,'completed')==[]
        head=sequence.snapshot()['inputResults'][0]
        assert len(boundary.fact_sets[head['producerStepId']])==257 and len(boundary.fact_requests)==3
        assert all(len(value['references'])<=128 for value in boundary.fact_requests)
        assert sequence.snapshot()['turn']==binding['turn'] and sequence.snapshot()['context']==binding['context']
    asyncio.run(run())


@pytest.mark.parametrize('outcome',['current','changed','reconciliation','storage'])
def test_known_model_continuation_preserves_current_frontiers_or_waits_without_stale_state(monkeypatch,outcome):
    test_pending_tool_checkpoint_refresh_preserves_acceptance_or_waits_without_loading_sdk_state(monkeypatch,outcome,model_recovery=True)


@pytest.mark.parametrize('outcome',['current','changed','reconciliation','storage'])
def test_pending_tool_checkpoint_refresh_preserves_acceptance_or_waits_without_loading_sdk_state(monkeypatch,outcome,*,model_recovery=False,logical=False):
    from pathlib import Path
    from uuid import uuid4
    from temporalio.exceptions import ApplicationError
    from agentic_os_agent_worker import query_source_journey
    _,_,binding=binding_fixture();pairs=[query_item(i) for i in range(2)];items,queries=zip(*pairs)
    boundary=FactsBoundary(queries);goal='a'*64;binding['sdkInstanceId']=str(uuid5(UUID(binding['context']['taskId']),'sdk-instance/1'))
    binding.update(turn=4,parentOperationId=str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/3')))
    if logical:binding['context']['harness'].update(ref='focused-child-reads/1',revision=3)
    checkpoint=str(uuid5(UUID(binding['sdkInstanceId']),'checkpoint/4'))
    reference=asyncio.run(boundary.accepted_model_operation(binding['context'],str(uuid4())))
    reference['payload']['schemaRef']='AgentQueryFactSet';binding['inputResults']=[reference]
    value=deepcopy(next(row['value'] for row in json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
        if row['valid'] and row['contract']=='AgentSDKQuerySourceChildJoinJourneyStart'))
    frontiers=[dict(toolName=tool_alias(item['capability']),queryKeys=[query['key']],queryDigest=str(index)*64,
        pageOrdinal=0,nextCursor=None) for index,(item,query) in enumerate(pairs)]
    value.update(phase='query-source',binding=deepcopy(binding),goalDigest=goal,goalDraftJson=json.dumps(dict(queries=queries)),
        continuationInputJson=json.dumps([dict(role='user',content=json.dumps(dict(schema=FACT_FORMAT,goalDigest=goal,
            results=[reference],frontiers=frontiers)))]))
    value['start'].update(context=deepcopy(binding['context']),checkpointId=None if model_recovery else checkpoint)
    if logical:value['goalDraftJson']=json.dumps(dict(schema='agent-query-intent-index/2',context=binding['context'],goalDigest=goal,queryCount=80,criterionCount=96))
    original=deepcopy(value);carried=[]
    class Continued(Exception):pass
    def carry(result):carried.append(deepcopy(result));raise Continued()
    monkeypatch.setattr(query_source_journey.workflow,'continue_as_new',carry)
    class PendingBoundary(FactsBoundary):
        async def recover_query_model(self,requested,digest):
            assert requested==binding and digest==goal
            result=await self.query_checkpoint_state(binding['context'],checkpoint,goal,operation_id=binding['parentOperationId'])
            result.pop('checkpointId')
            if result['kind']!='current':result['operationId']=str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/'+str(binding['turn'])))
            if result['kind']=='changed':result['binding'].update(turn=binding['turn']+1,parentOperationId=result['operationId'])
            return result
        async def query_checkpoint_state(self,context,ident,digest,*,operation_id):
            assert context==binding['context'] and ident==checkpoint and digest==goal
            assert operation_id==binding['parentOperationId']
            if outcome=='current':return dict(kind='current',checkpointId=checkpoint)
            if outcome=='reconciliation':return dict(kind='reconciliation',checkpointId=checkpoint,operationId=binding['parentOperationId'])
            if outcome=='storage':
                attempt=deepcopy(next(row['value'] for row in json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
                    if row['valid'] and row['contract']=='AttemptHandle'))
                return dict(kind='storage',checkpointId=checkpoint,operationId=binding['parentOperationId'],
                    preparation=dict(kind='reconciliation',writeId=str(uuid4()),attempt=attempt,reason='private-payload-write-uncertain'))
            return dict(kind='changed',checkpointId=checkpoint,binding=deepcopy(binding),goalDigest=goal,
                result=reference,**(dict(invalidCount=80) if logical else dict(invalidQueryKeys=[queries[0]['key']])))
        async def get_checkpoint(self,*args):raise AssertionError('Stale SDK state must not be loaded')
    def refresh():
        boundary=PendingBoundary(queries)
        return (query_source_journey.recover_query_model(value,boundary,binding) if model_recovery
            else query_source_journey.refresh_query_checkpoint(value,boundary))
    if outcome=='current':
        assert asyncio.run(refresh()) is False
        assert value==original and carried==[]
    elif outcome in {'reconciliation','storage'}:
        with pytest.raises(ApplicationError) as wait:asyncio.run(refresh())
        assert wait.value.details[0].operationId==(str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/'+str(binding['turn'])))
            if model_recovery else binding['parentOperationId'])
        assert value==original and carried==[]
    else:
        with pytest.raises(Continued):asyncio.run(refresh())
        expected=dict(binding,turn=binding['turn']+1,parentOperationId=str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/'+str(binding['turn'])))) if model_recovery else binding
        result=carried[0];assert result['start']['checkpointId'] is None and result['binding']==expected
        assert json.loads(json.loads(result['continuationInputJson'])[0]['content'])['frontiers']==([] if logical else [frontiers[1]])
        assert result['start']['context']==original['start']['context'] and result['goalDraftJson']==original['goalDraftJson']


@pytest.mark.parametrize("outcome",["current","changed","reconciliation","storage"])
@pytest.mark.parametrize("model_recovery",[False,True])
def test_logical_checkpoint_and_model_recovery_keep_original_holds(monkeypatch,outcome,model_recovery):
    test_pending_tool_checkpoint_refresh_preserves_acceptance_or_waits_without_loading_sdk_state(
        monkeypatch,outcome,model_recovery=model_recovery,logical=True)
