"""Actual SDK approval/checkpoint/restore over bounded completed tool rounds."""
import asyncio
from copy import deepcopy
from dataclasses import replace
import json
from uuid import uuid4

from agents import Agent,ModelSettings,RunConfig,Runner
import pytest

from agentic_os_agent_worker.catalog_context import completed_discovery_window,discovery_call_model_input_filter
from agentic_os_agent_worker.checkpoint import export_checkpoint,restore_checkpoint,SDKCheckpointError
from agentic_os_agent_worker.sdk_model import SDKModelSequence,SDKModelPolicyError
from agentic_os_agent_worker.sdk_tools import governed_read_tool
from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
from test_sdk_model import binding_fixture
from test_sdk_tools import Boundary,ModelCalls,item_fixture
from test_tool_execution_rpc import accepted_for,failed_for


def test_nine_actual_sdk_metadata_approval_rounds_keep_checkpoints_within_existing_payload_bound():
    _,_,binding=binding_fixture();binding['context']['harness']['ref']='governed-read-discovery/'+'a'*64
    original=deepcopy(binding['context']);question='Original read objective';sizes=[];heads=[]
    class CatalogBoundary(Boundary):
        async def execute_tool(self,request):
            ordinal=len(self.requests);self.requests.append(deepcopy(request));result=accepted_for(request)
            entries=[dict(capability=dict(request['capability'],ref='reviewed.read.'+str(ordinal*16+i)),kind='read',
                title='Reviewed choice '+str(i),description='M'*512,descriptionTruncated=False,
                available=True,blocker=None,providerRef='synthetic.read') for i in range(16)]
            page=dict(context=deepcopy(request['context']),request=json.loads(request['argumentsJson']),
                catalogVersion=130,items=entries,retained=[],nextCursor='opaque/'+str(ordinal+1),
                validUntil=request['context']['authorizationHorizon'])
            raw=json.dumps(page,separators=(',',':'));result['accepted']['payloadJson']=raw
            result['accepted']['result']['payload'].update(schemaRef='AgentCapabilityDiscoveryPage',bytes=len(raw.encode()))
            return result
    boundary=CatalogBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary);initial=question
    item=item_fixture();item['inputSchemaJson']=json.dumps(dict(type='object',additionalProperties=False,
        required=['cursor','limit','retain'],properties=dict(cursor=dict(anyOf=[dict(type='null'),dict(type='string')]),
            limit=dict(type='integer'),retain=dict(type='array',items=dict(type='object')))))
    class MetadataModel(ModelCalls):
        async def get_response(self,*args,**kwargs):
            result=await super().get_response(*args,**kwargs)
            result.output[0].arguments=json.dumps(dict(cursor=None if not boundary.requests else 'opaque/'+str(len(boundary.requests)),
                limit=16,retain=[]))
            return result
    async def run():
        nonlocal sequence,initial
        for ordinal in range(9):
            def agent(model):
                tool=replace(governed_read_tool(item,boundary,sequence,result_context='agent-capability-discovery/1'),needs_approval=True)
                return Agent(name='Bounded discovery round',model=model,tools=[tool],tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
            model=MetadataModel('',count=1);selected=agent(model);model.name=selected.tools[0].name
            cfg=RunConfig(tracing_disabled=True,call_model_input_filter=discovery_call_model_input_filter(original))
            paused=await Runner.run(selected,initial,hooks=sequence,max_turns=None,run_config=cfg)
            assert len(paused.interruptions)==1 and len(boundary.requests)==ordinal
            with pytest.raises(SDKModelPolicyError):completed_discovery_window(paused,sequence,item['capability'],question)
            envelope=export_checkpoint(paused,sequence,[item['capability']])
            payload=AgentPayloadConverter().to_payloads([dict(checkpointId=str(uuid4()),value=envelope)])[0]
            sizes.append(len(payload.SerializeToString(deterministic=True)))
            sequence=SDKModelSequence(envelope['binding'],dependency_boundary=boundary);selected=agent(model)
            loaded=await restore_checkpoint(selected,envelope,expected_context=original,sdk_instance_id=binding['sdkInstanceId'],
                capabilities=[item['capability']],sequence=sequence,dependency_boundary=boundary)
            for interruption in loaded.state.get_interruptions():loaded.state.approve(interruption)
            completed=await Runner.run(selected,loaded.state,hooks=sequence,max_turns=None,run_config=cfg)
            assert len(model.inputs)==1 and len(boundary.requests)==ordinal+1
            initial=completed_discovery_window(completed,sequence,item['capability'],question)
            assert initial[0]['content']==question and len([row for row in initial if row.get('type')=='function_call_output'])==1
            heads.append(sequence.snapshot()['inputResults']);assert len(heads[-1])==2
            if ordinal:assert model.bindings[0]['inputResults']==heads[ordinal-1]
        assert sequence.snapshot()['context']==original and len({row['modelOperationId'] for row in boundary.requests})==9
        assert max(sizes)<=65536
    asyncio.run(run())


def test_oversized_metadata_checkpoint_is_refused_before_any_tool_dispatch():
    _,_,binding=binding_fixture();binding['context']['harness']['ref']='governed-read-discovery/'+'a'*64
    boundary=Boundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary);item=item_fixture()
    class WideModel(ModelCalls):
        async def get_response(self,*args,**kwargs):
            result=await super().get_response(*args,**kwargs)
            result.output[0].arguments=json.dumps(dict(value='x'*70000))
            return result
    async def run():
        tool=replace(governed_read_tool(item,boundary,sequence,result_context='agent-capability-discovery/1'),needs_approval=True)
        model=WideModel(tool.name,count=1);agent=Agent(name='Reject oversized private state',model=model,tools=[tool],model_settings=ModelSettings(metadata={}))
        paused=await Runner.run(agent,'Original read objective',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert len(paused.interruptions)==1
        with pytest.raises(SDKCheckpointError):export_checkpoint(paused,sequence,[item['capability']])
        assert not boundary.requests and sequence.snapshot()['context']==binding['context']
    asyncio.run(run())


def test_actual_sdk_metadata_error_checkpoint_retries_smaller_page_without_evidence_or_new_authority():
    _,_,binding=binding_fixture();binding['context']['harness']['ref']='governed-read-discovery/'+'a'*64
    original=deepcopy(binding['context']);question='Original read objective';sizes=[]
    class BudgetBoundary(Boundary):
        async def execute_tool(self,request):
            self.requests.append(deepcopy(request))
            if len(self.requests)==1:return failed_for(request)
            entry=dict(capability=dict(request['capability'],ref='r'+'x'*255),kind='read',title='🧭'*160,
                description='🧭'*256,descriptionTruncated=False,available=True,blocker=None,providerRef='p'+'x'*255)
            result=accepted_for(request);page=dict(context=deepcopy(request['context']),request=json.loads(request['argumentsJson']),
                catalogVersion=130,items=[entry],retained=[],nextCursor=None,validUntil=request['context']['authorizationHorizon'])
            raw=json.dumps(page,separators=(',',':'));result['accepted']['payloadJson']=raw
            result['accepted']['result']['payload'].update(schemaRef='AgentCapabilityDiscoveryPage',bytes=len(raw.encode()))
            return result
    boundary=BudgetBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary);item=item_fixture();initial=question
    item['inputSchemaJson']=json.dumps(dict(type='object',additionalProperties=False,required=['cursor','limit','retain'],
        properties=dict(cursor=dict(type='null'),limit=dict(type='integer'),retain=dict(type='array',items=dict(type='object')))))
    class MetadataModel(ModelCalls):
        async def get_response(self,*args,**kwargs):
            result=await super().get_response(*args,**kwargs)
            result.output[0].arguments=json.dumps(dict(cursor=None,limit=16 if not boundary.requests else 1,retain=[]))
            return result
    async def run():
        nonlocal initial,sequence
        for ordinal in range(3):
            def agent(model):
                tool=replace(governed_read_tool(item,boundary,sequence,result_context='agent-capability-discovery/1'),needs_approval=True)
                return Agent(name='Recover bounded metadata',model=model,tools=[tool],tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
            model=MetadataModel('',count=1);selected=agent(model);model.name=selected.tools[0].name
            cfg=RunConfig(tracing_disabled=True,call_model_input_filter=discovery_call_model_input_filter(original))
            paused=await Runner.run(selected,initial,hooks=sequence,max_turns=None,run_config=cfg)
            assert len(paused.interruptions)==1
            envelope=export_checkpoint(paused,sequence,[item['capability']])
            sizes.append(len(AgentPayloadConverter().to_payloads([dict(checkpointId=str(uuid4()),value=envelope)])[0].SerializeToString(deterministic=True)))
            sequence=SDKModelSequence(envelope['binding'],dependency_boundary=boundary);selected=agent(model)
            restored=await restore_checkpoint(selected,envelope,expected_context=original,sdk_instance_id=binding['sdkInstanceId'],
                capabilities=[item['capability']],sequence=sequence,dependency_boundary=boundary)
            for interruption in restored.state.get_interruptions():restored.state.approve(interruption)
            completed=await Runner.run(selected,restored.state,hooks=sequence,max_turns=None,run_config=cfg)
            initial=completed_discovery_window(completed,sequence,item['capability'],question)
            assert initial[0]['content']==question and sequence.snapshot()['context']==original
            if ordinal==0:
                assert json.loads(initial[-1]['output'])==dict(kind='tool-error',failure='tool-failed')
                assert len(sequence.snapshot()['inputResults'])==1
                invalid=deepcopy(sequence.binding);sequence.binding['inputResults']=[]
                with pytest.raises(SDKModelPolicyError):completed_discovery_window(completed,sequence,item['capability'],question)
                sequence.binding=invalid
            else:assert len(sequence.snapshot()['inputResults'])==2
        assert [json.loads(request['argumentsJson'])['limit'] for request in boundary.requests]==[16,1,1]
        assert len({request['modelOperationId'] for request in boundary.requests})==3 and max(sizes)<=65536
    asyncio.run(run())
