"""Private execution reply binding with synthetic kernel responses."""
import asyncio
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from uuid import UUID,uuid5

import httpx
import pytest

from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from test_tool_rpc import fixture


def failed_for(request):
    """Closed existing tool-error wire; no accepted evidence is fabricated."""
    vectors=json.loads((Path(__file__).resolve().parents[3]/'tests/fixtures/contracts.json').read_text())
    invocation=deepcopy(next(v['value'] for v in vectors if v['contract']=='AgentToolInvocation' and v['valid']))
    binding=accepted_for(request)['accepted']['binding']
    invocation['record'].update(context=deepcopy(request['context']),identity=binding['identity'],
        modelOperationId=request['modelOperationId'],modelResult=binding['modelResult'],capability=request['capability'])
    return dict(kind='failed',request=invocation,observation=dict(capability=request['capability'],operation=dict(
        attemptId=invocation['attempt']['id'],state='failed',candidate=None,receiptRef=None,failure='tool-failed',
        usage=dict(measured=dict(tokens=0,costMicros=0,workMs=1,computeMs=0,storageBytes=0),completeness='known',providerUsageRef=None))))


def accepted_for(request,*,query=False):
    _,_,binding=fixture();binding=deepcopy(binding)
    binding.update(context=deepcopy(request['context']),modelOperationId=request['modelOperationId'],
        capability=deepcopy(request['capability']),callId=request['callId'],toolName=request['toolName'],argumentsJson=request['argumentsJson'])
    payload={k:binding[k] for k in ('modelResult','capability','callId','callIndex','toolName','argumentsJson')}
    raw=json.dumps(payload,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
    c=request['context'];identity={k:c[k] for k in ('taskId','rootId','segmentId','intentRevision','controlEpoch')}
    op=uuid5(UUID(request['modelOperationId']),'sdk-tool/'+request['callId']);step=uuid5(op,'tool-attempt/1')
    identity.update(operationId=str(op),planRevision=1,parentOperationId=request['modelOperationId'],iteration=0,kind='tool',
        inputDigest=hashlib.sha256(b'agentic-os.hash/1\0command\0'+raw).hexdigest());binding['identity']=identity
    result=deepcopy(binding['modelResult']);result.update(resultId=str(uuid5(step,'accepted-result')),producerStepId=str(step))
    result['payload'].update(schemaRef='AgentQueryPage' if query else 'EvidencePage',schemaVersion=1)
    page=dict(evidence=dict(id=str(step),subject=deepcopy(c['subject']),providerRef='synthetic.read',resourceRefs=[],
        observedAt=result['acceptedAt'],classification='host-authorized',quality='synthetic',completeness='1',
        publicFields=[],formatterRef='synthetic/1',formatterVersion=1,coreDigest='a'*64),records=[],nextCursor=None)
    if query:
        page=dict(schema='agent-query-page/1',page=page,coverage=dict(queryRef='synthetic.query',snapshotRef='synthetic.snapshot',
            requestedScopeRef=c['scopeRef'],coveredScopeRef=c['scopeRef'],observedRows=0,expectedRows=0,nextCursorRef=None,
            status='complete',explanationRef=None),queryDigest='a'*64,requestCursor=None,pageOrdinal=0,grain=['id'],pageGroupFields=[])
    return dict(kind='accepted',accepted=dict(result=result,binding=binding,attemptNumber=1,payloadJson=json.dumps(page,separators=(',',':'))))


def memory_accepted_for(request):
    result=accepted_for(request);accepted=result['accepted'];page=json.loads(accepted['payloadJson'])
    accepted['result']['payload']['schemaRef']='AgentMemoryPage'
    page['evidence'].update(classification='owner-private',quality='reported',completeness='0')
    value=dict(page=page,bindingId=str(uuid5(UUID(request['context']['taskId']),'synthetic-memory-binding')),
        bindingMac='f'*64,contextRef='general/1',references=[],
        coverage=dict(selection='ranked-results',scopeCount=0,returnedCount=0,exhaustive=False))
    accepted['payloadJson']=json.dumps(value,separators=(',',':'))
    return result


@pytest.mark.parametrize('fault',[None,'legacy-profile','foreign-scope'],ids=['accepted','legacy-profile','foreign-scope'])
def test_private_knowledge_result_requires_its_profile_and_exact_application_scope(fault):
    config,request,_=fixture()
    if fault!='legacy-profile':request['context']['harness']['ref']='private-planned-read/synthetic-source'
    result=accepted_for(request);accepted=result['accepted'];accepted['result']['payload']['schemaRef']='AgentPrivateKnowledgePage'
    scope={key:request['context']['subject'][key] for key in ('installationId','applicationId','tenantId')}
    if fault=='foreign-scope':scope['tenantId']='foreign-tenant'
    page=dict(binding=dict(keyId=accepted['result']['resultId'],mac='f'*64,
        value=dict(scope=scope,contentRevision=1,references=[],validUntil=None)),passages=[])
    accepted['payloadJson']=json.dumps(page,separators=(',',':'))
    async def token():return 'synthetic-workload'
    async def rpc(_):return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.execute_tool(request)
            else:assert await client.execute_tool(request)==result
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('memory_profile',[True,False])
def test_private_memory_result_requires_the_explicit_original_memory_profile(memory_profile):
    config,request,_=fixture()
    if memory_profile:request['context']['harness']['ref']='memory-assisted-read/synthetic-source'
    result=memory_accepted_for(request)
    async def token():return 'synthetic-workload'
    async def rpc(_):return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if memory_profile:assert await client.execute_tool(request)==result
            else:
                with pytest.raises(ModelRPCError):await client.execute_tool(request)
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'legacy-profile','source','bytes'])
def test_wasm_verification_rpc_preserves_original_profile_source_and_result_binding(fault):
    config,request,_=fixture()
    request['context']['harness']['ref']='verified-wasm-creation/synthetic-original'
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
    candidate=deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']=='AgentWasmVerificationCandidate'))
    request['argumentsJson']=json.dumps(dict(source=candidate['compiled']['source']))
    if fault=='legacy-profile':request['context']['harness']['ref']='verified-evidence-read/1'
    result=accepted_for(request);accepted=result['accepted']
    if fault=='source':candidate['compiled']['source']='(module)'
    accepted['payloadJson']=json.dumps(candidate,separators=(',',':'))
    accepted['result']['payload'].update(schemaRef='AgentWasmVerificationCandidate',bytes=len(accepted['payloadJson'].encode()))
    if fault=='bytes':accepted['result']['payload']['bytes']+=1
    calls=[]
    async def token():return 'synthetic-workload'
    async def rpc(http):calls.append(json.loads(http.content));return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.execute_tool(request)
            else:assert await client.execute_tool(request)==result
        finally:await client.close()
    asyncio.run(run());assert len(calls)==1 and calls[0]['request']==request


def test_worker_execution_freezes_request_and_validates_accepted_result_identity():
    config,request,_=fixture();original=deepcopy(request);sent=[];result=accepted_for(original)
    async def token():
        await asyncio.sleep(0);request['argumentsJson']='{"value":999}'
        return 'synthetic-workload'
    async def rpc(http):
        assert http.url.path.endswith('/execute-tool');sent.append(json.loads(http.content))
        return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:assert await client.execute_tool(request)==result
        finally:await client.close()
    asyncio.run(run());assert sent[0]['request']==original and len(sent)==1


@pytest.mark.parametrize('fault',['owner','schema','producer','result','arguments','parent','ready','invalid-page'])
def test_worker_refuses_substituted_tool_result_or_executable_grant(fault):
    config,request,_=fixture();result=accepted_for(request)
    if fault=='owner':result['accepted']['result']['subject']['subjectId']='foreign'
    elif fault=='schema':result['accepted']['result']['payload']['schemaRef']='AgentProviderResponse'
    elif fault=='producer':result['accepted']['result']['producerStepId']='00000000-0000-4000-8000-000000000099'
    elif fault=='result':result['accepted']['result']['resultId']='00000000-0000-4000-8000-000000000099'
    elif fault=='arguments':result['accepted']['binding']['argumentsJson']='{"value":999}'
    elif fault=='parent':result['accepted']['binding']['modelOperationId']='00000000-0000-4000-8000-000000000099'
    elif fault=='invalid-page':result['accepted']['payloadJson']='{"records":[]}'
    else:
        # The client may receive a schema-valid preparation, but it must never
        # expose a ready grant as a completed execute action.
        from test_operation_rpc import operation_fixture
        _,record,_,_,ready=operation_fixture();model=ready['preparation']['request']
        b=result['accepted']['binding'];r=dict(context=b['context'],identity=b['identity'],binding=dict(
            artifactRef=model['input']['artifactRef'],ciphertextDigest='c'*64,bytes=100,schemaRef='AgentSDKToolBinding',schemaVersion=1),
            modelOperationId=b['modelOperationId'],modelResult=b['modelResult'],capability=b['capability'],profile=b['capability'])
        result=dict(kind='ready',request=dict(record=r,callId=result['accepted']['result']['producerStepId'],attemptNumber=1,
            attempt=dict(subject=request['context']['subject'],id=model['grant']['attemptId'],rootId=request['context']['rootId'],
                taskId=request['context']['taskId'],segmentId=request['context']['segmentId'],controlEpoch=request['context']['controlEpoch'],
                leaseToken=model['grant']['attemptId'],leaseUntil=request['context']['authorizationHorizon'],state='RESERVED'),
            reserved=dict(tokens=0,costMicros=0,workMs=30000,computeMs=0,storageBytes=0)))
        from agentic_os_agent_worker.transport import _validate
        _validate('AgentToolPreparation',result)
    async def token():return 'synthetic-workload'
    async def rpc(_):return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            with pytest.raises(ModelRPCError):await client.execute_tool(request)
        finally:await client.close()
    asyncio.run(run())


def test_worker_preserves_reconciliation_without_retrying_unknown_work():
    config,request,binding=fixture();seen=[]
    result=dict(kind='reconciliation',operationId=binding['identity']['operationId'],
        callId=str(uuid5(UUID(binding['identity']['operationId']),'tool-attempt/1')),reason='tool-completion-unknown')
    async def token():return 'synthetic-workload'
    async def rpc(_):seen.append(1);return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:assert await client.execute_tool(request)==result
        finally:await client.close()
    asyncio.run(run());assert seen==[1]


def test_worker_accepts_valid_query_payload_without_relabeling_it_as_legacy_evidence():
    config,request,_=fixture();result=accepted_for(request,query=True)
    async def token():return 'synthetic-workload'
    async def rpc(_):return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:assert await client.execute_tool(request)==result
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',[None,'owner','invalid-preparation'],ids=['accepted','foreign-owner','invalid-payload'])
def test_worker_preparation_rpc_checks_typed_payload_and_original_result_identity(fault):
    from pathlib import Path
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
    prepared=deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']=='AgentPreparedChange'))
    config,request,_=fixture();result=accepted_for(request)
    if fault=='invalid-preparation':prepared.pop('bindingDigest')
    raw=json.dumps(prepared,separators=(',',':'))
    result['accepted']['payloadJson']=raw
    result['accepted']['result']['payload'].update(schemaRef='AgentPreparedChange',bytes=len(raw.encode()))
    if fault=='owner':result['accepted']['result']['subject']['subjectId']='foreign'
    calls=[]
    async def token():return 'synthetic-workload'
    async def rpc(_):calls.append(1);return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.execute_tool(request)
            else:assert await client.execute_tool(request)==result
        finally:await client.close()
    asyncio.run(run());assert calls==[1]
