"""Independent authenticated causal-input protocol with synthetic replies."""
import asyncio
from copy import deepcopy
from uuid import UUID,uuid5
import json
import httpx
import pytest
from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from test_tool_rpc import fixture


def values():
    config,request,binding=fixture();context=request['context'];operation=request['modelOperationId'];reference=deepcopy(binding['modelResult'])
    reference['producerStepId']=str(uuid5(UUID(operation),'model-attempt/1'))
    return config,context,operation,reference


@pytest.mark.parametrize('fault',[None,'set','owner','root','result','schema'])
def test_current_fact_response_preserves_context_and_rejects_substitution(fault):
    config,context,operation,reference=values();original=deepcopy(context);sources=[deepcopy(reference)]
    expected=deepcopy(sources);set_id=str(uuid5(UUID(operation),'current-facts'))
    reference.update(resultId=set_id,producerStepId=set_id);reference['payload']['schemaRef']='AgentQueryFactSet'
    result=dict(kind='ready',setId=set_id,result=reference,invalidQueryKeys=[]);seen=[]
    if fault=='set':result['setId']=str(uuid5(UUID(operation),'foreign-set'))
    elif fault=='owner':reference['subject']['subjectId']='foreign'
    elif fault=='root':reference['rootId']=str(uuid5(UUID(operation),'foreign-root'))
    elif fault=='result':reference['resultId']=str(uuid5(UUID(operation),'foreign-result'))
    elif fault=='schema':reference['payload']['schemaRef']='EvidencePage'
    async def token():
        context['subject']['subjectId']='changed-after-await';sources.clear()
        return 'synthetic-workload'
    async def rpc(http):
        value=json.loads(http.content);seen.append(value)
        assert http.url.path.endswith('/retain-query-facts') and value['context']==original
        assert value['results']==expected and value['goalDigest']=='a'*64
        return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.retain_query_facts(context,'a'*64,set_id,sources)
            else:assert await client.retain_query_facts(context,'a'*64,set_id,sources)==result
        finally:await client.close()
    asyncio.run(run());assert len(seen)==1


@pytest.mark.parametrize('fault',[None,'operation','owner','producer','schema'])
def test_accepted_operation_lookup_checks_original_context_and_attempt_identity(fault):
    config,context,operation,reference=values();original=deepcopy(context)
    result=dict(operationId=operation,attemptNumber=1,result=reference);seen=[]
    if fault=='operation':result['operationId']='00000000-0000-4000-8000-000000000099'
    elif fault=='owner':result['result']['subject']['subjectId']='foreign'
    elif fault=='producer':result['result']['producerStepId']='00000000-0000-4000-8000-000000000099'
    elif fault=='schema':result['result']['payload']['schemaRef']='EvidencePage'
    async def token():context['subject']['subjectId']='changed-after-await';return 'synthetic-workload'
    async def rpc(http):
        value=json.loads(http.content);seen.append(value)
        assert http.url.path.endswith('/accepted-operation') and value['context']==original
        return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.accepted_model_operation(context,operation)
            else:assert await client.accepted_model_operation(context,operation)==reference
        finally:await client.close()
    asyncio.run(run());assert len(seen)==1


@pytest.mark.parametrize('fault',[None,'set','owner','producer','result','schema'])
def test_result_set_response_cannot_substitute_owner_or_set_identity(fault):
    config,context,operation,reference=values();set_id=str(uuid5(UUID(operation),'set'));source=deepcopy(reference)
    reference['payload']['schemaRef']='AgentInputResultSet';reference.update(producerStepId=set_id,resultId=str(uuid5(UUID(set_id),'accepted-result-set')))
    result=dict(kind='ready',setId=set_id,result=reference);seen=[]
    if fault=='set':result['setId']='00000000-0000-4000-8000-000000000099'
    elif fault=='owner':reference['subject']['subjectId']='foreign'
    elif fault=='producer':reference['producerStepId']='00000000-0000-4000-8000-000000000099'
    elif fault=='result':reference['resultId']='00000000-0000-4000-8000-000000000099'
    elif fault=='schema':reference['payload']['schemaRef']='EvidencePage'
    async def token():return 'synthetic-workload'
    async def rpc(http):
        value=json.loads(http.content);seen.append(value)
        assert http.url.path.endswith('/pack-input-results') and value['results']==[source]
        return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault:
                with pytest.raises(ModelRPCError):await client.pack_input_results(context,set_id,[source])
            else:assert await client.pack_input_results(context,set_id,[source])==result
        finally:await client.close()
    asyncio.run(run());assert len(seen)==1
