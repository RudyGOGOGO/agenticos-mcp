"""Independent private history/checkpoint client with synthetic kernel replies."""
import asyncio
import base64
from copy import deepcopy
from datetime import datetime,timezone
import json
from uuid import uuid4
import httpx
import pytest


def test_proactive_review_control_cannot_reserve_private_history_after_publication():
    """The actual review Activity returns only the existing safe wait control."""
    from uuid import uuid4
    from agentic_os_agent_worker.temporal_driver import AgentActivities
    from agentic_os_agent_worker.private_history import AgentHistoryCodec
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,ReadControl,READ_CONTROL_ENCODING
    from temporalio.converter import WorkflowSerializationContext
    from test_tool_rpc import fixture as tool_fixture
    from test_tool_execution_rpc import accepted_for
    _,request,_=tool_fixture();context=request['context'];goal='a'*64
    state=dict(context=context,goalDigest=goal,preparation=accepted_for(request)['accepted']['result'],
        definitionId=str(uuid4()),kind='waiting',approval=None)
    class Boundary:
        async def proactivity(self,*args):return deepcopy(state)
        async def put_history(self,*args):raise AssertionError('Review output attempted private storage')
        async def lookup_history(self,*args):raise AssertionError('Review output attempted private lookup')
        def _key(self,*args):raise AssertionError('Review control attempted private encryption')
    boundary=Boundary()
    async def exercise():
        result=await AgentActivities(boundary).proactivity(dict(context=context,operationId=request['modelOperationId']))
        assert isinstance(result,ReadControl) and result.state=='incomplete' and result.goalDigest==goal
        assert result.rootId==context['rootId'] and result.taskId==context['taskId']
        payloads=AgentPayloadConverter().to_payloads([result])
        assert payloads[0].metadata['encoding']==READ_CONTROL_ENCODING
        workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
        codec=AgentHistoryCodec(boundary,boundary,context,'default',key_id=str(uuid4()),
            serialization_context=WorkflowSerializationContext('default',workflow_id))
        assert await codec.encode(payloads)==payloads
        assert context['subject']['subjectId'].encode() not in payloads[0].data
        assert b'definitionId' not in payloads[0].data and b'preparation' not in payloads[0].data
    asyncio.run(exercise())


def test_proactive_completion_retains_preparation_after_the_final_model_replaces_the_sdk_head():
    from agentic_os_agent_worker.read_journey import proactive_review_preparation
    from agentic_os_agent_worker.sdk_model import SDKModelPolicyError
    from test_tool_rpc import fixture as tool_fixture
    from test_tool_execution_rpc import accepted_for
    _,request,_=tool_fixture();preparation=accepted_for(request)['accepted']['result']
    preparation['payload']['schemaRef']='AgentProactivePreparation';goal='a'*64
    document=dict(goalDigest=goal,preparation=preparation)
    assert proactive_review_preparation(json.dumps(document),goal)==preparation
    with pytest.raises(SDKModelPolicyError):proactive_review_preparation(json.dumps(document),'b'*64)
    changed=deepcopy(document);changed['preparation']['payload']['schemaRef']='AgentProviderResponse'
    with pytest.raises(SDKModelPolicyError):proactive_review_preparation(json.dumps(changed),goal)
from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from test_tool_rpc import fixture as tool_fixture


def fixture():
    config,request,_=tool_fixture();c=request['context'];ident=str(uuid4())
    envelope=dict(profile='agent-private-history/1',namespace='default',workflowId='os-agent:'+':'.join(
        [c['subject']['installationId'],c['subject']['applicationId'],c['taskId']]),keyId=str(uuid4()),ciphertextBase64=base64.b64encode(b'x'*32).decode())
    reference=dict(subject=deepcopy(c['subject']),taskId=c['taskId'],rootId=c['rootId'],writeId=ident,
        payload=dict(artifactRef='artifact/'+str(uuid4()),ciphertextDigest='a'*64,bytes=200,schemaRef='AgentTemporalHistoryEnvelope',schemaVersion=1),
        createdAt=datetime.now(timezone.utc).isoformat(),expiresAt=c['authorizationHorizon'])
    return config,c,ident,envelope,reference


@pytest.mark.parametrize('observe',[False,True])
def test_versioned_history_accepts_supported_encrypted_checkpoint_at_the_actual_sender(observe):
    from temporalio.converter import WorkflowSerializationContext
    from agentic_os_agent_worker.private_history import AgentHistoryCodec,PrivateHistoryUnavailable,MAX_RAW_PAYLOAD
    from agentic_os_agent_worker.temporal_runtime import ObservedHistoryBoundary
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    from agentic_os_agent_worker.transport import _validate
    from test_private_history import CreateStore,Keys
    config,context,_,envelope,_=fixture();backing=CreateStore(context);keys=Keys();sent=[]
    payload=AgentPayloadConverter().to_payloads([dict(privateCheckpoint='s'*64000)])[0]
    assert len(payload.SerializeToString(deterministic=True))<65536
    async def token():return 'synthetic-workload'
    async def rpc(http):
        command=json.loads(http.content);_validate('AgentHistoryPutCommand',command)
        assert command['context']==context and 65536<len(http.content)<4*1048576+65536
        assert http.url.path.endswith('/history-create-observe-v1' if observe else '/history-create-v1')
        sent.append(command)
        return httpx.Response(200,json=await backing.store_history(context,command['writeId'],command['envelope']))
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        boundary=ObservedHistoryBoundary(client) if observe else client
        codec=AgentHistoryCodec(boundary,keys,context,envelope['namespace'],key_id=keys.id,
            serialization_context=WorkflowSerializationContext(envelope['namespace'],envelope['workflowId']))
        try:
            encoded=await codec.encode([payload]);assert len(encoded)==1
            # The actual authenticated stored envelope must recover identical
            # bytes. Wider create transport grants no lookup or payload limit.
            assert codec._decrypt(backing.values[sent[0]['writeId']],sent[0]['writeId'])==payload.SerializeToString(deterministic=True)
            with pytest.raises(ModelRPCError) as limited:
                await client._send('history-observe',dict(oversized='s'*65536),'AgentHistoryLookupResult')
            assert limited.value.code=='CAPACITY'
            oversized=deepcopy(payload);oversized.data=b's'*(MAX_RAW_PAYLOAD+1)
            with pytest.raises(PrivateHistoryUnavailable):await codec.encode([oversized])
            assert len(sent)==1 and len(backing.writes)==1
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('action',['put','lookup','create','create-observe'])
def test_history_requests_are_frozen_before_workload_token_renewal(action):
    config,c,ident,envelope,reference=fixture();original=deepcopy(c);original_envelope=deepcopy(envelope);seen=[]
    result=dict(kind='ready',reference=reference)
    if action!='put':result['envelope']=deepcopy(envelope)
    async def token():
        c['subject']['subjectId']='changed-after-await';envelope['keyId']=str(uuid4());return 'synthetic-workload'
    async def rpc(http):
        value=json.loads(http.content);seen.append(value);assert value['context']==original
        if action!='lookup':assert value['envelope']==original_envelope
        if action.startswith('create'):assert http.url.path.endswith('/history-create-observe-v1' if action=='create-observe' else '/history-create-v1')
        return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if action=='put':assert await client.put_history(c,ident,envelope)==result
            elif action.startswith('create'):assert await client.store_history(c,ident,envelope,observe=action=='create-observe')==result
            else:assert await client.lookup_history(c,ident,envelope['namespace'],envelope['workflowId'])==result
        finally:await client.close()
    asyncio.run(run());assert len(seen)==1


@pytest.mark.parametrize('fault',['owner','root','write','schema','workflow','missing'])
@pytest.mark.parametrize('create',[False,True])
def test_history_lookup_rejects_substituted_scope_reference_or_envelope(fault,create):
    config,c,ident,envelope,reference=fixture();result=dict(kind='ready',reference=reference,envelope=deepcopy(envelope))
    if fault=='owner':reference['subject']['subjectId']='foreign'
    elif fault=='root':reference['rootId']=str(uuid4())
    elif fault=='write':reference['writeId']=str(uuid4())
    elif fault=='schema':reference['payload']['schemaRef']='AgentSDKCheckpointState'
    elif fault=='workflow':result['envelope']['workflowId']='other-workflow'
    else:result=dict(kind='missing',writeId=ident)
    async def token():return 'synthetic-workload'
    async def rpc(_):return httpx.Response(200,json=result)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            if fault=='missing' and not create:
                assert await client.lookup_history(c,ident,envelope['namespace'],envelope['workflowId'])==result
            else:
                with pytest.raises(ModelRPCError):
                    if create:await client.store_history(c,ident,envelope)
                    else:await client.lookup_history(c,ident,envelope['namespace'],envelope['workflowId'])
        finally:await client.close()
    asyncio.run(run())


@pytest.mark.parametrize('foreign',[False,True])
def test_checkpoint_transport_keeps_the_original_binding_on_put_and_get(foreign):
    config,c,ident,_,reference=fixture();reference['payload']['schemaRef']='AgentSDKCheckpointState'
    value=dict(format='openai-agents/0.19.4/run-state/1.13',binding=dict(context=deepcopy(c),sdkInstanceId=str(uuid4()),
        turn=2,planRevision=1,parentOperationId=str(uuid4()),inputResults=[]),capabilities=[],stateJson='{}')
    returned=deepcopy(value)
    if foreign:returned['binding']['context']['subject']['subjectId']='foreign'
    async def token():return 'synthetic-workload'
    async def rpc(http):
        command=json.loads(http.content)
        if http.url.path.endswith('/checkpoint-put'):
            assert command['value']==value;return httpx.Response(200,json=dict(kind='ready',reference=reference))
        return httpx.Response(200,json=returned)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            assert (await client.put_checkpoint(ident,value))['kind']=='ready'
            if foreign:
                with pytest.raises(ModelRPCError):await client.get_checkpoint(c,ident)
            else:assert await client.get_checkpoint(c,ident)==value
        finally:await client.close()
    asyncio.run(run())
