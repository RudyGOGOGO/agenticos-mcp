"""Exercise the actual Runner with deterministic provider replies, never API calls."""
import asyncio
import json

from agents import Agent, Model, ModelResponse, RunConfig, Runner, RunState, function_tool
from agents.usage import Usage
from openai.types.responses import ResponseFunctionToolCall, ResponseOutputMessage, ResponseOutputText


def calls(*items):
    return ModelResponse(output=[ResponseFunctionToolCall(type="function_call", name=name,
        call_id=ident, arguments=json.dumps(arguments)) for name, ident, arguments in items],
        usage=Usage(requests=1, input_tokens=7, output_tokens=3, total_tokens=10), response_id=None)


def answer(text):
    return ModelResponse(output=[ResponseOutputMessage(id="answer", type="message",
        status="completed", role="assistant", content=[ResponseOutputText(type="output_text",
        text=text, annotations=[])])], usage=Usage(requests=1, input_tokens=7,
        output_tokens=3, total_tokens=10), response_id=None)


class ScriptedModel(Model):
    """Only the provider is scripted; SDK control flow and serialization are real."""
    def __init__(self, respond):
        self.respond = respond
        self.inputs = []

    async def get_response(self, system_instructions, input, *args, **kwargs):
        self.inputs.append(input)
        return self.respond(input)

    async def stream_response(self, *args, **kwargs):
        raise AssertionError("Streaming is a separate qualification gate")
        yield


CONFIG = RunConfig(tracing_disabled=True)


def outputs(items):
    return [json.loads(x["output"]) for x in items if x.get("type") == "function_call_output"]


def test_repeated_dependent_tool_calls_have_no_default_turn_ceiling():
    executed = []

    @function_tool(failure_error_function=None)
    async def advance(previous: int) -> str:
        """Advance a synthetic chain from the previous accepted value."""
        executed.append(previous)
        return json.dumps(previous + 1)

    def respond(items):
        values = outputs(items)
        latest = values[-1] if values else 0
        if latest == 12:
            return answer("Reached 12 using the previous result each time.")
        return calls(("advance", f"step-{latest}", {"previous": latest}))

    model = ScriptedModel(respond)
    result = asyncio.run(Runner.run(Agent(name="Chain", model=model, tools=[advance]),
        "Advance twelve times", max_turns=None, run_config=CONFIG))
    assert executed == list(range(12))
    assert len(model.inputs) == 13
    assert result.context_wrapper.usage.total_tokens == 130
    assert result.final_output == "Reached 12 using the previous result each time."


def test_parallel_branches_join_only_after_both_results_are_present():
    async def scenario():
        started = set()
        both_started = asyncio.Event()

        @function_tool(failure_error_function=None)
        async def branch(key: str) -> str:
            """Read one synthetic independent branch."""
            started.add(key)
            if len(started) == 2:
                both_started.set()
            await asyncio.wait_for(both_started.wait(), timeout=2)
            return json.dumps({"key": key, "amount": 4 if key == "a" else 9})

        def respond(items):
            values = outputs(items)
            if not values:
                return calls(("branch", "branch-a", {"key": "a"}),
                             ("branch", "branch-b", {"key": "b"}))
            assert {x["key"] for x in values} == {"a", "b"}
            return answer(str(sum(x["amount"] for x in values)))

        result = await Runner.run(Agent(name="Join", model=ScriptedModel(respond), tools=[branch]),
            "Combine two sources", max_turns=None, run_config=CONFIG)
        assert result.final_output == "13"
    asyncio.run(scenario())


def test_supported_checkpoint_roundtrip_does_not_repeat_prior_tool_work():
    async def scenario():
        executed = []

        @function_tool(failure_error_function=None)
        async def read_source() -> str:
            """Read a synthetic source before the interruption."""
            executed.append("read")
            return json.dumps({"source": "synthetic", "value": 19})

        @function_tool(needs_approval=True, failure_error_function=None)
        async def inspect_result(value: int) -> str:
            """Pause the SDK before a synthetic inspection; this is not Host approval."""
            executed.append("inspect")
            return json.dumps(value)

        def respond(items):
            values = outputs(items)
            if not values:
                return calls(("read_source", "read-1", {}))
            if len(values) == 1:
                return calls(("inspect_result", "inspect-1", {"value": values[0]["value"]}))
            return answer(f"Inspected {values[-1]}")

        model = ScriptedModel(respond)
        agent = Agent(name="Checkpoint", model=model, tools=[read_source, inspect_result])
        paused = await Runner.run(agent, "Inspect a result", max_turns=None, run_config=CONFIG)
        assert len(paused.interruptions) == 1 and executed == ["read"]
        saved = json.loads(json.dumps(paused.to_state().to_json(strict_context=True)))
        recovered = await RunState.from_json(agent, saved, strict_context=True)
        recovered.approve(recovered.get_interruptions()[0])
        result = await Runner.run(agent, recovered, run_config=CONFIG)
        assert result.final_output == "Inspected 19"
        assert executed == ["read", "inspect"]
        assert len(model.inputs) == 3
    asyncio.run(scenario())


def test_tool_denial_is_propagated_instead_of_becoming_false_completion():
    class CurrentAccessDenied(Exception):
        pass

    @function_tool(failure_error_function=None)
    async def protected_read() -> str:
        """Deny a synthetic resource through its authoritative execution facade."""
        raise CurrentAccessDenied("Denied")

    model = ScriptedModel(lambda _: calls(("protected_read", "denied-1", {})))
    import pytest
    from agents.exceptions import UserError
    with pytest.raises(UserError) as failure:
        asyncio.run(Runner.run(Agent(name="Denial", model=model, tools=[protected_read]),
            "Read", max_turns=None, run_config=CONFIG))
    assert isinstance(failure.value.__cause__, CurrentAccessDenied)
    assert len(model.inputs) == 1


def test_stop_cancels_active_tool_and_prevents_another_model_turn():
    async def scenario():
        started, cancelled = asyncio.Event(), asyncio.Event()

        @function_tool(failure_error_function=None)
        async def slow_read() -> str:
            """Wait until the synthetic controller cancels this operation."""
            started.set()
            try:
                await asyncio.Event().wait()
            finally:
                cancelled.set()
            return "unreachable"

        model = ScriptedModel(lambda _: calls(("slow_read", "slow-1", {})))
        task = asyncio.create_task(Runner.run(Agent(name="Stop", model=model, tools=[slow_read]),
            "Read", max_turns=None, run_config=CONFIG))
        await asyncio.wait_for(started.wait(), 2)
        task.cancel()
        import pytest
        with pytest.raises(asyncio.CancelledError):
            await task
        await asyncio.wait_for(cancelled.wait(), 2)
        assert len(model.inputs) == 1
    asyncio.run(scenario())


def test_actual_sdk_handoff_continues_with_result_dependent_specialist_work():
    from agents import handoff
    executed = []

    @function_tool(failure_error_function=None)
    async def read_lab_sample(sample_id: str) -> str:
        """Read one synthetic opaque sample through its governed facade."""
        executed.append(sample_id)
        return json.dumps({"sample": sample_id, "value": 23})

    def specialist_response(items):
        values = [value for value in outputs(items) if isinstance(value, dict) and "sample" in value]
        if not values:
            return calls(("read_lab_sample", "sample-read", {"sample_id": "synthetic-sample-1"}))
        return answer(f"The sample value is {values[-1]['value']}.")

    specialist_model = ScriptedModel(specialist_response)
    specialist = Agent(name="Lab specialist", model=specialist_model, tools=[read_lab_sample])
    root_model = ScriptedModel(lambda _: calls(("delegate_lab", "handoff-1", {})))
    root = Agent(name="Coordinator", model=root_model,
                 handoffs=[handoff(specialist, tool_name_override="delegate_lab")])
    result = asyncio.run(Runner.run(root, "Inspect the sample", max_turns=None, run_config=CONFIG))
    assert result.final_output == "The sample value is 23."
    assert executed == ["synthetic-sample-1"]
    assert len(root_model.inputs) == 1 and len(specialist_model.inputs) == 2
