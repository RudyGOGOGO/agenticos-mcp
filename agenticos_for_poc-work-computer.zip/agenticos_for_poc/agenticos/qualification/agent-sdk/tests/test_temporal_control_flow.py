"""Actual isolated Temporal server, SDK Activities, worker restart and replay."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from datetime import timedelta
import json
import os
import pytest
from uuid import uuid4

from agents.models.interface import ModelProvider
from temporalio import activity
from temporalio.common import RetryPolicy
from temporalio.contrib.openai_agents import OpenAIAgentsPlugin, ModelActivityParameters
from temporalio.converter import DataConverter
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker, Replayer

from agentic_os.adapters.local.artifacts import LocalKeys
from agentic_os.adapters.temporal.privacy import HistoryCodec, SafeFailureConverter, ENCODING
from workflow_fixture import SDKCompatibilityChain, SDKCompatibilityCheckpointChain, durable_advance
from test_openai_control_flow import ScriptedModel, calls, answer, outputs


@asynccontextmanager
async def bounded_worker(client, **options):
    with ThreadPoolExecutor(max_workers=4, thread_name_prefix="sdk-proof") as pool:
        async with Worker(client, workflow_task_executor=pool, max_cached_workflows=4,
            max_concurrent_workflow_tasks=4, max_concurrent_activities=4,
            graceful_shutdown_timeout=timedelta(seconds=3), **options) as worker:
            yield worker


@pytest.mark.parametrize('legacy',[False,True])
def test_protocol_metadata_real_temporal_restart_replays_original_activity_handoffs(proof_root,monkeypatch,legacy):
    from agentic_os_agent_worker import temporal_driver
    from agentic_os_agent_worker.temporal_runtime import agent_converter
    from agentic_os_agent_worker.protocol_metadata import ENCODING as METADATA
    from test_private_history import CreateStore,Keys,model_reference
    from test_checkpoint import paused
    from workflow_fixture import SDKProtocolMetadataCheckpoint
    async def run():
        item=await paused(private_input='PRIVATE_PROTOCOL_CHECKPOINT_CANARY')
        try:
            context=item['binding']['context'];saved=item['saved'];keys=Keys();store=CreateStore(context)
            workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
            converter=agent_converter(store,keys,context,'default',keys.active())
            reference=model_reference(context);operation=str(uuid4());checkpoint=str(uuid4());calls=[]
            class Boundary:
                async def accepted_model_operation(self,c,op):
                    assert c==context and op==operation;calls.append('accepted');return reference
                async def put_checkpoint(self,cp,state):
                    assert cp==checkpoint and state==saved;calls.append('save');return dict(kind='ready')
                async def get_checkpoint(self,c,cp):
                    assert c==context and cp==checkpoint;calls.append('checkpoint');return json.loads(json.dumps(saved,sort_keys=True))
            activities=temporal_driver.AgentActivities(Boundary())
            original_patched=temporal_driver.workflow.patched
            if legacy:
                # Produce the original marker-free /1 history, then replay it
                # using the ordinary current implementation on a fresh worker.
                monkeypatch.setattr(temporal_driver.workflow,'patched',lambda name:
                    False if name=='private-checkpoint-result-history-reuse/1' else original_patched(name))
            async with await WorkflowEnvironment.start_local(ip='127.0.0.1',ui=False,
                    dev_server_existing_path=os.environ['AGENTIC_OS_SDK_TEMPORAL_BINARY'],
                    dev_server_database_filename=str(proof_root/'protocol-history.sqlite'),data_converter=converter) as env:
                options=dict(task_queue='protocol-'+uuid4().hex,workflows=[SDKProtocolMetadataCheckpoint],
                    activities=[activities.accepted,activities.save,activities.load,activities.load_reuse])
                async with bounded_worker(env.client,**options):
                    handle=await env.client.start_workflow(SDKProtocolMetadataCheckpoint.run,
                        dict(context=context,operationId=operation,checkpointId=checkpoint,checkpoint=saved),id=workflow_id,
                        task_queue=options['task_queue'],execution_timeout=timedelta(seconds=60),
                        retry_policy=RetryPolicy(maximum_attempts=1))
                    async with asyncio.timeout(20):
                        while not await handle.query(SDKProtocolMetadataCheckpoint.is_ready):await asyncio.sleep(.05)
                assert calls==['accepted','save','checkpoint']
                monkeypatch.setattr(temporal_driver.workflow,'patched',original_patched)
                async with bounded_worker(env.client,**options):
                    assert await handle.query(SDKProtocolMetadataCheckpoint.is_ready)
                    await handle.signal(SDKProtocolMetadataCheckpoint.release)
                    assert await handle.result()==dict(reference=reference,saved=saved)
                history=await handle.fetch_history();raw=history.to_json().encode()
                assert b'PRIVATE_PROTOCOL_CHECKPOINT_CANARY' not in raw and context['scopeRef'].encode() not in raw
                encodings=[]
                for event in history.events:
                    if event.HasField('activity_task_scheduled_event_attributes'):
                        encodings.extend(p.metadata.get('encoding') for p in event.activity_task_scheduled_event_attributes.input.payloads)
                    if event.HasField('activity_task_completed_event_attributes'):
                        encodings.extend(p.metadata.get('encoding') for p in event.activity_task_completed_event_attributes.result.payloads)
                from agentic_os_agent_worker.private_history import ENCODING as PRIVATE
                assert encodings==[METADATA,METADATA,PRIVATE,PRIVATE,METADATA,PRIVATE]
                scheduled=[event.activity_task_scheduled_event_attributes for event in history.events if event.HasField('activity_task_scheduled_event_attributes')]
                completed=[event.activity_task_completed_event_attributes for event in history.events if event.HasField('activity_task_completed_event_attributes')]
                saved_frame=scheduled[1].input.payloads[0].SerializeToString(deterministic=True)
                loaded_frame=completed[2].result.payloads[0].SerializeToString(deterministic=True)
                assert (saved_frame==loaded_frame) is (not legacy)
                writes=len(store.writes)
                with ThreadPoolExecutor(max_workers=4,thread_name_prefix='protocol-replay') as pool:
                    await asyncio.wait_for(Replayer(workflows=[SDKProtocolMetadataCheckpoint],namespace='default',
                        workflow_task_executor=pool,data_converter=converter).replay_workflow(history),20)
                assert calls==['accepted','save','checkpoint'] and len(store.writes)==writes
                (proof_root/'protocol-history.json').write_text(history.to_json())
                (proof_root/'protocol-observations.json').write_text(json.dumps(dict(actualTemporal=True,
                    actualRegisteredActivities=True,workerInstances=2,replayed=True,activityCalls=3,
                    metadataFrames=3,privateCheckpointFrames=3,privateCanaryAbsent=True,
                    originalWritesReused=True,legacyHistory=legacy,actualSDKCheckpoint=True,liveProviderCalls=0)))
        finally:
            await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())


def test_cloud_mtls_transport_runs_shared_sdk_workflow_and_reuses_encrypted_closed_history(proof_root,monkeypatch):
    """Actual local TLS/service/API acceptance; no Cloud account qualification."""
    import ssl
    from temporalio.client import Client
    from temporalio.api.workflowservice.v1 import DescribeNamespaceRequest
    from agentic_os_agent_worker.temporal_cloud import CloudTemporalConnection
    from test_temporal_cloud import configuration
    value,tls=configuration();invoked=[];peers=[]
    for name,raw in [('server.pem',tls['server'][0]),('server.key',tls['server'][1])]:
        path=proof_root/name;path.write_bytes(raw);path.chmod(0o600)
    context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(str(proof_root/'server.pem'),str(proof_root/'server.key'))
    context.verify_mode=ssl.CERT_REQUIRED;context.load_verify_locations(cadata=tls['ca'].decode())
    context.set_alpn_protocols(['h2'])
    class Provider(ModelProvider):
        def get_model(self,name):
            def respond(items):invoked.append(activity.info().activity_id);return answer('Private Cloud transport accepted')
            return ScriptedModel(respond)
    async def run():
        namespace=value['namespace'];writers=set();tasks=set()
        async with await WorkflowEnvironment.start_local(ip='127.0.0.1',namespace=namespace,ui=False,
                dev_server_existing_path=os.environ['AGENTIC_OS_SDK_TEMPORAL_BINARY'],
                dev_server_database_filename=str(proof_root/'cloud-transport.sqlite')) as env:
            response=await env.client.workflow_service.describe_namespace(DescribeNamespaceRequest(namespace=namespace))
            value['namespaceId']=response.namespace_info.id
            value['retentionDays']=response.config.workflow_execution_retention_ttl.seconds//86400
            upstream=env.client.service_client.config.target_host.rsplit(':',1)
            async def proxy(reader,writer):
                task=asyncio.current_task();tasks.add(task);writers.add(writer);destination=None;pumps=[]
                try:
                    secure=writer.get_extra_info('ssl_object')
                    assert secure.selected_alpn_protocol()=='h2' and secure.getpeercert(binary_form=True)
                    peers.append(secure.version())
                    source,destination=await asyncio.open_connection(upstream[0],int(upstream[1]));writers.add(destination)
                    async def copy(source,target):
                        while raw:=await source.read(65536):target.write(raw);await target.drain()
                    pumps=[asyncio.create_task(copy(reader,destination)),asyncio.create_task(copy(source,writer))]
                    await asyncio.wait(pumps,return_when=asyncio.FIRST_COMPLETED)
                finally:
                    for pump in pumps:pump.cancel()
                    await asyncio.gather(*pumps,return_exceptions=True)
                    for stream in (writer,destination):
                        if stream is not None:stream.close();writers.discard(stream)
                    tasks.discard(task)
            server=await asyncio.start_server(proxy,'127.0.0.1',0,ssl=context)
            port=server.sockets[0].getsockname()[1];original=Client.connect
            async def routed(target,**kwargs):
                assert target==namespace+'.tmprl.cloud:7233'
                # Test-only DNS/route substitution; actual TLS still checks
                # the reviewed Cloud hostname and actual synthetic client cert.
                return await original('127.0.0.1:'+str(port),**kwargs)
            monkeypatch.setattr(Client,'connect',routed)
            directory=proof_root/'cloud-history-keys';directory.mkdir(mode=0o700)
            keys=LocalKeys(directory);keys.rotate()
            converter=DataConverter(payload_codec=HistoryCodec(keys,namespace,value['installationId']),
                failure_converter_class=SafeFailureConverter)
            plugin=OpenAIAgentsPlugin(model_provider=Provider(),add_temporal_spans=False,
                model_params=ModelActivityParameters(start_to_close_timeout=timedelta(seconds=10),
                    retry_policy=RetryPolicy(maximum_attempts=1)))
            try:
                connection=CloudTemporalConnection(value)
                client=await connection.connect(data_converter=converter,plugins=[plugin])
                queue='cloud-transport-'+uuid4().hex;ident='os:'+value['installationId']+':'+str(uuid4())+':'+str(uuid4())
                async with bounded_worker(client,task_queue=queue,workflows=[SDKCompatibilityCheckpointChain],activities=[durable_advance]):
                    handle=await client.start_workflow(SDKCompatibilityCheckpointChain.run,id=ident,task_queue=queue,
                        execution_timeout=timedelta(seconds=60),retry_policy=RetryPolicy(maximum_attempts=1))
                    assert await asyncio.wait_for(handle.result(),30)=='Private Cloud transport accepted'
                history=await handle.fetch_history()
                assert b'Private Cloud transport accepted' not in history.to_json().encode()
                (proof_root/'cloud-private-history.json').write_text(history.to_json())
                replacement=await connection.connect(data_converter=converter,plugins=[plugin])
                assert await replacement.get_workflow_handle(ident).result()=='Private Cloud transport accepted'
                assert len(invoked)==1 and peers
                (proof_root/'cloud-transport-proof.json').write_text(json.dumps(dict(actualLocalTemporal=True,
                    actualMutualTLS=True,cloudEndpointRoutedLocally=True,cloudQualified=False,sharedSDKWorkflow=True,
                    modelCalls=1,liveApiCalls=0,encryptedHistory=True,replacementReusedOriginal=True,
                    namespaceIdentityChecked=True,retentionChecked=True,databaseRestoreUsed=False)))
            finally:
                server.close()
                for writer in list(writers):writer.transport.abort()
                for task in list(tasks):task.cancel()
                await asyncio.gather(*list(tasks),return_exceptions=True)
                await asyncio.wait_for(server.wait_closed(),5)
    asyncio.run(run())


def test_private_payload_decode_exceeds_default_task_window_without_repeating_sdk_work(proof_root):
    from datetime import datetime,timezone
    from agentic_os_agent_worker.policy import WorkerPolicy
    async def scenario():
        decoded=[];invoked=[]
        class SlowHistoryCodec(HistoryCodec):
            def with_context(self,context):
                return SlowHistoryCodec(self.keys,self.namespace,self.installation_id,context)
            async def decode(self,payloads):
                payloads=await super().decode(list(payloads))
                # Delay the SDK model result inside workflow activation, rather
                # than the client's decoding of an already completed workflow.
                values=[json.loads(payload.data) for payload in payloads if payload.metadata.get('encoding')==b'json/plain']
                if not decoded and any(type(value) is dict and {'output','usage','response_id'}<=value.keys() for value in values):
                    interval=[datetime.now(timezone.utc),None];decoded.append(interval)
                    await asyncio.sleep(12)
                    interval[1]=datetime.now(timezone.utc)
                return payloads
        class Provider(ModelProvider):
            def get_model(self,name):
                assert name=='sdk-offline-proof'
                def respond(items):
                    invoked.append(activity.info().activity_id)
                    return answer('Private decode completed')
                return ScriptedModel(respond)
        installation=str(uuid4());ident=f'os:{installation}:{uuid4()}:{uuid4()}'
        key_dir=proof_root/'slow-codec-keys';key_dir.mkdir(mode=0o700)
        keys=LocalKeys(key_dir);keys.rotate()
        converter=DataConverter(payload_codec=SlowHistoryCodec(keys,'default',installation),
            failure_converter_class=SafeFailureConverter)
        policy=WorkerPolicy(45000);plugin=policy.plugin(Provider())
        async with await WorkflowEnvironment.start_local(ip='127.0.0.1',ui=False,
            dev_server_existing_path=os.environ['AGENTIC_OS_SDK_TEMPORAL_BINARY'],
            dev_server_database_filename=str(proof_root/'slow-codec.sqlite'),data_converter=converter,plugins=[plugin]) as env:
            queue='slow-codec-'+uuid4().hex
            async with bounded_worker(env.client,task_queue=queue,workflows=[SDKCompatibilityCheckpointChain],activities=[durable_advance]):
                handle=await env.client.start_workflow(SDKCompatibilityCheckpointChain.run,id=ident,task_queue=queue,
                    execution_timeout=timedelta(seconds=60),task_timeout=policy.workflow_task_timeout,
                    retry_policy=RetryPolicy(maximum_attempts=1))
                assert await asyncio.wait_for(handle.result(),50)=='Private decode completed'
            history=await handle.fetch_history()
        assert len(invoked)==len(decoded)==1
        start=history.events[0].workflow_execution_started_event_attributes
        assert start.workflow_execution_timeout.seconds==60 and start.workflow_task_timeout.seconds==45
        assert (decoded[0][1]-decoded[0][0]).total_seconds()>=11.5
        task_started={event.event_id:event.event_time.ToDatetime(tzinfo=timezone.utc) for event in history.events
            if event.HasField('workflow_task_started_event_attributes')}
        assert any(task_started[event.workflow_task_completed_event_attributes.started_event_id]<=decoded[0][0]
                and event.event_time.ToDatetime(tzinfo=timezone.utc)>=decoded[0][1]
            for event in history.events if event.HasField('workflow_task_completed_event_attributes'))
        assert not any(event.HasField('workflow_task_timed_out_event_attributes') for event in history.events)
        assert b'sdk-private-marker' not in history.to_json().encode()
        (proof_root/'slow-codec-observations.json').write_text(json.dumps(dict(result='passed',sdkModelCalls=1,
            decodeSeconds=round((decoded[0][1]-decoded[0][0]).total_seconds(),3),workflowTaskSeconds=45,
            originalExecutionSeconds=60,workflowTaskTimeouts=0,liveApiCalls=0)))
    asyncio.run(scenario())


def test_separate_durable_steps_survive_worker_restart_and_private_replay(proof_root):
    async def scenario():
        invoked_models, invoked_tools = [], []

        def respond(items):
            invoked_models.append(activity.info().activity_id)
            values = outputs(items)
            latest = values[-1] if values else 0
            if latest == 12:
                return answer("Reached twelve durable steps")
            return calls(("durable_advance", f"durable-{latest}", {"previous": latest}))

        class Provider(ModelProvider):
            def get_model(self, model_name):
                assert model_name == "sdk-offline-proof"
                return ScriptedModel(respond)

        @activity.defn(name="durable_advance")
        async def observed_advance(previous: int) -> str:
            invoked_tools.append((activity.info().activity_id, previous))
            return await durable_advance(previous)

        installation = str(uuid4())
        workflow_id = f"os:{installation}:{uuid4()}:{uuid4()}"
        key_dir = proof_root / "temporal-keys"
        key_dir.mkdir(mode=0o700)
        keys = LocalKeys(key_dir)
        keys.rotate()
        converter = DataConverter(payload_codec=HistoryCodec(keys, "default", installation),
                                  failure_converter_class=SafeFailureConverter)
        plugin = OpenAIAgentsPlugin(model_provider=Provider(), add_temporal_spans=False,
            model_params=ModelActivityParameters(start_to_close_timeout=timedelta(seconds=10),
                retry_policy=RetryPolicy(maximum_attempts=1)))
        async with await WorkflowEnvironment.start_local(ip="127.0.0.1", ui=False,
            dev_server_existing_path=os.environ["AGENTIC_OS_SDK_TEMPORAL_BINARY"],
            dev_server_database_filename=str(proof_root / "temporal.sqlite"),
            data_converter=converter, plugins=[plugin]) as env:
            queue = "sdk-proof-" + uuid4().hex
            options = dict(task_queue=queue, workflows=[SDKCompatibilityChain], activities=[observed_advance])
            async with bounded_worker(env.client, **options):
                handle = await env.client.start_workflow(SDKCompatibilityChain.run, id=workflow_id,
                    task_queue=queue, execution_timeout=timedelta(seconds=90),
                    retry_policy=RetryPolicy(maximum_attempts=1))
                async with asyncio.timeout(45):
                    while not await handle.query(SDKCompatibilityChain.is_ready):
                        await asyncio.sleep(.05)
                assert len(invoked_models) == 13
                assert [n for _, n in invoked_tools] == list(range(12))
            # A new worker has no sticky workflow cache. Accepted model/tool results
            # must be reconstructed from encrypted history, without another call.
            async with bounded_worker(env.client, **options):
                assert await handle.query(SDKCompatibilityChain.is_ready)
                await handle.signal(SDKCompatibilityChain.release)
                assert await handle.result() == "Reached twelve durable steps"
            history = await handle.fetch_history()
            assert len(invoked_models) == 13 and len(invoked_tools) == 12
            assert b"sdk-private-marker" not in history.to_json().encode()
            scheduled, completed = [], []
            for event in history.events:
                if event.HasField("activity_task_scheduled_event_attributes"):
                    attrs = event.activity_task_scheduled_event_attributes
                    scheduled.append(attrs.activity_id)
                    assert all(p.metadata["encoding"] == ENCODING for p in attrs.input.payloads)
                if event.HasField("activity_task_completed_event_attributes"):
                    completed.append(event.event_id)
                    assert all(p.metadata["encoding"] == ENCODING
                               for p in event.activity_task_completed_event_attributes.result.payloads)
            assert len(scheduled) == len(set(scheduled)) == len(completed) == 25
            with ThreadPoolExecutor(max_workers=4, thread_name_prefix="sdk-replay") as pool:
                await asyncio.wait_for(Replayer(workflows=[SDKCompatibilityChain],
                    namespace=env.client.namespace, workflow_task_executor=pool,
                    data_converter=converter, plugins=[plugin]).replay_workflow(history), 20)
            assert len(invoked_models) == 13 and len(invoked_tools) == 12
            (proof_root / "durable-observations.json").write_text(json.dumps({
                "modelActivities": 13, "toolActivities": 12, "workerInstances": 2,
                "historyReplay": "passed", "encryptedActivityPayloads": True,
                "liveApiCalls": 0, "sqlAccountingQualified": False,
            }, indent=2))
    asyncio.run(scenario())


def test_large_private_history_survives_restart_and_mixed_format_replay(proof_root):
    from agentic_os_agent_worker.private_history import AgentHistoryCodec,ENCODING as LEGACY,COMPRESSED_ENCODING
    from test_private_history import fixture
    from temporalio.converter import WorkflowSerializationContext
    from workflow_fixture import SDKPrivateHistoryCheckpoint,private_checkpoint_echo
    _,store,keys,context,workflow_id=fixture();invoked=[]
    converter=DataConverter(payload_codec=AgentHistoryCodec(store,keys,context,'default',key_id=keys.active()))
    private=dict(stateJson=json.dumps(dict(input='PRIVATE_LARGE_CHECKPOINT_MARKER'*3500,next='original approval')))
    @activity.defn(name="private_checkpoint_echo")
    async def observed(value:dict) -> dict:
        invoked.append(activity.info().activity_id)
        return await private_checkpoint_echo(value)
    async def scenario():
        async with await WorkflowEnvironment.start_local(ip='127.0.0.1',ui=False,
                dev_server_existing_path=os.environ['AGENTIC_OS_SDK_TEMPORAL_BINARY'],
                dev_server_database_filename=str(proof_root/'large-private-history.sqlite'),data_converter=converter) as env:
            options=dict(task_queue='private-checkpoint-'+uuid4().hex,workflows=[SDKPrivateHistoryCheckpoint],activities=[observed])
            async with bounded_worker(env.client,**options):
                handle=await env.client.start_workflow(SDKPrivateHistoryCheckpoint.run,private,id=workflow_id,
                    task_queue=options['task_queue'],execution_timeout=timedelta(seconds=60),
                    retry_policy=RetryPolicy(maximum_attempts=1))
                async with asyncio.timeout(30):
                    while not await handle.query(SDKPrivateHistoryCheckpoint.is_ready):await asyncio.sleep(.05)
            assert len(invoked)==1
            async with bounded_worker(env.client,**options):
                assert await handle.query(SDKPrivateHistoryCheckpoint.is_ready)
                await handle.signal(SDKPrivateHistoryCheckpoint.release)
                assert await handle.result()==private
            history=await handle.fetch_history();assert len(invoked)==1
            raw=history.to_json().encode();assert b'PRIVATE_LARGE_CHECKPOINT_MARKER' not in raw
            encodings=[]
            for event in history.events:
                if event.HasField('activity_task_scheduled_event_attributes'):
                    encodings.extend(payload.metadata.get('encoding') for payload in event.activity_task_scheduled_event_attributes.input.payloads)
                if event.HasField('activity_task_completed_event_attributes'):
                    encodings.extend(payload.metadata.get('encoding') for payload in event.activity_task_completed_event_attributes.result.payloads)
            assert encodings and all(value==COMPRESSED_ENCODING for value in encodings)
            # A small response is still the exact retained legacy format.
            assert (await env.client.data_converter.with_context(
                WorkflowSerializationContext('default',workflow_id)).encode([True]))[0].metadata['encoding']==LEGACY
            with ThreadPoolExecutor(max_workers=4,thread_name_prefix='private-checkpoint-replay') as pool:
                await asyncio.wait_for(Replayer(workflows=[SDKPrivateHistoryCheckpoint],namespace='default',
                    workflow_task_executor=pool,data_converter=converter).replay_workflow(history),20)
            assert len(invoked)==1
            (proof_root/'large-private-history-observations.json').write_text(json.dumps(dict(
                activityCalls=1,workerInstances=2,actualTemporalReplay=True,privateMarkerAbsent=True,
                completePayloadRestored=True,mixedLegacySupported=True,liveProviderCalls=0)))
    asyncio.run(scenario())


def test_supported_sdk_state_continues_across_temporal_run_segments(proof_root):
    async def scenario():
        model_calls, tool_values = [], []

        def respond(items):
            model_calls.append(activity.info().workflow_run_id)
            values = outputs(items)
            latest = values[-1] if values else 0
            if latest == 3:
                return answer("Completed one goal across durable segments")
            return calls(("durable_advance", f"segment-{latest}", {"previous": latest}))

        class Provider(ModelProvider):
            def get_model(self, model_name):
                assert model_name == "sdk-offline-proof"
                return ScriptedModel(respond)

        @activity.defn(name="durable_advance")
        async def observed_advance(previous: int) -> str:
            tool_values.append(previous)
            return await durable_advance(previous)

        installation = str(uuid4())
        workflow_id = f"os:{installation}:{uuid4()}:{uuid4()}"
        key_dir = proof_root / "segment-keys"
        key_dir.mkdir(mode=0o700)
        keys = LocalKeys(key_dir)
        keys.rotate()
        converter = DataConverter(payload_codec=HistoryCodec(keys, "default", installation),
                                  failure_converter_class=SafeFailureConverter)
        plugin = OpenAIAgentsPlugin(model_provider=Provider(), add_temporal_spans=False,
            model_params=ModelActivityParameters(start_to_close_timeout=timedelta(seconds=10),
                retry_policy=RetryPolicy(maximum_attempts=1)))
        async with await WorkflowEnvironment.start_local(ip="127.0.0.1", ui=False,
            dev_server_existing_path=os.environ["AGENTIC_OS_SDK_TEMPORAL_BINARY"],
            dev_server_database_filename=str(proof_root / "segments.sqlite"),
            data_converter=converter, plugins=[plugin]) as env:
            queue = "sdk-segments-" + uuid4().hex
            async with bounded_worker(env.client, task_queue=queue,
                workflows=[SDKCompatibilityCheckpointChain], activities=[observed_advance]):
                result = await asyncio.wait_for(env.client.execute_workflow(
                    SDKCompatibilityCheckpointChain.run, id=workflow_id, task_queue=queue,
                    execution_timeout=timedelta(seconds=60), retry_policy=RetryPolicy(maximum_attempts=1)), 45)
            assert result == "Completed one goal across durable segments"
            assert tool_values == [0, 1, 2]
            assert len(model_calls) == len(set(model_calls)) == 4
            (proof_root / "segmented-observations.json").write_text(json.dumps({
                "modelCalls": 4, "toolCalls": 3, "workflowRuns": 4,
                "sameWorkflowIdentity": True, "sdkStateFormat": "RunState.to_json/from_json",
                "workflowContinuation": "Temporal continue_as_new", "liveApiCalls": 0,
                "largeArtifactClaimCheckQualified": False,
            }, indent=2))
    asyncio.run(scenario())
