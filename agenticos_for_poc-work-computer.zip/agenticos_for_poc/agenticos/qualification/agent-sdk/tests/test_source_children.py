"""Actual SDK source checkpoint flows into data-dependent or empty child work."""
import asyncio
from copy import deepcopy
import json
from types import SimpleNamespace

from agents import RunConfig
from agents.models.interface import ModelProvider
import pytest

from agentic_os_agent_worker import child_read_journey as journey
from agentic_os_agent_worker.checkpoint import tool_alias
from agentic_os_agent_worker.sdk_model import BINDING_KEY
from agentic_os_agent_worker.transport import _validate
from test_parallel_children import fixture,Driver,Rollover,sample
from test_sdk_tools import Boundary,ModelCalls


def test_reduction_planner_contract_resolves_every_reference_and_keeps_the_closed_intent(record_property):
    from jsonschema import Draft202012Validator,ValidationError
    from agentic_os_agent_worker.read_journey import source_objective_instructions
    value,_=fixture();capabilities=value['start']['capabilities']
    providers=[dict(capability=item['capability'],providerRef='synthetic.current') for item in capabilities]
    instructions=source_objective_instructions(capabilities,providers,reduction=True)
    definitions=json.loads(instructions.split('matching these closed contracts: ',1)[1].split('. Exactly one source',1)[0])
    schema=dict(**{'$ref':'#/$defs/AgentSourceChildReductionIntentDraft','$defs':definitions})
    validator=Draft202012Validator(schema);draft=sample('AgentSourceChildReductionIntentDraft');validator.validate(draft)
    with pytest.raises(ValidationError):validator.validate(dict(draft,unexpectedGrant=True))
    assert instructions.startswith('Interpret the original user goal')
    record_property('planner_instruction_bytes',len(instructions.encode()))


@pytest.mark.parametrize('identifiers',[['00007','another-record','00007'],[]])
@pytest.mark.parametrize('reduction',[False,True,'parallel','join','paged-join'])
def test_actual_source_sdk_checkpoint_preserves_refs_and_uses_kernel_target_count(monkeypatch,identifiers,reduction,retained_source=False):
    value,page=fixture();value.update(schema='agent-paged-source-child-join-journey/1' if reduction=='paged-join' else 'agent-source-child-join-journey/1' if reduction=='join' else 'agent-parallel-source-child-reduction-journey/1' if reduction=='parallel' else 'agent-source-child-reduction-journey/1' if reduction else 'agent-source-child-read-journey/1',phase='source',
        goalDigest='a'*64,goalDraftJson='{"criteria":[],"target":{}}')
    if retained_source:
        from agentic_os.production.source_goal_retention import profile_pin
        context=value['start']['context'];context['harness']=profile_pin()
        from uuid import UUID,uuid5
        value['binding']['context']=deepcopy(context)
        value['binding']['sdkInstanceId']=str(uuid5(UUID(context['taskId']),'sdk-instance/1'))
        page['context']=deepcopy(context)
        for child in page['items']:child['scope']['goal']['context']=deepcopy(context)
    item=page['items'][0];models={};checkpoints={};accepted={};stored=[];rollovers=[]
    context=value['start']['context']
    expected='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,is_continue_as_new_suggested=lambda:False,
        get_current_history_length=lambda:1))
    class Router(ModelCalls):
        async def get_response(self,system_instructions,input,*args,**kwargs):
            settings=kwargs.get('model_settings') if 'model_settings' in kwargs else args[0]
            ident=json.loads(settings.metadata[BINDING_KEY])['sdkInstanceId']
            model=models.setdefault(ident,ModelCalls(self.name,count=1))
            return await model.get_response(system_instructions,input,*args,**kwargs)
    class Provider(ModelProvider):
        def get_model(self,name):return Router(tool_alias(value['start']['capabilities'][0]['capability']))
    monkeypatch.setattr(journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    class Kernel(Boundary):
        source=deepcopy(item)
        async def child_source_state(self,*args):
            assert not reduction
            return self.source_state()
        async def child_source_reduction_state(self,*args):
            assert reduction
            return self.source_state()
        async def child_source_join_state(self,*args):
            assert reduction=='join'
            return self.source_state()
        async def child_paged_source_join_state(self,*args):
            assert reduction=='paged-join'
            return self.source_state()
        def source_state(self):
            count=None if self.source['state']!='COMPLETED' else len(dict.fromkeys(identifiers))
            return dict(kind='ready',context=deepcopy(value['start']['context']),source=deepcopy(self.source),
                targetCount=count,goalDigest=None if count is None else 'b'*64)
        async def child_start(self,*args):
            self.source['state']='ACTIVE';return dict(kind='ready',item=deepcopy(self.source))
        async def accepted_model_operation(self,context,operation):
            result=await super().accepted_model_operation(context,operation);accepted[operation]=result;return result
        async def execute_tool(self,request):
            result=await super().execute_tool(request);page=json.loads(result['accepted']['payloadJson'])
            scope=self.source['scope'];criterion=scope['goal']['criteria'][0];selection=criterion['resources'][0]
            resource=sample('ResourceRef');resource.update(subject=deepcopy(request['context']['subject']),
                providerId=selection['providerRef'],resourceType=selection['resourceType'],externalId=selection['externalId'])
            page['evidence'].update(providerRef=selection['providerRef'],resourceRefs=[resource],publicFields=[criterion['fields'][0]])
            page['records']=[[dict(name=criterion['fields'][0],value=json.dumps(identifiers))]]
            _validate('EvidencePage',page);stored.append(deepcopy(page))
            result['accepted']['payloadJson']=json.dumps(page);return result
        async def put_checkpoint(self,ident,envelope):
            checkpoints[ident]=deepcopy(envelope);return dict(kind='ready')
        async def child_checkpoint(self,context,operation,child,ident):
            self.source['checkpointId']=ident;return deepcopy(self.source)
        async def get_checkpoint(self,context,ident):return deepcopy(checkpoints[ident])
        async def child_complete(self,context,operation,child):
            self.source.update(state='COMPLETED',verification=dict(childId=child,scopeDigest='a'*64,candidate=accepted[operation]))
            return dict(kind='completed',item=deepcopy(self.source))
    class SourceDriver(Driver):
        pending_control=None
        async def _save(self,boundary,ident,envelope):return await boundary.put_checkpoint(ident,envelope)
    def rollover(next_value):
        if retained_source:
            from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
            from agentic_os_agent_worker.read_journey import start_contract
            converter=AgentPayloadConverter();next_value=converter.from_payloads(converter.to_payloads([next_value]))[0]
            _validate(start_contract(next_value),next_value)
        rollovers.append(deepcopy(next_value));raise Rollover()
    monkeypatch.setattr(journey.workflow,'continue_as_new',rollover)
    async def run():
        kernel=Kernel()
        selected=journey.run_source_child
        if retained_source:
            from agentic_os_agent_worker import read_journey
            from agentic_os_agent_worker.logical_query_journey import selected as logical_selected
            assert not logical_selected(value['start']['context'])
            from agentic_os_agent_worker import temporal_driver
            class RoutedKernel(Kernel):
                def __init__(self,*_):self.__dict__=kernel.__dict__
            monkeypatch.setattr(temporal_driver,'WorkflowBoundary',RoutedKernel)
            selected=lambda driver,current,boundary:read_journey.run_read_journey(driver,current)
        before_phase_ack=deepcopy(value)
        with pytest.raises(Rollover):await selected(SourceDriver(),value,kernel)
        assert len(kernel.requests)==len(checkpoints)==len(stored)==1 and len(accepted)==2
        assert len(rollovers)==1 and rollovers[0]['phase']==('children' if identifiers else 'execution')
        assert rollovers[0]['goalDigest']=='b'*64 and rollovers[0]['childContinuation'] is None
        assert len(rollovers[0]['binding']['inputResults'])==1
        model=next(iter(models.values()));assert len(model.inputs)==2
        compact=json.loads(next(i['output'] for i in model.inputs[1] if i.get('type')=='function_call_output'))
        assert compact['schema']=='agent-accepted-read-ref/1' and 'page' not in compact
        assert json.dumps(identifiers) not in json.dumps(compact)
        with pytest.raises(Rollover):await selected(SourceDriver(),before_phase_ack,kernel)
        assert len(kernel.requests)==len(checkpoints)==len(stored)==1 and len(accepted)==2
        assert len(rollovers)==2 and rollovers[1]['binding']==rollovers[0]['binding']
        assert rollovers[1]['phase']==rollovers[0]['phase'] and rollovers[1]['goalDigest']==rollovers[0]['goalDigest']
    asyncio.run(run())


@pytest.mark.parametrize('paged',[False,True])
def test_join_planner_contract_is_closed_and_declares_explicit_subset_policy(paged):
    from jsonschema import Draft202012Validator,ValidationError
    from agentic_os_agent_worker.read_journey import source_objective_instructions
    value,_=fixture();capabilities=value['start']['capabilities']
    providers=[dict(capability=item['capability'],providerRef='synthetic.current') for item in capabilities]
    instructions=source_objective_instructions(capabilities,providers,join=True,paged=paged)
    definitions=json.JSONDecoder().raw_decode(instructions.split('matching these closed contracts: ',1)[1])[0]
    name='AgentPagedSourceChildJoinIntentDraft' if paged else 'AgentSourceChildJoinIntentDraft'
    schema={'$ref':'#/$defs/'+name,'$defs':definitions}
    validator=Draft202012Validator(schema);draft=sample(name)
    for policy in ({'kind':'all'},{'kind':'any'},{'kind':'quorum','minimum':2}):validator.validate(dict(draft,joinPolicy=policy))
    for policy in ({'kind':'quorum','minimum':0},{'kind':'any','grant':True},{'kind':'unreviewed'}):
        with pytest.raises(ValidationError):validator.validate(dict(draft,joinPolicy=policy))
    assert 'subset cannot certify an exhaustive claim' in instructions
    if paged:
        for size in (0,65,True):
            with pytest.raises(ValidationError):validator.validate(dict(draft,pageResources=size))


def test_retained_source_entry_preserves_actual_sdk_checkpoint_and_serialized_handoff(monkeypatch):
    test_actual_source_sdk_checkpoint_preserves_refs_and_uses_kernel_target_count(monkeypatch,['00007','another-record','00007'],False,retained_source=True)


def test_retained_query_pin_keeps_existing_single_intent_wire_and_logical_selection_separate():
    from agentic_os.production.source_goal_retention import profile_pin
    from agentic_os_agent_worker.logical_query_journey import selected
    from agentic_os_agent_worker.read_journey import start_contract
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    value=sample('AgentSDKQuerySourceChildJoinJourneyStart');value['start']['context']['harness']=profile_pin()
    converter=AgentPayloadConverter();value=converter.from_payloads(converter.to_payloads([value]))[0]
    assert start_contract(value)=='AgentSDKQuerySourceChildJoinJourneyStart'
    _validate(start_contract(value),value);assert not selected(value['start']['context'])
    value['start']['context']['harness']['revision']=3;assert selected(value['start']['context'])
