"""Source-dependent selection through the real SDK entry and exact consumer."""
import asyncio
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from uuid import uuid4

from agents import RunConfig
from agents.models.interface import ModelProvider
import pytest
from temporalio.converter import WorkflowSerializationContext

from agentic_os.contracts.canonical import digest
from agentic_os_agent_worker import read_journey
from agentic_os_agent_worker.checkpoint import tool_alias
from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
from agentic_os_agent_worker.transport import _validate
from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,ReadControl
from agentic_os_agent_worker.private_history import AgentHistoryCodec,MAX_RAW_PAYLOAD
from test_lookup_read import Rollover,sample,binding_fixture,Boundary,item_fixture,ScriptedModel,calls,answer,accepted_for
from test_private_history import Keys,Store


@pytest.mark.parametrize('outcome,changed_winner',[('dependent-iteration',False),('dependent-iteration',True),('result-followup',False)])
def test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(monkeypatch,tmp_path,outcome,changed_winner,*,premature=False,wrong_grain=False,malformed_tool=False,missing_page=False,source_rounds=False,core_incomplete=False,rejected_goal=False,source_contract=False,repeat_incomplete=False,metric_grain=False,null_key=False,targeted_source=False,targeted_completion=False,query_links=False,retain_links=False,repeat_query_links=False,invalid_completion=None,retain_nulls=False,predicate_instructions=False,dependent_semantics=False,schema_once=False):
    root=Path(__file__).parents[3]
    frozen=json.loads((root/'qualification/production-agent/fixtures/host-outcomes-v1.json').read_bytes())
    bank=json.loads((root/'qualification/production-agent/fixtures/english-task-bank-v1.json').read_bytes())
    question=next(row['question'] for row in bank['cases'] if row['id']==outcome)
    spec=importlib.util.spec_from_file_location('dependent_provider_fixture',root/'tests/integration/resources/analysis_fixture.py')
    fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
    value=sample('AgentSDKAdaptiveAnalysisJourneyStart');_,_,binding=binding_fixture();context=deepcopy(binding['context'])
    utility=item_fixture();utility['capability']['ref']='owned.utility-discovery'
    text=dict(type='string');cursor=dict(anyOf=[text,dict(type='null')])
    def schema(properties):return json.dumps(dict(type='object',properties=properties,required=list(properties),additionalProperties=False))
    utility['inputSchemaJson']=schema(dict(q=text,cursor=cursor))
    primary=deepcopy(utility);primary['capability']['ref']='owned.allocation-rows'
    primary['inputSchemaJson']=schema(dict(utility_id=dict(type='integer',minimum=1),start=text,end=text,cursor=cursor))
    primary['description']='Posted allocations. Declared period: '+frozen['window']['startDate']+'..'+frozen['window']['endDateInclusive']+'.'
    scoped=deepcopy(primary);scoped['capability']['ref']='owned.property-allocations'
    scoped['inputSchemaJson']=schema(dict(utility_id=dict(type='integer',minimum=1),start=text,end=text,cursor=cursor,property_id=dict(type='integer',minimum=1)))
    grain=['billId','lineId','allocationId','propertyId','currency']
    for item in (primary,scoped):item['outputSchemaJson']=json.dumps(dict(type='object',properties=dict(grain=dict(const=grain),pageGroupFields=dict(const=[]))))
    discovery=[utility['capability'],primary['capability']]
    context['harness']['ref']='adaptive-analysis-discovery/'+digest('manifest',discovery)
    value['start'].update(context=context,input=question,capabilities=[utility,primary,scoped],checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        discoveryCapabilities=discovery,providers=[dict(capability=item['capability'],providerRef='synthetic.read') for item in (utility,primary,scoped)])
    _validate('AgentSDKAdaptiveAnalysisJourneyStart',value)
    # Realistic source IDs differ from frozen logical fixture names. The second
    # vector changes the winning data, not the worker's configuration or prompt.
    ids=dict(p1='831',p2='941',p4='672');rows=[]
    for bill in frozen['warehouse']['bills']:
        if bill['id'] not in frozen['warehouse']['golden']['eligibleBills']:continue
        for line in bill['lines']:
            for allocation in line['allocations']:
                rows.append(dict(billId=bill['id'],invoiceNumber=bill['id'],lineId=line['id'],allocationId=allocation['id'],
                    propertyId=ids[allocation['property']],property='Property '+allocation['property'],currency=bill['currency'],
                    allocatedNet='1.00' if changed_winner and bill['id']=='bill-005' else allocation['net'],billFaceAmount=bill['faceAmount']))
    winner='p1' if changed_winner else 'p2';queue=[];saved={};material=[];drafts=[];goals=[];computed=[];scoped_calls=[];completion_operations=[];source_choices=[];completion_choices=[];retained_null_proposals=[]
    if source_contract:
        for item,fields in [(utility,['utilityId','name']),(primary,list(rows[0])),(scoped,list(rows[0]))]:
            shape=json.loads(item['outputSchemaJson']);shape.setdefault('properties',{})['page']=dict(properties=dict(
                evidence=dict(properties=dict(publicFields=dict(const=fields))),
                records=dict(items=dict(items=dict(properties=dict(value=dict(anyOf=[dict(type='string'),dict(type='null')])))))))
            item['outputSchemaJson']=json.dumps(shape)
    converter=AgentPayloadConverter();kernel=Boundary();replay=[]
    def wire(document):
        payload=converter.to_payloads([document])[0];assert len(payload.SerializeToString(deterministic=True))<=65536
        return converter.from_payloads([payload])[0]
    def rollover(document,**options):queue.append(wire(document));raise Rollover()
    workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    keys=Keys();history_store=Store(context);checkpoint_sizes=[]
    codec=AgentHistoryCodec(history_store,keys,context,'default',key_id=keys.active()).with_context(WorkflowSerializationContext('default',workflow_id))
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=workflow_id,is_continue_as_new_suggested=lambda:True,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:name in {'analysis-output-contracts/1','analysis-goal-schema-feedback/1'}
        or targeted_source and name=='analysis-targeted-source-read/1'
        or targeted_completion and name in {'analysis-bound-goal-tools/1','analysis-targeted-completion-read/1','analysis-incomplete-feedback-window/1','analysis-repeated-completion-control/1'}
        or source_rounds and name=='analysis-discovery-round-window/1'
        or core_incomplete and name in {'analysis-incomplete-feedback-window/1','analysis-dependent-goal-identity-check/1','analysis-repeated-completion-control/1'}
        or rejected_goal and name=='analysis-goal-feedback-source-window/1'
        or query_links and name=='analysis-goal-query-links/1'
        or retain_links and name=='analysis-query-link-repair-window/1'
        or invalid_completion and name=='analysis-completion-contract-repair/1'
        or retain_nulls and name=='analysis-null-key-repair-window/1'
        or predicate_instructions and name=='analysis-null-predicate-instructions/1'
        or dependent_semantics and name=='analysis-dependent-measure-and-source-chain/1'
        or schema_once and name=='analysis-structured-goal-schema-once/1'
        or null_key and name in {'analysis-nonnull-metric-keys/1','analysis-goal-feedback-source-window/1'}
        or metric_grain and name in {'analysis-source-measurement-identity/1','analysis-goal-feedback-source-window/1'}
        or source_contract and name in {'analysis-source-reads-before-goal/1','analysis-declared-source-output-schema/1'}
        or missing_page and name in {'analysis-answer-reference-feedback/1','analysis-complete-page-chain-feedback/1','analysis-feedback-window/1'}
        or not changed_winner and name in {'analysis-dependent-selectors-before-goal/1','analysis-dependent-source-before-goal/1','analysis-typed-feedback-message/1','analysis-shared-source-schemas/1','analysis-exact-source-shape-feedback/1','analysis-tool-argument-feedback/1'})
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    async def accepted(self,c,operation):return await kernel.accepted_model_operation(c,operation)
    async def checkpoint(self,c,ident):return deepcopy(saved[ident])
    async def execute(self,request):
        args=json.loads(request['argumentsJson']);capability=request['capability']
        if capability==utility['capability']:
            assert args==dict(q='',cursor=None)
            actual=[dict(utilityId='741',name='water')];actual_grain=['utilityId'];ordinal=0;next_cursor=None;expected=1
        else:
            assert {k:v for k,v in args.items() if k not in {'cursor','property_id'}}==dict(utility_id=741,start=frozen['window']['startDate'],end=frozen['window']['endDateInclusive'])
            actual_grain=grain;ordinal=0;next_cursor=None;actual=rows;expected=len(rows)
            if capability==scoped['capability']:
                assert goals and int(ids[winner])==args['property_id']
                scoped_calls.append(args)
                actual=[row for row in rows if row['propertyId']==str(args['property_id'])];expected=len(actual)
                assert args['cursor'] in {None,'scoped-next'}
                if args['cursor'] is None:actual=[];next_cursor='scoped-next'
                else:ordinal=1
            else:assert capability==primary['capability'] and args['cursor'] is None
        response=accepted_for(request,query=True);source=response['accepted'];page=json.loads(source['payloadJson'])
        page.update(queryDigest=digest('command',{k:v for k,v in args.items() if k!='cursor'}),requestCursor=args['cursor'],pageOrdinal=ordinal,grain=actual_grain,pageGroupFields=[])
        columns=list(actual[0]) if actual else list(rows[0]);e=page['page']['evidence']
        e.update(id=str(uuid4()),subject=context['subject'],providerRef='synthetic.read',publicFields=columns,
            resourceRefs=[dict(subject=context['subject'],providerId='synthetic.read',resourceType='bill-allocation',contractVersion=1,
                externalId=row.get('allocationId','utility/741'),observedVersion='e'*64) for row in actual])
        page['page'].update(records=[[dict(name=k,value=v) for k,v in row.items()] for row in actual],nextCursor=next_cursor)
        e['coreDigest']=digest('evidence',dict(evidence={k:v for k,v in e.items() if k!='coreDigest'},records=page['page']['records']))
        page['coverage'].update(queryRef='query/'+page['queryDigest'],snapshotRef='snapshot/'+digest('command',dict(capability=capability,query=page['queryDigest'])),
            observedRows=len(actual),expectedRows=expected,status='partial' if next_cursor else 'complete',nextCursorRef='cursor/'+digest('command',next_cursor) if next_cursor else None)
        page['coverage']['coveredScopeRef']=page['coverage']['requestedScopeRef']
        source['payloadJson']=json.dumps(page);source['result'].update(subject=context['subject'],rootId=context['rootId'],taskId=context['taskId'])
        source['result']['payload']['bytes']=len(source['payloadJson'].encode())
        material.append(dict(result=source['result'],binding=source['binding'],query=page,page=page['page']))
        return response
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',checkpoint);monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    class Model(ScriptedModel):
        injected=False
        goal_rejected=False
        late_null=False
        async def get_response(self,system_instructions,input,*args,**kwargs):
            schema=kwargs.get('output_schema',args[2] if len(args)>2 else None);tools=kwargs.get('tools',args[1] if len(args)>1 else None)
            if 'Accepted query and metric criteria: ' not in system_instructions:
                if schema_once:
                    from agentic_os_agent_worker.memory_output import AnalysisOutput
                    assert 'Schema: ' not in system_instructions
                    assert 'structured response format supplies the complete closed goal schema' in system_instructions
                    assert schema.json_schema()==AnalysisOutput(objective=True).json_schema()
                    assert schema.is_strict_json_schema() and schema.name()=='AgentAnalysisGoalDraft'
                if source_contract:
                    settings=kwargs.get('model_settings',args[0] if args else None)
                    from agentic_os_agent_worker.memory_output import analysis_source_read_required,analysis_source_read_choice
                    required=analysis_source_read_required(input,[tool.name for tool in tools],context)
                    choice=analysis_source_read_choice(input,[tool.name for tool in tools],context) if targeted_source else 'required' if required else None
                    assert settings.tool_choice==choice
                    if targeted_source and choice==tool_alias(primary['capability']):
                        source_choices.append(choice)
                        # Re-reading the same accepted utility metadata after
                        # this feedback must not satisfy the missing source.
                        from agents.exceptions import ModelBehaviorError
                        utility_call=next(deepcopy(v) for v in input if v.get('type')=='function_call' and v['name']==tool_alias(utility['capability']))
                        utility_output=next(deepcopy(v) for v in input if v.get('type')=='function_call_output' and v['call_id']==utility_call['call_id'])
                        utility_call['call_id']=utility_output['call_id']='unrelated-utility-repeat'
                        repeated=[*input,utility_call,utility_output]
                        assert analysis_source_read_choice(repeated,[tool.name for tool in tools],context)==choice
                        foreign=deepcopy(utility_output);foreign['call_id']='foreign-source'
                        foreign_value=json.loads(foreign['output']);foreign_value['result']['rootId']=str(uuid4())
                        foreign['output']=json.dumps(foreign_value)
                        with pytest.raises(ModelBehaviorError):analysis_source_read_choice(
                            [*input,dict(utility_call,call_id='foreign-source',name=choice),foreign],[tool.name for tool in tools],context)
                    declared=schema.json_schema()['$defs']['AgentExactFilter']['properties']
                    assert {v['type'] for v in declared['value']['anyOf']}=={'string','null'}
                    assert 'property_id' not in declared['field']['enum'] and 'propertyId' in declared['field']['enum']
                assert ('resolve that selection through current discovery reads' in system_instructions)==(not changed_winner)
                assert ('one complete immutable goal containing EVERY requested answer' in system_instructions)==(not changed_winner)
                metadata=json.JSONDecoder().raw_decode(system_instructions.split('Reviewed metadata: ',1)[1])[0]
                restored=deepcopy(metadata['capabilities'])
                for item in restored:
                    if 'sharedOutputSchema' in item:
                        item['outputSchemaJson']=metadata['sharedOutputSchemas'][item.pop('sharedOutputSchema')]
                assert restored==value['start']['capabilities'] and metadata['providers']==value['providers']
            if targeted_completion and goals:
                settings=kwargs.get('model_settings',args[0] if args else None)
                assert {tool.name for tool in tools}=={tool_alias(primary['capability']),tool_alias(scoped['capability'])}
                if settings.tool_choice is not None:
                    assert settings.tool_choice==tool_alias(scoped['capability'])
                    completion_choices.append(settings.tool_choice)
            result=fixture.property_composition_step(value,dict(input=input,instructions=system_instructions,tools=[dict(name=tool.name) for tool in tools]),outcome=outcome,malformed_discovery=malformed_tool,missing_completion_page=missing_page,invalid_goal=rejected_goal or null_key)
            injected=False;grain_injected=False;tool_injected=False;page_injected=False;core_injected=False;goal_injected=False;metric_injected=False;null_injected=False
            query_injected=False
            if (targeted_completion and not self.injected and goals and result[0]['type']=='function_call'
                    and result[0]['name']==tool_alias(scoped['capability'])):
                # Captured failure: omit the entire second query, rather than
                # a reference to an already completed source read.
                current_calls={row['call_id']:row['name'] for row in input if row.get('type')=='function_call'}
                partial=dict(goalDigest=digest('command',goals[0]),results=[json.loads(row['output'])['result'] for row in input
                    if row.get('type')=='function_call_output' and current_calls.get(row['call_id'])==tool_alias(primary['capability'])])
                assert partial['results'] and not scoped_calls
                result=[dict(type='message',content=[dict(type='output_text',text=json.dumps(partial))])]
                self.injected=True;query_injected=True
            if null_key and self.goal_rejected and not goals:
                assert 'filters a required non-null' in json.dumps(input)
                assert input[0]==dict(role='user',content=question)
                assert not any(item.get('type')=='reasoning' for item in input)
            if null_key and not self.goal_rejected and result[0]['type']=='message' and 'Accepted query and metric criteria: ' not in system_instructions:
                malformed=json.loads(result[0]['content'][0]['text'])
                if len(malformed['queries'])==2:
                    metric=malformed['criteria'][1]
                    assert any(rule['value'] is None and rule['field'] in metric['populationFields'] for rule in metric['populationFilters'])
                    self.injected=True;self.goal_rejected=True;null_injected=True
            if repeat_query_links and self.goal_rejected and not goals:
                result=[dict(type='message',content=[dict(type='output_text',text=json.dumps(drafts[-1]))])]
            if rejected_goal and self.goal_rejected and not goals:
                from agentic_os_agent_worker.memory_output import ANALYSIS_GOAL_FEEDBACK
                messages=[item for item in input if item.get('role')=='assistant']
                assert len(messages)==(2 if retain_links else 1)
                assert ANALYSIS_GOAL_FEEDBACK in str(messages[-1]['content'])
                if retain_links:
                    # Retention supplies context, never an accepted goal: this
                    # fixture's wrong winner must still be corrected downstream.
                    assert json.loads(messages[0]['content'][0]['text'])==drafts[-1]
                    assert not goals
                assert not any(item.get('type')=='reasoning' for item in input)
                assert input[0]==dict(role='user',content=question)
                assert any(item.get('type')=='function_call_output' for item in input)
                if query_links:
                    feedback=messages[-1]['content'][0]['text']
                    issues=json.loads(feedback.split('Issues: ',1)[1])
                    issue=next(text for text in issues if text.startswith('Every criterion queryKey'))
                    assert 'Declared queries[*].key values:' in issue and '"queryKey":"unbound-rejected-query"' in issue
                    assert 'Multiple criteria may share one query.' in issue
                    assert all(query['key'] in issue for query in drafts[-1]['queries'])
            if retain_links and (metric_grain or null_key) and self.injected and not goals:
                from agentic_os_agent_worker.memory_output import ANALYSIS_GOAL_FEEDBACK
                messages=[item for item in input if item.get('role')=='assistant']
                assert len(messages) in ({1,2} if retain_nulls else {1})
                assert ANALYSIS_GOAL_FEEDBACK in str(messages[-1]['content'])
                if retain_nulls and len(messages)==2:
                    assert json.loads(messages[0]['content'][0]['text'])==drafts[-1]
                    assert 'Invalid predicates: ' in str(messages[-1]['content'])
                    invalid_index=len(drafts[-1]['criteria'][1]['populationFilters'])-1
                    assert 'populationFilters['+str(invalid_index)+']' in str(messages[-1]['content'])
                    assert drafts[-1]['criteria'][1]['populationFilters'][-1]['field'] in str(messages[-1]['content'])
                    retained_null_proposals.append(deepcopy(drafts[-1]))
                    if predicate_instructions:
                        assert 'criteria[1].populationFilters['+str(invalid_index)+'].value' in system_instructions
                        assert 'Correct EVERY listed predicate' in system_instructions
                        from agentic_os_agent_worker.memory_output import analysis_null_repair_instructions
                        operation_id=messages[-1]['id'].removeprefix('msg_os_feedback_')
                        advice=analysis_null_repair_instructions(input,operation_id)
                        assert advice and advice in system_instructions
                        assert drafts[-1]['criteria'][1]['id'] not in advice and 'propertyId' not in advice
                        assert not analysis_null_repair_instructions(input,str(uuid4()))
                        incomplete=deepcopy(input);incomplete[-2]['content'][0]['text']='{}'
                        assert not analysis_null_repair_instructions(incomplete,operation_id)
                        valid=deepcopy(input);goal=json.loads(valid[-2]['content'][0]['text'])
                        goal['criteria'][1]['populationFilters']=[dict(field='missingValue',value=None)]
                        valid[-2]['content'][0]['text']=json.dumps(goal)
                        assert not analysis_null_repair_instructions(valid,operation_id)
            if premature and not self.injected and result[0]['type']=='message' and 'Accepted query and metric criteria: ' not in system_instructions:
                partial=json.loads(result[0]['content'][0]['text'])
                assert len(partial['queries'])==len(partial['criteria'])==1
                self.injected=True;injected=True
            if rejected_goal and not self.goal_rejected and result[0]['type']=='message' and 'Accepted query and metric criteria: ' not in system_instructions:
                malformed=json.loads(result[0]['content'][0]['text'])
                if len(malformed['queries'])==2:
                    assert json.loads(malformed['queries'][1]['argumentsJson'])['property_id']==int(ids['p1'])
                    assert malformed['criteria'][1]['queryKey']=='unbound-rejected-query'
                    self.injected=True;self.goal_rejected=True;goal_injected=True
            if core_incomplete and 'Accepted query and metric criteria: ' not in system_instructions:
                assert 'copy the exact selected identity into every downstream query' in system_instructions
            if dependent_semantics:
                assert ('Preserve explicitly requested dependent source chains.'in system_instructions)==(
                    'Accepted query and metric criteria: 'not in system_instructions)
                if 'Accepted query and metric criteria: 'not in system_instructions:
                    assert 'aggregate it at the requested contributor grain before ranking' in system_instructions
                    assert 'a metric label cannot change the meaning of its selected value field' in system_instructions
            if repeat_incomplete and self.injected and result[0]['type']=='message' and 'Accepted query and metric criteria: ' in system_instructions:
                result=deepcopy(result);result[0]['content'][0]['text']=json.dumps(drafts[-1]);core_injected=True
            if core_incomplete and not self.injected and result[0]['type']=='message' and 'Accepted query and metric criteria: ' in system_instructions:
                partial=json.loads(result[0]['content'][0]['text'])
                empty=next(row['result']['resultId'] for row in material if not row['page']['records'] and row['page']['nextCursor'] is not None)
                partial['results']=[ref for ref in partial['results'] if ref['resultId']!=empty]
                assert len(partial['results'])==2
                result=deepcopy(result);result[0]['content'][0]['text']=json.dumps(partial)
                self.injected=True;core_injected=True
            if missing_page and not self.injected and result[0]['type']=='message' and 'Accepted query and metric criteria: ' in system_instructions:
                from agentic_os.production.verified_analysis import VerifiedAnalysis
                partial=json.loads(result[0]['content'][0]['text'])
                empty=next(row['result']['resultId'] for row in material
                    if not row['page']['records'] and row['page']['nextCursor'] is not None)
                assert empty not in {ref['resultId'] for ref in partial['results']}
                checked=VerifiedAnalysis._produce(None,goals[0],partial,material,dict(resultId=context['taskId']),lambda:None)
                assert checked['status']=='incomplete' and checked['missingCriteria']
                self.injected=True;page_injected=True
            if malformed_tool and not self.injected and result[0]['type']=='function_call' and 'property_id' in json.loads(result[0]['arguments']):
                assert result[0]['name']==tool_alias(primary['capability'])
                self.injected=True;tool_injected=True
            if wrong_grain and not self.injected and result[0]['type']=='message' and 'Accepted query and metric criteria: ' not in system_instructions:
                malformed=json.loads(result[0]['content'][0]['text']);malformed['queries'][0]['grain']=['utilityId']
                result=deepcopy(result);result[0]['content'][0]['text']=json.dumps(malformed)
                self.injected=True;grain_injected=True
            if metric_grain and not self.injected and result[0]['type']=='message' and 'Accepted query and metric criteria: ' not in system_instructions:
                from agentic_os.production.exact_summary import summarize
                from agentic_os.errors import OSErrorCode
                from agentic_os_agent_worker.memory_output import analysis_source_discovery_feedback
                malformed=json.loads(result[0]['content'][0]['text']);metric=malformed['criteria'][0]
                metric['grain']=list(metric['groupBy'])
                with pytest.raises(OSErrorCode,match='CONFLICT'):summarize(metric,rows,check=lambda:None)
                # Parent deduplication and legitimately filtered measurements
                # must remain possible; this is no universal grain constant.
                parent=deepcopy(malformed);parent['criteria'][0].update(grain=['billId','currency'],groupBy=['currency'],
                    populationFields=['billId','currency'],valueField='billFaceAmount')
                summarize(parent['criteria'][0],rows,check=lambda:None)
                assert not analysis_source_discovery_feedback(json.dumps(parent),input,discovery,context,measurement_identity=True)
                narrowed=deepcopy(malformed);narrowed['criteria'][0]['filters'].append(dict(field='allocationId',value=rows[0]['allocationId']))
                summarize(narrowed['criteria'][0],rows,check=lambda:None)
                assert not analysis_source_discovery_feedback(json.dumps(narrowed),input,discovery,context,measurement_identity=True)
                result=deepcopy(result);result[0]['content'][0]['text']=json.dumps(malformed)
                self.injected=True;metric_injected=True
            if premature and not self.injected and result[0]['type']=='function_call' and result[0]['name']==tool_alias(primary['capability']):
                partial=fixture.analysis_goal(dict(analysisProfile='warehouse-query/1',queryGrain=grain,queryPageGroups=[],
                    capability=primary['capability'],resource=dict(providerRef='synthetic.read'),argumentsJson=result[0]['arguments']))
                partial['criteria']=partial['criteria'][:1]
                result=[dict(type='message',content=[dict(type='output_text',text=json.dumps(partial))])]
                self.injected=True;injected=True
            local_null=False
            if (retain_nulls and self.goal_rejected and not self.late_null and not goals and result[0]['type']=='message'):
                partial=json.loads(result[0]['content'][0]['text'])
                if not any(rule['value'] is None for metric in partial['criteria'] for rule in metric['populationFilters']):
                    # The first legacy fault also lacks source discovery. This
                    # distinct captured fault occurs after that read succeeds.
                    partial['criteria'][1]['populationFilters'].append(dict(field='propertyId',value=None))
                    result=deepcopy(result);result[0]['content'][0]['text']=json.dumps(partial)
                    self.late_null=True;local_null=True
            contract_invalid=None
            if (invalid_completion and result[0]['type']=='message' and 'Accepted query and metric criteria: ' in system_instructions
                    and (not self.injected or invalid_completion=='repeated-duplicate')):
                partial=json.loads(result[0]['content'][0]['text'])
                contract_invalid='missing-field' if invalid_completion=='missing-field' else 'duplicate'
                if contract_invalid=='duplicate':partial['results'].append(deepcopy(partial['results'][-1]))
                else:partial['results'][0].pop('scopeRef')
                result=deepcopy(result);result[0]['content'][0]['text']=json.dumps(partial);self.injected=True
            replay.append(dict(body=dict(input=deepcopy(input),instructions=system_instructions,tools=[dict(name=tool.name) for tool in tools]),output=deepcopy(result),premature=injected,wrongGrain=grain_injected,malformedTool=tool_injected,missingPage=page_injected,coreIncomplete=core_injected,rejectedGoal=goal_injected,metricGrain=metric_injected,nullKey=null_injected,missingQuery=query_injected,contractInvalid=contract_invalid,localNull=local_null))
            if result[0]['type']=='function_call':return calls(*[(r['name'],r['call_id'],json.loads(r['arguments'])) for r in result])
            raw=result[0]['content'][0]['text']
            # The real Runner must reject this response after the model hook
            # records it, retaining public SDK error details for correction.
            if not contract_invalid:schema.validate_json(raw)
            drafts.append(json.loads(raw));response=answer(raw)
            if core_injected:
                from openai.types.responses import ResponseReasoningItem
                response.output.insert(0,ResponseReasoningItem(id='private-incomplete-reasoning',type='reasoning',summary=[],encrypted_content='private-incomplete-reasoning-'*1024))
            return response
    model=Model(None)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    async def consume(driver,boundary,c,operation,**flags):
        assert flags['analysis'] and c==context
        if flags['objective']:
            _validate('AgentAnalysisGoalDraft',drafts[-1]);assert len(drafts[-1]['queries'])==len(drafts[-1]['criteria'])==2
            assert json.loads(drafts[-1]['queries'][1]['argumentsJson'])['property_id']==int(ids[winner])
            assert any(row['binding']['capability']==primary['capability'] for row in material) and not scoped_calls
            goals.append(dict(context=context,sourceDigest='a'*64,operator=sample('AgentAnalysisGoal')['operator'],nextPage=None,**drafts[-1]));state='goal-bound'
        else:
            completion_operations.append(operation)
            _validate('AgentAnalysisAnswerDraft',drafts[-1]);assert drafts[-1]['goalDigest']==digest('command',goals[0])
            by_id={row['result']['resultId']:row for row in material}
            selected=[by_id[ref['resultId']] for ref in drafts[-1]['results']]
            assert all(row['result']==ref for row,ref in zip(selected,drafts[-1]['results']))
            assert all(row['binding']['context']==context for row in selected)
            if core_incomplete or targeted_completion:
                from agentic_os.production.verified_analysis import VerifiedAnalysis
                verified=VerifiedAnalysis._produce(None,goals[0],drafts[-1],material,dict(resultId=context['taskId']),lambda:None)
                if verified['status']=='incomplete':
                    assert model.injected and verified['missingCriteria']
                    return ReadControl(rootId=c['rootId'],taskId=c['taskId'],operationId=operation,state='incomplete',
                        goalDigest=digest('command',goals[0]),missingCriteria=verified['missingCriteria'])
                assert verified['status']=='verified' and not verified['missingCriteria']
            for query in goals[0]['queries']:
                args=json.loads(query['argumentsJson']);ident=digest('command',{k:v for k,v in args.items() if k!='cursor'})
                pages=[row for row in selected if row['query']['queryDigest']==ident]
                assert pages and all(row['binding']['capability']==query['capability'] for row in pages)
                assert pages[0]['query']['requestCursor'] is None and pages[-1]['query']['page']['nextCursor'] is None
            if missing_page or source_rounds:
                from agentic_os.production.verified_analysis import VerifiedAnalysis
                verified=VerifiedAnalysis._produce(None,goals[0],drafts[-1],material,dict(resultId=context['taskId']),lambda:None)
                assert verified['status']=='verified' and not verified['missingCriteria']
            handoff=dict(goal=goals[0],draft=drafts[-1],material=material,changedWinner=changed_winner,
                expected=dict(property=winner,sourcePropertyId=ids[winner],propertyTotal='1500.00' if changed_winner else '1600.00',
                    bill='bill-002' if changed_winner else 'bill-005',billAllocation='900.00' if changed_winner else '1000.00'))
            path=tmp_path/'serialized-dependent-handoff.json';path.write_text(json.dumps(handoff));path.chmod(0o600)
            computed.append(handoff);state='completed'
        return ReadControl(rootId=c['rootId'],taskId=c['taskId'],operationId=operation,state=state,goalDigest=digest('command',goals[0]),missingCriteria=[])
    monkeypatch.setattr(read_journey,'complete_goal',consume)
    class Driver(AgentTaskDriver):
        def _expired(self):return False
        async def _save(self,boundary,ident,envelope):
            # Private checkpoint arguments use the already qualified encrypted
            # history codec; workflow starts/continuations above keep64KiB.
            payload=converter.to_payloads([envelope])[0];size=len(payload.SerializeToString(deterministic=True))
            assert size<=MAX_RAW_PAYLOAD;checkpoint_sizes.append(size)
            encoded=await codec.encode([payload]);assert len(encoded[0].SerializeToString(deterministic=True))<=65536
            decoded=(await codec.decode(encoded))[0];assert decoded==payload
            saved[ident]=converter.from_payloads([decoded])[0];return dict(kind='ready')
    async def run():
        queue.append(wire(value));terminal=None
        for _ in range(16):
            if not queue:break
            try:terminal=await Driver().run(queue.pop(0))
            except Rollover:pass
        assert not queue
        if repeat_query_links:
            assert terminal.status=='configuration-required' and not goals and not computed and not scoped_calls
            return
        if invalid_completion=='repeated-duplicate':
            assert terminal.status=='configuration-required' and not completion_operations and not computed
            assert drafts[-1]==drafts[-2]
            return
        if repeat_incomplete:
            assert terminal.status=='configuration-required' and terminal.operationId==completion_operations[-1]
            assert len(completion_operations)==2
        else:assert terminal.state=='completed'
    asyncio.run(run())
    if repeat_query_links:
        assert model.goal_rejected and len(drafts)>=2 and drafts[-1]==drafts[-2]
        return
    if invalid_completion=='repeated-duplicate':
        assert len(goals)==1 and len(scoped_calls)==2
        return
    assert len(computed)==(0 if repeat_incomplete else 1) and len(scoped_calls)==2 and question==value['start']['input']
    if invalid_completion:
        assert model.injected and len(drafts)==3 and len(completion_operations)==1
        from agentic_os_agent_worker.memory_output import ANALYSIS_CONTRACT_FEEDBACK
        assert any(ANALYSIS_CONTRACT_FEEDBACK in json.dumps(row['body']['input']) for row in replay)
    if targeted_source:assert source_choices and len(computed)==1
    if targeted_completion:assert completion_choices and len(completion_operations)==2 and len(computed)==1
    if premature:
        assert model.injected and len(drafts)==3+int(missing_page)+int(rejected_goal)
        assert any('Read every current page of source-discovery query' in json.dumps(row['body']['input']) for row in replay)
    if wrong_grain:
        assert model.injected and len(drafts)==3
        feedback_text=[content['text'] for row in replay for item in row['body']['input']
            if item.get('type')=='message' and type(item.get('content')) is list
            for content in item['content'] if content.get('type')=='output_text']
        issues=[json.loads(text.split('Issues: ',1)[1]) for text in feedback_text if 'Issues: ' in text]
        assert any('This capability owned.allocation-rows declares '+json.dumps(grain,separators=(',',':')) in message
            for messages in issues for message in messages)
    if malformed_tool:
        assert model.injected and len(drafts)==2+int(premature)+int(missing_page)+int(rejected_goal)
        assert any(json.loads(item['output'])==dict(kind='tool-error',failure='invalid-input')
            for row in replay for item in row['body']['input'] if item.get('type')=='function_call_output')
    if missing_page:
        assert model.injected and len(drafts)==3+int(premature)+int(rejected_goal)
        assert any('Exact missing accepted result: ' in json.dumps(row['body']['input']) for row in replay)
    if core_incomplete or targeted_completion:
        assert model.injected and len(drafts)==3
        assert any('Completion verification still requires criteria' in json.dumps(row['body']['input']) for row in replay)
    if metric_grain:
        assert model.injected and len(drafts)==3
        assert any('grain combines differing source measurements' in json.dumps(row['body']['input']) for row in replay)
    if null_key:
        assert model.injected and len(drafts)==4+int(retain_nulls) and len(goals)==1
        assert not any(rule['value'] is None for metric in goals[0]['criteria'] for rule in metric['populationFilters'])
        if retain_nulls:
            assert retained_null_proposals and len(computed)==1
            assert all(metric['valueField']=='allocatedNet' for metric in goals[0]['criteria'])
    if not source_rounds:assert max(checkpoint_sizes)>65536
    replay_path=tmp_path/'private-dependent-provider-replay.json'
    replay_path.write_text(json.dumps(dict(start=value,replay=replay,outcome=outcome,malformedTool=malformed_tool,missingPage=missing_page,nullKeyFixture=null_key)));replay_path.chmod(0o600)
    # The isolated assigned worker has no Core package. Replay every actual
    # serialized provider input there, rather than inheriting conftest paths.
    script='''import importlib.util,json,sys
from copy import deepcopy
from pathlib import Path
spec=importlib.util.spec_from_file_location('actual_dependent_fixture',sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
value=json.loads(Path(sys.argv[2]).read_bytes())
def normalized(output):
 output=json.loads(json.dumps(output))
 for item in output:
  if item['type']=='message':
   document=json.loads(item['content'][0]['text'])
   for metric in document.get('criteria',[]):metric.pop('id')
   item['content'][0]['text']=document
 return output
for row in value['replay']:
 actual=m.property_composition_step(value['start'],row['body'],outcome=value['outcome'],malformed_discovery=value['malformedTool'],missing_completion_page=value['missingPage'],invalid_goal=value['nullKeyFixture'])
 if row['premature']:
  assert actual[0]['type']=='function_call'
  partial=json.loads(row['output'][0]['content'][0]['text'])
  assert len(partial['criteria'])==1 and partial['queries'][0]['argumentsJson']==actual[0]['arguments']
 elif row['malformedTool']:
  assert normalized(actual)==normalized(row['output']) and 'property_id' in json.loads(actual[0]['arguments'])
 elif row['wrongGrain']:
  expected=normalized(actual);expected[0]['content'][0]['text']['queries'][0]['grain']=['utilityId']
  assert expected==normalized(row['output'])
 elif row.get('metricGrain'):
  expected=normalized(actual);metric=expected[0]['content'][0]['text']['criteria'][0]
  metric['grain']=list(metric['groupBy'])
  assert expected==normalized(row['output'])
 elif row.get('localNull'):
  expected=normalized(actual);expected[0]['content'][0]['text']['criteria'][1]['populationFilters'].append(dict(field='propertyId',value=None))
  assert expected==normalized(row['output'])
 elif row.get('nullKey'):
  assert normalized(actual)==normalized(row['output'])
 elif row['rejectedGoal']:
  expected=normalized(actual);draft=expected[0]['content'][0]['text']
  args=json.loads(draft['queries'][1]['argumentsJson']);args['property_id']=831
  draft['queries'][1]['argumentsJson']=json.dumps(args)
  draft['criteria'][1]['queryKey']='unbound-rejected-query'
  assert expected==normalized(row['output'])
 elif row.get('missingQuery'):
  assert actual[0]['type']=='function_call'
  partial=json.loads(row['output'][0]['content'][0]['text'])
  assert partial['results'] and partial['goalDigest']
 elif row.get('contractInvalid'):
  expected=normalized(actual);draft=expected[0]['content'][0]['text']
  if row['contractInvalid']=='duplicate':draft['results'].append(deepcopy(draft['results'][-1]))
  else:draft['results'][0].pop('scopeRef')
  assert expected==normalized(row['output'])
 elif row['coreIncomplete']:
  expected=normalized(actual);selected=normalized(row['output'])[0]['content'][0]['text']['results']
  assert len(expected[0]['content'][0]['text']['results'])==3 and len(selected)==2
  expected[0]['content'][0]['text']['results']=[ref for ref in expected[0]['content'][0]['text']['results'] if ref in selected]
  assert expected==normalized(row['output'])
 else:assert normalized(actual)==normalized(row['output'])
assert 'agentic_os' not in sys.modules
'''
    checked=subprocess.run([sys.executable,'-I','-B','-c',script,str(root/'tests/integration/resources/analysis_fixture.py'),str(replay_path)],capture_output=True,text=True,timeout=20)
    assert checked.returncode==0,checked.stderr


def test_actual_partial_goal_repairs_source_discovery_before_serialized_dependent_completion(monkeypatch,tmp_path):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,'dependent-iteration',False,premature=True)


def test_actual_wrong_discovery_grain_repairs_before_serialized_dependent_completion(monkeypatch,tmp_path):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,'dependent-iteration',False,wrong_grain=True)


def test_actual_malformed_discovery_tool_repairs_without_execution_or_fabricated_source(monkeypatch,tmp_path):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,'dependent-iteration',False,malformed_tool=True)


def test_current_numeric_null_predicate_instructions_reach_serialized_sdk_and_complete_consumer(monkeypatch,tmp_path):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,'result-followup',False,source_rounds=True,null_key=True,
        retain_links=True,retain_nulls=True,predicate_instructions=True)


@pytest.mark.parametrize('outcome',['dependent-iteration','result-followup'])
def test_dependent_measure_and_source_chain_guidance_reaches_serialized_sdk_and_consumer(monkeypatch,tmp_path,outcome):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,outcome,False,source_rounds=True,dependent_semantics=True)


@pytest.mark.parametrize('changed_winner',[False,True])
def test_single_structured_goal_schema_keeps_actual_dependent_winner_and_serialized_consumer(monkeypatch,tmp_path,changed_winner):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,'dependent-iteration',changed_winner,source_rounds=True,
        dependent_semantics=True,schema_once=True)


def test_actual_missing_empty_page_repairs_complete_dependent_source_chain(monkeypatch,tmp_path):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,'dependent-iteration',False,missing_page=True)


@pytest.mark.parametrize('fault',['duplicate','missing-field','repeated-duplicate'])
def test_invalid_completion_repairs_after_actual_serialized_sdk_validation(monkeypatch,tmp_path,fault):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,'result-followup',False,source_rounds=True,invalid_completion=fault)


@pytest.mark.parametrize('fault',['normal','malformed','missing-page','core-incomplete','rejected-goal','rejected-goal-adjacent','repeated-completion','metric-grain','null-key-filter','null-key-retained','targeted-source','targeted-completion','query-links','query-links-retained','query-links-repeated'])
def test_actual_source_rounds_retain_question_and_pages_across_sdk_checkpoints(monkeypatch,tmp_path,fault):
    test_actual_dependent_entry_binds_current_winner_to_later_query_and_bound_consumer(
        monkeypatch,tmp_path,'result-followup' if fault in {'null-key-filter','null-key-retained'} else 'dependent-iteration',False,source_rounds=True,
        malformed_tool=fault in {'malformed','rejected-goal-adjacent'},missing_page=fault in {'missing-page','rejected-goal-adjacent'},
        core_incomplete=fault in {'core-incomplete','repeated-completion'},rejected_goal=fault in {'rejected-goal','rejected-goal-adjacent','query-links','query-links-retained','query-links-repeated'},
        source_contract=fault in {'rejected-goal-adjacent','metric-grain','targeted-source'},premature=fault in {'rejected-goal','rejected-goal-adjacent','targeted-source','query-links','query-links-retained','query-links-repeated'},
        repeat_incomplete=fault=='repeated-completion',metric_grain=fault=='metric-grain',null_key=fault in {'null-key-filter','null-key-retained'},targeted_source=fault=='targeted-source',targeted_completion=fault=='targeted-completion',query_links=fault in {'query-links','query-links-retained','query-links-repeated'},
        retain_links=fault in {'query-links-retained','query-links-repeated','metric-grain','null-key-filter','null-key-retained'},repeat_query_links=fault=='query-links-repeated',retain_nulls=fault=='null-key-retained')
