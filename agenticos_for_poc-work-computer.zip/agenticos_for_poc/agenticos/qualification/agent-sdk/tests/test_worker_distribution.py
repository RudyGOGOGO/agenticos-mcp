"""Build the actual worker artifact and import it outside the Host checkout."""
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile


def test_worker_wheel_and_installed_package_are_independent_of_the_checkout(proof_root):
    project = Path(__file__).resolve().parents[3] / "harnesses/agent-worker"
    wheels = proof_root / "worker-wheels"
    command = ["uv", "build", "--project", str(project), "--wheel", "--out-dir", str(wheels)]
    built = subprocess.run(command, cwd=proof_root, capture_output=True, text=True, timeout=90)
    assert built.returncode == 0, built.stdout + built.stderr
    wheel, = wheels.glob("*.whl")
    with zipfile.ZipFile(wheel) as archive:
        names = archive.namelist()
        assert "agentic_os_agent_worker/policy.py" in names
        assert "agentic_os_agent_worker/transport.py" in names
        assert "agentic_os_agent_worker/provider_privacy.py" in names
        assert "agentic_os_agent_worker/model_rpc.py" in names
        assert "agentic_os_agent_worker/sdk_model.py" in names
        assert "agentic_os_agent_worker/checkpoint.py" in names
        assert "agentic_os_agent_worker/sdk_tools.py" in names
        assert "agentic_os_agent_worker/private_history.py" in names
        for name in ['workflow_control.py','temporal_driver.py','temporal_runtime.py','temporal_cloud.py','query_context.py','native_query_journey.py','workload.py','catalog_context.py']:
            assert 'agentic_os_agent_worker/'+name in names
        installed_root=Path(__import__('agentic_os_agent_worker').__file__).parent
        for path in (project/'src/agentic_os_agent_worker').rglob('*'):
            if path.is_file() and path.suffix in {'.py','.json'} and '__pycache__' not in path.parts:
                assert (installed_root/path.relative_to(project/'src/agentic_os_agent_worker')).read_bytes()==path.read_bytes()
        assert json.loads(archive.read('agentic_os_agent_worker/contracts.json')) == json.loads(
            (project/'src/agentic_os_agent_worker/contracts.json').read_text())
        assert not any(name.endswith((".key", ".env", ".sqlite")) for name in names)
        assert not any(name.startswith("agentic_os/") for name in names)
    probe = '''import json
from importlib.util import find_spec
from pathlib import Path
import agentic_os_agent_worker
from agentic_os_agent_worker import contracts
from agentic_os_agent_worker.policy import verify_dependencies
from agentic_os_agent_worker.transport import OfficialTransport
from agentic_os_agent_worker.provider_privacy import resolve_privacy
assert callable(resolve_privacy)
from agentic_os_agent_worker.model_rpc import RPCModelBoundary
from agentic_os_agent_worker.workload import ProjectedWorkloadToken
assert callable(ProjectedWorkloadToken.__call__)
from agentic_os_agent_worker.temporal_cloud import CloudTemporalConnection
assert callable(CloudTemporalConnection.connect)
from agentic_os_agent_worker.sdk_model import GovernedResponsesProvider, SDKModelSequence
from agentic_os_agent_worker.checkpoint import export_checkpoint, restore_checkpoint
from agentic_os_agent_worker.sdk_tools import governed_read_tool, SDKToolDeferred
from agentic_os_agent_worker.private_history import AgentHistoryCodec
from agentic_os_agent_worker.workflow_control import MemoryReadControl
from agentic_os_agent_worker.read_journey import start_contract
assert start_contract({'schema':'agent-memory-read-journey/1'})=='AgentSDKMemoryReadJourneyStart'
assert start_contract({'schema':'agent-memory-response-journey/1'})=='AgentSDKMemoryResponseJourneyStart'
assert start_contract({'schema':'agent-lookup-read-journey/1'})=='AgentSDKLookupReadJourneyStart'
assert start_contract({'schema':'agent-discovered-read-journey/1'})=='AgentSDKDiscoveredReadJourneyStart'
from agentic_os_agent_worker.catalog_context import discovery_model_input
assert callable(discovery_model_input) and callable(RPCModelBoundary.selected_read_tools)
from agentic_os_agent_worker.query_context import completed_query_window, incomplete_query_window
from agentic_os_agent_worker.query_source_journey import refresh_query_checkpoint
from agentic_os_agent_worker.native_query_journey import run_native_query
from agentic_os_agent_worker.sdk_tools import governed_native_tool
assert callable(refresh_query_checkpoint) and callable(RPCModelBoundary.query_checkpoint_state)
assert callable(run_native_query) and callable(governed_native_tool)
assert callable(RPCModelBoundary.execute_native) and callable(RPCModelBoundary.native_source_state)
verify_dependencies()
assert find_spec('agentic_os') is None
schema=json.loads(Path(agentic_os_agent_worker.__file__).with_name('contracts.json').read_text())
assert 'AgentTaskContext' in schema['$defs']
assert 'AgentTaskContext' in contracts.__dict__
assert 'AgentMemoryPage' in schema['$defs'] and 'AgentSDKMemoryReadJourneyStart' in contracts.__dict__
assert 'AgentSDKMemoryResponseJourneyStart' in schema['$defs'] and 'AgentSDKMemoryResponseJourneyStart' in contracts.__dict__
from agentic_os_agent_worker.memory_output import MemoryResponseOutput
assert MemoryResponseOutput(objective=True).name()=='AgentMemoryResponseDraft'
assert MemoryResponseOutput(objective=False).name()=='AgentMemoryReadAnswerDraft'
assert 'AgentSDKLookupReadJourneyStart' in schema['$defs'] and 'AgentSDKLookupReadJourneyStart' in contracts.__dict__
from agentic_os_agent_worker.memory_output import LookupOutput,NativeSourceOutput
assert LookupOutput(objective=True).name()=='AgentReadGoalDraft'
assert LookupOutput(objective=False).name()=='AgentReadAnswerDraft'
native_output=NativeSourceOutput(objective=True)
assert native_output.name()=='AgentQuerySourceIntentDraft'
assert 'AgentExactMetric' in native_output.json_schema()['$defs']
assert 'AgentCapabilityDiscoveryPage' in schema['$defs'] and 'AgentSDKDiscoveredReadJourneyStart' in contracts.__dict__
assert 'BudgetLimits' not in schema['$defs']
assert 'AgentRepairExecutionPolicyInput' not in schema['$defs']
print(json.dumps({"module":str(Path(agentic_os_agent_worker.__file__).resolve())}))
'''
    # -I excludes cwd/PYTHONPATH and the source kernel; only the installed wheel
    # and resolved SDK dependencies can satisfy this import.
    checked = subprocess.run([sys.executable, "-I", "-c", probe], cwd=proof_root,
        env={k: v for k, v in os.environ.items() if k not in {"PYTHONPATH"}},
        capture_output=True, text=True, timeout=30)
    assert checked.returncode == 0, checked.stderr
    installed = Path(json.loads(checked.stdout)["module"])
    assert installed.is_relative_to(Path(sys.prefix))
    assert not installed.is_relative_to(project)
