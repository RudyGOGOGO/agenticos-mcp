"""Real SDK child checkpoints overlap; shared waits/rollover require quiescence."""
import asyncio
from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

from agents import RunConfig
from agents.models.interface import ModelProvider
import pytest

from agentic_os_agent_worker import child_read_journey as journey
from agentic_os_agent_worker.sdk_model import BINDING_KEY,SDKModelPolicyError
from agentic_os_agent_worker.transport import _validate
from agentic_os_agent_worker.workflow_control import WorkflowControl
from test_sdk_tools import Boundary,ModelCalls,item_fixture
from test_sdk_model import binding_fixture
from agentic_os_agent_worker.checkpoint import tool_alias

VECTORS=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())


def sample(name):return deepcopy(next(row['value'] for row in VECTORS if row['valid'] and row['contract']==name))


@pytest.fixture(autouse=True)
def legacy_workflow_versions(monkeypatch):
    monkeypatch.setattr(journey.workflow,'patched',lambda _:False)


@pytest.mark.parametrize('mode',['legacy','typed','typed-bounded','duplicate-once','duplicate-repeated'])
def test_child_completion_uses_full_current_references_through_sdk_checkpoint_and_core(monkeypatch,mode):
    from agents.items import ModelResponse
    from agents.usage import Usage
    from openai.types.responses import ResponseFunctionToolCall,ResponseOutputMessage,ResponseOutputText
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    from agentic_os_agent_worker.memory_output import LookupOutput
    from agentic_os_agent_worker.private_history import AgentHistoryCodec
    from temporalio.converter import WorkflowSerializationContext
    from agentic_os.production.completion import compile_read_answer
    from agentic_os.production.child_read_scope import child_instructions,child_input,arguments,validate_arguments
    from agentic_os.production.child_reads import ChildReads
    from agentic_os_agent_worker.sdk_model import GovernedResponsesModel
    from agents.models.interface import ModelTracing
    from datetime import datetime,timezone,timedelta
    from agentic_os.contracts.canonical import digest
    from test_private_history import Keys,Store
    from test_tool_execution_rpc import accepted_for
    from agents.exceptions import ModelBehaviorError
    value,page=fixture();item=page['items'][0];context=value['start']['context'];capability=value['start']['capabilities'][0]
    resource=dict(subject=deepcopy(context['subject']),providerId='synthetic.read',resourceType='counter',
        contractVersion=1,externalId='one',observedVersion='1')
    goal=item['scope']['goal'];goal.update(context=deepcopy(context),nextPage=None,criteria=[dict(
        id=str(uuid4()),capability=capability['capability'],resources=[dict(providerRef='synthetic.read',
            resourceType='counter',externalId='one')],fields=['value'],coverage='selected-records')])
    item['scope']['adapter']['providerRef']='synthetic.read'
    _validate('AgentChildReadScope',item['scope'])
    selector=arguments(item['scope']);adapter=item['scope']['adapter']
    capability['inputSchemaJson']=json.dumps(dict(type='object',properties={
        adapter['resourceTypeField']:dict(type='string',maxLength=128),
        adapter['externalIdsField']:dict(type='array',maxItems=16,items=dict(type='string',maxLength=128)),
        adapter['fieldNamesField']:dict(type='array',maxItems=16,items=dict(type='string',maxLength=128))},required=list(selector),additionalProperties=False))
    from agentic_os.production.capability_schema import qualified_schema
    qualified_schema(capability['inputSchemaJson'])
    item.update(instructions=child_instructions(item['scope']),input=child_input(item['scope']))
    converter=AgentPayloadConverter();keys=Keys();store=Store(context)
    workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    codec=AgentHistoryCodec(store,keys,context,'default',key_id=keys.id).with_context(WorkflowSerializationContext('default',workflow_id))
    materials=[];saved={};calls=[];candidates=[];completed=[];accepted=[];staged=[]
    maximum_request_bytes=4096 if mode=='typed-bounded' else 1048576
    monkeypatch.setattr(journey.workflow,'patched',lambda name:mode!='legacy' and name=='child-read-output-contracts/1')
    async def wire(document):
        payload=converter.to_payloads([document])[0]
        assert (await codec.decode(await codec.encode([payload])))[0]==payload
        return converter.from_payloads([payload])[0]
    class Kernel(Boundary):
        async def accepted_model_operation(self,c,operation):
            accepted.append(operation);return await super().accepted_model_operation(c,operation)
        async def put_checkpoint(self,ident,envelope):saved[ident]=await wire(envelope);return dict(kind='ready')
        async def get_checkpoint(self,c,ident):assert c==context;return deepcopy(saved[ident])
        async def child_checkpoint(self,c,operation,ident,checkpoint):
            assert c==context and ident==item['scope']['childId'];return dict(item,checkpointId=checkpoint)
        async def execute_tool(self,request):
            validate_arguments(item['scope'],request['capability'],request['argumentsJson'])
            self.requests.append(await wire(request));reply=accepted_for(request);a=reply['accepted'];evidence=json.loads(a['payloadJson'])
            evidence.update(records=[[dict(name='value',value=42)]])
            evidence['evidence'].update(resourceRefs=[resource],publicFields=['value'])
            evidence['evidence']['coreDigest']=digest('evidence',dict(evidence={k:v for k,v in evidence['evidence'].items()if k!='coreDigest'},records=evidence['records']))
            a['payloadJson']=json.dumps(evidence);materials.append(dict(result=deepcopy(a['result']),binding=a['binding'],page=evidence))
            return await wire(reply)
        async def child_complete(self,c,operation,ident):
            assert c==context and ident==item['scope']['childId']
            # The actual strict consumer checks both full object identities,
            # exact current evidence and the original child goal.
            assessment=compile_read_answer(goal,candidates[-1],materials)
            assert assessment['kind']=='verified';completed.append(operation)
            return await wire(dict(kind='completed',item=dict(item,state='COMPLETED',verification=dict(
                childId=ident,scopeDigest='a'*64,candidate=await self.accepted_model_operation(c,operation)))))
    kernel=Kernel()
    class Model(ModelCalls):
        async def get_response(self,system_instructions,input,model_settings,tools,output_schema,*args,**kwargs):
            calls.append(deepcopy(input));assert (output_schema is not None)==(mode!='legacy')
            # Use the actual worker request serializer and Core staging guard,
            # stopping at the existing private-storage port before mutation.
            serializer=object.__new__(GovernedResponsesModel)
            serializer.transport=SimpleNamespace(config=SimpleNamespace(model_profile_digest=context['model']['digest'],max_request_bytes=maximum_request_bytes))
            serializer.max_output_tokens=value['start']['maxOutputTokens'];serializer.reasoning_effort=None
            from temporalio.contrib.openai_agents._temporal_model_stub import _TemporalModelStub
            from temporalio.contrib.openai_agents._model_parameters import ModelActivityParameters
            from temporalio.contrib.openai_agents._invoke_model_activity import ActivityModelInput,_build_tools_and_handoffs
            from temporalio.contrib.openai_agents._temporal_worker_env_ref import _WorkerEnvRefResolver,AllowAllWorkerEnvVars
            stub=_TemporalModelStub('synthetic',model_params=ModelActivityParameters(),agent=None)
            activity,_=stub._build_activity_input(system_instructions=system_instructions,input=input,
                model_settings=model_settings,tools=tools,output_schema=output_schema,handoffs=[],
                tracing=ModelTracing.DISABLED,previous_response_id=None,conversation_id=None,prompt=None)
            encoded=converter.to_payloads([activity])
            decoded=converter.from_payloads(await codec.decode(await codec.encode(encoded)),[ActivityModelInput])[0]
            restored,_=_build_tools_and_handoffs(decoded,_WorkerEnvRefResolver(AllowAllWorkerEnvVars()))
            binding,_,raw=serializer._request(decoded['system_instructions'],decoded['input'],decoded['model_settings'],
                restored,decoded['output_schema'],[],ModelTracing.DISABLED,None,None,None)
            class ReachedStorage(Exception):pass
            async def selected(*_):return item['scope'],dict(maxRequestBytes=maximum_request_bytes)
            async def references(*_):pass
            async def lane(*_):return capability
            async def storage(*args,**command):
                assert command['schema_ref']=='AgentProviderInput' and command['content']==raw.encode()
                staged.append(raw);raise ReachedStorage()
            core=object.__new__(ChildReads);core.models=SimpleNamespace(admission=object())
            core._selected=selected;core._references=references;core._lane=lane
            core._row=lambda *_:dict(state='ACTIVE',expiresAt=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())
            from agentic_os.production import child_reads
            with monkeypatch.context() as patch:
                patch.setattr(child_reads,'PrivateInputs',lambda _:SimpleNamespace(put=storage))
                with pytest.raises(ReachedStorage):await core.stage_model(None,context,item['scope']['childId'],binding,raw)
                from agentic_os.errors import OSErrorCode
                altered=json.loads(raw);altered['instructions']+=' changed'
                with pytest.raises(OSErrorCode,match='DENIED'):
                    await core.stage_model(None,context,item['scope']['childId'],binding,
                        json.dumps(altered,ensure_ascii=False,separators=(',',':')))
            if output_schema is not None:
                assert output_schema.name()=='AgentReadAnswerDraft'
                with pytest.raises(ModelBehaviorError):output_schema.validate_json(json.dumps(dict(
                    goalDigest=digest('command',goal),facts=[dict(result=str(uuid4()),resource='counter/one',field='value')])))
            if len(calls)==1:output=[ResponseFunctionToolCall(type='function_call',name=self.name,arguments=json.dumps(selector),call_id='read_one',id='fc_one')]
            else:
                draft=dict(goalDigest=digest('command',goal),facts=[dict(result=materials[0]['result'],resource=resource,field='value')]);candidates.append(draft)
                raw=json.dumps(draft);assert output_schema is None or output_schema.validate_json(raw)==raw
                message=ResponseOutputMessage(type='message',id='msg_'+str(len(calls)),role='assistant',status='completed',
                    content=[ResponseOutputText(type='output_text',text=raw,annotations=[])])
                output=[message]
                if mode=='duplicate-repeated' or mode=='duplicate-once' and len(calls)==2:
                    output.append(message.model_copy(update=dict(id=message.id+'_copy')))
            return ModelResponse(output=output,usage=Usage(requests=1),response_id='response_'+str(len(calls)))
    model=Model(tool_alias(capability['capability']))
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    result=asyncio.run(journey._run_child(Driver(),value,kernel,item,batch=True))
    if mode=='duplicate-repeated':assert result.status=='configuration-required' and not completed
    else:assert result['state']=='COMPLETED' and len(completed)==1
    assert len(kernel.requests)==len(saved)==1 and len(calls)==(3 if mode.startswith('duplicate')else 2)
    assert len(staged)==len(calls)
    assert value['childContinuation']['binding']['context']==context
    assert len(accepted)>=len(calls) and all(material['result']['rootId']==context['rootId']for material in materials)


def fixture():
    value=sample('AgentSDKParallelChildReadJourneyStart');_,_,binding=binding_fixture()
    context=deepcopy(binding['context']);value['start']['context']=context
    context['harness']['ref']='focused-child-reads/1';capability=item_fixture()
    value['start'].update(capabilities=[capability],modelId='synthetic-child',checkpointId=None)
    binding.update(context=deepcopy(context),inputResults=[],turn=2,parentOperationId=str(uuid4()))
    value.update(binding=binding,phase='children',childAfter=None,childContinuation=None,childContinuations=[])
    items=[]
    for _ in range(2):
        item=sample('AgentChildWorkerItem');scope=item['scope']
        scope.update(childId=str(uuid4()),sdkInstanceId=str(uuid4()),parentOperationId=binding['parentOperationId'])
        scope['goal']['context']=deepcopy(context);scope['adapter']['capability']=deepcopy(capability['capability'])
        item.update(state='UNSTARTED',checkpointId=None,verification=None)
        items.append(item)
    page=dict(context=deepcopy(context),policy=deepcopy(items[0]['scope']['policy']),items=items,nextChild=None,maxActiveChildren=2)
    _validate('AgentSDKParallelChildReadJourneyStart',value);_validate('AgentParallelChildWorkerPage',page)
    return value,page


class Rollover(BaseException):pass


class Driver:
    stopped=False
    def _expired(self):return False
    async def _save(self,*_):raise AssertionError('Concurrent child entered a shared checkpoint wait')
    async def _pause(self,*_):raise AssertionError('Unexpected shared wait')


def test_actual_sdk_children_overlap_with_separate_checkpoints_and_joined_references(monkeypatch):
    value,page=fixture();models={};entered=[];checkpoints={};accepted={};completed=[]
    async def run():
        gate=asyncio.Event()
        class Model(ModelCalls):
            async def get_response(self,*args,**kwargs):
                if not self.inputs:
                    entered.append(self)
                    if len(entered)==2:gate.set()
                    await asyncio.wait_for(gate.wait(),2)
                return await super().get_response(*args,**kwargs)
        class Router(ModelCalls):
            async def get_response(self,system_instructions,input,*args,**kwargs):
                settings=kwargs.get('model_settings') if 'model_settings' in kwargs else args[0]
                ident=json.loads(settings.metadata[BINDING_KEY])['sdkInstanceId']
                model=models.setdefault(ident,Model(self.name,count=1))
                return await model.get_response(system_instructions,input,*args,**kwargs)
        class Provider(ModelProvider):
            def get_model(self,name):
                assert name==value['start']['modelId']
                return Router(tool_alias(value['start']['capabilities'][0]['capability']))
        monkeypatch.setattr(journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
        class Kernel(Boundary):
            async def child_parallel_page(self,*args,**kwargs):return deepcopy(page)
            async def child_start(self,context,parent,ident):
                item=deepcopy(next(item for item in page['items'] if item['scope']['childId']==ident));item['state']='ACTIVE'
                return dict(kind='ready',item=item)
            async def accepted_model_operation(self,context,operation):
                reference=await super().accepted_model_operation(context,operation);accepted[operation]=reference;return reference
            async def put_checkpoint(self,ident,envelope):
                _validate('AgentSDKCheckpointState',envelope);checkpoints[ident]=deepcopy(envelope);return dict(kind='ready')
            async def child_checkpoint(self,context,operation,ident,checkpoint):
                item=deepcopy(next(item for item in page['items'] if item['scope']['childId']==ident))
                item.update(state='ACTIVE',checkpointId=checkpoint);return item
            async def get_checkpoint(self,context,ident):return deepcopy(checkpoints[ident])
            async def child_complete(self,context,operation,ident):
                item=deepcopy(next(item for item in page['items'] if item['scope']['childId']==ident))
                item.update(state='COMPLETED',verification=dict(childId=ident,scopeDigest='a'*64,candidate=accepted[operation]))
                completed.append(ident);return dict(kind='completed',item=item)
        kernel=Kernel();rollovers=[]
        def rollover(next_value):rollovers.append(deepcopy(next_value));raise Rollover()
        monkeypatch.setattr(journey.workflow,'continue_as_new',rollover)
        with pytest.raises(Rollover):await journey.run_parallel_children(Driver(),value,kernel)
        assert len(entered)==len(models)==len(checkpoints)==len(kernel.requests)==len(completed)==2
        assert len(accepted)==4 and all(len(model.inputs)==2 for model in models.values())
        assert {state['binding']['sdkInstanceId'] for state in checkpoints.values()}==set(models)
        assert all(state['binding']['context']==value['start']['context'] for state in checkpoints.values())
        assert len(rollovers)==1 and rollovers[0]['childContinuations']==[]
        assert rollovers[0]['childAfter']==page['items'][-1]['scope']['childId']
        assert len(rollovers[0]['binding']['inputResults'])==2
    asyncio.run(run())


@pytest.mark.parametrize('outcome',['wait','failure','stop'])
def test_shared_wait_failure_or_stop_does_not_abandon_another_branch(monkeypatch,outcome,*,query_resume=None):
    value,page=fixture();settled=[];pauses=[];rolled=[]
    if query_resume is not None:
        query=sample('AgentSDKQuerySourceChildJoinJourneyStart')
        query.update({key:deepcopy(item) for key,item in value.items() if key in query and key!='schema'})
        value=query;_validate('AgentSDKQuerySourceChildJoinJourneyStart',value)
        monkeypatch.setattr(journey.workflow,'patched',lambda name:name=='query-child-wait-resume-in-place/1')
    async def child(driver,branch,boundary,item,*,batch):
        assert batch
        await asyncio.sleep(0)
        ident=item['scope']['childId']
        if ident==page['items'][0]['scope']['childId']:
            if outcome=='failure':raise ValueError('synthetic branch failure')
            if outcome=='stop':driver.stopped=True
            state=sample('AgentSDKChildContinuation');state.update(childId=ident)
            state['binding'].update(context=deepcopy(value['start']['context']),sdkInstanceId=item['scope']['sdkInstanceId'])
            branch['childContinuation']=state
            return WorkflowControl(value['start']['context']['rootId'],value['start']['context']['taskId'],
                value['binding']['parentOperationId'],'waiting-reconciliation')
        await asyncio.sleep(.02);settled.append(ident)
        result=deepcopy(item);result.update(state='COMPLETED',verification=dict(childId=ident,scopeDigest='a'*64,candidate=sample('AgentResultReference')))
        return result
    class Kernel:
        async def child_parallel_page(self,*args,**kwargs):return deepcopy(page)
        async def child_start(self,context,parent,ident):
            item=deepcopy(next(item for item in page['items'] if item['scope']['childId']==ident));item['state']='ACTIVE'
            return dict(kind='ready',item=item)
    class SharedDriver(Driver):
        def _expired(self):return query_resume is True
        async def _pause(self,control):
            assert len(settled)==1;pauses.append(control)
            if query_resume=='stop':self.stopped=True
    def rollover(next_value):
        assert len(settled)==1;rolled.append(deepcopy(next_value));raise Rollover()
    monkeypatch.setattr(journey,'_run_child',child);monkeypatch.setattr(journey.workflow,'continue_as_new',rollover)
    async def run():
        driver=SharedDriver()
        if outcome=='failure':
            with pytest.raises(ValueError,match='synthetic branch failure'):await journey.run_parallel_children(driver,value,Kernel())
        elif outcome=='wait':
            if query_resume is None:
                with pytest.raises(Rollover):await journey.run_parallel_children(driver,value,Kernel())
                assert len(pauses)==len(rolled)==1 and len(rolled[0]['childContinuations'])==1
            else:
                result=await journey.run_parallel_children(driver,value,Kernel())
                if query_resume=='stop':assert result.status=='stopped'
                elif query_resume is True:assert result.status=='authorization-expired'
                else:assert result is None
                assert len(pauses)==1 and rolled==[] and len(value['childContinuations'])==1
        else:
            result=await journey.run_parallel_children(driver,value,Kernel());assert result.status=='stopped' and not pauses
        assert len(settled)==1
    asyncio.run(run())


@pytest.mark.parametrize('expired',[False,True,'stop'])
def test_query_child_wait_preserves_continuation_before_source_gate_without_early_rollover(monkeypatch,expired):
    test_shared_wait_failure_or_stop_does_not_abandon_another_branch(monkeypatch,'wait',query_resume=expired)


@pytest.mark.parametrize('fault',['root','sibling-context','duplicate-state'])
def test_foreign_parallel_continuation_is_denied_before_child_dispatch(fault):
    value,page=fixture();item=page['items'][0];state=sample('AgentSDKChildContinuation')
    state.update(childId=item['scope']['childId'])
    state['binding'].update(context=deepcopy(value['start']['context']),sdkInstanceId=item['scope']['sdkInstanceId'])
    if fault=='root':state['binding']['context']['rootId']=str(uuid4())
    elif fault=='sibling-context':state['binding']['sdkInstanceId']=page['items'][1]['scope']['sdkInstanceId']
    value['childContinuations']=[state,deepcopy(state)] if fault=='duplicate-state' else [state]
    class Kernel:
        async def child_parallel_page(self,*args,**kwargs):return deepcopy(page)
        async def child_start(self,*args):raise AssertionError('Invalid continuation reached child admission')
    async def run():
        with pytest.raises(SDKModelPolicyError):await journey.run_parallel_children(Driver(),value,Kernel())
    asyncio.run(run())


def test_initial_worker_assignment_cannot_supply_saved_parallel_child_state(monkeypatch):
    from agentic_os_agent_worker import task_service
    value,_=fixture();config,_,binding=binding_fixture();context=binding['context']
    value['start'].update(context=context,modelId=config.model_id)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        childContinuations=[sample('AgentSDKChildContinuation')])
    boundary=SimpleNamespace();transport=SimpleNamespace(boundary=boundary,config=config)
    async def connect(*args,**kwargs):raise AssertionError('Untrusted initial continuation reached Temporal')
    monkeypatch.setattr(task_service.Client,'connect',connect)
    async def run():
        with pytest.raises(SDKModelPolicyError):
            await task_service.serve_read_task(target='127.0.0.1:7233',namespace='default',boundary=boundary,
                transport=transport,history_keys=None,history_key_id=None,start=value,local_synthetic=True)
    asyncio.run(run())


def test_resume_can_match_either_quiesced_child_but_never_a_foreign_operation_or_root():
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver
    value,_=fixture();context=value['start']['context'];first,second=str(uuid4()),str(uuid4())
    driver=AgentTaskDriver();driver.context=context
    driver.control=WorkflowControl(context['rootId'],context['taskId'],first,'waiting-resources')
    driver.parallel_resume_operations=frozenset({first,second})
    def signal(operation,*,root=None,status='resume'):
        driver.command(WorkflowControl(root or context['rootId'],context['taskId'],operation,status))
    signal(str(uuid4()));assert not driver.resumed
    signal(second,root=str(uuid4()));assert not driver.resumed
    signal(second,status='claim');assert not driver.claimed and not driver.resumed
    signal(second);assert driver.resumed
    driver.resumed=False;driver.parallel_resume_operations=frozenset()
    signal(second);assert not driver.resumed
    signal(first);assert driver.resumed
