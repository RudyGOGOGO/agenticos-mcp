"""Independent worker HTTP/SDK composition; all network replies are synthetic."""
import asyncio
from datetime import datetime,timezone
import json

import httpx
import httpx2
import pytest

from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
from agentic_os_agent_worker.transport import OfficialTransport
from provider_transport_fixture import fixture,ident,privacy_configuration


def observation(request,response):
    payload=dict(artifactRef='private-synthetic-output',ciphertextDigest='e'*64,bytes=len(json.dumps(response).encode()),schemaRef='AgentProviderResponse',schemaVersion=1)
    return dict(operation=dict(attemptId=request['grant']['attemptId'],state='succeeded',candidate=payload,
        usage=dict(measured=dict(tokens=110 if response.get('object')=='response' else 122,costMicros=23,workMs=1,computeMs=0,storageBytes=0),completeness='known',providerUsageRef=None),
        receiptRef=None,failure=None),providerRequestId='req_synthetic',providerResponseId=response['id'],model=request['context']['model'])


@pytest.mark.parametrize('provider',['openai','anthropic'])
def test_actual_official_sdk_uses_separate_private_workload_boundary_and_accepted_reply(provider):
    config,request,body,response=fixture(provider);events=[];provider_calls=[];tokens=[]
    config=privacy_configuration(config)
    request['context']['model']['digest']=config.model_profile_digest
    observed=observation(request,response)
    async def token():tokens.append(1);return 'synthetic-workload-token-'+str(len(tokens))
    async def rpc(r):
        assert 'synthetic-provider-key' not in r.headers.get('authorization','')
        assert r.headers['authorization'].startswith('Bearer synthetic-workload-token-')
        value=json.loads(r.content);action=r.url.path.rsplit('/',1)[1];events.append(action)
        assert 'synthetic-reviewed-account-controls' not in r.content.decode()
        assert 'privacy_configuration_json' not in value.get('transport',{})
        if action=='begin':
            assert value['request']==request and value['transport']['modelDigest']==config.model_profile_digest
            assert value['transport']['maxResponseBytes']==config.max_response_bytes
            assert 'synthetic-provider-key' not in r.content.decode()
            return httpx.Response(200,json=dict(inputJson=json.dumps(body)))
        if action=='finish':
            assert value['usage']['outputTokens']==10 and value['providerEvidenceJson'] and value['candidateJson']
            assert value['request']==request
            return httpx.Response(200,json=observed)
        assert action=='accept'
        ref=dict(subject=request['context']['subject'],taskId=request['context']['taskId'],rootId=request['context']['rootId'],
            resultId=ident(20),producerStepId=request['step']['stepId'],acceptedAttemptId=request['grant']['attemptId'],
            payload=observed['operation']['candidate'],lineageRef=None,scopeRef=request['context']['scopeRef'],acceptedAt=datetime.now(timezone.utc).isoformat())
        return httpx.Response(200,json=dict(result=ref,contentJson=json.dumps(response)))
    library=httpx if provider=='openai' else httpx2
    async def upstream(r):
        assert events==['begin']
        assert (r.headers['authorization']=='Bearer synthetic-provider-key' if provider=='openai'
            else r.headers['x-api-key']=='synthetic-provider-key')
        assert 'synthetic-workload-token' not in r.content.decode()
        provider_calls.append(1)
        return library.Response(200,json=response,headers={'x-request-id':'req_synthetic'})
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider-key',network_transport=library.MockTransport(upstream))
        try:
            result=await transport.invoke(request);assert result==observed
            accepted=await boundary.accept_model(request)
            assert accepted['result']['acceptedAttemptId']==request['grant']['attemptId']
            assert json.loads(accepted['contentJson'])==response
        finally:await transport.close();await boundary.close()
    asyncio.run(run())
    assert events==['begin','finish','accept'] and provider_calls==[1] and len(tokens)==3


@pytest.mark.parametrize('status,code',[(401,'UNAUTHENTICATED'),(403,'DENIED'),(429,'CAPACITY'),(503,'UNAVAILABLE')])
def test_boundary_failure_never_retries_or_sends_a_provider_request(status,code):
    config,request,_,_=fixture('openai');calls=[]
    async def token():return 'synthetic-workload-token'
    async def rpc(r):calls.append(r);return httpx.Response(status,json=dict(code=code,private='PRIVATE_RPC_MARKER'),headers={'Retry-After':'3600'})
    async def provider(_):pytest.fail('Provider must not run after a failed begin')
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider-key',network_transport=httpx.MockTransport(provider))
        try:
            with pytest.raises(ModelRPCError) as error:await transport.invoke(request)
            assert error.value.code==code and 'PRIVATE_RPC_MARKER' not in str(error.value)
        finally:await transport.close();await boundary.close()
    asyncio.run(run());assert len(calls)==1


@pytest.mark.parametrize('raw',[b'{"inputJson":"first","inputJson":"second"}',b'{"inputJson":"private","bad":1.0}',
    b'{"inputJson":"private","bad":NaN}',b'x'*(2*1048576+65537)])
def test_ambiguous_or_oversized_kernel_response_cannot_become_executable_input(raw):
    config,request,_,_=fixture('openai');calls=[]
    async def token():return 'synthetic-workload-token'
    async def handler(r):calls.append(r);return httpx.Response(200,content=raw)
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(handler))
        boundary.bind_transport(config)
        try:
            with pytest.raises(ModelRPCError):await boundary.begin_model(request)
        finally:await boundary.close()
    asyncio.run(run());assert len(calls)==1


@pytest.mark.parametrize('url,local',[('http://127.0.0.1:1234',False),('http://example.test',True),
    ('https://user:secret@example.test',False),('https://example.test/?query=private',False),(None,False)])
def test_private_kernel_endpoint_requires_explicit_tls_or_owned_local_profile(url,local):
    async def token():return 'synthetic-token'
    with pytest.raises(ModelRPCError,match='invalid'):RPCModelBoundary(url,token,local_synthetic=local)


def test_client_cancellation_during_begin_does_not_retry_or_start_provider():
    config,request,_,_=fixture('openai');calls=[]
    async def token():return 'synthetic-token'
    async def run():
        entered=asyncio.Event()
        async def handler(r):calls.append(r);entered.set();await asyncio.Event().wait()
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(handler))
        boundary.bind_transport(config)
        try:
            task=asyncio.create_task(boundary.begin_model(request));await entered.wait();task.cancel()
            with pytest.raises(asyncio.CancelledError):await task
        finally:await boundary.close()
    asyncio.run(run());assert len(calls)==1


def test_unbound_worker_cannot_request_executable_input():
    _,request,_,_=fixture('openai');calls=[]
    async def token():return 'synthetic-token'
    async def handler(r):calls.append(r);return httpx.Response(200,json=dict(inputJson='private'))
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(handler))
        try:
            with pytest.raises(ModelRPCError,match='profile_disabled'):await boundary.begin_model(request)
        finally:await boundary.close()
    asyncio.run(run());assert calls==[]


def test_one_private_boundary_cannot_be_rebound_to_different_transport_limits():
    from dataclasses import replace
    config,_,_,_=fixture('openai')
    async def token():return 'synthetic-token'
    async def run():
        boundary=RPCModelBoundary('https://private.synthetic',token)
        try:
            boundary.bind_transport(config);boundary.bind_transport(config)
            with pytest.raises(ModelRPCError,match='conflict'):boundary.bind_transport(replace(config,max_response_bytes=config.max_response_bytes+1))
        finally:await boundary.close()
    asyncio.run(run())
