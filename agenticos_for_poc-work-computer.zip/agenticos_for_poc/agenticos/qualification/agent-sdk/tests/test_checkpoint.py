"""Actual pinned SDK pause/restore with the governed model and synthetic RPC."""
import asyncio
from copy import deepcopy
import json

from agents import Agent,ModelSettings,Runner,RunConfig,function_tool
import httpx
import pytest

from agentic_os_agent_worker.checkpoint import export_checkpoint,restore_checkpoint,tool_alias,SDKCheckpointError
from agentic_os_agent_worker.model_rpc import RPCModelBoundary
from agentic_os_agent_worker.sdk_model import GovernedResponsesModel,GovernedResponsesProvider,SDKModelSequence
from agentic_os_agent_worker.transport import OfficialTransport
from test_sdk_model import binding_fixture,SyntheticOperationRPC,response_document


async def paused(*,instructions_factory=None,dependency_boundary=None,private_input='private checkpoint marker'):
    config,request,binding=binding_fixture();rpc=SyntheticOperationRPC(request);issued=[];executed=[]
    if callable(dependency_boundary):dependency_boundary=dependency_boundary(rpc)
    pin=dict(ref='synthetic.inspect',revision=1,digest='a'*64);name=tool_alias(pin)
    @function_tool(name_override=name,needs_approval=True,failure_error_function=None)
    async def inspect()->str:
        """Synthetic local continuation; this is not a governed Host tool."""
        executed.append(1);return 'inspected'
    async def token():return 'private-checkpoint-workload-token'
    async def upstream(http):
        body=json.loads(http.content);issued.append(body)
        output=([dict(type='message',id='msg_done',role='assistant',status='completed',
            content=[dict(type='output_text',text='Checkpoint continued',annotations=[])])]
            if any(i.get('type')=='function_call_output' for i in body['input']) else
            [dict(type='function_call',call_id='call_checkpoint',id='fc_checkpoint',status='completed',name=name,arguments='{}')])
        return httpx.Response(200,json=response_document(output))
    boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
    transport=OfficialTransport(config,boundary,api_key='private-checkpoint-provider-key',network_transport=httpx.MockTransport(upstream))
    provider=GovernedResponsesProvider(GovernedResponsesModel(transport,max_output_tokens=64))
    def agent():return Agent(name='Private checkpoint',model=config.model_id,tools=[inspect],
        instructions=instructions_factory(sequence,binding) if instructions_factory else None,
        model_settings=ModelSettings(metadata={},max_tokens=64,store=False))
    sequence=SDKModelSequence(binding,dependency_boundary=dependency_boundary)
    result=await Runner.run(agent(),private_input,max_turns=None,hooks=sequence,
        run_config=RunConfig(model_provider=provider,tracing_disabled=True))
    assert len(result.interruptions)==1 and len(issued)==1 and not executed
    saved=export_checkpoint(result,sequence,[pin])
    return dict(config=config,binding=binding,rpc=rpc,issued=issued,executed=executed,pin=pin,agent=agent,
        sequence=sequence,result=result,saved=saved,boundary=boundary,transport=transport,provider=provider,
        dependencies=dependency_boundary)


def test_unwritten_checkpoint_replay_keeps_exact_envelope_without_another_provider_call():
    from uuid import UUID,uuid5
    from test_sdk_tools import Boundary
    class AcceptedLedger(Boundary):
        def __init__(self,rpc):super().__init__();self.rpc=rpc
        async def accepted_model_operation(self,context,operation):
            step=str(uuid5(UUID(operation),'model-attempt/1'))
            result=deepcopy(self.rpc.accepted[step]['result'])
            assert all(result[key]==context[key] for key in ('subject','rootId','taskId'))
            return result
    async def run():
        item=await paused(dependency_boundary=AcceptedLedger);dependencies=item['dependencies']
        try:
            original=deepcopy(item['saved']);sequence=SDKModelSequence(item['binding'],dependency_boundary=dependencies)
            replay=await Runner.run(item['agent'](),'private checkpoint marker',max_turns=None,hooks=sequence,
                run_config=RunConfig(model_provider=item['provider'],tracing_disabled=True))
            assert len(replay.interruptions)==1 and not item['executed']
            assert len(item['issued'])==len(item['rpc'].accepted)==1
            assert export_checkpoint(replay,sequence,[item['pin']])==original
            assert sequence.snapshot()==item['sequence'].snapshot()
            assert len(sequence.snapshot()['inputResults'])==1
        finally:await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())


def test_actual_checkpoint_restores_next_model_binding_and_never_repeats_the_accepted_model():
    async def run():
        item=await paused()
        try:
            raw=json.dumps(item['saved'])
            assert 'private-checkpoint-workload-token' not in raw and 'private-checkpoint-provider-key' not in raw
            assert 'private checkpoint marker' in raw
            saved=json.loads(raw)
            restored=await restore_checkpoint(item['agent'](),saved,expected_context=item['binding']['context'],
                sdk_instance_id=item['binding']['sdkInstanceId'],capabilities=[item['pin']])
            assert restored.sequence.snapshot()==item['sequence'].snapshot()
            # Only a trusted controller may authorize the actual OS lane. This
            # synthetic inspection tests SDK serialization, not Host approval.
            restored.state.approve(restored.state.get_interruptions()[0])
            result=await restored.run(item['provider'])
            assert result.final_output=='Checkpoint continued' and item['executed']==[1]
            assert len(item['issued'])==len(item['rpc'].accepted)==2
            assert restored.sequence.snapshot()['turn']==3
        finally:await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())


@pytest.mark.parametrize('fault',['context','instance','capabilities','trace','turn-limit','schema'])
def test_unqualified_continuations_are_rejected_before_any_new_model_or_tool_call(fault):
    async def run():
        item=await paused()
        try:
            saved=deepcopy(item['saved']);context=deepcopy(item['binding']['context']);instance=item['binding']['sdkInstanceId'];pins=[item['pin']]
            if fault=='context':context['controlEpoch']+=1
            elif fault=='instance':instance='00000000-0000-4000-8000-000000000099'
            elif fault=='capabilities':pins=[item['pin']|dict(revision=2)]
            else:
                state=json.loads(saved['stateJson'])
                if fault=='trace':state['trace']={}
                elif fault=='turn-limit':state['max_turns']=10
                else:state['$schemaVersion']='unqualified'
                saved['stateJson']=json.dumps(state)
            with pytest.raises(SDKCheckpointError):await restore_checkpoint(item['agent'](),saved,
                expected_context=context,sdk_instance_id=instance,capabilities=pins)
            assert len(item['issued'])==1 and item['executed']==[]
        finally:await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())


def test_inflight_model_cannot_be_exported_as_a_finished_sdk_checkpoint():
    async def run():
        item=await paused()
        try:
            item['sequence'].pending='inflight-operation'
            with pytest.raises(SDKCheckpointError):export_checkpoint(item['result'],item['sequence'],[item['pin']])
            assert len(item['issued'])==1 and item['executed']==[]
        finally:await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())
