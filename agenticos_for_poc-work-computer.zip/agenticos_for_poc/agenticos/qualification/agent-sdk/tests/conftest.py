"""Collect only inside a runner-created, private SDK proof target."""
import os
import json
from pathlib import Path
import pytest


def pytest_sessionstart(session):
    from agentic_os.adapters.local.resources import read_signed
    from agentic_os.adapters.local.files import check_private
    root = Path(os.environ.get("AGENTIC_OS_SDK_PROOF_ROOT", ""))
    try:
        if not root.is_absolute():
            raise ValueError()
        check_private(root, directory=True)
        manifest = read_signed(root / "manifest.json", root / "resource.key")
        if manifest != {"version": 1, "profile": "agent-sdk-engineering/1", "root": str(root)}:
            raise ValueError()
        if any(name in os.environ for name in (
            "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "DATABASE_URL", "AGENTIC_OS_TEST_MANIFEST"
        )):
            raise ValueError()
    except Exception:
        raise pytest.UsageError("Use tools/qualify_agent_sdk.py with a fresh private target") from None


@pytest.fixture
def proof_root():
    return Path(os.environ["AGENTIC_OS_SDK_PROOF_ROOT"])


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    phases = getattr(item, "_sdk_completed_phases", {})
    phases[report.when] = report.outcome
    item._sdk_completed_phases = phases
    if report.when != "teardown" or "setup" not in phases:
        return
    if phases["setup"] == "passed" and "call" not in phases:
        return
    result = "skipped" if "skipped" in phases.values() else "failed" if "failed" in phases.values() else "passed"
    record = {"nodeid": item.nodeid, "phases": phases, "result": result}
    root = Path(os.environ["AGENTIC_OS_SDK_PROOF_ROOT"])
    with (root / "completed-cases.jsonl").open("a") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
