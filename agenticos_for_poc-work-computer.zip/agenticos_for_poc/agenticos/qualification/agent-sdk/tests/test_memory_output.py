"""Actual SDK structured memory output; authoritative Core contracts retained."""
import asyncio
from copy import deepcopy
import json
from pathlib import Path
from uuid import uuid4

from agents import Agent,Model,ModelSettings,Runner,RunConfig
from agents.exceptions import ModelBehaviorError
import httpx
import pytest

from agentic_os_agent_worker.memory_output import AnalysisOutput,MemoryOutput
from agentic_os_agent_worker.model_rpc import RPCModelBoundary
from agentic_os_agent_worker.sdk_model import GovernedResponsesModel,GovernedResponsesProvider,SDKModelSequence
from agentic_os_agent_worker.transport import OfficialTransport,_SCHEMA,_validate
from test_sdk_model import binding_fixture,SyntheticOperationRPC,response_document


@pytest.mark.parametrize('options',[
    {},dict(precise=True,charts=True),dict(precise=True,planned=True),
    dict(precise=True,comparison=True),dict(precise=True,extrema=True)])
@pytest.mark.parametrize('compact',[False,True])
def test_response_goal_schema_cannot_be_omitted_from_untyped_or_different_profiles(options,compact):
    from agentic_os_agent_worker.read_journey import analysis_objective_instructions
    from agentic_os_agent_worker.sdk_model import SDKModelPolicyError
    with pytest.raises(SDKModelPolicyError):
        analysis_objective_instructions([],[],goal_schema_in_response=True,compact=compact,**options)


def goal():
    return dict(criteria=[dict(id=str(uuid4()),capability=dict(ref='owner.memory.recall',revision=1,digest='a'*64),
        resources=[dict(providerRef='owner-memory/1',resourceType='owner-memory',externalId=str(uuid4()))],
        fields=['text'],coverage='selected-records')])


@pytest.mark.parametrize('wrong_pin',[False,True])
@pytest.mark.parametrize('outcome',['memory','memory-answer','analysis-goal','analysis-answer','analysis-metric-schema','analysis-schema-once','analysis-base-bounded'])
def test_actual_sdk_transmits_memory_schema_and_rejects_digest_string_without_retry(wrong_pin,outcome):
    compact=outcome=='analysis-base-bounded'
    schema_once=outcome=='analysis-schema-once' or compact
    metric_semantics=outcome=='analysis-metric-schema' or schema_once
    if metric_semantics:outcome='analysis-goal'
    config,request,binding=binding_fixture();rpc=SyntheticOperationRPC(request);issued=[];draft=goal()
    if compact:
        from dataclasses import replace
        config=replace(config,max_request_bytes=16384)
    schema=MemoryOutput(objective=outcome=='memory') if outcome.startswith('memory') else AnalysisOutput(objective=outcome=='analysis-goal',metric_semantics=metric_semantics)
    if outcome!='memory':
        vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
        draft=deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']==schema.contract))
        if outcome=='analysis-answer':
            draft['results']=[deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']=='AgentResultReference'))]
        elif outcome=='memory-answer':
            fact=next(row['value']['facts'][0] for row in vectors if row['valid'] and row['contract']=='AgentReadAnswerDraft' and row['value']['facts'])
            draft['facts']=[deepcopy(fact)|dict(field=field) for field in ['text','memoryType','contextRef','sourceStatus']]
    if wrong_pin:
        if outcome=='analysis-goal':draft['queries'][0]['capability']='a'*64
        elif outcome=='analysis-answer':draft['results']=['agent-accepted-query/1#'+draft['results'][0]['resultId']]
        elif outcome=='memory-answer':draft['facts'][0]['result']='a'*64
        else:draft['criteria'][0]['capability']='a'*64
    raw=json.dumps(draft)
    async def token():return 'synthetic-workload'
    async def upstream(request):
        issued.append(json.loads(request.content))
        return httpx.Response(200,json=response_document([dict(type='message',id='memory-draft',role='assistant',status='completed',
            content=[dict(type='output_text',text=raw,annotations=[])])]))
    async def run():
        from temporalio.contrib.openai_agents._temporal_model_stub import _TemporalModelStub
        from temporalio.contrib.openai_agents._model_parameters import ModelActivityParameters
        from temporalio.contrib.openai_agents._invoke_model_activity import ActivityModelInput,ModelActivity
        from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
        boundary=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc))
        transport=OfficialTransport(config,boundary,api_key='synthetic-provider',network_transport=httpx.MockTransport(upstream))
        try:
            governed=GovernedResponsesModel(transport,max_output_tokens=request['maxOutputTokens'],
                reasoning_effort='low' if outcome.startswith('analysis') else None)
            activity=ModelActivity(model_provider=GovernedResponsesProvider(governed))
            stub=_TemporalModelStub(config.model_id,model_params=ModelActivityParameters(),agent=None)
            converter=AgentPayloadConverter()
            class SerializedTemporal(Model):
                async def get_response(self,system_instructions,input,model_settings,tools,output_schema,handoffs,tracing,**kwargs):
                    # Exercise the exact stub admission, actual serializer and
                    # downstream activity body. Only scheduling/heartbeats and
                    # provider/Core replies are synthetic in this cheap check.
                    wire,_=stub._build_activity_input(system_instructions=system_instructions,input=input,
                        model_settings=model_settings,tools=tools,output_schema=output_schema,handoffs=handoffs,tracing=tracing,**kwargs)
                    decoded=converter.from_payloads(converter.to_payloads([wire]),[ActivityModelInput])[0]
                    return await ModelActivity.invoke_model_activity.__wrapped__(activity,decoded)
                def stream_response(self,*args,**kwargs):raise AssertionError('No streaming in this bounded prerequisite')
            sequence=SDKModelSequence(binding)
            from agentic_os_agent_worker.read_journey import analysis_objective_instructions
            metadata=json.loads((Path(__file__).parents[1]/'fixtures/base-analysis-catalog.json').read_bytes())['metadata'] if compact else dict(capabilities=[],providers=[])
            instructions=(analysis_objective_instructions(metadata['capabilities'],metadata['providers'],precise=True,goal_schema_in_response=True,compact=compact)
                if schema_once else None)
            agent=Agent(name='Typed memory goal',model=SerializedTemporal(),instructions=instructions,
                output_type=schema,model_settings=ModelSettings(metadata={},store=False))
            result=await Runner.run(agent,'Original private memory question',hooks=sequence,
                run_config=RunConfig(tracing_disabled=True))
            assert result.final_output==raw
        finally:await transport.close();await boundary.close()
    if wrong_pin:
        with pytest.raises(ModelBehaviorError):asyncio.run(run())
    else:asyncio.run(run())
    assert len(issued)==1 and issued[0]['text']['format']==dict(type='json_schema',name=schema.name(),schema=schema.json_schema(),strict=True)
    if compact:
        assert len(json.dumps(issued[0],ensure_ascii=False,separators=(',',':')).encode())<=16384
        displayed=json.JSONDecoder().raw_decode(issued[0]['instructions'].split('Reviewed metadata: ',1)[1])[0]
        assert displayed==json.loads((Path(__file__).parents[1]/'fixtures/base-analysis-catalog.json').read_bytes())['metadata']
    if schema_once:
        assert 'Schema: ' not in issued[0]['instructions']
        assert ('supplied by the structured response format' if compact else 'structured response format supplies the complete closed goal schema') in issued[0]['instructions']
    if metric_semantics:
        fields=issued[0]['text']['format']['schema']['$defs']['AgentExactMetric']['properties']
        assert 'Largest TOTAL means aggregate sum' in fields['aggregate']['description']
        assert 'ACROSS the computed group aggregates' in fields['ranking']['description']
        assert 'requested eligible universe' in fields['populationFilters']['description']
    assert issued[0].get('reasoning')==(dict(effort='low') if outcome.startswith('analysis') else None)
    assert rpc.events==['stage','prepare-operation','begin','finish','accept']


@pytest.mark.parametrize('objective',[True,False])
def test_memory_output_uses_only_existing_contract_closure_and_preserves_original_validation(objective):
    schema=MemoryOutput(objective=objective);wire=schema.json_schema();before=deepcopy(wire)
    assert len(json.dumps(wire).encode())<16384 and len(wire['$defs'])<32
    assert set(wire['$defs'])<=set(_SCHEMA['$defs'])
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
    value=goal() if objective else deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']==schema.contract))
    raw=json.dumps(value);assert schema.validate_json(raw)==raw;_validate(schema.contract,value)
    if objective:
        duplicate=deepcopy(value);duplicate['criteria'][0]['fields']=['text','text']
        with pytest.raises(ModelBehaviorError):schema.validate_json(json.dumps(duplicate))
    with pytest.raises(ModelBehaviorError):schema.validate_json(raw[:-1])
    wire.clear();assert schema.json_schema()==before
