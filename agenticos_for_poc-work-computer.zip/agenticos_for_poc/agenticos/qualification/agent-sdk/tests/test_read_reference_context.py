"""Real SDK tool payloads fit a small model window without copying source values."""
import asyncio
from copy import deepcopy
from dataclasses import replace
import json
from types import SimpleNamespace

from agents import Agent,ModelSettings,Runner,RunConfig
from agents.exceptions import UserError
from agents.models.interface import ModelTracing
import pytest

from agentic_os_agent_worker.sdk_model import (BINDING_KEY,GovernedResponsesModel,
    SDKModelSequence,SDKModelPolicyError)
from agentic_os_agent_worker.sdk_tools import governed_read_tool
from agentic_os_agent_worker.transport import _validate
from test_sdk_model import binding_fixture
from test_sdk_tools import Boundary,ModelCalls,item_fixture
from test_tool_execution_rpc import accepted_for

PRIVATE_VALUE='PRIVATE-SELECTED-VALUE-'+'🔒'*960


def source_result(request):
    result=accepted_for(request);page=json.loads(result['accepted']['payloadJson'])
    page['evidence'].update(publicFields=['body'],resourceRefs=[dict(subject=deepcopy(request['context']['subject']),
        providerId=page['evidence']['providerRef'],resourceType='note',contractVersion=1,externalId='00007',observedVersion='1')])
    page['records']=[[dict(name='body',value=PRIVATE_VALUE)]]
    _validate('EvidencePage',page)
    return result,page


def test_actual_sdk_reference_projection_preserves_exact_sources_and_avoids_large_input(record_property):
    config,_,binding=binding_fixture();captures={};sources=[];references=[]
    class SourceBoundary(Boundary):
        async def execute_tool(self,request):
            self.requests.append(deepcopy(request));result,page=source_result(request);sources.append(page)
            result['accepted']['payloadJson']=json.dumps(page,ensure_ascii=False,separators=(',',':'))
            references.append(deepcopy(result['accepted']['result']))
            return result
    async def capture(profile):
        boundary=SourceBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
        tool=governed_read_tool(item_fixture(),boundary,sequence,result_context=profile);model=ModelCalls(tool.name,count=1)
        agent=Agent(name='Literal field read',model=model,tools=[tool],instructions='Select exact accepted fact references.',
            model_settings=ModelSettings(metadata={}))
        result=await Runner.run(agent,'Read this selected body',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
        assert result.final_output=='Done' and len(boundary.requests)==1 and len(model.inputs)==2
        captures[profile]=(model.inputs[1],model.bindings[1],tool)
    asyncio.run(capture('agent-accepted-read/1'));asyncio.run(capture('agent-accepted-read-ref/1'))
    full_items,full_binding,full_tool=captures['agent-accepted-read/1']
    compact_items,compact_binding,compact_tool=captures['agent-accepted-read-ref/1']
    full=json.loads(next(item['output'] for item in full_items if item.get('type')=='function_call_output'))
    compact=json.loads(next(item['output'] for item in compact_items if item.get('type')=='function_call_output'))
    _validate('AgentAcceptedReadReferenceContext',compact)
    assert compact['resources']==sources[1]['evidence']['resourceRefs'] and compact['fields']==['body']
    assert compact['result']==references[1] and full['result']==references[0]
    assert PRIVATE_VALUE in json.dumps(full,ensure_ascii=False)
    assert 'PRIVATE-SELECTED-VALUE-' not in json.dumps(compact,ensure_ascii=False) and 'page' not in compact
    class NoIO:
        async def stage_model_input(self,*_):raise AssertionError('Rejected input reached private storage')
        async def prepare_model_operation(self,*_):raise AssertionError('Rejected input reached admission')
        async def accept_model(self,*_):raise AssertionError('Rejected input reached acceptance')
    model=GovernedResponsesModel(SimpleNamespace(config=replace(config,max_request_bytes=4096),boundary=NoIO()),max_output_tokens=64)
    full_settings=ModelSettings(metadata={BINDING_KEY:json.dumps(full_binding)},store=False)
    compact_settings=ModelSettings(metadata={BINDING_KEY:json.dumps(compact_binding)},store=False)
    with pytest.raises(SDKModelPolicyError):
        asyncio.run(model.get_response('Select exact accepted fact references.',full_items,full_settings,[full_tool],None,[],
            ModelTracing.DISABLED,previous_response_id=None,conversation_id=None,prompt=None))
    _,_,raw=model._request('Select exact accepted fact references.',compact_items,compact_settings,[compact_tool],None,[],
        ModelTracing.DISABLED,None,None,None)
    assert len(raw.encode())<=4096 and 'PRIVATE-SELECTED-VALUE-' not in raw
    wider=GovernedResponsesModel(SimpleNamespace(config=replace(config,max_request_bytes=49152),boundary=NoIO()),max_output_tokens=64)
    _,_,full_raw=wider._request('Select exact accepted fact references.',full_items,full_settings,[full_tool],None,[],
        ModelTracing.DISABLED,None,None,None)
    assert len(full_raw.encode())>4096
    record_property('full_request_bytes',len(full_raw.encode()));record_property('reference_request_bytes',len(raw.encode()))


@pytest.mark.parametrize('fault',['page-owner','resource-owner'])
def test_reference_projection_rejects_foreign_metadata_before_another_sdk_model(fault):
    _,_,binding=binding_fixture()
    class ForeignBoundary(Boundary):
        async def execute_tool(self,request):
            self.requests.append(deepcopy(request));result,page=source_result(request)
            if fault=='page-owner':page['evidence']['subject']['subjectId']='foreign'
            else:page['evidence']['resourceRefs'][0]['subject']['subjectId']='foreign'
            result['accepted']['payloadJson']=json.dumps(page,ensure_ascii=False);return result
    boundary=ForeignBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    tool=governed_read_tool(item_fixture(),boundary,sequence,result_context='agent-accepted-read-ref/1');model=ModelCalls(tool.name,count=1)
    agent=Agent(name='Scoped reference read',model=model,tools=[tool],model_settings=ModelSettings(metadata={}))
    with pytest.raises(UserError):
        asyncio.run(Runner.run(agent,'Read only this selected record',hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True)))
    assert len(boundary.requests)==len(model.inputs)==1
