"""Actual supported SDK tool pauses and fresh bounded query contexts."""
import asyncio
from copy import deepcopy
from dataclasses import replace
import json

from agents import Agent,ModelSettings,RunConfig,Runner
import pytest

from agentic_os_agent_worker.checkpoint import export_checkpoint,restore_checkpoint
from agentic_os_agent_worker.query_context import completed_query_window,incomplete_query_window,query_window_selected,MAXIMUM_WINDOW_BYTES
from agentic_os_agent_worker.sdk_model import SDKModelSequence,SDKModelPolicyError
from agentic_os_agent_worker.sdk_tools import governed_read_tool
from test_sdk_model import binding_fixture
from test_sdk_tools import Boundary,ModelCalls,item_fixture
from test_tool_execution_rpc import accepted_for


@pytest.mark.parametrize('large_arguments',[False,True])
def test_actual_sdk_query_windows_keep_frontier_and_causal_refs_across_private_pause_restore(large_arguments,record_property):
    _,_,binding=binding_fixture();original=deepcopy(binding['context']);goal='a'*64
    class QueryBoundary(Boundary):
        async def execute_tool(self,request):
            ordinal=len(self.requests);self.requests.append(deepcopy(request));result=accepted_for(request,query=True)
            value=json.loads(result['accepted']['payloadJson'])
            value.update(pageOrdinal=ordinal,requestCursor=None if ordinal==0 else 'cursor/'+str(ordinal))
            value['page'].update(records=[[dict(name='raw',value='PRIVATE-RAW-'+'x'*900)] for _ in range(16)],
                nextCursor=None if ordinal==11 else 'cursor/'+str(ordinal+1))
            result['accepted']['payloadJson']=json.dumps(value,separators=(',',':'))
            result['accepted']['result']['payload']['bytes']=len(result['accepted']['payloadJson'].encode())
            # Distinct page identities, as supplied by the actual Core journal.
            from uuid import UUID,uuid5
            result['accepted']['result']['resultId']=str(uuid5(UUID(request['modelOperationId']),'page/'+str(ordinal)))
            return result
    boundary=QueryBoundary();sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    previous=json.dumps(incomplete_query_window(sequence,None,goal));sizes=[];heads=[];payload_sizes=[]
    item=item_fixture()
    if large_arguments:
        schema=json.loads(item['inputSchemaJson']);schema['properties']['ids']=dict(type='array',items=dict(type='string'))
        schema['required'].append('ids');item['inputSchemaJson']=json.dumps(schema)
    class QueryModel(ModelCalls):
        async def get_response(self,*args,**kwargs):
            response=await super().get_response(*args,**kwargs)
            if large_arguments and len(self.inputs)==1:
                response.output[0].arguments=json.dumps(dict(value=0.5,ids=[str(100000+i) for i in range(128)]))
            return response
    async def run():
        nonlocal sequence,previous
        for ordinal in range(12):
            tool=replace(governed_read_tool(item,boundary,sequence,result_context='agent-accepted-query-ref/1'),needs_approval=True)
            model=QueryModel(tool.name,count=1)
            agent=Agent(name='Bounded query',model=model,tools=[tool],tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
            initial='Read the original query' if previous is None else json.loads(previous)
            paused=await Runner.run(agent,initial,hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
            assert len(paused.interruptions)==1 and len(boundary.requests)==ordinal
            with pytest.raises(SDKModelPolicyError):completed_query_window(paused,sequence,previous,goal)
            envelope=export_checkpoint(paused,sequence,[item['capability']])
            from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
            encoded=AgentPayloadConverter().to_payloads([dict(checkpointId='00000000-0000-4000-8000-000000000001',value=envelope)])[0]
            payload_sizes.append(len(encoded.SerializeToString(deterministic=True)))
            assert payload_sizes[-1]<=65536
            sequence=SDKModelSequence(envelope['binding'],dependency_boundary=boundary)
            tool=replace(governed_read_tool(item,boundary,sequence,result_context='agent-accepted-query-ref/1'),needs_approval=True)
            agent=Agent(name=agent.name,model=model,tools=[tool],tool_use_behavior='stop_on_first_tool',model_settings=ModelSettings(metadata={}))
            loaded=await restore_checkpoint(agent,envelope,expected_context=original,sdk_instance_id=binding['sdkInstanceId'],
                capabilities=[item['capability']],sequence=sequence,dependency_boundary=boundary)
            for interruption in loaded.state.get_interruptions():loaded.state.approve(interruption)
            result=await Runner.run(agent,loaded.state,hooks=sequence,max_turns=None,run_config=RunConfig(tracing_disabled=True))
            assert len(model.inputs)==1 and len(boundary.requests)==ordinal+1
            # Replay the real read-journey dispatch on this serialized SDK
            # pause/restore result. A provider tool call is not a malformed
            # final answer and must reach the query frontier consumer first.
            import ast
            from pathlib import Path
            from types import SimpleNamespace
            from agents.items import ToolCallOutputItem
            from agentic_os_agent_worker.memory_output import completion_frame_valid
            import agentic_os_agent_worker.read_journey as journey
            tree=ast.parse(Path(journey.__file__).read_text())
            guard=next(node.test for node in ast.walk(tree) if isinstance(node,ast.If)
                and any(isinstance(child,ast.Constant) and child.value=='query-tool-round-before-completion-envelope/1'
                    for child in ast.walk(node.test)))
            def dispatch(candidate,*,bounded=True,patched=True):
                return eval(compile(ast.Expression(guard),'actual-query-completion-dispatch','eval'),
                    dict(result=candidate,bounded_query=bounded,ToolCallOutputItem=ToolCallOutputItem,
                        workflow=SimpleNamespace(patched=lambda name:patched)))
            assert not completion_frame_valid([item.model_dump(mode='json') for item in result.raw_responses[-1].output])
            assert dispatch(result) and not dispatch(result,bounded=False) and not dispatch(result,patched=False)
            # No tool-output bypass applies to genuine final messages: the
            # unchanged strict envelope still rejects duplicate completions.
            final=dict(type='message',role='assistant',content=[dict(type='output_text',text='{}')])
            assert not dispatch(SimpleNamespace(new_items=[]))
            assert completion_frame_valid([final]) and not completion_frame_valid([final,final])
            if ordinal==1:
                from agents.items import ToolCallOutputItem
                from types import SimpleNamespace
                actual=next(item for item in result.new_items if isinstance(item,ToolCallOutputItem))
                for fault in ('foreign-result','cursor','ordinal'):
                    changed=json.loads(actual.output)
                    if fault=='foreign-result':changed['result']['rootId']='00000000-0000-4000-8000-000000000099'
                    elif fault=='cursor':changed['requestCursor']='forged-cursor'
                    else:changed['pageOrdinal']+=1
                    forged=SimpleNamespace(interruptions=[],new_items=[replace(actual,output=json.dumps(changed))])
                    with pytest.raises(SDKModelPolicyError):completed_query_window(forged,sequence,previous,goal)
                with pytest.raises(SDKModelPolicyError):completed_query_window(result,sequence,previous,'b'*64)
            window=completed_query_window(result,sequence,previous,goal)
            previous=json.dumps(window,separators=(',',':'));sizes.append(len(previous.encode()))
            saved=json.loads(window[0]['content']);heads.append(deepcopy(saved['results']))
            assert saved['frontiers'][0]['pageOrdinal']==ordinal
            assert saved['frontiers'][0]['nextCursor']==(None if ordinal==11 else 'cursor/'+str(ordinal+1))
            assert saved['results']==sequence.snapshot()['inputResults'] and len(saved['results'])==2
            assert sequence.snapshot()['context']==original and 'PRIVATE-RAW-' not in previous
            if ordinal:
                assert model.bindings[0]['inputResults']==heads[ordinal-1]
        assert len({r['modelOperationId'] for r in boundary.requests})==12
        assert max(sizes)<8192<MAXIMUM_WINDOW_BYTES and max(sizes)-min(sizes)<100
    asyncio.run(run());record_property('maximum_private_checkpoint_payload_bytes',max(payload_sizes))


def test_explicit_private_window_opt_in_survives_rollover_without_selecting_legacy_transcripts():
    _,_,binding=binding_fixture();sequence=SDKModelSequence(binding,dependency_boundary=Boundary());goal='a'*64
    for previous in [None,json.dumps([dict(role='user',content='original request')]),
            json.dumps([dict(role='user',content='{ordinary legacy request')]),
            json.dumps([dict(role='user',content='original'),dict(type='function_call_output',call_id='old',output='{}')])]:
        assert not query_window_selected(previous,goal)
    window=json.dumps(incomplete_query_window(sequence,None,goal))
    assert query_window_selected(window,goal)
    assert query_window_selected(json.dumps(json.loads(window)),goal)
    with pytest.raises(SDKModelPolicyError):query_window_selected(window,'b'*64)


@pytest.mark.parametrize('have_page',[False,True])
def test_incomplete_candidate_keeps_bounded_frontier_and_accepted_head(monkeypatch,have_page):
    from pathlib import Path
    from types import SimpleNamespace
    from agentic_os_agent_worker import query_source_journey
    from agentic_os_agent_worker.query_context import incomplete_query_window
    from uuid import UUID,uuid5
    _,_,binding=binding_fixture();boundary=Boundary();goal='a'*64
    binding['parentOperationId']=str(uuid5(UUID(binding['sdkInstanceId']),'incomplete-candidate'))
    binding['inputResults']=[asyncio.run(boundary.accepted_model_operation(binding['context'],binding['parentOperationId']))]
    sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    # Saved navigation comes from an earlier completed, accepted round. The
    # incomplete model candidate now owns the latest causal result reference.
    previous=incomplete_query_window(sequence,None,goal)
    content=json.loads(previous[0]['content'])
    if have_page:content['frontiers']=[dict(queryDigest='b'*64,pageOrdinal=4,nextCursor='owned-next-page')]
    previous=[dict(role='user',content=json.dumps(content))]
    value=deepcopy(next(row['value'] for row in json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
        if row['valid'] and row['contract']=='AgentSDKQuerySourceChildJoinJourneyStart'))
    value.update(phase='query-source',binding=sequence.snapshot(),goalDigest=goal,continuationInputJson=json.dumps(previous))
    value['start']['context']=binding['context']
    async def incomplete(context,operation):return dict(kind='incomplete',missingCriteria=['00000000-0000-4000-8000-000000000099'])
    class Continued(Exception):pass
    observed=[]
    def carry(value):observed.append(deepcopy(value));raise Continued()
    monkeypatch.setattr(query_source_journey.workflow,'continue_as_new',carry)
    def forbidden():raise AssertionError('Do not restore an incomplete candidate transcript')
    with pytest.raises(Continued):
        asyncio.run(query_source_journey.complete_source(None,value,SimpleNamespace(complete_query_source=incomplete),sequence,
            SimpleNamespace(to_input_list=forbidden),bounded=True))
    saved=json.loads(observed[0]['continuationInputJson']);assert len(saved)==1
    current=json.loads(saved[0]['content'])
    assert current['frontiers']==content['frontiers'] and current['results']==sequence.snapshot()['inputResults']
    assert observed[0]['start']['checkpointId'] is None and observed[0]['start']['context']==binding['context']
