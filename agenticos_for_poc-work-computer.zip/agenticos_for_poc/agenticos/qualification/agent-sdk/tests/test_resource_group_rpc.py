"""Independent worker preserves resource wait identity; synthetic HTTP only."""
import asyncio
from copy import deepcopy
from datetime import datetime,timezone
from uuid import uuid4
import httpx
import pytest
from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError,ResourceGroupDeferred
from agentic_os_agent_worker.temporal_driver import _rpc_control
from test_operation_rpc import operation_fixture


def outcome(context,kind='resource-wait'):
    units=dict(tokens=160,costMicros=300,workMs=90000,computeMs=60000,storageBytes=32768)
    if kind=='resource-limit':return dict(kind=kind,groupId=str(uuid4()),required=units,authorizationHorizon=context['authorizationHorizon'])
    wait={k:deepcopy(context[k]) for k in ('subject','rootId','taskId','segmentId','controlEpoch','authorizationHorizon')}
    wait.update(groupId=str(uuid4()),ticket=3,state='WAITING',required=units,createdAt=datetime.now(timezone.utc).isoformat())
    return dict(kind=kind,wait=wait)


@pytest.mark.parametrize('action',['stage','prepare-operation','history-put','checkpoint-put'])
def test_wait_is_typed_current_context_and_never_retried_by_http(action):
    config,record,raw,_,_=operation_fixture();context=record['context'];value=outcome(context);seen=[]
    async def token():return 'synthetic-workload'
    async def rpc(request):seen.append(request.url.path);return httpx.Response(409,json=value)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            with pytest.raises(ResourceGroupDeferred) as caught:
                if action=='stage':await client.stage_model_input(context,record['identity']['operationId'],raw)
                elif action=='prepare-operation':await client.prepare_model_operation(record,max_output_tokens=64,request_timeout_ms=10000)
                else:
                    # Exercise shared transport context extraction independently
                    # of unrelated checkpoint/history fixture serialization.
                    command=dict(context=context) if action=='history-put' else dict(value=dict(binding=dict(context=context)))
                    await client._send(action,command,'AgentPayloadPreparation')
            assert caught.value.outcome==value and caught.value.code=='CAPACITY'
            control=_rpc_control(context,caught.value,record['identity']['operationId'])
            assert control.status=='waiting-resources' and control.rootId==context['rootId']
            assert control.operationId==record['identity']['operationId'] and control.notBefore is None
        finally:await client.close()
    asyncio.run(run());assert len(seen)==1


@pytest.mark.parametrize('fault',['owner','root','task','segment','epoch','horizon','shape','ready'])
def test_foreign_or_malformed_wait_cannot_become_a_resumable_resource_control(fault):
    config,record,raw,_,_=operation_fixture();context=record['context'];value=outcome(context)
    if fault=='owner':value['wait']['subject']['subjectId']='foreign'
    elif fault in {'root','task','segment'}:value['wait'][fault+'Id']=str(uuid4())
    elif fault=='epoch':value['wait']['controlEpoch']+=1
    elif fault=='horizon':value['wait']['authorizationHorizon']='2099-01-01T00:00:00Z'
    elif fault=='shape':value['wait']['credential']='foreign'
    else:value=dict(kind='group-ready',groupId=str(uuid4()))
    async def token():return 'synthetic-workload'
    async def rpc(_):return httpx.Response(409,json=value)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            with pytest.raises(ModelRPCError) as caught:await client.stage_model_input(context,record['identity']['operationId'],raw)
            assert not isinstance(caught.value,ResourceGroupDeferred)
        finally:await client.close()
    asyncio.run(run())


def test_original_lifetime_exhaustion_requires_configuration_and_never_automatic_retry():
    config,record,raw,_,_=operation_fixture();context=record['context'];value=outcome(context,'resource-limit')
    async def token():return 'synthetic-workload'
    async def rpc(_):return httpx.Response(409,json=value)
    async def run():
        client=RPCModelBoundary('https://private.synthetic',token,network_transport=httpx.MockTransport(rpc));client.bind_transport(config)
        try:
            with pytest.raises(ResourceGroupDeferred) as caught:await client.stage_model_input(context,record['identity']['operationId'],raw)
            assert caught.value.outcome==value and _rpc_control(context,caught.value).status=='configuration-required'
        finally:await client.close()
    asyncio.run(run())
