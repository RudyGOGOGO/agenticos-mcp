"""Frozen allocation outcome through the actual serialized SDK and bound goal consumer."""
import asyncio
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import pytest

from agents import RunConfig
from agents.models.interface import ModelProvider

from agentic_os_agent_worker import read_journey
from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
from agentic_os_agent_worker.transport import _validate
from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,ReadControl
from agentic_os.contracts.canonical import digest
from agentic_os.contracts.validation import validate_contract
from test_lookup_read import Rollover,sample,binding_fixture,Boundary,item_fixture,ScriptedModel,calls,answer,accepted_for


@pytest.mark.parametrize('typed_analysis,empty_discovery,invalid_goal,outcome',[
    (False,False,False,'property-composition'),(True,False,False,'property-composition'),(False,False,False,'exact-chart'),
    (True,True,False,'property-composition'),(True,True,True,'property-composition'),(True,False,False,'all-pages'),(True,False,False,'laboratory-join'),(True,False,False,'exact-chart'),(True,False,False,'laboratory-captured-fields'),(True,False,False,'property-captured-reference'),(True,False,False,'laboratory-premature-goal'),(True,False,False,'all-pages-captured-fields'),(True,False,False,'all-pages-feedback-overflow'),(True,False,False,'property-feedback-overflow'),(True,False,False,'chart-captured-fields')])
def test_actual_property_entry_serializes_discovery_goal_pages_and_bound_consumer(monkeypatch,typed_analysis,empty_discovery,invalid_goal,outcome):
    root=Path(__file__).parents[3]
    captured=outcome=='laboratory-captured-fields'
    overflow_goal=outcome=='all-pages-feedback-overflow';overflow_answer=outcome=='property-feedback-overflow'
    captured_reference=outcome=='property-captured-reference' or overflow_answer
    premature_goal=outcome=='laboratory-premature-goal'
    captured_chart=outcome=='chart-captured-fields'
    if captured_chart:outcome='exact-chart'
    captured_rows=outcome=='all-pages-captured-fields' or overflow_goal
    if captured_rows:outcome='all-pages'
    if premature_goal:outcome='laboratory-join'
    if captured_reference:outcome='property-composition'
    if captured:outcome='laboratory-join'
    captured_case=json.loads((Path(__file__).parents[1]/'fixtures/laboratory-provider-fields.json').read_bytes()) if captured else None
    bank=json.loads((root/'qualification/production-agent/fixtures/english-task-bank-v1.json').read_bytes())
    frozen=json.loads((root/'qualification/production-agent/fixtures/host-outcomes-v1.json').read_bytes())
    question=next(row['question'] for row in bank['cases'] if row['id']==outcome)
    chart=outcome=='exact-chart'
    start_schema='AgentSDKChartAnalysisJourneyStart' if chart else 'AgentSDKAdaptiveAnalysisJourneyStart'
    goal_schema='AgentChartAnalysisGoalDraft' if chart else 'AgentAnalysisGoalDraft'
    value=sample(start_schema);_,_,binding=binding_fixture();context=deepcopy(binding['context'])
    discovery=item_fixture();discovery['capability']['ref']='owned.utility-discovery'
    discovery['inputSchemaJson']=json.dumps(dict(type='object',additionalProperties=False,required=['q','cursor'],properties=dict(q=dict(type='string'),cursor=dict(type=['string','null']))))
    primary=deepcopy(discovery);primary['capability']['ref']='owned.allocation-query'
    primary['description']='Posted allocations. Declared period: '+frozen['window']['startDate']+'..'+frozen['window']['endDateInclusive']+'. Sum allocatedNet by property,currency; billFaceAmount repeats invoice net.'
    primary['inputSchemaJson']=json.dumps(dict(type='object',additionalProperties=False,required=['utility_id','start','end','cursor'],properties=dict(utility_id=dict(type='integer'),start=dict(type='string'),end=dict(type='string'),cursor=dict(type=['string','null']))))
    laboratory=outcome=='laboratory-join'
    grain=['billId','lineId','allocationId','propertyId','currency'];groups=['billId']
    if laboratory:
        discovery['capability']['ref']='owned.project-discovery'
        discovery['inputSchemaJson']=json.dumps(dict(type='object',properties=dict(cursor=dict(type=['string','null'])),required=['cursor'],additionalProperties=False))
        primary['capability']['ref']='owned.laboratory-query'
        primary['inputSchemaJson']=json.dumps(dict(type='object',properties={key:dict(type='string') for key in ['projectId','metric','targetUnit']}|dict(cursor=dict(type=['string','null'])),required=['projectId','metric','targetUnit','cursor'],additionalProperties=False))
        primary['description']='Current authorized samples; filter accepted before latest version, convert using returned factors; missing is unknown.'
        grain=['projectId','sampleId','readingId','version'];groups=['sampleId']
    primary['outputSchemaJson']=json.dumps(dict(type='object',properties=dict(grain=dict(type='array',const=grain),pageGroupFields=dict(type='array',const=groups))))
    if chart:
        shape=json.loads(primary['outputSchemaJson'])
        fields=['billId','lineId','allocationId','propertyId','property','currency','allocatedNet','billFaceAmount']+(['utilityId'] if captured_chart else [])
        shape['properties']['page']=dict(properties=dict(evidence=dict(properties=dict(publicFields=dict(const=fields))),
            records=dict(items=dict(items=dict(properties=dict(value=dict(anyOf=[dict(type='string'),dict(type='null')])))))))
        primary['outputSchemaJson']=json.dumps(shape)
    if captured:
        shape=json.loads(primary['outputSchemaJson'])
        fields=[cell['name'] for cell in captured_case['sourceRows'][0][0]]
        shape['properties']['page']=dict(properties=dict(evidence=dict(properties=dict(publicFields=dict(const=fields)))))
        primary['outputSchemaJson']=json.dumps(shape)
    if captured_rows:
        shape=json.loads(primary['outputSchemaJson'])
        fields=['billId','lineId','allocationId','propertyId','property','currency','allocatedNet','billFaceAmount','utilityId']
        shape['properties']['page']=dict(properties=dict(evidence=dict(properties=dict(publicFields=dict(const=fields))),
            records=dict(items=dict(items=dict(properties=dict(value=dict(anyOf=[dict(type='string'),dict(type='null')])))))))
        primary['outputSchemaJson']=json.dumps(shape)
    context['harness']['ref']=('adaptive-analysis-charts/' if chart else 'adaptive-analysis-discovery/')+digest('manifest',[discovery['capability']])
    value['start'].update(context=context,input=question,capabilities=[primary,discovery],checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        discoveryCapabilities=[discovery['capability']],providers=[dict(capability=item['capability'],providerRef='synthetic.read') for item in (primary,discovery)])
    _validate(start_schema,value)
    spec=importlib.util.spec_from_file_location('actual_property_provider',root/'tests/integration/resources/analysis_fixture.py')
    fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
    if captured:discovery['description']=fixture.laboratory_tool_configuration(dict(id='owned.read'))['discovery']['agentToolSchema']['description']
    queue=[];saved={};material=[];drafts=[];goals=[];completed=[];converter=AgentPayloadConverter()
    def wire(item):
        payload=converter.to_payloads([item])[0];assert len(payload.SerializeToString(deterministic=True))<=65536
        return converter.from_payloads([payload])[0]
    def rollover(item,**options):queue.append(wire(item));raise Rollover()
    workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=workflow_id,is_continue_as_new_suggested=lambda:True,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:typed_analysis and name in {'analysis-output-contracts/1','analysis-goal-schema-feedback/1'} or captured and name in {'analysis-goal-source-fields/1','analysis-goal-aggregation-coverage/1','analysis-extremum-winner-identity/1'} or captured_reference and name in {'analysis-answer-reference-feedback/1','analysis-requested-currency-population/1','analysis-metric-schema-semantics/1'} or premature_goal and name in {'analysis-discovery-before-goal/1','analysis-metric-schema-semantics/1','analysis-answer-reference-feedback/1'} or captured_rows and name in {'analysis-goal-source-fields/1','analysis-goal-source-value-types/1','analysis-requested-group-coverage/1','analysis-discovery-before-goal/1'} or (overflow_goal or overflow_answer) and name=='analysis-feedback-window/1')
    original_patched=read_journey.workflow.patched
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:name=='analysis-typed-feedback-message/1'
        or typed_analysis and name in {'analysis-chart-output-contracts/1','analysis-goal-request-cursor/1'}
        or captured_chart and name in {'analysis-goal-source-fields/1','analysis-goal-source-value-types/1'} or original_patched(name))
    window_sizes=[]
    if overflow_goal or overflow_answer:
        from agentic_os_agent_worker import memory_output
        original_window=memory_output.analysis_feedback_continuation
        def observed_window(items,question):
            result=original_window(items,question);window_sizes.append((len(json.dumps(items)),len(result) if result else None))
            return result
        monkeypatch.setattr(memory_output,'analysis_feedback_continuation',observed_window)
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    kernel=Boundary();query_count=0;discovery_count=0
    async def accepted(self,c,operation):return await kernel.accepted_model_operation(c,operation)
    async def checkpoint(self,c,ident):return deepcopy(saved[ident])
    async def execute(self,request):
        nonlocal query_count,discovery_count
        response=accepted_for(request,query=True);source=response['accepted'];page=json.loads(source['payloadJson']);args=json.loads(request['argumentsJson'])
        if request['capability']==discovery['capability']:
            assert args==(dict(cursor=None) if laboratory else dict(q='water allocations utility' if empty_discovery and discovery_count==0 else 'water',cursor=None))
            rows=[] if empty_discovery and discovery_count==0 else [dict(utilityId='741',name='water')]
            if laboratory:rows=[dict(projectId='resolved-project-741',name='Current project')]
            discovery_count+=1
            actual_grain=['projectId'] if laboratory else ['utilityId'];actual_groups=['projectId'] if laboratory else [];cursor=None;ordinal=0;expected=len(rows)
        else:
            if laboratory:
                assert args==dict(projectId='resolved-project-741',metric='concentration',targetUnit='mg/L',cursor=None if query_count==0 else 'next-page')
                lab=frozen['laboratory'];selected={'s1','s2'} if query_count==0 else {'s3'};rows=[]
                for sample in lab['samples']:
                    if sample['id'] not in selected:continue
                    readings=[r for r in lab['readings'] if r['sample']==sample['id'] and r['metric']=='concentration'] or [dict(id='missing/'+sample['id']+'/concentration',version=0,state='missing',amount=None,unit=None)]
                    for reading in readings:
                        rule=next((r for r in lab['unitConversions'] if r['from']==reading['unit'] and r['to']=='mg/L'),None)
                        rows.append(dict(projectId=args['projectId'],sampleId=sample['id'],readingId=reading['id'],version=reading['version'],state=reading['state'],
                            metric='concentration',amount=reading['amount'],unit=reading['unit'],targetUnit='mg/L',
                            conversionFactor='1' if reading['unit']=='mg/L' else rule['factor'] if rule else None,
                            conversionVersion='laboratory.identity-units/1' if reading['unit']=='mg/L' else rule['version'] if rule else None))
            else:
                assert args==dict(utility_id=741,start=frozen['window']['startDate'],end=frozen['window']['endDateInclusive'],cursor=None if query_count==0 else 'next-page')
                bills=[bill for bill in frozen['warehouse']['bills'] if bill['id'] in frozen['warehouse']['golden']['eligibleBills']]
                selected=bills[:2] if query_count==0 else bills[2:];rows=[]
                names={prop['id']:prop['name'] for prop in frozen['warehouse']['properties']}
                for bill in selected:
                    for line in bill['lines']:
                        for allocation in line['allocations']:
                            rows.append(dict(billId=bill['id'],lineId=line['id'],allocationId=allocation['id'],propertyId=allocation['property'],
                                property=names[allocation['property']],currency=bill['currency'],allocatedNet=allocation['net'],billFaceAmount=bill['faceAmount']))
                if captured_rows or captured_chart:
                    for row in rows:row['utilityId']=str(args['utility_id'])
            actual_grain=grain;actual_groups=groups;cursor='next-page' if query_count==0 else None;ordinal=query_count;expected=5 if laboratory else 7;query_count+=1
            if captured:
                rows=[{cell['name']:cell['value'] for cell in row} for row in captured_case['sourceRows'][ordinal]]
                for row in rows:row['projectId']=args['projectId']
        page.update(queryDigest=digest('command',{key:arg for key,arg in args.items() if key!='cursor'}),requestCursor=args['cursor'],pageOrdinal=ordinal,grain=actual_grain,pageGroupFields=actual_groups)
        page['page'].update(records=[[dict(name=key,value=arg) for key,arg in row.items()] for row in rows],nextCursor=cursor)
        page['page']['evidence']['publicFields']=list(rows[0]) if rows else ['utilityId','name']
        page['coverage'].update(observedRows=len(rows),expectedRows=expected,status='partial' if cursor else 'complete',nextCursorRef='cursor/'+digest('command',cursor) if cursor else None)
        source['payloadJson']=json.dumps(page);source['result'].update(subject=context['subject'],rootId=context['rootId'],taskId=context['taskId'],scopeRef=context['scopeRef'])
        source['result']['payload']['bytes']=len(source['payloadJson'].encode())
        material.append(dict(result=source['result'],binding=source['binding'],query=page,page=page['page']))
        return response
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',checkpoint)
    monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    altered=[];reference_feedback=[];premature=[];discovery_feedback=[];row_proposals=[];row_feedback=[]
    class Model(ScriptedModel):
        async def get_response(self,system_instructions,input,*args,**kwargs):
            schema=kwargs.get('output_schema',args[2] if len(args)>2 else None);tools=kwargs.get('tools',args[1] if len(args)>1 else None)
            # Exercise the real Temporal model encoder/typed decoder after
            # actual SDK pause/restore, including a discovery tool after feedback.
            # A malformed assistant message must not downgrade tool dataclasses.
            from temporalio.contrib.openai_agents._temporal_model_stub import _TemporalModelStub
            from temporalio.contrib.openai_agents._model_parameters import ModelActivityParameters
            from temporalio.contrib.openai_agents._invoke_model_activity import ActivityModelInput,_build_tools_and_handoffs
            from temporalio.contrib.openai_agents._temporal_worker_env_ref import _WorkerEnvRefResolver,AllowAllWorkerEnvVars
            from pydantic import TypeAdapter
            stub=_TemporalModelStub('synthetic',model_params=ModelActivityParameters(),agent=None)
            activity_input,_=stub._build_activity_input(system_instructions=system_instructions,input=input,
                model_settings=kwargs.get('model_settings',args[0] if args else None),tools=tools,output_schema=schema,
                handoffs=kwargs.get('handoffs',args[3] if len(args)>3 else []),tracing=kwargs.get('tracing',args[4] if len(args)>4 else None),
                previous_response_id=kwargs.get('previous_response_id'),conversation_id=kwargs.get('conversation_id'),prompt=kwargs.get('prompt'))
            encoded=converter.to_payloads([activity_input])
            TypeAdapter(ActivityModelInput).validate_json(encoded[0].data)
            decoded=converter.from_payloads(encoded,[ActivityModelInput])[0]
            restored_tools,_=_build_tools_and_handoffs(decoded,_WorkerEnvRefResolver(AllowAllWorkerEnvVars()))
            assert [tool.params_json_schema for tool in restored_tools]==[tool.params_json_schema for tool in tools]
            assert (schema is not None)==typed_analysis
            if schema is not None:assert schema.name() in {goal_schema,'AgentAnalysisAnswerDraft'}
            if (captured_rows or captured_chart) and schema.name()==goal_schema:
                row_feedback.extend(item for item in input if item.get('role')=='assistant' and 'Issues:' in str(item.get('content')))
            if captured_rows and schema.name()==goal_schema:
                assert 'include a ranking all criterion' in system_instructions
                row_feedback.extend(item for item in input if item.get('role')=='assistant' and 'declared source' in str(item.get('content')))
            if captured_reference:
                if schema.name()==goal_schema:
                    assert 'restricts the eligible population' in system_instructions
                    assert 'Largest TOTAL means aggregate sum' in schema.json_schema()['$defs']['AgentExactMetric']['properties']['aggregate']['description']
                from agentic_os_agent_worker.memory_output import ANALYSIS_ANSWER_FEEDBACK
                reference_feedback.extend(item for item in input if item.get('role')=='assistant' and ANALYSIS_ANSWER_FEEDBACK in str(item.get('content')))
            if captured and 'Accepted query and metric criteria: ' not in system_instructions:
                assert 'each aggregate is computed within one group' in system_instructions
                assert 'Including entity identity computes a separate mean for each entity' in system_instructions
                assert 'Follow only returned nextCursor; null means complete' in system_instructions
                assert 'must retain the winning entity identities and every tie' in system_instructions
            if premature_goal:
                discovery_feedback.extend(item for item in input if item.get('role')=='assistant'
                    and 'accepted discovery tool result before proposing' in str(item.get('content')))
            if premature_goal and not premature:
                proposal=fixture.analysis_goal(dict(analysisProfile='laboratory-query/1',capability=primary['capability'],
                    resource=dict(providerRef='synthetic.read'),queryGrain=grain,queryPageGroups=groups,
                    argumentsJson=json.dumps(dict(projectId='<resolve through discovery>',metric='concentration',targetUnit='mg/L',cursor=None))))
                premature.append(deepcopy(proposal))
                output=[dict(type='message',content=[dict(text=json.dumps(proposal))])]
            else:
                output=fixture.property_composition_step(value,dict(input=input,instructions=system_instructions,text=None,tools=[dict(name=tool.name) for tool in tools]),empty_discovery=empty_discovery,invalid_goal=invalid_goal,outcome=outcome)
            if output[0]['type']=='function_call':return calls(*[(row['name'],row['call_id'],json.loads(row['arguments'])) for row in output])
            raw=output[0]['content'][0]['text']
            long_reasoning=False
            if captured_chart and schema.name()==goal_schema and not altered:
                proposal=json.loads(raw);proposal['queries'][0]['cursorField']='nextCursor'
                metric=proposal['criteria'][0];metric['groupBy']=['property'];metric['partitions']=['currency']
                metric['latest']=dict(groupBy=list(metric['grain']),versionField='version')
                metric['populationFilters'].append(dict(field='utilityId',value=741))
                altered.append(deepcopy(proposal));raw=json.dumps(proposal)
            if captured_rows and schema.name()==goal_schema and len(row_proposals)<(2 if overflow_goal else 1):
                proposal=json.loads(raw)
                if overflow_goal:
                    proposal['criteria'][0]['populationFilters'].append(dict(field='utilityId',value=741))
                    if not row_proposals:proposal['criteria'][0]['queryKey']='incorrect-query-key'
                    long_reasoning=True
                else:proposal['criteria'][0].update(filters=[dict(field='utility_id',value=741)],ranking='maximum')
                row_proposals.append(deepcopy(proposal));raw=json.dumps(proposal)
            if captured_reference and schema.name()=='AgentAnalysisAnswerDraft' and not altered:
                proposal=json.loads(raw);proposal['results'][-1]['scopeRef']+='x'
                altered.append(deepcopy(proposal));raw=json.dumps(proposal)
                long_reasoning=overflow_answer
            if captured and 'Accepted query and metric criteria: ' not in system_instructions and not drafts:
                draft=deepcopy(captured_case['draft']);draft['queries'][0].update(capability=primary['capability'],providerRef='synthetic.read',
                    argumentsJson=json.dumps(dict(projectId='resolved-project-741',metric='concentration',targetUnit='mg/L',cursor=None)))
                raw=json.dumps(draft)
            if schema is not None:schema.validate_json(raw)
            drafts.append(json.loads(raw));response=answer(raw)
            if long_reasoning:
                from openai.types.responses import ResponseReasoningItem
                response.output.insert(0,ResponseReasoningItem(id='rs_private_feedback',summary=[],type='reasoning',
                    encrypted_content='opaque-private-state-'*(2000 if overflow_answer else 1000)))
            return response
    model=Model(None)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    async def consume(driver,boundary,c,operation,**flags):
        assert flags['analysis'] and c==context
        if flags['objective']:
            _validate(goal_schema,drafts[-1]);assert len(drafts[-1]['criteria'])==(2 if laboratory else 1)
            if laboratory:
                assert json.loads(drafts[-1]['queries'][0]['argumentsJson'])['projectId']=='resolved-project-741'
                assert [c['aggregate'] for c in drafts[-1]['criteria']]==['mean','maximum']
                assert all(c['filters']==[dict(field='state',value='accepted')] and c['latest']==dict(groupBy=['readingId'],versionField='version')
                    and c['conversion']['targetUnit']=='mg/L' and c['populationFields']==['sampleId'] for c in drafts[-1]['criteria'])
            else:
                assert json.loads(drafts[-1]['queries'][0]['argumentsJson'])['utility_id']==741
                assert drafts[-1]['criteria'][0]['ranking']==('all' if outcome in {'all-pages','exact-chart'} else 'maximum')
            if chart:
                assert len(drafts[-1]['charts'])==1 and drafts[-1]['charts'][0]['kind']=='bar'
                assert drafts[-1]['charts'][0]['criterionId']==drafts[-1]['criteria'][0]['id']
            goals.append(dict(context=context,sourceDigest='a'*64,operator=sample('AgentAnalysisGoal')['operator'],nextPage=None,
                **{key:item for key,item in drafts[-1].items() if key!='charts'}));state='goal-bound'
        else:
            validate_contract('AgentAnalysisAnswerDraft',drafts[-1])
            assert drafts[-1]['goalDigest']==digest('command',goals[0])
            sources={row['result']['resultId']:row for row in material}
            selected=[sources[ref['resultId']] for ref in drafts[-1]['results']]
            assert all(source['result']==ref for source,ref in zip(selected,drafts[-1]['results']))
            assert [source['query']['pageOrdinal'] for source in selected]==[0,1]
            assert [source['query']['requestCursor'] for source in selected]==[None,'next-page']
            assert [source['query']['page']['nextCursor'] for source in selected]==['next-page',None]
            assert all(source['binding']['context']==context and source['binding']['capability']==primary['capability'] for source in selected)
            assert goals[0]['criteria'][0]['valueField']==('amount' if laboratory else 'allocatedNet') and goals[0]['criteria'][0]['aggregate']==('mean' if laboratory else 'sum')
            completed.append(deepcopy(drafts[-1]));state='completed'
            if chart:
                from agentic_os.production.verified_analysis import VerifiedAnalysis
                from agentic_os.production.chart_projection import compile_charts
                computed=VerifiedAnalysis._produce(None,goals[0],drafts[-1],material,dict(resultId=context['taskId']),lambda:None)
                record=sample('AgentChartAnalysisGoalRecord')
                record.update(goal=goals[0],charts=next(draft['charts'] for draft in reversed(drafts) if 'charts' in draft))
                projected=compile_charts(record,computed['derivedPage'])
                assert len(projected)==1 and projected[0]['kind']=='bar'
                assert {point['value'] for point in projected[0]['points']}==set(frozen['warehouse']['golden']['allocatedPropertyPeriodUSD'].values())
            if captured_reference:
                from agentic_os.production.exact_summary import collect_queries,summarize
                from agentic_os.errors import OSErrorCode
                with pytest.raises(OSErrorCode):collect_queries(goals[0],altered[0],material,check=lambda:None)
                collected=collect_queries(goals[0],drafts[-1],material,check=lambda:None)
                criterion=goals[0]['criteria'][0]
                summary=summarize(criterion,collected['queries'][criterion['queryKey']]['rows'],check=lambda:None)
                assert summary['available']==summary['eligible']==2 and not summary['missing']
                assert [row['value'] for row in summary['rows']]==[frozen['warehouse']['golden']['largestAllocatedPropertyPeriodUSD']['amount']]
            if captured:
                from agentic_os.production.exact_summary import collect_queries,summarize
                from agentic_os.errors import OSErrorCode
                collected=collect_queries(goals[0],drafts[-1],material,check=lambda:None)
                assert collected['kind']=='ready'
                rows=[]
                for criterion in goals[0]['criteria']:
                    source=collected['queries'][criterion['queryKey']]['rows']
                    computed=summarize(criterion,source,check=lambda:None)
                    rows.extend(dict(row,coverage=str(computed['available'])+'/'+str(computed['eligible']),missing='/'.join(computed['missing'][0])) for row in computed['rows'])
                    # Original provider field names still fail in the actual
                    # consumer; advisory repair does not weaken completion.
                    original_metric=deepcopy(captured_case['draft']['criteria'][0])
                    original_metric['populationFilters']=[dict(field='projectId',value='resolved-project-741')]
                    with pytest.raises((KeyError,OSErrorCode)):summarize(original_metric,source,check=lambda:None)
                gold=frozen['laboratory']['golden']
                assert len(rows)==2
                assert {row['value'] for row in rows}=={gold['meanAvailableConcentrationMgL'],gold['observedMaximumMgL']['amount']}
                assert sum(row['value']==gold['meanAvailableConcentrationMgL'] and row.get('sampleId') is None for row in rows)==1
                assert sum(row['value']==gold['observedMaximumMgL']['amount'] and row.get('sampleId')==gold['observedMaximumMgL']['sample'] for row in rows)==1
                assert all(row['coverage']=='2/3' and row['missing']=='s3' and row['unit']=='mg/L' for row in rows)
                per_entity=[]
                source=next(iter(collected['queries'].values()))['rows']
                for metric in captured_case['perEntityDraft']['criteria']:
                    metric=deepcopy(metric);metric['populationFilters']=[]
                    per_entity.extend(summarize(metric,source,check=lambda:None)['rows'])
                assert len(per_entity)==4 and all('sampleId' in row for row in per_entity)
                assert not any(row['value'].startswith(gold['meanAvailableConcentrationMgL']) for row in per_entity)
                for metric in captured_case['unitFilteredDraft']['criteria']:
                    wrong=summarize(metric,source,check=lambda:None)
                    assert wrong['available']==wrong['eligible']==1 and not wrong['missing']
                    assert all(row['value'].startswith('3.000') for row in wrong['rows'])
                value_only=captured_case['valueOnlyMaximumDraft']['criteria'][1]
                output=summarize(value_only,source,check=lambda:None)
                assert len(output['rows'])==1 and 'sampleId' not in output['rows'][0]
        return ReadControl(rootId=c['rootId'],taskId=c['taskId'],operationId=operation,state=state,goalDigest=digest('command',goals[0]),missingCriteria=[])
    monkeypatch.setattr(read_journey,'complete_goal',consume)
    class Driver(AgentTaskDriver):
        def _expired(self):return False
        async def _save(self,boundary,ident,envelope):saved[ident]=wire(envelope);return dict(kind='ready')
    async def run():
        queue.append(wire(value));terminal=None
        for _ in range(8):
            if not queue:break
            try:terminal=await Driver().run(queue.pop(0))
            except Rollover:pass
        assert terminal.state=='completed' and not queue
    asyncio.run(run())
    assert query_count==2 and len(saved)==3+int(empty_discovery) and len(completed)==1
    assert len(completed[0]['results'])==2 and len(goals[0]['criteria'])==(2 if laboratory else 1)
    assert question==value['start']['input']
    if captured_reference:
        assert len(altered)==1 and reference_feedback and len(drafts)==3
        assert altered[0]['results'][-1]!=completed[0]['results'][-1]
    if captured_chart:
        assert len(altered)==1 and row_feedback and len(drafts)==3
        assert goals[0]['queries'][0]['cursorField']=='cursor' and goals[0]['criteria'][0]['latest'] is None
    if captured:
        assert len(drafts)==3 and drafts[0]['criteria'][0]['valueField']=='concentration'
        assert goals[0]['criteria'][0]['valueField']=='amount'
    if premature_goal:
        from agentic_os.production.exact_summary import collect_queries,summarize
        assert len(premature)==1 and discovery_feedback and len(drafts)==3
        assert len(goals)==1 and json.loads(goals[0]['queries'][0]['argumentsJson'])['projectId']=='resolved-project-741'
        unresolved=dict(goals[0],queries=deepcopy(premature[0]['queries']))
        unresolved_draft=dict(completed[0],goalDigest=digest('command',unresolved))
        assert collect_queries(unresolved,unresolved_draft,material,check=lambda:None)['kind']=='incomplete'
        collected=collect_queries(goals[0],completed[0],material,check=lambda:None)
        assert collected['kind']=='ready'
        summaries=[summarize(c,collected['queries'][c['queryKey']]['rows'],check=lambda:None) for c in goals[0]['criteria']]
        gold=frozen['laboratory']['golden']
        assert {r['value'] for summary in summaries for r in summary['rows']}=={gold['meanAvailableConcentrationMgL'],gold['observedMaximumMgL']['amount']}
        assert any(r.get('sampleId')==gold['observedMaximumMgL']['sample'] for r in summaries[1]['rows'])
        assert all(summary['available']==2 and summary['eligible']==3 and summary['missing']==[['s3']] for summary in summaries)
    if captured_rows:
        from agentic_os.production.verified_analysis import VerifiedAnalysis
        from agentic_os.errors import OSErrorCode
        assert len(row_proposals)==(2 if overflow_goal else 1) and row_feedback and len(drafts)==(4 if overflow_goal else 3) and goals[0]['criteria'][0]['ranking']=='all'
        original=dict(goals[0],criteria=row_proposals[0]['criteria'])
        candidate=dict(resultId=context['taskId'])
        with pytest.raises(OSErrorCode):VerifiedAnalysis._produce(None,original,dict(completed[0],goalDigest=digest('command',original)),material,candidate,lambda:None)
        result=VerifiedAnalysis._produce(None,goals[0],completed[0],material,candidate,lambda:None)
        rows=[{c['name']:c['value'] for c in row} for row in result['derivedPage']['records']]
        assert result['status']=='verified' and {row['value'] for row in rows}==set(frozen['warehouse']['golden']['allocatedPropertyPeriodUSD'].values())
    if overflow_goal or overflow_answer:
        assert window_sizes and all(before>32768 and after is not None and after<=32768 for before,after in window_sizes)


@pytest.mark.parametrize('fault',[None,'extra-user','unknown-item','large-source','missing-proposal'])
@pytest.mark.parametrize('retain_proposal',[True,False])
def test_analysis_feedback_window_preserves_intent_sources_and_small_legacy_input(fault,retain_proposal):
    from agentic_os_agent_worker.memory_output import analysis_feedback_continuation
    question='Original complete request';items=[dict(role='user',content=question),
        dict(type='function_call',name='current_source',call_id='source',arguments='{}'),
        dict(type='function_call_output',call_id='source',output='accepted source'),
        dict(type='reasoning',encrypted_content='private-state'*4000),
        dict(role='assistant',type='message',content=[dict(type='output_text',text='latest proposal')]),
        dict(role='assistant',content='correct its declared types')]
    if fault=='extra-user':items.insert(2,dict(role='user',content='Additional intent must never disappear'))
    elif fault=='unknown-item':items.insert(2,dict(type='unrecognized-private-item',value='keep-or-refuse'))
    elif fault=='large-source':items[2]['output']='required source'*4000
    elif fault=='missing-proposal':items.pop(-2)
    before=deepcopy(items);result=analysis_feedback_continuation(items,question,retain_proposal=retain_proposal)
    assert items==before
    if fault is not None:assert result is None
    else:
        window=json.loads(result)
        assert window==[items[0],items[1],items[2],*([items[-2]] if retain_proposal else []),items[-1]]
        small=[items[0],items[-2],items[-1]]
        assert analysis_feedback_continuation(small,question)==json.dumps(small,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


@pytest.mark.parametrize('fault',[None,'scope-copy','goal-digest','unknown-selection',
    'foreign-root','foreign-owner','foreign-scope','conflicting-source'])
def test_analysis_answer_feedback_preserves_proposals_and_rejects_foreign_transcripts(fault):
    from uuid import uuid4
    from agents.exceptions import ModelBehaviorError
    from agentic_os_agent_worker.memory_output import analysis_answer_feedback
    context=sample('AgentTaskContext');source=sample('AgentAcceptedQueryContext')
    source['result'].update({key:deepcopy(context[key]) for key in ('subject','rootId','taskId','scopeRef')})
    draft=sample('AgentAnalysisAnswerDraft');draft['results']=[deepcopy(source['result'])]
    goal_digest=draft['goalDigest']
    if fault=='scope-copy':draft['results'][0]['scopeRef']='scope/altered'
    elif fault=='goal-digest':draft['goalDigest']='f'*64 if goal_digest!='f'*64 else 'a'*64
    elif fault=='unknown-selection':draft['results'][0]['resultId']=str(uuid4())
    elif fault=='foreign-root':source['result']['rootId']=str(uuid4())
    elif fault=='foreign-owner':source['result']['subject']['subjectId']='foreign-owner'
    elif fault=='foreign-scope':source['result']['scopeRef']='scope/foreign'
    inputs=[dict(type='function_call_output',call_id='accepted',output=json.dumps(source))]
    if fault=='conflicting-source':
        changed=deepcopy(source);changed['result']['payload']['ciphertextDigest']='f'*64
        inputs.append(dict(type='function_call_output',call_id='conflict',output=json.dumps(changed)))
    before=deepcopy((draft,inputs,context))
    if fault in {'foreign-root','foreign-owner','foreign-scope','conflicting-source'}:
        with pytest.raises(ModelBehaviorError):analysis_answer_feedback(json.dumps(draft),goal_digest,inputs,context)
    else:
        issues=analysis_answer_feedback(json.dumps(draft),goal_digest,inputs,context)
        assert bool(issues)==(fault is not None)
        assert len(json.dumps(issues).encode())<=8192
        if fault=='scope-copy':
            exact=next(item.removeprefix('Exact accepted result: ') for item in issues if item.startswith('Exact accepted result: '))
            assert json.loads(exact)==source['result']
            assert draft['results'][0]!=source['result']
    assert (draft,inputs,context)==before


@pytest.mark.parametrize('fault',['none','matching','different-tool','unpaired','foreign-root','foreign-owner','foreign-scope','tool-error','plain'])
def test_declared_discovery_requires_actual_paired_current_context_before_goal(fault):
    from uuid import uuid4
    from agents.exceptions import ModelBehaviorError
    from agentic_os_agent_worker.checkpoint import tool_alias
    from agentic_os_agent_worker.memory_output import analysis_discovery_feedback
    context=sample('AgentTaskContext');source=sample('AgentAcceptedQueryContext')
    source['result'].update({key:deepcopy(context[key]) for key in ('subject','rootId','taskId','scopeRef')})
    pin=sample('AgentAnalysisGoalDraft')['queries'][0]['capability']
    if fault=='foreign-root':source['result']['rootId']=str(uuid4())
    elif fault=='foreign-owner':source['result']['subject']['subjectId']='foreign-owner'
    elif fault=='foreign-scope':source['result']['scopeRef']='scope/foreign'
    elif fault=='tool-error':source=dict(kind='tool-error',failure='tool-failed')
    inputs=[dict(type='function_call',call_id='discovery',name=tool_alias(pin),arguments='{"cursor":null}'),
        dict(type='function_call_output',call_id='discovery',output=json.dumps(source))]
    if fault=='none':inputs=[]
    elif fault=='different-tool':inputs[0]['name']='unrelated_tool'
    elif fault=='unpaired':inputs[0]['call_id']='another-call'
    before=deepcopy((inputs,context,pin))
    if fault in {'foreign-root','foreign-owner','foreign-scope'}:
        with pytest.raises(ModelBehaviorError):analysis_discovery_feedback(inputs,[tool_alias(pin)],context)
    else:
        assert bool(analysis_discovery_feedback(inputs,[] if fault=='plain' else [tool_alias(pin)],context))==(fault not in {'matching','plain'})
    assert (inputs,context,pin)==before


def test_actual_assigned_analysis_completion_callback_records_control(tmp_path,monkeypatch):
    """Reproduce the wrapper's post-commit failure without SQL or Temporal."""
    import hashlib
    from dataclasses import asdict
    import agentic_os_agent_worker
    from agentic_os_agent_worker.model_rpc import RPCModelBoundary
    root=Path(__file__).parents[3]
    spec=importlib.util.spec_from_file_location('actual_property_probe',root/'tests/integration/resources/assigned_read_probe.py')
    probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
    transport,_,_=binding_fixture();start=sample('AgentSDKAdaptiveAnalysisJourneyStart')
    installed=Path(agentic_os_agent_worker.__file__).parent
    config=dict(mode='property-analysis',propertyAnalysis=True,origin='http://127.0.0.1:8999',target='127.0.0.1:7233',
        token='synthetic-only',transport=asdict(transport),workerSource={'__init__.py':hashlib.sha256((installed/'__init__.py').read_bytes()).hexdigest()},
        historyKeyId='synthetic-history',historyKeyHex='ab'*32,analysisControls=str(tmp_path/'analysis-controls.jsonl'))
    control=sample('AgentReadControl');control.update(state='completed')
    import subprocess,sys
    document=tmp_path/'callback.json'
    document.write_text(json.dumps(dict(config=config,start=start,control=control)));document.chmod(0o600)
    script="""import asyncio,importlib.util,json,sys
from pathlib import Path
from agentic_os_agent_worker.model_rpc import RPCModelBoundary
from agentic_os_agent_worker.workflow_control import ReadControl
spec=importlib.util.spec_from_file_location('actual_probe',sys.argv[1]);probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
value=json.loads(Path(sys.argv[2]).read_bytes())
async def complete(self,*args):return value['control']
async def serve(**options):
 result=await options['boundary'].complete_analysis(value['start']['start']['context'],value['control']['operationId'])
 assert result==value['control']
 return ReadControl(**result)
RPCModelBoundary.complete_analysis=complete;probe.serve_read_task=serve
asyncio.run(probe.run(value['config'],value['start']))
"""
    result=subprocess.run([sys.executable,'-I','-B','-c',script,str(root/'tests/integration/resources/assigned_read_probe.py'),str(document)],capture_output=True,timeout=20)
    assert result.returncode==0,result.stderr.decode()
    records=[json.loads(row) for row in Path(config['analysisControls']).read_text().splitlines()]
    assert len(records)==1 and records[0]['state']=='completed' and records[0]['missingCriteria']==[]


@pytest.mark.parametrize('case',['valid','local-ref','null','boolean','float','zero','string','query-key','initial-cursor','remote-ref',
    'row-field','row-value','row-value-valid','row-number','row-unknown','legacy-row-value','cursor-field','legacy-cursor-field'])
def test_analysis_draft_feedback_checks_nested_arguments_without_remote_schema_io(case):
    from agents.exceptions import ModelBehaviorError
    from agentic_os_agent_worker.memory_output import analysis_goal_feedback
    draft=sample('AgentAnalysisGoalDraft');draft['queries']=draft['queries'][:1];draft['criteria']=draft['criteria'][:1]
    query=draft['queries'][0];draft['criteria'][0].update(queryKey=query['key'],partitions=[])
    query.update(argumentsJson='{"selector":741,"cursor":null}',cursorField='cursor')
    schema=dict(type='object',properties=dict(selector=dict(type='integer',minimum=1),
        cursor=dict(anyOf=[dict(type='string'),dict(type='null')])),required=['selector','cursor'],additionalProperties=False)
    arguments=dict(selector=741,cursor=None)
    if case in {'null','boolean','float','zero','string'}:
        arguments['selector']={'null':None,'boolean':True,'float':741.5,'zero':0,'string':'synthetic-private-value'}[case]
    if case=='initial-cursor':arguments['cursor']='not-initial'
    if case=='query-key':draft['criteria'][0]['queryKey']='other-query'
    query['argumentsJson']=json.dumps(arguments)
    if case=='local-ref':schema={'$ref':'#/$defs/input','$defs':dict(input=schema)}
    if case=='remote-ref':schema={'$ref':'https://example.invalid/no-network'}
    if case in {'cursor-field','legacy-cursor-field'}:query['cursorField']='nextCursor'
    item=item_fixture();item.update(capability=query['capability'],kind='read',available=True,inputSchemaJson=json.dumps(schema),
        outputSchemaJson=json.dumps(dict(type='object',properties=dict(grain=dict(const=query['grain']),pageGroupFields=dict(const=query['pageGroupFields'])))))
    row_case=case in {'row-field','row-value','row-value-valid','row-number','row-unknown','legacy-row-value'}
    if row_case:
        criterion=draft['criteria'][0]
        fields=set(criterion['grain']+criterion['groupBy']+criterion['partitions']+criterion['populationFields']+[criterion['valueField'],'utilityId'])
        if criterion['unitField'] is not None:fields.add(criterion['unitField'])
        criterion.update(filters=[dict(field='utility_id' if case=='row-field' else 'utilityId',
            value='741' if case in {'row-field','row-value-valid'} else 741)],populationFilters=[],latest=None,conversion=None)
        shape=json.loads(item['outputSchemaJson'])
        shape['properties']['page']=dict(properties=dict(evidence=dict(properties=dict(publicFields=dict(const=sorted(fields)))),
            records=dict(items=dict(items=dict(properties=dict(value=dict(anyOf=[dict(type='string'),dict(type='null')])))))))
        item['outputSchemaJson']=json.dumps(shape)
        if case in {'row-number','row-unknown'}:
            cell=shape['properties']['page']['properties']['records']['items']['items']['properties']
            cell['value']={} if case=='row-unknown' else dict(anyOf=[dict(type='number'),dict(type='null')])
            item['outputSchemaJson']=json.dumps(shape)
        from agentic_os_agent_worker.memory_output import AnalysisOutput
        output=AnalysisOutput(objective=True,source_fields=None if case=='legacy-row-value' else [item])
        if case in {'row-field','row-value'}:
            with pytest.raises(ModelBehaviorError):output.validate_json(json.dumps(draft))
        else:assert output.validate_json(json.dumps(draft))==json.dumps(draft)
    providers=[dict(capability=query['capability'],providerRef=query['providerRef'])]
    if case=='remote-ref':
        with pytest.raises(ModelBehaviorError):analysis_goal_feedback(json.dumps(draft),[item],providers)
    else:
        issues=analysis_goal_feedback(json.dumps(draft),[item],providers,declared_fields=row_case,declared_values=row_case and case!='legacy-row-value',request_cursor=case=='cursor-field')
        assert bool(issues)==(case not in {'valid','local-ref','row-value-valid','row-number','row-unknown','legacy-row-value','legacy-cursor-field'})
        assert 'synthetic-private-value' not in json.dumps(issues)


def test_analysis_goal_feedback_loads_and_validates_inside_actual_temporal_sandbox():
    from temporalio.worker.workflow_sandbox import SandboxRestrictions
    from temporalio.worker.workflow_sandbox._importer import Importer
    from temporalio.worker.workflow_sandbox._restrictions import RestrictionContext
    context=RestrictionContext();context.is_runtime=True
    restrictions=SandboxRestrictions.default.with_passthrough_modules(
        'agents','agentic_os_agent_worker.transport','agentic_os_agent_worker.model_rpc')
    draft=sample('AgentAnalysisGoalDraft');query=draft['queries'][0]
    item=item_fixture();item.update(capability=query['capability'],kind='read',available=True,
        inputSchemaJson=json.dumps(dict(type='object',properties=dict(selector=dict(type='integer')),required=['selector'],additionalProperties=False)),
        outputSchemaJson=json.dumps(dict(type='object',properties={})))
    draft['queries']=[query];draft['criteria']=draft['criteria'][:1]
    draft['criteria'][0].update(queryKey=query['key'],partitions=[])
    query.update(argumentsJson='{"selector":741}',cursorField='cursor')
    providers=[dict(capability=query['capability'],providerRef=query['providerRef'])]
    task_context=sample('AgentTaskContext');accepted=sample('AgentAcceptedQueryContext')
    accepted['result'].update({key:deepcopy(task_context[key]) for key in ('subject','rootId','taskId','scopeRef')})
    answer_draft=sample('AgentAnalysisAnswerDraft');answer_draft['results']=[deepcopy(accepted['result'])]
    inputs=[dict(type='function_call_output',call_id='accepted',output=json.dumps(accepted))]
    # The installed failure occurred on the lazy workflow import, before any
    # model/Activity. Use the real SDK restriction importer rather than a helper
    # mock; schema dependencies alone may pass through, not workflow restrictions.
    with Importer(restrictions,context).applied():
        from agentic_os_agent_worker.memory_output import AnalysisOutput,analysis_goal_feedback,analysis_answer_feedback,analysis_discovery_feedback,analysis_feedback_continuation
        assert AnalysisOutput(objective=True).name()=='AgentAnalysisGoalDraft'
        assert analysis_goal_feedback(json.dumps(draft),[item],providers)==[]
        impossible=deepcopy(draft);criterion=impossible['criteria'][0]
        criterion['populationFilters'].append(dict(field=criterion['populationFields'][0],value=None))
        assert analysis_goal_feedback(json.dumps(impossible),[item],providers)==[]
        assert any('filters a required non-null' in issue for issue in
            analysis_goal_feedback(json.dumps(impossible),[item],providers,key_filters=True))
        missing=deepcopy(draft);criterion=missing['criteria'][0]
        criterion.update(grain=['entity'],groupBy=['parent'],populationFields=['entity'],partitions=[],
            populationFilters=[],filters=[dict(field='missingMeasurement',value=None)],valueField='value',
            unitField=None,latest=None,conversion=None,aggregate='sum',ranking='all',outputScale=2)
        assert analysis_goal_feedback(json.dumps(missing),[item],providers,key_filters=True)==[]
        typed=deepcopy(draft);metric=typed['criteria'][0]
        metric.update(filters=[dict(field='selector',value='741')],populationFilters=[],latest=None,conversion=None)
        fields=set(metric['grain']+metric['groupBy']+metric['populationFields']+[metric['valueField'],'selector'])
        if metric['unitField'] is not None:fields.add(metric['unitField'])
        declared=deepcopy(item);declared['outputSchemaJson']=json.dumps(dict(properties=dict(page=dict(properties=dict(
            evidence=dict(properties=dict(publicFields=dict(const=sorted(fields)))),
            records=dict(items=dict(items=dict(properties=dict(value=dict(anyOf=[dict(type='string'),dict(type='null')]))))))))))
        assert analysis_goal_feedback(json.dumps(typed),[declared],providers,declared_fields=True,declared_values=True)==[]
        metric['filters'][0]['value']=741
        assert analysis_goal_feedback(json.dumps(typed),[declared],providers,declared_fields=True,declared_values=True)
        query['argumentsJson']='{"selector":null}'
        assert analysis_goal_feedback(json.dumps(draft),[item],providers)
        assert analysis_answer_feedback(json.dumps(answer_draft),answer_draft['goalDigest'],inputs,task_context)==[]
        answer_draft['results'][0]['scopeRef']='scope/altered'
        assert analysis_answer_feedback(json.dumps(answer_draft),answer_draft['goalDigest'],inputs,task_context)
        assert analysis_discovery_feedback([], ['cap_discovery'],task_context)
        assert analysis_discovery_feedback([], [],task_context)==[]
        large=[dict(role='user',content='Original request'),dict(type='reasoning',encrypted_content='opaque'*8000),
            dict(type='message',role='assistant',content=[dict(type='output_text',text='proposal')]),dict(role='assistant',content='feedback')]
        assert len(analysis_feedback_continuation(large,'Original request'))<32768
        import platform
        from temporalio.worker.workflow_sandbox import RestrictedWorkflowAccessError
        with pytest.raises(RestrictedWorkflowAccessError):platform.python_implementation()
    # Exact computation belongs to Core, outside the workflow sandbox.
    from agentic_os.production.exact_summary import summarize
    checked=summarize(criterion,[dict(entity='one',parent='group',missingMeasurement=None,value='1.25')],check=lambda:None)
    assert checked['rows'][0]['value']=='1.25'


def test_actual_ambiguous_grain_entry_serializes_registered_question_before_goal_or_business_read(monkeypatch):
    from uuid import uuid4
    value=sample('AgentSDKClarifiedAnalysisJourneyStart');_,_,binding=binding_fixture();context=deepcopy(binding['context'])
    root=Path(__file__).parents[3];spec=importlib.util.spec_from_file_location('grain_sdk_fixture',root/'tests/integration/resources/analysis_fixture.py')
    fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
    item=item_fixture();primary=deepcopy(item);primary['capability']['ref']='separate.allocations'
    policy=fixture.grain_clarification_policy(primary['capability']);validate_contract('AgentAnalysisClarificationPolicy',policy)
    question=next(row['question'] for row in json.loads((root/'qualification/production-agent/fixtures/english-task-bank-v1.json').read_bytes())['cases'] if row['id']=='ambiguous-grain')
    context['harness']['ref']='clarified-paged-analysis/'+digest('manifest',dict(policy=policy,discovery=[item['capability']]))
    value['start'].update(context=context,input=question,capabilities=[item,primary],checkpointId=None)
    value.update(clarification=policy,phase='objective',questionOperationId=None,binding=None,goalDigest=None,goalDraftJson=None,
        continuationInputJson=None,discoveryCapabilities=[item['capability']],providers=[dict(capability=row['capability'],providerRef='synthetic.read') for row in (item,primary)])
    _validate('AgentSDKClarifiedAnalysisJourneyStart',value)
    expected='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,is_continue_as_new_suggested=lambda:True,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda _:False)
    converter=AgentPayloadConverter();carried=[];kernel=Boundary();issued=[];questions=[]
    def wire(value):
        payload=converter.to_payloads([value])[0];assert len(payload.SerializeToString(deterministic=True))<=65536
        return converter.from_payloads([payload])[0]
    def rollover(value,**kwargs):carried.append(wire(value));raise Rollover()
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    async def accepted(self,c,operation):return await kernel.accepted_model_operation(c,operation)
    async def owner(self,c,operation,bind=False):
        assert c==context and bind and len(issued)==1
        original=issued[0]['input']
        assert original==question or original[0]==dict(role='user',content=question)
        questions.append(operation);return dict(kind='waiting',questionId=str(uuid4()))
    async def forbidden(*args,**kwargs):raise AssertionError('No business tool or goal before clarification')
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    monkeypatch.setattr(WorkflowBoundary,'owner_input',owner);monkeypatch.setattr(WorkflowBoundary,'execute_tool',forbidden)
    monkeypatch.setattr(read_journey,'complete_goal',forbidden)
    class QuestionModel(ScriptedModel):
        def __init__(self):super().__init__(lambda items:answer('unused'))
        async def get_response(self,system_instructions,input,*args,**kwargs):
            issued.append(dict(input=deepcopy(input),instructions=system_instructions))
            document=fixture.property_composition_step(value,dict(input=input,instructions=system_instructions),outcome='ambiguous-grain')
            raw=document[0]['content'][0]['text'];_validate('AgentAnalysisQuestionDraft',json.loads(raw))
            return answer(raw)
    model=QuestionModel()
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    class Driver(AgentTaskDriver):
        def _expired(self):return False
    async def run():
        with pytest.raises(Rollover):await Driver().run(wire(value))
    asyncio.run(run())
    assert len(carried)==len(questions)==1 and not kernel.requests
    next_value=carried[0];assert next_value['phase']=='owner-input' and next_value['goalDigest'] is None
    assert next_value['start']['checkpointId'] is None and next_value['start']['context']==context
    assert json.loads(next_value['continuationInputJson'])[0]['content']==question
    assert {choice['id'] for choice in next_value['clarification']['choices']}=={'period-total','property-bill','bill-face'}
