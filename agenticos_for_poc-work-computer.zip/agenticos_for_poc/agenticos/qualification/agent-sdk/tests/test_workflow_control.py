"""Typed metadata stays usable while private history remains governed."""
import asyncio
from dataclasses import asdict,replace
import json
from uuid import uuid4
import pytest
from temporalio.api.common.v1 import Payload
from temporalio.api.failure.v1 import Failure
from temporalio.converter import WorkflowSerializationContext
from temporalio.exceptions import ApplicationError
from agentic_os_agent_worker.private_history import ENCODING,PrivateHistoryUnavailable
from agentic_os_agent_worker.temporal_runtime import agent_converter,agent_plugin
from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,AgentFailureConverter,WorkflowControl,CONTROL_ENCODING,WAIT_TYPE
from test_private_history import fixture


def selected():
    _,store,keys,context,workflow_id=fixture()
    converter=agent_converter(store,keys,context,'default',keys.active())
    return converter.with_context(WorkflowSerializationContext('default',workflow_id)),store,keys,context,workflow_id


@pytest.mark.parametrize('fault',['checkpoint','context','schema','extra','denied','legacy'])
def test_checkpoint_reload_versioned_consumer_keeps_binding_and_legacy_guards(monkeypatch,fault):
    from copy import deepcopy
    from temporalio import activity
    from agentic_os_agent_worker import temporal_driver
    from agentic_os_agent_worker.model_rpc import ModelRPCError
    from test_private_history import CreateStore,Keys
    from test_checkpoint import paused
    async def run():
        item=await paused()
        try:
            context=item['binding']['context'];checkpoint=str(uuid4());reads=[]
            keys=Keys();store=CreateStore(context)
            workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
            converter=agent_converter(store,keys,context,'default',keys.active()).with_context(
                WorkflowSerializationContext('default',workflow_id))
            class Boundary:
                async def get_checkpoint(self,c,ident):
                    assert c==context and ident==checkpoint;reads.append(ident)
                    if fault=='denied':raise ModelRPCError('DENIED')
                    return deepcopy(item['saved'])
            activities=temporal_driver.AgentActivities(Boundary())
            registered={activity._Definition.must_from_callable(method).name:method for method in activities.registered()}
            # Both old histories and the new version use the real registered
            # producer and consumer. Mutations model invalid returned frames.
            async def execute(name,value,**options):
                assert name==('agent.checkpoint-get/1' if fault=='legacy' else 'agent.checkpoint-get/2')
                command=(await converter.decode(await converter.encode([value])))[0]
                result=await registered[name](command)
                if fault=='checkpoint':result['checkpointId']=str(uuid4())
                elif fault=='context':result['value']['binding']['context']['rootId']=str(uuid4())
                elif fault=='schema':result['value']['format']='unregistered-checkpoint-format'
                elif fault=='extra':result['unregistered']='not metadata'
                return (await converter.decode(await converter.encode([result])))[0]
            monkeypatch.setattr(temporal_driver.workflow,'execute_activity',execute)
            monkeypatch.setattr(temporal_driver.workflow,'patched',lambda name:
                fault!='legacy' or name!='private-checkpoint-result-history-reuse/1')
            call=temporal_driver.WorkflowBoundary(30000).get_checkpoint(context,checkpoint)
            if fault=='legacy':assert await call==item['saved']
            elif fault=='denied':
                with pytest.raises(ApplicationError) as caught:await call
                assert caught.value.type==WAIT_TYPE and caught.value.details[0].status=='scope-changed'
            else:
                with pytest.raises(ValueError):await call
            assert reads==[checkpoint] and len(item['issued'])==1 and not item['executed']
        finally:
            await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())


@pytest.mark.parametrize('method',['child_source_join_state','child_paged_source_join_state'])
def test_source_join_state_crosses_registered_temporal_activity_with_original_binding(monkeypatch,method):
    from temporalio import activity
    from agentic_os_agent_worker import temporal_driver
    _,_,_,context,_=fixture();operation=str(uuid4());seen=[]
    result=dict(goalDigest='a'*64,phase='source')
    class Boundary:
        async def child_source_join_state(self,received_context,received_operation):
            seen.append((received_context,received_operation));return result
        child_paged_source_join_state=child_source_join_state
    activities=temporal_driver.AgentActivities(Boundary())
    registered={activity._Definition.must_from_callable(method).name:method for method in activities.registered()}
    async def execute(name,value,**options):
        assert options['retry_policy'].maximum_attempts==1
        assert options['start_to_close_timeout'].total_seconds()==30
        return await registered[name](value)
    monkeypatch.setattr(temporal_driver.workflow,'execute_activity',execute)
    async def run():
        assert await getattr(temporal_driver.WorkflowBoundary(30000),method)(context,operation) is result
    asyncio.run(run())
    assert seen==[(context,operation)]


def test_only_typed_control_bypasses_private_storage_and_survives_key_unavailability():
    converter,store,keys,context,_=selected()
    control=WorkflowControl(context['rootId'],context['taskId'],None,'stopped')
    async def run():
        private=await converter.encode([asdict(control)])
        assert private[0].metadata['encoding']==ENCODING and len(store.writes)==1
        keys.key=None
        encoded=await converter.encode([control])
        assert encoded[0].metadata['encoding']==CONTROL_ENCODING
        assert await converter.decode(encoded)==[control] and len(store.writes)==1
        with pytest.raises(ApplicationError) as caught:await converter.encode([dict(private='FORBIDDEN_PRIVATE_VALUE')])
        assert caught.value.type==WAIT_TYPE and caught.value.details[0].status=='waiting-reconciliation'
    asyncio.run(run())


def test_planned_control_content_uses_actual_private_history_encoding():
    from agentic_os_agent_worker.workflow_control import PlannedReadControl,read_control
    converter,store,keys,context,_=selected()
    control=PlannedReadControl(context['rootId'],context['taskId'],str(uuid4()),'plan-amended','a'*64,[],2,
        '{"queryKey":"PRIVATE_PLAN_QUERY_MARKER"}')
    async def run():
        value=read_control(asdict(control))
        assert type(value) is dict
        encoded=await converter.encode([value])
        assert encoded[0].metadata['encoding']==ENCODING
        assert b'PRIVATE_PLAN_QUERY_MARKER' not in encoded[0].SerializeToString()
        assert await converter.decode(encoded)==[asdict(control)]
        assert 'PRIVATE_PLAN_QUERY_MARKER' not in json.dumps(store.values)
        keys.key=None
        with pytest.raises(ApplicationError):await converter.encode([dict(value,planRevision=3)])
    asyncio.run(run())


def test_planned_completion_uses_the_original_closed_control_without_private_storage():
    from agentic_os_agent_worker.workflow_control import read_control,ReadControl,READ_CONTROL_ENCODING
    from agentic_os_agent_worker.transport import _validate
    converter,store,keys,context,_=selected()
    terminal=dict(profile='agent-read-control/1',rootId=context['rootId'],taskId=context['taskId'],
        operationId=str(uuid4()),state='completed',goalDigest='a'*64,missingCriteria=[])
    _validate('AgentPlannedReadResponse',terminal)
    async def run():
        keys.key=None
        control=read_control(terminal);assert isinstance(control,ReadControl)
        encoded=await converter.encode([control])
        assert encoded[0].metadata['encoding']==READ_CONTROL_ENCODING
        assert await converter.decode(encoded)==[control] and store.writes==[]
    asyncio.run(run())


def test_memory_no_match_control_preserves_unsatisfied_outcome_without_private_payload_or_new_root():
    from agentic_os_agent_worker.workflow_control import MemoryReadControl,ReadControl,read_control,READ_CONTROL_ENCODING
    converter,store,keys,context,_=selected()
    context['harness']['ref']='memory-assisted-read/synthetic-current-source';store.context=context
    workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    converter=agent_converter(store,keys,context,'default',keys.active()).with_context(WorkflowSerializationContext('default',workflow_id))
    control=MemoryReadControl(context['rootId'],context['taskId'],str(uuid4()),'not-satisfied','a'*64,[str(uuid4())])
    async def run():
        assert read_control(asdict(control))==control
        # The dictionary remains private; only this closed typed metadata can
        # survive unavailable content storage after canonical publication.
        private=await converter.encode([asdict(control)])
        assert private[0].metadata['encoding']==ENCODING
        keys.key=None
        encoded=await converter.encode([control])
        assert encoded[0].metadata['encoding']==READ_CONTROL_ENCODING
        assert await converter.decode(encoded)==[control]
        assert isinstance(control,ReadControl) and len(store.writes)==1
    asyncio.run(run())


def test_memory_control_cannot_reinterpret_a_legacy_history_profile():
    from agentic_os_agent_worker.workflow_control import MemoryReadControl
    converter,store,keys,context,_=selected()
    control=MemoryReadControl(context['rootId'],context['taskId'],str(uuid4()),'not-satisfied','a'*64,[str(uuid4())])
    async def run():
        with pytest.raises(ApplicationError) as denied:await converter.encode([control])
        assert denied.value.type==WAIT_TYPE and store.writes==[]
    asyncio.run(run())


@pytest.mark.parametrize('kind',['completed','rejected','not-applied'])
def test_review_activity_terminal_result_needs_no_new_private_history_after_root_closure(kind):
    from agentic_os_agent_worker.temporal_driver import AgentActivities
    from agentic_os_agent_worker.workflow_control import ReadControl,READ_CONTROL_ENCODING
    from agentic_os_agent_worker.transport import _validate
    converter,store,keys,context,_=selected();operation=str(uuid4());review=str(uuid4());goal='a'*64
    class Boundary:
        async def review(self,c,op,review_id,preparation):
            assert c==context and op==operation and review_id==review and preparation is None
            value=dict(context=c,kind=kind,reviewId=review_id,receipt=None)
            _validate('AgentReviewWorkerState',value);return value
    async def run():
        control=await AgentActivities(Boundary()).review(dict(context=context,operationId=operation,reviewId=review,
            preparation=None,goalDigest=goal))
        assert isinstance(control,ReadControl if kind=='completed' else WorkflowControl)
        keys.key=None
        encoded=await converter.encode([control])
        assert encoded[0].metadata['encoding']==(READ_CONTROL_ENCODING if kind=='completed' else CONTROL_ENCODING)
        assert await converter.decode(encoded)==[control] and store.writes==[]
        assert b'subject' not in encoded[0].data and b'receipt' not in encoded[0].data
    asyncio.run(run())


@pytest.mark.parametrize('fault',['root','task','workflow','namespace','extra-metadata','private-text'])
def test_control_cannot_cross_root_workflow_or_smuggle_unclassified_text(fault):
    converter,store,keys,context,workflow_id=selected()
    control=WorkflowControl(context['rootId'],context['taskId'],None,'resume')
    async def run():
        encoded=await converter.encode([control])
        if fault=='root':encoded=AgentPayloadConverter().to_payloads([replace(control,rootId=str(uuid4()))])
        elif fault=='task':encoded=AgentPayloadConverter().to_payloads([replace(control,taskId=str(uuid4()))])
        elif fault in {'workflow','namespace'}:
            converter_context=WorkflowSerializationContext('other' if fault=='namespace' else 'default',workflow_id+'x' if fault=='workflow' else workflow_id)
            candidate=agent_converter(store,keys,context,'default',keys.active()).with_context(converter_context)
            with pytest.raises(PrivateHistoryUnavailable):await candidate.decode(encoded)
            return
        elif fault=='extra-metadata':encoded[0].metadata['private']=b'UNCLASSIFIED_VALUE'
        else:
            value=json.loads(encoded[0].data);value['message']='UNCLASSIFIED_VALUE';encoded[0].data=json.dumps(value).encode()
        with pytest.raises(PrivateHistoryUnavailable):await converter.decode(encoded)
    asyncio.run(run());assert store.writes==[]


def test_failure_converter_preserves_typed_wait_and_removes_private_messages_causes_and_stacks():
    _,_,_,context,_=selected();payloads=AgentPayloadConverter();failures=AgentFailureConverter()
    control=WorkflowControl(context['rootId'],context['taskId'],str(uuid4()),'waiting-provider',context['admittedAt'])
    wait=ApplicationError('PRIVATE_ERROR_VALUE',control,type=WAIT_TYPE)
    wait.__cause__=ValueError('PRIVATE_CAUSE_VALUE')
    failure=Failure();failures.to_failure(wait,payloads,failure)
    assert b'PRIVATE_' not in failure.SerializeToString() and not failure.HasField('cause') and failure.stack_trace==''
    restored=failures.from_failure(failure,payloads)
    assert restored.type==WAIT_TYPE and restored.details==(control,) and restored.non_retryable
    failures.to_failure(ValueError('PRIVATE_UNKNOWN_ERROR'),payloads,failure)
    assert b'PRIVATE_' not in failure.SerializeToString()
    assert failures.from_failure(failure,payloads).type=='OS_AGENT_SAFE_FAILURE/1'


def test_agents_plugin_preserves_custom_control_converter_failure_converter_and_private_codec():
    from temporalio.contrib.openai_agents import OpenAIAgentsPlugin
    converter,_,_,_,_=selected()
    actual=OpenAIAgentsPlugin(add_temporal_spans=False,use_otel_instrumentation=False).configure_client({'data_converter':converter})['data_converter']
    assert actual.payload_converter_class is AgentPayloadConverter
    assert actual.failure_converter_class is AgentFailureConverter
    assert actual.payload_codec is converter.payload_codec


def test_temporal_activity_failure_wrapper_preserves_only_the_closed_wait_cause():
    _,_,_,context,_=selected();payloads=AgentPayloadConverter();failures=AgentFailureConverter()
    control=WorkflowControl(context['rootId'],context['taskId'],str(uuid4()),'waiting-reconciliation')
    cause=Failure();failures.to_failure(ApplicationError('PRIVATE_ACTIVITY_MESSAGE',control,type=WAIT_TYPE),payloads,cause)
    wrapper=Failure(message='PRIVATE_WRAPPER',stack_trace='PRIVATE_STACK',cause=cause)
    wrapper.activity_failure_info.identity='PRIVATE_WORKER_IDENTITY'
    result=failures.from_failure(wrapper,payloads)
    assert result.type==WAIT_TYPE and result.details==(control,)
    assert 'PRIVATE' not in str(result) and result.__cause__ is None


def test_workflow_signals_require_original_root_task_and_current_operation():
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver
    _,_,_,context,_=selected();driver=AgentTaskDriver();driver.context=context
    control=WorkflowControl(context['rootId'],context['taskId'],str(uuid4()),'candidate-ready');driver.control=control
    for value in [replace(control,status='claim',rootId=str(uuid4())),replace(control,status='stop',taskId=str(uuid4())),replace(control,status='claim',operationId=str(uuid4())),replace(control,status='claim',operationId=None)]:
        driver.command(value)
        assert not driver.claimed and not driver.stopped and not driver.resumed
    driver.command(replace(control,status='claim'))
    assert driver.claimed


def test_stop_received_before_initialization_survives_a_later_resume_signal():
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver
    _,_,_,context,_=selected();driver=AgentTaskDriver()
    stop=WorkflowControl(context['rootId'],context['taskId'],None,'stop')
    driver.command(stop);driver.command(replace(stop,status='resume'))
    assert driver.pending_control==stop
    driver.context=context;driver.command(driver.pending_control)
    assert driver.stopped and not driver.resumed


def test_source_join_non_success_control_is_typed_scoped_and_preserves_legacy_bytes():
    from agentic_os_agent_worker.workflow_control import SourceJoinReadControl,ReadControl,read_control,JOIN_CONTROL_ENCODING,READ_CONTROL_ENCODING
    converter,store,keys,context,_=selected()
    control=SourceJoinReadControl(context['rootId'],context['taskId'],str(uuid4()),'not-satisfied','a'*64,[str(uuid4())])
    old=ReadControl(context['rootId'],context['taskId'],control.operationId,'completed','a'*64,[])
    async def run():
        private=await converter.encode([asdict(control)])
        assert private[0].metadata['encoding']==ENCODING and len(store.writes)==1
        keys.key=None
        typed=read_control(asdict(control));assert isinstance(typed,SourceJoinReadControl)
        encoded=await converter.encode([typed,old])
        assert [value.metadata['encoding'] for value in encoded]==[JOIN_CONTROL_ENCODING,READ_CONTROL_ENCODING]
        assert encoded[1].data==json.dumps(asdict(old),sort_keys=True,separators=(',',':')).encode()
        assert await converter.decode(encoded)==[control,old] and len(store.writes)==1
        with pytest.raises(ApplicationError):await converter.encode([replace(control,rootId=str(uuid4()))])
        assert len(store.writes)==1
    asyncio.run(run())
