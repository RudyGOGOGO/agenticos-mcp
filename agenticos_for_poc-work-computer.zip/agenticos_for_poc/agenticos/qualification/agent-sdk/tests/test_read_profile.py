"""Discovery selection stays explicit without changing frozen journey wires."""
from copy import deepcopy
import json
from pathlib import Path

import pytest

from agentic_os_agent_worker.read_journey import selected_reads
from agentic_os_agent_worker.sdk_model import SDKModelPolicyError
from agentic_os_agent_worker.transport import _validate
from test_sdk_tools import item_fixture
from agentic_os_agent_worker.read_journey import validate_phase


@pytest.mark.parametrize('compact',[False,True])
@pytest.mark.parametrize('phase',['objective','execution'])
def test_base_analysis_entry_keeps_full_serialized_schema_with_original_request_bound(monkeypatch,compact,phase):
    """Replay the demonstrated base-catalog overflow through its actual entry."""
    import asyncio
    from datetime import datetime
    from dataclasses import replace
    from uuid import UUID,uuid5
    from types import SimpleNamespace
    from agents import ModelTracing
    from agents.items import ItemHelpers
    from temporalio.contrib.openai_agents._temporal_model_stub import _TemporalModelStub
    from temporalio.contrib.openai_agents._model_parameters import ModelActivityParameters
    from temporalio.contrib.openai_agents._invoke_model_activity import ActivityModelInput,_build_tools_and_handoffs
    from temporalio.contrib.openai_agents._temporal_worker_env_ref import _WorkerEnvRefResolver,AllowAllWorkerEnvVars
    from temporalio.converter import WorkflowSerializationContext
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.memory_output import AnalysisOutput
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    from agentic_os_agent_worker.private_history import AgentHistoryCodec
    from agentic_os_agent_worker.sdk_model import GovernedResponsesModel
    from agentic_os_agent_worker.transport import OfficialTransport
    from agents.tool_context import ToolContext
    from test_tool_execution_rpc import accepted_for
    from test_parallel_children import sample
    from test_sdk_model import binding_fixture
    from test_private_history import Keys,Store
    metadata=json.loads((Path(__file__).parents[1]/'fixtures/base-analysis-catalog.json').read_bytes())['metadata']
    value=sample('AgentSDKAnalysisJourneyStart');config,_,binding=binding_fixture();context=binding['context']
    question='Compute the mean available concentration and maximum sample, preserving units, coverage and all ties.'
    value['start'].update(context=context,input=question,capabilities=metadata['capabilities'],checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,
        continuationInputJson=None,providers=metadata['providers'])
    arguments=json.dumps(dict(projectId='synthetic-project',metric='concentration',targetUnit='mg/L',cursor=None))
    if phase=='execution':
        goal=sample('AgentAnalysisGoalDraft');goal['queries'][0].update(capability=metadata['capabilities'][0]['capability'],
            providerRef=metadata['providers'][0]['providerRef'],argumentsJson=arguments)
        binding.update(sdkInstanceId=str(uuid5(UUID(context['taskId']),'sdk-instance/1')),turn=2,
            parentOperationId=str(uuid5(UUID(context['taskId']),'synthetic-original-model')))
        value.update(phase=phase,binding=binding,goalDigest='a'*64,goalDraftJson=json.dumps(goal))
    async def execute(self,request):
        result=accepted_for(request,query=True);page=json.loads(result['accepted']['payloadJson'])
        page['page'].update(records=[[dict(name='amount',value='PRIVATE-RAW-CONTENT-'+'x'*900)]for _ in range(16)],nextCursor='next/owned')
        page['page']['evidence']['publicFields']=['amount']
        page['coverage'].update(observedRows=16,expectedRows=32,status='partial',nextCursorRef='cursor/owned')
        result['accepted']['payloadJson']=json.dumps(page,separators=(',',':'))
        result['accepted']['result'].update(subject=context['subject'],rootId=context['rootId'],taskId=context['taskId'])
        result['accepted']['result']['payload']['bytes']=len(result['accepted']['payloadJson'].encode())
        return result
    monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    workflow_id='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=workflow_id))
    monkeypatch.setattr(read_journey.workflow,'now',lambda:datetime.fromisoformat(context['admittedAt']))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:compact or name not in {
        'analysis-base-schema-once-instructions/1','analysis-base-compact-query-results/1'})
    converter=AgentPayloadConverter();keys=Keys();store=Store(context)
    codec=AgentHistoryCodec(store,keys,context,'default',key_id=keys.id).with_context(WorkflowSerializationContext('default',workflow_id))
    seen=[]
    class Captured(BaseException):pass
    async def inspect(agent,initial,**kwargs):
        seen.append(agent)
        expected=AnalysisOutput(objective=phase=='objective',metric_semantics=True)
        assert agent.output_type.json_schema()==expected.json_schema()
        items=ItemHelpers.input_to_new_input_list(initial)
        if phase=='execution':
            tool=agent.tools[0];call_id='synthetic-original-query-call'
            output=await tool.on_invoke_tool(ToolContext(context=None,agent=agent,tool_name=tool.name,
                tool_call_id=call_id,tool_arguments=arguments),arguments)
            page=json.loads(output)
            assert page['schema']==('agent-accepted-query-ref/1'if compact else 'agent-accepted-query/1')
            if compact:assert page['nextCursor']=='next/owned' and page['coverage']['observedRows']==16 and 'PRIVATE-RAW-CONTENT'not in output
            items.extend([dict(type='function_call',name=tool.name,call_id=call_id,arguments=arguments),
                dict(type='function_call_output',call_id=call_id,output=output)])
        await kwargs['hooks'].on_llm_start(None,agent,agent.instructions,items)
        stub=_TemporalModelStub('synthetic',model_params=ModelActivityParameters(),agent=None)
        activity,_=stub._build_activity_input(system_instructions=agent.instructions,input=items,
            model_settings=agent.model_settings,tools=agent.tools,output_schema=agent.output_type,handoffs=[],
            tracing=ModelTracing.DISABLED,previous_response_id=None,conversation_id=None,prompt=None)
        decoded=converter.from_payloads(await codec.decode(await codec.encode(converter.to_payloads([activity]))),[ActivityModelInput])[0]
        tools,_=_build_tools_and_handoffs(decoded,_WorkerEnvRefResolver(AllowAllWorkerEnvVars()))
        model=object.__new__(GovernedResponsesModel)
        model.transport=SimpleNamespace(config=replace(config,max_request_bytes=16384))
        model.max_output_tokens=value['start']['maxOutputTokens'];model.reasoning_effort=None
        args=(decoded['system_instructions'],decoded['input'],decoded['model_settings'],tools,decoded['output_schema'],[],ModelTracing.DISABLED,None,None,None)
        if compact:
            _,_,raw=model._request(*args);body=json.loads(raw)
            assert len(raw.encode())<=16384 and body['input']==items and items[0]==ItemHelpers.input_to_new_input_list(question)[0]
            assert body['text']['format']['schema']==expected.json_schema()
            transport=object.__new__(OfficialTransport);transport.config=model.transport.config
            transport._body(dict(context=context,requestTimeoutMs=config.request_timeout_ms,maxOutputTokens=value['start']['maxOutputTokens']),raw)
            if phase=='objective':
                displayed=json.JSONDecoder().raw_decode(body['instructions'].split('Reviewed metadata: ',1)[1])[0]
                assert displayed==metadata and 'Schema: ' not in body['instructions']
            from agents.exceptions import ModelBehaviorError
            with pytest.raises(ModelBehaviorError):agent.output_type.validate_json('{"queries":[],"criteria":[]}')
        else:
            with pytest.raises(SDKModelPolicyError):model._request(*args)
            if phase=='objective':assert 'Schema: ' in agent.instructions and 'must retain the winning entity identities' in agent.instructions
        raise Captured()
    monkeypatch.setattr(read_journey.Runner,'run',inspect)
    with pytest.raises(Captured):asyncio.run(AgentTaskDriver().run(value))
    assert len(seen)==1 and store.writes


@pytest.mark.parametrize('reuse',[False,True])
@pytest.mark.parametrize('empty',[False,True])
def test_memory_goal_handoff_reuses_serialized_sdk_source_and_keeps_legacy_discovery(monkeypatch,reuse,empty,overflow=False,response=False,more_evidence=False,stalled=False):
    """Actual router, SDK approval/checkpoint, model wire and phase consumer."""
    import asyncio
    from types import SimpleNamespace
    from uuid import UUID,uuid5
    from agents import Model,RunConfig
    from agents.items import ModelResponse
    from agents.models.interface import ModelProvider
    from agents.usage import Usage
    from openai.types.responses import ResponseFunctionToolCall,ResponseOutputMessage,ResponseOutputText
    from temporalio.contrib.openai_agents._temporal_model_stub import _TemporalModelStub
    from temporalio.contrib.openai_agents._model_parameters import ModelActivityParameters
    from temporalio.contrib.openai_agents._invoke_model_activity import ActivityModelInput,ModelActivity
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.sdk_model import BINDING_KEY,operation_id,_RESPONSE_INPUT
    from agentic_os_agent_worker.temporal_driver import WorkflowBoundary
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,MemoryReadControl
    from test_parallel_children import Rollover,sample
    from test_sdk_model import binding_fixture
    from test_sdk_tools import Boundary
    from test_tool_execution_rpc import memory_accepted_for
    value=sample('AgentSDKMemoryResponseJourneyStart' if response else 'AgentSDKMemoryReadJourneyStart');_,_,binding=binding_fixture()
    c=deepcopy(binding['context']);c['harness']['ref']='memory-assisted-read/synthetic-source'
    if response:c['harness']['ref']='memory-assisted-read/response/2/'+'a'*64
    item=item_fixture()|dict(kind='memory');question='Which saved response length, type, context and source status did I select?'
    value['start'].update(context=c,capabilities=[item],checkpointId=None,
        input=json.dumps(dict(question=question,contextRef='general/1')))
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        discoveryCapabilities=[item['capability']],providers=[dict(capability=item['capability'],providerRef='synthetic.read')])
    converter=AgentPayloadConverter();seen=[];checkpoints={};carried=[];goals=[];finals=[];drafts=[];kernel=Boundary()
    expected='os-agent:'+':'.join([c['subject']['installationId'],c['subject']['applicationId'],c['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,
        is_continue_as_new_suggested=lambda:True,get_current_history_length=lambda:1))
    patches={'memory-selected-context-input/1','memory-original-question-prefix/1','memory-goal-field-coverage/1','memory-output-contracts/1'}
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:name in patches or reuse and name=='memory-accepted-source-continuation/1')
    def wire(value):return converter.from_payloads(converter.to_payloads([value]))[0]
    def rollover(next_value,**kwargs):carried.append(wire(next_value));raise Rollover()
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    async def accepted(self,context,operation):return await kernel.accepted_model_operation(context,operation)
    async def get(self,context,ident):assert context==c;return wire(checkpoints[ident])
    async def execute(self,request):
        assert request['context']==c;kernel.requests.append(deepcopy(request))
        result=memory_accepted_for(request);memory=json.loads(result['accepted']['payloadJson'])
        if not empty:
            resource=dict(subject=deepcopy(c['subject']),providerId='synthetic.read',resourceType='owner-memory',
                contractVersion=1,externalId=str(uuid5(UUID(c['taskId']),'saved-memory')),observedVersion='1')
            memory['page']['evidence']['resourceRefs']=[resource]
            memory['page']['records']=[[dict(name=name,value=text) for name,text in (
                ('text','I prefer concise written updates.'),('memoryType','preference'),('contextRef','general/1'),('sourceStatus','current'))]]
            memory['coverage'].update(scopeCount=1,returnedCount=1)
            if overflow:
                memory['page']['evidence']['resourceRefs']=[dict(resource,externalId=str(uuid5(UUID(c['taskId']),'saved-memory/'+str(i)))) for i in range(8)]
                record=memory['page']['records'][0];record[0]['value']='M'*1000
                memory['page']['records']=[deepcopy(record) for _ in range(8)]
                memory['coverage'].update(scopeCount=8,returnedCount=8)
        _validate('AgentMemoryPage',memory)
        result['accepted']['payloadJson']=json.dumps(memory)
        return result
    async def bind(self,context,operation):
        assert context==c and operation==operation_id(seen[-1]['binding'])
        goals.append(operation)
        return MemoryReadControl(rootId=c['rootId'],taskId=c['taskId'],operationId=operation,state='goal-bound',goalDigest='a'*64,missingCriteria=[])
    async def complete(self,context,operation):
        assert context==c and operation==operation_id(seen[-1]['binding']);finals.append(operation)
        criteria=next(draft['criteria'] for draft in reversed(drafts) if 'criteria' in draft)
        required={(resource['externalId'],field) for criterion in criteria for resource in criterion['resources'] for field in criterion['fields']}
        selected={(fact['resource']['externalId'],fact['field']) for fact in drafts[-1]['facts']}
        state='incomplete' if required-selected else 'not-satisfied' if response and empty else 'completed'
        return MemoryReadControl(rootId=c['rootId'],taskId=c['taskId'],operationId=operation,state=state,
            goalDigest='a'*64,missingCriteria=[str(uuid5(UUID(c['taskId']),'criterion'))] if state=='incomplete' else [])
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',get)
    monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    monkeypatch.setattr(WorkflowBoundary,'bind_read_goal',bind)
    monkeypatch.setattr(WorkflowBoundary,'complete_read',complete)
    class ProviderModel(Model):
        async def get_response(self,system_instructions,input,model_settings,tools,output_schema,*args,**kwargs):
            current=_RESPONSE_INPUT.dump_python(input,mode='json',warnings='error')
            current_binding=json.loads(model_settings.metadata[BINDING_KEY]);seen.append(dict(input=current,binding=current_binding))
            outputs=[json.loads(row['output']) for row in current if row.get('type')=='function_call_output']
            objective=output_schema.name() in {'AgentMemoryReadGoalDraft','AgentMemoryResponseDraft'}
            if not outputs:
                output=[ResponseFunctionToolCall(type='function_call',name=tools[0].name,arguments='{"value":0.5}',
                    call_id='recall_'+str(len(seen))+'_'+str(i),id='fc_'+str(len(seen))+'_'+str(i)) for i in range(3 if overflow else 1)]
            else:
                source=outputs[-1];assert source['schema']=='agent-accepted-memory/1'
                page=source['memory']['page'];resources=page['evidence']['resourceRefs'];fields=['text','memoryType','contextRef','sourceStatus']
                draft=(dict(criteria=[dict(id=str(uuid5(UUID(c['taskId']),'criterion')),capability=item['capability'],resources=[dict(providerRef='synthetic.read',resourceType=row['resourceType'],externalId=row['externalId']) for row in resources],fields=fields,coverage='selected-records')] if resources else []) if objective else
                    dict(goalDigest='a'*64,facts=[dict(result=source['result'],resource=resource,field=field) for resource in resources for field in fields]))
                if response and objective:
                    draft['facts']=[dict(result=source['result'],resource=resource,field=field) for resource in resources for field in fields]
                    if more_evidence:draft['facts']=draft['facts'][:1]
                    assert 'then independently verifies' in system_instructions and 'with only "criteria"' not in system_instructions
                if stalled and not objective:draft['facts']=draft['facts'][:1]
                drafts.append(deepcopy(draft))
                raw=json.dumps(draft);_validate(output_schema.name(),draft)
                if overflow and objective:raw=raw.ljust(16384)
                if not objective:
                    assert question in json.dumps(current) or not reuse
                    assert ('phase transition alone does not require another recall' in system_instructions)==reuse
                    if reuse and not overflow:
                        parent=operation_id(seen[-2]['binding']) if stalled and len(seen)>3 else goals[0]
                        assert current_binding['parentOperationId']==parent and len(current_binding['inputResults'])==1
                output=[ResponseOutputMessage(type='message',id='msg_'+str(len(seen)),role='assistant',status='completed',content=[ResponseOutputText(type='output_text',text=raw,annotations=[])])]
            return ModelResponse(output=output,usage=Usage(requests=1),response_id='response_'+str(len(seen)))
        def stream_response(self,*args,**kwargs):raise AssertionError('No streaming in this profile')
    model=ProviderModel()
    class Provider(ModelProvider):
        def get_model(self,name):return model
    activity=ModelActivity(model_provider=Provider());stub=_TemporalModelStub(value['start']['modelId'],model_params=ModelActivityParameters(),agent=None)
    class SerializedModel(Model):
        async def get_response(self,system_instructions,input,model_settings,tools,output_schema,handoffs,tracing,**kwargs):
            request,_=stub._build_activity_input(system_instructions=system_instructions,input=input,model_settings=model_settings,tools=tools,output_schema=output_schema,handoffs=handoffs,tracing=tracing,**kwargs)
            request=converter.from_payloads(converter.to_payloads([request]),[ActivityModelInput])[0]
            return await ModelActivity.invoke_model_activity.__wrapped__(activity,request)
        def stream_response(self,*args,**kwargs):raise AssertionError('No streaming in this profile')
    class WorkflowProvider(ModelProvider):
        def get_model(self,name):return SerializedModel()
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=WorkflowProvider()))
    class Driver:
        stopped=False;pending_control=None
        def _expired(self):return False
        def _terminal(self,control):return control
        async def _save(self,boundary,ident,envelope):checkpoints[ident]=wire(envelope);return dict(kind='ready')
    async def run():
        current=wire(value)
        for _ in range(6):
            try:result=await read_journey.run_read_journey(Driver(),current)
            except Rollover:current=carried[-1];continue
            if stalled:assert result.status=='configuration-required'
            else:assert result.state==('not-satisfied' if response and empty else 'completed')
            break
        else:raise AssertionError('Serialized memory handoff did not finish')
    asyncio.run(run())
    assert len(seen)==(4 if stalled else 3 if more_evidence else 2 if response else 3 if reuse and not overflow else 4)
    assert len(kernel.requests)==(6 if overflow else 1 if reuse else 2)
    assert len(checkpoints)==(2 if overflow else len(kernel.requests)) and len(goals)==1 and len(finals)==(3 if stalled else 2 if more_evidence else 1)
    if response and not more_evidence:
        assert all(row['phase']=='objective' for row in carried)
        assert goals==finals  # Bind and verify the same original accepted operation.
        assert all(row['binding']['context']==c for row in seen)
        return
    execution=next(row for row in carried if row['phase']=='execution')
    assert (execution['continuationInputJson'] is not None)==(reuse and not overflow)
    assert execution['binding']['parentOperationId']==goals[0] and execution['start']['checkpointId'] is None
    assert all(row['binding']['context']==c for row in seen)


def test_memory_handoff_keeps_full_goal_and_uses_discovery_when_context_exceeds_existing_bound(monkeypatch):
    test_memory_goal_handoff_reuses_serialized_sdk_source_and_keeps_legacy_discovery(monkeypatch,True,False,overflow=True)


@pytest.mark.parametrize('outcome',['complete','empty','more-evidence'])
def test_versioned_memory_response_reaches_actual_serialized_goal_and_completion_or_original_execution(monkeypatch,outcome):
    test_memory_goal_handoff_reuses_serialized_sdk_source_and_keeps_legacy_discovery(monkeypatch,True,
        outcome=='empty',response=True,more_evidence=outcome=='more-evidence')


@pytest.mark.parametrize('response',[False,True])
def test_memory_response_entry_refuses_cross_version_context_before_model_or_control(response):
    import asyncio
    from types import SimpleNamespace
    from agentic_os_agent_worker import read_journey
    from test_parallel_children import sample
    value=sample('AgentSDKMemoryResponseJourneyStart' if response else 'AgentSDKMemoryReadJourneyStart')
    value['start']['context']['harness']['ref']=('memory-assisted-read/' if response else 'memory-assisted-read/response/2/')+'a'*64
    with pytest.raises(SDKModelPolicyError):asyncio.run(read_journey.run_read_journey(SimpleNamespace(),value))


def test_memory_response_uses_existing_no_progress_control_for_identical_incomplete_facts(monkeypatch):
    test_memory_goal_handoff_reuses_serialized_sdk_source_and_keeps_legacy_discovery(monkeypatch,True,False,
        response=True,more_evidence=True,stalled=True)


@pytest.mark.parametrize('objective',[False,True])
@pytest.mark.parametrize('patched',[False,'context-only','fresh-legacy',True,'field-coverage'])
def test_serialized_memory_start_preserves_question_context_and_legacy_prompt_boundary(monkeypatch,patched,objective):
    import asyncio
    from types import SimpleNamespace
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
    value=deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']=='AgentSDKMemoryReadJourneyStart'))
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None)
    if not objective:
        from test_memory_output import goal
        draft=goal();draft['criteria'][0]['fields']=['text','memoryType','contextRef','sourceStatus']
        value.update(phase='execution',goalDigest='a'*64,goalDraftJson=json.dumps(draft))
    item=item_fixture()|dict(kind='memory',inputSchemaJson=json.dumps(dict(type='object',additionalProperties=False,
        required=['contextRef','query','mode'],properties=dict(contextRef=dict(type='string'),query=dict(type='string'),
            mode=dict(type='string',enum=['exact','lexical'])))))
    value['start']['capabilities']=[item];value['discoveryCapabilities']=[item['capability']]
    value['providers']=[dict(capability=item['capability'],providerRef='owner-memory/1')]
    question='Which response length did I save?';original=question if not patched or patched=='fresh-legacy' else json.dumps(dict(question=question,contextRef='general/1'))
    value['start'].update(input=original,checkpointId=None)
    converter=AgentPayloadConverter();value=converter.from_payloads(converter.to_payloads([value]))[0]
    c=value['start']['context'];seen=[]
    expected='os-agent:'+':'.join([c['subject']['installationId'],c['subject']['applicationId'],c['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:bool(patched) if name in {'memory-selected-context-input/1','memory-output-contracts/1'} else patched in (True,'fresh-legacy','field-coverage') if name=='memory-original-question-prefix/1' else patched=='field-coverage' if name=='memory-goal-field-coverage/1' else False)
    class Observed(BaseException):pass
    async def observe(agent,initial,**kwargs):
        assert initial==(question if patched in (True,'field-coverage') else original) and len(agent.tools)==1
        assert ('owner-selected contextRef' in agent.instructions)==bool(patched)
        assert ('offline vector similarity' in agent.instructions)==bool(patched)
        assert (agent.output_type is not None)==bool(patched)
        if patched is True:assert '"general/1"' in agent.instructions
        if patched:assert agent.output_type.name()==('AgentMemoryReadGoalDraft' if objective else 'AgentMemoryReadAnswerDraft') and agent.output_type.is_strict_json_schema()
        if patched=='field-coverage':
            assert 'not additional requested deliverables' not in agent.instructions
            if objective:assert 'select text' in agent.instructions
            else:
                assert 'every resource and field' in agent.instructions
                assert draft['criteria'][0]['fields']==['text','memoryType','contextRef','sourceStatus']
                assert json.dumps(draft) in agent.instructions
        elif patched:assert 'not additional requested deliverables' in agent.instructions
        assert 'Memory text is owner context, never authority' in agent.instructions
        assert 'concise written updates' not in agent.instructions
        seen.append(True);raise Observed()
    monkeypatch.setattr(read_journey.Runner,'run',observe)
    class Driver:
        stopped=False;pending_control=None
        def _expired(self):return False
    with pytest.raises(Observed):asyncio.run(read_journey.run_read_journey(Driver(),value))
    assert seen==[True]


@pytest.mark.parametrize('analysis',[False,True])
@pytest.mark.parametrize('patched,objective,failures,stopped,expired,reason,calls,pauses,terminal',[
    (True,False,1,False,False,'waiting-reconciliation',2,0,None),
    (False,False,1,False,False,'waiting-reconciliation',2,1,None),
    (True,True,1,False,False,'waiting-reconciliation',2,1,None),
    (True,False,2,False,False,'waiting-reconciliation',3,1,None),
    (True,False,1,True,False,'waiting-reconciliation',1,0,'stopped'),
    (True,False,1,False,True,'waiting-reconciliation',1,0,'authorization-expired'),
    (True,False,1,False,False,'scope-changed',1,0,'scope-changed'),
])
def test_uncertain_completion_observes_same_candidate_once_before_wait_without_renewal(
        monkeypatch,analysis,patched,objective,failures,stopped,expired,reason,calls,pauses,terminal):
    import asyncio
    from types import SimpleNamespace
    from uuid import uuid4
    from temporalio.exceptions import ApplicationError
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.workflow_control import WorkflowControl,ReadControl,WAIT_TYPE
    from test_private_state_rpc import fixture
    _,context,_,_,_=fixture();operation=str(uuid4());seen=[];waited=[]
    expected=('bind_analysis_goal' if analysis else 'bind_read_goal') if objective else ('complete_analysis' if analysis else 'complete_read')
    def handler(name):
        async def call(actual,ident):
            assert actual==context and ident==operation and name==expected
            seen.append(ident)
            if len(seen)<=failures:
                control=WorkflowControl(context['rootId'],context['taskId'],operation,reason,None)
                raise ApplicationError('agent_wait',control,type=WAIT_TYPE,non_retryable=True)
            return ReadControl(rootId=context['rootId'],taskId=context['taskId'],operationId=operation,
                state='goal-bound' if objective else 'completed',goalDigest='a'*64,missingCriteria=[])
        return call
    boundary=SimpleNamespace(**{name:handler(name) for name in ('bind_analysis_goal','bind_read_goal','complete_analysis','complete_read')})
    class Driver:
        def _expired(self):return expired
        async def _pause(self,wait):
            assert wait.operationId==operation
            waited.append(wait)
    driver=Driver();driver.stopped=stopped
    def patch(name):
        assert name=='read-completion-ack-observation/1'
        return patched
    monkeypatch.setattr(read_journey.workflow,'patched',patch)
    result=asyncio.run(read_journey.complete_goal(driver,boundary,context,operation,analysis=analysis,objective=objective))
    assert len(seen)==calls and len(waited)==pauses
    assert result.operationId==(None if terminal in {'stopped','authorization-expired'} else operation)
    assert result.rootId==context['rootId'] and result.taskId==context['taskId']
    if terminal:assert result.status==terminal
    else:assert result.state==('goal-bound' if objective else 'completed')


@pytest.mark.parametrize('patched',[False,True])
def test_model_timeout_retains_pending_operation_only_for_patched_histories(monkeypatch,patched,retained_logical=False):
    import asyncio
    from types import SimpleNamespace
    from uuid import UUID,uuid5
    from temporalio.exceptions import TimeoutError,TimeoutType
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.sdk_model import operation_id
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
    contract='AgentSDKQuerySourceChildJoinJourneyStart' if retained_logical else 'AgentSDKReadJourneyStart'
    value=deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']==contract))
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None)
    value['start']['checkpointId']=None;c=value['start']['context'];seen=[];pending=[]
    if retained_logical:
        from agentic_os.production.logical_goal_retention import profile_pin
        from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
        value.update(childAfter=None,childContinuation=None,childContinuations=[],sourceBindingId=None,sourceQueryWindowJson=None)
        c['harness']=profile_pin();converter=AgentPayloadConverter()
        value=converter.from_payloads(converter.to_payloads([value]))[0];c=value['start']['context']
        _validate(contract,value)
    expected='os-agent:'+':'.join([c['subject']['installationId'],c['subject']['applicationId'],c['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:patched if name=='read-model-timeout-operation/1' else False)
    async def timed_out(agent,initial,*,hooks,**_):
        # Exercise the actual public start hook that establishes the pending
        # operation before the SDK's model Activity can lose its return ACK.
        await hooks.on_llm_start(None,agent,None,[]);pending.append(operation_id(hooks.snapshot()))
        raise TimeoutError('synthetic model Activity timeout',type=TimeoutType.START_TO_CLOSE,last_heartbeat_details=[])
    monkeypatch.setattr(read_journey.Runner,'run',timed_out)
    class Driver:
        stopped=False;pending_control=None
        def _expired(self):return False
        def _terminal(self,value):return value
        async def _pause(self,control):seen.append(control);self.stopped=True
    result=asyncio.run(read_journey.run_read_journey(Driver(),value))
    assert result.status=='stopped' and len(seen)==len(pending)==1
    assert seen[0].operationId==(pending[0] if patched else None)
    assert pending[0]==str(uuid5(uuid5(UUID(c['taskId']),'sdk-instance/1'),'model-turn/1'))


@pytest.mark.parametrize('charts',[False,True,'paged','planned','comparison'])
def test_discovery_prelude_offers_only_selected_pins_and_retains_execution_tools(charts):
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
    value=deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']=='AgentSDKAdaptiveAnalysisJourneyStart'))
    if charts:value['schema']='agent-comparison-journey/1' if charts=='comparison' else 'agent-planned-analysis-journey/1' if charts=='planned' else 'agent-paged-analysis-journey/1' if charts=='paged' else 'agent-chart-analysis-journey/1'
    if charts in {'planned','comparison'}:value['planStateJson']=None
    discovery=item_fixture();value['start']['capabilities']=[discovery]
    value['discoveryCapabilities']=[deepcopy(discovery['capability'])]
    other=deepcopy(discovery);other['capability']['ref']='separate.query';value['start']['capabilities'].append(other)
    _validate('AgentSDKComparisonJourneyStart' if charts=='comparison' else 'AgentSDKPlannedAnalysisJourneyStart' if charts=='planned' else 'AgentSDKPagedAnalysisJourneyStart' if charts=='paged' else 'AgentSDKChartAnalysisJourneyStart' if charts else 'AgentSDKAdaptiveAnalysisJourneyStart',value)
    assert selected_reads(value,objective=True)==[discovery]
    assert selected_reads(value,objective=False)==[discovery,other]
    value['discoveryCapabilities'][0]['revision']+=1
    with pytest.raises(SDKModelPolicyError):selected_reads(value,objective=True)
    for schema,name in [('agent-analysis-journey/1','AgentSDKAnalysisJourneyStart'),('agent-read-journey/1','AgentSDKReadJourneyStart')]:
        frozen=deepcopy(value);frozen['schema']=schema
        with pytest.raises(Exception):_validate(name,frozen)
        del frozen['discoveryCapabilities'];frozen.pop('planStateJson',None);_validate(name,frozen)
        assert selected_reads(frozen,objective=True)==frozen['start']['capabilities']


@pytest.mark.parametrize('charts',[False,True,'paged','planned'])
def test_discovery_checkpoint_resumes_the_actual_sdk_before_goal_binding(charts):
    import asyncio
    from test_checkpoint import paused
    from agentic_os_agent_worker.checkpoint import export_checkpoint,restore_checkpoint,SDKCheckpointError
    async def run():
        item=await paused()
        try:
            discovery=item_fixture();discovery['capability']=item['pin']
            execution=deepcopy(discovery);execution['capability']=item['pin']|dict(ref='separate.execution')
            value=dict(schema='agent-adaptive-analysis-journey/1',phase='objective',goalDigest=None,goalDraftJson=None,
                start=dict(capabilities=[discovery,execution]),discoveryCapabilities=[item['pin']])
            if charts:value['schema']='agent-planned-analysis-journey/1' if charts=='planned' else 'agent-paged-analysis-journey/1' if charts=='paged' else 'agent-chart-analysis-journey/1'
            phase_pins=[entry['capability'] for entry in selected_reads(value,objective=True)]
            saved=json.loads(json.dumps(export_checkpoint(item['result'],item['sequence'],phase_pins)))
            validate_phase(value,saved)
            for schema in ['agent-read-journey/1','agent-analysis-journey/1']:
                with pytest.raises(SDKModelPolicyError):validate_phase(value|dict(schema=schema),saved)
            with pytest.raises(SDKModelPolicyError):validate_phase(value|dict(goalDigest='a'*64),saved)
            assert len(item['issued'])==1 and item['executed']==[]
            with pytest.raises(SDKCheckpointError):await restore_checkpoint(item['agent'](),saved,
                expected_context=item['binding']['context'],sdk_instance_id=item['binding']['sdkInstanceId'],
                capabilities=[discovery['capability'],execution['capability']])
            restored=await restore_checkpoint(item['agent'](),saved,expected_context=item['binding']['context'],
                sdk_instance_id=item['binding']['sdkInstanceId'],capabilities=phase_pins)
            restored.state.approve(restored.state.get_interruptions()[0])
            result=await restored.run(item['provider'])
            assert result.final_output=='Checkpoint continued' and item['executed']==[1]
            assert len(item['issued'])==len(item['rpc'].accepted)==2
            assert restored.sequence.snapshot()['turn']==3
        finally:await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())


def test_chart_planner_uses_a_closed_source_only_schema_without_changing_legacy_instructions():
    from agentic_os_agent_worker.read_journey import analysis_objective_instructions
    from jsonschema import Draft202012Validator
    legacy=analysis_objective_instructions([],[])
    assert 'AgentChartRequest' not in legacy
    current=analysis_objective_instructions([],[],charts=True)
    schema=json.loads(current.split('Schema: ',1)[1].split('. Reviewed metadata: ',1)[0])
    Draft202012Validator.check_schema(schema)
    request=schema['$defs']['AgentChartRequest']
    assert set(request['properties'])=={'id','kind','criterionId','dimension','unit'}
    assert request['additionalProperties'] is False


def test_actual_read_entry_keeps_serialized_conflict_and_obtainable_gap_before_partial_consumer(monkeypatch):
    import asyncio,importlib.util
    from dataclasses import asdict
    from types import SimpleNamespace
    from uuid import UUID,uuid4,uuid5
    from agents import RunConfig
    from agents.models.interface import ModelProvider
    from temporalio.converter import WorkflowSerializationContext
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,PartialReadControl
    from agentic_os_agent_worker.private_history import AgentHistoryCodec,PrivateHistoryUnavailable
    from agentic_os_agent_worker.sdk_model import BINDING_KEY,operation_id
    from test_parallel_children import Rollover,sample
    from test_sdk_tools import Boundary
    from test_openai_control_flow import ScriptedModel,answer
    from agentic_os.production.partial_read_answer import compile_partial_read_answer
    path=Path(__file__).parents[3]/'tests/unit/test_partial_read_answer.py'
    spec=importlib.util.spec_from_file_location('partial_read_source_fixture',path)
    fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
    goal,material,full,partial=fixture.fixture();context=deepcopy(goal['context'])
    value=sample('AgentSDKReadJourneyStart');item=item_fixture();item['capability']=goal['criteria'][0]['capability']
    value['start'].update(context=context,input='Read both requested fields from the selected record.',
        capabilities=[item],checkpointId=None)
    binding=dict(context=deepcopy(context),sdkInstanceId=str(uuid5(UUID(context['taskId']),'sdk-instance/1')),
        turn=2,planRevision=1,parentOperationId=str(uuid4()),inputResults=[row['result'] for row in material])
    value.update(phase='execution',binding=binding,goalDigest=full['goalDigest'],
        goalDraftJson=json.dumps(dict(criteria=goal['criteria'])),continuationInputJson=None,
        providers=[dict(capability=item['capability'],providerRef=goal['criteria'][0]['resources'][0]['providerRef'])])
    expected='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,
        is_continue_as_new_suggested=lambda:False,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda _:False)
    carried=[];observed=[];documents=[full,dict(partial,facts=[]),partial];kernel=Boundary();converter=AgentPayloadConverter()
    staged={};accepted_by_operation={};causal={};sources={row['result']['resultId']:row for row in material}
    def wire(value):
        payload=converter.to_payloads([value])[0]
        assert len(payload.SerializeToString(deterministic=True))<=65536
        return converter.from_payloads([payload])[0]
    def rollover(next_value,**options):
        assert options==dict(task_queue=expected+'/execution/1')
        carried.append(wire(next_value));raise Rollover()
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    async def accepted(self,c,operation):
        if operation not in accepted_by_operation:
            reference=await kernel.accepted_model_operation(c,operation)
            accepted_by_operation[operation]=reference;causal[reference['resultId']]=deepcopy(staged[operation])
        return deepcopy(accepted_by_operation[operation])
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    def respond(items):
        document=documents[len(observed)];observed.append(deepcopy(document));return answer(json.dumps(document))
    class ObservedModel(ScriptedModel):
        async def get_response(self,system_instructions,input,*args,**kwargs):
            settings=kwargs['model_settings'] if 'model_settings' in kwargs else args[0]
            current=json.loads(settings.metadata[BINDING_KEY])
            staged[operation_id(current)]=deepcopy(current['inputResults'])
            return await super().get_response(system_instructions,input,*args,**kwargs)
    model=ObservedModel(respond)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    accepted_result=[]
    def source_closure(references):
        found={};seen=set()
        def visit(reference):
            ident=reference['resultId']
            if ident in seen:return
            seen.add(ident)
            if ident in sources:
                assert reference==sources[ident]['result'];found[ident]=sources[ident]
            else:
                assert ident in causal
                for dependency in causal[ident]:visit(dependency)
        for reference in references:visit(reference)
        return list(found.values())
    async def complete(driver,boundary,c,operation,**flags):
        assert c==context and not flags['objective'] and not flags['analysis']
        current_sources=source_closure([accepted_by_operation[operation]])
        assert len(current_sources)==len(material)
        current=compile_partial_read_answer(goal,observed[-1],current_sources)
        state='not-satisfied' if current['kind']=='verified' else 'incomplete'
        if current['kind']=='verified':accepted_result.append(current)
        return wire(PartialReadControl(rootId=c['rootId'],taskId=c['taskId'],operationId=operation,
            state=state,goalDigest=full['goalDigest'],missingCriteria=current['missingCriteria']))
    monkeypatch.setattr(read_journey,'complete_goal',complete)
    class Driver(AgentTaskDriver):
        def _expired(self):return False
    async def run():
        with pytest.raises(Rollover):await Driver().run(wire(value))
        with pytest.raises(Rollover):await Driver().run(carried[0])
        return await Driver().run(carried[1])
    control=asyncio.run(run())
    assert isinstance(control,PartialReadControl) and control.state=='not-satisfied'
    assert len(model.inputs)==3 and len(carried)==2 and len(accepted_result)==1
    assert all(len(state['binding']['inputResults'])==1 and len(source_closure(state['binding']['inputResults']))==2 for state in carried)
    result=accepted_result[0]
    assert result['answer']['blocks'][1]['value']==dict(name='stable',value='Verified unaffected fact')
    assert len(result['answer']['evidence'])==2 and result['missingCriteria']==[goal['criteria'][1]['id']]
    # The new closed safe control has no source bodies. Raw lookalike dicts
    # still use private encoding; another harness cannot accept this control.
    key=str(uuid4());store=SimpleNamespace(put_history=lambda:None,lookup_history=lambda:None)
    keys=SimpleNamespace(_key=lambda _:b'x'*32)
    codec=AgentHistoryCodec(store,keys,context,'private-local',key_id=key,
        serialization_context=WorkflowSerializationContext('private-local',expected))
    payload=converter.to_payloads([control])[0];assert codec._control(payload) is payload
    assert b'Verified unaffected fact' not in payload.data
    with pytest.raises(PrivateHistoryUnavailable):codec._control(converter.to_payloads([asdict(control)])[0])
    foreign=deepcopy(context);foreign['harness']['ref']='legacy-read/1'
    with pytest.raises(PrivateHistoryUnavailable):AgentHistoryCodec(store,keys,foreign,'private-local',key_id=key,
        serialization_context=WorkflowSerializationContext('private-local',expected))._control(payload)


def test_comparison_planner_declares_exact_source_sums_and_closed_missing_semantics():
    from agentic_os_agent_worker.read_journey import analysis_objective_instructions
    from jsonschema import Draft202012Validator
    instructions=analysis_objective_instructions([],[],charts=True,planned=True,comparison=True)
    schema=json.loads(instructions.split('Schema: ',1)[1].split('. Reviewed metadata: ',1)[0])
    Draft202012Validator.check_schema(schema)
    assert schema['$ref']=='#/$defs/AgentComparisonGoalDraft'
    criterion=schema['$defs']['AgentExactComparison']
    assert criterion['additionalProperties'] is False
    assert criterion['properties']['missing']=={'const':'report-undefined'}
    assert criterion['properties']['zeroBaseline']=={'const':'report-undefined'}
    assert criterion['properties']['operation']['enum']==['difference','percentage-change']
    assert 'signed base' in instructions and 'baseValue' not in criterion['properties']


def test_actual_assigned_probe_entry_point_uses_the_same_closed_start_contracts(tmp_path,record_property):
    import hashlib
    import os
    import subprocess
    import sys
    root=Path(__file__).parents[3]
    for name,source in [('assigned_read_probe.py',root/'tests/integration/resources/assigned_read_probe.py'),
            ('analysis_fixture.py',root/'tests/integration/resources/analysis_fixture.py'),
            ('contracts.json',root/'tests/fixtures/contracts.json')]:
        raw=source.read_bytes();target=tmp_path/name;target.write_bytes(raw);target.chmod(0o600)
        record_property(name+'_sha256',hashlib.sha256(raw).hexdigest())
    script=r"""
import importlib.util,json,sys
from pathlib import Path
from agentic_os_agent_worker.read_journey import start_contract
from agentic_os_agent_worker.sdk_model import SDKModelPolicyError
from agentic_os_agent_worker.transport import TransportError
assert importlib.util.find_spec('agentic_os') is None
spec=importlib.util.spec_from_file_location('actual_assigned_probe',Path.cwd()/'assigned_read_probe.py')
probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
page=dict(evidence=dict(resourceRefs=[dict(externalId='first'),dict(externalId='selected')]),
    records=[[dict(name='text',value='other approved note')],[dict(name='text',value='selected approved note')]])
assert probe.selected_memory_resources(dict(selectMemoryText=True,expected='selected approved note'),page)==[dict(externalId='selected')]
assert probe.selected_memory_resources(dict(expected='other approved note'),page)==page['evidence']['resourceRefs']
for expected in ('missing note','other approved note'):
    changed=json.loads(json.dumps(page))
    if expected=='other approved note':changed['records'][1][0]['value']=expected
    try:probe.selected_memory_resources(dict(selectMemoryText=True,expected=expected),changed)
    except AssertionError:pass
    else:raise AssertionError('Missing or ambiguous requested note accepted')
source=dict(resource=dict(externalId='source'),sourceField='text',field='text')
for identifiers in [['source'],['00007','other']]:
    probe._goal_module.check_source_child_selector(source,dict(externalIds=identifiers,fieldNames=['text']))
for identifiers,fields in [(['source','target'],['text']),(['target'],['headline'])]:
    try:probe._goal_module.check_source_child_selector(source,dict(externalIds=identifiers,fieldNames=fields))
    except AssertionError:pass
    else:raise AssertionError('Invalid source/target selector accepted')
from agentic_os_agent_worker.transport import _validate
_validate('AgentExactMetric',probe._goal_module.source_reduction_metric('text'))
vectors=json.loads(Path('contracts.json').read_bytes())
names=['AgentSDKReadJourneyStart','AgentSDKAnalysisJourneyStart','AgentSDKAdaptiveAnalysisJourneyStart',
    'AgentSDKChartAnalysisJourneyStart','AgentSDKPagedAnalysisJourneyStart','AgentSDKPlannedAnalysisJourneyStart','AgentSDKComparisonJourneyStart','AgentSDKOwnerInputJourneyStart','AgentSDKReviewJourneyStart','AgentSDKChildReadJourneyStart','AgentSDKReferenceChildReadJourneyStart','AgentSDKParallelChildReadJourneyStart','AgentSDKSourceChildReadJourneyStart','AgentSDKSourceChildReductionJourneyStart','AgentSDKParallelSourceChildReductionJourneyStart','AgentSDKSourceChildJoinJourneyStart','AgentSDKPagedSourceChildJoinJourneyStart']
for name in names:
    value=next(row['value'] for row in vectors if row['valid'] and row['contract']==name)
    assert start_contract(value)==name and probe.parse_start(json.dumps(value).encode())==value
    forged=dict(value,unexpectedGrant=True)
    try:probe.parse_start(json.dumps(forged).encode())
    except TransportError:pass
    else:raise AssertionError('Unreviewed start fields accepted')
try:probe.parse_start(b'{"schema":"unreviewed-journey/1"}')
except SDKModelPolicyError:pass
else:raise AssertionError('Unreviewed journey accepted')
assert 'agentic_os' not in sys.modules
print(json.dumps(dict(profiles=len(names),kernelRequired=False)))
"""
    env={key:value for key,value in os.environ.items() if key in {'PATH','HOME','TMPDIR','LANG','OPENAI_AGENTS_DISABLE_TRACING'}}
    result=subprocess.run([sys.executable,'-I','-B','-c',script],cwd=tmp_path,env=env,
        text=True,capture_output=True,check=True,timeout=20)
    assert json.loads(result.stdout)==dict(profiles=17,kernelRequired=False)


def test_planned_goal_and_amendment_instructions_use_closed_contracts():
    from agentic_os_agent_worker.read_journey import analysis_objective_instructions,planned_answer_instructions
    from jsonschema import Draft202012Validator
    instructions=analysis_objective_instructions([],[],charts=True,planned=True)
    schema=json.loads(instructions.split('Schema: ',1)[1].split('. Reviewed metadata: ',1)[0])
    Draft202012Validator.check_schema(schema)
    assert schema['$ref']=='#/$defs/AgentPlannedAnalysisGoalDraft'
    assert schema['$defs']['AgentAnalysisPlanNodeDraft']['additionalProperties'] is False
    assert '"kind":"plan-patch"' in planned_answer_instructions('a'*64,'{}','{}')


def test_actual_private_rpc_accepts_only_context_bound_planned_control_and_state():
    import asyncio
    import httpx
    from uuid import uuid4
    from agentic_os_agent_worker.model_rpc import RPCModelBoundary,ModelRPCError
    vectors=json.loads((Path(__file__).parents[3]/'tests/fixtures/contracts.json').read_bytes())
    def fixture(name):return deepcopy(next(row['value'] for row in vectors if row['valid'] and row['contract']==name))
    command=fixture('AgentReadOperationCommand');context=command['context']
    context['harness']['ref']='adaptive-analysis-planned/'+'a'*64
    state=dict(context=context,revision=2,goalDigest='b'*64,nodes=[],totalNodes=4)
    control=dict(profile='agent-planned-read-control/1',rootId=context['rootId'],taskId=context['taskId'],
        operationId=command['operationId'],state='plan-amended',goalDigest=state['goalDigest'],missingCriteria=[],
        planRevision=2,planStateJson=json.dumps(state))
    actions=[];wrong=False;completed=False
    terminal={key:value for key,value in control.items() if key not in {'planRevision','planStateJson'}}
    terminal.update(profile='agent-read-control/1',state='completed')
    async def token():return 'synthetic-workload-token'
    async def rpc(request):
        actions.append(request.url.path.rsplit('/',1)[1]);assert json.loads(request.content)==command
        value=deepcopy(state if actions[-1]=='plan-state' else terminal if completed else control)
        if wrong:value['context']=dict(context,rootId=str(uuid4()))
        return httpx.Response(200,json=value)
    async def run():
        nonlocal wrong,completed
        boundary=RPCModelBoundary('http://127.0.0.1:8123',token,local_synthetic=True,network_transport=httpx.MockTransport(rpc))
        boundary.transport_settings=command['transport']
        try:
            assert await boundary.complete_analysis(context,command['operationId'])==control
            assert await boundary.plan_state(context,command['operationId'])==state
            wrong=True
            with pytest.raises(ModelRPCError):await boundary.plan_state(context,command['operationId'])
            wrong=False;completed=True
            assert await boundary.complete_analysis(context,command['operationId'])==terminal
            terminal['state']='incomplete'
            with pytest.raises(ModelRPCError):await boundary.complete_analysis(context,command['operationId'])
        finally:await boundary.close()
    asyncio.run(run());assert actions==['complete-analysis','plan-state','plan-state','complete-analysis','complete-analysis']


def test_actual_sdk_refreshes_private_plan_instructions_after_tools_and_checkpoint_restore():
    import asyncio
    from uuid import uuid4
    from test_checkpoint import paused
    from agentic_os_agent_worker.read_journey import current_plan_instructions
    from agentic_os_agent_worker.checkpoint import restore_checkpoint
    seen=[];current_view=dict(marker='ready-after')
    def instructions(sequence,binding):
        class Boundary:
            async def plan_state(self,context,parent):
                assert context==binding['context'] and parent==sequence.snapshot()['parentOperationId']
                assert current_view['item']['executed']==[1]
                marker=current_view['marker']
                seen.append(marker)
                return dict(context=context,revision=sequence.snapshot()['planRevision'],goalDigest='b'*64,totalNodes=4,
                    nodes=[dict(id=str(uuid4()),kind='read',queryKey=marker,dependencies=[],dependencyScope='listed',
                        join='all-required',state='UNSTARTED',ready=True)])
        # An objective has no plan. The first SDK call is synthetic objective
        # setup; execution instructions begin after its accepted parent exists.
        async def current(context,agent):
            if sequence.snapshot()['parentOperationId'] is None:return 'Objective setup'
            return await current_plan_instructions(Boundary(),sequence,binding['context'],'b'*64,'{}')(context,agent)
        return current
    async def run():
        item=await paused(instructions_factory=instructions)
        current_view['item']=item
        try:
            agent=item['agent']();restored=await restore_checkpoint(agent,item['saved'],
                expected_context=item['binding']['context'],sdk_instance_id=item['binding']['sdkInstanceId'],
                capabilities=[item['pin']],sequence=item['sequence'])
            restored.state.approve(restored.state.get_interruptions()[0])
            result=await restored.run(item['provider'])
            assert result.final_output=='Checkpoint continued' and item['executed']==[1]
            assert seen==['ready-after'] and 'ready-after' in item['issued'][-1]['instructions']
            # Another actual system-prompt request observes current metadata,
            # rather than a string captured before the accepted tool result.
            seen.clear();current_view['marker']='next-window';await agent.get_system_prompt(None);assert seen==['next-window']
        finally:await item['transport'].close();await item['boundary'].close()
    asyncio.run(run())


@pytest.mark.parametrize('clarified',[False,True])
def test_actual_paged_journey_restores_pending_tool_then_rolls_completed_query_window(monkeypatch,clarified,immediate=False,reuse=False,denied=False):
    import asyncio
    from types import SimpleNamespace
    from agents import RunConfig
    from agents.models.interface import ModelProvider
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.temporal_driver import WorkflowBoundary
    from agentic_os_agent_worker.query_context import incomplete_query_window,SCOPED_FORMAT
    from agentic_os_agent_worker.sdk_model import SDKModelSequence
    from agentic_os_agent_worker.checkpoint import tool_alias
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    from test_parallel_children import Rollover,sample
    from test_sdk_tools import Boundary,ModelCalls,item_fixture
    from test_sdk_model import binding_fixture
    from test_tool_execution_rpc import accepted_for
    from uuid import UUID,uuid5
    value=sample('AgentSDKPagedAnalysisJourneyStart');_,_,binding=binding_fixture();item=item_fixture()
    context=deepcopy(binding['context']);binding.update(context=context,sdkInstanceId=str(uuid5(UUID(context['taskId']),'sdk-instance/1')))
    binding.update(parentOperationId=None,inputResults=[],turn=1)
    value['start'].update(context=context,capabilities=[item],checkpointId=None)
    goal=dict(queries=[dict(key='q',capability=item['capability'],providerRef='synthetic.current',argumentsJson='{"value":0.5}',
        cursorField='cursor',grain=['id'],pageGroupFields=[])])
    kernel=Boundary();sequence=SDKModelSequence(binding,dependency_boundary=kernel)
    value.update(phase='execution',binding=binding,goalDigest='a'*64,goalDraftJson=json.dumps(goal),
        continuationInputJson=json.dumps(incomplete_query_window(sequence,None,'a'*64,format=SCOPED_FORMAT)))
    value['providers']=[dict(capability=item['capability'],providerRef='synthetic.current')]
    value['discoveryCapabilities']=[item['capability']]
    if clarified:
        import hashlib
        value.update(schema='agent-clarified-analysis-journey/1',questionOperationId=str(uuid5(UUID(context['taskId']),'basis-question')),
            clarification=sample('AgentSDKClarifiedAnalysisJourneyStart')['clarification'])
        registered=dict(policy=value['clarification'],discovery=value['discoveryCapabilities'])
        context['harness']['ref']='clarified-paged-analysis/'+hashlib.sha256(
            b'agentic-os.hash/1\0manifest\0'+json.dumps(registered,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
        # Context objects embedded in the existing bounded window must match.
        binding['context']=context;value['binding']=binding
    expected='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,
        is_continue_as_new_suggested=lambda:not immediate,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda name:reuse and name=='same-execution-checkpoint-state/1')
    checkpoints={};carried=[];loaded=[]
    def rollover(next_value):carried.append(deepcopy(next_value));raise Rollover()
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    async def accepted(self,c,operation):return await kernel.accepted_model_operation(c,operation)
    async def get(self,c,ident):
        assert c==context;loaded.append(ident)
        return AgentPayloadConverter().from_payloads(AgentPayloadConverter().to_payloads([checkpoints[ident]]))[0]
    async def execute(self,request):
        kernel.requests.append(deepcopy(request))
        if denied:
            from temporalio.exceptions import ApplicationError
            from agentic_os_agent_worker.workflow_control import WorkflowControl,WAIT_TYPE
            raise ApplicationError('agent_wait',WorkflowControl(context['rootId'],context['taskId'],
                request['modelOperationId'],'scope-changed'),type=WAIT_TYPE,non_retryable=True)
        return accepted_for(request,query=True)
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',get)
    monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    model=ModelCalls(tool_alias(item['capability']),count=1)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    class Driver:
        stopped=False;pending_control=None
        def _expired(self):return False
        def _terminal(self,control):return control
        async def _save(self,boundary,ident,envelope):
            payload=AgentPayloadConverter().to_payloads([dict(checkpointId=ident,value=envelope)])[0]
            assert len(payload.SerializeToString(deterministic=True))<=65536
            checkpoints[ident]=AgentPayloadConverter().from_payloads([payload])[0]['value'];return dict(kind='ready')
    async def run():
        if denied:
            control=await read_journey.run_read_journey(Driver(),value)
            assert control.status=='scope-changed'
        else:
            with pytest.raises(Rollover):await read_journey.run_read_journey(Driver(),value)
        assert len(checkpoints)==1 and len(model.inputs)==1
        if not immediate:
            assert not kernel.requests
            with pytest.raises(Rollover):await read_journey.run_read_journey(Driver(),carried[0])
    asyncio.run(run())
    if denied:
        assert len(model.inputs)==len(kernel.requests)==len(checkpoints)==1 and not carried
        assert len(loaded)==(0 if reuse else 1)
        return
    assert len(model.inputs)==len(kernel.requests)==1 and len(carried)==(1 if immediate else 2)
    final=carried[-1]
    assert final['start']['context']==context and final['start']['checkpointId'] is None
    assert len(loaded)==(0 if immediate and reuse else 1)
    window=json.loads(json.loads(final['continuationInputJson'])[0]['content'])
    assert window['schema']==SCOPED_FORMAT and window['frontiers'][0]['queryKeys']==['q']
    assert window['frontiers'][0]['pageOrdinal']==0 and window['frontiers'][0]['nextCursor'] is None
    assert len(window['results'])==2 and final['binding']['inputResults']==window['results']


@pytest.mark.parametrize('reuse',[False,True])
@pytest.mark.parametrize('rollover',[False,True])
def test_actual_sdk_immediate_checkpoint_reuses_only_acknowledged_same_execution_state(monkeypatch,reuse,rollover):
    test_actual_paged_journey_restores_pending_tool_then_rolls_completed_query_window(
        monkeypatch,False,immediate=not rollover,reuse=reuse)


@pytest.mark.parametrize('reuse',[False,True])
def test_actual_sdk_immediate_checkpoint_keeps_current_tool_denial_before_another_model(monkeypatch,reuse):
    test_actual_paged_journey_restores_pending_tool_then_rolls_completed_query_window(
        monkeypatch,False,immediate=True,reuse=reuse,denied=True)


def test_actual_clarified_journey_keeps_discovery_and_causal_reply_across_owner_wait(monkeypatch):
    import asyncio,hashlib
    from types import SimpleNamespace
    from uuid import UUID,uuid4,uuid5
    from agents import RunConfig
    from agents.models.interface import ModelProvider
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.temporal_driver import WorkflowBoundary
    from agentic_os_agent_worker.checkpoint import tool_alias
    from test_parallel_children import Rollover,sample
    from test_sdk_tools import Boundary,ModelCalls,item_fixture
    from test_sdk_model import binding_fixture
    value=sample('AgentSDKClarifiedAnalysisJourneyStart');_,_,binding=binding_fixture();item=item_fixture();kernel=Boundary()
    context=deepcopy(binding['context']);original='Compare the selected property bills and clarify amount basis.'
    registered=dict(policy=value['clarification'],discovery=[item['capability']])
    context['harness']['ref']='clarified-paged-analysis/'+hashlib.sha256(b'agentic-os.hash/1\0manifest\0'+json.dumps(registered,
        sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    operation=str(uuid4());question=asyncio.run(kernel.accepted_model_operation(context,operation));reply=deepcopy(question)
    reply.update(resultId=str(uuid4()),producerStepId=str(uuid4()));reply['payload']['schemaRef']='AgentOwnerReply'
    prefix=[dict(role='user',content=original),dict(role='user',content=json.dumps(dict(schema='agent-owner-reply/1',inputKind='analysis-basis',text='allocated-net')))]
    previous=[dict(role='user',content=original),dict(type='function_call',name=tool_alias(item['capability']),call_id='prior',arguments='{"value":0.5}'),
        dict(type='function_call_output',call_id='prior',output='{"acceptedDiscovery":"current-property"}')]
    binding.update(context=context,parentOperationId=operation,inputResults=[question],turn=1,
        sdkInstanceId=str(uuid5(UUID(context['taskId']),'sdk-instance/1')))
    value['start'].update(context=context,input=original,capabilities=[item],checkpointId=None)
    value.update(phase='owner-input',questionOperationId=operation,binding=binding,goalDigest=None,goalDraftJson=None,
        continuationInputJson=json.dumps(previous),discoveryCapabilities=[item['capability']],providers=[dict(capability=item['capability'],providerRef='synthetic.current')])
    expected='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,is_continue_as_new_suggested=lambda:True,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda _:False)
    carried=[]
    def rollover(next_value):carried.append(deepcopy(next_value));raise Rollover()
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    async def owner(self,c,ident):
        assert c==context and ident==operation
        return dict(kind='answered',questionId=str(uuid4()),result=reply,inputJson=json.dumps(prefix))
    async def accepted(self,c,ident):return await kernel.accepted_model_operation(c,ident)
    monkeypatch.setattr(WorkflowBoundary,'owner_input',owner)
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    model=ModelCalls(tool_alias(item['capability']),count=1)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver
    class Driver(AgentTaskDriver):
        stopped=False;pending_control=None
        def _expired(self):return False
        async def _save(self,*args):return dict(kind='ready')
    async def run():
        with pytest.raises(Rollover):await Driver().run(value)
    asyncio.run(run())
    assert model.inputs[0][:2]==prefix and previous[-1] in model.inputs[0]
    assert reply in model.bindings[0]['inputResults'] and question in model.bindings[0]['inputResults']
    assert carried[0]['start']['context']==context and carried[0]['questionOperationId']==operation
    assert len(model.inputs)==1 and not kernel.requests


@pytest.mark.parametrize("relative_period",[False,True])
def test_clarified_question_retires_completed_discovery_checkpoint_before_reply(monkeypatch,relative_period,retained_objective=False):
    import asyncio,hashlib
    from types import SimpleNamespace
    from uuid import UUID,uuid4,uuid5
    from agents import RunConfig
    from agents.models.interface import ModelProvider
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    from agentic_os_agent_worker.checkpoint import tool_alias
    from test_parallel_children import Rollover,sample
    from test_sdk_tools import Boundary,ModelCalls,item_fixture
    from test_sdk_model import binding_fixture
    from test_tool_execution_rpc import accepted_for
    value=sample('AgentSDKPeriodClarifiedAnalysisJourneyStart' if relative_period else 'AgentSDKClarifiedAnalysisJourneyStart');_,_,binding=binding_fixture();item=item_fixture();kernel=Boundary()
    context=deepcopy(binding['context']);original='Clarify the amount basis after current discovery.'
    value['clarification']['choices'][0]['id']='allocated-net'
    value['clarification']['choices'][1]['id']='invoice-net'
    value['clarification']['choices'][1]['metric']['valueField']='invoiceNet'
    if relative_period:
        context.update(admittedAt='2026-10-20T12:00:00Z',timeZone='America/New_York')
        original='Clarify the amount basis after current discovery for the last six months.'
        value['clarification']['period'].update(startField='start',endField='end')
        value['clarification']['scopeFields']=[dict(field='start',label='Inclusive start'),dict(field='end',label='Inclusive end')]
        value['resolvedPeriod']=dict(schema='agent-relative-calendar-period/1',expression='last six months',months=6,
            mode='rolling-calendar-months-inclusive',referenceDate='2026-10-20',timeZone=context['timeZone'],start='2026-04-20',end='2026-10-20')
    registered=dict(policy=value['clarification'],discovery=[item['capability']])
    context['harness']['ref']='clarified-paged-analysis/'+hashlib.sha256(b'agentic-os.hash/1\0manifest\0'+json.dumps(registered,
        sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    if retained_objective:
        from agentic_os.production.retained_context_pins import profile_pin
        context['harness']=profile_pin('clarified',context['harness'])
    value['start'].update(context=context,input=original,capabilities=[item],checkpointId=None)
    value.update(phase='objective',questionOperationId=None,binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        discoveryCapabilities=[item['capability']],providers=[dict(capability=item['capability'],providerRef='synthetic.current')])
    expected='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,is_continue_as_new_suggested=lambda:True,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda _:False)
    carried=[];checkpoints={};reply=None;question=None;serialized_sizes=[]
    converter=AgentPayloadConverter()
    def wire(value):
        payload=converter.to_payloads([value])[0]
        serialized_sizes.append(len(payload.SerializeToString(deterministic=True)))
        assert serialized_sizes[-1]<=65536
        return converter.from_payloads([payload])[0]
    def rollover(next_value):carried.append(wire(next_value));raise Rollover()
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    accepted_models={}
    async def accepted(self,c,ident):
        if ident not in accepted_models:accepted_models[ident]=await kernel.accepted_model_operation(c,ident)
        return deepcopy(accepted_models[ident])
    async def execute(self,request):kernel.requests.append(deepcopy(request));return accepted_for(request,query=True)
    async def get(self,c,ident):return deepcopy(checkpoints[ident])
    async def owner(self,c,ident,bind=False):
        nonlocal reply,question
        if bind:
            question=await accepted(None,c,ident);reply=deepcopy(question)
            reply.update(resultId=str(uuid4()),producerStepId=str(uuid4()));reply['payload']['schemaRef']='AgentOwnerReply'
            return dict(kind='waiting',questionId=str(uuid4()))
        return dict(kind='answered',questionId=str(uuid4()),result=reply,inputJson=json.dumps([
            dict(role='user',content=original),dict(role='user',content=json.dumps(dict(schema='agent-owner-reply/1',inputKind='analysis-basis',text='allocated-net')))]))
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted);monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',get);monkeypatch.setattr(WorkflowBoundary,'owner_input',owner)
    async def goal(*args,**kwargs):raise Rollover()
    monkeypatch.setattr(read_journey,'complete_goal',goal)
    model=ModelCalls(tool_alias(item['capability']),count=1)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    class Driver(AgentTaskDriver):
        def _expired(self):return False
        async def _save(self,boundary,ident,envelope):
            stored=wire(dict(checkpointId=ident,value=envelope));checkpoints[ident]=stored['value'];return dict(kind='ready')
    async def run():
        with pytest.raises(Rollover):await Driver().run(value)
        assert carried[0]['start']['checkpointId'] in checkpoints
        with pytest.raises(Rollover):await Driver().run(carried[0])
        assert carried[1]['phase']=='owner-input' and carried[1]['start']['checkpointId'] is None
        assert len(kernel.requests)==1 and len(model.inputs)==2
        with pytest.raises(Rollover):await Driver().run(carried[1])
    asyncio.run(run())
    assert len(model.inputs)==3 and len(kernel.requests)==1
    assert json.loads(model.inputs[2][1]['content'])['text']=='allocated-net'
    assert any(item.get('type')=='function_call_output'for item in model.inputs[2])
    assert reply in model.bindings[2]['inputResults'] and question in model.bindings[2]['inputResults']
    assert len(serialized_sizes)==3
    if relative_period:
        assert all(item['resolvedPeriod']==value['resolvedPeriod']for item in carried)
        assert '2026-04-20' in read_journey.clarification_instructions(carried[1])
        assert '2026-10-20' in read_journey.clarification_instructions(carried[1])


def test_actual_extrema_entry_serializes_discovery_checkpoint_and_typed_goal_rollover(monkeypatch):
    import asyncio,importlib.util
    from types import SimpleNamespace
    from uuid import UUID,uuid5
    from agents import RunConfig
    from agents.models.interface import ModelProvider
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter,PlannedReadControl
    from agentic_os_agent_worker.checkpoint import tool_alias
    from test_parallel_children import Rollover,sample
    from test_sdk_tools import Boundary,ModelCalls
    from test_sdk_model import binding_fixture
    from test_tool_execution_rpc import accepted_for
    path=Path(__file__).parents[3]/'tests/integration/resources/analysis_fixture.py'
    spec=importlib.util.spec_from_file_location('extrema_sdk_fixture',path)
    goals=importlib.util.module_from_spec(spec);spec.loader.exec_module(goals)
    value=sample('AgentSDKExtremaComparisonJourneyStart');_,_,binding=binding_fixture();context=deepcopy(binding['context'])
    context['harness'].update(ref='adaptive-analysis-planned/'+'a'*64,revision=3)
    discovery=item_fixture();execution=deepcopy(discovery);execution['capability']['ref']='separate.query'
    value['start'].update(context=context,input='Compare early and late costs; show the lowest early total and exact late/base ratio.',
        capabilities=[discovery,execution],checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        discoveryCapabilities=[discovery['capability']],providers=[dict(capability=execution['capability'],providerRef='synthetic.read')],planStateJson=None)
    expected='os-agent:'+':'.join([context['subject']['installationId'],context['subject']['applicationId'],context['taskId']])
    monkeypatch.setattr(read_journey.workflow,'info',lambda:SimpleNamespace(workflow_id=expected,is_continue_as_new_suggested=lambda:True,get_current_history_length=lambda:1))
    monkeypatch.setattr(read_journey.workflow,'patched',lambda _:False)
    kernel=Boundary();checkpoints={};carried=[];sizes=[];accepted_models={};proposed=[]
    converter=AgentPayloadConverter()
    def wire(item):
        payload=converter.to_payloads([item])[0];sizes.append(len(payload.SerializeToString(deterministic=True)))
        assert sizes[-1]<=65536
        return converter.from_payloads([payload])[0]
    def rollover(next_value,**options):
        assert not options or options==dict(task_queue=expected+'/execution/1')
        carried.append(wire(next_value));raise Rollover()
    monkeypatch.setattr(read_journey.workflow,'continue_as_new',rollover)
    async def accepted(self,c,operation):
        if operation not in accepted_models:accepted_models[operation]=await kernel.accepted_model_operation(c,operation)
        return deepcopy(accepted_models[operation])
    async def execute(self,request):
        kernel.requests.append(deepcopy(request));result=accepted_for(request,query=True);page=json.loads(result['accepted']['payloadJson'])
        page.update(grain=['utilityId']);page['page']['records']=[[dict(name='utilityId',value='17')]]
        page['page']['evidence']['publicFields']=['utilityId'];page['coverage'].update(observedRows=1,expectedRows=1)
        result['accepted']['payloadJson']=json.dumps(page);return result
    async def get(self,c,ident):return deepcopy(checkpoints[ident])
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted);monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',get)
    async def complete(driver,boundary,c,operation,**flags):
        assert flags['analysis'] and flags['objective'] and c==context
        return PlannedReadControl(rootId=c['rootId'],taskId=c['taskId'],operationId=operation,state='goal-bound',
            goalDigest='b'*64,missingCriteria=[],planRevision=1,planStateJson='{}')
    monkeypatch.setattr(read_journey,'complete_goal',complete)
    class GoalModel(ModelCalls):
        async def get_response(self,system_instructions,input,*args,**kwargs):
            response=await super().get_response(system_instructions,input,*args,**kwargs)
            assert 'AgentExtremaComparisonGoalDraft' in system_instructions and '"minimum"' in system_instructions and '"ratio"' in system_instructions
            if len(self.inputs)>1:
                outputs=[json.loads(item['output'])for item in self.inputs[-1]if item.get('type')=='function_call_output']
                utility=int(outputs[0]['query']['page']['records'][0][0]['value'])
                document=goals.analysis_goal(dict(analysisProfile='warehouse-query/1',chartProfile=True,plannedProfile=True,
                    comparisonProfile=True,extremaComparisonProfile=True,capability=execution['capability'],resource=dict(providerRef='synthetic.read'),
                    queryGrain=['billId','lineId','allocationId','propertyId','currency'],queryPageGroups=['billId'],
                    argumentsJson=json.dumps(dict(utility_id=utility,start='2026-04-14',end='2026-10-14',cursor=None))))
                _validate('AgentExtremaComparisonGoalDraft',document);proposed.append(document)
                response.output[0].content[0].text=json.dumps(document)
            return response
    model=GoalModel(tool_alias(discovery['capability']),count=1)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    class Driver(AgentTaskDriver):
        def _expired(self):return False
        async def _save(self,boundary,ident,envelope):
            stored=wire(dict(checkpointId=ident,value=envelope));checkpoints[ident]=stored['value'];return dict(kind='ready')
    async def run():
        with pytest.raises(Rollover):await Driver().run(value)
        with pytest.raises(Rollover):await Driver().run(carried[0])
    asyncio.run(run())
    assert len(kernel.requests)==1 and len(model.inputs)==2 and len(sizes)==3
    final=carried[1];assert final['phase']=='execution' and final['planStateJson']=='{}' and final['start']['checkpointId'] is None
    assert json.loads(final['goalDraftJson'])==proposed[0]
    assert any(metric['ranking']=='minimum'for metric in proposed[0]['criteria'])
    assert proposed[0]['comparisons'][0]['operation']=='ratio' and all(json.loads(query['argumentsJson'])['utility_id']==17 for query in proposed[0]['queries'])


@pytest.mark.parametrize('repairable',[False,True,'bank','dependent','clarified'],ids=['legacy','repairable','bank','dependent','clarified'])
def test_actual_review_entry_serializes_preparation_checkpoint_and_hands_off_before_another_model(monkeypatch,repairable):
    import asyncio
    from types import SimpleNamespace
    from uuid import uuid4
    from temporalio import workflow
    from agents import RunConfig
    from agents.models.interface import ModelProvider
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.checkpoint import tool_alias
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    from test_parallel_children import Rollover,sample
    from test_sdk_tools import Boundary,ModelCalls
    from test_tool_execution_rpc import accepted_for
    value=sample('AgentSDKClarifiedReviewJourneyStart' if repairable=='clarified' else 'AgentSDKReviewJourneyStart');c=value['start']['context'];item=item_fixture()|dict(kind='propose')
    bank=repairable=='bank'
    dependent=repairable=='dependent'
    if dependent:
        schema=json.loads(item['inputSchemaJson']);schema['$comment']='agent-change-continuation/1'
        schema.setdefault('properties',{})['remainingRequest']={'type':['string','null']}
        item['inputSchemaJson']=json.dumps(schema)
    if repairable is True:c['harness']['ref']='agent-sdk-repairable-change/1'
    if repairable=='clarified':
        c['harness'].update(ref='agent-sdk-reviewed-change/1',revision=2);value['questionOperationId']=None
    question='Prepare this exact change for a separate owner review.'
    if bank:
        import importlib.util
        root=Path(__file__).parents[3]
        spec=importlib.util.spec_from_file_location('actual_review_provider',root/'tests/integration/resources/analysis_fixture.py')
        fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
        question=next(row['question'] for row in json.loads((root/'qualification/production-agent/fixtures/english-task-bank-v1.json').read_bytes())['cases'] if row['id']=='review-before-effect')
        selected=dict(resourceId='00007',expectedVersion='1',fields=[dict(name='note',value='Owner must decide'),dict(name='label',value=None)])
        item['description']=fixture.selected_review_metadata(selected)
        item['inputSchemaJson']=json.dumps(dict(type='object',additionalProperties=False,required=['resourceId','expectedVersion','fields'],properties=dict(
            resourceId=dict(type='string'),expectedVersion=dict(type='string'),fields=dict(type='array',items=dict(type='object',additionalProperties=False,
                required=['name','value'],properties=dict(name=dict(type='string'),value=dict(type=['string','null'])))))))
    schema=json.loads(item['inputSchemaJson']);mapping_note='Reviewed mapping: a new target uses its containing identity; updates require the actual existing target identity.'
    schema['description']=mapping_note;item['inputSchemaJson']=json.dumps(schema)
    value['start'].update(input=question,capabilities=[item],checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        reviewId=None,preparation=None,providers=[dict(capability=item['capability'],providerRef='synthetic/preparation')])
    _validate('AgentSDKClarifiedReviewJourneyStart' if repairable=='clarified' else 'AgentSDKReviewJourneyStart',value)
    expected='os-agent:'+':'.join([c['subject']['installationId'],c['subject']['applicationId'],c['taskId']])
    monkeypatch.setattr(workflow,'info',lambda:SimpleNamespace(workflow_id=expected,
        is_continue_as_new_suggested=lambda:False,get_current_history_length=lambda:1))
    monkeypatch.setattr(workflow,'patched',lambda _:False)
    converter=AgentPayloadConverter();checkpoints={};carried=[];executed=[];models={};kernel=Boundary();reviewed=[]
    def wire(v):return converter.from_payloads(converter.to_payloads([v]))[0]
    def rollover(v,**options):
        assert options==dict(task_queue=expected+'/execution/1');carried.append(wire(v));raise Rollover()
    monkeypatch.setattr(workflow,'continue_as_new',rollover)
    async def accepted(self,context,operation):
        if operation not in models:models[operation]=await kernel.accepted_model_operation(context,operation)
        return deepcopy(models[operation])
    async def execute(self,request):
        if bank:assert json.loads(request['argumentsJson'])==selected
        result=accepted_for(request);result['accepted']['result'].update(**{k:c[k] for k in ('subject','taskId','rootId')})
        result['accepted']['payloadJson']=json.dumps(sample('AgentPreparedChange'),separators=(',',':'))
        result['accepted']['result']['payload'].update(schemaRef='AgentPreparedChange',bytes=len(result['accepted']['payloadJson'].encode()))
        executed.append(deepcopy(result));return result
    async def checkpoint(self,context,ident):return deepcopy(checkpoints[ident])
    async def review(self,context,operation,preparation=None):
        assert context==c and operation in models and len(executed)==1 and preparation==executed[0]['accepted']['result']
        reviewed.append(operation);return wire(dict(context=c,reviewId=str(uuid4()),kind='waiting',receipt=None))
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',checkpoint)
    monkeypatch.setattr(WorkflowBoundary,'review',review)
    class Once(ModelCalls):
        async def get_response(self,system_instructions,input,*args,**options):
            assert not self.inputs,'Review preparation must not enter another model'
            assert 'Calling the offered preparation tool produces the actual editable form' in system_instructions
            assert 'declared collection version or other literal sentinel must be copied verbatim' in system_instructions
            assert 'If the schema requires a decimal revision string' in system_instructions
            schema=options['output_schema']
            if repairable=='clarified':
                assert schema.name()=='AgentChangeQuestionDraft' and schema.is_strict_json_schema()
                from agents.exceptions import ModelBehaviorError
                with pytest.raises(ModelBehaviorError):schema.validate_json('This prose is not an editable form.')
                with pytest.raises(ModelBehaviorError):schema.validate_json('{"kind":"proposal","safeMessage":"Approve it"}')
            else:assert schema is None  # Exact legacy/repairable profile behavior.
            tools=options.get('tools',args[1] if len(args)>1 else None)
            assert len(tools)==1 and tools[0].params_json_schema==json.loads(item['inputSchemaJson'])
            assert tools[0].description==(item['description']+'\nDeclared preparation mapping: '+mapping_note if repairable=='clarified' else item['description'])
            assert 'Never invent an update target or supply a null target ID' in system_instructions
            assert 'Do not ask the owner to choose between their explicit mapped value and a registered default' in system_instructions
            assert 'another request for permission to prepare' in system_instructions
            assert 'detail read to verify that entity and its version directly' in system_instructions
            assert 'registered tool contract requires' in system_instructions
            assert ('An identifier produced by that first effect is a dependency' in system_instructions)==dependent
            if dependent:
                assert 'new user Send, fresh current authorization and separate trusted confirmation' in system_instructions
                assert 'draft work is complete' in system_instructions
            if bank:
                from test_property_composition import calls
                self.inputs.append(deepcopy(input));tools=options.get('tools',args[1] if len(args)>1 else None)
                output=fixture.reviewed_change_step(value,dict(input=input,instructions=system_instructions,tools=[dict(name=tool.name) for tool in tools]))
                return calls(*[(row['name'],row['call_id'],json.loads(row['arguments'])) for row in output])
            return await super().get_response(system_instructions,input,*args,**options)
    model=Once(tool_alias(item['capability']),count=1)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    class Driver(AgentTaskDriver):
        def _expired(self):return False
        async def _save(self,boundary,ident,envelope):
            checkpoints[ident]=wire(envelope);return dict(kind='ready')
    async def run():
        with pytest.raises(Rollover):await Driver().run(wire(value))
    asyncio.run(run())
    assert len(model.inputs)==len(executed)==len(reviewed)==len(carried)==1 and checkpoints
    result=carried[0];_validate('AgentSDKClarifiedReviewJourneyStart' if repairable=='clarified' else 'AgentSDKReviewJourneyStart',result)
    assert result['phase']=='review' and result['preparation']==executed[0]['accepted']['result']
    assert result['start']['checkpointId'] is None and result['start']['input']==value['start']['input']


@pytest.mark.parametrize("relative_period",[False,True])
def test_retained_clarification_entry_keeps_exact_serialized_discovery_reply_and_period(monkeypatch,relative_period):
    test_clarified_question_retires_completed_discovery_checkpoint_before_reply(monkeypatch,relative_period,retained_objective=True)



@pytest.mark.parametrize('boundary_kind',['temporal','direct-rpc'])
@pytest.mark.parametrize('malformed_preparation',[False,True,'duplicate','syntax'])
def test_review_clarification_keeps_original_root_and_causal_reply_before_typed_preparation(monkeypatch,boundary_kind,malformed_preparation):
    import asyncio
    from types import SimpleNamespace
    from uuid import uuid4
    from temporalio import workflow
    from agents import RunConfig
    from agents.models.interface import ModelProvider
    from agents.items import ModelResponse
    from agents.usage import Usage
    from openai.types.responses import ResponseFunctionToolCall,ResponseOutputMessage,ResponseOutputText
    from agentic_os_agent_worker import read_journey
    from agentic_os_agent_worker.checkpoint import tool_alias
    from agentic_os_agent_worker.temporal_driver import AgentTaskDriver,WorkflowBoundary
    from agentic_os_agent_worker.workflow_control import AgentPayloadConverter
    from test_parallel_children import Rollover,sample
    from test_sdk_tools import Boundary,ModelCalls
    from test_tool_execution_rpc import accepted_for
    value=sample('AgentSDKClarifiedReviewJourneyStart');c=value['start']['context'];c['harness'].update(ref='agent-sdk-reviewed-change/1',revision=2)
    item=item_fixture()|dict(kind='propose');original='Create a new synthetic place and notify the selected member.'
    value['start'].update(input=original,capabilities=[item],checkpointId=None)
    value.update(phase='objective',binding=None,goalDigest=None,goalDraftJson=None,continuationInputJson=None,
        reviewId=None,preparation=None,questionOperationId=None,providers=[dict(capability=item['capability'],providerRef='synthetic/preparation')])
    _validate('AgentSDKClarifiedReviewJourneyStart',value)
    expected='os-agent:'+':'.join([c['subject']['installationId'],c['subject']['applicationId'],c['taskId']])
    monkeypatch.setattr(workflow,'info',lambda:SimpleNamespace(workflow_id=expected,is_continue_as_new_suggested=lambda:False,get_current_history_length=lambda:1))
    monkeypatch.setattr(workflow,'patched',lambda name:name=='reviewed-tool-argument-feedback/1')
    converter=AgentPayloadConverter();carried=[];executed=[];models={};checkpoints={};kernel=Boundary();reviewed=[];question_id=str(uuid4())
    reply_text='Use the synthetic coordinates and name I supplied; show editable settings.'
    def wire(v):return converter.from_payloads(converter.to_payloads([v]))[0]
    def rollover(v,**options):
        assert options==(dict(task_queue=expected+'/execution/1') if v['phase']=='review' else {})
        carried.append(wire(v));raise Rollover()
    monkeypatch.setattr(workflow,'continue_as_new',rollover)
    async def accepted(self,context,operation):
        if operation not in models:models[operation]=await kernel.accepted_model_operation(context,operation)
        return deepcopy(models[operation])
    async def owner(self,context,operation,bind=False):
        assert context==c and operation in models
        if bind:return dict(kind='waiting',questionId=question_id)
        reply=deepcopy(models[operation]);reply.update(resultId=str(uuid4()),producerStepId=str(uuid4()))
        reply['payload']['schemaRef']='AgentOwnerReply'
        prefix=[dict(role='user',content=original),dict(role='user',content=json.dumps(dict(schema='agent-owner-reply/1',inputKind='change-details',text=reply_text)))]
        return dict(kind='answered',questionId=question_id,result=reply,inputJson=json.dumps(prefix))
    async def execute(self,request):
        result=accepted_for(request);result['accepted']['result'].update(**{k:c[k] for k in ('subject','taskId','rootId')})
        result['accepted']['payloadJson']=json.dumps(sample('AgentPreparedChange'),separators=(',',':'))
        result['accepted']['result']['payload'].update(schemaRef='AgentPreparedChange',bytes=len(result['accepted']['payloadJson'].encode()))
        executed.append(result);return result
    async def review(self,context,operation,preparation=None):
        assert context==c and operation in models and len(executed)==1 and preparation==executed[0]['accepted']['result']
        reviewed.append(operation);return wire(dict(context=c,reviewId=str(uuid4()),kind='waiting',receipt=None))
    async def get_checkpoint(self,context,ident):return deepcopy(checkpoints[ident])
    monkeypatch.setattr(WorkflowBoundary,'get_checkpoint',get_checkpoint)
    monkeypatch.setattr(WorkflowBoundary,'accepted_model_operation',accepted)
    monkeypatch.setattr(WorkflowBoundary,'owner_input',owner)
    monkeypatch.setattr(WorkflowBoundary,'execute_tool',execute)
    monkeypatch.setattr(WorkflowBoundary,'review',review)
    class Model(ModelCalls):
        async def get_response(self,system_instructions,input,*args,**options):
            self.inputs.append(deepcopy(input));assert len(self.inputs)<=2+int(bool(malformed_preparation))
            if len(self.inputs)==1:
                assert 'change-details' in system_instructions
                text=json.dumps(dict(kind='owner-input',inputKind='change-details',safeMessage='Which exact coordinates and name should I use?'))
                assert options['output_schema'].name()=='AgentChangeQuestionDraft' and options['output_schema'].validate_json(text)==text
                output=[ResponseOutputMessage(type='message',id='question',role='assistant',status='completed',content=[ResponseOutputText(type='output_text',text=text,annotations=[])])]
            else:
                assert input[0]['content']==original
                assert any(row.get('role')=='user' and 'agent-owner-reply/1' in str(row.get('content')) and json.loads(row['content'])['text']==reply_text for row in input)
                assert any(row.get('role')=='assistant' for row in input[1:-1])
                from agentic_os_agent_worker.sdk_model import serialized_response_input
                assert serialized_response_input(json.loads(json.dumps(input)))==input
                bad=malformed_preparation and len(self.inputs)==2
                if len(self.inputs)==3:
                    failures=[json.loads(row['output']) for row in input if row.get('type')=='function_call_output']
                    assert not executed
                    if malformed_preparation in {'duplicate','syntax'}:
                        expected_error=dict(code='duplicate-property',property='value') if malformed_preparation=='duplicate' else dict(code='malformed-json',property=None)
                        assert any(row.get('validationError')==expected_error
                            and 'No tool executed' in row.get('correction','') for row in failures)
                        assert 'Do not ask the owner to repeat known details' in system_instructions
                    else:assert dict(kind='tool-error',failure='invalid-input',validation='local-schema') in failures
                arguments=('{"value":0.5,"value":0.5}' if malformed_preparation=='duplicate' else
                    '{"value":0.5} trailing invalid JSON' if malformed_preparation=='syntax' else
                    '{"value":0.5,"resourceType":"saved-locations"}') if bad else '{"value":0.5}'
                output=[ResponseFunctionToolCall(type='function_call',name=self.name,arguments=arguments,call_id='prepare_after_reply_'+str(len(self.inputs)),id='fc_prepare_'+str(len(self.inputs)))]
            return ModelResponse(output=output,usage=Usage(requests=1),response_id='response_'+str(len(self.inputs)))
    model=Model(tool_alias(item['capability']),count=1)
    class Provider(ModelProvider):
        def get_model(self,name):return model
    monkeypatch.setattr(read_journey,'RunConfig',lambda **options:RunConfig(**options,model_provider=Provider()))
    class Driver(AgentTaskDriver):
        def _expired(self):return False
        async def _save(self,boundary,ident,envelope):
            checkpoints[ident]=wire(envelope);return dict(kind='ready')
    owner_rpc_calls=[]
    class RPC:
        async def accepted_model_operation(self,context,operation):return await accepted(self,context,operation)
        async def owner_input(self,context,operation,bind=False):
            owner_rpc_calls.append((wire(context),operation,bind))
            return wire(await owner(self,context,operation,bind))
        async def execute_tool(self,request):return await execute(self,request)
        async def review(self,context,operation,review_id,preparation):return await review(self,context,operation,preparation)
        async def get_checkpoint(self,context,ident):return await get_checkpoint(self,context,ident)
    def driver():
        current=Driver()
        if boundary_kind=='direct-rpc':
            from agentic_os_agent_worker.direct_driver import DirectReadBoundary
            current.tool_calls=0
            current.boundary_factory=lambda timeout:DirectReadBoundary(RPC(),current)
        return current
    async def run():
        with pytest.raises(Rollover):await driver().run(wire(value))
        assert not executed and not reviewed
        assert carried[0]['phase']=='owner-input' and carried[0]['start']['checkpointId'] is None
        with pytest.raises(Rollover):await driver().run(carried[0])
    asyncio.run(run())
    assert len(model.inputs)==2+int(bool(malformed_preparation)) and len(carried)==2 and len(executed)==len(reviewed)==1
    assert json.loads(executed[0]['accepted']['binding']['argumentsJson'])=={'value':0.5}
    assert carried[0]['phase']=='owner-input' and carried[1]['phase']=='review'
    assert all(v['start']['context']==c and v['start']['input']==original for v in carried)
    assert all(v['start']['checkpointId'] is None for v in carried)
    assert carried[1]['questionOperationId']==carried[0]['questionOperationId']
    if boundary_kind=='direct-rpc':
        assert [call[2] for call in owner_rpc_calls]==[True,False]
        assert all(call[0]==c and call[1]==carried[0]['questionOperationId'] for call in owner_rpc_calls)
