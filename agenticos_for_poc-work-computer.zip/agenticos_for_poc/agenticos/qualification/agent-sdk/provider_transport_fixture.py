"""Synthetic wire and private-boundary probes, not a SQL admission implementation."""
from datetime import datetime,timedelta,timezone
import hashlib,json
from uuid import UUID

from agentic_os_agent_worker.transport import TransportConfig


def pin(ref,digest='a'*64):return dict(ref=ref,revision=1,digest=digest)
def ident(n):return str(UUID(int=n))


def privacy_configuration(config,*,change=None):
    """Explicit synthetic account-policy references, not real account evidence."""
    from dataclasses import replace
    profile=json.loads(config.model_profile_json)
    value=dict(retention=dict(id=profile['retention']['ref'],revision=profile['retention']['revision'],
        provider=config.provider,credentialRef=config.credential_ref,mode='provider-account-managed',
        requestStorage='disabled' if config.provider=='openai' else 'provider-account-managed',
        accountPolicyRef='synthetic-reviewed-account-controls'),
        residency=dict(id=profile['residency']['ref'],revision=profile['residency']['revision'],
        provider=config.provider,endpointRef=config.endpoint_ref,baseUrl=config.base_url,placement='global',inferenceGeo=None))
    if change is not None:change(value)
    def fingerprint(document):
        return hashlib.sha256(b'agentic-os.hash/1\0manifest\0'+json.dumps(document,sort_keys=True,
            ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    for name,document in value.items():
        profile[name]=dict(ref=document['id'],revision=document['revision'],digest=fingerprint(document))
    return replace(config,model_profile_digest=fingerprint(profile),model_profile_json=json.dumps(profile),
        privacy_configuration_json=json.dumps(value))


def fixture(provider):
    model_id='gpt-5.4-mini-2026-03-17' if provider=='openai' else 'claude-haiku-4-5-20251001'
    profile=dict(id='synthetic-'+provider,revision=1,provider=provider,
        api='responses' if provider=='openai' else 'messages',modelId=model_id,modelRevision='synthetic-snapshot',
        floatingAliasAllowed=False,endpointRef='synthetic-endpoint',credentialRef='synthetic-secret',
        pricing=pin('synthetic-prices'),retention=pin('synthetic-retention'),residency=pin('synthetic-residency'),
        hostedToolPolicyRef=None,lifecycle='qualified')
    fingerprint=hashlib.sha256(b'agentic-os.hash/1\0manifest\0'+json.dumps(profile,sort_keys=True,
        ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    config=TransportConfig(provider=provider,model_id=model_id,model_profile_digest=fingerprint,
        model_profile_json=json.dumps(profile),endpoint_ref=profile['endpointRef'],credential_ref=profile['credentialRef'],
        base_url='https://api.openai.com/v1' if provider=='openai' else 'https://api.anthropic.com',
        request_timeout_ms=10000,max_request_bytes=65536,max_response_bytes=65536)
    now=datetime.now(timezone.utc)
    context=dict(subject=dict(installationId=ident(1),applicationId=ident(2),tenantId='synthetic',subjectId='owner'),
        taskId=ident(3),conversationId=ident(4),segmentId=ident(5),purpose='synthetic-read',definition=pin('definition'),
        profile=pin('profile'),harness=pin('harness'),model=pin(profile['id'],fingerprint),resourcePolicy=pin('policy'),
        authorityRef='synthetic-authority',scopeRef='synthetic-scope',delegationRef=None,rootId=ident(6),
        accountingFormat='agent-resources/1',intentRevision=1,controlEpoch=1,
        admittedAt=(now-timedelta(seconds=5)).isoformat(),authorizationHorizon=(now+timedelta(minutes=5)).isoformat(),timeZone='UTC')
    step=dict(taskId=ident(3),rootId=ident(6),segmentId=ident(5),stepId=ident(7),parentStepId=None,
        intentRevision=1,controlEpoch=1,inputDigest='b'*64,kind='model')
    payload=dict(artifactRef='private-synthetic-input',ciphertextDigest='c'*64,bytes=100,schemaRef='provider-input',schemaVersion=1)
    vector=dict(tokens=2000,costMicros=10000,workMs=10000,computeMs=0,storageBytes=100000)
    grant={k:context[k] for k in ('subject','taskId','rootId','segmentId','intentRevision','controlEpoch','accountingFormat')}
    grant.update(stepId=step['stepId'],attemptId=ident(8),leaseToken=ident(9),inputDigest=step['inputDigest'],
        input=payload,reserved=vector,expiresAt=(now+timedelta(seconds=10)).isoformat())
    request=dict(context=context,step=step,grant=grant,input=payload,maxOutputTokens=64,requestTimeoutMs=10000)
    if provider=='openai':
        body=dict(input=[dict(role='user',content='Synthetic private request')])
        response=dict(id='resp_synthetic',object='response',model=model_id,status='completed',error=None,service_tier='default',
            output=[dict(type='message',id='msg_synthetic',role='assistant',status='completed',content=[dict(type='output_text',text='Synthetic result',annotations=[])])],
            usage=dict(input_tokens=100,input_tokens_details=dict(cached_tokens=20),output_tokens=10,
                output_tokens_details=dict(reasoning_tokens=4),total_tokens=110))
    else:
        body=dict(messages=[dict(role='user',content='Synthetic private request')])
        response=dict(id='msg_synthetic',type='message',role='assistant',model=model_id,stop_reason='end_turn',stop_sequence=None,
            content=[dict(type='text',text='Synthetic result')],usage=dict(input_tokens=80,output_tokens=10,
                cache_creation_input_tokens=12,cache_read_input_tokens=20,cache_creation=dict(ephemeral_5m_input_tokens=4,ephemeral_1h_input_tokens=5),
                service_tier='standard',inference_geo=None))
    return config,request,body,response


class Boundary:
    def __init__(self,body):self.body=json.dumps(body);self.events=[];self.records=[];self.outstanding=2000;self.denied=False
    async def begin_model(self,request):
        if self.denied:raise PermissionError('synthetic-denied')
        self.events.append('begun');return self.body
    async def finish_model(self,request,**record):
        self.records.append(record);u=record['usage'];unknown=u is None
        if not unknown:self.outstanding=0
        self.events.append('unknown' if unknown else 'settled')
        measured=dict(tokens=0 if unknown else sum(u[k] for k in ('uncachedInputTokens','cachedInputTokens',
            'cacheWrite5mTokens','cacheWrite1hTokens','cacheWriteUnspecifiedTokens','outputTokens')),
            costMicros=0,workMs=record['work_ms'],computeMs=0,storageBytes=0)
        return dict(operation=dict(attemptId=request['grant']['attemptId'],state='unknown' if unknown else
            'failed' if record['failure'] else 'succeeded',candidate=None,
            usage=dict(measured=measured,completeness='unknown' if unknown else 'known',providerUsageRef='private-proof'),
            receiptRef=None,failure=record['failure']),providerRequestId=record['request_id'],
            providerResponseId=record['response_id'],model=request['context']['model'])
