# Agent SDK engineering qualification

This independently locked environment tests actual SDK control flow before a
production harness is selected. It is not an enabled runtime or an API/release
qualification. Deterministic model replies are injected through supported SDK
interfaces; the SDK itself chooses and executes the control flow.

The existing product pins MCP 2.2.0. Temporal 1.34.0's Agent integration requires
MCP below 2 and Agents SDK 0.19.x. Do not merge this environment into the product
environment, force dependency resolution, downgrade the existing MCP profile,
or install with `--no-deps`. A production packaging decision requires the full
compatibility proof, including durable service recovery and resource governance.
The candidate now installs the separately packaged worker from its maintained
path dependency under the frozen lock; both projects are included in the source
evidence. It does not import worker code through an ad hoc source path.

Run with the maintained product interpreter:

```text
python tools/qualify_agent_sdk.py --root /absolute/owned/external/directory
```

Keep this root separate from every installed runtime SDK environment. The runner
refuses a root whose `environment/agentic-os-runtime-sdk-role.json` marker reserves
it for a runtime, before creating evidence or synchronizing dependencies. Runtime
installation tooling maintains that marker; qualification must not remove it.

The runner admits capacity with the unchanged 20 GiB floor, creates a fresh
private evidence directory, uses the frozen lock and external cache/environment,
and strips inherited provider/database credentials from the test subprocess.
It records exact source/lock identities and failed results without promoting
G10 or API acceptance. No Host database is accessed. Live API qualification is
separate and requires server-side credentials and an authorized spending ceiling.

Use repeated `--case tests/test_file.py::test_name` selections to resume affected
or unfinished cases. `--test-timeout-seconds` bounds that selected subprocess.
The fsynced completion journal credits only cases whose teardown completed;
a later timeout remains a failed aggregate and cannot create a passing milestone.
