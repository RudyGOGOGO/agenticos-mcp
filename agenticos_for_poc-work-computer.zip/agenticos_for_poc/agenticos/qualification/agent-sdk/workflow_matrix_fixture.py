"""SDK control-flow probes using public Temporal and Agent SDK interfaces."""
from datetime import timedelta
import json
from temporalio import activity, workflow
from temporalio.common import RetryPolicy

with workflow.unsafe.imports_passed_through():
    from agents import Agent, RunConfig, Runner, RunContextWrapper, function_tool
    from agents.tool_context import ToolContext
    from temporalio.contrib.openai_agents.workflow import activity_as_tool


@activity.defn
async def matrix_branch(context: RunContextWrapper[dict], key: str) -> str:
    """Read an independent synthetic branch using copied trusted context."""
    context.context["touches"] += 1
    return json.dumps({"key": key, "amount": 4 if key == "a" else 9})


@activity.defn
async def matrix_step(previous: int) -> str:
    """Advance a dependent synthetic child result."""
    return json.dumps(previous + 1)


@activity.defn
async def matrix_dispatch(envelope: dict) -> str:
    """Execute a minimal governed envelope, never a raw SDK runtime context."""
    assert set(envelope) == {"root", "toolCallId", "key", "touches"}
    envelope["touches"] += 1
    return json.dumps({"key": envelope["key"], "amount": 4 if envelope["key"] == "a" else 9})


@function_tool(name_override="matrix_branch", failure_error_function=None)
async def governed_branch(context: ToolContext[dict], key: str) -> str:
    """Read through a durable boundary with stable SDK call identity."""
    envelope = {"root": context.context["root"], "toolCallId": context.tool_call_id,
                "key": key, "touches": context.context["touches"]}
    return await workflow.execute_activity(matrix_dispatch, envelope,
        start_to_close_timeout=timedelta(seconds=10), heartbeat_timeout=timedelta(seconds=2),
        retry_policy=RetryPolicy(maximum_attempts=1),
        cancellation_type=workflow.ActivityCancellationType.TRY_CANCEL)


def durable_tool(fn):
    return activity_as_tool(fn, start_to_close_timeout=timedelta(seconds=10),
        heartbeat_timeout=timedelta(seconds=2), retry_policy=RetryPolicy(maximum_attempts=1),
        cancellation_type=workflow.ActivityCancellationType.WAIT_CANCELLATION_COMPLETED)


@workflow.defn(name="SDKCompatibilityMatrix/1")
class SDKCompatibilityMatrix:
    @workflow.run
    async def run(self, scenario: str) -> dict:
        context = {"root": "fixture-original-root", "touches": 0}
        agent = Agent(name="Matrix candidate", model="matrix-" + scenario,
                      tools=[governed_branch])
        result = await Runner.run(agent, "Synthetic matrix request", context=context,
            max_turns=None, run_config=RunConfig(tracing_disabled=True))
        return {"answer": result.final_output, "touches": context["touches"]}


@workflow.defn(name="SDKCompatibilityChild/1")
class SDKCompatibilityChild:
    @workflow.run
    async def run(self, trusted_context: dict) -> str:
        agent = Agent(name="Child candidate", model="matrix-child", tools=[durable_tool(matrix_step)])
        result = await Runner.run(agent, "Synthetic child request", context=trusted_context,
            max_turns=None, run_config=RunConfig(tracing_disabled=True))
        return result.final_output


@workflow.defn(name="SDKCompatibilityParent/1")
class SDKCompatibilityParent:
    @workflow.run
    async def run(self) -> str:
        @function_tool(failure_error_function=None)
        async def delegate(context: RunContextWrapper[dict], request: str) -> str:
            """Run a declared specialist under the same original authority root."""
            parts = workflow.info().workflow_id.split(":")
            child_id = ":".join(parts[:3] + [str(workflow.uuid4())])
            return await workflow.execute_child_workflow(SDKCompatibilityChild.run,
                context.context, id=child_id, retry_policy=RetryPolicy(maximum_attempts=1))

        agent = Agent(name="Parent candidate", model="matrix-parent", tools=[delegate])
        result = await Runner.run(agent, "Synthetic parent request",
            context={"root": "fixture-original-root"}, max_turns=None,
            run_config=RunConfig(tracing_disabled=True))
        return result.final_output
