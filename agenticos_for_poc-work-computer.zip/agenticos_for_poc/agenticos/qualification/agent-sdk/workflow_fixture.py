"""Candidate workflow: real SDK orchestration and separately durable tool work."""
from datetime import timedelta
from dataclasses import replace
import json

from temporalio import activity, workflow
from temporalio.common import RetryPolicy

with workflow.unsafe.imports_passed_through():
    from agents import Agent, RunConfig, Runner, RunState
    from temporalio.contrib.openai_agents.workflow import activity_as_tool
    from agentic_os_agent_worker.temporal_driver import WorkflowBoundary


@activity.defn
async def durable_advance(previous: int) -> str:
    """Advance a synthetic chain in a separately scheduled Activity."""
    return json.dumps(previous + 1)


@workflow.defn(name="SDKCompatibilityChain/1")
class SDKCompatibilityChain:
    def __init__(self):
        self.ready = False
        self.released = False

    @workflow.run
    async def run(self) -> str:
        tool = activity_as_tool(durable_advance, start_to_close_timeout=timedelta(seconds=10),
                                retry_policy=RetryPolicy(maximum_attempts=1))
        agent = Agent(name="Durable candidate", model="sdk-offline-proof", tools=[tool])
        result = await Runner.run(agent, "sdk-private-marker", max_turns=None,
                                  run_config=RunConfig(tracing_disabled=True))
        self.ready = True
        await workflow.wait_condition(lambda: self.released)
        return result.final_output

    @workflow.query
    def is_ready(self) -> bool:
        return self.ready

    @workflow.signal
    def release(self):
        self.released = True


@workflow.defn(name="SDKCompatibilityCheckpointChain/1")
class SDKCompatibilityCheckpointChain:
    @workflow.run
    async def run(self, saved: dict | None = None) -> str:
        tool = activity_as_tool(durable_advance, start_to_close_timeout=timedelta(seconds=10),
                                retry_policy=RetryPolicy(maximum_attempts=1))
        # This is an internal read checkpoint, not owner approval for an effect.
        # Production use must re-enter its current-authority execution facade.
        tool = replace(tool, needs_approval=True)
        agent = Agent(name="Checkpoint candidate", model="sdk-offline-proof", tools=[tool])
        initial = "sdk-private-marker"
        if saved is not None:
            initial = await RunState.from_json(agent, saved, strict_context=True)
            for interruption in initial.get_interruptions():
                initial.approve(interruption)
        # Public model override makes the integration wrap the restored agent's
        # model too. Never hydrate a saved SDK state into a direct API model.
        result = await Runner.run(agent, initial, max_turns=None,
            run_config=RunConfig(model="sdk-offline-proof", tracing_disabled=True))
        if result.interruptions:
            workflow.continue_as_new(result.to_state().to_json(strict_context=True))
        return result.final_output


@activity.defn(name="private_checkpoint_echo")
async def private_checkpoint_echo(value: dict) -> dict:
    return value


@workflow.defn(name="SDKPrivateHistoryCheckpoint/1")
class SDKPrivateHistoryCheckpoint:
    def __init__(self):
        self.ready=False
        self.released=False

    @workflow.run
    async def run(self,value:dict) -> dict:
        result=await workflow.execute_activity(private_checkpoint_echo,value,
            start_to_close_timeout=timedelta(seconds=10),retry_policy=RetryPolicy(maximum_attempts=1))
        self.ready=True
        await workflow.wait_condition(lambda:self.released)
        return result

    @workflow.query
    def is_ready(self) -> bool:
        return self.ready

    @workflow.signal
    def release(self):
        self.released=True


@workflow.defn(name="SDKProtocolMetadataCheckpoint/1")
class SDKProtocolMetadataCheckpoint(SDKPrivateHistoryCheckpoint):
    @workflow.run
    async def run(self,value:dict) -> dict:
        boundary=WorkflowBoundary(10000)
        reference=await boundary.accepted_model_operation(value['context'],value['operationId'])
        if 'checkpoint' in value:
            await boundary.put_checkpoint(value['checkpointId'],value['checkpoint'])
        saved=await boundary.get_checkpoint(value['context'],value['checkpointId'])
        self.ready=True
        await workflow.wait_condition(lambda:self.released)
        return dict(reference=reference,saved=saved)
