"""SDK extension-point probe, not the production accounting implementation.

The authority supplied by tests is an in-memory observation fixture. Actual
original-root SQL reservation/UNKNOWN integrity remains a separate PA03 gate.
"""
import asyncio
from agents import Model


class ProbeModelUnavailable(RuntimeError):
    def __init__(self):
        super().__init__("model_work_unavailable")


class AdmissionProbeModel(Model):
    def __init__(self, inner, authority):
        self.inner, self.authority = inner, authority

    async def get_response(self, *args, **kwargs):
        lease = await self.authority.reserve()
        await self.authority.begin(lease)
        reply = None
        failed = False
        try:
            reply = await self.inner.get_response(*args, **kwargs)
        except asyncio.CancelledError:
            await asyncio.shield(self.authority.unknown(lease))
            raise
        except Exception:
            failed = True
        if failed:
            await self.authority.unknown(lease)
            # Raise outside the provider exception context, before SDK logging.
            raise ProbeModelUnavailable()
        usage = reply.usage
        units = (usage.input_tokens, usage.output_tokens, usage.total_tokens)
        if (any(type(x) is not int or x < 0 for x in units)
                or units[0] + units[1] != units[2]):
            await self.authority.unknown(lease)
            raise ProbeModelUnavailable()
        await self.authority.settle(lease, usage.total_tokens)
        return reply

    async def stream_response(self, *args, **kwargs):
        raise ProbeModelUnavailable()
        yield
