"""Shared SDK control and governed model handling; no worker startup/decorators."""
from agents import Model,ModelProvider
from temporalio.exceptions import ApplicationError,TimeoutError as ActivityTimeout
from .model_rpc import ModelRPCError
from .sdk_model import BINDING_KEY,SDKModelDeferred,SDKModelPolicyError,GovernedResponsesProvider,operation_id
from .transport import _json,_validate
from .workflow_control import WorkflowControl,WAIT_TYPE


def _control(context,status,operation=None,not_before=None):
    return WorkflowControl(context['rootId'],context['taskId'],operation,status,not_before)


def _rpc_control(context,error,operation=None):
    status=('waiting-resources' if error.code=='CAPACITY' else 'scope-changed' if error.code=='DENIED'
        else 'configuration-required' if error.code in {'PROFILE_DISABLED','INVALID','UNAUTHENTICATED'} else 'waiting-reconciliation')
    return _control(context,status,operation)


def _wait(error,context=None,operation=None):
    seen=set();timed_out=False
    while isinstance(error,BaseException) and id(error) not in seen:
        seen.add(id(error))
        if isinstance(error,ApplicationError) and error.type==WAIT_TYPE and len(error.details)==1 and isinstance(error.details[0],WorkflowControl):return error.details[0]
        timed_out=timed_out or isinstance(error,ActivityTimeout)
        error=error.__cause__ or getattr(error,'cause',None)
    # Only the explicitly versioned read journey opts into timeout recovery.
    # A timeout is uncertainty, never permission to repeat provider work.
    if timed_out and context is not None:return _control(context,'waiting-reconciliation',operation)
    return None


class DurableModel(Model):
    def __init__(self,model):self.model=model
    async def get_response(self,system_instructions,input,model_settings,tools,output_schema,handoffs,tracing,*,
                           previous_response_id,conversation_id,prompt):
        binding=_json(model_settings.metadata[BINDING_KEY]);_validate('AgentSDKModelBinding',binding);context=binding['context']
        control=None
        try:
            return await self.model.get_response(system_instructions,input,model_settings,tools,output_schema,handoffs,tracing,
                previous_response_id=previous_response_id,conversation_id=conversation_id,prompt=prompt)
        except SDKModelDeferred as error:
            value=error.preparation;kind=value['kind']
            status=('waiting-provider' if kind in {'provider-wait','ready'} or kind=='failed' and value.get('retryable') else 'storage-failed' if kind=='failed' and 'writeId' in value
                else 'model-failed' if kind=='failed' else 'waiting-reconciliation')
            not_before=value.get('notBefore') if kind=='provider-wait' else context['admittedAt'] if status=='waiting-provider' else None
            control=_control(context,status,operation_id(binding),not_before)
        except ModelRPCError as error:control=_rpc_control(context,error,operation_id(binding))
        except SDKModelPolicyError:control=_control(context,'configuration-required',operation_id(binding))
        # Raise after leaving the except suite; arbitrary provider causes never
        # accompany this typed control record in Activity logs or failure data.
        raise ApplicationError('agent_wait',control,type=WAIT_TYPE,non_retryable=True)
    def stream_response(self,*args,**kwargs):raise SDKModelPolicyError()


class DurableModelProvider(ModelProvider):
    def __init__(self,provider):
        if not isinstance(provider,GovernedResponsesProvider):raise SDKModelPolicyError()
        self.provider=provider
    def get_model(self,model_name):return DurableModel(self.provider.get_model(model_name))
