"""Fixed trusted SDK child using the maintained read journey and private RPC.

No Temporal worker, generated code, network discovery or automatic process
recovery. The parent owns the durable execution binding. A continuation changes
SDK phase in this process and never creates another task or renews its horizon.
"""
import asyncio
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone,timedelta
import json
import sys

from .journey_control import _control, _wait, _rpc_control, DurableModelProvider
from .model_rpc import RPCModelBoundary, ModelRPCError, _group_context
from .read_journey import run_read_journey
from .sdk_model import SDKModelPolicyError
from .transport import _validate
from .workflow_control import WorkflowControl, read_control
from .sdk_model import GovernedResponsesProvider
from agents import Model


class DecisionModel(Model):
    def __init__(self,model,driver):self.model,self.driver=model,driver
    async def get_response(self,*args,**kwargs):
        if self.driver.model_calls>=8:raise SDKModelPolicyError()
        self.driver.model_calls+=1
        return await self.model.get_response(*args,**kwargs)
    def stream_response(self,*args,**kwargs):raise SDKModelPolicyError()


class DecisionProvider(GovernedResponsesProvider):
    def __init__(self,provider,driver):self.provider,self.driver=provider,driver
    def get_model(self,name):return DecisionModel(self.provider.get_model(name),self.driver)


class ContinueJourney(Exception):
    def __init__(self, value):
        self.value = deepcopy(value)
        super().__init__('direct_journey_continuation')


class DirectRuntime:
    def __init__(self, execution_id, features):
        self.execution_id = execution_id
        self.features = frozenset(features)
        self.step_count = 0

    def feature(self, name):
        # Direct executions have no old replay histories. Only this release's
        # explicitly selected feature set is enabled; unknown features fail.
        if name not in self.features:
            raise SDKModelPolicyError()
        return True

    def should_yield(self):
        return False

    def continue_journey(self, value, **kwargs):
        if set(kwargs) - {'task_queue'}:
            raise SDKModelPolicyError()
        self.step_count += 1
        if self.step_count > 32:
            raise SDKModelPolicyError()
        raise ContinueJourney(value)


class AssignedRPCBoundary(RPCModelBoundary):
    def __init__(self, *args, assigned_context, **kwargs):
        super().__init__(*args, **kwargs)
        self.assigned_context = deepcopy(assigned_context)

    async def _send(self, action, value, contract):
        if _group_context(value) != self.assigned_context:
            raise ModelRPCError('DENIED')
        return await super()._send(action, value, contract)


class DirectReadBoundary:
    """Provider-neutral SDK operations mapped to the existing RPC contract."""
    def __init__(self, rpc, driver):
        self.rpc, self.driver = rpc, driver

    async def accepted_model_operation(self, context, operation_id):
        return await self.rpc.accepted_model_operation(context, operation_id)

    async def execute_tool(self, request):
        self.driver.tool_calls += 1
        if self.driver.tool_calls > 16:
            raise SDKModelPolicyError()
        result = await self.rpc.execute_tool(request)
        if result['kind'] not in {'accepted', 'failed'}:
            from temporalio.exceptions import ApplicationError
            from .workflow_control import WAIT_TYPE
            raise ApplicationError('agent_wait', _control(request['context'], 'waiting-reconciliation',
                request['modelOperationId']), type=WAIT_TYPE, non_retryable=True)
        return result

    async def pack_input_results(self, context, set_id, references):
        result = await self.rpc.pack_input_results(context, set_id, references)
        if result['kind'] != 'ready':
            raise ModelRPCError('UNAVAILABLE')
        return result

    async def put_checkpoint(self, checkpoint_id, value):
        return await self.rpc.put_checkpoint(checkpoint_id, value)

    async def get_checkpoint(self, context, checkpoint_id):
        return await self.rpc.get_checkpoint(context, checkpoint_id)

    async def bind_read_goal(self, context, operation_id):
        result=read_control(await self.rpc.bind_read_goal(context, operation_id))
        if self.driver.pause_after_goal and not self.driver.goal_control_paused:
            self.driver.goal_control_paused=True
            until=min(datetime.now(timezone.utc)+timedelta(seconds=2),
                datetime.fromisoformat(context['authorizationHorizon'].replace('Z','+00:00')))
            await self.driver._pause(_control(context,'waiting-reconciliation',operation_id,
                not_before=until.isoformat().replace('+00:00','Z')))
        return result

    async def complete_read(self, context, operation_id):
        return read_control(await self.rpc.complete_read(context, operation_id))

    async def selected_read_tools(self,context,operation_id,goal_digest):
        return await self.rpc.selected_read_tools(context,goal_digest)

    async def plan_state(self,context,operation_id):
        return await self.rpc.plan_state(context,operation_id)

    async def review(self,context,operation_id,*,review_id=None,preparation=None,goal_digest=None):
        # The shared journey handles the bounded completed/rejected result
        # directly, before any further checkpoint write on a closed Root.
        return await self.rpc.review(context,operation_id,review_id,preparation)

    async def owner_input(self,context,operation_id,*,bind=False):
        return await self.rpc.owner_input(context,operation_id,bind=bind)


class DirectDriver:
    serialize_tools=True

    def __init__(self, rpc, model_provider, *, execution_id, features, max_model_turns=8,control_sink=None,pause_after_goal=False):
        if max_model_turns!=8:raise SDKModelPolicyError()
        if type(pause_after_goal) is not bool:raise SDKModelPolicyError()
        self.model_calls=0
        self.rpc, self.model_provider = rpc, DurableModelProvider(DecisionProvider(model_provider,self))
        self.execution_id = execution_id
        self.journey_runtime = DirectRuntime(execution_id, features)
        self.boundary_factory = lambda timeout_ms: DirectReadBoundary(rpc, self)
        # The retained checkpoint format requires SDK max_turns=None.
        # DecisionModel enforces the eight-call bound across all phases and
        # checkpoints rather than changing that serialization contract.
        self.max_model_turns = None
        self.context = self.control = self.pending_control = None
        self.stopped = self.claimed = self.resumed = False
        self.parallel_resume_operations = frozenset()
        self.tool_calls = 0
        self._wake = asyncio.Event()
        self.control_sink=control_sink
        self.pause_after_goal=pause_after_goal
        self.goal_control_paused=False

    def _expired(self):
        return datetime.now(timezone.utc) >= datetime.fromisoformat(
            self.context['authorizationHorizon'].replace('Z', '+00:00'))

    def _terminal(self, control):
        self.control = control
        return control

    def command(self, control):
        if (not isinstance(control, WorkflowControl) or self.context is None or
                any(getattr(control, key) != self.context[key] for key in ('rootId', 'taskId'))):
            raise SDKModelPolicyError()
        if control.status == 'stop':
            self.stopped = True
        elif self.control is None or control.operationId != self.control.operationId:
            raise SDKModelPolicyError()
        elif control.status == 'resume':
            self.resumed = True
        elif control.status == 'claim' and self.control.status == 'candidate-ready':
            self.claimed = True
        else:
            raise SDKModelPolicyError()
        self._wake.set()

    async def _pause(self, control):
        self.control = control
        self.resumed = False
        self._wake.clear()
        if self.control_sink is not None:self.control_sink(control)
        remaining = (datetime.fromisoformat(self.context['authorizationHorizon'].replace('Z', '+00:00'))
            - datetime.now(timezone.utc)).total_seconds()
        if remaining > 0 and not self.stopped:
            try:
                await asyncio.wait_for(self._wake.wait(), remaining)
            except TimeoutError:
                pass

    async def _save(self, boundary, checkpoint_id, envelope):
        # An uncertain write suspends. No retry or new checkpoint identity is
        # introduced merely because this process received an uncertain reply.
        try:
            result = await boundary.put_checkpoint(checkpoint_id, envelope)
            if result['kind'] == 'ready':
                return result
        except Exception as error:
            control = _wait(error)
            if control is None:
                control = _rpc_control(self.context, error) if isinstance(error, ModelRPCError) else None
            if control is None:
                raise
            return self._terminal(control)
        return self._terminal(_control(self.context, 'waiting-reconciliation',
            envelope['binding']['parentOperationId']))

    async def run(self, value):
        contracts={'agent-read-journey/1':'AgentSDKReadJourneyStart',
            'agent-contextual-lookup-read-journey/2':'AgentSDKContextualCoverageLookupReadJourneyStart',
        'agent-contextual-lookup-read-journey/1':'AgentSDKContextualLookupReadJourneyStart',
        'agent-lookup-read-journey/1':'AgentSDKLookupReadJourneyStart',
            'agent-discovered-read-journey/1':'AgentSDKDiscoveredReadJourneyStart',
            'agent-capability-read-journey/1':'AgentSDKCapabilityReadJourneyStart',
            'agent-reviewed-change-journey/1':'AgentSDKReviewJourneyStart',
            'agent-memory-read-journey/1':'AgentSDKMemoryReadJourneyStart',
            'agent-memory-response-journey/1':'AgentSDKMemoryResponseJourneyStart'}
        contract=contracts.get(value.get('schema'))
        if value.get('schema')=='agent-reviewed-change-journey/1':
            from .read_journey import start_contract
            contract=start_contract(value)
        if contract is None:
            raise SDKModelPolicyError()
        _validate(contract,value)
        if value['schema']=='agent-reviewed-change-journey/1' and value['start']['context']['harness']['ref']!='agent-sdk-reviewed-change/1':
            raise SDKModelPolicyError()
        self.context = deepcopy(value['start']['context'])
        remaining = (datetime.fromisoformat(self.context['authorizationHorizon'].replace('Z', '+00:00'))
            - datetime.now(timezone.utc)).total_seconds()
        if remaining <= 0:
            return self._terminal(_control(self.context, 'authorization-expired'))
        try:
            async with asyncio.timeout(remaining):
                while True:
                    try:
                        return await run_read_journey(self, value)
                    except ContinueJourney as next_phase:
                        if next_phase.value['start']['context'] != self.context:
                            raise SDKModelPolicyError()
                        value = next_phase.value
        except TimeoutError:
            return self._terminal(_control(self.context, 'authorization-expired'))


def features():
    from .direct_features import FEATURES
    return FEATURES


async def read_parent_commands(driver):
    # Only the trusted parent owns this pipe. It carries existing typed
    # control, no source, credentials, arguments or new task authority.
    reader=asyncio.StreamReader(limit=4096)
    protocol=asyncio.StreamReaderProtocol(reader)
    transport,_=await asyncio.get_running_loop().connect_read_pipe(lambda:protocol,sys.stdin.buffer)
    try:
        while True:
            raw=await reader.readline()
            if not raw:return
            if len(raw)>4096 or not raw.endswith(b'\n'):raise SDKModelPolicyError()
            value=json.loads(raw)
            if set(value)!={'schema','control'} or value['schema']!='agent-direct-command/1':raise SDKModelPolicyError()
            _validate('AgentWorkflowControl',value['control'])
            driver.command(WorkflowControl(**value['control']))
    finally:transport.close()


async def run_child(configuration):
    from pathlib import Path
    import ssl
    from .sdk_model import GovernedResponsesModel, GovernedResponsesProvider
    from .transport import OfficialTransport, TransportConfig
    from .direct_fixture import deterministic_transport
    from .policy import verify_dependencies
    import importlib.util
    import importlib.metadata
    verify_dependencies()
    if importlib.util.find_spec('agentic_os') is not None or 'agentic_os_agent_worker.temporal_driver' in sys.modules:
        raise SDKModelPolicyError()
    if set(configuration) != {'schema', 'origin', 'token_file', 'ca_file', 'start', 'execution_id', 'transport', 'inference'}:
        raise SDKModelPolicyError()
    if configuration['schema'] != 'agent-direct-child/2' or configuration['inference'].get('mode') not in {'deterministic','live-openai','live-anthropic'}:
        raise SDKModelPolicyError()
    context = configuration['start']['start']['context']
    async def token():
        path = Path(configuration['token_file'])
        if (not path.is_absolute() or path.is_symlink() or not path.is_file() or
                path.stat().st_mode & 0o077 or path.stat().st_uid != __import__('os').getuid()):
            raise SDKModelPolicyError()
        raw = path.read_bytes()
        if not 1 <= len(raw) <= 8192:
            raise SDKModelPolicyError()
        return raw.decode('ascii')
    tls = ssl.create_default_context(cafile=configuration['ca_file'])
    rpc = AssignedRPCBoundary(configuration['origin'], token, tls_context=tls,
        local_synthetic=False, assigned_context=context)
    transport = None
    try:
        config = TransportConfig(**configuration['transport'])
        inference=deepcopy(configuration['inference'])
        pause_after_goal=inference.pop('control_pause_after_goal',False)
        if inference['mode']=='deterministic':
            transport = OfficialTransport(config, rpc, api_key='synthetic-no-paid-provider',
                network_transport=deterministic_transport(inference))
        else:
            # Only an explicit protected credential file is accepted. The
            # original Core Root and operator allowance are reserved before
            # this child is started; ambient environment keys are never read.
            if (set(inference)!={'mode','credential_file'} or inference['mode']!='live-'+config.provider
                    or config.privacy_configuration_json is None):raise SDKModelPolicyError()
            path=Path(inference['credential_file'])
            if (not path.is_absolute() or path.is_symlink() or not path.is_file()
                    or path.stat().st_mode & 0o077 or path.stat().st_uid!=__import__('os').getuid()):
                raise SDKModelPolicyError()
            raw=path.read_bytes()
            if not 1<=len(raw)<=8192:raise SDKModelPolicyError()
            rows=[row.strip() for row in raw.decode('utf-8').splitlines()
                if row.strip() and not row.lstrip().startswith('#')]
            if len(rows)!=1 or not rows[0].startswith(config.provider.upper()+'_API_KEY='):raise SDKModelPolicyError()
            key=rows[0].split('=',1)[1].strip()
            if key[:1] in ('"',"'") and key[-1:]==key[:1]:key=key[1:-1]
            if not key.startswith('sk-ant-' if config.provider=='anthropic' else 'sk-') or (config.provider=='openai' and key.startswith('sk-ant-')) or any(c.isspace() for c in key):raise SDKModelPolicyError()
            transport=OfficialTransport(config,rpc,api_key=key)
        model = GovernedResponsesModel(transport, max_output_tokens=configuration['start']['start']['maxOutputTokens'],
            reasoning_effort='none' if inference['mode']=='live-openai' else None)
        def publish_control(control):
            sys.stdout.write(json.dumps(dict(schema='agent-direct-status/1',control=asdict(control)),
                sort_keys=True,separators=(',',':'))+'\n');sys.stdout.flush()
        driver = DirectDriver(rpc, GovernedResponsesProvider(model),
            execution_id=configuration['execution_id'], features=features(),control_sink=publish_control,pause_after_goal=pause_after_goal)
        journey=asyncio.create_task(driver.run(configuration['start']))
        commands=asyncio.create_task(read_parent_commands(driver))
        try:
            done,_=await asyncio.wait((journey,commands),return_when=asyncio.FIRST_COMPLETED)
            if journey not in done:
                # Parent EOF or malformed control cannot restart a model or
                # extend a grant. Original uncertain work remains in Core.
                await commands
                raise SDKModelPolicyError()
            result=await journey
        finally:
            for task in (journey,commands):
                if not task.done():task.cancel()
            await asyncio.gather(journey,commands,return_exceptions=True)
        return dict(schema='agent-direct-child-result/1', control=asdict(result),
            toolCalls=driver.tool_calls,modelCalls=driver.model_calls,continuations=driver.journey_runtime.step_count,
            environment=dict(mcp=importlib.metadata.version('mcp'),corePackageVisible=False,
                temporalDriverImported='agentic_os_agent_worker.temporal_driver' in sys.modules))
    finally:
        if transport is not None:
            await transport.close()
        await rpc.close()


def main():
    # The fixed parent sends bounded canonical input over a private inherited
    # pipe. Neither user input nor credentials select a module or command.
    try:
        raw = sys.stdin.buffer.readline(1024 * 1024 + 1)
        if not raw.endswith(b'\n') or len(raw) > 1024 * 1024:
            raise SDKModelPolicyError()
        result = asyncio.run(run_child(json.loads(raw)))
        sys.stdout.write(json.dumps(result, sort_keys=True, separators=(',', ':')) + '\n')
    except Exception as error:
        import traceback
        from pathlib import Path
        seen=set();locations=[];cause=error
        while isinstance(cause,BaseException) and id(cause) not in seen and len(locations)<60:
            seen.add(id(cause))
            locations.extend(dict(file=Path(frame.filename).name,line=frame.lineno,error=type(cause).__name__)
                for frame in traceback.extract_tb(cause.__traceback__)[-20:])
            cause=cause.__cause__ or cause.__context__
        sys.stderr.write(json.dumps(dict(schema='agent-direct-diagnostic/1',error=type(error).__name__,
            code=getattr(error,'code',None),locations=locations),separators=(',',':'))+'\n')
        raise SystemExit(1) from None


if __name__ == '__main__':
    main()
