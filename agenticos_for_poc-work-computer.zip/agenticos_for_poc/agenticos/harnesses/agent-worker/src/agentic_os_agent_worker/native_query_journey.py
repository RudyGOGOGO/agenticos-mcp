"""One offline program stage inside the existing source/child SDK journey."""
from copy import deepcopy
from dataclasses import replace
import json
from uuid import UUID,uuid5

from agents import Agent,ModelSettings,RunConfig,Runner
from temporalio import workflow
from temporalio.exceptions import ApplicationError

from .checkpoint import export_checkpoint,restore_checkpoint
from .sdk_model import BINDING_KEY,SDKModelSequence,SDKModelPolicyError
from .sdk_tools import governed_native_tool
from .transport import _SCHEMA,_json,_validate
from .workflow_control import WorkflowControl,WAIT_TYPE


def _dump(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def instructions(goal,*,exact_values=False):
    names=['AgentNativeAnalysisValues','AgentNativeMetricValues','FieldValue','Scalar']
    definitions={name:_SCHEMA['$defs'][name] for name in names if name in _SCHEMA['$defs']}
    semantics=(' Metric value fields must be decimal strings with exactly outputScale fractional digits, '
        'including trailing zeros; never emit a JSON number for a computed value. Always include unit, '
        'using the conversion target unit when converting, otherwise null when no unitField is declared. '
        'Preserve source identifier types. '
        'Apply populationFilters before metric filters. Deduplicate identical relevant projections at the '
        'declared grain before aggregation: repeated copies of one measurement count once, not as added '
        'contributions. Conflicting projections at one grain cannot be combined. Apply latest and nulls '
        'before aggregating. Count available distinct population identities with non-null accepted '
        'measurements before ranking; missing is every eligible identity without such a measurement. '
        'Use the declared aggregate and ranking; maximum ranking compares within partitions and retains '
        'all ties, while all ranking retains every group. ' if exact_values else '')
    return ('Write one Python standard-library program and call the offered native tool with that source, '
        'language python-stdlib/1 and goalDigest '+goal['digest']+'. The program reads newline-delimited JSON '
        'from stdin. Its first line has schema agent-native-query-input/1, goalDigest, queries and criteria. '
        'Each following line has queryKey, pageOrdinal and records (objects of typed source field values). '
        'Consume every page of every query before deriving results. Apply the declared filters, latest revision, '
        'grouping, aggregation, conversion, ranking, population and missing-data policies exactly. '
        'Use Decimal for numeric values; preserve identifiers, units and missing values. Emit one JSON object '
        'on stdout with the same goalDigest and one metrics entry per criterion: criterionId, rows (arrays of '
        'name/value fields for every groupBy field, value and unit), eligible, available and missing (arrays '
        'of name/value fields for every populationFields identity). Do not emit logs or additional text. '
        'The program has no model, network, Host, database or mounted files. It must obtain all source values '
        'from stdin; no expected answer is provided. The kernel independently compares every value and '
        'missing identity with already verified current source evidence before accepting output. '
        'An accepted result is final for this stage; do not run another program. '
        'A known tool-error may be corrected by a new accepted proposal, while reconciliation cannot be retried. '
        +semantics+'Declared objective: '+_dump(goal['declaration'])+'. Output contracts: '+_dump(definitions))


def repeated_native_error(items):
    """Stop identical known failure feedback in this private source generation."""
    prior=None
    for item in reversed(items):
        if item.get('type')!='function_call_output':continue
        try:value=_json(item['output'])
        except (KeyError,TypeError,ValueError):return False
        if type(value) is not dict or value.get('kind')!='tool-error':return False
        if prior is not None:return value==prior
        prior=value
    return False


async def run_native_query(driver,value,boundary):
    from .temporal_driver import _control,_wait
    from .child_read_journey import _deferred
    from .read_journey import start_contract
    start=value['start'];context=start['context'];selected=[item for item in start['capabilities'] if item['kind']=='native']
    if len(selected)!=1:raise SDKModelPolicyError()
    binding=value['binding']
    if binding is None or binding['parentOperationId'] is None:raise SDKModelPolicyError()
    carried=[ref for ref in binding['inputResults'] if ref['payload']['schemaRef']=='AgentNativeAnalysisResult']
    if start['checkpointId'] is None and carried:
        # This stage already completed in this saved sequence. The caller has
        # just checked the source binding; a source rebind replaces all inputs
        # with its new query-fact head. Do not re-enter the stage or repack its
        # accepted output at every child continuation. This reference grants
        # no authority: Core rechecks its current sources/native permission on
        # model admission, accepted ancestry and final completion.
        if (len(carried)!=1 or any(carried[0][key]!=context[key] for key in ('subject','rootId','taskId'))):
            raise SDKModelPolicyError()
        return None
    state=await boundary.native_source_state(context,binding['parentOperationId']);_validate('AgentNativeSourceState',state)
    if (state['context']!=context or state['bindingId']!=value['sourceBindingId']
            or state['capability']!=selected[0]['capability']):raise SDKModelPolicyError()
    if state['kind']=='reconciliation':raise _deferred(context,binding['parentOperationId'],dict(kind='reconciliation'))
    if state['result'] is not None and start['checkpointId'] is None:
        sequence=SDKModelSequence(binding,dependency_boundary=boundary)
        accepted_agent=Agent(name='Accepted current-source analysis',model_settings=ModelSettings(metadata={}))
        await sequence.add_tool_result(state['result'],accepted_agent)
        value['binding']=sequence.snapshot()
        value['continuationInputJson']=None
        return None
    goal=state['goal']
    # The core returns the canonical command digest in the same private source
    # state. Workers never invent a second digest recipe for canonical data.
    goal_digest=state['goalDigest']
    exact_values=workflow.patched('native-exact-output-feedback/1')
    pins=[selected[0]['capability']];instance=binding['sdkInstanceId']
    while True:
        if driver.stopped:return _control(context,'stopped')
        if driver._expired():return _control(context,'authorization-expired')
        sequence=None
        try:
            saved=None
            if start['checkpointId'] is not None:
                saved=await boundary.get_checkpoint(context,start['checkpointId']);binding=saved['binding']
            sequence=SDKModelSequence(binding,dependency_boundary=boundary)
            agent=Agent(name='Current-source offline analysis',model=start['modelId'],tool_use_behavior='stop_on_first_tool',
                instructions=instructions(dict(digest=goal_digest,declaration={key:deepcopy(goal[key]) for key in ('queries','criteria')}),exact_values=exact_values),
                model_settings=ModelSettings(metadata={BINDING_KEY:_dump(binding)},store=False,max_tokens=start['maxOutputTokens']))
            agent.tools=[replace(governed_native_tool(selected[0],boundary,sequence),needs_approval=True)]
            initial=[dict(role='user',content='Compute the complete declared current-source analysis in the offline sandbox.')]
            if value['continuationInputJson'] is not None:initial=_json(value['continuationInputJson'])
            if saved is not None:
                restored=await restore_checkpoint(agent,saved,expected_context=context,sdk_instance_id=instance,
                    capabilities=pins,sequence=sequence,dependency_boundary=boundary)
                initial=restored.state
                for interruption in initial.get_interruptions():initial.approve(interruption)
            driver.control=_control(context,'running',binding['parentOperationId'])
            result=await Runner.run(agent,initial,max_turns=None,hooks=sequence,
                run_config=RunConfig(model=start['modelId'],tracing_disabled=True))
            binding=sequence.snapshot();value['binding']=binding
            if result.interruptions:
                checkpoint=str(uuid5(UUID(instance),'native-checkpoint/'+str(binding['turn'])))
                stored=await driver._save(boundary,checkpoint,export_checkpoint(result,sequence,pins))
                if isinstance(stored,WorkflowControl):return stored
                start['checkpointId']=checkpoint;value['continuationInputJson']=None
                _validate(start_contract(value),value)
                if workflow.info().is_continue_as_new_suggested() or workflow.info().get_current_history_length()>=start['maxSegmentEvents']:
                    workflow.continue_as_new(value)
                continue
            state=await boundary.native_source_state(context,binding['parentOperationId']);_validate('AgentNativeSourceState',state)
            if state['bindingId']!=value['sourceBindingId'] or state['goalDigest']!=goal_digest:raise SDKModelPolicyError()
            if state['kind']=='reconciliation':raise _deferred(context,binding['parentOperationId'],dict(kind='reconciliation'))
            start['checkpointId']=None
            if state['result'] is not None:
                if state['result'] not in binding['inputResults']:raise SDKModelPolicyError()
                value['continuationInputJson']=None
                _validate(start_contract(value),value)
                return None
            if exact_values and repeated_native_error(result.to_input_list()):
                return _control(context,'configuration-required',binding['parentOperationId'])
            value['continuationInputJson']=_dump([*result.to_input_list(),dict(role='user',
                content='Complete the offline native analysis through the offered tool. Correct only a known failed proposal; do not invent success.')])
            _validate(start_contract(value),value)
            workflow.continue_as_new(value)
        except Exception as error:
            operation=sequence.pending if sequence is not None and sequence.pending is not None else binding['parentOperationId']
            control=_wait(error,context,operation)
            if control is None:raise
        raise ApplicationError('agent_wait',control,type=WAIT_TYPE,non_retryable=True)
