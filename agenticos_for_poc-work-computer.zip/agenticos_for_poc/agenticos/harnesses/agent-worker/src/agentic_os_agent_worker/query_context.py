"""Fresh private SDK context after a completed, accepted query tool round.

The causal result head retains earlier pages in the existing accepted journal.
Frontiers are navigation context only: the kernel still verifies all pages,
scope, versions and the original objective before deriving or publishing facts.
Pending SDK calls must use RunState instead of this completed-round projection.
"""
from copy import deepcopy
import json

from agents.items import ToolCallItem,ToolCallOutputItem

from .checkpoint import tool_alias
from .sdk_model import SDKModelPolicyError
from .transport import _json,_validate

FORMAT='agent-query-context-window/1'
SCOPED_FORMAT='agent-query-context-window/2'
FACT_FORMAT='agent-query-context-window/3'
MAXIMUM_WINDOW_BYTES=24576


def _dump(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def _frontiers(previous,goal_digest,*,format=FORMAT):
    frontiers={}
    if previous is not None:
        messages=_json(previous)
        if type(messages) is not list or len(messages)!=1 or messages[0].get('role')!='user':raise SDKModelPolicyError()
        saved=_json(messages[0]['content'])
        if (set(saved)!={'schema','goalDigest','results','frontiers'} or saved['schema']!=format
                or saved['goalDigest']!=goal_digest):raise SDKModelPolicyError()
        for frontier in saved['frontiers']:
            fields={'queryDigest','pageOrdinal','nextCursor'}
            if format in {SCOPED_FORMAT,FACT_FORMAT}:fields|={'toolName','queryKeys'}
            if set(frontier)!=fields:raise SDKModelPolicyError()
            key=(frontier['toolName'],frontier['queryDigest']) if format in {SCOPED_FORMAT,FACT_FORMAT} else frontier['queryDigest']
            if key in frontiers:raise SDKModelPolicyError()
            frontiers[key]=frontier
    return frontiers


def _window(sequence,frontiers,goal_digest,*,format=FORMAT):
    window=dict(schema=format,goalDigest=goal_digest,results=sequence.snapshot()['inputResults'],
        frontiers=[frontiers[key] for key in sorted(frontiers)])
    messages=[dict(role='user',content=_dump(window))]
    # Full request admission remains independently enforced by the Core.
    if len(_dump(messages).encode())>MAXIMUM_WINDOW_BYTES:raise SDKModelPolicyError()
    return messages


def incomplete_query_window(sequence,previous,goal_digest,*,format=FORMAT):
    """An incomplete candidate retains navigation and its new causal head."""
    if sequence.pending is not None:raise SDKModelPolicyError()
    if previous is not None:format=_json(_json(previous)[0]['content'])['schema']
    return _window(sequence,_frontiers(previous,goal_digest,format=format),goal_digest,format=format)


def query_window_selected(previous,goal_digest):
    """Carry the opt-in across runs; legacy transcripts/checkpoints stay legacy."""
    if previous is None:return False
    messages=_json(previous)
    if (type(messages) is not list or len(messages)!=1 or messages[0].get('role')!='user'
            or type(messages[0].get('content')) is not str or not messages[0]['content'].lstrip().startswith('{')):return False
    try:saved=json.loads(messages[0]['content'])
    except (ValueError,TypeError):return False
    if type(saved) is not dict or saved.get('schema') not in {FORMAT,SCOPED_FORMAT,FACT_FORMAT}:return False
    _frontiers(previous,goal_digest,format=saved['schema'])
    return True


def _completed_frontiers(result,sequence,previous,goal_digest,*,queries=None,format=FORMAT,query_aliases=None):
    if result.interruptions or sequence.pending is not None:raise SDKModelPolicyError()
    outputs=[item for item in result.new_items if isinstance(item,ToolCallOutputItem)]
    if not outputs:return None
    binding=sequence.snapshot();context=binding['context'];frontiers=_frontiers(previous,goal_digest,format=format)
    calls={item.call_id:item.to_input_item() for item in result.new_items if isinstance(item,ToolCallItem)}
    for item in outputs:
        value=_json(item.output);_validate('AgentAcceptedQueryReferenceContext',value)
        reference=value['result']
        if (reference not in binding['inputResults'] or reference['payload']['schemaRef']!='AgentQueryPage'
                or any(reference[key]!=context[key] for key in ('subject','taskId','rootId'))):raise SDKModelPolicyError()
        key=value['queryDigest'];extra={}
        if format in {SCOPED_FORMAT,FACT_FORMAT}:
            call=calls.get(item.call_id)
            if call is None or call.get('type')!='function_call':raise SDKModelPolicyError()
            actual=_json(call['arguments']);matches=[]
            for query in queries:
                _validate('AgentAnalysisQuery',query)
                original=_json(query['argumentsJson']);cursor_field=query['cursorField']
                if (call['name']==tool_alias(query['capability'])
                        and _dump({k:v for k,v in actual.items() if k!=cursor_field})==_dump({k:v for k,v in original.items() if k!=cursor_field})):
                    if value['requestCursor']!=actual.get(cursor_field):raise SDKModelPolicyError()
                    aliases=[entry['queryKeys'] for entry in query_aliases or [] if entry['queryKey']==query['key']]
                    if len(aliases)>1:raise SDKModelPolicyError()
                    matches.extend(aliases[0] if aliases else [query['key']])
            if not matches:raise SDKModelPolicyError()
            extra=dict(toolName=call['name'],queryKeys=sorted(set(matches)))
            key=(call['name'],value['queryDigest'])
        prior=frontiers.get(key)
        if (prior is None and (value['pageOrdinal']!=0 or value['requestCursor'] is not None)
                or prior is not None and (value['pageOrdinal']!=prior['pageOrdinal']+1
                    or prior['nextCursor'] is None or value['requestCursor']!=prior['nextCursor'])):raise SDKModelPolicyError()
        if prior is not None and extra and any(prior[k]!=extra[k] for k in extra):raise SDKModelPolicyError()
        frontiers[key]=dict({key:deepcopy(value[key]) for key in ('queryDigest','pageOrdinal','nextCursor')},**extra)
    return frontiers


def completed_query_window(result,sequence,previous,goal_digest):
    """Preserve the accepted v1 projection for existing one-query histories."""
    frontiers=_completed_frontiers(result,sequence,previous,goal_digest)
    return None if frontiers is None else _window(sequence,frontiers,goal_digest)


async def completed_scoped_query_window(result,sequence,previous,goal_digest,queries,*,query_aliases=None):
    """Bind query keys to accepted SDK calls; index large causal heads privately."""
    frontiers=_completed_frontiers(result,sequence,previous,goal_digest,queries=queries,format=SCOPED_FORMAT,query_aliases=query_aliases)
    if frontiers is None:return None
    if len(_dump(sequence.snapshot()['inputResults']).encode())>4096:
        await sequence.pack_accepted_results()
    return _window(sequence,frontiers,goal_digest,format=SCOPED_FORMAT)


async def _current_window(sequence,previous,goal_digest,queries,frontiers,additional,phase):
    saved=_json(_json(previous)[0]['content']);references=saved['results']
    if any(value['payload']['schemaRef']!='AgentQueryFactSet' for value in references):raise SDKModelPolicyError()
    if references or additional:
        invalid=await sequence.retain_query_facts(goal_digest,[*references,*additional],phase)
        if not set(invalid)<={query['key'] for query in queries}:raise SDKModelPolicyError()
        frontiers={key:value for key,value in frontiers.items() if not set(value['queryKeys']).intersection(invalid)}
    else:sequence.binding['inputResults']=[]
    return _window(sequence,frontiers,goal_digest,format=FACT_FORMAT)


async def refresh_query_window(sequence,previous,goal_digest,queries):
    """Recheck opaque facts before a fresh SDK model round, never a paid retry."""
    if sequence.pending is not None:raise SDKModelPolicyError()
    frontiers=_frontiers(previous,goal_digest,format=FACT_FORMAT)
    return await _current_window(sequence,previous,goal_digest,queries,frontiers,[],'preflight')


def rebound_query_window(sequence,previous,goal_digest,queries,result,invalid_keys):
    """Resume the original query objective from the Core's current fact head."""
    if sequence.pending is not None:raise SDKModelPolicyError()
    frontiers=_frontiers(previous,goal_digest,format=FACT_FORMAT)
    keys={query['key'] for query in queries}
    if not invalid_keys or not set(invalid_keys)<=keys:raise SDKModelPolicyError()
    _validate('AgentResultReference',result);context=sequence.snapshot()['context']
    if (result['payload']['schemaRef']!='AgentQueryFactSet'
            or any(result[key]!=context[key] for key in ('subject','taskId','rootId'))):raise SDKModelPolicyError()
    sequence.binding['inputResults']=[deepcopy(result)]
    frontiers={key:value for key,value in frontiers.items() if not set(value['queryKeys']).intersection(invalid_keys)}
    return _window(sequence,frontiers,goal_digest,format=FACT_FORMAT)


async def completed_current_query_window(result,sequence,previous,goal_digest,queries,*,all_queries=None,query_aliases=None):
    frontiers=_completed_frontiers(result,sequence,previous,goal_digest,queries=queries,format=FACT_FORMAT,query_aliases=query_aliases)
    if frontiers is None:return None
    references=[_json(item.output)['result'] for item in result.new_items if isinstance(item,ToolCallOutputItem)]
    return await _current_window(sequence,previous,goal_digest,queries if all_queries is None else all_queries,frontiers,references,'completed')
