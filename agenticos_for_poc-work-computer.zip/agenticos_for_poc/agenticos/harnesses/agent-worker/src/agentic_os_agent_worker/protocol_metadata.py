"""Typed opaque protocol metadata, never user/model dictionaries or source data.

Only enforcing worker boundaries construct this wrapper. The history codec
authenticates a projection of UUIDs, ciphertext pins and protocol timestamps;
the original private context comes from its own exact task binding.
"""
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
import re
from uuid import UUID

from .transport import _validate

INPUT_ENCODING=b'json/os-agent-protocol-metadata-v1'
ENCODING=b'binary/os-agent-protocol-metadata-hmac-v1'
PROFILE='agent-protocol-metadata-hmac/1'
MAX_BYTES=16384


def _uuid(value):
    if type(value) is not str or str(UUID(value))!=value:raise ValueError('Invalid opaque metadata')


def _timestamp(value):
    if (type(value) is not str or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|\+00:00)',value)
            or datetime.fromisoformat(value.replace('Z','+00:00')).utcoffset().total_seconds()!=0):
        raise ValueError('Invalid opaque metadata')


def _payload(value,schema):
    _validate('AgentPayloadReference',value)
    if (value['schemaRef']!=schema or value['schemaVersion']!=1
            or type(value['bytes']) is not int):raise ValueError('Invalid opaque metadata')
    if not value['artifactRef'].startswith('artifact/'):raise ValueError('Invalid opaque metadata')
    _uuid(value['artifactRef'][9:])
    if not re.fullmatch(r'[0-9a-f]{64}',value['ciphertextDigest']):raise ValueError('Invalid opaque metadata')


def project(kind,value,context):
    """Prove that the complete typed value contains only reconstructible metadata."""
    _validate('AgentTaskContext',context)
    if kind in {'operation','checkpoint'}:
        field='operationId' if kind=='operation' else 'checkpointId'
        if type(value) is not dict or set(value)!={'context',field} or value['context']!=context:
            raise ValueError('Invalid opaque metadata')
        _uuid(value[field]);compact={field:value[field]}
    elif kind=='model-result':
        _validate('AgentResultReference',value)
        if (any(value[key]!=context[key] for key in ('subject','rootId','taskId'))
                or value['scopeRef']!=context['scopeRef'] or value['lineageRef'] is not None):
            raise ValueError('Invalid opaque metadata')
        for key in ('resultId','producerStepId','acceptedAttemptId'):_uuid(value[key])
        _payload(value['payload'],'AgentProviderResponse');_timestamp(value['acceptedAt'])
        compact={key:deepcopy(value[key]) for key in ('resultId','producerStepId','acceptedAttemptId','payload','acceptedAt')}
    else:raise ValueError('Invalid opaque metadata')
    return dict(kind=kind,value=compact)


def restore(compact,context):
    if type(compact) is not dict or set(compact)!={'kind','value'}:raise ValueError('Invalid opaque metadata')
    kind=compact['kind'];body=deepcopy(compact['value'])
    if type(body) is not dict:raise ValueError('Invalid opaque metadata')
    if kind in {'operation','checkpoint'}:value=dict(context=deepcopy(context),**body)
    elif kind=='model-result':
        value=dict(**{key:deepcopy(context[key]) for key in ('subject','rootId','taskId')},
            scopeRef=context['scopeRef'],lineageRef=None,**body)
    else:raise ValueError('Invalid opaque metadata')
    if project(kind,value,context)!=compact:raise ValueError('Invalid opaque metadata')
    return kind,value


@dataclass(frozen=True)
class ProtocolMetadata:
    kind:str
    value:dict


class ProtocolCommand(dict):
    """Only a verified converter frame marks the Activity's protocol selection."""


def command(kind,value):
    # The boundary supplies the complete command, not a caller permission flag.
    project(kind,value,value['context'])
    return ProtocolMetadata(kind,deepcopy(value))
