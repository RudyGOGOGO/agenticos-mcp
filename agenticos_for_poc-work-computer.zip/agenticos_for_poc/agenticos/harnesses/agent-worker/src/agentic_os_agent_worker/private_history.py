"""Context-bound Temporal claim checks through original-root private storage.

Only this new profile uses the encoding below. Existing history encodings are
untouched. Keys belong to an explicit worker history-key port, never the kernel's
artifact key store. Serialization I/O runs outside deterministic workflow code.
"""
import base64
from copy import deepcopy
import hashlib
import hmac
import json
import secrets
import zlib
from uuid import UUID,uuid5

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from temporalio.api.common.v1 import Payload
from temporalio.converter import PayloadCodec,WithSerializationContext,WorkflowSerializationContext,ActivitySerializationContext

from .model_rpc import ModelRPCError,_control
from .transport import _validate
from .workflow_control import CONTROL_ENCODING,READ_CONTROL_ENCODING,JOIN_CONTROL_ENCODING
from .protocol_metadata import (INPUT_ENCODING as METADATA_INPUT,ENCODING as METADATA_ENCODING,
    PROFILE as METADATA_PROFILE,MAX_BYTES as MAX_METADATA,project as project_metadata,restore as restore_metadata)

ENCODING=b'binary/os-agent-private-history-v1'
COMPRESSED_ENCODING=b'binary/os-agent-private-history-deflate-v1'
PROFILE='agent-private-history/1'
COMPRESSED_PROFILE='agent-private-history-deflate/1'
MAX_PAYLOAD=65536
MAX_RAW_PAYLOAD=1048576
MAX_BATCH=64


def _dump(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()


class PrivateHistoryUnavailable(ValueError):
    def __init__(self,code='UNAVAILABLE',*,write_id=None):
        self.code=code;self.write_id=str(UUID(write_id)) if write_id is not None else None
        super().__init__('agent_private_history_unavailable')


class PrivateHistoryDeferred(PrivateHistoryUnavailable):
    def __init__(self,preparation):
        self.preparation=deepcopy(preparation)
        super().__init__()


class AgentHistoryCodec(PayloadCodec,WithSerializationContext):
    def __init__(self,store,keys,context,namespace,*,key_id,serialization_context=None):
        _validate('AgentTaskContext',context)
        if (not callable(getattr(store,'put_history',None)) or not callable(getattr(store,'lookup_history',None))
                or not callable(getattr(keys,'_key',None))
                or type(namespace) is not str or not 1<=len(namespace)<=256):raise PrivateHistoryUnavailable()
        self.store,self.keys,self.context,self.namespace=store,keys,deepcopy(context),namespace
        self.serialization_context=serialization_context
        try:
            self.key_id=str(UUID(key_id))
        except Exception:raise PrivateHistoryUnavailable() from None

    def with_context(self,context):
        return AgentHistoryCodec(self.store,self.keys,self.context,self.namespace,
            serialization_context=context,key_id=self.key_id)

    def _binding(self,key_id,*,compressed=False):
        value=self.serialization_context;subject=self.context['subject']
        expected='os-agent:'+':'.join([subject['installationId'],subject['applicationId'],self.context['taskId']])
        if (not isinstance(value,(WorkflowSerializationContext,ActivitySerializationContext))
                or value.namespace!=self.namespace or value.workflow_id!=expected):raise PrivateHistoryUnavailable()
        return _dump(dict(profile=COMPRESSED_PROFILE if compressed else PROFILE,
            namespace=self.namespace,workflowId=expected,keyId=str(UUID(key_id))))

    def _write_id(self,key_id,raw,*,compressed=False):
        key=self._key(key_id)
        fingerprint=hmac.new(key,b'agent-private-history-write/1\0'+self._binding(key_id,compressed=compressed)+b'\0'+raw,hashlib.sha256).hexdigest()
        return str(uuid5(UUID(self.context['rootId']),'history-payload/'+fingerprint))

    def _key(self,key_id):
        key=self.keys._key(key_id)
        if type(key) is not bytes or len(key)!=32:raise PrivateHistoryUnavailable()
        return key

    def _control(self,payload):
        self._binding(self.key_id)
        encoding=payload.metadata.get('encoding')
        if (encoding not in {CONTROL_ENCODING,READ_CONTROL_ENCODING,JOIN_CONTROL_ENCODING} or dict(payload.metadata)!={'encoding':encoding}
                or len(payload.data)>(2048 if encoding==CONTROL_ENCODING else 4096)):raise PrivateHistoryUnavailable()
        schema={CONTROL_ENCODING:'AgentWorkflowControl',READ_CONTROL_ENCODING:'AgentReadControl',JOIN_CONTROL_ENCODING:'AgentSourceChildJoinControl'}[encoding]
        value=_control(payload.data)
        if encoding==READ_CONTROL_ENCODING and value.get('profile')=='agent-memory-read-control/1':
            if not self.context['harness']['ref'].startswith('memory-assisted-read/'):raise PrivateHistoryUnavailable()
            schema='AgentMemoryReadControl'
        if encoding==READ_CONTROL_ENCODING and value.get('profile')=='agent-partial-read-control/1':
            from .workflow_control import partial_read_context
            if not partial_read_context(self.context):raise PrivateHistoryUnavailable()
            schema='AgentPartialReadControl'
        _validate(schema,value)
        if any(value[k]!=self.context[k] for k in ('rootId','taskId')):raise PrivateHistoryUnavailable()
        return payload

    async def _lookup(self,write_id):
        result=await self.store.lookup_history(self.context,write_id,self.namespace,self.serialization_context.workflow_id)
        return self._stored(result,write_id)

    def _stored(self,result,write_id,*,allow_missing=True):
        _validate('AgentHistoryLookupResult',result)
        if result['kind']=='ready':
            reference=result['reference'];envelope=result['envelope']
            if (reference['writeId']!=write_id or any(reference[k]!=self.context[k] for k in ('subject','taskId','rootId'))
                    or reference['payload']['schemaRef']!='AgentTemporalHistoryEnvelope' or reference['payload']['schemaVersion']!=1
                    or envelope['namespace']!=self.namespace or envelope['workflowId']!=self.serialization_context.workflow_id):raise PrivateHistoryUnavailable()
        elif result['kind']=='missing':
            if not allow_missing or result['writeId']!=write_id:raise PrivateHistoryUnavailable()
        else:raise PrivateHistoryDeferred(result['preparation'])
        return result

    def _decrypt(self,value,write_id,*,compressed=False):
        envelope=value['envelope'];key_id=envelope['keyId'];binding=self._binding(key_id,compressed=compressed)
        encoded=base64.b64decode(envelope['ciphertextBase64'],validate=True)
        if not 28<=len(encoded)<=MAX_PAYLOAD+28:raise PrivateHistoryUnavailable()
        raw=AESGCM(self._key(key_id)).decrypt(encoded[:12],encoded[12:],binding)
        if compressed:
            # Authenticate before bounded decompression. Reject concatenated,
            # trailing, truncated and over-expanding streams without allocating
            # more than the supported1MiB private SDK message profile.
            inflater=zlib.decompressobj();raw=inflater.decompress(raw,MAX_RAW_PAYLOAD+1)
            if (len(raw)>MAX_RAW_PAYLOAD or not inflater.eof or inflater.unconsumed_tail
                    or inflater.unused_data):raise PrivateHistoryUnavailable()
        if (len(raw)>(MAX_RAW_PAYLOAD if compressed else MAX_PAYLOAD)
                or self._write_id(key_id,raw,compressed=compressed)!=write_id):raise PrivateHistoryUnavailable()
        return raw

    def _metadata_signature(self,key_id,compact):
        binding=self._binding(key_id)
        return hmac.new(self._key(key_id),b'agent-private-protocol-metadata/1\0'+binding+b'\0'+
            _dump(self.context)+b'\0'+_dump(compact),hashlib.sha256).hexdigest()

    async def _encode_metadata(self,payload):
        if dict(payload.metadata)!={'encoding':METADATA_INPUT}:raise PrivateHistoryUnavailable()
        value=_control(payload.data)
        if type(value) is not dict or set(value)!={'kind','value'}:raise PrivateHistoryUnavailable()
        if value['kind'] in {'operation','checkpoint'} and value['value']['context']!=self.context:
            # Child/planner commands retain their complete distinct private
            # context. Never reconstruct it from the worker's parent binding.
            project_metadata(value['kind'],value['value'],value['value']['context'])
            return await self._encode_one(Payload(metadata={'encoding':b'json/plain'},data=_dump(value['value'])))
        compact=project_metadata(value['kind'],value['value'],self.context)
        raw=_dump(dict(profile=METADATA_PROFILE,keyId=self.key_id,value=compact,
            signature=self._metadata_signature(self.key_id,compact)))
        if len(raw)>MAX_METADATA:raise PrivateHistoryUnavailable()
        return Payload(metadata={'encoding':METADATA_ENCODING},data=raw)

    def _decode_metadata(self,payload):
        if dict(payload.metadata)!={'encoding':METADATA_ENCODING} or len(payload.data)>MAX_METADATA:raise PrivateHistoryUnavailable()
        value=_control(payload.data)
        if (type(value) is not dict or set(value)!={'profile','keyId','value','signature'}
                or value['profile']!=METADATA_PROFILE or type(value['signature']) is not str
                or not hmac.compare_digest(value['signature'],self._metadata_signature(value['keyId'],value['value']))):
            raise PrivateHistoryUnavailable()
        kind,original=restore_metadata(value['value'],self.context)
        return Payload(metadata={'encoding':METADATA_INPUT},data=_dump(dict(kind=kind,value=original)))

    async def _encode_one(self,payload):
        raw=payload.SerializeToString(deterministic=True)
        if len(raw)>MAX_RAW_PAYLOAD:raise PrivateHistoryUnavailable()
        compressed=len(raw)>MAX_PAYLOAD
        packed=zlib.compress(raw) if compressed else raw
        if len(packed)>MAX_PAYLOAD:raise PrivateHistoryUnavailable()
        self._binding(self.key_id,compressed=compressed);write_id=self._write_id(self.key_id,raw,compressed=compressed)
        create=getattr(self.store,'store_history',None)
        if callable(create):
            nonce=secrets.token_bytes(12);ciphertext=nonce+AESGCM(self._key(self.key_id)).encrypt(
                nonce,packed,self._binding(self.key_id,compressed=compressed))
            envelope=dict(profile=PROFILE,namespace=self.namespace,workflowId=self.serialization_context.workflow_id,
                keyId=self.key_id,ciphertextBase64=base64.b64encode(ciphertext).decode('ascii'))
            try:
                stored=self._stored(await create(self.context,write_id,envelope),write_id,allow_missing=False)
            except ModelRPCError as error:
                # The versioned exchange owns the same content-addressed write
                # as the legacy put below. Preserve its exact pending identity
                # so replacement can wait for that write's original grant.
                if error.code=='CAPACITY':raise PrivateHistoryUnavailable('CAPACITY',write_id=write_id) from None
                raise
        else:stored=await self._lookup(write_id)
        if stored['kind']=='missing':
            nonce=secrets.token_bytes(12);ciphertext=nonce+AESGCM(self._key(self.key_id)).encrypt(
                nonce,packed,self._binding(self.key_id,compressed=compressed))
            envelope=dict(profile=PROFILE,namespace=self.namespace,workflowId=self.serialization_context.workflow_id,
                keyId=self.key_id,ciphertextBase64=base64.b64encode(ciphertext).decode('ascii'))
            try:
                prepared=await self.store.put_history(self.context,write_id,envelope)
                _validate('AgentPayloadPreparation',prepared)
                if prepared['kind']!='ready':raise PrivateHistoryDeferred(prepared)
                stored=dict(kind='ready',reference=prepared['reference'],envelope=envelope)
            except ModelRPCError as error:
                # Another encoder can claim the same content address. Observe
                # its original write; never create another identity or retry I/O.
                if error.code=='CAPACITY':raise PrivateHistoryUnavailable('CAPACITY',write_id=write_id) from None
                if error.code!='CONFLICT':raise
                stored=await self._lookup(write_id)
                if stored['kind']!='ready':raise PrivateHistoryUnavailable()
        if self._decrypt(stored,write_id,compressed=compressed)!=raw:raise PrivateHistoryUnavailable()
        reference=stored['reference']
        if (reference['writeId']!=write_id or any(reference[k]!=self.context[k] for k in ('subject','taskId','rootId'))
                or reference['payload']['schemaRef']!='AgentTemporalHistoryEnvelope' or reference['payload']['schemaVersion']!=1):raise PrivateHistoryUnavailable()
        ticket=dict(profile=PROFILE,writeId=write_id,payload=reference['payload']);_validate('AgentHistoryTicket',ticket)
        return Payload(metadata={'encoding':COMPRESSED_ENCODING if compressed else ENCODING},data=_dump(ticket))

    async def encode(self,payloads):
        try:
            payloads=list(payloads)
            if len(payloads)>MAX_BATCH:raise PrivateHistoryUnavailable()
            result=[]
            for payload in payloads:
                result.append(self._control(payload) if payload.metadata.get('encoding') in {CONTROL_ENCODING,READ_CONTROL_ENCODING,JOIN_CONTROL_ENCODING}
                    else await self._encode_metadata(payload) if payload.metadata.get('encoding')==METADATA_INPUT else await self._encode_one(payload))
            return result
        except PrivateHistoryUnavailable:raise
        except ModelRPCError as error:raise PrivateHistoryUnavailable(error.code) from None
        except Exception:raise PrivateHistoryUnavailable() from None

    async def decode(self,payloads):
        try:
            payloads=list(payloads)
            if len(payloads)>MAX_BATCH:raise PrivateHistoryUnavailable()
            result=[]
            for payload in payloads:
                if payload.metadata.get('encoding') in {CONTROL_ENCODING,READ_CONTROL_ENCODING,JOIN_CONTROL_ENCODING}:
                    result.append(self._control(payload));continue
                if payload.metadata.get('encoding')==METADATA_ENCODING:
                    result.append(self._decode_metadata(payload));continue
                self._binding(self.key_id)
                if (dict(payload.metadata) not in ({'encoding':ENCODING},{'encoding':COMPRESSED_ENCODING})
                        or len(payload.data)>16384):raise PrivateHistoryUnavailable()
                ticket=_control(payload.data);_validate('AgentHistoryTicket',ticket)
                stored=await self._lookup(ticket['writeId'])
                if stored['kind']!='ready' or stored['reference']['payload']!=ticket['payload']:raise PrivateHistoryUnavailable()
                result.append(Payload.FromString(self._decrypt(stored,ticket['writeId'],
                    compressed=payload.metadata['encoding']==COMPRESSED_ENCODING)))
            return result
        except PrivateHistoryUnavailable:raise
        except ModelRPCError as error:raise PrivateHistoryUnavailable(error.code) from None
        except Exception:raise PrivateHistoryUnavailable() from None
