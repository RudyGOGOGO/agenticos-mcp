"""One official SDK request per kernel-begun attempt, with no hidden retries.

The kernel boundary authenticates stored context/grants and loads private input.
It settles known counters using its own pinned prices, or retains uncertain work.
This worker owns neither a budget ledger nor Host/database credentials. Responses
remain private candidates until the kernel accepts them; raw SDK text is not UI.
"""
import asyncio
import base64
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import hashlib
from importlib.resources import files
import json
import logging
import math
import os
import time
from typing import Protocol

import httpx
import httpx2
from anthropic import AsyncAnthropic,APITimeoutError as AnthropicTimeout
from openai import AsyncOpenAI,APITimeoutError as OpenAITimeout
from jsonschema import Draft202012Validator

from .contracts import AgentModelInvocation, AgentModelObservation, AgentProviderUsage


class TransportError(ValueError):
    def __init__(self):
        super().__init__('unqualified_provider_transport')


class DuplicateJSONProperty(TransportError):
    def __init__(self,key):
        self.key=key
        super().__init__()


class EnvelopeExceeded(ValueError):
    pass


class LeaseExpired(ValueError):
    pass


_SCHEMA=json.loads(files('agentic_os_agent_worker').joinpath('contracts.json').read_text())


def _validate(name,value):
    schema={'$defs':_SCHEMA['$defs'],'$ref':'#/$defs/'+name}
    if not Draft202012Validator(schema).is_valid(value):raise TransportError()


class ModelBoundary(Protocol):
    async def begin_model(self, request: AgentModelInvocation) -> str:
        """Authenticate the exact stored grant, commit begin, return private JSON.

        A duplicate begun/unknown attempt must not return executable input again.
        No SQL session or credential is carried into the provider request.
        """
        ...

    async def finish_model(self, request: AgentModelInvocation, *, usage: AgentProviderUsage | None,
                           candidate_json: str | None, failure: str | None, reason: str | None,
                           provider_evidence_json: str | None,
                           request_id: str | None, response_id: str | None,
                           work_ms: int, retry_after_ms: int | None) -> AgentModelObservation:
        """Private idempotent accounting; uncertainty stays held even after Stop."""
        ...


@dataclass(frozen=True)
class TransportConfig:
    provider: str
    model_id: str
    # This digest pins the complete server-owned AgentModelProfile, including
    # endpoint/credential/pricing/retention/residency references.
    model_profile_digest: str
    model_profile_json: str
    endpoint_ref: str
    credential_ref: str
    base_url: str
    request_timeout_ms: int
    max_request_bytes: int
    max_response_bytes: int
    inference_geo: str | None = None
    privacy_configuration_json: str | None = None

    def __post_init__(self):
        profile=_json(self.model_profile_json)
        _validate('AgentModelProfile',profile)
        fingerprint=hashlib.sha256(b'agentic-os.hash/1\0manifest\0'+json.dumps(profile,
            sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
        endpoints=dict(openai='https://api.openai.com/v1',anthropic='https://api.anthropic.com')
        if (self.provider not in {'openai','anthropic'} or not self.model_id
                or len(self.model_profile_digest)!=64
                or any(c not in '0123456789abcdef' for c in self.model_profile_digest)
                or type(self.request_timeout_ms) is not int or not 1<=self.request_timeout_ms<=900000
                or any(type(n) is not int or not 1024<=n<=16777216
                       for n in (self.max_request_bytes,self.max_response_bytes))
                or profile['lifecycle']!='qualified' or profile['provider']!=self.provider
                or profile['api']!=('responses' if self.provider=='openai' else 'messages')
                or profile['modelId']!=self.model_id or profile['endpointRef']!=self.endpoint_ref
                or profile['credentialRef']!=self.credential_ref or fingerprint!=self.model_profile_digest
                or self.base_url!=endpoints.get(self.provider)):
            raise TransportError()
        if self.privacy_configuration_json is not None:
            self.validate_privacy()

    def validate_privacy(self):
        from .provider_privacy import resolve_privacy
        try:
            resolve_privacy(self.privacy_configuration_json,_json(self.model_profile_json),
                base_url=self.base_url,inference_geo=self.inference_geo,parse=_json)
        except (ValueError,TypeError,KeyError,UnicodeError,RecursionError):
            raise TransportError() from None


def _json(raw):
    def pairs(values):
        result={}
        for key,value in values:
            if key in result:raise DuplicateJSONProperty(key)
            result[key]=value
        return result
    def invalid(_):raise TransportError()
    def number(raw):
        value=float(raw)
        if not math.isfinite(value):raise TransportError()
        return value
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=invalid,parse_float=number)


def _integer(value):
    if type(value) is not int or not 0<=value<2**53:raise TransportError()
    return value


def provider_usage(provider, payload, model_id, geo):
    """Normalize disjoint billable categories; preserve missing reasoning data."""
    if payload.get('model')!=model_id:raise TransportError()
    u=payload.get('usage')
    if type(u) is not dict:raise TransportError()
    if provider=='openai':
        if payload.get('service_tier')!='default':raise TransportError()
        cached=_integer(u['input_tokens_details']['cached_tokens'])
        input_total=_integer(u['input_tokens']);output=_integer(u['output_tokens'])
        if cached>input_total or _integer(u['total_tokens'])!=input_total+output:raise TransportError()
        reasoning=u.get('output_tokens_details',{}).get('reasoning_tokens')
        values=(input_total-cached,cached,0,0,0,output,reasoning)
    else:
        if u.get('service_tier') not in (None,'standard') or u.get('inference_geo') not in ({None,'global','not_available'} if geo is None else {geo}):raise TransportError()
        server=u.get('server_tool_use')
        if server is not None and (type(server) is not dict or any(v not in (None,0) for v in server.values())):
            raise TransportError()
        cached=_integer(u.get('cache_read_input_tokens') if u.get('cache_read_input_tokens') is not None else 0)
        created=_integer(u.get('cache_creation_input_tokens') if u.get('cache_creation_input_tokens') is not None else 0)
        detail=u.get('cache_creation') or {}
        short=_integer(detail.get('ephemeral_5m_input_tokens',0));long=_integer(detail.get('ephemeral_1h_input_tokens',0))
        if short+long>created:raise TransportError()
        values=(_integer(u['input_tokens']),cached,short,long,created-short-long,_integer(u['output_tokens']),None)
    if values[-1] is not None and _integer(values[-1])>values[-2]:raise TransportError()
    result=dict(provider=provider,modelId=model_id,serviceTier='default',**dict(zip(
        ('uncachedInputTokens','cachedInputTokens','cacheWrite5mTokens','cacheWrite1hTokens',
         'cacheWriteUnspecifiedTokens','outputTokens','reasoningOutputTokens'),values)))
    _validate('AgentProviderUsage',result)
    _integer(sum(values[:-1]))
    return result


def _retry_delay(headers):
    hint=headers.get('retry-after')
    if not hint:return None
    try:
        if hint.isascii() and hint.isdecimal():value=int(hint)*1000
        else:value=max(0,math.ceil((parsedate_to_datetime(hint)-datetime.now(timezone.utc)).total_seconds()*1000))
        return value if 0<=value<2**53 else None
    except (TypeError,ValueError,OverflowError):return None


def _work_ms(started):
    return max(1,(time.monotonic_ns()-started+999999)//1000000)


def _transport(library, inner, maximum, origin, path):
    class BoundedStream(library.AsyncByteStream):
        def __init__(self, stream):self.stream=stream
        async def __aiter__(self):
            size=0
            async for chunk in self.stream:
                size+=len(chunk)
                if size>maximum:raise EnvelopeExceeded()
                yield chunk
        async def aclose(self):await self.stream.aclose()
    class BoundedTransport(library.AsyncBaseTransport):
        async def handle_async_request(self,request):
            if (request.method!='POST' or str(request.url)!=origin+path
                    or request.headers.get('accept-encoding')!='identity'):
                raise TransportError()
            response=await inner.handle_async_request(request)
            if response.headers.get('content-encoding','identity')!='identity':
                await response.aclose();raise EnvelopeExceeded()
            return library.Response(response.status_code,headers=response.headers,
                stream=BoundedStream(response.stream),extensions=response.extensions)
        async def aclose(self):await inner.aclose()
    return BoundedTransport()


class OfficialTransport:
    """Reusable official connection; one invocation is never a retry loop."""
    def __init__(self,config:TransportConfig,boundary:ModelBoundary,*,api_key:str,network_transport=None):
        if type(api_key) is not str or not api_key:raise TransportError()
        library=httpx if config.provider=='openai' else httpx2
        # Frozen deterministic fixtures may inject the official in-memory mock.
        # An actual transport, including a custom network adapter, needs both
        # resolved policies before binding or constructing any provider client.
        if type(network_transport) is not library.MockTransport or config.privacy_configuration_json is not None:
            config.validate_privacy()
        # A separately launched worker must have explicit configuration. Reject
        # ambient header/account overrides instead of silently changing billing.
        if any(os.environ.get(k) for k in ('OPENAI_ORG_ID','OPENAI_PROJECT_ID','ANTHROPIC_CUSTOM_HEADERS')):
            raise TransportError()
        binder=getattr(boundary,'bind_transport',None)
        if binder is not None:
            if not callable(binder):raise TransportError()
            binder(config)
        self.config,self.boundary=config,boundary
        for name in ('openai','anthropic'):logging.getLogger(name).setLevel(logging.WARNING)
        origin='https://api.openai.com' if config.provider=='openai' else 'https://api.anthropic.com'
        path='/v1/responses' if config.provider=='openai' else '/v1/messages'
        network=network_transport or library.AsyncHTTPTransport(retries=0)
        client=library.AsyncClient(trust_env=False,follow_redirects=False,
            timeout=config.request_timeout_ms/1000,headers={'Accept-Encoding':'identity'},
            limits=library.Limits(max_connections=8,max_keepalive_connections=4),
            transport=_transport(library,network,config.max_response_bytes,origin,path))
        if config.provider=='openai':
            self.client=AsyncOpenAI(api_key=api_key,base_url=config.base_url,max_retries=0,http_client=client)
        else:
            self.client=AsyncAnthropic(api_key=api_key,base_url=config.base_url,max_retries=0,
                open_telemetry=False,http_client=client)

    async def close(self):await self.client.close()

    def _body(self,request,raw):
        c=self.config
        if (request['context']['model']['digest']!=c.model_profile_digest
                or request['requestTimeoutMs']>c.request_timeout_ms
                or len(raw.encode())>c.max_request_bytes):raise TransportError()
        body=_json(raw)
        allowed=({'input','instructions','tools','tool_choice','parallel_tool_calls','text','reasoning','include'}
                 if c.provider=='openai' else {'messages','system','tools','tool_choice','thinking'})
        if c.provider=='anthropic' and type(body) is dict and 'input' in body:
            from .anthropic_messages import messages_body
            if set(body)-{'input','instructions','tools','tool_choice','parallel_tool_calls','text','reasoning','include'}:
                raise TransportError()
            if ('include' in body and body['include']!=['reasoning.encrypted_content']
                    or any(type(tool) is not dict or tool.get('type')!='function' for tool in body.get('tools',[]))):
                raise TransportError()
            body=messages_body(body,_json)
            allowed=allowed|{'output_config'}
        if type(body) is not dict or set(body)-allowed:raise TransportError()
        if 'include' in body and (c.provider!='openai' or body['include']!=['reasoning.encrypted_content']):raise TransportError()
        for tool in body.get('tools',[]):
            if type(tool) is not dict or tool.get('type') not in (
                    ('function',) if c.provider=='openai' else (None,'custom')):raise TransportError()
        if c.provider=='openai':
            body.update(model=c.model_id,max_output_tokens=request['maxOutputTokens'],
                        store=False,background=False,service_tier='default',stream=False)
        else:
            body.update(model=c.model_id,max_tokens=request['maxOutputTokens'],stream=False,service_tier='standard_only')
        if len(json.dumps(body,ensure_ascii=False).encode())>c.max_request_bytes:raise TransportError()
        return body

    async def invoke(self,request:AgentModelInvocation)->AgentModelObservation:
        # The authenticated kernel revalidates private stored configuration and
        # input before returning a begun attempt. Wire equality alone is no grant.
        _validate('AgentModelInvocation',request)
        profile=_json(self.config.model_profile_json)
        expected=dict(ref=profile['id'],revision=profile['revision'],digest=self.config.model_profile_digest)
        if (request['context']['model']!=expected or request['maxOutputTokens']>request['grant']['reserved']['tokens']
                or request['requestTimeoutMs']>self.config.request_timeout_ms):raise TransportError()
        raw=await self.boundary.begin_model(request)
        started=time.monotonic_ns();usage=candidate=failure=reason=request_id=response_id=retry=evidence=None;issued=False
        try:
            body=self._body(request,raw)
            deadlines=[datetime.fromisoformat(value.replace('Z','+00:00')) for value in (
                request['grant']['expiresAt'],request['context']['authorizationHorizon'])]
            if any(value.utcoffset() is None for value in deadlines):raise TransportError()
            remaining=(min(deadlines)-datetime.now(timezone.utc)).total_seconds()
            if remaining<=0:raise LeaseExpired()
            timeout=min(request['requestTimeoutMs']/1000,remaining)
            async with asyncio.timeout(timeout):
                endpoint=self.client.responses if self.config.provider=='openai' else self.client.messages
                issued=True
                response=await endpoint.with_raw_response.create(**body,timeout=timeout)
                request_id=response.http_response.headers.get('x-request-id') or response.http_response.headers.get('request-id')
                evidence=json.dumps(dict(statusCode=response.http_response.status_code,
                    bodyBase64=base64.b64encode(response.http_response.content).decode(),requestId=request_id),separators=(',',':'))
                payload=_json(response.http_response.content)
                response_id=payload.get('id')
                usage=provider_usage(self.config.provider,payload,self.config.model_id,self.config.inference_geo)
                complete=(payload.get('status')=='completed' and payload.get('error') is None
                    if self.config.provider=='openai' else payload.get('stop_reason') in {'end_turn','tool_use','stop_sequence'})
                if complete:
                    if self.config.provider=='anthropic' and 'input' in _json(raw):
                        from .anthropic_messages import accepted_response
                        payload=accepted_response(payload,usage)
                    encoded_candidate=json.dumps(payload,ensure_ascii=False,separators=(',',':'))
                    encoded_candidate.encode('utf-8')
                    candidate=encoded_candidate
                else:
                    failure,reason='provider-unavailable','provider-incomplete-output'
                    retry=_retry_delay(response.http_response.headers)
        except asyncio.CancelledError:
            await asyncio.shield(self.boundary.finish_model(request,usage=None,candidate_json=None,
                provider_evidence_json=evidence,
                failure='cancelled',reason='cancelled-unknown-completion',request_id=request_id,
                response_id=response_id,work_ms=_work_ms(started),retry_after_ms=None))
            raise
        except Exception as error:
            status=getattr(error,'status_code',None)
            logging.getLogger(__name__).warning('Provider transport failed: type=%s status=%s issued=%s',
                type(error).__name__,status,issued)
            request_id=getattr(error,'request_id',None) or request_id
            failure='invalid-input' if status in (400,422) else 'not-authorized' if status in (401,403) else 'rate-limited' if status==429 else 'provider-unavailable'
            reason='provider-http-error' if status is not None else 'provider-unknown-completion'
            if isinstance(error,(TimeoutError,OpenAITimeout,AnthropicTimeout)):
                reason='provider-request-timeout'
            if status==404 and (self.config.provider=='anthropic' or getattr(error,'code',None)=='model_not_found'):
                # An explicit unavailable model is a configuration/access
                # blocker, not proof of zero usage or of a specific retirement.
                # Other missing resources and transient errors stay distinct.
                failure,reason='invalid-input','provider-model-unavailable'
            if isinstance(error,UnicodeError):reason='provider-invalid-output'
            headers=getattr(getattr(error,'response',None),'headers',{})
            retry=_retry_delay(headers)
            if status is not None:
                evidence=json.dumps(dict(statusCode=status,
                    bodyBase64=base64.b64encode(error.response.content).decode(),requestId=request_id),separators=(',',':'))
            if not issued:
                # A locally rejected body never reached the SDK. Its token/cost
                # consumption is known zero, while local elapsed work is measured.
                usage=dict(provider=self.config.provider,modelId=self.config.model_id,
                    uncachedInputTokens=0,cachedInputTokens=0,cacheWrite5mTokens=0,
                    cacheWrite1hTokens=0,cacheWriteUnspecifiedTokens=0,outputTokens=0,
                    reasoningOutputTokens=None,serviceTier='default')
                failure,reason='invalid-input','unsupported-provider-input'
                if isinstance(error,LeaseExpired):failure,reason='cancelled','lease-expired-before-provider'
            # No exception message, payload, credentials or raw SDK trace is
            # published. A rejected/malformed/timeout response without trustworthy
            # usage remains UNKNOWN; no undocumented zero-cost refund is inferred.
        return await self.boundary.finish_model(request,usage=usage,candidate_json=candidate,
            provider_evidence_json=evidence,
            failure=failure,reason=reason,request_id=request_id,response_id=response_id,
            work_ms=_work_ms(started),retry_after_ms=retry)
