"""Bounded internal control metadata, separate from private SDK/source content.

Only the typed class below gets the control encoding. A user/model dictionary
with the same keys remains private. Control records grant no OS permission and
cannot prove goal completion; the kernel journals remain authoritative.
"""
from dataclasses import asdict,dataclass
import json
from temporalio.api.common.v1 import Payload
from temporalio.contrib.openai_agents import OpenAIPayloadConverter
from temporalio.converter import DefaultFailureConverter
from temporalio.exceptions import ApplicationError,CancelledError,TimeoutError
from .model_rpc import _control
from .transport import _validate
from .protocol_metadata import ProtocolMetadata,ProtocolCommand,INPUT_ENCODING as METADATA_INPUT,command

CONTROL_ENCODING=b'json/os-agent-control-v1'
READ_CONTROL_ENCODING=b'json/os-agent-read-control-v1'
JOIN_CONTROL_ENCODING=b'json/os-agent-source-join-control-v1'
WAIT_TYPE='OS_AGENT_WAIT/1'


@dataclass(frozen=True)
class WorkflowControl:
    rootId:str
    taskId:str
    operationId:str|None
    status:str
    notBefore:str|None=None
    profile:str='agent-control/1'

    def __post_init__(self):_validate('AgentWorkflowControl',asdict(self))


@dataclass(frozen=True)
class ReadControl:
    rootId:str
    taskId:str
    operationId:str
    state:str
    goalDigest:str
    missingCriteria:list[str]
    profile:str='agent-read-control/1'

    def __post_init__(self):_validate('AgentReadControl',asdict(self))


@dataclass(frozen=True)
class MemoryReadControl(ReadControl):
    profile:str='agent-memory-read-control/1'

    def __post_init__(self):_validate('AgentMemoryReadControl',asdict(self))


@dataclass(frozen=True)
class PartialReadControl(ReadControl):
    profile:str='agent-partial-read-control/1'

    def __post_init__(self):_validate('AgentPartialReadControl',asdict(self))


def partial_read_context(context):
    harness=context['harness']
    return (harness['ref']=='partial-evidence-read/1'
        or harness['ref'].startswith('governed-read-discovery/') and harness['revision']==2)


@dataclass(frozen=True)
class SourceJoinReadControl:
    rootId:str
    taskId:str
    operationId:str
    state:str
    goalDigest:str
    missingCriteria:list[str]
    profile:str='agent-source-join-control/1'

    def __post_init__(self):_validate('AgentSourceChildJoinControl',asdict(self))


@dataclass(frozen=True)
class PlannedReadControl:
    rootId:str
    taskId:str
    operationId:str
    state:str
    goalDigest:str
    missingCriteria:list[str]
    planRevision:int
    planStateJson:str
    profile:str='agent-planned-read-control/1'

    def __post_init__(self):_validate('AgentPlannedReadControl',asdict(self))


def read_control(value):
    # Planned controls contain private model metadata. Keep them out of the
    # plaintext safe-control encoding; the existing history codec encrypts them.
    if value.get('profile')=='agent-planned-read-control/1':
        _validate('AgentPlannedReadControl',value);return value
    if value.get('profile')=='agent-source-join-control/1':return SourceJoinReadControl(**value)
    if value.get('profile')=='agent-memory-read-control/1':return MemoryReadControl(**value)
    if value.get('profile')=='agent-partial-read-control/1':return PartialReadControl(**value)
    return ReadControl(**value)


class AgentPayloadConverter(OpenAIPayloadConverter):
    def to_payloads(self,values):
        result=[]
        for value in values:
            if isinstance(value,ProtocolMetadata):
                raw=json.dumps(dict(kind=value.kind,value=value.value),sort_keys=True,separators=(',',':')).encode()
                result.append(Payload(metadata={'encoding':METADATA_INPUT},data=raw))
            elif isinstance(value,SourceJoinReadControl):
                raw=json.dumps(asdict(value),sort_keys=True,separators=(',',':')).encode()
                result.append(Payload(metadata={'encoding':JOIN_CONTROL_ENCODING},data=raw))
            elif isinstance(value,(WorkflowControl,ReadControl)):
                raw=json.dumps(asdict(value),sort_keys=True,separators=(',',':')).encode()
                result.append(Payload(metadata={'encoding':READ_CONTROL_ENCODING if isinstance(value,ReadControl) else CONTROL_ENCODING},data=raw))
            else:result.extend(super().to_payloads([value]))
        return result

    def from_payloads(self,payloads,type_hints=None):
        result=[]
        for index,payload in enumerate(payloads):
            if payload.metadata.get('encoding')==METADATA_INPUT:
                value=_control(payload.data)
                if type(value) is not dict or set(value)!={'kind','value'}:raise ValueError('Invalid protocol metadata')
                if value['kind'] in {'operation','checkpoint'}:
                    command(value['kind'],value['value'])
                    result.append(ProtocolCommand(value['value']))
                elif value['kind']=='model-result':
                    _validate('AgentResultReference',value['value']);result.append(value['value'])
                else:raise ValueError('Invalid protocol metadata')
            elif payload.metadata.get('encoding')==JOIN_CONTROL_ENCODING:
                value=_control(payload.data);_validate('AgentSourceChildJoinControl',value)
                result.append(SourceJoinReadControl(**value))
            elif payload.metadata.get('encoding')==READ_CONTROL_ENCODING:
                value=_control(payload.data)
                if value.get('profile')=='agent-memory-read-control/1':result.append(MemoryReadControl(**value))
                elif value.get('profile')=='agent-partial-read-control/1':result.append(PartialReadControl(**value))
                else:
                    _validate('AgentReadControl',value);result.append(ReadControl(**value))
            elif payload.metadata.get('encoding')==CONTROL_ENCODING:
                value=_control(payload.data);_validate('AgentWorkflowControl',value)
                result.append(WorkflowControl(**value))
            else:result.extend(super().from_payloads([payload],None if type_hints is None else [type_hints[index]]))
        return result


class AgentFailureConverter(DefaultFailureConverter):
    """Preserve only typed control waits; discard arbitrary text and causes."""
    def to_failure(self,exception,payload_converter,failure):
        failure.Clear()
        if (isinstance(exception,ApplicationError) and exception.type==WAIT_TYPE and len(exception.details)==1
                and isinstance(exception.details[0],WorkflowControl)):
            safe=ApplicationError('agent_wait',exception.details[0],type=WAIT_TYPE,non_retryable=True)
        elif isinstance(exception,CancelledError):safe=CancelledError('agent_cancelled')
        elif isinstance(exception,TimeoutError):safe=TimeoutError('agent_timed_out',type=exception.type,last_heartbeat_details=[])
        else:safe=ApplicationError('agent_failed',type='OS_AGENT_SAFE_FAILURE/1',non_retryable=True)
        super().to_failure(safe,payload_converter,failure)

    def from_failure(self,failure,payload_converter):
        # Temporal wraps an Activity's application failure. Preserve only the
        # closed control record, never the wrapper's text, identity or trace.
        if failure.HasField('activity_failure_info') and failure.HasField('cause'):
            cause=failure.cause
            if cause.HasField('application_failure_info') and cause.application_failure_info.type==WAIT_TYPE:
                return self.from_failure(cause,payload_converter)
        if failure.HasField('application_failure_info') and failure.application_failure_info.type==WAIT_TYPE:
            values=payload_converter.from_payloads(failure.application_failure_info.details.payloads)
            if len(values)==1 and isinstance(values[0],WorkflowControl):
                return ApplicationError('agent_wait',values[0],type=WAIT_TYPE,non_retryable=True)
        if failure.HasField('canceled_failure_info'):return CancelledError('agent_cancelled')
        if failure.HasField('timeout_failure_info'):
            from temporalio.exceptions import TimeoutType
            return TimeoutError('agent_timed_out',type=TimeoutType(failure.timeout_failure_info.timeout_type),last_heartbeat_details=[])
        return ApplicationError('agent_failed',type='OS_AGENT_SAFE_FAILURE/1',non_retryable=True)


class ReadFailureConverter(AgentFailureConverter):
    """Read journeys retain only the safe timeout type of an Activity wrapper."""
    def from_failure(self,failure,payload_converter):
        if (failure.HasField('activity_failure_info') and failure.HasField('cause')
                and failure.cause.HasField('timeout_failure_info')):
            return super().from_failure(failure.cause,payload_converter)
        return super().from_failure(failure,payload_converter)
