"""Independent SDK error mapping over the shared rotating-token guard."""
from pathlib import Path

from ._projected_token import ProjectedTokenReader
from .model_rpc import ModelRPCError


class ProjectedWorkloadToken(ProjectedTokenReader):
    def __init__(self,root:Path,filename='token'):
        try:super().__init__(root,filename)
        except Exception:raise ModelRPCError('INVALID') from None

    def _read(self):
        try:return super().read()
        except Exception:raise ModelRPCError('UNAVAILABLE') from None

    def read(self):
        """Synchronous SDK credential callback with the original public errors."""
        return self._read()
