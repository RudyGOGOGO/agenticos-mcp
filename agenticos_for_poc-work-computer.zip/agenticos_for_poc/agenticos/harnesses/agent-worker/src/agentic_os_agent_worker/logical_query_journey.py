"""Linked objective parts and current bounded windows over the existing journey."""
from copy import deepcopy
import json
from uuid import UUID,uuid5

from agents.items import ToolCallOutputItem

from .checkpoint import tool_alias
from .query_context import FACT_FORMAT,_window
from .sdk_model import SDKModelPolicyError
from .transport import _SCHEMA,_validate


def selected(context):
    return context['harness']['ref']=='focused-child-reads/1' and context['harness']['revision']==3


def instructions(capabilities,providers):
    definitions={};pending=['AgentQueryIntentPartDraft']
    def references(node):
        if isinstance(node,dict):
            if '$ref' in node:pending.append(node['$ref'].removeprefix('#/$defs/'))
            for child in node.values():references(child)
        elif isinstance(node,list):
            for child in node:references(child)
    while pending:
        name=pending.pop()
        if name in definitions:continue
        definitions[name]=_SCHEMA['$defs'][name];references(definitions[name])
    return ('Interpret the complete original request as linked AgentQueryIntentPartDraft JSON parts. '
        'Return exactly one bounded part per response, preserving every requested metric and query. '
        'Start ordinal0/priorDigest:null/header populated; later parts increment ordinal, use the last Core receipt partDigest '
        'as priorDigest, and set header:null. Criteria UUIDs are distinct across parts; never repeat a metric. '
        'A repeated query key must preserve its exact definition. Each declared query must serve a metric in the accepted prefix. '
        'Set more:true only while requested metrics remain; the final part uses more:false. '
        'The first header selects an exact first-part criterion/string identity field for target reads and the requested join policy. '
        'Use all unless the owner explicitly requests any or a minimum quorum. Do not guess IDs or weaken completeness. '
        'Core retains each accepted part; a receipt grants no resource authority. Contracts: '+json.dumps(definitions)+
        '. Reviewed metadata: '+json.dumps(dict(capabilities=[v for v in capabilities if v['kind']=='read'],providers=providers)))


def accept_part(value,receipt):
    """Keep only a small checked receipt, never the cumulative raw objective."""
    if value['phase']!='objective':raise SDKModelPolicyError()
    _validate('AgentQueryIntentPartState',receipt)
    context=value['start']['context']
    if receipt['context']!=context:raise SDKModelPolicyError()
    prior=None if value['goalDraftJson'] is None else json.loads(value['goalDraftJson'])
    if prior is not None:
        _validate('AgentQueryIntentPartState',prior)
        if prior['sealed'] or receipt['ordinal']!=prior['ordinal']+1:raise SDKModelPolicyError()
    elif receipt['ordinal']!=0:raise SDKModelPolicyError()
    if receipt['sealed']!=(receipt['goalDigest'] is not None):raise SDKModelPolicyError()
    if not receipt['sealed']:
        return receipt,[dict(role='user',content=json.dumps(dict(
            originalRequest=value['start']['input'],acceptedPart=receipt,
            next='Continue the remaining requested metrics without repeating accepted criteria.')))]
    index=dict(schema='agent-query-intent-index/2',context=deepcopy(context),goalDigest=receipt['goalDigest'],
        queryCount=receipt['queryCount'],criterionCount=receipt['criterionCount'])
    _validate('AgentLogicalQueryIntentIndex',index)
    return index,None


def saved_queries(value):
    """Restore only the bounded descriptors used by this pending SDK round.

    Core query-checkpoint-state rechecks all current query scope before the
    private checkpoint is loaded; tool resolution still checks fresh authority.
    The encrypted journey field changes to its existing fact-window purpose
    when the source binding/child phase starts.
    """
    index=json.loads(value['goalDraftJson']);_validate('AgentLogicalQueryIntentIndex',index)
    raw=value.get('sourceQueryWindowJson')
    if type(raw) is not str:raise SDKModelPolicyError()
    try:cache=json.loads(raw)
    except (ValueError,TypeError):raise SDKModelPolicyError() from None
    if (index['context']!=value['start']['context'] or index['goalDigest']!=value['goalDigest']
            or set(cache)!={'schema','goalDigest','queries'} or cache['schema']!='agent-logical-query-window/1'
            or cache['goalDigest']!=index['goalDigest'] or type(cache['queries']) is not list or len(cache['queries'])>2
            or len(value['sourceQueryWindowJson'].encode())>24576):raise SDKModelPolicyError()
    for query in cache['queries']:_validate('AgentAnalysisQuery',query)
    if len({query['key'] for query in cache['queries']})!=len(cache['queries']):raise SDKModelPolicyError()
    return cache['queries']


async def current_window(value,boundary,sequence,*,additional=(),phase='preflight'):
    from .child_read_journey import _deferred
    index=json.loads(value['goalDraftJson']);_validate('AgentLogicalQueryIntentIndex',index)
    context=value['start']['context']
    if index['context']!=context or index['goalDigest']!=value['goalDigest'] or sequence.pending is not None:raise SDKModelPolicyError()
    previous=value.get('continuationInputJson');references=[]
    if previous is not None:
        window=json.loads(json.loads(previous)[0]['content'])
        if window['schema']!=FACT_FORMAT or window['goalDigest']!=index['goalDigest']:raise SDKModelPolicyError()
        references=window['results']
        if any(v['payload']['schemaRef']!='AgentQueryFactSet' for v in references):raise SDKModelPolicyError()
    references=[*references,*additional]
    ident=str(uuid5(UUID(sequence.snapshot()['sdkInstanceId']),
        'logical-progress/'+str(sequence.snapshot()['turn'])+'/'+phase))
    result=await boundary.logical_query_progress(context,index['goalDigest'],ident,references)
    _validate('AgentLogicalQueryProgressState',result)
    if result['kind']=='storage':raise _deferred(context,sequence.snapshot()['parentOperationId'],result['preparation'])
    if result['index']!=index or result['allComplete']!=(not bool(result['queries'])):raise SDKModelPolicyError()
    reference=result['result'];_validate('AgentResultReference',reference)
    if reference['payload']['schemaRef']!='AgentQueryFactSet' or any(reference[k]!=context[k] for k in ('subject','taskId','rootId')):
        raise SDKModelPolicyError()
    sequence.binding['inputResults']=[deepcopy(reference)];queries=result['queries'];frontiers={}
    cache=dict(schema='agent-logical-query-window/1',goalDigest=index['goalDigest'],queries=queries)
    raw=json.dumps(cache,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
    if len(raw.encode())>24576:raise SDKModelPolicyError()
    value['sourceQueryWindowJson']=raw
    for frontier in result['frontiers']:
        matches=[query for query in queries if query['key']==frontier['queryKey']]
        if len(matches)!=1 or frontier['nextCursor'] is None:raise SDKModelPolicyError()
        tool=tool_alias(matches[0]['capability'])
        frontiers[(tool,frontier['queryDigest'])]=dict(toolName=tool,queryKeys=[frontier['queryKey']],
            **{k:frontier[k] for k in ('queryDigest','pageOrdinal','nextCursor')})
    return _window(sequence,frontiers,index['goalDigest'],format=FACT_FORMAT),queries


async def completed_window(value,boundary,sequence,result):
    references=[]
    for item in result.new_items:
        if not isinstance(item,ToolCallOutputItem):continue
        output=json.loads(item.output);_validate('AgentAcceptedQueryReferenceContext',output)
        if output['result'] not in sequence.snapshot()['inputResults']:raise SDKModelPolicyError()
        references.append(output['result'])
    if not references:return None
    window,_=await current_window(value,boundary,sequence,additional=references,phase='completed')
    return window


def rebound_window(sequence,goal_digest,reference):
    _validate('AgentResultReference',reference);context=sequence.snapshot()['context']
    if (sequence.pending is not None or reference['payload']['schemaRef']!='AgentQueryFactSet'
            or any(reference[key]!=context[key] for key in ('subject','taskId','rootId'))):raise SDKModelPolicyError()
    sequence.binding['inputResults']=[deepcopy(reference)]
    return _window(sequence,{},goal_digest,format=FACT_FORMAT)


async def stage_part(driver,boundary,context,operation):
    from .journey_control import _control,_wait
    while True:
        try:return await boundary.query_intent_part(context,operation)
        except Exception as error:
            control=_wait(error,context,operation)
            if control is None:raise
            if control.status in {'configuration-required','scope-changed','model-failed','storage-failed'}:return control
            await driver._pause(control)
            if driver.stopped:return _control(context,'stopped')
            if driver._expired():return _control(context,'authorization-expired')
