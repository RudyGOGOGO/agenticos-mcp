"""Explicit Cloud transport for the existing assigned workflow service.

Only the connection changes. The caller retains the original private converter,
SDK plugin, queues, workflow start, deadline and replay checks. Configuration is
read through the existing bounded private operator-file boundary, never envconfig.
"""
import asyncio
from dataclasses import dataclass,field
from datetime import datetime,timezone,timedelta
import hashlib
import re
from uuid import UUID

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.x509.oid import ExtendedKeyUsageOID
from temporalio.api.workflowservice.v1 import DescribeNamespaceRequest
from temporalio.client import Client
from temporalio.service import TLSConfig

from .sdk_model import SDKModelPolicyError


@dataclass(frozen=True)
class CloudTemporalConnection:
    configuration:dict=field(repr=False)

    def __post_init__(self):
        from copy import deepcopy
        object.__setattr__(self,'configuration',deepcopy(self.configuration))
        self.check()

    @property
    def namespace(self):return self.configuration['namespace']

    @property
    def target(self):return self.server_name+':7233'

    @property
    def server_name(self):
        return self.configuration['endpoint'] if self.configuration.get('profile')=='temporal-self-hosted-mtls/1' else self.namespace+'.tmprl.cloud'

    def check(self):
        try:
            value=self.configuration
            self_hosted=value.get('profile')=='temporal-self-hosted-mtls/1' if type(value) is dict else False
            if (type(value) is not dict or set(value)!={'profile','installationId','namespace','namespaceId',
                    'retentionDays','serverCA','serverCASha256','certificate','privateKey','resumeExisting'}|(
                        {'endpoint','serverName'} if self_hosted else set())
                    or value['profile'] not in {'temporal-cloud-mtls/1','temporal-self-hosted-mtls/1'}
                    or any(type(value[k]) is not str for k in value if k not in {'retentionDays','resumeExisting'})
                    or str(UUID(value['installationId']))!=value['installationId']
                    or str(UUID(value['namespaceId']))!=value['namespaceId']
                    or len(value['namespace'])>128
                    or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}' if self_hosted else
                        r'[a-z0-9][a-z0-9-]*\.[a-z0-9][a-z0-9-]*',value['namespace']) is None
                    or type(value['retentionDays']) is not int or not 1<=value['retentionDays']<=90
                    or type(value['resumeExisting']) is not bool):raise ValueError()
            if self_hosted and (value['namespace']=='default' or value['serverName']!=value['endpoint']
                    or value['endpoint'].endswith('.tmprl.cloud') or re.fullmatch(
                        r'(?=.{1,253}\Z)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+',
                        value['endpoint']) is None):raise ValueError()
            ca,cert,key=(value[k].encode('ascii') for k in ('serverCA','certificate','privateKey'))
            if any(not 1<=len(raw)<=65536 for raw in (ca,cert,key)):raise ValueError()
            if hashlib.sha256(ca).hexdigest()!=value['serverCASha256']:raise ValueError()
            if not x509.load_pem_x509_certificates(ca):raise ValueError()
            leaf=x509.load_pem_x509_certificates(cert)[0]
            private=serialization.load_pem_private_key(key,password=None)
            public=lambda k:k.public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
            if (public(leaf.public_key())!=public(private.public_key())
                    or not leaf.not_valid_before_utc<=datetime.now(timezone.utc)<leaf.not_valid_after_utc):raise ValueError()
            try:
                if ExtendedKeyUsageOID.CLIENT_AUTH not in leaf.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value:
                    raise ValueError()
            except x509.ExtensionNotFound:pass
            return TLSConfig(server_root_ca_cert=ca,domain=self.server_name,
                client_cert=cert,client_private_key=key)
        except Exception:raise SDKModelPolicyError() from None

    async def connect(self,*,data_converter,plugins):
        try:
            client=await asyncio.wait_for(Client.connect(self.target,namespace=self.namespace,tls=self.check(),
                identity='agentic-os:'+self.configuration['installationId'],data_converter=data_converter,plugins=plugins),10)
            if not await asyncio.wait_for(client.service_client.check_health(),5):raise ValueError()
            response=await client.workflow_service.describe_namespace(DescribeNamespaceRequest(namespace=self.namespace),
                timeout=timedelta(seconds=5))
            info=response.namespace_info;retention=response.config.workflow_execution_retention_ttl
            if (info.name!=self.namespace or info.id!=self.configuration['namespaceId'] or info.state!=1
                    or retention.seconds!=self.configuration['retentionDays']*86400 or retention.nanos!=0):raise ValueError()
            return client
        except Exception:raise SDKModelPolicyError() from None
