"""Explicit worker wiring; no server, provider, key, namespace or root default."""
from datetime import timedelta
from temporalio.converter import DataConverter
from temporalio.exceptions import ApplicationError
from .policy import WorkerPolicy
from .private_history import AgentHistoryCodec,PrivateHistoryUnavailable
from .temporal_driver import AgentActivities,AgentTaskDriver,DurableModelProvider
from .workflow_control import AgentPayloadConverter,AgentFailureConverter,ReadFailureConverter,WorkflowControl,WAIT_TYPE


class AgentTemporalCodec(AgentHistoryCodec):
    def with_context(self,context):
        return AgentTemporalCodec(self.store,self.keys,self.context,self.namespace,
            serialization_context=context,key_id=self.key_id)

    async def encode(self,payloads):
        try:return await super().encode(payloads)
        except PrivateHistoryUnavailable as error:
            status=('waiting-resources' if error.code=='CAPACITY' else 'scope-changed' if error.code=='DENIED'
                else 'configuration-required' if error.code in {'PROFILE_DISABLED','UNAUTHENTICATED','INVALID'} else 'waiting-reconciliation')
            operation=error.write_id if status=='waiting-resources' else None
        control=WorkflowControl(self.context['rootId'],self.context['taskId'],operation,status)
        raise ApplicationError('agent_wait',control,type=WAIT_TYPE,non_retryable=True)


class ObservedHistoryBoundary:
    def __init__(self,boundary):self.boundary=boundary
    async def lookup_history(self,*args):return await self.boundary.observe_history(*args)
    async def put_history(self,*args):return await self.boundary.put_history(*args)
    def __getattr__(self,name):
        if name!='store_history':raise AttributeError(name)
        method=getattr(self.boundary,name)
        async def observed(*args):return await method(*args,observe=True)
        return observed


def agent_converter(boundary,history_keys,context,namespace,history_key_id,*,observe_history=False):
    if type(observe_history) is not bool:raise ValueError('Explicit history observation profile required')
    history=ObservedHistoryBoundary(boundary) if observe_history else boundary
    return DataConverter(payload_converter_class=AgentPayloadConverter,
        payload_codec=AgentTemporalCodec(history,history_keys,context,namespace,key_id=history_key_id),
        failure_converter_class=ReadFailureConverter if observe_history else AgentFailureConverter)


def agent_plugin(model_provider,*,operation_timeout_ms):
    # Dependency verification happens before a worker can start or execute the
    # public SDK checkpoint loader. The independently locked graph is unchanged.
    return WorkerPolicy(operation_timeout_ms).plugin(DurableModelProvider(model_provider))


def agent_worker_options(boundary,*,planning_context=None,planning_phase=None):
    activities=AgentActivities(boundary,planning_context=planning_context,planning_phase=planning_phase)
    return dict(workflows=[AgentTaskDriver],activities=activities.registered(),
        max_concurrent_activities=4,max_concurrent_workflow_tasks=4,max_cached_workflows=4,
        graceful_shutdown_timeout=timedelta(seconds=3))
