"""Private lookup draft feedback; Core remains the completion authority."""
from copy import deepcopy
import json

from .transport import _validate
from .checkpoint import tool_alias

FEEDBACK='Lookup source-reference correction required.'
CONTINUATION='Lookup accepted-source continuation.'
PAGE_LIMIT='This proposed goal needs more than the four source pages permitted by AgentTableReadAnswerDraft.'


def accepted_pages(messages,context):
    for message in messages:
        if message.get('type')!='function_call_output' or type(message.get('output')) is not str:continue
        try:value=json.loads(message['output'])
        except (ValueError,TypeError):continue
        if type(value) is not dict or value.get('schema') not in {'agent-accepted-read/1','agent-accepted-read-ref/1'}:continue
        _validate('AgentAcceptedReadContext' if 'page' in value else 'AgentAcceptedReadReferenceContext',value)
        if any(value['result'][key]!=context[key] for key in ('subject','taskId','rootId')):continue
        yield message,value


def guidance(item):
    """Closed advisory metadata; malformed declarations cannot authorize work."""
    try:
        comment=json.loads(item['inputSchemaJson']).get('$comment')
        value=json.loads(comment) if type(comment) is str and comment.startswith('{') else None
        if value is None:return []
        if (set(value)!={'schema','mappingPin','prerequisites'} or value['schema']!='agent-read-guidance/1'
                or type(value['mappingPin']) is not str or len(value['mappingPin'])!=64
                or type(value['prerequisites']) is not list or len(value['prerequisites'])>16):return []
        for row in value['prerequisites']:
            if (type(row) is not dict or set(row)!={'sourceCapabilityRef','sourceField','sourceArgumentsJson','readCapabilityRef','argumentField'}
                    or any(type(v) is not str or not 1<=len(v)<=256 for v in row.values())
                    or type(json.loads(row['sourceArgumentsJson'])) is not dict):return []
        return value['prerequisites']
    except (KeyError,TypeError,ValueError):return []


def accepted_reads(messages,context,capabilities):
    aliases={tool_alias(item['capability']):item for item in capabilities}
    calls={item['call_id']:item for item in messages if item.get('type')=='function_call'}
    for message,value in accepted_pages(messages,context):
        call=calls.get(message.get('call_id'));item=aliases.get(call.get('name')) if call else None
        if item is not None:yield message,value,item,call


def lookup_goal_feedback(raw,messages,context,capabilities=()):
    try:
        draft=json.loads(raw) if type(raw) is str else raw
        _validate('AgentReadGoalDraft',draft)
    except Exception:return ['Return the declared AgentReadGoalDraft JSON contract.']
    observed={(r['providerId'],r['resourceType'],r['externalId'])
        for _,value in accepted_pages(messages,context)
        for r in (value['page']['evidence']['resourceRefs'] if 'page' in value else value['resources'])}
    issues=[]
    if any((r['providerRef'],r['resourceType'],r['externalId']) not in observed
            for criterion in draft['criteria'] for r in criterion['resources']):
        issues.append('Copy resourceType and externalId exactly from accepted evidence.resourceRefs, including composite IDs. '
            'A parent object ID cannot replace a returned row ID. Complete all supporting reads declared by reviewed metadata before proposing the goal.')
        reads=list(accepted_reads(messages,context,capabilities));choices=[]
        for criterion in draft['criteria']:
            wrong=[r for r in criterion['resources'] if (r['providerRef'],r['resourceType'],r['externalId']) not in observed]
            if not wrong:continue
            selected=[value for _,value,item,_ in reads if item['capability']==criterion['capability']]
            available={(r['providerId'],r['resourceType'],r['externalId']) for value in selected
                for r in (value['page']['evidence']['resourceRefs'] if 'page' in value else value['resources'])}
            if not available:available=observed
            choices.append(dict(capability=criterion['capability'],unobserved=wrong,
                acceptedResources=[dict(providerRef=p,resourceType=t,externalId=i) for p,t,i in sorted(available)]))
        encoded=json.dumps(choices,sort_keys=True,ensure_ascii=False,separators=(',',':'))
        if len(encoded.encode())<=8192:issues.append('Correct every unobserved selector in this proposal using these exact accepted choices: '+encoded)
    selected=[item for item in capabilities if any(item['capability']==criterion['capability'] for criterion in draft['criteria'])]
    reads=list(accepted_reads(messages,context,capabilities));missing=[]
    if context['harness']['revision'] in {2,3,4,5}:
        # The declared table-answer contract selects at most four pages.
        # Detect an impossible immutable goal before Core binds it. This is
        # advice only: the model still selects the goal and accepted results.
        from itertools import combinations
        required={(index,r['providerRef'],r['resourceType'],r['externalId'])
            for index,criterion in enumerate(draft['criteria']) for r in criterion['resources']}
        pages=[]
        for _,value,item,_ in reads:
            resources=value['page']['evidence']['resourceRefs'] if 'page' in value else value['resources']
            fields=set(value['page']['evidence']['publicFields'] if 'page' in value else value['fields'])
            covered={(index,r['providerId'],r['resourceType'],r['externalId'])
                for index,criterion in enumerate(draft['criteria'])
                if criterion['capability']==item['capability'] and set(criterion['fields'])<=fields
                for r in resources}&required
            if covered and covered not in pages:pages.append(covered)
        if (len(pages)>4 and len(pages)<=16 and required<=set().union(*pages)
                and not any(required<=set().union(*choice) for size in range(1,5) for choice in combinations(pages,size))):
            counts={}
            for page in pages:
                refs={draft['criteria'][index]['capability']['ref'] for index,*_ in page}
                for ref in refs:counts[ref]=counts.get(ref,0)+1
            issues.append(PAGE_LIMIT+' '
                'The limit counts accepted result objects, not criteria: one capability can require several pages. '
                'Contributing accepted page counts by capability: '+json.dumps(counts,sort_keys=True)+'. '
                'Keep supporting discovery reads in the causal context without a display criterion when their own tables were not requested. Core still retains those sources for derived output. Required display fields apply only to selected deliverables, not every supporting source. Reconsider which criteria actually answer the original question rather than repeating this over-capacity goal. '
                'Revise the goal to fit the declared four-page answer limit before binding it. Do not omit requested facts.')
    for item in selected:
        for dependency in guidance(item):
            source=[value for _,value,cap,_ in reads if cap['capability']['ref']==dependency['sourceCapabilityRef'] and 'page' in value]
            targets=[cap for cap in capabilities if cap['capability']['ref']==dependency['readCapabilityRef']]
            if len(targets)!=1:issues.append('Required supporting capability is unavailable.');continue
            if not source:
                issues.append('Read required discovery '+dependency['sourceCapabilityRef']+' with '+dependency['sourceArgumentsJson']+' before proposing this goal.');continue
            values={field['value'] for value in source for row in value['page']['records'] for field in row
                if field['name']==dependency['sourceField'] and type(field['value']) is str}
            completed=set()
            for _,_,cap,call in reads:
                if cap['capability']!=targets[0]['capability']:continue
                try:argument=json.loads(call['arguments']).get(dependency['argumentField'])
                except (TypeError,ValueError):continue
                if type(argument) is str:completed.add(argument)
            for value in sorted(values-completed):missing.append(dict(capability=targets[0]['capability'],arguments={dependency['argumentField']:value}))
    if missing:
        encoded=json.dumps(missing,sort_keys=True,separators=(',',':'))
        issues.append('Missing accepted supporting reads, including zero-related-record objects: '+encoded if len(encoded)<=4096 else 'Required supporting reads exceed bounded feedback capacity.')
    return issues


def lookup_repair_instructions(messages,operation_id):
    """Promote only a static SDK constraint, never source identifiers or text."""
    from .memory_output import analysis_feedback_message
    if type(messages) is not list or type(operation_id) is not str:return ''
    expected=analysis_feedback_message('',operation_id)['id']
    for message in reversed(messages):
        if type(message) is not dict:continue
        if (message.get('type')!='message' or message.get('role')!='assistant'
                or message.get('id')!=expected or message.get('status')!='completed'):continue
        text=' '.join(part.get('text','') for part in message.get('content',[])
            if part.get('type')=='output_text')
        if not text.startswith(FEEDBACK):return ''
        if PAGE_LIMIT not in text:return ''
        return (' The previous goal was rejected before binding because it selected more than four source pages. '
            'Return a revised goal, not the rejected goal again. Re-evaluate every criterion against the original user question. '
            'An identifier lookup or supporting computation read does not require a display criterion unless its own output was requested. '
            'Its accepted evidence remains available for the requested derived output. Keep every requested fact and all required supporting reads; '
            'select only the requested deliverables within the existing four-page bound. ')
    return ''


def lookup_feedback_continuation(messages,context,feedback,operation,capabilities=()):
    from .memory_output import analysis_feedback_message
    current=deepcopy(messages)
    preserve={row['sourceCapabilityRef'] for item in capabilities for row in guidance(item)}
    protected={message.get('call_id') for message,_,item,_ in accepted_reads(current,context,capabilities)
        if item['capability']['ref'] in preserve}
    # Existing reference-only context carries the exact accepted causal head.
    # The kernel retains the complete page; this private repair needs row IDs.
    for message,value in accepted_pages(current,context):
        if 'page' not in value:continue
        if message.get('call_id') in protected:continue
        resources={json.dumps(r,sort_keys=True,separators=(',',':')):r for r in value['page']['evidence']['resourceRefs']}
        compact=dict(schema='agent-accepted-read-ref/1',result=value['result'],
            resources=list(resources.values()),fields=value['page']['evidence']['publicFields'])
        _validate('AgentAcceptedReadReferenceContext',compact)
        message['output']=json.dumps(compact,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
    current.append(analysis_feedback_message(feedback,operation))
    raw=json.dumps(current,sort_keys=True,separators=(',',':'))
    return raw if len(raw.encode())<=32768 else None
