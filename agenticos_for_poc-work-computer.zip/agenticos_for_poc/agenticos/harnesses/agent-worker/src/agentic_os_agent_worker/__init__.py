"""Independent production harness boundary; kernel admission remains authoritative."""
__version__ = "0.1.0"
