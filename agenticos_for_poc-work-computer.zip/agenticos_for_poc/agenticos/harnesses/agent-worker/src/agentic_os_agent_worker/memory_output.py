"""Existing memory contracts projected into the SDK's structured-output API.

Core still checks exact current pins, sources, authority and goal satisfaction.
The provider schema only prevents a malformed draft such as a digest string
where the existing contract requires a complete version-pin object.
"""
from copy import deepcopy
from dataclasses import dataclass
import json

from agents.agent_output import AgentOutputSchema
from agents.exceptions import ModelBehaviorError
from temporalio import workflow

# Schema libraries inspect the interpreter when imported. Their pure local
# validators may be shared; workflow IO/replay restrictions remain enabled.
with workflow.unsafe.imports_passed_through():
    from jsonschema import Draft202012Validator,FormatChecker
    from referencing import Registry
    from referencing.exceptions import NoSuchResource

from .transport import _SCHEMA,_validate,_json
from .model_rpc import _control


class AnalysisOutputContractError(ModelBehaviorError):
    """An unaccepted proposal, retained privately for a distinct repair turn."""
    def __init__(self,raw):
        super().__init__('Invalid analysis outcome contract')
        self.raw=raw


@dataclass(init=False)
class MemoryOutput(AgentOutputSchema):
    goal_contract='AgentMemoryReadGoalDraft'
    answer_contract='AgentMemoryReadAnswerDraft'
    contract: str
    schema: dict
    def __init__(self, *, objective):
        # The pinned Temporal SDK serializes AgentOutputSchema, including its
        # unwrapped representation. Keep the existing JSON-text consumer while
        # supplying the original contract through the supported SDK subtype.
        super().__init__(str)
        if type(objective) is not bool:raise ValueError('Explicit memory phase required')
        self.contract=self.goal_contract if objective else self.answer_contract
        definitions={};pending=[self.contract]
        def project(value):
            if type(value) is list:return [project(item) for item in value]
            if type(value) is not dict:return value
            if '$ref' in value:
                ref=value['$ref']
                if not ref.startswith('#/$defs/'):raise ValueError('Local bundled contract reference required')
                name=ref.removeprefix('#/$defs/')
                if name not in definitions and name not in pending:pending.append(name)
            # OpenAI's subset has enums but no uniqueItems. Uniqueness remains
            # mandatory in the original local contract and Core validation.
            result={key:project(item) for key,item in value.items() if key not in {'uniqueItems','const'}}
            if 'const' in value:
                result['enum']=[deepcopy(value['const'])]
                if 'type' not in result:result['type']={str:'string',int:'integer',bool:'boolean',type(None):'null'}[type(value['const'])]
            return result
        while pending:
            name=pending.pop()
            if name in definitions:continue
            definitions[name]=None
            definitions[name]=project(deepcopy(_SCHEMA['$defs'][name]))
            if len(definitions)>32:raise ValueError('Bounded memory contract closure required')
        root=definitions.pop(self.contract)
        self.schema={**root,'$defs':definitions}
        if len(json.dumps(self.schema).encode())>16384:raise ValueError('Bounded memory output schema required')

    def is_plain_text(self):return False
    def name(self):return self.contract
    def json_schema(self):return deepcopy(self.schema)
    def is_strict_json_schema(self):return True

    def validate_json(self, json_str):
        try:
            value=_control(json_str.encode());_validate(self.contract,value)
        except Exception:raise ModelBehaviorError('Invalid memory outcome contract') from None
        # The existing journal/goal consumer expects private JSON text. Keep
        # that representation, rather than adding another persisted SDK type.
        return json_str


class MemoryResponseOutput(MemoryOutput):
    """Versioned criteria/fact proposal; completion stays Core-owned."""
    goal_contract='AgentMemoryResponseDraft'


class ChangeQuestionOutput(MemoryOutput):
    """A reviewed planner ends only with the existing typed missing-detail draft.

    The SDK preparation tool stops at its accepted result before final text.
    A prose imitation of a form cannot be mistaken for that tool or for an
    authenticated clarification. Core remains the owner of both boundaries.
    """
    goal_contract=answer_contract='AgentChangeQuestionDraft'


class LookupOutput(MemoryOutput):
    """The same SDK projection, with the existing ordinary read contracts."""
    goal_contract='AgentReadGoalDraft'
    answer_contract='AgentReadAnswerDraft'


class TableLookupOutput(LookupOutput):
    answer_contract='AgentTableReadAnswerDraft'


class GoalTableLookupOutput(LookupOutput):
    answer_contract='AgentTableReadCompletionDraft'


class AnalysisOutput(MemoryOutput):
    """Existing plain/adaptive analysis contracts over the same SDK boundary."""
    goal_contract='AgentAnalysisGoalDraft'
    answer_contract='AgentAnalysisAnswerDraft'

    def __init__(self,*,objective,metric_semantics=False,source_fields=None):
        if type(metric_semantics) is not bool:raise ValueError('Explicit analysis schema version required')
        super().__init__(objective=objective)
        if objective and metric_semantics:
            fields=self.schema['$defs']['AgentExactMetric']['properties']
            fields['aggregate']['description']='Compute WITHIN each group after deduplication by grain. sum adds the available measurements; maximum selects one largest individual measurement; mean averages them. Largest TOTAL means aggregate sum, then ranking maximum. Do not use aggregate maximum for a requested total.'
            fields['ranking']['description']='Select ACROSS the computed group aggregates within each partition. maximum keeps all tied winning groups; all keeps every group. Ranking does not replace within-group aggregation.'
            fields['populationFilters']['description']='Define the requested eligible universe independently of available-measurement filters. Include an explicitly requested source currency restriction here even when also in filters. A converted output unit alone does not exclude convertible source units or entities with missing measurements.'
            if len(json.dumps(self.schema).encode())>16384:raise ValueError('Bounded analysis output schema required')
        if objective and source_fields is not None:
            candidate=deepcopy(self.schema);fields=set();types=set()
            for item in source_fields:
                shape=_json(item['outputSchemaJson']).get('properties',{}).get('page',{}).get('properties',{})
                names=shape.get('evidence',{}).get('properties',{}).get('publicFields',{}).get('const')
                cell=shape.get('records',{}).get('items',{}).get('items',{}).get('properties',{}).get('value',{})
                variants=cell.get('anyOf',[cell])
                if (type(names) is not list or not names or any(type(name) is not str for name in names)
                        or not variants or any(type(v) is not dict or v.get('type') not in {'string','integer','number','boolean','null'} for v in variants)):
                    break  # Undeclared/heterogeneous metadata keeps the original general contract.
                fields.update(names);types.update(v['type'] for v in variants)
                if 'number' in types:types.add('integer')
            else:
                filters=candidate['$defs']['AgentExactFilter']['properties']
                variants=[v for v in filters['value']['anyOf'] if v.get('type') in types]
                if fields and len(fields)<=128 and variants:
                    filters['field']['enum']=sorted(fields);filters['value']['anyOf']=variants
                    metric=candidate['$defs']['AgentExactMetric']['properties']
                    for name in ('grain','groupBy','partitions','populationFields'):
                        metric[name]['items']={**metric[name]['items'],'enum':sorted(fields)}
                    metric['valueField']['enum']=sorted(fields)
                    if len(json.dumps(candidate).encode())<=16384:self.schema=candidate

    def validate_json(self,json_str):
        try:value=super().validate_json(json_str)
        except ModelBehaviorError:raise AnalysisOutputContractError(json_str) from None
        # Enforce the same declared projection in local/serialized SDK paths;
        # the unchanged Core contract and current-source checks still apply.
        if not Draft202012Validator(self.schema).is_valid(_json(value)):
            raise AnalysisOutputContractError(json_str)
        return value


class ChartAnalysisOutput(AnalysisOutput):
    """The existing chart draft shares exact metrics and completion contracts."""
    goal_contract='AgentChartAnalysisGoalDraft'


class SourceJoinOutput(MemoryOutput):
    """The existing policy-verified child join, without a new result shape."""
    answer_contract='AgentSourceChildJoinAnswerDraft'


class NativeSourceOutput(AnalysisOutput):
    """Project the existing source intent before its immutable native handoff."""
    goal_contract='AgentQuerySourceIntentDraft'

    def __init__(self,*,objective,parent_metrics=False,reporting_metrics=False):
        if type(parent_metrics) is not bool or type(reporting_metrics) is not bool:
            raise ValueError('Explicit native metric schema version required')
        super().__init__(objective=objective,metric_semantics=True)
        if objective:
            # The provider supports anyOf, not oneOf. These closed variants
            # are disjoint by kind, so their union preserves the original
            # policy semantics. Local/Core validation still uses oneOf.
            policy=self.schema['$defs']['AgentSourceChildJoinPolicy']
            variants=policy.pop('oneOf')
            if [item['properties']['kind']['enum'] for item in variants]!=[['all'],['any'],['quorum']]:
                raise ValueError('Disjoint native join policies required')
            policy['anyOf']=variants
            fields=self.schema['$defs']['AgentExactMetric']['properties']
            fields['grain']['description']=('Identify distinct measurements before grouping, independently for each metric. Preserve the source identity when measurements can differ. For a parent value repeated across child rows, use its declared parent identity and unit, not the child identity, so it is counted once. Keep the query grain unchanged; reporting dimensions belong in groupBy.' if parent_metrics else
                'Identify source records before grouping. Preserve the declared source identity when distinct measurements can differ; aggregation dimensions belong in groupBy. Dropping allocation/line identity can merge or conflict with different source values.')
            fields['groupBy']['description']='The requested reporting dimensions, including every ranking partition. The declared query window is the period of a period total; split by source dates only when the request asks for that breakdown.'
            fields['conversion']['description']='Use null when the source already has the requested unit. Convert only with explicitly declared numeric factor, target-unit and version fields. Currency codes and record IDs are not conversion factors or conversion provenance.'
            fields['filters']['description']='Filter only declared source values required by the request. Host authorization is enforced independently; do not invent a source state to represent permission or repeat selectors already enforced by the query.'
            fields['partitions']['description']='Dimensions requesting a separate ranking within each partition. Use [] for a global ranking across eligible entities. Partitioning by the entity being ranked prevents competition between those entities; use it only for an explicitly requested per-entity ranking.'
            if reporting_metrics:
                fields['groupBy']['description']+=' When comparing parent totals made from child amounts, include the parent identity before summing and ranking. Comparing one parent amount also requires that parent identity; summing different parents into another entity total changes the requested metric.'
            if len(json.dumps(self.schema).encode())>16384:raise ValueError('Bounded native source output schema required')


def native_source_goal_feedback(raw,capabilities,providers,*,target_schema=False,unit_semantics=False,request_cursor=False,measurement_identity=False,ranking_units=False):
    """Reuse local query/metric advisories without changing Core admission."""
    draft=_json(raw);_validate('AgentQuerySourceIntentDraft',draft)
    projected=json.dumps({key:draft[key] for key in ('queries','criteria')})
    issues=analysis_goal_feedback(projected,capabilities,providers,declared_fields=True,declared_values=True,
        request_cursor=request_cursor)
    if ranking_units:
        for metric in draft['criteria']:
            unit=metric['unitField']
            if (metric['ranking']!='maximum' or unit is None or metric['conversion'] is not None
                    or unit in metric['partitions']):continue
            filters=[rule['value']for rule in metric['filters']if rule['field']==unit]
            population=[rule['value']for rule in metric['populationFilters']if rule['field']==unit]
            if len(filters)!=1 or population!=filters:
                issues.append('Ranking must compare one dimensional unit for metric '+metric['id']+'. '
                    'Preserve the original requested unit and eligible population: restrict that unit consistently in '
                    'filters and populationFilters, use a declared conversion to one requested unit, or partition by '
                    'unit only when the original request asks for separate rankings. Grouping by unit alone still '
                    'compares different units in a global maximum; never silently choose a narrower population.')
    if measurement_identity:
        for query in draft['queries']:
            matching=[item for item in capabilities if item['capability']==query['capability']]
            if len(matching)!=1:continue  # Existing capability feedback owns this gap.
            schema=_json(matching[0]['outputSchemaJson'])
            if 'x-agentic-os-measurement-grains' not in schema:continue
            declaration=schema['x-agentic-os-measurement-grains']
            fields=schema.get('properties',{}).get('page',{}).get('properties',{}).get('evidence',{}).get('properties',{}).get('publicFields',{}).get('const')
            if (type(declaration) is not dict or set(declaration)!={'version','fields'}
                    or type(declaration['version']) is not int or declaration['version']!=1
                    or type(declaration['fields']) is not dict or not 1<=len(declaration['fields'])<=64
                    or len(json.dumps(declaration).encode())>8192 or type(fields) is not list
                    or not 1<=len(fields)<=128 or any(type(field) is not str or not 1<=len(field)<=128 for field in fields)
                    or len(set(fields))!=len(fields)):
                raise ModelBehaviorError('Unusable declared measurement identities')
            for field,measurement in declaration['fields'].items():
                if field not in fields or type(measurement) is not dict or set(measurement)!={'identity','dimensions'}:
                    raise ModelBehaviorError('Unusable declared measurement identities')
                for key,limit in (('identity',16),('dimensions',128)):
                    names=measurement[key]
                    if (type(names) is not list or not 1<=len(names)<=limit
                            or any(type(name) is not str or name not in fields for name in names)
                            or len(set(names))!=len(names)):
                        raise ModelBehaviorError('Unusable declared measurement identities')
                if not set(measurement['identity'])<=set(measurement['dimensions']) or field not in measurement['dimensions']:
                    raise ModelBehaviorError('Unusable declared measurement identities')
            for metric in draft['criteria']:
                measurement=declaration['fields'].get(metric['valueField'])
                if metric['queryKey']!=query['key'] or measurement is None:continue
                grain=measurement['identity']
                if not set(grain)<=set(metric['grain']):
                    issues.append('Metric '+metric['id']+' must retain its declared measurement identity '+
                        json.dumps(grain,separators=(',',':'))+' in grain before grouping. '
                        'Keep the original requested metric and reporting groups. Repeated parent amounts use their own declared identity; '
                        'reporting dimensions alone cannot identify distinct child contributions.')
                elif not set(metric['groupBy']+metric['partitions']+metric['populationFields'])<=set(measurement['dimensions']+metric['grain']):
                    issues.append('Metric '+metric['id']+' uses a grouping or population field outside its declared measurement dimensions '+
                        json.dumps(measurement['dimensions'],separators=(',',':'))+'. Choose the eligible entity for the original '
                        'requested measurement. A parent bill amount can repeat across child properties; those child properties '
                        'are not its parent population identity. Adding child dimensions to grain can change the requested measure.')
    if unit_semantics:
        queries={query['key']:query for query in draft['queries']}
        for criterion in draft['criteria']:
            conversion=criterion['conversion']
            if conversion is None:continue
            query=queries.get(criterion['queryKey'])
            if query is None:continue
            item=next((item for item in capabilities if item['capability']==query['capability']),None)
            if item is None:continue
            fields=_json(item['outputSchemaJson']).get('properties',{}).get('page',{}).get('properties',{}).get('evidence',{}).get('properties',{}).get('publicFields',{}).get('const')
            if type(fields) is list and any(conversion[field] not in fields for field in ('factorField','targetUnitField','versionField')):
                issues.append('Repair conversion without dropping the original requested unit or population restrictions. Use only declared factor, destination-unit and version fields. When selecting source records already in the requested unit, retain that restriction in both filters and populationFilters on the declared unitField. Never compare or aggregate incompatible units.')
                break
    if target_schema:
        target=draft['target']
        matching=[item for item in capabilities if item['capability']==target['capability']
            and item['kind']=='read' and item['available']]
        origins=[item['providerRef'] for item in providers if item['capability']==target['capability']]
        if len(matching)!=1 or origins!=[target['providerRef']]:
            issues.append('The target must select an available reviewed resource reader and its exact provider.')
        else:
            schema=_json(matching[0]['inputSchemaJson']);properties=schema.get('properties',{})
            if not {'resourceType','externalIds','fieldNames'}<=set(properties):
                issues.append('The target is a follow-up resource reader accepting resourceType, externalIds and fieldNames, not a paged source query. Select that reader from reviewed metadata.')
            else:
                def no_remote(uri):raise NoSuchResource(ref=uri)
                try:
                    validator=Draft202012Validator(schema,registry=Registry(retrieve=no_remote))
                    valid=all(validator.evolve(schema=properties[field]).is_valid(value)
                        for field,value in [('resourceType',target['resourceType']),('fieldNames',target['fields'])])
                except Exception:raise ModelBehaviorError('Unusable local target schema') from None
                if not valid:issues.append('The target resourceType and fields must match its selected resource reader input schema. Source query columns are not target metadata fields.')
    return issues[:16]


ANALYSIS_GOAL_FEEDBACK='The proposed draft failed local checks against the declared tool schemas.'
ANALYSIS_ANSWER_FEEDBACK='The proposed completion failed local exact-reference checks.'
COMPLETION_FRAME_FEEDBACK=('The accepted provider response must contain exactly one assistant message with one output_text JSON document. '
    'Return the complete requested JSON once; omit duplicate final messages. Keep the original goal and accepted source references.')


def completion_frame_valid(output):
    """Mirror Core's strict response envelope before proposing a completion."""
    if type(output) is not list or any(item.get('type')=='function_call' for item in output):return False
    messages=[item for item in output if item.get('type')=='message' and item.get('role')=='assistant']
    if len(messages)!=1:return False
    content=messages[0].get('content')
    return (type(content) is list and len(content)==1 and content[0].get('type')=='output_text'
        and type(content[0].get('text')) is str)


def analysis_feedback_message(text,operation_id):
    """Keep advisory text typed across SDK checkpoint and Activity decoding."""
    return dict(type='message',id='msg_os_feedback_'+operation_id.replace('-',''),role='assistant',status='completed',
        content=[dict(type='output_text',text=text,annotations=[])])


def analysis_null_repair_instructions(items,operation_id):
    """Promote only recomputed numeric repair paths, never proposal text.

    The worker's private continuation retains its latest unaccepted draft and
    exact feedback parent. Source text, field names and model-authored labels
    must not become trusted instructions. Core still binds the whole goal.
    """
    if type(items) is not list or len(items)<3 or type(operation_id) is not str:return ''
    proposal,feedback=items[-2:]
    if (type(feedback) is not dict or feedback.get('id')!=analysis_feedback_message('',operation_id)['id']
            or feedback.get('type')!='message' or feedback.get('role')!='assistant'
            or feedback.get('status')!='completed'):return ''
    content=feedback.get('content')
    if (type(content) is not list or len(content)!=1 or type(content[0]) is not dict
            or content[0].get('type')!='output_text' or type(content[0].get('text')) is not str
            or not content[0]['text'].startswith(ANALYSIS_GOAL_FEEDBACK)):return ''
    if (type(proposal) is not dict or proposal.get('type')!='message'
            or proposal.get('role')!='assistant'):return ''
    content=proposal.get('content')
    if (type(content) is not list or len(content)!=1 or type(content[0]) is not dict
            or content[0].get('type')!='output_text'):return ''
    try:
        draft=_json(content[0]['text']);_validate('AgentAnalysisGoalDraft',draft)
    except (ValueError,TypeError,KeyError):return ''
    paths=[]
    for number,metric in enumerate(draft['criteria']):
        keys=set(metric['grain']+metric['groupBy']+metric['populationFields'])
        for name in ('filters','populationFilters'):
            for index,rule in enumerate(metric[name]):
                if rule['value'] is None and rule['field'] in keys:
                    paths.append('criteria['+str(number)+'].'+name+'['+str(index)+'].value')
    if not paths:return ''
    return (' The latest unaccepted draft still has literal null on required non-null keys at: '
        +', '.join(paths)+'. Correct EVERY listed predicate before returning the draft. '
        'Use an actual source-derived identity or omit a redundant predicate already enforced by its query. '
        'Preserve the original request, source arguments, requested measures and aggregations; '
        'do not change legitimate null filters on non-key missing-value fields. '
        'These local diagnostics grant no source authority or goal acceptance. ')


def analysis_repeated_completion(items,raw,feedback):
    """Recognize the same rejected completion without intervening tool work.

    A new read/poll or changed proposal may make progress. This compares only
    the existing private transcript; it grants no authority or completion.
    """
    prior=None
    for index,item in enumerate(items):
        content=item.get('content')
        if (item.get('role')=='assistant' and item.get('id','').startswith('msg_os_feedback_')
                and type(content) is list and len(content)==1 and content[0].get('text')==feedback):
            prior=index
    if prior is None or any(item.get('type') in {'function_call','function_call_output'} for item in items[prior+1:]):
        return False
    for item in reversed(items[:prior]):
        if item.get('role')!='assistant' or item.get('type')!='message':continue
        content=item.get('content')
        if type(content) is not list or len(content)!=1 or content[0].get('type')!='output_text':return False
        try:return _json(content[0]['text'])==_json(raw)
        except (ValueError,TypeError):return content[0]['text']==raw
    return False


ANALYSIS_CONTRACT_FEEDBACK=('The analysis completion violates its declared JSON contract. '
    'Return exactly the accepted goalDigest and complete unmodified accepted result objects. '
    'Include every required page once; never duplicate a result reference. '
    'Copy opaque identifiers and all required fields from the accepted tool replies. '
    'Do not change the accepted goal, calculate an answer or invent sources.')


def retain_analysis_contract_failure(value):
    # The supported callback sees the failed turn before Runner assembles its
    # outer exception details, which contain only prior completed turns. None
    # preserves rejection; never return a substitute successful final output.
    if isinstance(value.error,AnalysisOutputContractError):value.error.failed_run_data=value.run_data
    return None


def analysis_contract_failure_context(error):
    """Recover the failed SDK turn through its supported private run details.

    Validation still rejects the draft. Its accepted model operation and actual
    tool transcript can support a new, separately accounted correction; no
    replacement output or successful completion is manufactured here.
    """
    if not isinstance(error,AnalysisOutputContractError):return None
    data=getattr(error,'failed_run_data',None)
    if data is None or not data.raw_responses:return None
    output=data.raw_responses[-1].to_input_items()
    messages=[item for item in output if item.get('type')=='message' and item.get('role')=='assistant']
    if (len(messages)!=1 or any(item.get('type') not in {'reasoning','message'} for item in output)
            or ''.join(part.get('text','') for part in messages[0].get('content',[])
                if part.get('type')=='output_text')!=error.raw):return None
    return deepcopy(data.history)


def analysis_feedback_continuation(items,original_question,*,retain_proposal=True,compact=False):
    """Bound a completed corrective round, retaining the original request/facts.

    Earlier proposals and encrypted reasoning remain in their original private
    journals. A fresh SDK continuation needs every tool pair, the latest proposal
    and its feedback. A rejected pre-goal draft can instead restart from those
    sources and the latest issue, without anchoring on guessed draft selectors.
    Never discard user intent or source pairs to fit a packet.
    Compatible small continuations keep their exact existing representation.
    Explicit compaction also removes obsolete feedback from short repair rounds.
    """
    encode=lambda value:json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
    raw=encode(items)
    if type(retain_proposal) is not bool or type(compact) is not bool:return None
    if len(raw)<=32768 and retain_proposal and not compact:return raw
    if type(items) is not list or len(items)<3 or items[0]!=dict(role='user',content=original_question):return None
    feedback=items[-1]
    if type(feedback) is not dict or feedback.get('role')!='assistant':return None
    content=feedback.get('content')
    typed=(feedback.get('type')=='message' and feedback.get('status')=='completed' and type(feedback.get('id')) is str
        and type(content) is list and len(content)==1 and type(content[0]) is dict
        and content[0].get('type')=='output_text' and type(content[0].get('text')) is str and content[0].get('annotations')==[])
    if type(content) is not str and not typed:return None
    latest=None;pairs=[]
    for item in items[1:-1]:
        if type(item) is not dict or item.get('role') in {'user','system','developer'}:return None
        kind=item.get('type')
        if kind in {'function_call','function_call_output'}:pairs.append(item)
        elif kind=='message' and item.get('role')=='assistant':latest=item
        elif kind!='reasoning' and not (item.get('role')=='assistant' and type(item.get('content')) is str):return None
    if latest is None:return None
    raw=encode([items[0],*pairs,*([latest] if retain_proposal else []),items[-1]])
    return raw if len(raw)<=32768 else None


def analysis_tool_arguments_valid(schema,arguments):
    """Local metadata feedback only; valid calls still require Core admission."""
    def no_remote(uri):raise NoSuchResource(ref=uri)
    try:value=_json(arguments)
    except ValueError:return False
    try:return Draft202012Validator(schema,format_checker=FormatChecker(),registry=Registry(retrieve=no_remote)).is_valid(value)
    except Exception:raise ModelBehaviorError('Unusable local tool schema') from None


def analysis_discovery_feedback(input_items,tool_names,context):
    """The declared discovery phase must precede its immutable query goal.

    This is advisory worker sequencing, not source or execution authority.
    Plain analysis without declared discovery retains its existing behavior.
    """
    if not tool_names:return []
    _validate('AgentTaskContext',context)
    allowed=set(tool_names)
    calls={item.get('call_id'):item.get('name') for item in input_items
        if type(item) is dict and item.get('type')=='function_call'}
    for item in input_items:
        if (type(item) is not dict or item.get('type')!='function_call_output'
                or calls.get(item.get('call_id')) not in allowed or type(item.get('output')) is not str):continue
        value=_json(item['output']);schema=value.get('schema')
        if schema not in {'agent-accepted-query/1','agent-accepted-query-ref/1'}:continue
        _validate('AgentAcceptedQueryContext' if schema=='agent-accepted-query/1' else 'AgentAcceptedQueryReferenceContext',value)
        if any(value['result'][key]!=context[key] for key in ('subject','rootId','taskId','scopeRef')):
            raise ModelBehaviorError('Unusable accepted discovery context')
        return []
    return ['Complete the declared identifier-discovery phase with an accepted discovery tool result before proposing the goal. Use its resolved literal selectors; never freeze placeholder instructions to resolve identifiers later. An accepted goal cannot be amended during execution.']


def analysis_source_discovery_feedback(raw,input_items,discovery_capabilities,context,*,measurement_identity=False,targeted_tools=False,completion=False):
    """Advise complete source reads for queries in the declared discovery phase.

    This checks the existing paired wire context, not current authority or the
    business answer. Core still verifies every retained source independently.
    """
    from .checkpoint import tool_alias
    draft=_json(raw);_validate('AgentAnalysisGoalDraft',draft)
    discovery={tool_alias(pin) for pin in discovery_capabilities}
    calls={item.get('call_id'):item for item in input_items
        if type(item) is dict and item.get('type')=='function_call'}
    sources=[]
    for item in input_items:
        if type(item) is not dict or item.get('type')!='function_call_output':continue
        call=calls.get(item.get('call_id'))
        if call is None or call.get('name') not in discovery:continue
        value=_json(item['output'])
        if value.get('schema')!='agent-accepted-query/1':continue
        _validate('AgentAcceptedQueryContext',value)
        if any(value['result'][key]!=context[key] for key in ('subject','rootId','taskId','scopeRef')):
            raise ModelBehaviorError('Unusable accepted source-discovery context')
        sources.append((call,value))
    issues=[]
    for query in draft['queries']:
        alias=tool_alias(query['capability'])
        if alias not in discovery:continue
        cursor=query['cursorField'];arguments=_json(query['argumentsJson'])
        selected={key:value for key,value in arguments.items() if key!=cursor}
        expected_cursor=None;seen=set();complete=False;query_digest=None;source_rows=[]
        for call,value in sources:
            actual=_json(call['arguments'])
            if call['name']!=alias or {key:value for key,value in actual.items() if key!=cursor}!=selected:continue
            ident=value['result']['resultId'];page=value['query']
            if ident in seen:continue
            if (complete or actual.get(cursor)!=expected_cursor or page['requestCursor']!=expected_cursor
                    or page['pageOrdinal']!=len(seen) or query_digest is not None and page['queryDigest']!=query_digest):break
            seen.add(ident);query_digest=page['queryDigest'];expected_cursor=page['page']['nextCursor']
            source_rows.extend({field['name']:field['value'] for field in row} for row in page['page']['records'])
            complete=expected_cursor is None and page['coverage']['status']=='complete'
        if not complete:
            issues.append(('Read every current page of required query '+query['key']+' for completion. ' if completion else
                'Read every current page of source-discovery query '+query['key']+' before binding the goal. ')
                +('Use offered tool '+alias+' for this source query; supply its reviewed arguments and follow its actual cursors. ' if targeted_tools else '')+
                ('The immutable goal and its exact arguments remain unchanged. Retain both source chains and return their accepted references.' if completion else
                'Use its actual selected identities to bind every requested downstream query and criterion in this same immutable goal; '
                'do not bind only the first answer and defer the rest to execution. A final page alone does not replace earlier source evidence.'))
        elif measurement_identity:
            # Advisory functional-dependency check, not aggregation. Different
            # measurements cannot share one metric identity. Coarser parent
            # identities remain valid when their complete projections agree.
            encode=lambda value:json.dumps(value,sort_keys=True,separators=(',',':'))
            for metric in draft['criteria']:
                if metric['queryKey']!=query['key']:continue
                relevant=set(metric['grain']+metric['groupBy']+metric['populationFields']+[metric['valueField']])
                if metric['unitField'] is not None:relevant.add(metric['unitField'])
                if metric['latest'] is not None:relevant.update(metric['latest']['groupBy']+[metric['latest']['versionField']])
                if metric['conversion'] is not None:relevant.update(metric['conversion'][key] for key in ('factorField','targetUnitField','versionField'))
                chosen={}
                for row in source_rows:
                    rules=metric['populationFilters']+metric['filters']
                    if any(rule['field'] not in row or encode(row[rule['field']])!=encode(rule['value']) for rule in rules):continue
                    if not relevant<=row.keys() or any(row[field] is None for field in metric['grain']):continue
                    key=encode([row[field] for field in metric['grain']]);projection=encode({field:row[field] for field in relevant})
                    if key in chosen and chosen[key]!=projection:
                        issues.append('Query '+query['key']+' metric '+metric['id']+' grain combines differing source measurements. '
                            'Keep their distinct measurement identities before grouping; use the declared query grain unless a repeated parent projection agrees. '
                            'groupBy is the reporting group, not the measurement identity. Choose the value field for the original requested phenomenon; '
                            'a full parent amount is not a child contribution, and choosing maximum does not change that distinction.')
                        break
                    chosen[key]=projection
    return issues


def analysis_source_read_required(input_items,tool_names,context):
    """Require an actual read after existing missing-source feedback.

    Discovery capabilities are alternatives, not an instruction to read every
    capability. This only sequences one new accepted read before another goal
    after the existing checker requested it; Core still binds complete chains.
    """
    if analysis_discovery_feedback(input_items,tool_names,context):return True
    feedback=None
    for index,item in enumerate(input_items):
        if item.get('role')!='assistant' or not item.get('id','').startswith('msg_os_feedback_'):continue
        content=item.get('content',[])
        if type(content) is list and len(content)==1:
            text=content[0].get('text','')
            if text.startswith(ANALYSIS_GOAL_FEEDBACK):feedback=(index,text)
    if feedback is None or 'Read every current page of source-discovery query ' not in feedback[1]:return False
    calls={item.get('call_id'):item.get('name') for item in input_items if item.get('type')=='function_call'}
    for item in input_items[feedback[0]+1:]:
        if item.get('type')!='function_call_output' or calls.get(item.get('call_id')) not in tool_names:continue
        value=_json(item['output'])
        if value.get('schema')!='agent-accepted-query/1':continue
        _validate('AgentAcceptedQueryContext',value)
        if any(value['result'][key]!=context[key] for key in ('subject','rootId','taskId','scopeRef')):
            raise ModelBehaviorError('Unusable accepted source-discovery context')
        return False
    return True


def analysis_source_read_choice(input_items,tool_names,context,*,completion=False):
    """A missing source cannot be satisfied by another identifier lookup.

    Select only an already offered tool named by our current advisory feedback.
    Arguments remain model-owned; normal tool resolution, source-chain and Core
    authority checks remain mandatory. Older feedback keeps its old behavior.
    """
    feedback=None
    prefix='Completion verification still requires criteria ' if completion else ANALYSIS_GOAL_FEEDBACK
    for index,item in enumerate(input_items):
        content=item.get('content')
        if (item.get('role')=='assistant' and item.get('id','').startswith('msg_os_feedback_')
                and type(content) is list and len(content)==1
                and content[0].get('text','').startswith(prefix)):
            feedback=(index,content[0]['text'])
    named=[] if feedback is None else [name for name in tool_names
        if 'Use offered tool '+name+' for this source query;' in feedback[1]]
    if not named:
        if completion:return None
        return 'required' if analysis_source_read_required(input_items,tool_names,context) else None
    _validate('AgentTaskContext',context)
    calls={item.get('call_id'):item.get('name') for item in input_items[feedback[0]+1:]
        if item.get('type')=='function_call'}
    observed=set()
    for item in input_items[feedback[0]+1:]:
        alias=calls.get(item.get('call_id'))
        if item.get('type')!='function_call_output' or alias not in named:continue
        value=_json(item['output'])
        if value.get('schema')!='agent-accepted-query/1':continue
        _validate('AgentAcceptedQueryContext',value)
        if any(value['result'][key]!=context[key] for key in ('subject','rootId','taskId','scopeRef')):
            raise ModelBehaviorError('Unusable accepted source-discovery context')
        observed.add(alias)
    return next((name for name in named if name not in observed),None)


def analysis_answer_feedback(raw,goal_digest,input_items,context,*,complete_pages=False):
    """Advise a new model turn; never rewrite a proposal or certify authority.

    The SDK transcript contains the actual accepted tool replies. Core still
    checks the complete causal graph and fresh source/owner authority on finish.
    """
    draft=_json(raw);_validate('AgentAnalysisAnswerDraft',draft)
    _validate('AgentTaskContext',context)
    accepted={}
    for item in input_items:
        if type(item) is not dict or item.get('type')!='function_call_output' or type(item.get('output')) is not str:continue
        value=_json(item['output']);schema=value.get('schema')
        if schema not in {'agent-accepted-query/1','agent-accepted-query-ref/1'}:continue
        _validate('AgentAcceptedQueryContext' if schema=='agent-accepted-query/1' else 'AgentAcceptedQueryReferenceContext',value)
        reference=value['result']
        if any(reference[key]!=context[key] for key in ('subject','rootId','taskId','scopeRef')):
            raise ModelBehaviorError('Unusable accepted query context')
        previous=accepted.get(reference['resultId'])
        if previous is not None and previous!=reference:raise ModelBehaviorError('Ambiguous accepted query context')
        accepted[reference['resultId']]=reference
    issues=[];copied=False
    if draft['goalDigest']!=goal_digest:issues.append('Copy the exact accepted goalDigest from the execution instructions.')
    for index,reference in enumerate(draft['results']):
        original=accepted.get(reference['resultId'])
        if original is None:
            issues.append('Result '+str(index)+' must select a complete result object returned by the accepted query tools.')
        elif reference!=original:
            fields=sorted(key for key in original if original[key]!=reference[key])
            issues.append('Result '+str(index)+' changed '+','.join(fields)+'. Copy the complete unmodified tool result object, including every opaque identifier.')
            # One bounded verbatim example is existing private source context,
            # not a new reference or a repair to the archived model response.
            encoded=json.dumps(original,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            if not copied and len(encoded.encode())<=4096:
                issues.append('Exact accepted result: '+encoded);copied=True
        if len(issues)>=16:break
    if complete_pages:
        selected={reference['resultId'] for reference in draft['results']}
        missing=[reference for ident,reference in accepted.items() if ident not in selected]
        if missing:
            issues.append('Retain every accepted page of every required query, including empty pages and earlier pages. '
                'A terminal page does not replace its preceding pages. Keep the already selected pages from other queries.')
            issues.append('Required accepted resultIds (first 128; retain any further accepted pages too): '
                +json.dumps(sorted(accepted)[:128],separators=(',',':')))
            encoded=json.dumps(missing[0],sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            example='Exact missing accepted result: '+encoded
            if len(encoded.encode())<=4096 and len(json.dumps([*issues,example]).encode())<=8192:
                issues.append(example)
    return issues[:16]


def analysis_goal_feedback(raw,capabilities,providers,*,declared_fields=False,declared_values=False,charts=False,request_cursor=False,exact_source_shape=False,key_filters=False,query_links=False,key_filter_paths=False):
    """Advisory draft repair; Core alone validates current scope and binding.

    Reuse the declared tool schemas before freezing a goal. Never retrieve a
    schema, invent an identifier, amend an accepted goal or refund a model call.
    """
    draft=_json(raw);_validate('AgentChartAnalysisGoalDraft' if charts else 'AgentAnalysisGoalDraft',draft);issues=[]
    pins=lambda pin:tuple(pin[key] for key in ('ref','revision','digest'))
    items={pins(item['capability']):item for item in capabilities}
    provider_refs={pins(item['capability']):item['providerRef'] for item in providers}
    keys=[query['key'] for query in draft['queries']]
    if len(set(keys))!=len(keys):issues.append('Query keys must be unique.')
    if {criterion['queryKey'] for criterion in draft['criteria']}!=set(keys):
        message='Every criterion queryKey must match its query key; every query must be used.'
        if query_links:
            used={criterion['queryKey'] for criterion in draft['criteria']}
            message+=' Declared queries[*].key values: '+json.dumps(keys,separators=(',',':'))+'.'
            message+=' Unmatched criteria: '+json.dumps([
                dict(id=criterion['id'],queryKey=criterion['queryKey']) for criterion in draft['criteria']
                if criterion['queryKey'] not in keys],separators=(',',':'))+'.'
            message+=' Queries with no criterion: '+json.dumps([key for key in keys if key not in used],separators=(',',':'))+'.'
            message+=' Set each criterion.queryKey to the exact key of its source query, not a new metric name. Multiple criteria may share one query. Keep discovery-only calls in the accepted transcript; include a query in the goal only when a requested criterion uses its rows. Preserve every requested metric and its correct source, selector and measurement grain.'
        issues.append(message)
    if len({criterion['id'] for criterion in draft['criteria']})!=len(draft['criteria']):
        issues.append('Criterion IDs must be unique.')
    if any(not set(criterion['partitions'])<=set(criterion['groupBy']) for criterion in draft['criteria']):
        issues.append('Every ranking partition must be included in groupBy.')
    if key_filters:
        for metric in draft['criteria']:
            # The exact operator rejects null identity keys. Equality to null
            # on one of those keys can never yield a verified measurement;
            # null filters on other fields remain valid source semantics.
            keys=set(metric['grain']+metric['groupBy']+metric['populationFields'])
            invalid=[dict(path=name+'['+str(index)+']',field=rule['field'])
                for name in ('filters','populationFilters') for index,rule in enumerate(metric[name])
                if rule['value'] is None and rule['field'] in keys]
            if invalid:
                message=('Metric '+metric['id']+' filters a required non-null measurement, grouping or population key to null. '
                    'A null equality is literal, not a placeholder for a selected entity or another criterion. '
                    'Use the exact source-derived literal identity when required; do not repeat a selector already enforced by its query. '
                    'Preserve legitimate missing-value filters on non-key fields and the original requested measurement.')
                if key_filter_paths:
                    message+=' Invalid predicates: '+json.dumps(invalid,separators=(',',':'))+'. '
                    message+='Correct only the diagnosed predicates and query-name links in the latest unaccepted proposal. Preserve its source-derived query arguments, requested measure, aggregation and grouping unless the original question requires a correction. A repair is not an accepted goal.'
                issues.append(message)
    if charts:
        metrics={metric['id']:metric for metric in draft['criteria']}
        if len({metric['label'] for metric in draft['criteria']})!=len(metrics):issues.append('Chart metric labels must be unique.')
        if len({chart['id'] for chart in draft['charts']})!=len(draft['charts']):issues.append('Chart IDs must be unique.')
        if any(chart['criterionId'] not in metrics or chart['dimension'] not in metrics[chart['criterionId']]['groupBy'] for chart in draft['charts']):
            issues.append('Every chart must select its existing criterion and one of that criterion\'s groupBy dimensions.')
    def no_remote(uri):raise NoSuchResource(ref=uri)
    for query in draft['queries']:
        pin=pins(query['capability']);item=items.get(pin);key=query['key']
        if item is None or item['kind']!='read' or not item['available'] or provider_refs.get(pin)!=query['providerRef']:
            issues.append('Query '+key+' must select an available reviewed read capability and its provider.');continue
        schema=_json(item['inputSchemaJson']);arguments=_json(query['argumentsJson'])
        try:
            error=next(Draft202012Validator(schema,format_checker=FormatChecker(),registry=Registry(retrieve=no_remote)).iter_errors(arguments),None)
        except Exception:raise ModelBehaviorError('Unusable local query schema') from None
        if error is not None:
            path='/'.join(str(value) for value in error.absolute_path)[:256] or '(arguments)'
            issues.append('Query '+key+' violates input rule '+str(error.validator)+' at '+path+'.')
        shape=_json(item['outputSchemaJson']).get('properties',{})
        if declared_fields:
            fields=shape.get('page',{}).get('properties',{}).get('evidence',{}).get('properties',{}).get('publicFields',{}).get('const')
            if type(fields) is list and fields and all(type(field) is str for field in fields):
                for criterion in draft['criteria']:
                    if criterion['queryKey']!=key:continue
                    selected=set(criterion['grain']+criterion['groupBy']+criterion['partitions']+criterion['populationFields']+[criterion['valueField']])
                    selected.update(rule['field'] for rule in criterion['filters']+criterion['populationFilters'])
                    if criterion['unitField'] is not None:selected.add(criterion['unitField'])
                    if criterion['latest'] is not None:selected.update(criterion['latest']['groupBy']+[criterion['latest']['versionField']])
                    if criterion['conversion'] is not None:selected.update(criterion['conversion'][field] for field in ('factorField','targetUnitField','versionField'))
                    if selected-set(fields):issues.append('Query '+key+' metrics must use only declared source row fields: '+json.dumps(fields,separators=(',',':'))+'.')
                    if declared_values:
                        cell=shape.get('page',{}).get('properties',{}).get('records',{}).get('items',{}).get('items',{})
                        value_schema=cell.get('properties',{}).get('value')
                        if type(value_schema) is dict:
                            try:
                                validator=Draft202012Validator(value_schema,registry=Registry(retrieve=no_remote))
                                invalid=any(not validator.is_valid(rule['value']) for rule in criterion['filters']+criterion['populationFilters'])
                            except Exception:raise ModelBehaviorError('Unusable local source cell schema') from None
                            if invalid:issues.append('Query '+key+' filter values must match the declared source cell types, which can differ from query argument types. Do not repeat an already enforced query selector as a row filter unless needed.')
        for field in ('grain','pageGroupFields'):
            if 'const' in shape.get(field,{}) and query[field]!=shape[field]['const']:
                message='Query '+key+' must preserve the declared '+field+'.'
                if exact_source_shape:
                    message+=' This capability '+query['capability']['ref']+' declares '+json.dumps(shape[field]['const'],separators=(',',':'))+'. Copy that exact source shape, not the shape of another discovery tool. Metric measurement grain is separate from query grain.'
                issues.append(message)
        if (type(arguments) is not dict or request_cursor and query['cursorField'] not in arguments
                or arguments.get(query['cursorField']) is not None):
            issues.append('Query '+key+' needs its declared request cursor field and an initial null cursor.')
    return issues[:16]
