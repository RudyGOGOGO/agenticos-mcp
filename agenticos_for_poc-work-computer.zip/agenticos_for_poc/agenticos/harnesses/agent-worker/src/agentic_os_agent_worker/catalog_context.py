"""Bounded provider input for the explicit governed metadata-discovery phase.

The SDK keeps its supported private history. The provider receives the original
question and latest accepted metadata window; the Core still checks the complete
causal graph. No synthetic user message or execution permission is introduced.
"""
from copy import deepcopy
import json

from agents.run_config import ModelInputData

from .sdk_model import SDKModelPolicyError
from .transport import _json,_validate


def discovery_wire_bytes(value,*,layers=3):
    """Conservative JSON-string expansion before SDK checkpoint nesting."""
    for _ in range(layers):
        value=json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':'))
    return len(value.encode('utf-8'))


def discovery_response_budget(output):
    values=[item.model_dump(mode='json',exclude_none=True) for item in output]
    if (discovery_wire_bytes(values)>8192 or any(item['type']=='function_call'
            and discovery_wire_bytes(item)>4096 for item in values)):
        raise SDKModelPolicyError()


def discovery_input_budget(items,instructions):
    if discovery_wire_bytes(dict(input=items,instructions=instructions),layers=1)>40*1024:
        raise SDKModelPolicyError()


def discovery_model_input(items,context):
    if not context['harness']['ref'].startswith('governed-read-discovery/') or type(items) is str:
        return items
    if type(items) is not list or any(type(item) is not dict for item in items):raise SDKModelPolicyError()
    outputs=[index for index,item in enumerate(items) if item.get('type')=='function_call_output']
    if not outputs:return items
    last=items[outputs[-1]]
    try:accepted=_json(last['output'])
    except Exception:return items
    failure=accepted==dict(kind='tool-error',failure='tool-failed')
    if not failure:
        if type(accepted) is not dict or accepted.get('schema')!='agent-capability-discovery/1':return items
        _validate('AgentAcceptedCapabilityDiscoveryContext',accepted)
        if (accepted['page']['context']!=context
                or any(accepted['result'][key]!=context[key] for key in ('subject','rootId','taskId'))):
            raise SDKModelPolicyError()
    if (not items or items[0].get('role')!='user'
            or any(item.get('role') in {'user','system','developer'} for item in items[1:])):
        raise SDKModelPolicyError()
    boundary=outputs[-2]+1 if len(outputs)>1 else 1
    suffix=items[boundary:]
    calls=[item for item in suffix if item.get('type')=='function_call']
    if (len(calls)!=1 or calls[0].get('call_id')!=last.get('call_id')
            or len([item for item in suffix if item.get('type')=='function_call_output'])!=1):
        raise SDKModelPolicyError()
    return deepcopy([items[0],*suffix])


def discovery_call_model_input_filter(context):
    """Public SDK hook, before Temporal serializes the model Activity input.

    The SDK retains its supported history; only this call's model input is
    projected. The transport repeats the same validation after typed decode.
    """
    expected=deepcopy(context)
    def filtered(call):
        from .sdk_model import _RESPONSE_INPUT
        value=call.model_data
        items=_RESPONSE_INPUT.dump_python(value.input,mode='json',warnings='error')
        items=discovery_model_input(items,expected)
        discovery_input_budget(items,value.instructions)
        return ModelInputData(input=items,instructions=value.instructions)
    return filtered


def completed_discovery_window(result,sequence,capability,original_question):
    """Fresh SDK context only after a complete accepted metadata tool round.

    Pending approvals still use supported RunState. This mirrors the existing
    query completed-round boundary; prior causal work stays in Core journals
    and private Temporal history, not an ever-growing approval checkpoint.
    """
    from agents.items import ToolCallItem,ToolCallOutputItem
    from .checkpoint import tool_alias
    if result.interruptions or sequence.pending is not None:raise SDKModelPolicyError()
    outputs=[item for item in result.new_items if isinstance(item,ToolCallOutputItem)]
    if not outputs:return None
    calls=[item for item in result.new_items if isinstance(item,ToolCallItem)]
    if len(outputs)!=1 or len(calls)!=1:raise SDKModelPolicyError()
    output=outputs[0];call=calls[0].to_input_item();binding=sequence.snapshot();context=binding['context']
    value=_json(output.output)
    if value==dict(kind='tool-error',failure='tool-failed'):
        heads=binding['inputResults']
        if (len(heads)!=1 or heads[0]['payload']['schemaRef']!='AgentProviderResponse'
                or any(heads[0][key]!=context[key] for key in ('subject','rootId','taskId'))):raise SDKModelPolicyError()
    else:
        _validate('AgentAcceptedCapabilityDiscoveryContext',value)
        if (value['result'] not in binding['inputResults'] or value['result']['payload']['schemaRef']!='AgentCapabilityDiscoveryPage'
                or value['page']['context']!=context or value['page']['request']!=_json(call['arguments'])
                or any(value['result'][key]!=context[key] for key in ('subject','rootId','taskId'))):raise SDKModelPolicyError()
    if (call['name']!=tool_alias(capability) or call['call_id']!=output.call_id
            or not context['harness']['ref'].startswith('governed-read-discovery/')):raise SDKModelPolicyError()
    current=discovery_model_input(result.to_input_list(),context)
    if current[0].get('content')!=original_question:raise SDKModelPolicyError()
    return current


def completed_analysis_discovery_window(result,sequence,capabilities,original_question):
    """Retain complete query evidence after a supported SDK tool round.

    Accepted model responses, including encrypted reasoning, remain in their
    original private journals. A new SDK round needs the original question,
    every tool pair and all non-reasoning messages, rather than duplicate
    copies of prior model responses in another approval checkpoint.
    """
    from agents.items import ToolCallItem,ToolCallOutputItem
    from .checkpoint import tool_alias
    from .memory_output import analysis_tool_arguments_valid
    if result.interruptions or sequence.pending is not None:raise SDKModelPolicyError()
    outputs=[item for item in result.new_items if isinstance(item,ToolCallOutputItem)]
    if not outputs:return None
    calls={item.call_id:item.to_input_item() for item in result.new_items if isinstance(item,ToolCallItem)}
    selected={tool_alias(item['capability']):item for item in capabilities}
    context=sequence.snapshot()['context']
    if len(calls)!=len(outputs):raise SDKModelPolicyError()
    for output in outputs:
        call=calls.get(output.call_id)
        if call is None or call['name'] not in selected:raise SDKModelPolicyError()
        value=_json(output.output)
        if value==dict(kind='tool-error',failure='invalid-input'):
            if analysis_tool_arguments_valid(_json(selected[call['name']]['inputSchemaJson']),call['arguments']):raise SDKModelPolicyError()
        elif value!=dict(kind='tool-error',failure='tool-failed'):
            _validate('AgentAcceptedQueryContext',value)
            if (value['result']['payload']['schemaRef']!='AgentQueryPage'
                    or any(value['result'][key]!=context[key] for key in ('subject','rootId','taskId','scopeRef'))
                    or value['query']['page']['evidence']['subject']!=context['subject']):raise SDKModelPolicyError()
    current=result.to_input_list()
    if not current or current[0]!=dict(role='user',content=original_question):raise SDKModelPolicyError()
    retained=[current[0]]
    for item in current[1:]:
        if type(item) is not dict or item.get('role') in {'user','system','developer'}:raise SDKModelPolicyError()
        kind=item.get('type')
        if kind=='reasoning':continue
        if kind not in {'function_call','function_call_output'} and item.get('role')!='assistant':raise SDKModelPolicyError()
        retained.append(item)
    if len(json.dumps(retained,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode())>32768:raise SDKModelPolicyError()
    return deepcopy(retained)
