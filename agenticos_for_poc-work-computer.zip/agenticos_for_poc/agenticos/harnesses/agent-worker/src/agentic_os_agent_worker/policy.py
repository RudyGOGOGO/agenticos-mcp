"""Explicit SDK execution policy without implicit credentials or tracing."""
from dataclasses import dataclass
from datetime import timedelta
from importlib.metadata import version

from agents import ModelProvider, RunConfig
from temporalio.common import RetryPolicy
from temporalio.contrib.openai_agents import OpenAIAgentsPlugin, ModelActivityParameters
from temporalio.workflow import ActivityCancellationType

DEPENDENCY_PINS = {
    "openai-agents": "0.19.4", "openai": "2.54.0", "anthropic": "1.14.0",
    "temporalio": "1.34.0", "mcp": "1.30.0", "cryptography": "50.0.2",
    "jsonschema": "4.26.0",
    "httpx": "0.28.1", "httpx2": "2.13.1",
}


class HarnessPolicyError(ValueError):
    def __init__(self):
        super().__init__("unqualified_harness_configuration")


def verify_dependencies():
    if any(version(name) != expected for name, expected in DEPENDENCY_PINS.items()):
        raise HarnessPolicyError()


@dataclass(frozen=True)
class WorkerPolicy:
    operation_timeout_ms: int

    def __post_init__(self):
        # This is one request's execution bound, never a task topology/turn limit.
        if type(self.operation_timeout_ms) is not int or not 1 <= self.operation_timeout_ms <= 900_000:
            raise HarnessPolicyError()

    def plugin(self, model_provider: ModelProvider) -> OpenAIAgentsPlugin:
        verify_dependencies()
        if not isinstance(model_provider, ModelProvider):
            raise HarnessPolicyError()
        return OpenAIAgentsPlugin(model_provider=model_provider, add_temporal_spans=False,
            use_otel_instrumentation=False, resolvable_worker_env_vars=(),
            model_params=ModelActivityParameters(
                start_to_close_timeout=timedelta(milliseconds=self.operation_timeout_ms),
                retry_policy=RetryPolicy(maximum_attempts=1),
                cancellation_type=ActivityCancellationType.TRY_CANCEL,
                summary_override="Governed model work"))

    @property
    def workflow_task_timeout(self) -> timedelta:
        # Private codec I/O belongs to the enclosing workflow-task observation.
        # Temporal caps this window at120s; the original execution horizon and
        # every Core operation/IO lease remain independently enforced.
        return timedelta(milliseconds=min(self.operation_timeout_ms,120_000))

    def run_config(self, *, model_override: str | None = None) -> RunConfig:
        if model_override is not None and (type(model_override) is not str
                or not model_override or len(model_override) > 256):
            raise HarnessPolicyError()
        # The model name resolves through the explicit metered provider. No
        # default OpenAI provider, credentials or desktop login are selected.
        return RunConfig(model=model_override, tracing_disabled=True)
