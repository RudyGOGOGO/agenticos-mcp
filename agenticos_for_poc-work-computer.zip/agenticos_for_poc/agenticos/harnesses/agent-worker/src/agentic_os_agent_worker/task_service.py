"""One explicitly assigned local read task on the selected Temporal service.

The kernel supplies the original immutable start. This service polls both phase
queues, so replacement before Continue-As-New acknowledgement cannot strand work.
It owns no Host credential, SQL connection, goal verifier or resource balance.
"""
from concurrent.futures import ThreadPoolExecutor
from contextlib import AsyncExitStack
from copy import deepcopy
from datetime import datetime,timedelta,timezone
import ipaddress
import math

from temporalio.client import Client
from temporalio.common import RetryPolicy,WorkflowIDConflictPolicy,WorkflowIDReusePolicy
from temporalio.converter import WorkflowSerializationContext
from temporalio.exceptions import WorkflowAlreadyStartedError
from temporalio.worker import Worker

from .sdk_model import GovernedResponsesModel,GovernedResponsesProvider,SDKModelPolicyError
from .temporal_driver import AgentTaskDriver
from .temporal_runtime import agent_converter,agent_plugin,agent_worker_options
from .transport import _validate
from .policy import WorkerPolicy


async def serve_read_task(*,target,namespace,boundary,transport,history_keys,history_key_id,start,ready=None,local_synthetic=False,planner=None,cloud_connection=None,reasoning_effort=None):
    planning=start.get('schema')=='agent-private-planned-read-journey/1'
    if planning!=(planner is not None):raise SDKModelPolicyError()
    paged=start.get('schema') in {'agent-paged-analysis-journey/1','agent-clarified-analysis-journey/1','agent-period-clarified-analysis-journey/1','agent-planned-analysis-journey/1','agent-comparison-journey/1','agent-extrema-comparison-journey/1'}
    charts=paged or start.get('schema')=='agent-chart-analysis-journey/1'
    adaptive=charts or start.get('schema') in {'agent-contextual-lookup-read-journey/2','agent-contextual-lookup-read-journey/1','agent-lookup-read-journey/1','agent-adaptive-analysis-journey/1','agent-memory-read-journey/1','agent-memory-response-journey/1'}
    from .read_journey import start_contract
    contract=start_contract(start)
    _validate(contract,start)
    from .read_journey import selected_reads
    selected_reads(start,objective=True)
    if type(namespace) is not str or not 1<=len(namespace)<=256:
        raise SDKModelPolicyError()
    if cloud_connection is None:
        if local_synthetic is not True:raise SDKModelPolicyError()
        try:
            host,port=target.rsplit(':',1)
            if not ipaddress.ip_address(host.strip('[]')).is_loopback or not 1<=int(port)<=65535:raise ValueError()
        except (ValueError,AttributeError):raise SDKModelPolicyError() from None
    else:
        from .temporal_cloud import CloudTemporalConnection
        if (type(cloud_connection) is not CloudTemporalConnection or local_synthetic is not False
                or cloud_connection.target!=target or cloud_connection.namespace!=namespace
                or cloud_connection.configuration['installationId']!=start['start']['context']['subject']['installationId']):
            raise SDKModelPolicyError()
    c=start['start']['context'];config=transport.config
    if (transport.boundary is not boundary or config.model_profile_digest!=c['model']['digest']
            or config.model_id!=start['start']['modelId'] or start['phase']!='objective'
            or start['binding'] is not None or start['goalDigest'] is not None
            or start['goalDraftJson'] is not None or start['continuationInputJson'] is not None
            or start.get('planStateJson') is not None
            or start.get('reviewId') is not None or start.get('preparation') is not None
            or start.get('childAfter') is not None or start.get('childContinuation') is not None
            or start.get('childContinuations') not in (None,[])
            or start['start']['checkpointId'] is not None):raise SDKModelPolicyError()
    horizon=datetime.fromisoformat(c['authorizationHorizon'].replace('Z','+00:00'))
    remaining=(horizon-datetime.now(timezone.utc)).total_seconds()
    if remaining<=0:raise SDKModelPolicyError()
    workflow_id='os-agent:'+':'.join([c['subject']['installationId'],c['subject']['applicationId'],c['taskId']])
    converter=agent_converter(boundary,history_keys,c,namespace,history_key_id,observe_history=True)
    model=GovernedResponsesModel(transport,max_output_tokens=start['start']['maxOutputTokens'],reasoning_effort=reasoning_effort)
    plugin=agent_plugin(GovernedResponsesProvider(model),operation_timeout_ms=start['start']['operationTimeoutMs'])
    queues=[workflow_id+'/objective/1',workflow_id+'/execution/1']
    private_client=None;private_converter=None;private_plugin=None
    if planning:
        if type(planner) is not dict or set(planner)!={'boundary','transport','historyKeys','historyKeyId','meterPolicy'}:raise SDKModelPolicyError()
        profile=start['planning'];private_context={**deepcopy(c),'model':deepcopy(profile['plannerModel'])}
        private_transport=planner['transport'];private_boundary=planner['boundary']
        private_meter=planner['meterPolicy'];_validate('AgentModelMeterPolicy',private_meter)
        import hashlib,json
        meter_digest=hashlib.sha256(b'agentic-os.hash/1\0policy\0'+json.dumps(private_meter,
            sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
        if (c['model']!=profile['publicModel'] or private_transport.boundary is not private_boundary
                or private_boundary is boundary or private_transport.config.model_profile_digest!=profile['plannerModel']['digest']
                or meter_digest!=profile['plannerMeterDigest']
                or private_meter['model']!=json.loads(private_transport.config.model_profile_json)
                or private_meter['requestTimeoutMs']!=private_transport.config.request_timeout_ms
                or private_meter['maxRequestBytes']!=private_transport.config.max_request_bytes
                or private_meter['maxResponseBytes']!=private_transport.config.max_response_bytes
                or private_transport.config.credential_ref==config.credential_ref
                or private_transport.client.api_key==transport.client.api_key
                or planner['historyKeyId']==history_key_id
                or planner['historyKeys']._key(planner['historyKeyId'])==history_keys._key(history_key_id)):
            raise SDKModelPolicyError()
        private_converter=agent_converter(private_boundary,planner['historyKeys'],private_context,namespace,
            planner['historyKeyId'],observe_history=True)
        private_model=GovernedResponsesModel(private_transport,max_output_tokens=private_meter['maxOutputTokens'])
        private_plugin=agent_plugin(GovernedResponsesProvider(private_model),operation_timeout_ms=start['start']['operationTimeoutMs'])
        queues.append(workflow_id+'/planner/1')
    async def connect(converter,plugin):
        if cloud_connection is not None:
            return await cloud_connection.connect(data_converter=converter,plugins=[plugin])
        return await Client.connect(target,namespace=namespace,data_converter=converter,plugins=[plugin])
    client=await connect(converter,plugin)
    if planning:
        private_client=await connect(private_converter,private_plugin)
    with ThreadPoolExecutor(max_workers=8,thread_name_prefix='assigned-agent') as pool:
        options=agent_worker_options(boundary)
        async with AsyncExitStack() as workers:
            await workers.enter_async_context(Worker(client,task_queue=queues[0],workflow_task_executor=pool,**options))
            await workers.enter_async_context(Worker(client,task_queue=queues[1],workflow_task_executor=pool,
                **agent_worker_options(boundary,planning_context=c if planning else None,
                    planning_phase='execution' if planning else None)))
            if private_client is not None:
                await workers.enter_async_context(Worker(private_client,task_queue=queues[2],workflow_task_executor=pool,
                    **agent_worker_options(private_boundary,planning_context=private_context,planning_phase='planner')))
            handle=None
            if cloud_connection is None or not cloud_connection.configuration['resumeExisting']:
                if cloud_connection is not None:
                    # TLS/namespace setup must not move the original horizon.
                    remaining=(horizon-datetime.now(timezone.utc)).total_seconds()
                    if remaining<=0:raise SDKModelPolicyError()
                try:
                    handle=await client.start_workflow(AgentTaskDriver.run,start,id=workflow_id,task_queue=queues[0],
                        execution_timeout=timedelta(seconds=math.ceil(remaining)),retry_policy=RetryPolicy(maximum_attempts=1),
                        task_timeout=min(WorkerPolicy(start['start']['operationTimeoutMs']).workflow_task_timeout,
                            timedelta(seconds=math.ceil(remaining))),
                        id_reuse_policy=WorkflowIDReusePolicy.REJECT_DUPLICATE,id_conflict_policy=WorkflowIDConflictPolicy.FAIL)
                except WorkflowAlreadyStartedError:pass
            if handle is None:
                # Replacement/recovery explicitly observes an existing chain.
                # If Cloud history was deleted or expired, fail closed; never
                # turn a missing lookup into a fresh start after retention.
                handle=client.get_workflow_handle(workflow_id)
                description=await handle.describe()
                if (description.raw_description.workflow_execution_info.type.name!='OSAgentTaskDriver/1'
                        or description.raw_description.execution_config.task_queue.name not in queues):raise SDKModelPolicyError()
                original_handle=handle
                if planning:
                    from uuid import UUID
                    first=description.raw_description.workflow_execution_info.first_run_id
                    try:
                        if str(UUID(first))!=first:raise ValueError()
                    except (ValueError,TypeError):raise SDKModelPolicyError() from None
                    original_handle=client.get_workflow_handle(workflow_id,run_id=first)
                history=await original_handle.fetch_history()
                event=history.events[0]
                if not event.HasField('workflow_execution_started_event_attributes'):raise SDKModelPolicyError()
                original=await converter.with_context(WorkflowSerializationContext(namespace,workflow_id)).decode(
                    event.workflow_execution_started_event_attributes.input.payloads)
                if len(original)!=1:raise SDKModelPolicyError()
                _validate(contract,original[0])
                if (original[0]['schema']!=start['schema'] or any(original[0]['start'][key]!=start['start'][key] for key in start['start'] if key!='checkpointId')
                        or original[0]['providers']!=start['providers']
                        or adaptive and original[0]['discoveryCapabilities']!=start['discoveryCapabilities']
                        or planning and original[0]['planning']!=start['planning']):raise SDKModelPolicyError()
            if ready is not None:await ready(workflow_id)
            return await handle.result()


def _private_configuration(path,*,maximum=65536,expected_sha256=None):
    import hashlib,os,re,stat
    from pathlib import Path
    from .model_rpc import _control
    path=Path(path)
    if type(maximum) is not int or maximum not in (65536,16*1024**2):raise SDKModelPolicyError()
    if expected_sha256 is not None and (type(expected_sha256) is not str or re.fullmatch('[a-f0-9]{64}',expected_sha256) is None):
        raise SDKModelPolicyError()
    if not path.is_absolute():raise SDKModelPolicyError()
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as handle:
        info=os.fstat(handle.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077:raise SDKModelPolicyError()
        raw=handle.read(maximum+1)
    if len(raw)>maximum:raise SDKModelPolicyError()
    if expected_sha256 is not None and hashlib.sha256(raw).hexdigest()!=expected_sha256:raise SDKModelPolicyError()
    return _control(raw)


def _workload_token(configuration):
    """Exactly one explicit source; rotating projection never falls back."""
    if 'workloadTokenRoot' in configuration:
        if 'workloadToken' in configuration:raise SDKModelPolicyError()
        from pathlib import Path
        from .workload import ProjectedWorkloadToken
        if type(configuration['workloadTokenRoot']) is not str:raise SDKModelPolicyError()
        return ProjectedWorkloadToken(Path(configuration['workloadTokenRoot']))
    value=configuration.get('workloadToken')
    if type(value) is not str or not 1<=len(value)<=8192:raise SDKModelPolicyError()
    async def token():return value
    return token


def _rpc_tls(configuration):
    value=configuration.get('rpcTLS')
    if 'rpcTLS' not in configuration:return None
    try:
        import hashlib,re,ssl
        if (type(value) is not dict or set(value)!={'ca','sha256'} or type(value['ca']) is not str
                or not 1<=len(value['ca'])<=32768 or type(value['sha256']) is not str
                or re.fullmatch(r'[a-f0-9]{64}',value['sha256']) is None
                or hashlib.sha256(value['ca'].encode('ascii')).hexdigest()!=value['sha256']):raise ValueError()
        return ssl.create_default_context(cadata=value['ca'])
    except Exception:raise SDKModelPolicyError() from None


def _configuration_shape(configuration,planning):
    """The ordinary entry prefix, also used before any task admission."""
    expected={'profile','target','namespace','kernelOrigin','transport','apiKey','historyKeyId','historyKeyHex'}
    expected.add('workloadTokenRoot' if 'workloadTokenRoot' in configuration else 'workloadToken')
    if 'reasoningEffort' in configuration:
        expected.add('reasoningEffort')
        if (type(configuration['reasoningEffort']) is not str
                or configuration['reasoningEffort'] not in {'none','low','medium','high','xhigh'}):raise SDKModelPolicyError()
    if 'rpcTLS' in configuration:expected.add('rpcTLS')
    if 'nativeOrigin' in configuration:
        expected.add('nativeOrigin')
        if type(configuration['nativeOrigin']) is not str:raise SDKModelPolicyError()
    backend='self-hosted' if configuration.get('profile') in {
        'assigned-read-self-hosted/1','assigned-private-planned-read-self-hosted/1'} else 'cloud'
    cloud=configuration.get('profile') in {'assigned-read-cloud/1','assigned-private-planned-read-cloud/1',
        'assigned-read-self-hosted/1','assigned-private-planned-read-self-hosted/1'}
    if cloud:expected.add('temporal')
    if planning:expected.add('planner')
    if (set(configuration)!=expected or configuration['profile']!=
            ('assigned-private-planned-read-'+(backend+'/1' if cloud else 'local/1') if planning
                else 'assigned-read-'+(backend+'/1' if cloud else 'local/1'))):
        raise SDKModelPolicyError()
    from .temporal_cloud import CloudTemporalConnection
    cloud_connection=CloudTemporalConnection(configuration['temporal']) if cloud else None
    if cloud and cloud_connection.configuration['profile']!='temporal-'+backend+'-mtls/1':
        raise SDKModelPolicyError()
    return cloud,cloud_connection


def _planner_shape(value):
    fields={'transport','apiKey','historyKeyId','historyKeyHex','meterPolicyJson'}
    if type(value) is not dict:raise SDKModelPolicyError()
    fields.add('workloadTokenRoot' if 'workloadTokenRoot' in value else 'workloadToken')
    if set(value)!=fields:raise SDKModelPolicyError()


def configuration_inspection(configuration):
    """Validate static private inputs without a start, client or token read.

    Projected tokens and task-specific authority remain checked by the ordinary
    entry at execution. No fake Root/context is needed to prepare an operator
    installation, and this result grants no execution or qualification.
    """
    from pathlib import Path
    from .model_rpc import _rpc_origin,_control
    from .transport import TransportConfig
    from .policy import verify_dependencies
    verify_dependencies()
    planning=configuration.get('profile') in {'assigned-private-planned-read-local/1',
        'assigned-private-planned-read-cloud/1','assigned-private-planned-read-self-hosted/1'}
    cloud,connection=_configuration_shape(configuration,planning)
    _rpc_origin(configuration['kernelOrigin'],local_synthetic=not cloud)
    if 'nativeOrigin' in configuration:_rpc_origin(configuration['nativeOrigin'],local_synthetic=not cloud)
    _rpc_tls(configuration)
    if cloud:
        if configuration['target']!=connection.target or configuration['namespace']!=connection.namespace:raise SDKModelPolicyError()
    else:
        try:
            host,port=configuration['target'].rsplit(':',1)
            if not ipaddress.ip_address(host.strip('[]')).is_loopback or not 1<=int(port)<=65535:raise ValueError()
            if type(configuration['namespace']) is not str or not 1<=len(configuration['namespace'])<=256:raise ValueError()
        except Exception:raise SDKModelPolicyError() from None
    models=[]
    for value in ([configuration,configuration['planner']] if planning else [configuration]):
        if value is not configuration:_planner_shape(value)
        if type(value['apiKey']) is not str or not value['apiKey']:raise SDKModelPolicyError()
        config=TransportConfig(**value['transport']);config.validate_privacy();models.append(config.model_profile_digest)
        if len(bytes.fromhex(value['historyKeyHex']))!=32:raise SDKModelPolicyError()
        if 'workloadTokenRoot' in value:
            root=Path(value['workloadTokenRoot'])
            if not root.is_absolute() or root.resolve()!=root:raise SDKModelPolicyError()
        else:_workload_token(value)  # Constructs the existing supplier; never reads it.
        if value is not configuration:_validate('AgentModelMeterPolicy',_control(value['meterPolicyJson']))
    return dict(state='configuration-validated',profile=configuration['profile'],
        target=configuration['target'],namespace=configuration['namespace'],
        installationId=connection.configuration['installationId'] if cloud else None,
        namespaceId=connection.configuration['namespaceId'] if cloud else None,
        modelProfileDigests=models,historyKeyIds=[v['historyKeyId'] for v in
            ([configuration,configuration['planner']] if planning else [configuration])],
        kernelOrigin=configuration['kernelOrigin'],nativeOrigin=configuration.get('nativeOrigin'),
        temporalProfile=connection.configuration['profile'] if cloud else None,
        retentionDays=connection.configuration['retentionDays'] if cloud else None,
        runtimeStarted=False,newProviderCalls=0)


async def assigned_main(configuration,start):
    """Local operator configuration is private; submitted input arrives by pipe."""
    from dataclasses import asdict
    import json
    from .model_rpc import RPCModelBoundary
    from .transport import OfficialTransport,TransportConfig
    from .workflow_control import WorkflowControl
    planning=start.get('schema')=='agent-private-planned-read-journey/1'
    cloud,cloud_connection=_configuration_shape(configuration,planning)
    class Keys:
        def __init__(self,value):self.value=value
        def _key(self,key_id):
            if key_id!=self.value['historyKeyId']:raise SDKModelPolicyError()
            key=bytes.fromhex(self.value['historyKeyHex'])
            if len(key)!=32:raise SDKModelPolicyError()
            return key
    token=_workload_token(configuration);tls=_rpc_tls(configuration)
    boundary=None;transport=None;planner=None;private_boundary=None;private_transport=None
    async def ready(_):
        c=start['start']['context']
        print(json.dumps(asdict(WorkflowControl(c['rootId'],c['taskId'],None,'running')),separators=(',',':')),flush=True)
    try:
        boundary=RPCModelBoundary(configuration['kernelOrigin'],token,local_synthetic=not cloud,
            native_origin=configuration.get('nativeOrigin'),tls_context=tls)
        transport=OfficialTransport(TransportConfig(**configuration['transport']),boundary,api_key=configuration['apiKey'])
        if planning:
            value=configuration['planner']
            _planner_shape(value)
            private_token=_workload_token(value)
            private_boundary=RPCModelBoundary(configuration['kernelOrigin'],private_token,local_synthetic=not cloud,
                native_origin=configuration.get('nativeOrigin'),tls_context=tls)
            private_transport=OfficialTransport(TransportConfig(**value['transport']),private_boundary,api_key=value['apiKey'])
            from .model_rpc import _control
            planner=dict(boundary=private_boundary,transport=private_transport,historyKeys=Keys(value),
                historyKeyId=value['historyKeyId'],meterPolicy=_control(value['meterPolicyJson']))
        result=await serve_read_task(target=configuration['target'],namespace=configuration['namespace'],boundary=boundary,
            transport=transport,history_keys=Keys(configuration),history_key_id=configuration['historyKeyId'],start=start,ready=ready,
            local_synthetic=not cloud,planner=planner,cloud_connection=cloud_connection,
            reasoning_effort=configuration.get('reasoningEffort'))
        print(json.dumps(asdict(result),separators=(',',':')),flush=True)
    finally:
        if private_transport is not None:await private_transport.close()
        if private_boundary is not None:await private_boundary.close()
        if transport is not None:await transport.close()
        if boundary is not None:await boundary.close()


def main():
    import argparse,asyncio,sys
    from .model_rpc import _control
    parser=argparse.ArgumentParser(description='Explicit assigned local/Cloud SDK read worker')
    parser.add_argument('--configuration',required=True)
    parser.add_argument('--configuration-sha256',help='Exact operator-selected private configuration bytes')
    parser.add_argument('--start-file',help='Explicit private original start file; otherwise read the existing pipe')
    parser.add_argument('--check-configuration',action='store_true',help='Read-only static check; consumes no start and makes no connection or model call')
    args=parser.parse_args()
    try:
        configuration=_private_configuration(args.configuration,expected_sha256=args.configuration_sha256)
        if args.check_configuration:
            if args.start_file is not None:raise SDKModelPolicyError()
            import json
            print(json.dumps(configuration_inspection(configuration),separators=(',',':')))
            return 0
        if args.start_file is None:
            raw=sys.stdin.buffer.read(16*1024**2+1)
            if len(raw)>16*1024**2:raise SDKModelPolicyError()
            start=_control(raw)
        else:start=_private_configuration(args.start_file,maximum=16*1024**2)
        from .read_journey import start_contract
        _validate(start_contract(start),start)
        asyncio.run(assigned_main(configuration,start))
    except Exception:
        # Submitted source, provider text and secret configuration never become
        # process diagnostics. The kernel retains authoritative private facts.
        print('assigned_worker_unavailable',file=sys.stderr)
        return 1
    return 0


if __name__=='__main__':
    raise SystemExit(main())
