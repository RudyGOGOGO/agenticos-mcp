"""Translate the governed SDK transcript to stateless Claude Messages.

Core still verifies the exact canonical function proposal against the original
registered schema. The raw Claude response is archived separately as evidence.
"""
import json

from anthropic import transform_schema


def _text_parts(value):
    if isinstance(value, str):
        return value
    if not isinstance(value, list) or any(
            part.get('type') not in {'input_text', 'output_text'} or not isinstance(part.get('text'), str)
            for part in value):
        raise ValueError('Unsupported message content')
    return ''.join(part['text'] for part in value)


def messages_body(body, parse):
    messages = []
    pending = set()
    call_ids = set()

    def append(role, block):
        if messages and messages[-1]['role'] == role:
            messages[-1]['content'].append(block)
        else:
            messages.append(dict(role=role, content=[block]))

    system = [body['instructions']] if body.get('instructions') else []
    items = body['input']
    if isinstance(items, str):
        items = [dict(role='user', content=items)]
    for item in items:
        kind = item.get('type', 'message')
        if kind == 'reasoning':
            # Foreign encrypted reasoning is never sent to Claude.
            continue
        if kind == 'function_call':
            if messages and messages[-1]['role'] != 'assistant' and pending:
                raise ValueError('Unresolved tool calls')
            ident = item['call_id']
            arguments = parse(item['arguments'])
            if not ident or ident in call_ids or type(arguments) is not dict:
                raise ValueError('Invalid tool call')
            call_ids.add(ident)
            pending.add(ident)
            append('assistant', dict(type='tool_use', id=ident, name=item['name'], input=arguments))
        elif kind == 'function_call_output':
            ident = item['call_id']
            if ident not in pending or not isinstance(item['output'], str):
                raise ValueError('Invalid tool result')
            pending.remove(ident)
            append('user', dict(type='tool_result', tool_use_id=ident, content=item['output']))
        elif kind == 'message':
            role = item['role']
            if pending:
                raise ValueError('Missing tool results')
            content = _text_parts(item['content'])
            if role in {'system', 'developer'} and not messages:
                system.append(content)
            elif role in {'user', 'assistant'}:
                if content:
                    append(role, dict(type='text', text=content))
            else:
                raise ValueError('Unsupported message role')
        else:
            raise ValueError('Unsupported transcript item')
    if pending or not messages or messages[0]['role'] != 'user' or messages[-1]['role'] != 'user':
        raise ValueError('Incomplete Claude transcript')
    result = dict(messages=messages, thinking=dict(type='disabled'))
    if system:
        result['system'] = '\n\n'.join(system)
    if body.get('tools'):
        result['tools'] = [dict(name=tool['name'], description=tool['description'], input_schema=tool['parameters'])
            for tool in body['tools']]
        choice = body.get('tool_choice', 'auto')
        if isinstance(choice, dict):
            choice = dict(type='tool', name=choice['name'])
        else:
            choice = dict(type='any' if choice == 'required' else choice)
        if choice['type'] != 'none' and body.get('parallel_tool_calls') is False:
            choice['disable_parallel_tool_use'] = True
        result['tool_choice'] = choice
    output = body.get('text', {}).get('format')
    if output:
        result['output_config'] = dict(format=dict(type='json_schema', schema=transform_schema(output['schema'])))
    return result


def accepted_response(payload, usage):
    """Project complete text and custom tool blocks into the governed SDK shape."""
    if payload.get('type') != 'message' or payload.get('role') != 'assistant' or not payload.get('id'):
        raise ValueError('Invalid Claude message')
    output = []
    calls = set()
    for index, block in enumerate(payload['content']):
        ident = payload['id'] + '_' + str(index)
        if block['type'] == 'text' and isinstance(block['text'], str):
            output.append(dict(type='message', id=ident, role='assistant', status='completed',
                content=[dict(type='output_text', text=block['text'], annotations=[])]))
        elif block['type'] == 'tool_use' and type(block['input']) is dict and block['id'] and block['id'] not in calls:
            calls.add(block['id'])
            output.append(dict(type='function_call', id=ident, call_id=block['id'], name=block['name'],
                arguments=json.dumps(block['input'], ensure_ascii=False, allow_nan=False, separators=(',', ':')),
                status='completed'))
        else:
            raise ValueError('Unsupported Claude output block')
    if not output or bool(calls) != (payload['stop_reason'] == 'tool_use'):
        raise ValueError('Inconsistent Claude stop reason')
    input_total = sum(usage[field] for field in ('uncachedInputTokens', 'cachedInputTokens',
        'cacheWrite5mTokens', 'cacheWrite1hTokens', 'cacheWriteUnspecifiedTokens'))
    return dict(id=payload['id'], model=payload['model'], object='response', created_at=0,
        status='completed', error=None, output=output, parallel_tool_calls=len(calls)>1,
        instructions=None, tool_choice='auto', tools=[],
        usage=dict(input_tokens=input_total, output_tokens=usage['outputTokens'],
            total_tokens=input_total+usage['outputTokens'],
            input_tokens_details=dict(cached_tokens=usage['cachedInputTokens'],
                cache_write_tokens=input_total-usage['uncachedInputTokens']-usage['cachedInputTokens']),
            output_tokens_details=dict(reasoning_tokens=0)))
