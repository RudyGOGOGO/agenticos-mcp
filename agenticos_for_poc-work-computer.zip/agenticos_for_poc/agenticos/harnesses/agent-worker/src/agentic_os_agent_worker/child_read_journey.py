"""Separate focused SDK contexts within the original durable Temporal task.

The kernel owns scope, active admission, accepted results and completion. This
adapter reuses SDK checkpoints and the parent's history rollover; it owns no
balance, tool authority, work queue or independent task/root.
"""
from dataclasses import replace
from copy import deepcopy
import asyncio
import json
from uuid import UUID,uuid5

from agents import Agent,ModelSettings,RunConfig,Runner
from temporalio import workflow
from temporalio.exceptions import ApplicationError

from .checkpoint import export_checkpoint,restore_checkpoint
from .sdk_model import BINDING_KEY,SDKModelSequence,SDKModelPolicyError
from .sdk_tools import governed_read_tool
from .transport import _json,_validate
from .workflow_control import WorkflowControl,WAIT_TYPE


def _dump(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def _deferred(context,operation,preparation):
    from .temporal_driver import _control
    status='waiting-resources' if preparation['kind'] in {'resource-wait','resource-limit'} else 'waiting-reconciliation'
    return ApplicationError('agent_wait',_control(context,status,operation),type=WAIT_TYPE,non_retryable=True)


async def _run_child(driver,value,boundary,item,*,batch=False):
    from .temporal_driver import _control,_wait
    start=value['start'];context=start['context'];scope=item['scope'];child_id=scope['childId']
    selected=[entry for entry in start['capabilities'] if entry['capability']==scope['adapter']['capability']]
    if len(selected)!=1 or scope['goal']['context']!=context:raise SDKModelPolicyError()
    pins=[selected[0]['capability']]
    state=value['childContinuation']
    if state is None:
        state=dict(childId=child_id,checkpointId=item['checkpointId'],continuationInputJson=None,
            binding=dict(context=context,sdkInstanceId=scope['sdkInstanceId'],turn=1,planRevision=1,
                parentOperationId=scope['parentOperationId'],inputResults=[]))
        value['childContinuation']=state
    if state['childId']!=child_id:raise SDKModelPolicyError()
    while True:
        if driver.stopped:return _control(context,'stopped')
        if driver._expired():return _control(context,'authorization-expired')
        sequence=None;control=None
        try:
            saved=None
            if state['checkpointId'] is not None:
                saved=await boundary.get_checkpoint(context,state['checkpointId'])
                state['binding']=saved['binding']
            if state['binding']['context']!=context or state['binding']['sdkInstanceId']!=scope['sdkInstanceId']:
                raise SDKModelPolicyError()
            sequence=SDKModelSequence(state['binding'],dependency_boundary=boundary)
            typed_completion=workflow.patched('child-read-output-contracts/1')
            from .memory_output import LookupOutput
            agent=Agent(name='Focused governed child read',model=start['modelId'],instructions=item['instructions'],
                output_type=LookupOutput(objective=False) if typed_completion else None,
                model_settings=ModelSettings(metadata={BINDING_KEY:_dump(state['binding'])},store=False,max_tokens=start['maxOutputTokens']))
            result_context='agent-accepted-read-ref/1' if value['schema'] in {'agent-reference-child-read-journey/1','agent-parallel-child-read-journey/1','agent-source-child-read-journey/1','agent-source-child-reduction-journey/1','agent-parallel-source-child-reduction-journey/1','agent-source-child-join-journey/1','agent-paged-source-child-join-journey/1','agent-query-source-child-join-journey/1'} else 'agent-accepted-read/1'
            agent.tools=[replace(governed_read_tool(selected[0],boundary,sequence,result_context=result_context),needs_approval=True)]
            initial=item['input'] if state['continuationInputJson'] is None else _json(state['continuationInputJson'])
            if saved is not None:
                restored=await restore_checkpoint(agent,saved,expected_context=context,sdk_instance_id=scope['sdkInstanceId'],
                    capabilities=pins,sequence=sequence,dependency_boundary=boundary)
                initial=restored.state
                for interruption in initial.get_interruptions():initial.approve(interruption)
            driver.control=_control(context,'running',state['binding']['parentOperationId'])
            while True:
                if typed_completion and driver.stopped:return _control(context,'stopped')
                if typed_completion and driver._expired():return _control(context,'authorization-expired')
                result=await Runner.run(agent,initial,max_turns=None,hooks=sequence,
                    run_config=RunConfig(model=start['modelId'],tracing_disabled=True))
                if result.interruptions or not typed_completion:break
                from .memory_output import completion_frame_valid,COMPLETION_FRAME_FEEDBACK,analysis_feedback_message,analysis_repeated_completion
                output=[entry.model_dump(mode='json') for entry in result.raw_responses[-1].output] if result.raw_responses else []
                if completion_frame_valid(output):break
                current=result.to_input_list()
                if analysis_repeated_completion(current,result.final_output,COMPLETION_FRAME_FEEDBACK):
                    return _control(context,'configuration-required',sequence.snapshot()['parentOperationId'])
                initial=[*current,analysis_feedback_message(COMPLETION_FRAME_FEEDBACK,sequence.snapshot()['parentOperationId'])]
            if result.interruptions:
                envelope=export_checkpoint(result,sequence,pins)
                checkpoint=str(uuid5(UUID(scope['sdkInstanceId']),'checkpoint/'+str(sequence.snapshot()['turn'])))
                stored=await boundary.put_checkpoint(checkpoint,envelope) if batch else await driver._save(boundary,checkpoint,envelope)
                if isinstance(stored,WorkflowControl):return stored
                if batch and stored['kind']!='ready':raise _deferred(context,sequence.snapshot()['parentOperationId'],stored)
                item=await boundary.child_checkpoint(context,sequence.snapshot()['parentOperationId'],child_id,checkpoint)
                _validate('AgentChildWorkerItem',item)
                state.update(binding=sequence.snapshot(),checkpointId=checkpoint,continuationInputJson=None)
                _validate('AgentSDKChildContinuation',state)
                if not batch and (workflow.info().is_continue_as_new_suggested() or workflow.info().get_current_history_length()>=start['maxSegmentEvents']):
                    workflow.continue_as_new(value)
                continue
            operation=sequence.snapshot()['parentOperationId']
            while True:
                try:
                    completed=await boundary.child_complete(context,operation,child_id)
                    _validate('AgentChildCompletionResponse',completed)
                    if completed['kind']=='storage':raise _deferred(context,operation,completed['preparation'])
                    break
                except Exception as error:
                    wait=_wait(error,context,operation)
                    if wait is None:raise
                    if wait.status in {'configuration-required','scope-changed','model-failed','storage-failed'}:return wait
                    if batch:return wait
                    await driver._pause(wait)
                    if driver.stopped:return _control(context,'stopped')
                    if driver._expired():return _control(context,'authorization-expired')
            if completed['kind']=='completed':return completed['item']
            feedback='Complete the remaining focused criterion fields from current governed evidence: '+_dump(completed['missingCriteria'])
            state.update(binding=sequence.snapshot(),checkpointId=None,
                continuationInputJson=_dump([*result.to_input_list(),dict(role='user',content=feedback)]))
            _validate('AgentSDKChildContinuation',state)
            if batch:return _control(context,'running',operation)
            workflow.continue_as_new(value)
        except Exception as error:
            operation=(sequence.pending if sequence is not None and sequence.pending is not None else state['binding']['parentOperationId'])
            control=_wait(error,context,operation)
            if control is None:raise
            if control.operationId is None and operation is not None:control=replace(control,operationId=operation)
        # Do not retain an arbitrary private exception/cause with this control.
        if batch:return control
        raise ApplicationError('agent_wait',control,type=WAIT_TYPE,non_retryable=True)


async def run_children(driver,value,boundary):
    """Process a bounded current page; accepted children survive every rollover."""
    from .temporal_driver import _control
    context=value['start']['context'];parent=value['binding']
    if parent is None or parent['parentOperationId'] is None:raise SDKModelPolicyError()
    page=await boundary.child_page(context,parent['parentOperationId'],after=value['childAfter'])
    _validate('AgentChildWorkerPage',page)
    if page['context']!=context:raise SDKModelPolicyError()
    if not page['items']:
        value.update(phase='execution',childContinuation=None)
        return None
    item=page['items'][0];child_id=item['scope']['childId']
    if item['state']=='UNSTARTED':
        admitted=await boundary.child_start(context,parent['parentOperationId'],child_id)
        _validate('AgentChildAdmissionResponse',admitted)
        if admitted['kind']=='storage':raise _deferred(context,parent['parentOperationId'],admitted['preparation'])
        item=admitted['item']
    if item['state']=='INTERRUPTED':return _control(context,'model-failed',parent['parentOperationId'])
    if item['state']!='COMPLETED':
        item=await _run_child(driver,value,boundary,item)
        if isinstance(item,WorkflowControl):return item
    verification=item['verification']
    if verification is None or item['scope']['childId']!=child_id:raise SDKModelPolicyError()
    # Reuse the SDK's existing bounded reference packing for the parent join.
    # Neither all child messages nor their private prompts enter parent context.
    sequence=SDKModelSequence(parent,dependency_boundary=boundary)
    carrier=Agent(name='Parent accepted child references',model_settings=ModelSettings(metadata={BINDING_KEY:_dump(parent)}))
    await sequence.add_tool_result(verification['candidate'],carrier)
    value.update(binding=sequence.snapshot(),childAfter=child_id,childContinuation=None)
    from .read_journey import start_contract
    _validate(start_contract(value),value)
    workflow.continue_as_new(value)


async def run_parallel_children(driver,value,boundary):
    """Quiesce bounded independent SDK contexts before any shared wait/rollover."""
    from .temporal_driver import _control,_wait
    context=value['start']['context'];parent=value['binding']
    if parent is None or parent['context']!=context or parent['parentOperationId'] is None:raise SDKModelPolicyError()
    page=await boundary.child_parallel_page(context,parent['parentOperationId'],after=value['childAfter'])
    _validate('AgentParallelChildWorkerPage',page)
    if page['context']!=context:raise SDKModelPolicyError()
    window=page['items'][:page['maxActiveChildren']]
    identities=[item['scope']['childId'] for item in window]
    saved={state['childId']:deepcopy(state) for state in value['childContinuations']}
    if (len(set(identities))!=len(identities) or len(saved)!=len(value['childContinuations'])
            or set(saved)-set(identities)):raise SDKModelPolicyError()
    for item in window:
        state=saved.get(item['scope']['childId'])
        if state is not None and (state['binding']['context']!=context
                or state['binding']['sdkInstanceId']!=item['scope']['sdkInstanceId']):raise SDKModelPolicyError()
    if not window:
        value.update(phase='execution',childContinuations=[])
        return None
    branches=[dict(value,childContinuation=saved.get(ident)) for ident in identities]
    async def execute(branch,item):
        ident=item['scope']['childId']
        if item['scope']['policy']!=page['policy']:raise SDKModelPolicyError()
        try:
            if driver.stopped:return _control(context,'stopped')
            if item['state']=='UNSTARTED':
                admitted=await boundary.child_start(context,parent['parentOperationId'],ident)
                _validate('AgentChildAdmissionResponse',admitted)
                if admitted['kind']=='storage':raise _deferred(context,parent['parentOperationId'],admitted['preparation'])
                item=admitted['item']
            if item['state']=='INTERRUPTED':return _control(context,'model-failed',parent['parentOperationId'])
            if item['state']!='COMPLETED':item=await _run_child(driver,branch,boundary,item,batch=True)
            if isinstance(item,WorkflowControl):return item
            if item['scope']['childId']!=ident or item['verification'] is None:raise SDKModelPolicyError()
            return item
        except Exception as error:
            control=_wait(error,context,parent['parentOperationId'])
            if control is None:raise
            return control
    # All branch calls settle before propagating a failure or changing history.
    # Cancellation/worker death never pretends already dispatched work is free.
    results=await asyncio.gather(*(execute(branch,item) for branch,item in zip(branches,window)),return_exceptions=True)
    value['childContinuations']=[branch['childContinuation'] for branch,result in zip(branches,results)
        if branch['childContinuation'] is not None and isinstance(result,WorkflowControl)]
    errors=[result for result in results if isinstance(result,BaseException)]
    if errors:raise errors[0]
    if driver.stopped:return _control(context,'stopped')
    controls=[result for result in results if isinstance(result,WorkflowControl)]
    if controls:
        fatal=[item for item in controls if item.status in {'stopped','authorization-expired','configuration-required','scope-changed','model-failed','storage-failed'}]
        if fatal:return fatal[0]
        waiting=[item for item in controls if item.status!='running']
        if waiting:
            driver.parallel_resume_operations=frozenset(item.operationId for item in waiting if item.operationId is not None)
            try:await driver._pause(waiting[0])
            finally:driver.parallel_resume_operations=frozenset()
            if (value['schema']=='agent-query-source-child-join-journey/1'
                    and workflow.patched('query-child-wait-resume-in-place/1')):
                if driver.stopped:return _control(context,'stopped')
                if driver._expired():return _control(context,'authorization-expired')
                # Retry the current-source gate and original private producer
                # before another history write can queue behind that producer.
                # The existing checkpoint and Activity history retain the step.
                return None
        if driver.stopped:return _control(context,'stopped')
        from .read_journey import start_contract
        _validate(start_contract(value),value)
        workflow.continue_as_new(value)
    sequence=SDKModelSequence(parent,dependency_boundary=boundary)
    carrier=Agent(name='Parent accepted parallel child references',model_settings=ModelSettings(metadata={BINDING_KEY:_dump(parent)}))
    for item in results:await sequence.add_tool_result(item['verification']['candidate'],carrier)
    value.update(binding=sequence.snapshot(),childAfter=identities[-1],childContinuations=[])
    from .read_journey import start_contract
    _validate(start_contract(value),value)
    workflow.continue_as_new(value)


async def run_source_child(driver,value,boundary):
    """Finish one narrow source, then receive the kernel-derived target goal."""
    from .temporal_driver import _control
    context=value['start']['context'];parent=value['binding']
    if parent is None or parent['context']!=context or parent['parentOperationId'] is None:raise SDKModelPolicyError()
    from .read_journey import REDUCTION_JOURNEYS
    state_schema='AgentPagedSourceChildWorkerState' if value['schema']=='agent-paged-source-child-join-journey/1' else 'AgentSourceChildWorkerState'
    source_state=(boundary.child_paged_source_join_state if value['schema']=='agent-paged-source-child-join-journey/1' else boundary.child_source_join_state if value['schema']=='agent-source-child-join-journey/1' else boundary.child_source_reduction_state if value['schema'] in REDUCTION_JOURNEYS
        else boundary.child_source_state)
    state=await source_state(context,parent['parentOperationId'])
    _validate(state_schema,state)
    if state['kind'] in {'storage','goal-page-storage'}:raise _deferred(context,state['writeId'],state['preparation'])
    if state['context']!=context:raise SDKModelPolicyError()
    item=state['source'];child_id=item['scope']['childId']
    if item['state']=='UNSTARTED':
        admitted=await boundary.child_start(context,parent['parentOperationId'],child_id)
        _validate('AgentChildAdmissionResponse',admitted)
        if admitted['kind']=='storage':raise _deferred(context,parent['parentOperationId'],admitted['preparation'])
        item=admitted['item']
    if item['state']=='INTERRUPTED':return _control(context,'model-failed',parent['parentOperationId'])
    if item['state']!='COMPLETED':
        item=await _run_child(driver,value,boundary,item)
        if isinstance(item,WorkflowControl):return item
        state=await source_state(context,parent['parentOperationId'])
        _validate(state_schema,state)
        if state['kind'] in {'storage','goal-page-storage'}:raise _deferred(context,state['writeId'],state['preparation'])
    if (state['source']['scope']['childId']!=child_id or state['targetCount'] is None
            or state['goalDigest'] is None or item['verification'] is None):raise SDKModelPolicyError()
    sequence=SDKModelSequence(parent,dependency_boundary=boundary)
    carrier=Agent(name='Accepted source child reference',model_settings=ModelSettings(metadata={BINDING_KEY:_dump(parent)}))
    await sequence.add_tool_result(item['verification']['candidate'],carrier)
    value.update(binding=sequence.snapshot(),goalDigest=state['goalDigest'],
        phase='children' if state['targetCount'] else 'execution',childContinuation=None,childAfter=None,childContinuations=[])
    from .read_journey import start_contract
    _validate(start_contract(value),value)
    workflow.continue_as_new(value)
