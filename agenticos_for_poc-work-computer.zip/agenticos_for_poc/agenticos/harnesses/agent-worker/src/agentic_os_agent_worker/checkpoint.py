"""Supported private SDK pause serialization with explicit continuation pins.

The kernel must store/read this envelope through its governed encrypted artifact
boundary and revalidate current authority. Serialized SDK approvals, text, tools
and summaries issue no OS grant. This adapter never approves an interruption.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json

from agents import FunctionTool,RunConfig,Runner,RunState

from .policy import verify_dependencies
from .sdk_model import BINDING_KEY,GovernedResponsesProvider,SDKModelSequence
from .transport import _json,_validate

FORMAT='openai-agents/0.19.4/run-state/1.13'
MAXIMUM_STATE_BYTES=1048576


class SDKCheckpointError(ValueError):
    def __init__(self):super().__init__('unqualified_sdk_checkpoint')


def _dump(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def tool_alias(pin):
    _validate('AgentVersionPin',pin)
    return 'cap_'+hashlib.sha256(_dump(pin).encode()).hexdigest()[:40]


def _state(raw):
    if type(raw) is not str or len(raw.encode('utf-8'))>MAXIMUM_STATE_BYTES:raise SDKCheckpointError()
    state=_json(raw)
    if (type(state) is not dict or state.get('$schemaVersion')!='1.13' or state.get('max_turns') is not None
            or state.get('trace') is not None or state.get('sandbox') is not None
            or state.get('conversation_id') is not None or state.get('previous_response_id') is not None):raise SDKCheckpointError()
    return state


def export_checkpoint(result,sequence,capabilities):
    """One supported SDK pause; result/context content remains private data."""
    verify_dependencies()
    if not isinstance(sequence,SDKModelSequence) or sequence.pending is not None or not result.interruptions:raise SDKCheckpointError()
    state=result.to_state().to_json(strict_context=True,include_tracing_api_key=False)
    raw=_dump(state);_state(raw)
    value=dict(format=FORMAT,binding=sequence.snapshot(),capabilities=deepcopy(capabilities),stateJson=raw)
    _validate('AgentSDKCheckpointState',value)
    if value['binding']['context']['harness']['ref'].startswith('governed-read-discovery/'):
        # Check the actual public Temporal encoding before reserving/writing
        # private history. Unsupported provider state is a policy refusal,
        # never a late codec failure or permission to repeat accepted work.
        from .workflow_control import AgentPayloadConverter
        payload=AgentPayloadConverter().to_payloads([dict(checkpointId='00000000-0000-4000-8000-000000000001',value=value)])[0]
        if len(payload.SerializeToString(deterministic=True))>65536:raise SDKCheckpointError()
    return value


@dataclass
class RestoredSDKCheckpoint:
    agent:object
    state:RunState
    sequence:SDKModelSequence

    async def run(self,provider):
        """The controller authorizes pending work before SDK continuation."""
        if (not isinstance(provider,GovernedResponsesProvider)
                or provider.model.transport.config.model_profile_digest!=self.sequence.snapshot()['context']['model']['digest']):raise SDKCheckpointError()
        model=provider.model.transport.config.model_id
        return await Runner.run(self.agent,self.state,max_turns=None,hooks=self.sequence,
            run_config=RunConfig(model=model,model_provider=provider,tracing_disabled=True))


async def restore_checkpoint(agent,value,*,expected_context,sdk_instance_id,capabilities,
                             sequence=None,dependency_boundary=None):
    """Expected values must come from current kernel/worker assignment records."""
    verify_dependencies();value=deepcopy(value);capabilities=deepcopy(capabilities)
    _validate('AgentSDKCheckpointState',value);_validate('AgentTaskContext',expected_context)
    binding=value['binding']
    if (binding['context']!=expected_context or binding['sdkInstanceId']!=sdk_instance_id
            or value['capabilities']!=capabilities
            or len(agent.tools)!=len(capabilities)
            or any(not isinstance(tool,FunctionTool) for tool in agent.tools)
            or [tool.name for tool in agent.tools]!=[tool_alias(pin) for pin in capabilities]):raise SDKCheckpointError()
    if sequence is None:
        sequence=SDKModelSequence(binding,dependency_boundary=dependency_boundary)
    elif (not isinstance(sequence,SDKModelSequence) or sequence.pending is not None or sequence.snapshot()!=binding
            or dependency_boundary is not None and sequence.dependency_boundary is not dependency_boundary):raise SDKCheckpointError()
    state=_state(value['stateJson'])
    metadata=agent.model_settings.metadata
    if metadata is not None and set(metadata)-{BINDING_KEY}:raise SDKCheckpointError()
    # The SDK copies settings before its next start hook. Publish the saved
    # next-operation binding before loading/running, as the public end hook does
    # during a continuous run. A replacement worker must not start with an
    # empty metadata copy or create a new sequence/operation identity.
    agent.model_settings.metadata={BINDING_KEY:_dump(binding)}
    # Use the public loader with a freshly built registered agent. The explicit
    # model override in run() also wraps the restored agent's model and prevents
    # a saved model name from selecting the SDK's direct/default API provider.
    restored=await RunState.from_json(agent,state,strict_context=True)
    # Governed FunctionTool callbacks capture their sequence. Reuse that exact
    # caller-built instance instead of restoring a second, disconnected cursor.
    return RestoredSDKCheckpoint(agent,restored,sequence)
