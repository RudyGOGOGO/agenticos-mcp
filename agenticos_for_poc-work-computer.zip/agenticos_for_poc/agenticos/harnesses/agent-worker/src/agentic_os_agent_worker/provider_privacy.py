"""Resolve immutable provider settings; account controls need external evidence.

This is worker configuration, not a provider-policy registry or an assertion of
zero retention. The supported network placement is the explicit global endpoint.
Regional or stricter account requirements cannot fall back to that endpoint.
"""
import hashlib
import json


def _pin(value):
    raw=json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
    return dict(ref=value['id'],revision=value['revision'],digest=hashlib.sha256(
        b'agentic-os.hash/1\0manifest\0'+raw).hexdigest())


def resolve_privacy(raw,profile,*,base_url,inference_geo,parse):
    """Return no secrets or mutable policy objects to the transport.

    Both documents are authenticated by the complete server-owned model pin.
    Credential/endpoint references bind account controls to the selected profile;
    the documents cannot alter request retention, routing or provider selection.
    """
    if type(raw) is not str or not 1<=len(raw.encode('utf-8'))<=16384:
        raise ValueError('Provider privacy configuration required')
    value=parse(raw)
    if type(value) is not dict or set(value)!={'retention','residency'}:
        raise ValueError('Closed provider privacy configuration required')
    retention,residency=value['retention'],value['residency']
    for name,document in value.items():
        if (type(document) is not dict or type(document.get('id')) is not str
                or not 1<=len(document['id'])<=256
                or type(document.get('revision')) is not int or not 1<=document['revision']<2**53
                or document.get('provider')!=profile['provider'] or _pin(document)!=profile[name]):
            raise ValueError('Provider privacy pin differs')
    if (set(retention)!={'id','revision','provider','credentialRef','mode','requestStorage','accountPolicyRef'}
            or retention['credentialRef']!=profile['credentialRef']
            or retention['mode']!='provider-account-managed'
            or retention['requestStorage']!=('disabled' if profile['provider']=='openai' else 'provider-account-managed')
            or type(retention['accountPolicyRef']) is not str or not 1<=len(retention['accountPolicyRef'])<=256):
        raise ValueError('Unsupported provider retention configuration')
    if (set(residency)!={'id','revision','provider','endpointRef','baseUrl','placement','inferenceGeo'}
            or residency['endpointRef']!=profile['endpointRef'] or residency['baseUrl']!=base_url
            or residency['placement']!='global' or residency['inferenceGeo'] is not None or inference_geo is not None):
        raise ValueError('Unsupported provider residency configuration')
