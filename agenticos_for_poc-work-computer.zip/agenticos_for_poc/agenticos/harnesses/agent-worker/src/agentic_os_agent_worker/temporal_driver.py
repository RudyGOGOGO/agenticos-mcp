"""Selected SDK control flow with separately durable private kernel Activities.

The SDK owns model/tool iteration. This controller only handles supported SDK
checkpoints, original-horizon waits and Temporal history segments. Its result is
a private candidate reference for the kernel's later completion assessment.
"""
from copy import deepcopy
from dataclasses import replace
from datetime import datetime,timedelta
import json
from uuid import UUID,uuid5

from temporalio import activity,workflow
from temporalio.common import RetryPolicy
from temporalio.exceptions import ApplicationError,TimeoutError as ActivityTimeout

with workflow.unsafe.imports_passed_through():
    from agents import Agent,Model,ModelProvider,ModelSettings,RunConfig,Runner
    from .checkpoint import export_checkpoint,restore_checkpoint
    from .model_rpc import ModelRPCError
    from .sdk_model import (BINDING_KEY,SDKModelSequence,SDKModelDeferred,SDKModelPolicyError,
        GovernedResponsesProvider,operation_id)
    from .sdk_tools import governed_read_tool
    from .transport import _json,_validate
    from .workflow_control import WorkflowControl,ReadControl,WAIT_TYPE,read_control
    from .protocol_metadata import ProtocolMetadata,ProtocolCommand,command as metadata_command
    from .read_journey import run_read_journey


ACTIVITIES={'accepted':'agent.accepted-model/1','tool':'agent.execute-tool/1','pack':'agent.pack-results/1',
    'save':'agent.checkpoint-put/1','load':'agent.checkpoint-get/1','load_reuse':'agent.checkpoint-get/2'}


def _checkpoint_history_input(checkpoint_id,value):
    _validate('AgentSDKCheckpointState',value)
    # Core stores canonical JSON. Preserve every value (including opaque
    # stateJson bytes), but use the same dictionary order before both Temporal
    # encodings; the SDK's JSON converter otherwise preserves insertion order.
    return _json(json.dumps(dict(checkpointId=checkpoint_id,value=value),
        sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')))


from .journey_control import _control,_rpc_control,_wait,DurableModel,DurableModelProvider


class AgentActivities:
    def __init__(self,boundary,*,planning_context=None,planning_phase=None):
        self.boundary=boundary
        if (planning_context is None)!=(planning_phase is None):raise SDKModelPolicyError()
        if planning_context is not None:
            _validate('AgentTaskContext',planning_context)
            if planning_phase not in {'planner','execution'}:raise SDKModelPolicyError()
        self.planning_context,self.planning_phase=deepcopy(planning_context),planning_phase

    @activity.defn(name='agent.private-planning-start/1')
    async def planning_start(self,value:dict):
        if self.planning_context is None:raise SDKModelPolicyError()
        _validate('AgentReadControl',value)
        return await self._call(self.planning_context,self.boundary.private_planning_start,
            self.planning_context,value,self.planning_phase,operation=value['operationId'])

    @activity.defn(name='agent.bind-private-plan/1')
    async def bind_private_plan(self,value:dict):
        if self.planning_context!=value['context'] or self.planning_phase!='planner':raise SDKModelPolicyError()
        result=await self._call(value['context'],self.boundary.bind_private_plan,value['context'],value['operationId'],operation=value['operationId'])
        return result if isinstance(result,WorkflowControl) else read_control(result)

    async def _call(self,context,function,*args,operation=None,**kwargs):
        try:return await function(*args,**kwargs)
        except ModelRPCError as error:return _rpc_control(context,error,operation)

    @activity.defn(name='agent.accepted-model/1')
    async def accepted(self,value:dict):
        result=await self._call(value['context'],self.boundary.accepted_model_operation,value['context'],value['operationId'],operation=value['operationId'])
        return ProtocolMetadata('model-result',result) if isinstance(value,ProtocolCommand) and not isinstance(result,WorkflowControl) else result

    @activity.defn(name='agent.execute-tool/1')
    async def tool(self,value:dict):
        operation=str(uuid5(UUID(value['modelOperationId']),'sdk-tool/'+value['callId']))
        return await self._call(value['context'],self.boundary.execute_tool,value,operation=operation)

    @activity.defn(name='agent.execute-native/1')
    async def native(self,value:dict):
        operation=str(uuid5(UUID(value['modelOperationId']),'sdk-tool/'+value['callId']))
        return await self._call(value['context'],self.boundary.execute_native,value,operation=operation)

    @activity.defn(name='agent.native-source-state/1')
    async def native_source(self,value:dict):
        return await self._call(value['context'],self.boundary.native_source_state,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.pack-results/1')
    async def pack(self,value:dict):
        return await self._call(value['context'],self.boundary.pack_input_results,value['context'],value['setId'],value['results'])

    @activity.defn(name='agent.retain-query-facts/1')
    async def query_facts(self,value:dict):
        return await self._call(value['context'],self.boundary.retain_query_facts,value['context'],value['goalDigest'],
            value['setId'],value['results'],operation=value['operationId'])

    @activity.defn(name='agent.query-intent-metadata/1')
    async def query_intent_metadata(self,value:dict):
        return await self._call(value['context'],self.boundary.query_intent_metadata,value['context'],
            value['goalDigest'],value['queryKeys'])

    @activity.defn(name='agent.query-intent-part/1')
    async def query_intent_part(self,value:dict):
        return await self._call(value['context'],self.boundary.query_intent_part,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.logical-query-progress/1')
    async def logical_query_progress(self,value:dict):
        return await self._call(value['context'],self.boundary.logical_query_progress,value['context'],
            value['goalDigest'],value['setId'],value['results'])

    @activity.defn(name='agent.checkpoint-put/1')
    async def save(self,value:dict):
        return await self._call(value['value']['binding']['context'],self.boundary.put_checkpoint,value['checkpointId'],value['value'])

    @activity.defn(name='agent.checkpoint-get/1')
    async def load(self,value:dict):
        return await self._call(value['context'],self.boundary.get_checkpoint,value['context'],value['checkpointId'])

    @activity.defn(name='agent.checkpoint-get/2')
    async def load_reuse(self,value:dict):
        result=await self.load(value)
        if isinstance(result,WorkflowControl):return result
        _validate('AgentSDKCheckpointState',result)
        if result['binding']['context']!=value['context']:raise SDKModelPolicyError()
        # Match the complete checkpoint-put input, already stored by the
        # content-addressed history codec. A fresh authorized checkpoint read
        # must not queue a second copy behind the work it needs to resume.
        return _checkpoint_history_input(value['checkpointId'],result)

    @activity.defn(name='agent.query-checkpoint-state/1')
    async def query_checkpoint_state(self,value:dict):
        return await self._call(value['context'],self.boundary.query_checkpoint_state,value['context'],
            value['checkpointId'],value['goalDigest'],operation=value['operationId'])

    @activity.defn(name='agent.query-model-recovery/1')
    async def recover_query_model(self,value:dict):
        binding=value['binding']
        return await self._call(binding['context'],self.boundary.recover_query_model,binding,value['goalDigest'],
            operation=value['operationId'])

    @activity.defn(name='agent.bind-read-goal/1')
    async def bind_read_goal(self,value:dict):
        result=await self._call(value['context'],self.boundary.bind_read_goal,value['context'],value['operationId'],operation=value['operationId'])
        return result if isinstance(result,WorkflowControl) else read_control(result)

    @activity.defn(name='agent.complete-read/1')
    async def complete_read(self,value:dict):
        result=await self._call(value['context'],self.boundary.complete_read,value['context'],value['operationId'],operation=value['operationId'])
        return result if isinstance(result,WorkflowControl) else read_control(result)

    @activity.defn(name='agent.bind-analysis-goal/1')
    async def bind_analysis_goal(self,value:dict):
        result=await self._call(value['context'],self.boundary.bind_analysis_goal,value['context'],value['operationId'],operation=value['operationId'])
        return result if isinstance(result,WorkflowControl) else read_control(result)

    @activity.defn(name='agent.complete-analysis/1')
    async def complete_analysis(self,value:dict):
        result=await self._call(value['context'],self.boundary.complete_analysis,value['context'],value['operationId'],operation=value['operationId'])
        return result if isinstance(result,WorkflowControl) else read_control(result)

    @activity.defn(name='agent.plan-state/1')
    async def plan_state(self,value:dict):
        return await self._call(value['context'],self.boundary.plan_state,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.child-page/1')
    async def child_page(self,value:dict):
        return await self._call(value['context'],self.boundary.child_page,value['context'],after=value['after'],operation=value['operationId'])

    @activity.defn(name='agent.child-start/1')
    async def child_start(self,value:dict):
        return await self._call(value['context'],self.boundary.child_start,value['context'],value['childId'],operation=value['operationId'])

    @activity.defn(name='agent.child-source-state/1')
    async def child_source_state(self,value:dict):
        return await self._call(value['context'],self.boundary.child_source_state,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.child-source-reduction-state/1')
    async def child_source_reduction_state(self,value:dict):
        return await self._call(value['context'],self.boundary.child_source_reduction_state,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.child-source-join-state/1')
    async def child_source_join_state(self,value:dict):
        return await self._call(value['context'],self.boundary.child_source_join_state,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.child-paged-source-join-state/1')
    async def child_paged_source_join_state(self,value:dict):
        return await self._call(value['context'],self.boundary.child_paged_source_join_state,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.complete-query-source/1')
    async def complete_query_source(self,value:dict):
        return await self._call(value['context'],self.boundary.complete_query_source,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.bind-current-query-source/1')
    async def bind_current_query_source(self,value:dict):
        return await self._call(value['context'],self.boundary.bind_current_query_source,value['context'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.inspect-bound-query-source/1')
    async def inspect_bound_query_source(self,value:dict):
        return await self._call(value['context'],self.boundary.inspect_bound_query_source,value['context'],value['bindingId'],operation=value['operationId'])

    @activity.defn(name='agent.recover-bound-query-source/1')
    async def recover_bound_query_source(self,value:dict):
        return await self._call(value['context'],self.boundary.recover_bound_query_source,value['context'],value['bindingId'],operation=value['operationId'])

    @activity.defn(name='agent.child-parallel-page/1')
    async def child_parallel_page(self,value:dict):
        return await self._call(value['context'],self.boundary.child_parallel_page,value['context'],after=value['after'],operation=value['operationId'])

    @activity.defn(name='agent.child-checkpoint/1')
    async def child_checkpoint(self,value:dict):
        return await self._call(value['context'],self.boundary.child_checkpoint,value['context'],value['childId'],value['checkpointId'],operation=value['operationId'])

    @activity.defn(name='agent.child-complete/1')
    async def child_complete(self,value:dict):
        return await self._call(value['context'],self.boundary.child_complete,value['context'],value['childId'],value['operationId'],operation=value['operationId'])

    @activity.defn(name='agent.owner-input/1')
    async def owner_input(self,value:dict):
        return await self._call(value['context'],self.boundary.owner_input,value['context'],value['operationId'],
            value['bind'],operation=value['operationId'])

    @activity.defn(name='agent.review/1')
    async def review(self,value:dict):
        result=await self._call(value['context'],self.boundary.review,value['context'],value['operationId'],
            value['reviewId'],value['preparation'],operation=value['reviewId'] or value['operationId'])
        # The kernel may have closed the original root before this Activity
        # result is serialized. Reuse bounded terminal control, never admit a
        # new encrypted history write after closure. Old histories retain their
        # original response when the versioned workflow omits this digest.
        if not isinstance(result,WorkflowControl) and value.get('goalDigest') is not None:
            if result['context']!=value['context'] or result['reviewId']!=value['reviewId']:raise SDKModelPolicyError()
            if result['kind']=='completed':return ReadControl(rootId=value['context']['rootId'],taskId=value['context']['taskId'],
                operationId=value['operationId'],state='completed',goalDigest=value['goalDigest'],missingCriteria=[])
            if result['kind'] in {'rejected','not-applied'}:return _control(value['context'],'model-failed',value['reviewId'])
        return result

    @activity.defn(name='agent.proactivity/1')
    async def proactivity(self,value:dict):
        result=await self._call(value['context'],self.boundary.proactivity,value['context'],value['operationId'],
            value.get('goalDigest'),value.get('preparation'),operation=value['operationId'])
        if not isinstance(result,WorkflowControl):
            _validate('AgentProactiveState',result)
            if result['context']!=value['context']:raise SDKModelPolicyError()
            # Owner review must begin after metered private Activity inputs
            # settle. Return only existing minimal control, so publication
            # cannot race another private output/continuation reservation.
            if result['kind'] in {'waiting','completed'}:return ReadControl(rootId=value['context']['rootId'],taskId=value['context']['taskId'],
                operationId=value['operationId'],state='completed' if result['kind']=='completed' else 'incomplete',
                goalDigest=result['goalDigest'],missingCriteria=[])
            if result['kind'] in {'rejected','not-current'}:return _control(value['context'],'model-failed',value['operationId'])
        return result

    @activity.defn(name='agent.selected-read-tools/1')
    async def selected_read_tools(self,value:dict):
        return await self._call(value['context'],self.boundary.selected_read_tools,value['context'],
            value['goalDigest'],operation=value['operationId'])

    def registered(self):
        values=[self.accepted,self.tool,self.native,self.native_source,self.pack,self.query_facts,self.query_intent_metadata,self.query_intent_part,self.logical_query_progress,self.save,self.load,self.load_reuse,self.query_checkpoint_state,self.recover_query_model,self.bind_read_goal,self.complete_read,self.bind_analysis_goal,self.complete_analysis,self.plan_state,self.child_page,self.child_start,self.child_checkpoint,self.child_complete,self.owner_input,self.review,self.child_parallel_page,self.child_source_state,self.child_source_reduction_state,self.child_source_join_state,self.child_paged_source_join_state,self.complete_query_source,self.bind_current_query_source,self.inspect_bound_query_source]
        return [*values,self.proactivity,self.selected_read_tools,self.recover_bound_query_source]+([self.planning_start,self.bind_private_plan] if self.planning_context is not None else [])


class WorkflowBoundary:
    def __init__(self,timeout_ms):self.timeout=timedelta(milliseconds=timeout_ms)
    async def _call(self,name,value):
        wire=value
        metadata={'agent.accepted-model/1':'operation','agent.bind-read-goal/1':'operation',
            'agent.complete-read/1':'operation','agent.checkpoint-get/1':'checkpoint','agent.checkpoint-get/2':'checkpoint'}
        if name=='agent.native-source-state/1' and workflow.patched('native-source-state-opaque-command/1'):
            # A granted result write can be the FIFO head. Its inspection must
            # not require another private allocation before that write resumes.
            metadata[name]='operation'
        if name in metadata and workflow.patched('private-opaque-protocol-metadata/1'):
            wire=metadata_command(metadata[name],value)
        result=await workflow.execute_activity(name,wire,start_to_close_timeout=self.timeout,
            retry_policy=RetryPolicy(maximum_attempts=1),cancellation_type=workflow.ActivityCancellationType.TRY_CANCEL)
        if isinstance(result,WorkflowControl):raise ApplicationError('agent_wait',result,type=WAIT_TYPE,non_retryable=True)
        return result
    async def accepted_model_operation(self,context,operation_id):
        return await self._call(ACTIVITIES['accepted'],dict(context=context,operationId=operation_id))
    async def execute_tool(self,request):
        result=await self._call(ACTIVITIES['tool'],request)
        if result['kind'] not in {'accepted','failed'}:
            operation=str(uuid5(UUID(request['modelOperationId']),'sdk-tool/'+request['callId']))
            raise ApplicationError('agent_wait',_control(request['context'],'waiting-reconciliation',operation),type=WAIT_TYPE,non_retryable=True)
        return result

    async def execute_native(self,request):
        result=await self._call('agent.execute-native/1',request)
        if result['kind'] not in {'accepted','tool-error'}:
            operation=str(uuid5(UUID(request['modelOperationId']),'sdk-tool/'+request['callId']))
            raise ApplicationError('agent_wait',_control(request['context'],'waiting-reconciliation',operation),type=WAIT_TYPE,non_retryable=True)
        return result

    async def native_source_state(self,context,operation_id):
        return await self._call('agent.native-source-state/1',dict(context=context,operationId=operation_id))
    async def pack_input_results(self,context,set_id,references):
        result=await self._call(ACTIVITIES['pack'],dict(context=context,setId=set_id,results=references))
        if result['kind']!='ready':raise ApplicationError('agent_wait',_control(context,'waiting-reconciliation'),type=WAIT_TYPE,non_retryable=True)
        return result
    async def retain_query_facts(self,context,goal_digest,set_id,references,operation_id):
        result=await self._call('agent.retain-query-facts/1',dict(context=context,goalDigest=goal_digest,setId=set_id,
            results=references,operationId=operation_id))
        if result['kind']!='ready':raise ApplicationError('agent_wait',_control(context,'waiting-reconciliation',operation_id),type=WAIT_TYPE,non_retryable=True)
        return result
    async def put_checkpoint(self,checkpoint_id,value):
        wire=(_checkpoint_history_input(checkpoint_id,value)
            if workflow.patched('private-checkpoint-result-history-reuse/1')
            else dict(checkpointId=checkpoint_id,value=value))
        return await self._call(ACTIVITIES['save'],wire)
    async def get_checkpoint(self,context,checkpoint_id):
        reuse=workflow.patched('private-checkpoint-result-history-reuse/1')
        result=await self._call(ACTIVITIES['load_reuse'] if reuse else ACTIVITIES['load'],
            dict(context=context,checkpointId=checkpoint_id))
        if not reuse:return result
        if (type(result) is not dict or set(result)!={'checkpointId','value'}
                or result['checkpointId']!=checkpoint_id):raise SDKModelPolicyError()
        saved=result['value'];_validate('AgentSDKCheckpointState',saved)
        if saved['binding']['context']!=context:raise SDKModelPolicyError()
        return saved
    async def query_checkpoint_state(self,context,checkpoint_id,goal_digest,*,operation_id):
        return await self._call('agent.query-checkpoint-state/1',dict(context=context,checkpointId=checkpoint_id,
            goalDigest=goal_digest,operationId=operation_id))
    async def recover_query_model(self,binding,goal_digest):
        operation=str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/'+str(binding['turn'])))
        return await self._call('agent.query-model-recovery/1',dict(binding=binding,goalDigest=goal_digest,operationId=operation))
    async def bind_read_goal(self,context,operation_id):
        return await self._call('agent.bind-read-goal/1',dict(context=context,operationId=operation_id))

    async def bind_private_plan(self,context,operation_id):
        return await self._call('agent.bind-private-plan/1',dict(context=context,operationId=operation_id))
    async def owner_input(self,context,operation_id,*,bind=False):
        return await self._call('agent.owner-input/1',dict(context=context,operationId=operation_id,bind=bind))

    async def review(self,context,operation_id,*,review_id=None,preparation=None,goal_digest=None):
        value=dict(context=context,operationId=operation_id,reviewId=review_id,preparation=preparation)
        if goal_digest is not None:value['goalDigest']=goal_digest
        return await self._call('agent.review/1',value)

    async def proactivity(self,context,operation_id,*,goal_digest=None,preparation=None):
        return await self._call('agent.proactivity/1',dict(context=context,operationId=operation_id,
            goalDigest=goal_digest,preparation=preparation))

    async def selected_read_tools(self,context,operation_id,goal_digest):
        return await self._call('agent.selected-read-tools/1',dict(context=context,operationId=operation_id,goalDigest=goal_digest))
    async def query_intent_part(self,context,operation_id):
        return await self._call('agent.query-intent-part/1',dict(context=context,operationId=operation_id))
    async def logical_query_progress(self,context,goal_digest,set_id,references):
        return await self._call('agent.logical-query-progress/1',dict(context=context,goalDigest=goal_digest,setId=set_id,results=references))
    async def query_intent_metadata(self,context,goal_digest,query_keys):
        return await self._call('agent.query-intent-metadata/1',dict(context=context,goalDigest=goal_digest,queryKeys=list(query_keys)))
    async def complete_read(self,context,operation_id):
        return await self._call('agent.complete-read/1',dict(context=context,operationId=operation_id))
    async def bind_analysis_goal(self,context,operation_id):
        return await self._call('agent.bind-analysis-goal/1',dict(context=context,operationId=operation_id))
    async def complete_analysis(self,context,operation_id):
        return await self._call('agent.complete-analysis/1',dict(context=context,operationId=operation_id))
    async def plan_state(self,context,operation_id):
        return await self._call('agent.plan-state/1',dict(context=context,operationId=operation_id))

    async def child_page(self,context,operation_id,*,after=None):
        return await self._call('agent.child-page/1',dict(context=context,operationId=operation_id,after=after))

    async def child_parallel_page(self,context,operation_id,*,after=None):
        return await self._call('agent.child-parallel-page/1',dict(context=context,operationId=operation_id,after=after))

    async def child_source_state(self,context,operation_id):
        return await self._call('agent.child-source-state/1',dict(context=context,operationId=operation_id))

    async def child_source_reduction_state(self,context,operation_id):
        return await self._call('agent.child-source-reduction-state/1',dict(context=context,operationId=operation_id))

    async def child_source_join_state(self,context,operation_id):
        return await self._call('agent.child-source-join-state/1',dict(context=context,operationId=operation_id))

    async def child_paged_source_join_state(self,context,operation_id):
        return await self._call('agent.child-paged-source-join-state/1',dict(context=context,operationId=operation_id))

    async def complete_query_source(self,context,operation_id):
        return await self._call('agent.complete-query-source/1',dict(context=context,operationId=operation_id))

    async def bind_current_query_source(self,context,operation_id):
        return await self._call('agent.bind-current-query-source/1',dict(context=context,operationId=operation_id))

    async def inspect_bound_query_source(self,context,operation_id,binding_id):
        return await self._call('agent.inspect-bound-query-source/1',dict(context=context,operationId=operation_id,bindingId=binding_id))

    async def recover_bound_query_source(self,context,operation_id,binding_id):
        return await self._call('agent.recover-bound-query-source/1',dict(context=context,operationId=operation_id,bindingId=binding_id))

    async def child_start(self,context,operation_id,child_id):
        return await self._call('agent.child-start/1',dict(context=context,operationId=operation_id,childId=child_id))

    async def child_checkpoint(self,context,operation_id,child_id,checkpoint_id):
        return await self._call('agent.child-checkpoint/1',dict(context=context,operationId=operation_id,childId=child_id,checkpointId=checkpoint_id))

    async def child_complete(self,context,operation_id,child_id):
        return await self._call('agent.child-complete/1',dict(context=context,operationId=operation_id,childId=child_id))


@workflow.defn(name='OSAgentTaskDriver/1')
class AgentTaskDriver:
    def __init__(self):
        self.context=None;self.control=None;self.claimed=False;self.resumed=False;self.stopped=False;self.pending_control=None
        self.parallel_resume_operations=frozenset()

    @workflow.query
    def status(self)->WorkflowControl|ReadControl|None:return self.control

    @workflow.signal
    def command(self,value:WorkflowControl):
        if not isinstance(value,WorkflowControl):return
        if self.context is None:
            if self.pending_control is None or self.pending_control.status!='stop':self.pending_control=value
            return
        if any(getattr(value,k)!=self.context[k] for k in ('rootId','taskId')):return
        if value.status=='stop':self.stopped=True
        elif self.control is None or (value.operationId!=self.control.operationId
                and not (value.status=='resume' and value.operationId in self.parallel_resume_operations)):return
        elif value.status=='claim' and self.control is not None and self.control.status=='candidate-ready':self.claimed=True
        elif value.status=='resume':self.resumed=True

    def _expired(self):return workflow.now()>=datetime.fromisoformat(self.context['authorizationHorizon'].replace('Z','+00:00'))

    def _terminal(self,control):
        self.control=control
        return control

    async def _pause(self,control):
        self.control=control;self.resumed=False
        horizon=datetime.fromisoformat(self.context['authorizationHorizon'].replace('Z','+00:00'))
        until=horizon
        if control.status=='waiting-provider' and control.notBefore is not None:
            until=min(until,datetime.fromisoformat(control.notBefore.replace('Z','+00:00')))
        delay=max(timedelta(0),until-workflow.now())
        try:await workflow.wait_condition(lambda:self.resumed or self.stopped or control.status=='candidate-ready' and self.claimed,timeout=delay)
        except TimeoutError:pass

    async def _save(self,boundary,checkpoint_id,envelope):
        while True:
            if self.stopped:return self._terminal(_control(self.context,'stopped'))
            if self._expired():return self._terminal(_control(self.context,'authorization-expired'))
            try:
                result=await boundary.put_checkpoint(checkpoint_id,envelope)
                if result['kind']=='ready':return result
                control=_control(self.context,'waiting-reconciliation',envelope['binding']['parentOperationId'])
            except Exception as error:
                control=_wait(error)
                if control is None:raise
            if control.status in {'configuration-required','scope-changed','model-failed','storage-failed'}:return self._terminal(control)
            await self._pause(control)

    @workflow.run
    async def run(self,value:dict)->WorkflowControl:
        if isinstance(value,ReadControl):
            if value.state!='goal-bound' or value.missingCriteria:raise SDKModelPolicyError()
            # Only opaque root/task/operation/digest control crosses purposes.
            # A role-bound activity reconstructs current approved private or
            # public input; no previous SDK state is carried to the next run.
            from dataclasses import asdict
            transition=value
            self.context=dict(rootId=value.rootId,taskId=value.taskId)
            if self.pending_control is not None:self.command(self.pending_control);self.pending_control=None
            while True:
                if self.stopped:return self._terminal(_control(self.context,'stopped',transition.operationId))
                try:
                    value=await workflow.execute_activity('agent.private-planning-start/1',asdict(transition),
                        start_to_close_timeout=timedelta(seconds=30),retry_policy=RetryPolicy(maximum_attempts=1))
                except Exception as error:
                    value=_wait(error,self.context,transition.operationId)
                    if value is None:raise
                if not isinstance(value,WorkflowControl):break
                if value.status in {'configuration-required','scope-changed','model-failed','storage-failed'}:
                    return self._terminal(value)
                self.control=value;self.resumed=False
                # The original Temporal execution timeout spans this chain;
                # Core repeats the original SQL horizon before every start.
                # No new horizon or automatic provider retry is introduced.
                await workflow.wait_condition(lambda:self.resumed or self.stopped)
            _validate('AgentSDKPrivatePlannedReadJourneyStart',value)
            return await run_read_journey(self,value)
        if value.get('schema') in {'agent-wasm-creation-journey/1','agent-contextual-lookup-read-journey/2','agent-contextual-lookup-read-journey/1','agent-lookup-read-journey/1','agent-capability-read-journey/1','agent-discovered-read-journey/1','agent-proactive-journey/1','agent-private-planned-read-journey/1','agent-read-journey/1','agent-child-read-journey/1','agent-reference-child-read-journey/1','agent-parallel-child-read-journey/1','agent-source-child-read-journey/1','agent-source-child-reduction-journey/1','agent-parallel-source-child-reduction-journey/1','agent-source-child-join-journey/1','agent-paged-source-child-join-journey/1','agent-query-source-child-join-journey/1','agent-owner-input-journey/1','agent-clarified-analysis-journey/1','agent-period-clarified-analysis-journey/1','agent-analysis-journey/1','agent-adaptive-analysis-journey/1','agent-chart-analysis-journey/1','agent-paged-analysis-journey/1','agent-planned-analysis-journey/1','agent-comparison-journey/1','agent-extrema-comparison-journey/1','agent-reviewed-change-journey/1','agent-memory-read-journey/1','agent-memory-response-journey/1'}:
            return await run_read_journey(self,value)
        _validate('AgentSDKWorkflowStart',value);value=deepcopy(value);self.context=value['context']
        if self.pending_control is not None:self.command(self.pending_control);self.pending_control=None
        c=self.context;expected='os-agent:'+':'.join([c['subject']['installationId'],c['subject']['applicationId'],c['taskId']])
        if workflow.info().workflow_id!=expected:raise SDKModelPolicyError()
        boundary=WorkflowBoundary(value['operationTimeoutMs'])
        instance=str(uuid5(UUID(c['taskId']),'sdk-instance/1'));pins=[item['capability'] for item in value['capabilities']]
        checkpoint_id=value['checkpointId']
        while True:
            if self.stopped:return self._terminal(_control(c,'stopped'))
            if self._expired():return self._terminal(_control(c,'authorization-expired'))
            binding=dict(context=c,sdkInstanceId=instance,turn=1,planRevision=1,parentOperationId=None,inputResults=[])
            saved=None
            if checkpoint_id is not None:
                try:saved=await boundary.get_checkpoint(c,checkpoint_id);binding=saved['binding']
                except Exception as error:
                    control=_wait(error)
                    if control is None:raise
                    if control.status in {'configuration-required','scope-changed'}:return self._terminal(control)
                    await self._pause(control);continue
            sequence=SDKModelSequence(binding,dependency_boundary=boundary)
            tools=[replace(governed_read_tool(item,boundary,sequence),needs_approval=True) for item in value['capabilities']]
            agent=Agent(name='Private governed agent',model=value['modelId'],tools=tools,
                model_settings=ModelSettings(metadata={BINDING_KEY:json.dumps(binding,sort_keys=True,separators=(',',':'))},store=False,max_tokens=value['maxOutputTokens']))
            initial=value['input']
            if saved is not None:
                restored=await restore_checkpoint(agent,saved,expected_context=c,sdk_instance_id=instance,capabilities=pins,
                    sequence=sequence,dependency_boundary=boundary)
                initial=restored.state
                # This profile contains only registered read tools. Internal SDK
                # approval merely passes its checkpoint; the OS still authorizes
                # and begins each exact request before any remote dispatch.
                for interruption in initial.get_interruptions():initial.approve(interruption)
            self.control=_control(c,'running',binding['parentOperationId'])
            try:
                result=await Runner.run(agent,initial,max_turns=None,hooks=sequence,
                    run_config=RunConfig(model=value['modelId'],tracing_disabled=True))
                if result.interruptions:
                    envelope=export_checkpoint(result,sequence,pins)
                    next_id=str(uuid5(UUID(instance),'checkpoint/'+str(sequence.snapshot()['turn'])))
                    stored=await self._save(boundary,next_id,envelope)
                    if isinstance(stored,WorkflowControl):return stored
                    checkpoint_id=next_id
                    value['checkpointId']=checkpoint_id
                    if (workflow.info().is_continue_as_new_suggested()
                            or workflow.info().get_current_history_length()>=value['maxSegmentEvents']):workflow.continue_as_new(value)
                    continue
                self.control=_control(c,'candidate-ready',sequence.snapshot()['parentOperationId'])
                while not self.claimed and not self.stopped and not self._expired():await self._pause(self.control)
                return self._terminal(_control(c,'stopped' if self.stopped else 'authorization-expired' if self._expired() else 'candidate-ready',self.control.operationId))
            except Exception as error:
                control=_wait(error)
                if control is None:
                    workflow.logger.warning('Unclassified governed SDK failure: %s; cause: %s',
                        type(error).__name__,type(error.__cause__).__name__)
                    raise
                if control.rootId!=c['rootId'] or control.taskId!=c['taskId']:raise SDKModelPolicyError()
                if control.status in {'configuration-required','scope-changed','model-failed','storage-failed'}:return self._terminal(control)
                await self._pause(control)


class ReadWorkflowBoundary(WorkflowBoundary):
    async def _call(self,name,payload):
        try:return await super()._call(name,payload)
        except Exception as error:
            context=payload.get('context') or payload['value']['binding']['context']
            # A lost tool Activity acknowledgement does not identify a new
            # request. Wake only through its accepted parent model; the
            # kernel still requires zero outstanding holds before replay.
            operation=payload.get('operationId')
            if payload.get('reviewId') is not None:operation=payload['reviewId']
            if payload.get('modelOperationId') and workflow.patched('read-tool-timeout-parent/1'):
                operation=payload['modelOperationId']
            if 'value' in payload:operation=payload['value']['binding']['parentOperationId']
            control=_wait(error,context,operation)
            if control is None:raise
            if (control.status=='waiting-reconciliation' and control.operationId is None and operation is not None
                    and workflow.patched('read-activity-wait-parent/1')):
                control=replace(control,operationId=operation)
            if (control.status=='waiting-resources' and control.operationId is None and operation is not None
                    and workflow.patched('read-resource-wait-parent/1')):
                control=replace(control,operationId=operation)
        raise ApplicationError('agent_wait',control,type=WAIT_TYPE,non_retryable=True)


class TemporalJourneyRuntime:
    """Replay semantics remain exclusively in the Temporal adapter."""
    def feature(self,name):return workflow.patched(name)
    @property
    def execution_id(self):return workflow.info().workflow_id
    def should_yield(self):return workflow.info().is_continue_as_new_suggested()
    @property
    def step_count(self):return workflow.info().get_current_history_length()
    def continue_journey(self,value,**kwargs):return workflow.continue_as_new(value,**kwargs)


def read_runtime(driver):
    return getattr(driver,'journey_runtime',None) or TemporalJourneyRuntime()


def read_boundary(driver,timeout_ms):
    factory=getattr(driver,'boundary_factory',None) or ReadWorkflowBoundary
    return factory(timeout_ms)
