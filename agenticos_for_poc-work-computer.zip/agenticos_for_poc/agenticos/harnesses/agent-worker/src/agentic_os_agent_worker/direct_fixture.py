"""Explicit deterministic inference boundary for local plumbing qualification.

The official SDK/provider transport still prepares, accounts and commits each
model operation through Core. This fixture supplies inference responses only;
tools, authorization, RPC, storage and completion are never replaced.
"""
import json
import re
import asyncio
import httpx
from .sdk_model import SDKModelPolicyError


def deterministic_transport(configuration):
    if (not {'mode','criteria','arguments'}<=set(configuration)
            or set(configuration)-{'mode','criteria','arguments','first_response_delay_ms','response_profile'} or
            configuration['mode'] != 'deterministic'):
        raise SDKModelPolicyError()
    profile=configuration.get('response_profile','read/1')
    if profile not in {'read/1','memory-read/1','memory-response/1'}:raise SDKModelPolicyError()
    delay=configuration.get('first_response_delay_ms',0)
    if type(delay) is not int or not 0<=delay<=3000:raise SDKModelPolicyError()
    calls = 0

    async def respond(request):
        nonlocal calls
        calls += 1
        if calls > 8 or str(request.url) != 'https://api.openai.com/v1/responses':
            raise SDKModelPolicyError()
        if calls==1 and delay:await asyncio.sleep(delay/1000)
        body = json.loads(request.content)
        outputs = [value for value in body['input'] if value.get('type') == 'function_call_output']
        if not body.get('tools'):
            document = dict(criteria=configuration['criteria'])
        elif not outputs:
            if len(body['tools']) != 1:
                raise SDKModelPolicyError()
            output = [dict(type='function_call', id='fixture_call', status='completed', call_id='p0_read',
                name=body['tools'][0]['name'], arguments=json.dumps(configuration['arguments']))]
            document = None
        else:
            accepted = json.loads(outputs[-1]['output'])
            expected='agent-accepted-read/1' if profile=='read/1' else 'agent-accepted-memory/1'
            if accepted['schema'] != expected:
                raise SDKModelPolicyError()
            page=accepted['page'] if profile=='read/1' else accepted['memory']['page']
            fields=None if profile=='read/1' else {field for criterion in configuration['criteria'] for field in criterion['fields']}
            facts=[dict(result=accepted['result'],resource=resource,field=field['name'])
                for resource,row in zip(page['evidence']['resourceRefs'],page['records'],strict=True)
                for field in row if fields is None or field['name'] in fields]
            match = re.search(r'"goalDigest": "([a-f0-9]{64})"', body['instructions'])
            if profile=='memory-response/1':
                document=dict(criteria=configuration['criteria'],facts=facts)
            elif profile=='memory-read/1' and match is None:
                document=dict(criteria=configuration['criteria'])
            elif match is None:
                raise SDKModelPolicyError()
            else:document=dict(goalDigest=match[1],facts=facts)
        if document is not None:
            output = [dict(type='message', id='fixture_message_' + str(calls), role='assistant', status='completed',
                content=[dict(type='output_text', text=json.dumps(document), annotations=[])])]
        return httpx.Response(200, json=dict(id='fixture_response_' + str(calls), created_at=1, object='response',
            model=body['model'], status='completed', error=None, incomplete_details=None, instructions=None,
            metadata={}, service_tier='default', parallel_tool_calls=True, tool_choice='auto', tools=[], output=output,
            usage=dict(input_tokens=12, input_tokens_details=dict(cached_tokens=2), output_tokens=3,
                output_tokens_details=dict(reasoning_tokens=1), total_tokens=15)),
            headers={'x-request-id': 'synthetic-p0-' + str(calls)})

    return httpx.MockTransport(respond)
