"""One SDK query phase precedes the existing narrowed child/join phases."""
import json

from temporalio import workflow

from .sdk_model import SDKModelPolicyError
from .transport import _SCHEMA,_validate


def query_goal_queries(value):
    """All immutable query identities, without copying their arguments."""
    goal=json.loads(value['goalDraftJson'])
    if goal.get('schema')!='agent-query-intent-index/1':return goal['queries']
    _validate('AgentQueryIntentIndex',goal)
    if goal['context']!=value['start']['context']:raise SDKModelPolicyError()
    return [dict(key=key) for key in goal['queryKeys']]


async def query_execution_queries(value,boundary,*,skip_completed=False):
    """Hydrate only the next bounded descriptors through current Core scope."""
    goal=json.loads(value['goalDraftJson'])
    if goal.get('schema')!='agent-query-intent-index/1':
        if not skip_completed or value['continuationInputJson'] is None:return goal['queries'],[]
        from .query_context import _frontiers,FACT_FORMAT
        frontiers=_frontiers(value['continuationInputJson'],value['goalDigest'],format=FACT_FORMAT)
        done={key for frontier in frontiers.values() if frontier['nextCursor'] is None for key in frontier['queryKeys']}
        return [query for query in goal['queries'] if query['key'] not in done],[]
    query_goal_queries(value)
    done=set()
    if value['continuationInputJson'] is not None:
        messages=json.loads(value['continuationInputJson']);window=json.loads(messages[0]['content'])
        for frontier in window['frontiers']:
            if frontier['nextCursor'] is None:done.update(frontier['queryKeys'])
    keys=[key for key in goal['queryKeys'] if key not in done]
    if not keys:return [],[]
    response=await boundary.query_intent_metadata(value['start']['context'],goal['goalDigest'],keys[:2])
    _validate('AgentQueryIntentWindow',response)
    if response['context']!=goal['context'] or response['goalDigest']!=goal['goalDigest']:raise SDKModelPolicyError()
    if ([entry['queryKey'] for entry in response['aliases']]!=[query['key'] for query in response['queries']]
            or any(entry['queryKey'] not in entry['queryKeys'] or not set(entry['queryKeys'])<=set(goal['queryKeys'])
                for entry in response['aliases'])):raise SDKModelPolicyError()
    return response['queries'],response['aliases']


def objective_instructions(capabilities,providers,*,precise=False):
    capabilities=[item for item in capabilities if item['kind']=='read']
    definitions={};pending=['AgentQuerySourceIntentDraft']
    def references(node):
        if isinstance(node,dict):
            if '$ref' in node:pending.append(node['$ref'].removeprefix('#/$defs/'))
            for child in node.values():references(child)
        elif isinstance(node,list):
            for child in node:references(child)
    while pending:
        name=pending.pop()
        if name in definitions:continue
        definitions[name]=_SCHEMA['$defs'][name];references(definitions[name])
    return ('Interpret the original request as complete authorized queries and meaningful exact grouped metrics, '
        'followed by current scoped reads of the target identifiers in one declared metric group column. '+
        ('Return only AgentQuerySourceIntentDraft using the supplied output schema. ' if precise else
         'Return only AgentQuerySourceIntentDraft matching these contracts: '+json.dumps(definitions)+'. ')+
        'selection names an exact criterionId and a string identity field in both groupBy and populationFields. '
        'The kernel verifies all query pages and computes the artifact before selecting any target. '
        'Do not guess identifiers, invent measurements or use amounts as identifiers. Choose only requested metrics. '
        'Use all unless the owner explicitly requests any or a minimum quorum. pageResources is transport width1..64. '
        'The source artifact grants no resource authority. Reviewed metadata: '+json.dumps(dict(capabilities=capabilities,providers=providers)))


async def complete_source(driver,value,boundary,sequence,result,*,bounded=False,current_binding=False):
    from .temporal_driver import _control,_wait
    from .child_read_journey import _deferred
    from .read_journey import _dump,start_contract
    context=value['start']['context'];operation=sequence.snapshot()['parentOperationId']
    while True:
        try:
            response=await (boundary.bind_current_query_source(context,operation) if current_binding else boundary.complete_query_source(context,operation))
            _validate('AgentCurrentQuerySourceWorkerState' if current_binding else 'AgentQuerySourceWorkerState',response)
            if response['kind'] in {'storage','goal-page-storage'}:raise _deferred(context,operation,response['preparation'])
            break
        except Exception as error:
            wait=_wait(error,context,operation)
            if wait is None:raise
            if wait.status in {'configuration-required','scope-changed','model-failed','storage-failed'}:return wait
            await driver._pause(wait)
            if driver.stopped:return _control(context,'stopped')
            if driver._expired():return _control(context,'authorization-expired')
    if response['kind']=='incomplete':
        if bounded:
            from .query_context import incomplete_query_window,refresh_query_window,FACT_FORMAT
            previous=json.loads(json.loads(value['continuationInputJson'])[0]['content'])
            from .logical_query_journey import selected as logical_selected,current_window
            if logical_selected(context):
                continuation,_=await current_window(value,boundary,sequence,phase='incomplete')
            elif previous['schema']==FACT_FORMAT:
                continuation=await refresh_query_window(sequence,value['continuationInputJson'],value['goalDigest'],query_goal_queries(value))
            else:continuation=incomplete_query_window(sequence,value['continuationInputJson'],value['goalDigest'])
        else:
            continuation=[*result.to_input_list(),dict(role='user',
                content='Complete the accepted source query chains before selecting targets. Missing criteria: '+_dump(response['missingCriteria']))]
        value.update(binding=sequence.snapshot(),continuationInputJson=_dump(continuation))
    else:
        if response['context']!=context:raise SDKModelPolicyError()
        if current_binding:
            value.update(sourceQueryWindowJson=value['continuationInputJson'],sourceBindingId=response['bindingId'])
        value.update(binding=sequence.snapshot(),goalDigest=response['goalDigest'],
            phase='children' if response['targetCount'] else 'execution',continuationInputJson=None,
            childAfter=None,childContinuation=None,childContinuations=[])
    value['start']['checkpointId']=None
    _validate(start_contract(value),value)
    workflow.continue_as_new(value)


async def refresh_bound_source(value,boundary,*,pending_recovery=False):
    """Check a settled phase boundary before admitting new child/model work.

    Pending child SDK checkpoints stay with their original reconciliation
    path. They must not be discarded as if their usage were known.
    """
    from .child_read_journey import _deferred
    from .query_context import rebound_query_window
    from .sdk_model import SDKModelSequence
    from .read_journey import _dump,start_contract
    context=value['start']['context'];binding=value['binding']
    if (value['start']['checkpointId'] is not None or not pending_recovery
            and (value.get('childContinuation') is not None or value.get('childContinuations'))):return False
    inspect=boundary.recover_bound_query_source if pending_recovery else boundary.inspect_bound_query_source
    response=await inspect(context,binding['parentOperationId'],value['sourceBindingId'])
    from .logical_query_journey import selected as logical_selected,rebound_window
    logical=logical_selected(context)
    _validate(('AgentLogicalBoundQuerySourceRecoveryState' if logical else 'AgentBoundQuerySourceRecoveryState') if pending_recovery else
        'AgentLogicalQuerySourceRefreshState' if logical else 'AgentQuerySourceRefreshState',response)
    if response['bindingId']!=value['sourceBindingId']:raise SDKModelPolicyError()
    if response['kind']=='reconciliation':raise _deferred(context,binding['parentOperationId'],dict(kind='reconciliation'))
    if response['kind']=='storage':raise _deferred(context,binding['parentOperationId'],response['preparation'])
    if response['context']!=context or response['bindingId']!=value['sourceBindingId']:raise SDKModelPolicyError()
    if response['kind']=='ready':
        if response['goalDigest']!=value['goalDigest']:raise SDKModelPolicyError()
        return False
    sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    previous=value.get('sourceQueryWindowJson')
    if previous is None:raise SDKModelPolicyError()
    continuation=(rebound_window(sequence,response['queryGoalDigest'],response['result']) if logical else
        rebound_query_window(sequence,previous,response['queryGoalDigest'],query_goal_queries(value),
            response['result'],response['invalidQueryKeys']))
    value.update(binding=sequence.snapshot(),goalDigest=response['queryGoalDigest'],phase='query-source',
        continuationInputJson=_dump(continuation),childAfter=None,childContinuation=None,childContinuations=[])
    _validate(start_contract(value),value)
    workflow.continue_as_new(value)


async def refresh_query_checkpoint(value,boundary):
    """Replace obsolete unstarted SDK tool work without loading saved prompts."""
    from .child_read_journey import _deferred
    from .query_context import FACT_FORMAT,query_window_selected,rebound_query_window
    from .sdk_model import SDKModelSequence
    from .read_journey import _dump,start_contract
    start=value['start'];context=start['context'];checkpoint=start['checkpointId']
    previous=value.get('continuationInputJson');goal=value['goalDigest']
    if (checkpoint is None or not query_window_selected(previous,goal)
            or json.loads(json.loads(previous)[0]['content'])['schema']!=FACT_FORMAT):return False
    binding=value['binding']
    if binding is None or binding['context']!=context or binding['parentOperationId'] is None:raise SDKModelPolicyError()
    # The prior accepted causal parent is only a controller wake-up hint.
    # The kernel's checkpoint metadata still selects the exact saved next
    # operation. UNKNOWN holds prevent wake-up; this hint grants no execution.
    response=await boundary.query_checkpoint_state(context,checkpoint,goal,operation_id=binding['parentOperationId'])
    from .logical_query_journey import selected as logical_selected,rebound_window
    logical=logical_selected(context)
    _validate('AgentLogicalQueryCheckpointState' if logical else 'AgentQueryCheckpointState',response)
    if response['checkpointId']!=checkpoint:raise SDKModelPolicyError()
    if response['kind']=='current':return False
    if response['kind']=='storage':raise _deferred(context,response['operationId'],response['preparation'])
    if response['kind']=='reconciliation':
        raise _deferred(context,response['operationId'],dict(kind='reconciliation'))
    binding=response['binding']
    if binding['context']!=context or response['goalDigest']!=goal:raise SDKModelPolicyError()
    sequence=SDKModelSequence(binding,dependency_boundary=boundary)
    current=(rebound_window(sequence,goal,response['result']) if logical else
        rebound_query_window(sequence,previous,goal,query_goal_queries(value),response['result'],response['invalidQueryKeys']))
    start['checkpointId']=None
    value.update(binding=sequence.snapshot(),continuationInputJson=_dump(current))
    _validate(start_contract(value),value)
    workflow.continue_as_new(value)


async def recover_query_model(value,boundary,binding):
    """Discard no work until Core proves the unaccepted return fully settled."""
    from .child_read_journey import _deferred
    from .query_context import FACT_FORMAT,query_window_selected,rebound_query_window
    from .sdk_model import SDKModelSequence
    from .read_journey import _dump,start_contract
    previous=value.get('continuationInputJson');goal=value['goalDigest']
    if (value['phase']!='query-source' or value['start']['checkpointId'] is not None
            or not query_window_selected(previous,goal)
            or json.loads(json.loads(previous)[0]['content'])['schema']!=FACT_FORMAT):return False
    if binding['context']!=value['start']['context']:raise SDKModelPolicyError()
    response=await boundary.recover_query_model(binding,goal)
    from .logical_query_journey import selected as logical_selected,rebound_window
    logical=logical_selected(binding['context'])
    _validate('AgentLogicalQueryModelRecoveryState' if logical else 'AgentQueryModelRecoveryState',response)
    if response['kind']=='current':return False
    if response['kind']=='storage':raise _deferred(binding['context'],response['operationId'],response['preparation'])
    if response['kind']=='reconciliation':raise _deferred(binding['context'],response['operationId'],dict(kind='reconciliation'))
    resumed=response['binding']
    if resumed['context']!=binding['context'] or response['goalDigest']!=goal:raise SDKModelPolicyError()
    sequence=SDKModelSequence(resumed,dependency_boundary=boundary)
    current=(rebound_window(sequence,goal,response['result']) if logical else
        rebound_query_window(sequence,previous,goal,query_goal_queries(value),response['result'],response['invalidQueryKeys']))
    value.update(binding=sequence.snapshot(),continuationInputJson=_dump(current))
    _validate(start_contract(value),value)
    workflow.continue_as_new(value)
