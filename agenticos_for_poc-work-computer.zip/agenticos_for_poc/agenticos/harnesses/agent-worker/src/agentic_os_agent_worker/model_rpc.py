"""Bounded private kernel client; workload credentials never enter SDK prompts.

No client/HTTP retry or endpoint discovery is selected. A failed begin response
may already have committed; retry ownership belongs to the durable controller.
TLS workload identity is separate from Host mobile tokens and provider secrets.
"""
import ssl
import ipaddress
import hashlib
import json
from copy import deepcopy
from urllib.parse import urlsplit
from uuid import UUID,uuid5

import httpx

from .transport import TransportConfig,TransportError,_json,_validate


class ModelRPCError(ValueError):
    def __init__(self,code='UNAVAILABLE'):
        self.code=code
        super().__init__('private_model_boundary_'+code.lower())


class ResourceGroupDeferred(ModelRPCError):
    def __init__(self,outcome):
        _validate('AgentResourceGroupOutcome',outcome)
        if outcome['kind'] not in {'resource-wait','resource-limit'}:raise ModelRPCError()
        self.outcome=deepcopy(outcome)
        super().__init__('CAPACITY' if outcome['kind']=='resource-wait' else 'PROFILE_DISABLED')


def _group_context(value):
    if 'context' in value:return value['context']
    if 'record' in value:return value['record']['context']
    if 'request' in value:return value['request']['context']
    if 'value' in value:return value['value']['binding']['context']
    raise ModelRPCError()


def _control(raw):
    def reject(*_):raise ModelRPCError()
    def pairs(values):
        result={}
        for key,value in values:
            if key in result:raise ModelRPCError()
            result[key]=value
        return result
    try:return json.loads(raw,object_pairs_hook=pairs,parse_float=reject,parse_constant=reject)
    except (ValueError,UnicodeError,RecursionError):raise ModelRPCError() from None


def _rpc_origin(value,*,local_synthetic=False):
    try:
        if type(value) is not str:raise ValueError()
        parsed=urlsplit(value)
        local=False
        try:local=ipaddress.ip_address(parsed.hostname).is_loopback
        except ValueError:pass
        if (parsed.username or parsed.password or parsed.query or parsed.fragment
                or parsed.path not in ('','/') or not parsed.hostname
                or any(c in value for c in ('\\','%','\n','\r','\t'))
                or parsed.port is not None and not 1<=parsed.port<=65535
                or parsed.scheme!='https' and not (local_synthetic is True and parsed.scheme=='http' and local)):
            raise ValueError()
        return value.rstrip('/')
    except Exception:raise ModelRPCError('INVALID') from None


class RPCModelBoundary:
    def __init__(self,base_url,token_provider,*,timeout_ms=30000,local_synthetic=False,network_transport=None,native_origin=None,tls_context=None):
        base_url=_rpc_origin(base_url,local_synthetic=local_synthetic)
        native_url=base_url if native_origin is None else _rpc_origin(native_origin,local_synthetic=local_synthetic)
        if type(timeout_ms) is not int or not 1<=timeout_ms<=900000 or not callable(token_provider):
            raise ModelRPCError('INVALID')
        if tls_context is not None and (not isinstance(tls_context,ssl.SSLContext) or not tls_context.check_hostname
                or tls_context.verify_mode!=ssl.CERT_REQUIRED):raise ModelRPCError('INVALID')
        self.base_url,self.native_base_url,self.token_provider=base_url,native_url,token_provider
        self.transport_settings=None
        self.client=httpx.AsyncClient(verify=tls_context or True,trust_env=False,follow_redirects=False,timeout=timeout_ms/1000,
            limits=httpx.Limits(max_connections=8,max_keepalive_connections=4),
            transport=network_transport or httpx.AsyncHTTPTransport(verify=tls_context or True,trust_env=False,retries=0))

    async def close(self):await self.client.aclose()

    async def _read_operation(self,action,context,operation_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),operationId=operation_id,transport=self.transport_settings)
        _validate('AgentReadOperationCommand',value)
        from .workflow_control import partial_read_context
        contract=('AgentPartialReadControl' if partial_read_context(context) else
            'AgentMemoryReadControl' if context['harness']['ref'].startswith('memory-assisted-read/') else
            'AgentPlannedReadResponse' if context['harness']['ref'].startswith('adaptive-analysis-planned/') else 'AgentReadOrSourceJoinControl')
        result=await self._send(action,value,contract)
        if any(result[k]!=context[k] for k in ('rootId','taskId')) or result['operationId']!=operation_id:
            raise ModelRPCError()
        return result

    async def plan_state(self,context,operation_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),operationId=operation_id,transport=self.transport_settings)
        _validate('AgentReadOperationCommand',value)
        result=await self._send('plan-state',value,'AgentPlanWorkerState')
        if result['context']!=context:raise ModelRPCError()
        return result

    async def bind_read_goal(self,context,operation_id):
        return await self._read_operation('bind-read-goal',context,operation_id)

    async def selected_read_tools(self,context,goal_digest):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),goalDigest=goal_digest,transport=self.transport_settings)
        _validate('AgentSelectedReadToolsCommand',value)
        result=await self._send('selected-read-tools',value,'AgentSelectedReadTools')
        if result['context']!=context or result['goalDigest']!=goal_digest:raise ModelRPCError()
        return result

    async def bind_private_plan(self,context,operation_id):
        return await self._read_operation('bind-private-plan',context,operation_id)

    async def private_planning_start(self,context,control,phase):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),control=deepcopy(control),phase=phase,transport=self.transport_settings)
        _validate('AgentPrivatePlanningStartCommand',value)
        result=await self._send('private-planning-start',value,'AgentSDKPrivatePlannedReadJourneyStart')
        if (result['start']['context']!=context or result['phase']!=phase
                or result['goalDigest']!=control['goalDigest']):raise ModelRPCError()
        return result

    async def owner_input(self,context,operation_id,bind=False):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),operationId=operation_id,transport=self.transport_settings)
        _validate('AgentReadOperationCommand',value)
        result=await self._send('bind-owner-input' if bind else 'owner-input-state',value,'AgentOwnerInputState')
        if result['kind']=='answered':
            reference=result['result']
            if (reference['subject']!=context['subject'] or any(reference[k]!=context[k] for k in ('taskId','rootId'))
                    or reference['payload']['schemaRef']!='AgentOwnerReply'):raise ModelRPCError()
        return result

    async def review(self,context,operation_id,review_id=None,preparation=None):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),operationId=operation_id,transport=self.transport_settings,
            reviewId=review_id,preparation=deepcopy(preparation))
        _validate('AgentReviewWorkerCommand',value)
        result=await self._send('bind-review' if preparation is not None else 'review-state',value,'AgentReviewWorkerState')
        if result['context']!=context or review_id is not None and result['reviewId']!=review_id:raise ModelRPCError()
        return result

    async def query_intent_part(self,context,operation_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),operationId=operation_id,transport=self.transport_settings)
        _validate('AgentQueryIntentPartCommand',value)
        result=await self._send('query-intent-part',value,'AgentQueryIntentPartState')
        if result['context']!=context:raise ModelRPCError()
        return result

    async def logical_query_progress(self,context,goal_digest,set_id,references):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),goalDigest=goal_digest,setId=set_id,results=deepcopy(references),transport=self.transport_settings)
        _validate('AgentLogicalQueryProgressCommand',value)
        result=await self._send('logical-query-progress',value,'AgentLogicalQueryProgressState')
        if result['kind']=='ready' and (result['index']['context']!=context or result['index']['goalDigest']!=goal_digest):raise ModelRPCError()
        return result

    async def query_intent_metadata(self,context,goal_digest,query_keys):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        expected=deepcopy(context);keys=list(query_keys)
        value=dict(context=expected,goalDigest=goal_digest,queryKeys=keys,transport=self.transport_settings)
        _validate('AgentQueryIntentCommand',value)
        result=await self._send('query-intent-metadata',value,'AgentQueryIntentWindow' if keys else 'AgentQueryIntentIndex')
        if result['context']!=expected or result['goalDigest']!=goal_digest:raise ModelRPCError()
        if keys and (not result['queries'] or [query['key'] for query in result['queries']]!=keys[:len(result['queries'])]):
            raise ModelRPCError()
        return result

    async def proactivity(self,context,operation_id,goal_digest=None,preparation=None):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        if preparation is None:
            value=dict(context=deepcopy(context),operationId=operation_id,transport=self.transport_settings)
            _validate('AgentReadOperationCommand',value)
            result=await self._send('bind-proactive-review',value,'AgentProactiveState')
        else:
            value=dict(context=deepcopy(context),goalDigest=goal_digest,preparation=deepcopy(preparation),transport=self.transport_settings)
            _validate('AgentProactiveStateCommand',value)
            result=await self._send('proactive-state',value,'AgentProactiveState')
        if (result['context']!=context or goal_digest is not None and result['goalDigest']!=goal_digest
                or preparation is not None and result['preparation']!=preparation):raise ModelRPCError()
        return result

    async def complete_read(self,context,operation_id):
        return await self._read_operation('complete-read',context,operation_id)

    async def bind_analysis_goal(self,context,operation_id):
        return await self._read_operation('bind-analysis-goal',context,operation_id)

    async def complete_analysis(self,context,operation_id):
        return await self._read_operation('complete-analysis',context,operation_id)

    def bind_transport(self,config):
        if not isinstance(config,TransportConfig):raise ModelRPCError('PROFILE_DISABLED')
        value=dict(modelDigest=config.model_profile_digest,endpointRef=config.endpoint_ref,credentialRef=config.credential_ref,
            baseUrl=config.base_url,requestTimeoutMs=config.request_timeout_ms,maxRequestBytes=config.max_request_bytes,
            maxResponseBytes=config.max_response_bytes,inferenceGeo=config.inference_geo)
        _validate('AgentModelTransportSettings',value)
        if self.transport_settings is not None and self.transport_settings!=value:raise ModelRPCError('CONFLICT')
        self.transport_settings=value

    async def _send(self,action,value,contract):
        try:
            # Fetch a current service token for each boundary. Renewal does not
            # extend an execution grant, root deadline, or original user scope.
            token=await self.token_provider()
            if type(token) is not str or not 1<=len(token)<=8192:raise ModelRPCError('UNAUTHENTICATED')
            content=json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf-8')
            maximum=4*1048576+65536 if action in {'finish','stage','prepare-operation','resolve-tool','execute-tool','execute-native','pack-input-results','history-put','history-create-v1','history-create-observe-v1','checkpoint-put','child-stage'} else 65536
            if len(content)>maximum:raise ModelRPCError('CAPACITY')
            origin=self.native_base_url if action=='execute-native' else self.base_url
            async with self.client.stream('POST',origin+'/private/agent/model/'+action,content=content,
                    headers={'Authorization':'Bearer '+token,'Content-Type':'application/json','Accept-Encoding':'identity'}) as response:
                if response.headers.get('content-encoding','identity')!='identity':raise ModelRPCError()
                raw=bytearray()
                async for chunk in response.aiter_bytes():
                    if len(raw)+len(chunk)>(4 if action in {'execute-tool','child-page','child-parallel-page','child-source-state','child-start','child-checkpoint','child-complete'} else 2)*1048576+65536:raise ModelRPCError('CAPACITY')
                    raw.extend(chunk)
                result=_control(bytes(raw))
                if response.status_code==409 and type(result) is dict and result.get('kind') in {'resource-wait','resource-limit'}:
                    _validate('AgentResourceGroupOutcome',result)
                    context=_group_context(value)
                    if result['kind']=='resource-wait':
                        wait=result['wait']
                        if any(wait[k]!=context[k] for k in ('subject','rootId','taskId','segmentId','controlEpoch','authorizationHorizon')):raise ModelRPCError()
                    elif result['authorizationHorizon']!=context['authorizationHorizon']:raise ModelRPCError()
                    raise ResourceGroupDeferred(result)
                if response.status_code!=200:
                    allowed={'UNAUTHENTICATED','DENIED','NOT_FOUND','INVALID','CONFLICT','CAPACITY','UNAVAILABLE','PROFILE_DISABLED'}
                    code=result.get('code') if type(result) is dict else None
                    raise ModelRPCError(code if code in allowed else 'UNAVAILABLE')
                _validate(contract,result)
                return result
        except ModelRPCError:raise
        except Exception:raise ModelRPCError() from None

    async def begin_model(self,request):
        _validate('AgentModelInvocation',request)
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        result=await self._send('begin',dict(request=request,transport=self.transport_settings),'AgentModelBeginPayload')
        return result['inputJson']

    async def finish_model(self,request,*,usage,candidate_json,failure,reason,provider_evidence_json,
                           request_id,response_id,work_ms,retry_after_ms):
        value=dict(request=request,usage=usage,candidateJson=candidate_json,failure=failure,reason=reason,
            providerEvidenceJson=provider_evidence_json,requestId=request_id,responseId=response_id,
            workMs=work_ms,retryAfterMs=retry_after_ms)
        _validate('AgentModelFinishCommand',value)
        return await self._send('finish',value,'AgentModelObservation')

    async def accept_model(self,request):
        _validate('AgentModelInvocation',request)
        return await self._send('accept',request,'AgentModelAcceptedPayload')

    async def stage_model_input(self,context,operation_id,input_json):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context)
        value=dict(context=context,operationId=operation_id,inputJson=input_json,transport=self.transport_settings)
        _validate('AgentModelInputStageCommand',value)
        result=await self._send('stage',value,'AgentPayloadPreparation')
        expected=str(uuid5(UUID(operation_id),'provider-input/1'))
        if result['kind']=='ready':
            reference=result['reference']
            if (reference['subject']!=context['subject'] or reference['rootId']!=context['rootId']
                    or reference['taskId']!=context['taskId'] or reference['writeId']!=expected
                    or reference['payload']['schemaRef']!='AgentProviderInput' or reference['payload']['schemaVersion']!=1
                    or reference['payload']['bytes']!=len(input_json.encode('utf-8'))):raise ModelRPCError()
        elif result['writeId']!=expected:raise ModelRPCError()
        return result

    async def stage_child_model_input(self,context,binding,input_json):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);binding=deepcopy(binding)
        _validate('AgentSDKModelBinding',binding)
        if binding['context']!=context:raise ModelRPCError('DENIED')
        value=dict(context=context,binding=binding,inputJson=input_json,transport=self.transport_settings)
        _validate('AgentChildModelStageCommand',value)
        result=await self._send('child-stage',value,'AgentPayloadPreparation')
        operation=str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/'+str(binding['turn'])))
        self._payload_preparation(context,str(uuid5(UUID(operation),'provider-input/1')),result,'AgentProviderInput')
        if result['kind']=='ready' and result['reference']['payload']['bytes']!=len(input_json.encode()):raise ModelRPCError()
        return result

    async def prepare_model_operation(self,record,*,max_output_tokens,request_timeout_ms):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        record=deepcopy(record)
        value=dict(record=record,maxOutputTokens=max_output_tokens,requestTimeoutMs=request_timeout_ms,transport=self.transport_settings)
        _validate('AgentModelOperationCommand',value)
        result=await self._send('prepare-operation',value,'AgentModelOperationResponse')
        prepared,accepted=result['preparation'],result['accepted']
        if (prepared['operationId']!=record['identity']['operationId']
                or (prepared['kind']=='accepted')!=(accepted is not None)
                or accepted is not None and accepted['result']!=prepared['result']):raise ModelRPCError()
        if accepted is not None:
            reference=accepted['result'];context=record['context']
            expected=str(uuid5(UUID(record['identity']['operationId']),'model-attempt/'+str(prepared['attemptNumber'])))
            if (reference['subject']!=context['subject'] or reference['taskId']!=context['taskId']
                    or reference['rootId']!=context['rootId'] or reference['producerStepId']!=expected
                    or reference['payload']['schemaRef']!='AgentProviderResponse'):raise ModelRPCError()
        if prepared['kind']=='ready':
            request=prepared['request']
            expected=str(uuid5(UUID(record['identity']['operationId']),'model-attempt/'+str(prepared['attemptNumber'])))
            if (request['context']!=record['context'] or request['input']!=record['input']
                    or request['step']['stepId']!=expected or request['step']['inputDigest']!=record['identity']['inputDigest']
                    or request['maxOutputTokens']!=max_output_tokens or request['requestTimeoutMs']!=request_timeout_ms):raise ModelRPCError()
        return result

    async def resolve_tool(self,request):
        """Return a bound proposal only; execution still requires its own grant."""
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        request=deepcopy(request);_validate('AgentSDKToolRequest',request)
        value=dict(request=request,transport=self.transport_settings)
        result=await self._send('resolve-tool',value,'AgentSDKToolBinding')
        return self._tool_binding(request,result)

    @staticmethod
    def _tool_binding(request,result):
        _validate('AgentSDKToolBinding',result)
        context=request['context'];identity=result['identity'];reference=result['modelResult']
        payload={k:result[k] for k in ('modelResult','capability','callId','callIndex','toolName','argumentsJson')}
        raw=json.dumps(payload,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
        fingerprint=hashlib.sha256(b'agentic-os.hash/1\0command\0'+raw).hexdigest()
        if (result['context']!=context or result['modelOperationId']!=request['modelOperationId']
                or any(result[k]!=request[k] for k in ('capability','callId','toolName'))
                or any(identity[k]!=context[k] for k in ('taskId','rootId','segmentId','intentRevision','controlEpoch'))
                or identity['kind']!='tool' or identity['inputDigest']!=fingerprint
                or identity['parentOperationId']!=request['modelOperationId']
                or identity['operationId']!=str(uuid5(UUID(request['modelOperationId']),'sdk-tool/'+request['callId']))
                or reference['subject']!=context['subject'] or reference['taskId']!=context['taskId']
                or reference['rootId']!=context['rootId'] or reference['payload']['schemaRef']!='AgentProviderResponse'):
            raise ModelRPCError()
        from .transport import _json
        def normalized(value):return json.dumps(_json(value),sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
        if normalized(result['argumentsJson'])!=normalized(request['argumentsJson']):raise ModelRPCError()
        return result

    async def execute_tool(self,request):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        request=deepcopy(request);_validate('AgentSDKToolRequest',request)
        result=await self._send('execute-tool',dict(request=request,transport=self.transport_settings),'AgentToolPreparation')
        context=request['context'];operation=str(uuid5(UUID(request['modelOperationId']),'sdk-tool/'+request['callId']))
        if result['kind']=='accepted':
            accepted=result['accepted'];binding=self._tool_binding(request,accepted['binding']);reference=accepted['result']
            step=str(uuid5(UUID(binding['identity']['operationId']),'tool-attempt/'+str(accepted['attemptNumber'])))
            if (reference['subject']!=context['subject'] or reference['taskId']!=context['taskId'] or reference['rootId']!=context['rootId']
                    or reference['producerStepId']!=step or reference['resultId']!=str(uuid5(UUID(step),'accepted-result'))
                    or reference['payload']['schemaRef'] not in {'EvidencePage','AgentQueryPage','AgentPreparedChange','AgentMemoryPage','AgentPrivateKnowledgePage','AgentProactivePreparation','AgentCapabilityDiscoveryPage','AgentWasmVerificationCandidate'} or reference['payload']['schemaVersion']!=1
                    or reference['payload']['schemaRef']=='AgentWasmVerificationCandidate' and not context['harness']['ref'].startswith('verified-wasm-creation/')
                    or reference['payload']['schemaRef']=='AgentCapabilityDiscoveryPage' and not context['harness']['ref'].startswith('governed-read-discovery/')
                    or reference['payload']['schemaRef']=='AgentProactivePreparation' and not context['harness']['ref'].startswith('reviewed-proactivity/')
                    or reference['payload']['schemaRef']=='AgentMemoryPage' and not context['harness']['ref'].startswith('memory-assisted-read/')
                    or reference['payload']['schemaRef']=='AgentPrivateKnowledgePage' and not context['harness']['ref'].startswith('private-planned-read/')):raise ModelRPCError()
            try:
                page=_json(accepted['payloadJson']);_validate(reference['payload']['schemaRef'],page)
                if (reference['payload']['schemaRef']=='AgentWasmVerificationCandidate'
                        and (page['compiled']['source']!=_json(request['argumentsJson']).get('source')
                            or reference['payload']['bytes']!=len(accepted['payloadJson'].encode('utf-8')))):
                    raise ModelRPCError('DENIED')
                if (reference['payload']['schemaRef']=='AgentCapabilityDiscoveryPage'
                        and (page['context']!=context or page['request']!=_json(request['argumentsJson'])
                            or reference['payload']['bytes']!=len(accepted['payloadJson'].encode('utf-8')))):
                    raise ModelRPCError('DENIED')
                if (reference['payload']['schemaRef']=='AgentPrivateKnowledgePage'
                        and page['binding']['value']['scope']!={key:context['subject'][key]
                            for key in ('installationId','applicationId','tenantId')}):raise ModelRPCError('DENIED')
            except (TransportError,ValueError):raise ModelRPCError() from None
        elif result['kind']=='failed':
            invocation=result['request'];record=invocation['record'];observed=result['observation']
            step=str(uuid5(UUID(operation),'tool-attempt/'+str(invocation['attemptNumber'])))
            if (record['context']!=context or record['identity']['operationId']!=operation or record['capability']!=request['capability']
                    or record['modelOperationId']!=request['modelOperationId'] or invocation['callId']!=step
                    or invocation['attempt']['subject']!=context['subject'] or invocation['attempt']['rootId']!=context['rootId']
                    or observed['capability']!=request['capability'] or observed['operation']['attemptId']!=invocation['attempt']['id']
                    or observed['operation']['state']!='failed' or observed['operation']['candidate'] is not None):raise ModelRPCError()
        elif result['kind']=='ready':raise ModelRPCError()
        elif result['operationId']!=operation:raise ModelRPCError()
        return result

    async def execute_native(self,request):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        request=deepcopy(request);_validate('AgentSDKToolRequest',request)
        result=await self._send('execute-native',dict(request=request,transport=self.transport_settings),'AgentNativeAnalysisPreparation')
        operation=str(uuid5(UUID(request['modelOperationId']),'sdk-tool/'+request['callId']))
        if result['kind']=='accepted':
            accepted=result['accepted'];binding=self._tool_binding(request,accepted['binding']);reference=accepted['result']
            step=str(uuid5(UUID(operation),'tool-attempt/1'))
            self._result_owner(request['context'],reference,'AgentNativeAnalysisResult')
            value=_json(accepted['payloadJson']);_validate('AgentNativeAnalysisResult',value)
            import hashlib
            proposal=_json(binding['argumentsJson'])
            if (accepted['attemptNumber']!=1 or reference['producerStepId']!=step
                    or reference['payload']['bytes']!=len(accepted['payloadJson'].encode('utf-8'))
                    or reference['resultId']!=str(uuid5(UUID(step),'accepted-result'))
                    or reference['lineageRef']!='native-output/'+value['outputDigest']
                    or value['context']!=request['context'] or value['operationId']!=operation or value['callId']!=step
                    or value['goalDigest']!=proposal['goalDigest'] or value['values']['goalDigest']!=value['goalDigest']
                    or value['programDigest']!=hashlib.sha256(proposal['source'].encode('utf-8')).hexdigest()
                    or any(any(ref[key]!=request['context'][key] for key in ('subject','rootId','taskId'))
                        for ref in [value['output'],value['sourceVerification'],*value['inputResults']])):raise ModelRPCError()
        elif result['kind'] not in {'tool-error'} and result['operationId']!=operation:raise ModelRPCError()
        return result

    async def native_source_state(self,context,operation_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=dict(context=deepcopy(context),operationId=operation_id,transport=self.transport_settings)
        _validate('AgentReadOperationCommand',value)
        result=await self._send('native-source-state',value,'AgentNativeSourceState')
        if result['context']!=context or result['goal']['context']!=context:raise ModelRPCError()
        if result['result'] is not None:self._result_owner(context,result['result'],'AgentNativeAnalysisResult')
        return result

    @staticmethod
    def _result_owner(context,result,schema):
        if (result['subject']!=context['subject'] or result['taskId']!=context['taskId'] or result['rootId']!=context['rootId']
                or result['payload']['schemaRef']!=schema or result['payload']['schemaVersion']!=1):raise ModelRPCError()

    async def accepted_model_operation(self,context,operation_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,operationId=operation_id,transport=self.transport_settings)
        _validate('AgentAcceptedOperationCommand',value)
        result=await self._send('accepted-operation',value,'AgentAcceptedOperationResult')
        self._result_owner(context,result['result'],'AgentProviderResponse')
        if (result['operationId']!=operation_id or result['result']['producerStepId']!=
                str(uuid5(UUID(operation_id),'model-attempt/'+str(result['attemptNumber'])))):raise ModelRPCError()
        return result['result']

    async def pack_input_results(self,context,set_id,references):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,setId=set_id,results=deepcopy(references),transport=self.transport_settings)
        _validate('AgentInputResultSetCommand',value)
        result=await self._send('pack-input-results',value,'AgentInputResultSetResponse')
        if result['setId']!=set_id:raise ModelRPCError()
        if result['kind']=='ready':
            reference=result['result'];self._result_owner(context,reference,'AgentInputResultSet')
            if (reference['producerStepId']!=set_id or reference['resultId']!=str(uuid5(UUID(set_id),'accepted-result-set'))):raise ModelRPCError()
        return result

    async def retain_query_facts(self,context,goal_digest,set_id,references,operation_id=None):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,goalDigest=goal_digest,setId=set_id,
            results=deepcopy(references),transport=self.transport_settings)
        _validate('AgentQueryFactSetCommand',value)
        result=await self._send('retain-query-facts',value,'AgentQueryFactSetResponse')
        if result['setId']!=set_id:raise ModelRPCError()
        if result['kind']=='ready':
            reference=result['result'];self._result_owner(context,reference,'AgentQueryFactSet')
            if reference['resultId']!=reference['producerStepId']:raise ModelRPCError()
        return result

    @staticmethod
    def _payload_preparation(context,write_id,result,schema):
        if result['kind']=='ready':
            reference=result['reference']
            if (reference['writeId']!=write_id or any(reference[k]!=context[k] for k in ('subject','taskId','rootId'))
                    or reference['payload']['schemaRef']!=schema or reference['payload']['schemaVersion']!=1):raise ModelRPCError()
        elif result['writeId']!=write_id:raise ModelRPCError()
        elif result['kind']=='reconciliation':
            handle=result['attempt']
            if any(handle[k]!=context[k] for k in ('subject','taskId','rootId','segmentId','controlEpoch')):raise ModelRPCError()
        return result

    async def put_history(self,context,write_id,envelope):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,writeId=write_id,envelope=deepcopy(envelope),transport=self.transport_settings)
        _validate('AgentHistoryPutCommand',value)
        result=await self._send('history-put',value,'AgentPayloadPreparation')
        return self._payload_preparation(context,write_id,result,'AgentTemporalHistoryEnvelope')

    async def store_history(self,context,write_id,envelope,*,observe=False):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        if type(observe) is not bool:raise ModelRPCError('INVALID')
        context,envelope=deepcopy(context),deepcopy(envelope)
        value=dict(context=context,writeId=write_id,envelope=envelope,transport=self.transport_settings)
        _validate('AgentHistoryPutCommand',value)
        result=await self._send('history-create-observe-v1' if observe else 'history-create-v1',value,'AgentHistoryLookupResult')
        return self._history_result(context,write_id,envelope['namespace'],envelope['workflowId'],result,allow_missing=False)

    async def lookup_history(self,context,write_id,namespace,workflow_id):
        return await self._lookup_history('history-lookup',context,write_id,namespace,workflow_id)

    async def observe_history(self,context,write_id,namespace,workflow_id):
        return await self._lookup_history('history-observe',context,write_id,namespace,workflow_id)

    async def _lookup_history(self,action,context,write_id,namespace,workflow_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,writeId=write_id,namespace=namespace,workflowId=workflow_id,transport=self.transport_settings)
        _validate('AgentHistoryLookupCommand',value)
        result=await self._send(action,value,'AgentHistoryLookupResult')
        return self._history_result(context,write_id,namespace,workflow_id,result)

    def _history_result(self,context,write_id,namespace,workflow_id,result,*,allow_missing=True):
        if result['kind']=='ready':
            self._payload_preparation(context,write_id,dict(kind='ready',reference=result['reference']),'AgentTemporalHistoryEnvelope')
            if result['envelope']['namespace']!=namespace or result['envelope']['workflowId']!=workflow_id:raise ModelRPCError()
        elif result['kind']=='missing':
            if not allow_missing or result['writeId']!=write_id:raise ModelRPCError()
        else:
            if result['preparation']['kind']=='ready':raise ModelRPCError()
            self._payload_preparation(context,write_id,result['preparation'],'AgentTemporalHistoryEnvelope')
        return result

    async def put_checkpoint(self,checkpoint_id,value):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        value=deepcopy(value);_validate('AgentSDKCheckpointState',value);context=value['binding']['context']
        command=dict(checkpointId=checkpoint_id,value=value,transport=self.transport_settings);_validate('AgentCheckpointPutCommand',command)
        result=await self._send('checkpoint-put',command,'AgentPayloadPreparation')
        return self._payload_preparation(context,checkpoint_id,result,'AgentSDKCheckpointState')

    async def get_checkpoint(self,context,checkpoint_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);command=dict(context=context,checkpointId=checkpoint_id,transport=self.transport_settings)
        _validate('AgentCheckpointGetCommand',command)
        result=await self._send('checkpoint-get',command,'AgentSDKCheckpointState')
        if result['binding']['context']!=context:raise ModelRPCError()
        return result

    async def recover_query_model(self,binding,goal_digest):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        binding=deepcopy(binding);context=binding['context']
        command=dict(binding=binding,goalDigest=goal_digest,transport=self.transport_settings)
        _validate('AgentQueryModelRecoveryCommand',command)
        result=await self._send('query-model-recovery',command,'AgentLogicalQueryModelRecoveryState' if
            context['harness']['ref']=='focused-child-reads/1' and context['harness']['revision']==3 else 'AgentQueryModelRecoveryState')
        operation=str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/'+str(binding['turn'])))
        if result['kind']!='current' and result['operationId']!=operation:raise ModelRPCError()
        if result['kind']=='changed':
            resumed=result['binding'];reference=result['result']
            self._result_owner(context,reference,'AgentQueryFactSet')
            advanced=resumed['turn']==binding['turn']+1
            expected=dict(binding,turn=binding['turn']+int(advanced),
                parentOperationId=operation if advanced else binding['parentOperationId'],inputResults=[reference])
            if (resumed!=expected or result['goalDigest']!=goal_digest
                    or reference['resultId']!=reference['producerStepId']):raise ModelRPCError()
        elif result['kind']=='storage':
            preparation=result['preparation']
            write_id=preparation['reference']['writeId'] if preparation['kind']=='ready' else preparation.get('writeId')
            if write_id is None:raise ModelRPCError()
            self._payload_preparation(context,write_id,preparation,'AgentQueryFactSet')
        return result

    async def query_checkpoint_state(self,context,checkpoint_id,goal_digest):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context)
        command=dict(context=context,checkpointId=checkpoint_id,goalDigest=goal_digest,transport=self.transport_settings)
        _validate('AgentQueryCheckpointCommand',command)
        result=await self._send('query-checkpoint-state',command,'AgentLogicalQueryCheckpointState' if
            context['harness']['ref']=='focused-child-reads/1' and context['harness']['revision']==3 else 'AgentQueryCheckpointState')
        if result['checkpointId']!=checkpoint_id:raise ModelRPCError()
        if result['kind']=='changed':
            binding=result['binding'];reference=result['result']
            self._result_owner(context,reference,'AgentQueryFactSet')
            if (binding['context']!=context or result['goalDigest']!=goal_digest
                    or binding['sdkInstanceId']!=str(uuid5(UUID(context['taskId']),'sdk-instance/1'))
                    or checkpoint_id!=str(uuid5(UUID(binding['sdkInstanceId']),'checkpoint/'+str(binding['turn'])))
                    or binding['parentOperationId']!=str(uuid5(UUID(binding['sdkInstanceId']),'model-turn/'+str(binding['turn']-1)))
                    or binding['inputResults']!=[reference] or reference['resultId']!=reference['producerStepId']):raise ModelRPCError()
        elif result['kind']=='storage':
            preparation=result['preparation']
            write_id=preparation['reference']['writeId'] if preparation['kind']=='ready' else preparation.get('writeId')
            if write_id is None:raise ModelRPCError()
            self._payload_preparation(context,write_id,preparation,'AgentQueryFactSet')
        return result

    @staticmethod
    def _child_item(context,child_id,item):
        scope=item['scope']
        if (scope['childId']!=child_id or scope['goal']['context']!=context
                or any(scope['parentResult'][key]!=context[key] for key in ('subject','rootId','taskId'))):
            raise ModelRPCError()
        verification=item['verification']
        if verification is not None and (item['state']!='COMPLETED' or verification['childId']!=child_id
                or any(verification['candidate'][key]!=context[key] for key in ('subject','rootId','taskId'))):
            raise ModelRPCError()
        return item

    async def child_page(self,context,*,after=None,parallel=False):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,after=after,transport=self.transport_settings)
        _validate('AgentChildPageCommand',value)
        result=await self._send('child-parallel-page' if parallel else 'child-page',value,
            'AgentParallelChildWorkerPage' if parallel else 'AgentChildWorkerPage')
        if result['context']!=context:raise ModelRPCError()
        for item in result['items']:
            self._child_item(context,item['scope']['childId'],item)
            if item['scope']['policy']!=result['policy']:raise ModelRPCError()
        return result

    async def child_parallel_page(self,context,*,after=None):
        return await self.child_page(context,after=after,parallel=True)

    async def child_source_state(self,context,operation_id):
        return await self._child_source_state(context,operation_id,'AgentSourceChildGoalRecord')

    async def child_source_reduction_state(self,context,operation_id):
        return await self._child_source_state(context,operation_id,'AgentSourceChildReductionGoalRecord')

    async def child_source_join_state(self,context,operation_id):
        return await self._child_source_state(context,operation_id,'AgentSourceChildJoinGoalRecord')

    async def child_paged_source_join_state(self,context,operation_id):
        return await self._child_source_state(context,operation_id,'AgentSourceChildJoinGoalRecord',
            response_schema='AgentPagedSourceChildWorkerState')

    async def bind_current_query_source(self,context,operation_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context)
        candidate=await self.accepted_model_operation(context,operation_id)
        ident=str(uuid5(UUID(context['taskId']),'query-source-binding/1/'+candidate['resultId']))
        value=dict(context=context,operationId=operation_id,transport=self.transport_settings)
        _validate('AgentQuerySourceBindingCommand',value)
        result=await self._send('bind-current-query-source',value,'AgentCurrentQuerySourceWorkerState')
        if result['kind']=='ready':
            if result['context']!=context or result['bindingId']!=ident or result['sourceCandidate']!=candidate:raise ModelRPCError()
        elif result['kind']=='goal-page-storage':
            expected=str(uuid5(UUID(context['taskId']),'query-source-goal-page/1/'+ident+'/'+str(result['pageOrdinal'])))
            if result['writeId']!=expected:raise ModelRPCError()
            self._payload_preparation(context,expected,result['preparation'],'AgentReadGoal')
        elif result['kind']=='storage':
            schemas={str(uuid5(UUID(context['taskId']),name+'/'+ident)):schema for name,schema in (
                ('verified-query-source/1','AgentQuerySourceVerification'),('query-source-child-goal/1','AgentQuerySourceGoalRecord'))}
            schema=schemas.get(result['writeId'])
            if schema is None:raise ModelRPCError()
            self._payload_preparation(context,result['writeId'],result['preparation'],schema)
        return result

    async def inspect_bound_query_source(self,context,binding_id):
        return await self._bound_source_state(context,binding_id,recover=False)

    async def recover_bound_query_source(self,context,binding_id):
        return await self._bound_source_state(context,binding_id,recover=True)

    async def _bound_source_state(self,context,binding_id,*,recover):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,bindingId=binding_id,transport=self.transport_settings)
        _validate('AgentQuerySourceRefreshCommand',value)
        logical=context['harness']['ref']=='focused-child-reads/1' and context['harness']['revision']==3
        result=await self._send('recover-bound-query-source' if recover else 'inspect-bound-query-source',value,
            ('AgentLogicalBoundQuerySourceRecoveryState' if logical else 'AgentBoundQuerySourceRecoveryState') if recover else
            'AgentLogicalQuerySourceRefreshState' if logical else 'AgentQuerySourceRefreshState')
        if result['bindingId']!=binding_id:raise ModelRPCError()
        if result['kind']=='reconciliation':return result
        if result['kind']=='storage':
            preparation=result['preparation']
            write_id=preparation['reference']['writeId'] if preparation['kind']=='ready' else preparation.get('writeId')
            if write_id is None:raise ModelRPCError()
            self._payload_preparation(context,write_id,preparation,'AgentQueryFactSet')
        else:
            if result['context']!=context:raise ModelRPCError()
            if result['kind']=='changed':
                self._result_owner(context,result['result'],'AgentQueryFactSet')
                if result['result']['resultId']!=result['result']['producerStepId']:raise ModelRPCError()
            else:
                self._result_owner(context,result['sourceCandidate'],'AgentProviderResponse')
                if result['bindingId']!=str(uuid5(UUID(context['taskId']),'query-source-binding/1/'+result['sourceCandidate']['resultId'])):
                    raise ModelRPCError()
        return result

    async def complete_query_source(self,context,operation_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,operationId=operation_id,transport=self.transport_settings)
        _validate('AgentReadOperationCommand',value)
        result=await self._send('complete-query-source',value,'AgentQuerySourceWorkerState')
        if result['kind']=='ready':
            if result['context']!=context or any(result['sourceCandidate'][key]!=context[key] for key in ('subject','rootId','taskId')):
                raise ModelRPCError()
        elif result['kind']=='goal-page-storage':
            expected=str(uuid5(UUID(context['taskId']),'source-child-goal-page/1/'+str(result['pageOrdinal'])))
            if result['writeId']!=expected:raise ModelRPCError()
            self._payload_preparation(context,expected,result['preparation'],'AgentReadGoal')
        elif result['kind']=='storage':
            schemas={str(uuid5(UUID(context['taskId']),name)):schema for name,schema in (
                ('verified-query-source/1','AgentQuerySourceVerification'),('query-source-child-goal/1','AgentQuerySourceGoalRecord'))}
            schema=schemas.get(result['writeId'])
            if schema is None:raise ModelRPCError()
            self._payload_preparation(context,result['writeId'],result['preparation'],schema)
        return result

    async def _child_source_state(self,context,operation_id,goal_schema,*,response_schema='AgentSourceChildWorkerState'):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,operationId=operation_id,transport=self.transport_settings)
        _validate('AgentReadOperationCommand',value)
        result=await self._send('child-source-state',value,response_schema)
        if result['kind']=='goal-page-storage':
            if response_schema!='AgentPagedSourceChildWorkerState':raise ModelRPCError()
            expected=str(uuid5(UUID(context['taskId']),'source-child-goal-page/1/'+str(result['pageOrdinal'])))
            if result['writeId']!=expected:raise ModelRPCError()
            self._payload_preparation(context,expected,result['preparation'],'AgentReadGoal')
        elif result['kind']=='storage':
            expected=str(uuid5(UUID(context['taskId']),'source-child-goal/1'))
            if result['writeId']!=expected:raise ModelRPCError()
            self._payload_preparation(context,expected,result['preparation'],goal_schema)
        else:
            if result['context']!=context:raise ModelRPCError()
            self._child_item(context,result['source']['scope']['childId'],result['source'])
            if (result['targetCount'] is None)!=(result['goalDigest'] is None):raise ModelRPCError()
            ready=result['targetCount'] is not None and result['goalDigest'] is not None
            if (result['source']['state']=='COMPLETED')!=ready:raise ModelRPCError()
        return result

    async def child_start(self,context,child_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,childId=child_id,transport=self.transport_settings)
        _validate('AgentChildStartCommand',value)
        result=await self._send('child-start',value,'AgentChildAdmissionResponse')
        if result['kind']=='ready':
            self._child_item(context,child_id,result['item'])
            if result['item']['state']=='UNSTARTED':raise ModelRPCError()
        return result

    async def child_checkpoint(self,context,child_id,checkpoint_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,childId=child_id,checkpointId=checkpoint_id,transport=self.transport_settings)
        _validate('AgentChildCheckpointCommand',value)
        result=await self._send('child-checkpoint',value,'AgentChildWorkerItem')
        self._child_item(context,child_id,result)
        if result['checkpointId']!=checkpoint_id:raise ModelRPCError()
        return result

    async def child_complete(self,context,child_id,operation_id):
        if self.transport_settings is None:raise ModelRPCError('PROFILE_DISABLED')
        context=deepcopy(context);value=dict(context=context,childId=child_id,operationId=operation_id,transport=self.transport_settings)
        _validate('AgentChildCompleteCommand',value)
        result=await self._send('child-complete',value,'AgentChildCompletionResponse')
        if result['kind']=='completed':
            self._child_item(context,child_id,result['item'])
            if result['item']['state']!='COMPLETED' or result['item']['verification'] is None:raise ModelRPCError()
        return result
