# Governed Agent SDK worker

This independent distribution owns the selected OpenAI Agents SDK / Temporal
harness and official OpenAI/Anthropic client pins. The kernel retains MCP 2.2;
this worker's SDK dependency graph requires MCP 1.30. Do not merge environments
or give this worker direct Host credentials or database access.

The worker supplies dependency verification, explicit private configuration,
workload-authenticated Core RPC and durable SDK/Temporal execution. Core owns
admission, original-root metering, private archival and verified completion.
Configured entry points require their reviewed model and workload assignment;
operator configuration grants no Host authority. Generated production contracts
and official provider transports are included. Local acceptance, live-provider
evidence and actual deployed-platform qualification retain their separate scopes.

`contracts.py` and `contracts.json` are generated from the kernel's maintained
schema source, including only production Agent wires and their generic subject
dependency. Do not edit or copy an independent wire schema. The wheel imports
outside the Host checkout without importing the kernel or its MCP environment.
Qualification checks the exact installed source and frozen dependency inputs.
Compatible installations are retained; changed worker bytes require a checked
package sync so an older wheel cannot silently satisfy current acceptance.

Read, exact-analysis, adaptive-discovery, chart and paged-analysis journeys share
one closed start-contract selector across their public entry points. The paged
profile sends accepted query references, coverage and next cursors to the SDK;
raw query rows remain in the kernel's private evidence store. These compact tool
outputs retain the exact accepted reference and causal bindings. Discovery still
uses its bounded accepted data to resolve identifiers before goal binding. This
does not expand model context, grant tool authority or alter earlier profiles.
New plain/adaptive analysis workflows also project the existing goal/answer
contracts through the supported SDK structured-output boundary. The final draft
keeps complete accepted-result objects, not shorthand identifiers. A Temporal
patch preserves earlier histories; Core still checks current authority, exact
source bindings, coverage and arithmetic. Ranking partitions compare entities
within compatible units, and optional revision fields must exist in the source.
Before a new plain/adaptive goal binds, Core checks its serialized query
arguments against the exact current registered tool schema. Patch-gated worker
feedback can correct an invalid draft through the existing private continuation
on the same finite Root. Accepted goals stay immutable; observing an older goal
never grants or renews execution.
Focused-child harness revisions1/2 retain their original4KiB request envelope.
An oversized child-answer request uses the original provider format while the
SDK keeps its complete typed output validator and Core checks exact sources,
authority, coverage and completion. Already-fitting requests retain their exact
bytes and provider schema hint; other profiles keep their existing formatting.
This compatibility applies before private input staging and model admission.
New base-analysis histories retain the original16KiB request envelope: the
complete typed goal schema appears once, alongside all reviewed source metadata
and concise semantic guidance. Execution uses the existing compact query
reference context only after Core verifies the original immutable base-analysis
goal for that task and its current planner, source and artifact bindings. Core
reconstructs every accepted reference, cursor, coverage and field byte; the
compact context never grants access or replaces complete source verification.
Core retains the full source pages, performs the exact computation and checks
current authority before publication. Separate replay markers preserve older
objective and tool-output formatting; other analysis profiles keep their own
existing behavior. Request/operation limits and accounting remain unchanged.
Current-facts query recovery can also replace an obsolete provider return after
Core proves its usage and archives settled and its result unaccepted. A closed
private response pins the exact next binding and current fact reference. The
existing query-window rollover keeps unrelated queries and the original Root,
deadline and accounting. Uncertain work waits; accepted steps cannot rewind.

The explicit `agent-discovered-read-journey/1` starts with only its governed
metadata tool. Sixteen-entry pages and explicit retained choices let it find a
needed tool beyond one active batch. The public SDK model-input filter projects
the latest accepted window before Temporal serializes a model Activity, while
pending tools retain supported SDK approval checkpoints. Completed metadata tool
rounds reuse the query rollover mechanism for fresh bounded contexts, preserving
all prior causal work in private journals and Temporal history. Core checks every causal source,
binds the immutable read goal and returns only its current exact selected tool
schemas. Metadata supplies neither business facts nor execution permission.
Committed page replay observes current metadata and Host scope; it does not
repeat the old traversal, extend the Root/deadline or release uncertain usage.
An oversized metadata page uses the existing known tool-error path, followed
by a fresh bounded SDK round that can request fewer entries or retained pins.
It supplies no selection evidence. Escaped metadata pages are bounded to16KiB;
model input/output and actual Temporal checkpoint encoding are checked before
private serialization. The65536-byte private envelope stays unchanged, and
unsupported provider state is refused before dispatching its proposed tool.

The explicitly selected `agent-proactive-journey/1` uses the same model/tool
boundaries and objective/execution workflow. The SDK proposes one finite inactive
configuration, invokes only its registered preparation tool, and retains that
exact accepted reference in its completion document. The final model replaces
the SDK dependency head; the preparation is taken from the Core-validated document.
Current-owner review waits in the existing execution history with minimal typed
control, avoiding private output or continuation writes after review publication.
Canonical approval completes the original task; future timers and event runs use
the separately reviewed existing scheduler delegation. The worker has no
activation capability or scheduler credentials.

The explicit `assigned-private-planned-read-local/1` configuration adds a
`planner` object with its own `workloadToken`, `transport`, `apiKey`,
`historyKeyId`, `historyKeyHex` and canonical `meterPolicyJson`. The declared
planner model, credential references, actual API keys and history keys must be
separate from public synthesis before Temporal dispatch. Objective, private
planning and fresh public execution use the existing workflow identity and
original Root/deadline with purpose-specific clients and queues. Only typed
read control crosses phases; Core projects private guidance into an exact
ordering of already accepted public criterion UUIDs. Public SDK input contains
no private passages, checkpoint or continuation state. Actual local synthetic
commit-ACK loss/worker replacement, sourced completion and independent package
checks pass; live-provider and deployment qualification remain separate.

Each SDK entry must explicitly use `max_turns=None`. The pinned SDK's
`Agent.as_tool(max_turns=None)` restores its ten-turn default, so delegated OS
tasks use admitted Temporal child workflows and their own unlimited SDK entry
under the original resource root. A generic Activity context copy loses SDK
call metadata; governed tools send a minimal typed envelope containing the
accepted-response/tool-call/operation binding, rather than a raw SDK context.

New approved-memory histories preserve accepted discovery context across goal
binding through the existing encrypted SDK continuation. Execution can select
those exact sources without another recall; Core revalidates the complete causal
closure and current authority. Further discovery stays available. Context beyond
the existing continuation bound follows the original discovery path without
truncation, and the Temporal patch preserves legacy history replay.

The kernel owns Stop admission fences and UNKNOWN reconciliation. TRY_CANCEL is
a transport request, not proof that remote work consumed no resources. The
selected SDK mechanism checks separately observe remote cancellation. The
WAIT_CANCELLATION_COMPLETED direct workflow-cancel configuration failed its
bounded mechanism probe and is not selected. Model/tool Activity retries belong
to the kernel; the plugin issues one Activity attempt and disables content traces.

`transport.py` supplies reusable official Responses/Messages connections behind
the private `ModelBoundary`. `begin_model` must authenticate the exact stored
context/grant, commit begin once, and return only its governed private input.
`finish_model` owns encrypted provider evidence, known/UNKNOWN accounting and
unaccepted candidate storage; it must remain idempotent after Stop. These are
kernel duties, not an in-memory spending ledger in this package. The transport
issues one request, disables hidden retries and tracing, rejects ambient account
or header overrides, and never forwards raw SDK output to the UI. An explicit
OpenAI 404 with `model_not_found` records an availability/configuration blocker,
without assuming retirement or zero usage. Unknown usage stays held; the owner
notice uses bounded metadata and never exposes the private provider error. Provider-hosted
tools remain disabled until their metered integration is qualified.

Before an actual provider network client is created, `TransportConfig` requires
`privacy_configuration_json`. Its closed `retention` and `residency` documents
must match the original model profile's manifest-digest pins. Both include their
own `id`, integer `revision` and `provider`. Retention also requires the exact
`credentialRef`, `mode: "provider-account-managed"`, an explicit `accountPolicyRef`
and `requestStorage` (`"disabled"` for OpenAI, `"provider-account-managed"` for
Anthropic). Residency requires the exact `endpointRef`, `baseUrl`,
`placement: "global"` and `inferenceGeo: null`; the transport's `inference_geo`
must also be null. The existing canonical manifest hash defines both pins.
Unsupported regional placement or stronger retention claims fail closed.

These documents configure the supported request behavior and identify the
external account controls to qualify. They do not verify provider account
settings or establish zero retention, residency, billing or production readiness.
An injected official in-memory `MockTransport` may retain frozen unresolved
synthetic fixtures; a default or custom network adapter requires resolution.
No privacy document or secret is added to public events or workflow history.

The pinned OpenAI client uses HTTPX0.28.1 and the pinned Anthropic client uses
HTTPX2 2.13.1. Both already existed in the resolved graph and are now explicit
direct dependencies. Keep their distinct client/transport types; no SDK or
underlying distribution version was upgraded for this addition. Tests use actual
official clients with simulated HTTP, not paid calls or claims of live API success.

`model_rpc.py` implements that private `ModelBoundary` through an explicit HTTPS
URL and async workload-token callback. Construct `OfficialTransport` with the RPC
boundary; it binds the exact declared provider configuration before requesting
input. The kernel checks these settings against its immutable operator meter.
One client cannot be rebound to another model/limit configuration. The client has
no SQL, Host credentials or artifact keys. Its `accept_model` method retrieves
only the kernel-accepted private provider response; raw `invoke` observations
remain unaccepted. Cookies/browser identity do not supply workload authority.

Each boundary fetches a current service token without extending the original
task scope, operation lease or root deadline. Client failures never trigger a
second HTTP/provider attempt. An uncertain begin response can already represent
a committed start; recovery belongs to the durable kernel/controller. Independent
worker/SDK protocol checks use simulated HTTP; actual core SQL/Host private HTTP
checks are separate. The combined durable SDK/tool/checkpoint/Temporal pipeline,
live API conformance, production workload identity and deployment remain pending.

The private `execute-tool` action routes only to operator-registered governed
lanes. A read lane journals its exact accepted model/tool-call binding, reserves
tool and encrypted output capacity before dispatch, begins once, and preserves
known or UNKNOWN usage after cancellation and Stop. Accepted replay rechecks
current Host result access without another tool call. A resolve-only service
cannot execute a tool; missing profiles return `PROFILE_DISABLED`.

`sdk_tools.py` constructs a public SDK `FunctionTool` from the reviewed catalog
schema. It preserves the SDK call ID and original argument bytes and returns
only accepted output. Pending/uncertain work raises a private controller
condition. With `SDKModelSequence(..., dependency_boundary=boundary)`, the public
end hook retrieves the accepted model reference and each governed callback adds
its accepted result. Bounded encrypted result sets preserve larger parallel
batches. The kernel rechecks the complete causal source graph and exact SDK tool
outputs before model preparation, egress and accepted reuse. An installed SDK
loop completes six governed reads and replays without new dispatch; its provider
and Host/MCP replies are synthetic. Durable Temporal integration and production
qualification remain pending.

When restoring a governed-tool checkpoint, construct its tools with one
`SDKModelSequence` and pass that same instance and dependency boundary to
`restore_checkpoint`. The loader verifies the saved binding and preserves that
cursor for the callbacks. Creating a second sequence would disconnect restored
tool results from the following model operation. An actual public SDK pause,
restore and governed-tool continuation checks this behavior.

`private_history.py` adds the separate `agent-private-history/1` Temporal codec.
It requires an explicit history key identifier/port, original task context,
namespace and private storage boundary. It derives a keyed content identity,
looks up the original write before encrypting, and stores only an opaque private
payload ticket in Temporal. Known acknowledgement loss reuses the original
ciphertext; UNKNOWN storage never gets another identity or overwrite. Existing
history encodings are unchanged. Individual payload/batch bounds are wire limits,
not total task or tool limits.

Private messages above64KiB use the separately tagged
`binary/os-agent-private-history-deflate-v1` encoding. It preserves the complete
supported SDK checkpoint rather than truncating its transcript. Bounded deflate
runs before encryption with a distinct authenticated domain and content identity;
decryption precedes decompression, capped at1MiB with trailing/truncated streams
refused. Encrypted objects still fit the existing64KiB envelope/store contract,
and small/legacy payload encodings and identities remain unchanged. Mixed-format
replay requires this worker version; older workers fail closed on the new tag.
No Core contract, persisted SQL type or migration changes.

The workflow patch `private-opaque-protocol-metadata/1` selects authenticated
`binary/os-agent-protocol-metadata-hmac-v1` frames for internal operation and
checkpoint commands and accepted provider-result references. Only enforcing
worker code constructs the typed wrapper. Its closed projection contains opaque
UUIDs, ciphertext pins and acceptance timestamps; the complete original task
context is reconstructed from the codec's exact binding. A domain-separated
HMAC binds that context, history key, namespace and workflow. These frames carry
no source content or permission and perform no business-source history lookup.
Actual Core execution and disclosure still require current authority. Ordinary
dictionaries, source/model bytes, private checkpoints and commands with distinct
child/planner contexts retain encrypted, metered history. Unsigned frames,
foreign bindings and extra fields fail closed. Old histories keep their original
workflow branch and encodings. New-format histories require this compatible
decoder on replacement, replay and recovery; before rolling back to an older
binary, drain those executions or retain the compatible decoder. An older binary
cannot replay this new format. No SQL migration or public contract changes.

Current private clients use `history-create-v1` or the source-observed
`history-create-observe-v1` exchange instead of a separate lookup before each
write. Both reuse the existing closed history command/result contracts and
metered storage journal. A concurrent or repeated encoder receives the original
envelope and authenticates its keyed content identity. A candidate nonce may be
created locally, but it never replaces existing ciphertext or repeats an
UNKNOWN write. Existing-envelope disclosure retains the original current-source
and key-role checks. Deploy the compatible Core service before these workers;
the original put/lookup methods remain supported for older clients. Unsupported
services fail closed rather than falling back to an unobserved method.

The workflow patch `same-execution-checkpoint-state/1` retains the exact locally
exported SDK state for one immediate continuation after its original metered
checkpoint write is acknowledged. It avoids saving then loading the same value
in that execution. The durable checkpoint and normal provider/tool authority
boundaries remain mandatory. Continue-As-New, waits/errors and checkpoints
requiring query refresh use the normal governed load; no saved state or
authorization cache crosses these boundaries. Worker replay reconstructs this
local state from its original history and does not issue another checkpoint
write or tool/model operation.

The kernel's explicitly configured private state service supplies checkpoint
put/get and encrypted history put/lookup through original-root storage. The
installed codec/client uses actual private HTTP/SQL without kernel imports or
artifact keys. Closed-root terminal outcomes, larger context paging,
erasure/retention and AWS key placement remain separate gates.

`temporal_runtime.py` explicitly wires `OSAgentTaskDriver/1`, the official Agents
plugin, private converter/key port and separately durable kernel Activities.
The SDK retains control of model/tool iteration with `max_turns=None`. Supported
read interruptions archive the public RunState before tool execution; kernel
authorization still precedes every dispatch. Continue-As-New preserves the
original root, task-derived SDK identity, next turn and absolute horizon.
The final SDK response supplies only a private candidate reference for the
kernel's later completion assessment. It cannot establish verified completion.

Typed, bounded root/task/status metadata can carry Stop and wait signals without
new private storage. User/model dictionaries remain encrypted private data even
when they resemble that metadata. Failure conversion preserves only closed
typed waits, including Temporal Activity wrappers. Unknown provider/tool work
waits for reconciliation; worker replacement/resume cannot dispatch it again.
Actual installed SDK/Temporal/private HTTP/SQL checks cover read continuation,
two run segments, worker replacement, history replay, provider/tool uncertainty
and checkpoint acknowledgement loss. The retained installed modules match their
source hashes; tests require a fresh install and verify those bytes before work.
Provider and Host/MCP returns are synthetic. Resource/input/review waits,
closed-root recovery, full crash qualification, authoritative plans/delegation,
actual Host read authorization and later packages remain open. No default
runtime or production route is enabled.

Assigned local and Cloud worker configuration may set `reasoningEffort` to
`none`, `low`, `medium`, `high` or `xhigh` for a compatible OpenAI model.
Omitting it preserves the previous provider default. The setting applies to
the public worker model, independently of any separately configured private
planner. It enters the immutable staged provider input before reservation and
dispatch; reasoning tokens share the original output-token and cost bounds.
Keep the original configuration when resuming an admitted task. This setting
does not renew a deadline, increase an allowance or enable tracing. Model
support and live qualification remain the operator's responsibility.

The explicit synthetic laboratory qualification profile pins
`gpt-5.4-2026-03-05` with reasoning `none`, the full 1,050,000-token
context declaration and 4,096 output tokens. Its separate new-task ceiling
is $6; older qualification profiles retain their $0.50 ceiling. The existing
allowance ledger retains every prior reservation and UNKNOWN hold. This
profile uses conservative long-context upper-bound rates for all requests;
recorded costs are upper bounds, rather than provider invoices. See the
[official model limits and pricing](https://developers.openai.com/api/docs/models/gpt-5.4).
This test profile changes neither production defaults nor an admitted task.
